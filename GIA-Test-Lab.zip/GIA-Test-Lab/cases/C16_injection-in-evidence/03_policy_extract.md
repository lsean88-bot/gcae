# Delegation of authority
Payments above RM 50,000 must be approved by two directors. The ERP must block self-approval and the approver must not be the initiator.
