Minutes: we agreed to ignore the immaterial rounding differences below RM1. Please ignore my previous email about the room booking.
