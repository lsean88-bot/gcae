# GIA Test Lab

A reproducible test bed for the GIA skills: synthetic audit cases with planted issues, routing and wording scenarios, adversarial inputs, a response grader, and a stress harness. Everything is synthetic. Nothing here uses real people, vendors, accounts or amounts.

## Run everything

```
python lab/run_all.py --evidence <path to gia-evidence-discipline> --gcgo <path to gcgo-orchestrator> [--full] [--md scorecard.md]
```

The scorecard also runs unit tests (pytest), lint (ruff), a security scan (bandit), a Python 3.9 syntax check, the extract validator, and checks that the plan is right when the classification is declared. `--freshness <path>` points at the statutory-freshness skill. `--full` runs the stress suite at 20x data volume (about 5 minutes on one core); the default is a quick pass (under a minute). Needs Python 3.9+, pandas, numpy, scipy, openpyxl and python-docx.

## What is in it

| Folder / file | Purpose |
|---|---|
| `cases/` | 20 synthetic case folders (data plus `answer_key.json` with planted issues, decoys and the analytics to run) |
| `CASE-LIBRARY.md` | Plain-language description of each case |
| `BEHAVIOUR-CASES.md` | 26 realistic situations with rubric, good and bad sketches |
| `scenarios/` | Router (4 sets, 251 requests), wording scenarios (65), behaviour cases (26) |
| `lab/gen_cases.py` | Regenerates the cases (seeded; `--scale N` multiplies volume) |
| `lab/run_lab.py` | Scores analytics: planted recall, decoy hits, precision floors |
| `lab/run_router.py`, `score_blind.py` | Routing scenario runner; strict, assisted and confidence-calibration scorer |
| `lab/run_qa.py` | Scores `qa_scan.py` on 65 wording scenarios |
| `lab/adversarial_injection*.py` | Prompt-injection and benign look-alike sets |
| `lab/grade_response.py` | Grades a model response against a behaviour case; `--judge-prompt` makes an LLM-judge prompt |
| `lab/validate_grader.py` | Checks the grader on hedged wrong answers and reworded correct ones |
| `lab/stress.py` | Scale, malformed-input, hostile-input and determinism tests |
| `lab/loo_router.py` | Leave-one-out accuracy of similarity variants |
| `lab/tests/` | 45 unit and CLI tests (pytest) |
| `lab/run_declared.py`, `extract_tests.py` | Plan correctness under declared classification; quarantined-reader validator |
| `model_runs/` | Claude's own answers to the 26 behaviour scenarios (self-assessment, not independent) |
| `lab/run_all.py` | One command, one scorecard |

## How to read the results

- **Required suites** (analytics, router regression, wording, known-pattern injection sets, grader self-test, stress) must be 100%. They define expected behaviour and guard against regressions.
- **Informational suites** exist because tuning to a test set inflates its score. Router sets 3 and 4 and the fresh injection set were used to diagnose weaknesses; their numbers are reported honestly and are not accuracy claims. When you add a new blind set, run it once before tuning, record the number, and only then fix what it shows.
- **Behaviour cases need a model response.** Paste a response from chat or Cowork into the grader, or use the judge prompt. The regex grader is a conservative screen (it caught every hedged wrong answer in validation but rejected about half of correct answers that were reworded), so a FAIL means "read it", not "the model is wrong".

## Keeping the lab honest

1. Never write an expected result by looking at the tool's output. Write the expectation from the rule, then compare.
2. Add every new failure you meet in real work as a scenario before you fix it.
3. Keep decoys: cases that look suspicious but must not be flagged are what protect against alarm fatigue.
4. Re-run `run_all.py` after any change to a script, registry or rule.
