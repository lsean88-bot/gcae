# Stress test: 45/45 passed (analytics scale x20)

| Test | Result | Seconds | Peak MB | Note |
|---|---|---|---|---|
| router: 3000 random requests, no exceptions | PASS | 31.71 |  | 0 exceptions; 10.6 ms/request |
| router: deterministic (same input, same plan) | PASS | 0 |  |  |
| router: hostile/odd inputs (empty, 200k chars, control chars, RTL, emoji) | PASS | 7.23 |  |  |
| qa_scan: large markdown (lines) | PASS | 5.87 | 69 |  |
| qa_scan: 2.6MB single paragraph | PASS | 8.92 |  |  |
| qa_scan: random binary bytes as .md | PASS | 0.64 |  |  |
| qa_scan: missing file gives a message, not a traceback | PASS | 0.06 |  |  |
| qa_scan: docx with 400 tables | PASS | 1.73 |  |  |
| qa_scan: corrupt .docx handled | PASS | 0.13 |  | Could not read corrupt.docx as a Word document (PackageNotFoundError). Is the fi |
| analytics duplicates (~40,180 rows) | PASS | 5.46 | 259 |  |
| analytics split (~40,180 rows) | PASS | 1.89 | 259 |  |
| analytics benford (~65,200 rows) | PASS | 2.36 | 259 |  |
| analytics match-masters (~150 rows) | PASS | 0.48 | 259 |  |
| analytics ghost (~6,000 rows) | PASS | 0.72 | 259 |  |
| analytics ot (~2,145 rows) | PASS | 1.4 | 259 |  |
| analytics je-test (~80,000 rows) | PASS | 0.94 | 259 |  |
| analytics messy input: bom.csv | PASS | 0.5 |  | # duplicates |
| analytics messy input: latin1.csv | PASS | 0.51 |  | # duplicates |
| analytics messy input: semicolon.csv | PASS | 0.53 |  | # duplicates |
| analytics messy input: header_only.csv | PASS | 0.54 |  | Error: /tmp/stress_full2/messy/header_only.csv has no data rows (after --where filter, if  |
| analytics messy input: empty.csv | PASS | 0.47 |  | Error: /tmp/stress_full2/messy/empty.csv is empty. |
| analytics messy input: one_row.csv | PASS | 0.51 |  | # duplicates |
| analytics messy input: all_nan.csv | PASS | 0.5 |  | # duplicates |
| analytics messy input: huge.csv | PASS | 0.51 |  | # duplicates |
| analytics messy input: unicode.csv | PASS | 0.5 |  | # duplicates |
| analytics messy input: dupcols.csv | PASS | 0.57 |  | # duplicates |
| analytics messy input: notcsv.csv | PASS | 0.57 |  | Error: /tmp/stress_full2/messy/notcsv.csv could not be parsed as CSV (Error tokenizing dat |
| analytics messy input: ragged.csv | PASS | 0.53 |  | # duplicates |
| analytics messy input: book.xlsx | PASS | 0.71 |  | # duplicates |
| analytics: all-blank amounts give a message | PASS | 0.56 |  |  |
| analytics: parentheses = negative, currency text parsed | PASS | 0.65 |  |  |
| analytics: --where expression cannot run shell commands | PASS | 0.53 |  | expression rejected or inert |
| init_engagement: '../../escape' must not write outside --dest | PASS | 0.85 |  | path traversal blocked |
| init_engagement: absolute path as ref must not escape | PASS | 0.38 |  |  |
| init_engagement: odd ref 'GIA MKPC 2026 test' | PASS | 0.47 |  |  |
| init_engagement: odd ref 'GIA-ünïcode-டெஸ்ட்-001' | PASS | 0.48 |  |  |
| init_engagement: odd ref 'aaaaaaaaaaaaaaaaaaaaaaaa' | PASS | 0.32 |  | Invalid --ref: longer than 120 bytes; use a shorter engagement reference. |
| init_engagement: 40 engagements | PASS | 17.26 |  |  |
| init_engagement: re-run is idempotent (no overwrite) | PASS | 0 |  |   files created: 0 |
| status board with 20,000 exception rows | PASS | 3.2 | 259 |  |
| status board: corrupt register file handled | PASS | 3.16 |  | ok |
| status board: missing folder gives a message | PASS | 0.28 |  |  |
| injection scan: 804 files incl. 4.8MB text and corrupt office files | PASS | 13.78 | 259 |  |
| router: corrupt registry JSON gives a message | PASS | 0.06 |  | Registry /tmp/stress_full2/reg_bad.json is not valid JSON (Expecting property name enclose |
| router: missing registry gives a message | PASS | 0.07 |  |  |