# GIA Test Lab scorecard

PASS  analytics                                             43/43 runs passed (32s)
PASS  router router_scenarios.json                          94/94 passed
PASS  router router_holdout.json                            50/50 passed
PASS  router-info router_blind.json                         strict 29%, assisted 78%
PASS  router-info router_blind2.json                        strict 42%, assisted 82%
PASS  router: plan correct when classification is declared  164/164
PASS  extract validator (quarantined reader)                extract validator: 15/15 correct
PASS  unit tests (pytest)                                   45 passed in 10.38s
PASS  lint (ruff E9,F,B)                                    clean
PASS  security scan (bandit medium+)                        no medium or high findings
PASS  Python 3.9 syntax compatibility                       all scripts parse
PASS  qa_scan                                               65/65 passed
PASS  injection adversarial_injection.py                    adversarial injection: 45/45 correct
PASS  injection adversarial_injection_blind.py              BLIND injection set: 30/30 correct | attacks caught 15/15 | false positives 0/15
PASS  injection adversarial_injection_blind2.py             FRESH BLIND injection set: attacks caught 1/20 (5%) | false positives 2/20 (10%)
PASS  grader self-test                                      grader self-test: 26/26 cases discriminate good from bad
PASS  grader validation (hedged / reworded)                 grader validation on hedged-bad and reworded-good answers: correct 15/21  | bad answers caught 10/10 | good answers passed 5/11
PASS  stress (full)                                         45/45 passed (138s)

Overall: ALL REQUIRED SUITES PASS