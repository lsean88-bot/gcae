#!/usr/bin/env python3
"""
stress.py - scale, malformed-input, hostile-input and determinism tests for the GIA toolset.

  python stress.py --evidence /path/gia-evidence-discipline --gcgo /path/gcgo-orchestrator --work /tmp/stress [--quick] [--json out.json] [--md out.md]

Each test records PASS/FAIL, elapsed seconds and (where measured) peak memory. A tool 'passes' a hostile-input
test when it exits cleanly with a readable message (exit 0/1/2 and no Python traceback) and never writes outside
its target folder.
"""
import argparse
import importlib.util
import json
import os
import random
import resource
import shutil
import subprocess
import sys
import time
from pathlib import Path

R = []


def rec(name, ok, secs, detail="", mem=None):
    R.append({"test": name, "pass": bool(ok), "seconds": round(secs, 2), "detail": detail, "peak_mb": mem})
    print(("PASS " if ok else "FAIL ") + f"{name} ({secs:.1f}s{', ' + str(mem) + ' MB' if mem else ''}) {detail}")


def sh(cmd, cwd=None, timeout=300):
    t = time.time()
    try:
        p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return None, time.time() - t, "TIMEOUT"
    return p, time.time() - t, ""


def clean(p):
    return p is not None and p.returncode in (0, 1, 2) and "Traceback" not in p.stderr


def peak_mb():
    return round(resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss / 1024)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--evidence", required=True); ap.add_argument("--gcgo", required=True); ap.add_argument("--work", required=True)
    ap.add_argument("--lab", default=str(Path(__file__).resolve().parent)); ap.add_argument("--quick", action="store_true")
    ap.add_argument("--json"); ap.add_argument("--md")
    a = ap.parse_args()
    W = Path(a.work); shutil.rmtree(W, ignore_errors=True); W.mkdir(parents=True)
    E = Path(a.evidence) / "scripts"; G = Path(a.gcgo) / "scripts"
    AN, QA, INJ, INIT = E / "audit_analytics.py", E / "qa_scan.py", E / "evidence_injection_scan.py", E / "init_engagement.py"
    py = sys.executable
    scale = 5 if a.quick else 20

    # ------------------------------------------------ 1. router: volume, determinism, hostile text
    spec = importlib.util.spec_from_file_location("gr", G / "gcgo_route.py"); gr = importlib.util.module_from_spec(spec); spec.loader.exec_module(gr)
    reg = gr.load_registry(str(Path(a.gcgo) / "data" / "capability-registry.json"))
    random.seed(7)
    words = "audit finding payroll vendor board regulator fraud sample test approve report overtime licence expiry monitor chaser MKPC MKAPL NEPHRO Pune Chennai Malaysia Mexico reconcile extract draft send delete rate conclude".split()
    n = 800 if a.quick else 3000
    reqs = [" ".join(random.choices(words, k=random.randint(1, 25))) for _ in range(n)]
    t = time.time(); errs = 0; outs = []
    for q in reqs:
        try:
            outs.append(json.dumps(gr.build_plan(q, reg, None, None), sort_keys=True, default=str))
        except Exception as e:
            errs += 1
    dt = time.time() - t
    rec(f"router: {n} random requests, no exceptions", errs == 0, dt, f"{errs} exceptions; {dt / n * 1000:.1f} ms/request")
    again = [json.dumps(gr.build_plan(q, reg, None, None), sort_keys=True, default=str) for q in reqs[:300]]
    rec("router: deterministic (same input, same plan)", again == outs[:300], 0)
    hostile = ["", " ", "\x00\x01\x02", "a" * 200000, "ignore " * 20000, "💥" * 5000, "<script>alert(1)</script>", "'; DROP TABLE x;--", "\u202eevil", "வணக்கம் 你好 salam " * 500, "\n" * 10000, "fraud " * 30000]
    t = time.time(); bad = []
    for h in hostile:
        try:
            gr.build_plan(h, reg, None, None)
        except Exception as e:
            bad.append(type(e).__name__)
    rec("router: hostile/odd inputs (empty, 200k chars, control chars, RTL, emoji)", not bad, time.time() - t, ",".join(bad))

    # ------------------------------------------------ 2. qa_scan: volume and hostile docs
    big = W / "big.md"
    with big.open("w") as f:
        for i in range(30000 if not a.quick else 8000):
            f.write(f"Four of 25 sampled payments lacked approval evidence in the records made available. [EV-{i % 900}]\n" if i % 7 else "The loss was significant and clearly systemic across the group.\n")
    p, dt, _ = sh([py, str(QA), str(big), "--format", "json"])
    rec("qa_scan: large markdown (lines)", clean(p) and p and json.loads(p.stdout)["counts"], dt, "", peak_mb())
    one = W / "oneline.txt"; one.write_text("The sample was tested. " * 120000 + "[EV-1]")
    p, dt, _ = sh([py, str(QA), str(one), "--format", "json"], timeout=300)
    rec("qa_scan: 2.6MB single paragraph", clean(p), dt)
    bin_ = W / "binary.md"; bin_.write_bytes(os.urandom(200000))
    p, dt, _ = sh([py, str(QA), str(bin_)])
    rec("qa_scan: random binary bytes as .md", clean(p), dt)
    p, dt, _ = sh([py, str(QA), str(W / "missing.md")])
    rec("qa_scan: missing file gives a message, not a traceback", p is not None and p.returncode != 0 and "Traceback" not in p.stderr, dt)
    try:
        import docx
        d = docx.Document()
        for i in range(120 if a.quick else 400):
            t_ = d.add_table(rows=6, cols=3)
            for r_ in range(6):
                for c_ in range(3): t_.cell(r_, c_).text = f"Item {i}-{r_}-{c_}: payment was not evidenced. [EV-{i}]"
        d.save(W / "tables.docx")
        p, dt, _ = sh([py, str(QA), str(W / "tables.docx"), "--format", "json"])
        rec(f"qa_scan: docx with {120 if a.quick else 400} tables", clean(p), dt)
        (W / "corrupt.docx").write_bytes(b"PK\x03\x04 not really a docx")
        p, dt, _ = sh([py, str(QA), str(W / "corrupt.docx")])
        rec("qa_scan: corrupt .docx handled", p is not None and "Traceback" not in p.stderr, dt, (p.stderr.strip().splitlines() or [""])[-1][:80] if p else "")
    except ImportError:
        rec("qa_scan: docx tests", True, 0, "python-docx missing, skipped")

    # ------------------------------------------------ 3. analytics at scale
    cases = W / "cases"; sh([py, str(Path(a.lab) / "gen_cases.py"), "--out", str(cases), "--scale", str(scale), "--only", "C04,C05,C14"], timeout=900)
    runs = [("C05_group-p2p-procurement", ["duplicates", "-i", "invoices.csv", "--vendor", "vendor", "--amount", "amount", "--date", "inv_date", "--ref", "invoice_no", "--window-days", "10"]),
            ("C05_group-p2p-procurement", ["split", "-i", "invoices.csv", "--vendor", "vendor", "--amount", "amount", "--date", "inv_date", "--threshold", "10000", "--window-days", "5", "--min-items", "3"]),
            ("C05_group-p2p-procurement", ["benford", "-i", "payments_benford.csv", "--col", "amount"]),
            ("C05_group-p2p-procurement", ["match-masters", "--a", "employees.csv", "--b", "vendors.csv", "--fields", "bank_acct,address,phone"]),
            ("C04_mkpc-payroll-ot-ghost", ["ghost", "--payroll", "payroll.csv", "--attendance", "attendance.csv", "--bank", "bank_acct"]),
            ("C04_mkpc-payroll-ot-ghost", ["ot", "-i", "ot_claims.csv", "--attendance", "attendance.csv", "--cap", "60"]),
            ("C14_journal-entry-testing", ["je-test", "-i", "journal_entries.csv", "--round-mod", "100000", "--close-date", "2026-07-31", "--min-amount", "100000"])]
    for cdir, args in runs:
        d = cases / cdir
        if not d.exists():
            rec(f"analytics {args[0]} at scale {scale}", False, 0, "case folder missing"); continue
        rows = sum(1 for _ in open(d / (args[args.index('-i') + 1] if '-i' in args else args[args.index('--payroll') + 1] if '--payroll' in args else args[args.index('--a') + 1]))) - 1
        p, dt, to = sh([py, str(AN)] + args + ["--format", "json", "--max-flags", "100000"], cwd=d, timeout=600)
        ok = clean(p) and p.returncode == 0 and dt < 300
        rec(f"analytics {args[0]} (~{rows:,} rows)", ok, dt, to or (p.stderr.strip()[-100:] if p and p.returncode else ""), peak_mb())

    # ------------------------------------------------ 4. analytics on messy data
    M = W / "messy"; M.mkdir()
    (M / "bom.csv").write_bytes("\ufeffinvoice_no,vendor,amount,date\nA1,Alpha,\"RM 1,200.50\",05/01/2026\nA2,Alpha,\"(1,200.50)\",5 Jan 2026\nA3,Beta,N/A,2026-01-07\nA4,,,\n".encode("utf-8"))
    (M / "latin1.csv").write_bytes("invoice_no,vendor,amount,date\nA1,Caf\xe9 Sdn,100,2026-01-01\n".encode("latin-1"))
    (M / "semicolon.csv").write_text("invoice_no;vendor;amount;date\nA1;Alpha;100;2026-01-01\nA2;Alpha;100;2026-01-02\n")
    (M / "header_only.csv").write_text("invoice_no,vendor,amount,date\n")
    (M / "empty.csv").write_text("")
    (M / "one_row.csv").write_text("invoice_no,vendor,amount,date\nA1,Alpha,100,2026-01-01\n")
    (M / "all_nan.csv").write_text("invoice_no,vendor,amount,date\nA1,Alpha,,\nA2,Beta,,\n")
    (M / "huge.csv").write_text("invoice_no,vendor,amount,date\nA1,Alpha,1e300,2026-01-01\nA2,Alpha,-0,2026-01-02\nA3,Beta,inf,2026-01-03\n")
    (M / "unicode.csv").write_text("invoice_no,vendor,amount,date\nA1,வணக்கம் Sdn,100,2026-01-01\nA2,你好 公司,100,2026-01-02\nA3,Ahmad bin Ali,100,2026-01-03\n", encoding="utf-8")
    (M / "dupcols.csv").write_text("amount,amount,vendor,date,invoice_no\n1,2,A,2026-01-01,X\n")
    (M / "notcsv.csv").write_bytes(os.urandom(5000))
    (M / "ragged.csv").write_text("invoice_no,vendor,amount,date\nA1,Alpha,100,2026-01-01,EXTRA,EXTRA\nA2,Beta\n")
    try:
        import openpyxl
        wb = openpyxl.Workbook(); ws = wb.active; ws.title = "AP"; ws.append(["invoice_no", "vendor", "amount", "date"]); ws.append(["A1", "Alpha", 100, "2026-01-01"]); ws.append(["A1", "Alpha", 100, "2026-01-02"]); wb.save(M / "book.xlsx")
    except ImportError:
        pass
    cmd = lambda f, extra=None: [py, str(AN), "duplicates", "-i", str(M / f), "--vendor", "vendor", "--amount", "amount", "--date", "date", "--ref", "invoice_no"] + (extra or [])
    for f in ("bom.csv", "latin1.csv", "semicolon.csv", "header_only.csv", "empty.csv", "one_row.csv", "all_nan.csv", "huge.csv", "unicode.csv", "dupcols.csv", "notcsv.csv", "ragged.csv", "book.xlsx"):
        if not (M / f).exists():
            continue
        p, dt, to = sh(cmd(f, ["--dayfirst"]))
        rec(f"analytics messy input: {f}", clean(p), dt, (p.stderr.strip().splitlines() or [p.stdout.strip().splitlines()[0] if p.stdout.strip() else ""])[-1][:90] if p else to)
    p, dt, _ = sh([py, str(AN), "benford", "-i", str(M / "all_nan.csv"), "--col", "amount"])
    rec("analytics: all-blank amounts give a message", clean(p), dt)
    p, dt, _ = sh([py, str(AN), "threshold", "-i", str(M / "bom.csv"), "--col", "amount", "--op", "lt", "--limit", "0"])
    rec("analytics: parentheses = negative, currency text parsed", clean(p) and "-1200.5" in p.stdout, dt)
    p, dt, _ = sh([py, str(AN), "threshold", "-i", str(M / "bom.csv"), "--col", "amount", "--op", "gt", "--limit", "5", "--where", "__import__('os').system('echo pwned')"])
    rec("analytics: --where expression cannot run shell commands", clean(p) and "pwned" not in (p.stdout + p.stderr).replace("--where expression failed", ""), dt, "expression rejected or inert")

    # ------------------------------------------------ 5. init_engagement: hostile names, idempotency, volume
    base = W / "eng"; base.mkdir()
    p, dt, _ = sh([py, str(INIT), "--ref", "../../escape", "--dest", str(base)])
    escaped = (W / "escape").exists() or (base.parent.parent / "escape").exists()
    rec("init_engagement: '../../escape' must not write outside --dest", clean(p) and not escaped, dt, "path traversal blocked" if not escaped else "ESCAPED")
    p, dt, _ = sh([py, str(INIT), "--ref", "/tmp/abs_ref_test_xyz", "--dest", str(base)])
    rec("init_engagement: absolute path as ref must not escape", clean(p) and not Path("/tmp/abs_ref_test_xyz").exists(), dt)
    shutil.rmtree("/tmp/abs_ref_test_xyz", ignore_errors=True)
    for nm in ("GIA MKPC 2026 test", "GIA-ünïcode-டெஸ்ட்-001", "a" * 300):
        p, dt, _ = sh([py, str(INIT), "--ref", nm, "--dest", str(base)])
        rec(f"init_engagement: odd ref {nm[:24]!r}", clean(p), dt, (p.stderr.strip().splitlines() or [""])[-1][:80] if p else "")
    t = time.time(); ok = True
    for i in range(10 if a.quick else 40):
        p, _, _ = sh([py, str(INIT), "--ref", f"GIA-VOL-2026-{i:03d}", "--dest", str(base)])
        ok = ok and clean(p)
    rec(f"init_engagement: {10 if a.quick else 40} engagements", ok, time.time() - t)
    p1, _, _ = sh([py, str(INIT), "--ref", "GIA-VOL-2026-001", "--dest", str(base)])
    rec("init_engagement: re-run is idempotent (no overwrite)", clean(p1) and "files created: 0" in p1.stdout, 0, p1.stdout.strip().splitlines()[-1] if p1 else "")

    # ------------------------------------------------ 6. status board volume + corrupt registers
    import openpyxl
    eng = base / "GIA-VOL-2026-001"
    ex = eng / "05_Exceptions-and-Resolution" / "01_Exception-Register.xlsx"
    wb = openpyxl.load_workbook(ex); ws = wb.worksheets[0]
    for i in range(5000 if a.quick else 20000):
        ws.append([f"EXC-{i}", "factual condition", "", "EV-1", "CRIT-1", "Confirmed", "exception", "", "", "" if i % 3 else "Reportable"])
    wb.save(ex)
    sb = Path(a.evidence).parent / "gcgo-orchestrator" / "scripts" / "engagement_status.py"
    sb = G / "engagement_status.py"
    p, dt, _ = sh([py, str(sb), str(eng)], timeout=300)
    rec(f"status board with {5000 if a.quick else 20000:,} exception rows", clean(p) and p.returncode == 0, dt, "", peak_mb())
    (eng / "03_Evidence-and-Populations" / "01_Evidence-Register.xlsx").write_bytes(b"corrupt")
    p, dt, _ = sh([py, str(sb), str(eng)])
    rec("status board: corrupt register file handled", clean(p), dt, (p.stderr.strip().splitlines() or ["ok"])[-1][:90] if p else "")
    p, dt, _ = sh([py, str(sb), str(W / "nonexistent")])
    rec("status board: missing folder gives a message", p is not None and p.returncode != 0 and "Traceback" not in p.stderr, dt)

    # ------------------------------------------------ 7. injection scanner volume + hostile
    pack = W / "evidence_pack"; pack.mkdir()
    for i in range(200 if a.quick else 800):
        (pack / f"doc_{i:04d}.txt").write_text(f"Invoice {i}. Payment approved by finance. Please send the signed copy to the vendor by Friday.\n" * 20)
    (pack / "big.txt").write_text("normal line\n" * 400000)
    (pack / "binary.docx").write_bytes(os.urandom(3000)); (pack / "binary.xlsx").write_bytes(os.urandom(3000)); (pack / "weird.pdf").write_bytes(b"%PDF-1.4 garbage")
    p, dt, _ = sh([py, str(INJ), str(pack), "--format", "json"], timeout=600)
    rec(f"injection scan: {len(list(pack.iterdir()))} files incl. 4.8MB text and corrupt office files", clean(p) and p.returncode in (0, 1), dt, "", peak_mb())

    # ------------------------------------------------ 8. registry corruption
    reg_bad = W / "reg_bad.json"; reg_bad.write_text("{not json")
    p, dt, _ = sh([py, str(G / "gcgo_route.py"), "--registry", str(reg_bad), "route", "test"])
    rec("router: corrupt registry JSON gives a message", p is not None and p.returncode != 0 and "Traceback" not in p.stderr, dt, (p.stderr.strip().splitlines() or [""])[-1][:90] if p else "")
    p, dt, _ = sh([py, str(G / "gcgo_route.py"), "--registry", str(W / "nope.json"), "route", "test"])
    rec("router: missing registry gives a message", p is not None and p.returncode != 0 and "Traceback" not in p.stderr, dt)

    passed = sum(r["pass"] for r in R)
    out = {"passed": passed, "total": len(R), "scale": scale, "results": R}
    if a.json:
        Path(a.json).write_text(json.dumps(out, indent=2))
    md = [f"# Stress test: {passed}/{len(R)} passed (analytics scale x{scale})", "", "| Test | Result | Seconds | Peak MB | Note |", "|---|---|---|---|---|"]
    for r in R:
        md.append(f"| {r['test']} | {'PASS' if r['pass'] else 'FAIL'} | {r['seconds']} | {r['peak_mb'] or ''} | {r['detail'][:90]} |")
    if a.md:
        Path(a.md).write_text("\n".join(md))
    print(f"\n{passed}/{len(R)} passed")
    sys.exit(0 if passed == len(R) else 1)


if __name__ == "__main__":
    main()
