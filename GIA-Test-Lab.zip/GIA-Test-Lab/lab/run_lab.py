#!/usr/bin/env python3
"""
run_lab.py - run the analytics procedures against every case and score recall / precision / decoy hits.

  python run_lab.py --cases ../cases --analytics /path/to/audit_analytics.py [--json score.json] [--md score.md]

A run PASSES when every planted item is flagged (recall 100%), no decoy is flagged, and any declared
precision floor is met. Row numbers are spreadsheet rows (header = row 1).
"""
import argparse
import json
import re
import subprocess
import sys
import time
from pathlib import Path


def resolve(spec, key):
    out = set()
    for part in str(spec).split("+"):
        part = part.strip()
        src = key["decoys"] if part.startswith("decoys.") else key["planted"]
        name = part.split(".", 1)[1] if part.startswith("decoys.") else part
        v = src.get(name, [])
        out |= set(v if isinstance(v, list) else [v])
    return out


def rows_in(flags):
    s = set()
    for f in flags:
        for m in re.finditer(r"row (\d+)", f["reference"]):
            s.add(int(m.group(1)))
    return s


def run_injection(case_dir, key, analytics):
    scanner = Path(analytics).parent / "evidence_injection_scan.py"
    t = time.time()
    p = subprocess.run([sys.executable, str(scanner), str(case_dir), "--format", "json"], capture_output=True, text=True)
    dt = time.time() - t
    if p.returncode not in (0, 1):
        return None, dt, p.stderr[-200:]
    res = json.loads(p.stdout)
    probs = []
    by = {}
    for f in res["findings"]:
        by.setdefault(Path(f["file"]).name, set()).add(f["category"])
    for fn, cats in key["planted"]["flag_files"].items():
        for c in cats:
            if c not in by.get(fn, set()):
                probs.append(f"{fn}: missing {c} (got {sorted(by.get(fn, []))})")
    for fn in key["decoys"]["clean_files"]:
        if by.get(fn):
            probs.append(f"{fn}: false positive {sorted(by[fn])}")
    return probs, dt, ""


def run_freshness(case_dir, run, analytics, freshness):
    script = Path(freshness) / "scripts" / "check_rates.py"
    t = time.time()
    p = subprocess.run([sys.executable, str(script)] + run["args"] + ["--format", "json"], cwd=case_dir, capture_output=True, text=True)
    dt = time.time() - t
    if p.returncode not in (0, 1):
        return ["tool error: " + p.stderr[-150:]], dt
    res = json.loads(p.stdout)
    cats = {f["category"] for f in res["findings"]}
    probs = []
    for c in run["expect"].get("categories", []):
        if c not in cats: probs.append(f"expected {c}, got {sorted(cats)}")
    if run["expect"].get("no_high") and any(f["severity"] == "HIGH" for f in res["findings"]):
        probs.append("unexpected HIGH finding(s): " + "; ".join(f["detail"][:60] for f in res["findings"] if f["severity"] == "HIGH"))
    return probs, dt


def run_one(analytics, case_dir, run):
    cmd = [sys.executable, str(analytics), run["procedure"], *run["args"], "--format", "json", "--max-flags", "100000"]
    t = time.time()
    p = subprocess.run(cmd, cwd=case_dir, capture_output=True, text=True)
    dt = time.time() - t
    if p.returncode != 0:
        return None, dt, p.stderr.strip()[:300]
    return json.loads(p.stdout), dt, ""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cases", required=True)
    ap.add_argument("--analytics", required=True)
    ap.add_argument("--json"); ap.add_argument("--md")
    ap.add_argument("--only")
    ap.add_argument("--freshness", default=None)
    a = ap.parse_args()
    if not a.freshness:
        a.freshness = str(Path(a.analytics).resolve().parents[2] / "gia-statutory-freshness")
    results = []
    for d in sorted(Path(a.cases).iterdir()):
        if not (d / "answer_key.json").exists():
            continue
        if a.only and d.name.split("_")[0] not in a.only.split(","):
            continue
        key = json.loads((d / "answer_key.json").read_text())
        for run in key["runs"]:
            if run.get("tool") == "freshness":
                probs, dt = run_freshness(d, run, a.analytics, a.freshness)
                results.append({"case": key["case_id"], "slug": key["slug"], "procedure": "check_rates", "label": run["args"][1], "seconds": round(dt, 2), "pass": not probs, "problems": probs, "flag_count": "-"})
                continue
            if run.get("tool") == "injection":
                probs, dt, err = run_injection(d, key, a.analytics)
                results.append({"case": key["case_id"], "slug": key["slug"], "procedure": "injection-scan", "label": "", "seconds": round(dt, 2), "pass": probs == [] and not err, "problems": (probs or []) + ([err] if err else []), "flag_count": "-"})
                continue
            res, dt, err = run_one(a.analytics, d, run)
            rec = {"case": key["case_id"], "slug": key["slug"], "procedure": run["procedure"], "label": run.get("label", ""), "seconds": round(dt, 2), "pass": True, "problems": []}
            if res is None:
                rec["pass"] = False; rec["problems"].append("tool error: " + err); results.append(rec); continue
            flags = res["flags"]; ex = run.get("expect", {}); text = " ".join(f["reference"] + " " + f["detail"] for f in flags).lower()
            frows = rows_in(flags)
            rec["flag_count"] = len(flags)
            if "flags" in ex:
                if bool(flags) != ex["flags"]:
                    rec["pass"] = False; rec["problems"].append(f"expected flags={ex['flags']} got {len(flags)}")
            if "must_flag_rows" in ex:
                planted = resolve(ex["must_flag_rows"], key)
                miss = sorted(planted - frows)
                rec["recall"] = round(1 - len(miss) / len(planted), 3) if planted else 1.0
                rec["planted"] = len(planted)
                if miss:
                    rec["pass"] = False; rec["problems"].append(f"missed {len(miss)} planted rows: {miss[:15]}")
                if "min_precision_rows" in ex and frows:
                    prec = len(frows & planted) / len(frows)
                    rec["precision"] = round(prec, 3)
                    if prec < ex["min_precision_rows"]:
                        rec["pass"] = False; rec["problems"].append(f"precision {prec:.2f} < {ex['min_precision_rows']}; extra rows {sorted(frows - planted)[:15]}")
            if "must_not_flag_rows" in ex:
                dec = resolve(ex["must_not_flag_rows"], key)
                hit = sorted(dec & frows)
                rec["decoy_hits"] = len(hit)
                if hit:
                    rec["pass"] = False; rec["problems"].append(f"flagged {len(hit)} decoy rows: {hit[:15]}")
            for g in ("must_flag_groups",):
                if g in ex:
                    want = resolve(ex[g], key)
                    miss = [w for w in want if w.lower() not in text]
                    if miss: rec["pass"] = False; rec["problems"].append(f"missed groups {miss}")
            if "must_not_flag_groups" in ex:
                dec = resolve(ex["must_not_flag_groups"], key)
                hit = [w for w in dec if w.lower() in text]
                if hit: rec["pass"] = False; rec["problems"].append(f"flagged decoy groups {hit}")
            if "must_flag_text" in ex:
                want = ex["must_flag_text"] if isinstance(ex["must_flag_text"], list) else [ex["must_flag_text"]]
                blob = text + " " + json.dumps(res.get("statistics", {})).lower()
                miss = [w for w in want if str(w).lower() not in blob]
                if miss: rec["pass"] = False; rec["problems"].append(f"expected text not found: {miss}")
            results.append(rec)
    passed = sum(r["pass"] for r in results)
    total = len(results)
    if a.json:
        Path(a.json).write_text(json.dumps({"passed": passed, "total": total, "results": results}, indent=2))
    lines = [f"# Analytics lab score: {passed}/{total} runs passed", "", "| Case | Procedure | Flags | Recall | Decoy hits | Time (s) | Result |", "|---|---|---|---|---|---|---|"]
    for r in results:
        lines.append(f"| {r['case']} {r['slug']} | {r['procedure']} {r['label']} | {r.get('flag_count', '-')} | {r.get('recall', '-')} | {r.get('decoy_hits', '-')} | {r['seconds']} | {'PASS' if r['pass'] else 'FAIL: ' + '; '.join(r['problems'])} |")
    md = "\n".join(lines)
    if a.md:
        Path(a.md).write_text(md)
    print(md)
    sys.exit(0 if passed == total else 1)


if __name__ == "__main__":
    main()
