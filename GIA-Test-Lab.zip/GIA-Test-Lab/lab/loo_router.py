#!/usr/bin/env python3
"""loo_router.py - leave-one-out accuracy of similarity variants on labelled phrases (no blind data used)."""
import json, math, re, sys
from pathlib import Path
sys.path.insert(0, "/home/claude/gcgo-orchestrator/scripts")
import gcgo_route as g

def char_ngrams(text, ns=(3,4,5)):
    t = " " + re.sub(r"[^a-z0-9 ]", " ", text.lower()) + " "
    t = re.sub(r"\s+", " ", t)
    out = []
    for n in ns:
        out += [t[i:i+n] for i in range(len(t)-n+1)]
    return out

def build(docs, tokfn):
    df = {}
    for _, _, t in docs:
        for w in set(t): df[w] = df.get(w, 0) + 1
    n = len(docs)
    idf = lambda w: math.log((n+1)/(df.get(w,0)+1)) + 1
    return df, n, idf

def vec(t, idf):
    v = {}
    for w in t: v[w] = v.get(w, 0) + 1
    v = {w: c*idf(w) for w, c in v.items()}
    nm = math.sqrt(sum(x*x for x in v.values())) or 1
    return {w: x/nm for w, x in v.items()}

def scores(text, docs, tokfn):
    df, n, idf = build(docs, tokfn)
    q = vec(tokfn(text), idf); best = {}
    for i, ph, t in docs:
        d = vec(t, idf); s = sum(q[w]*d.get(w,0) for w in q)
        if s > best.get(i, 0): best[i] = s
    return sorted(best.items(), key=lambda x: -x[1])

def main():
    ex = json.load(open("/home/claude/gcgo-orchestrator/data/router-exemplars.json"))
    items = [(i, ph) for i, phs in ex.items() for ph in phs]
    variants = {"word-stem": g.toks, "char-ngram": char_ngrams, "both": None}
    for name, fn in variants.items():
        top1 = top3 = tot = 0
        for idx, (intent, phrase) in enumerate(items):
            docs_src = [(i, p) for j, (i, p) in enumerate(items) if j != idx]
            if name == "both":
                docs_w = [(i, p, g.toks(p)) for i, p in docs_src]; docs_c = [(i, p, char_ngrams(p)) for i, p in docs_src]
                a = dict(scores(phrase, docs_w, g.toks)); b = dict(scores(phrase, docs_c, char_ngrams))
                sc = sorted(((a.get(k,0)+b.get(k,0))/2, k) for k in set(a)|set(b))[::-1]
                ranked = [k for _, k in sc]
            else:
                docs = [(i, p, fn(p)) for i, p in docs_src]
                ranked = [k for k, _ in scores(phrase, docs, fn)]
            tot += 1; top1 += ranked[0] == intent; top3 += intent in ranked[:3]
        print(f"{name:10s} LOO top-1 {top1/tot:.0%}  top-3 {top3/tot:.0%}  (n={tot})")
main()
