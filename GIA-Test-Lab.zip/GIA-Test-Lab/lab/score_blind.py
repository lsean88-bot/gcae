#!/usr/bin/env python3
"""score_blind.py - strict / assisted accuracy, confidence calibration, policy, no-route, risk flags on a scenario file.
  python score_blind.py --gcgo /path --scenarios ../scenarios/router_blind2.json [--json out.json]"""
import argparse, importlib.util, json
from pathlib import Path
ap=argparse.ArgumentParser(); ap.add_argument("--gcgo",required=True); ap.add_argument("--scenarios",required=True); ap.add_argument("--json"); a=ap.parse_args()
spec=importlib.util.spec_from_file_location("gr",a.gcgo+"/scripts/gcgo_route.py"); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
reg=m.load_registry(a.gcgo+"/data/capability-registry.json")
res={k:0 for k in ["strict","assisted","intent_total","nr_total","nr_ok","pol_total","pol_ok","fl_total","fl_ok","high","high_wrong","medium","medium_wrong","low","low_wrong","none_with_intent_expected"]}
fails=[]
for x in json.load(open(a.scenarios)):
    e=x["expect"]; p=m.build_plan(x["request"],reg,None,None)
    got=[i["intent"] for i in p.get("intents",[])]; sug=[s["intent"] for s in p.get("suggestions",[])]
    if e.get("no_route"):
        res["nr_total"]+=1; ok=not got; res["nr_ok"]+=ok
        if not ok: fails.append((x["id"],x["request"][:70],"routed",got))
        continue
    if e.get("policy_flags"):
        res["pol_total"]+=1; ok=all(f in p.get("policy_flags",{}) for f in e["policy_flags"]); res["pol_ok"]+=ok
        if not ok: fails.append((x["id"],x["request"][:70],"policy missed",list(p.get("policy_flags",{}))))
        continue
    exp_all=e.get("intents",[]); exp_any=e.get("intents_any",[])
    sat=lambda g_: all(i in g_ for i in exp_all) and (not exp_any or any(i in g_ for i in exp_any))
    res["intent_total"]+=1; s1=sat(got); s2=sat(got+sug); res["strict"]+=s1; res["assisted"]+=s2
    conf=p.get("confidence","none")
    if conf in ("high","medium","low"): res[conf]+=1; res[conf+"_wrong"]+=(not s1)
    else: res["none_with_intent_expected"]+=1
    if e.get("flags"):
        res["fl_total"]+=1; okf=all(f in p.get("flags",{}) for f in e["flags"]); res["fl_ok"]+=okf
        if not okf: fails.append((x["id"],x["request"][:70],"flag missed",list(p.get("flags",{}))))
    if not s2: fails.append((x["id"],x["request"][:70],"intent missed even with suggestions",got,sug))
T=res["intent_total"]
print(f"STRICT intent accuracy (keyword routing only): {res['strict']}/{T} = {res['strict']/T:.0%}")
print(f"ASSISTED (chosen or in top-3 suggestions):     {res['assisted']}/{T} = {res['assisted']/T:.0%}")
print(f"no-route correct {res['nr_ok']}/{res['nr_total']}; policy requests caught {res['pol_ok']}/{res['pol_total']}; risk flags {res['fl_ok']}/{res['fl_total']}")
for lvl in ("high","medium","low"):
    n=res[lvl]; w=res[lvl+'_wrong']; print(f"routed at confidence {lvl}: {n}, strict-wrong {w}" + (f" ({w/n:.0%})" if n else ""))
print(f"intent expected but nothing routed: {res['none_with_intent_expected']}")
print("\nFAILS:"); [print(" ",f) for f in fails]
if a.json: Path(a.json).write_text(json.dumps({"summary":res,"fails":fails},indent=1,default=str))
