#!/usr/bin/env python3
"""run_declared.py - plan correctness when the caller declares the classification (Claude classifies, script plans).
For every scenario with explicit expected intents/entities/jurisdictions, declare them and check the plan:
playbooks match the intents, entity/jurisdiction specialists are loaded, risk flags and policy flags survive,
no crash. Expected: 100% (the plan step is deterministic)."""
import argparse, importlib.util, json, sys
from pathlib import Path
ap = argparse.ArgumentParser(); ap.add_argument("--gcgo", required=True); ap.add_argument("--scenarios", nargs="*"); a = ap.parse_args()
spec = importlib.util.spec_from_file_location("gr", Path(a.gcgo) / "scripts" / "gcgo_route.py"); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
reg = m.load_registry(str(Path(a.gcgo) / "data" / "capability-registry.json"))
files = a.scenarios or [str(p) for p in sorted((Path(__file__).resolve().parent.parent / "scenarios").glob("router_*.json"))]
tot = ok = 0; bad = []
for f in files:
    for sc in json.loads(Path(f).read_text()):
        e = sc["expect"]; intents = e.get("intents") or (e.get("intents_any") or [])[:1]
        if not intents: continue
        decl = {"intents": intents, "entities": e.get("entities", []), "jurisdictions": e.get("jurisdictions", []), "flags": e.get("flags", [])}
        tot += 1
        try:
            plan = m.build_plan(sc["request"], reg, None, None, decl)
        except SystemExit as ex:
            bad.append((sc["id"], str(ex)[:80])); continue
        got = [i["intent"] for i in plan["intents"]]
        pbs = {i["playbook"] for i in plan["intents"]}
        want_pbs = {reg["intents"][i]["playbook"] for i in intents}
        probs = []
        if not want_pbs <= pbs: probs.append(f"playbooks {sorted(want_pbs - pbs)} missing")
        for c in e.get("entities", []):
            if c not in [x["code"] for x in plan["entities"]]: probs.append("entity " + c)
        for fl in e.get("flags", []):
            if fl not in plan["flags"]: probs.append("flag " + fl)
        if not plan.get("plan"): probs.append("empty plan")
        for sk in e.get("skills_include", []):
            steps = [s_["skill"] for b in plan["plan"] for s_ in b["steps"]] + list(plan.get("entity_specialists", []))
            if sk not in steps: probs.append("skill " + sk)
        if probs: bad.append((sc["id"], probs))
        else: ok += 1
print(f"declared-classification plan correctness: {ok}/{tot}")
for b in bad[:15]: print("  ", b)
sys.exit(0 if ok == tot else 1)
