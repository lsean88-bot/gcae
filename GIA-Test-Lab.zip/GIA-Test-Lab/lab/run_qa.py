#!/usr/bin/env python3
"""run_qa.py - score qa_scan.py against scenarios/qa_scenarios.json (uses --format json)."""
import argparse, json, subprocess, sys, tempfile
from pathlib import Path
ap=argparse.ArgumentParser(); ap.add_argument("--qa",required=True); ap.add_argument("--scenarios",default=str(Path(__file__).resolve().parent.parent/"scenarios"/"qa_scenarios.json")); ap.add_argument("--md"); a=ap.parse_args()
ok=0; rows=[]; tmp=Path(tempfile.mkdtemp())
for sc in json.loads(Path(a.scenarios).read_text()):
    f=tmp/(sc["id"]+".md"); f.write_text(sc["text"],encoding="utf-8")
    cmd=[sys.executable,a.qa,str(f),"--format","json","--audience",sc["audience"]]
    if sc["approved"]: cmd+=["--approved",sc["approved"]]
    if sc["lenient"]: cmd.append("--lenient")
    if sc["require_declaration"]: cmd.append("--require-declaration")
    if sc["register"]:
        r=tmp/(sc["id"]+".txt"); r.write_text("\n".join(sc["register"])); cmd+=["--register",str(r)]
    p=subprocess.run(cmd,capture_output=True,text=True)
    probs=[]
    if p.returncode not in (0,1): probs.append("crash: "+p.stderr.strip()[-150:])
    else:
        try:
            cats={x["category"] for x in json.loads(p.stdout)["findings"]}
        except Exception as e:
            cats=set(); probs.append("bad json: "+str(e))
        for c in sc["has"]:
            if c not in cats: probs.append(f"expected {c}, got {sorted(cats)}")
        for c in sc["absent"]:
            if c in cats: probs.append(f"unexpected {c}")
    rows.append((sc["id"],not probs,probs,sc["text"][:60].replace("\n"," "))); ok+=not probs
lines=[f"# qa_scan scenarios: {ok}/{len(rows)} passed",""]+[f"- {i} {t!r}: "+"; ".join(p) for i,g,p,t in rows if not g]
md="\n".join(lines)
if a.md: Path(a.md).write_text(md)
print(md); sys.exit(0 if ok==len(rows) else 1)
