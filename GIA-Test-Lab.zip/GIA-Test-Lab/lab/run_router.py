#!/usr/bin/env python3
"""run_router.py - score gcgo_route.build_plan against scenarios/router_scenarios.json.
  python run_router.py --gcgo /path/to/gcgo-orchestrator [--json out.json] [--md out.md]"""
import argparse, importlib.util, json, sys
from pathlib import Path

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--gcgo", required=True); ap.add_argument("--scenarios", default=str(Path(__file__).resolve().parent.parent / "scenarios" / "router_scenarios.json"))
    ap.add_argument("--json"); ap.add_argument("--md"); a = ap.parse_args()
    spec = importlib.util.spec_from_file_location("gcgo_route", Path(a.gcgo) / "scripts" / "gcgo_route.py"); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    reg = m.load_registry(str(Path(a.gcgo) / "data" / "capability-registry.json"))
    out = []
    for sc in json.loads(Path(a.scenarios).read_text()):
        ex = sc["expect"]; plan = m.build_plan(sc["request"], reg, None, None)
        probs = []
        got_intents = [i["intent"] for i in plan.get("intents", [])]
        if ex.get("no_route") and got_intents: probs.append(f"should not route, got {got_intents}")
        for i in ex.get("intents", []):
            if i not in got_intents: probs.append(f"missing intent {i} (got {got_intents})")
        if ex.get("intents_any") and not any(i in got_intents for i in ex["intents_any"]): probs.append(f"none of {ex['intents_any']} (got {got_intents})")
        for e in ex.get("entities", []):
            if e not in [x["code"] for x in plan.get("entities", [])]: probs.append(f"missing entity {e}")
        for j in ex.get("jurisdictions", []):
            if j not in [x["jurisdiction"] for x in plan.get("jurisdictions", [])]: probs.append(f"missing jurisdiction {j}")
        for f in ex.get("flags", []):
            if f not in plan.get("flags", {}): probs.append(f"missing flag {f}")
        for f in ex.get("policy_flags", []):
            if f not in plan.get("policy_flags", {}): probs.append(f"missing policy flag {f}")
        steps = [s["skill"] for b in plan.get("plan", []) for s in b["steps"]] + list(plan.get("entity_specialists", []))
        for sk in ex.get("skills_include", []):
            if sk not in steps: probs.append(f"skill {sk} not in plan")
        if ex.get("conductor_in") and plan.get("conductor") not in ex["conductor_in"]: probs.append(f"conductor {plan.get('conductor')} not in {ex['conductor_in']}")
        warns = " ".join(plan.get("warnings", [])).lower()
        for w in ex.get("warn_contains", []):
            if w.lower() not in warns: probs.append(f"warning containing '{w}' missing")
        out.append({"id": sc["id"], "request": sc["request"], "pass": not probs, "problems": probs})
    ok = sum(o["pass"] for o in out)
    if a.json: Path(a.json).write_text(json.dumps({"passed": ok, "total": len(out), "results": out}, indent=2))
    lines = [f"# Router scenarios: {ok}/{len(out)} passed", ""]
    for o in out:
        if not o["pass"]: lines.append(f"- {o['id']} {o['request'][:80]!r}: " + "; ".join(o["problems"]))
    md = "\n".join(lines); 
    if a.md: Path(a.md).write_text(md)
    print(md); sys.exit(0 if ok == len(out) else 1)
if __name__ == "__main__": main()
