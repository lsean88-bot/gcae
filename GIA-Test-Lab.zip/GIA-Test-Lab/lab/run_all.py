#!/usr/bin/env python3
"""
run_all.py - run every deterministic suite in the GIA Test Lab and print one scorecard.

  python run_all.py --evidence /path/gia-evidence-discipline --gcgo /path/gcgo-orchestrator [--full] [--md scorecard.md]

Suites
  analytics    planted-issue recall, decoy precision, 20 synthetic cases       (must be 100%)
  router       core + natural-language regression sets                         (must be 100%)
  router-info  sets used for diagnosis (strict + assisted accuracy reported)   (informational)
  qa_scan      65 wording scenarios incl. evasion and multilingual             (must be 100%)
  injection    known-pattern sets (dev) and the fresh-attack set               (dev must be 100%; fresh is informational)
  grader       self-test and hedged/reworded validation                        (self-test must be 100%)
  stress       scale, malformed and hostile input                              (must be 100%)
The behaviour scenarios (26) are graded by pasting a model response into grade_response.py, or with an LLM judge
(grade_response.py --case ID --judge-prompt). They need a model response, so they are not run here.
"""
import argparse, re, subprocess, sys, time
from pathlib import Path

LAB = Path(__file__).resolve().parent
SC = LAB.parent / "scenarios"
py = sys.executable


def run(cmd, cwd=None, timeout=1800):
    t = time.time()
    p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
    return p, time.time() - t


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--evidence", required=True); ap.add_argument("--gcgo", required=True)
    ap.add_argument("--freshness"); ap.add_argument("--full", action="store_true"); ap.add_argument("--md"); a = ap.parse_args()
    E = Path(a.evidence); G = Path(a.gcgo); F = Path(a.freshness) if a.freshness else E.parent / "gia-statutory-freshness"; rows = []; ok_all = True

    def add(name, ok, detail, must=True):
        nonlocal ok_all
        rows.append((name, "PASS" if ok else ("FAIL" if must else "info"), detail))
        if must and not ok: ok_all = False

    cases = LAB.parent / "cases"
    if not cases.exists():
        run([py, str(LAB / "gen_cases.py"), "--out", str(cases)])
    p, dt = run([py, str(LAB / "run_lab.py"), "--cases", str(cases), "--analytics", str(E / "scripts" / "audit_analytics.py")])
    m = re.search(r"(\d+)/(\d+) runs passed", p.stdout); add("analytics", p.returncode == 0, f"{m.group(0) if m else p.stdout[:80]} ({dt:.0f}s)")

    for f in ("router_scenarios.json", "router_holdout.json"):
        p, dt = run([py, str(LAB / "run_router.py"), "--gcgo", str(G), "--scenarios", str(SC / f)])
        m = re.search(r"(\d+)/(\d+) passed", p.stdout); add(f"router {f}", p.returncode == 0, m.group(0) if m else p.stdout[:80])
    for f in ("router_blind.json", "router_blind2.json"):
        p, dt = run([py, str(LAB / "score_blind.py"), "--gcgo", str(G), "--scenarios", str(SC / f)])
        s = re.search(r"STRICT[^\n]*= (\d+%)", p.stdout); b = re.search(r"ASSISTED[^\n]*= (\d+%)", p.stdout)
        add(f"router-info {f}", True, f"strict {s.group(1) if s else '?'}, assisted {b.group(1) if b else '?'}", must=False)

    p, dt = run([py, str(LAB / "run_declared.py"), "--gcgo", str(G)])
    m = re.search(r"(\d+)/(\d+)", p.stdout); add("router: plan correct when classification is declared", p.returncode == 0, m.group(0) if m else p.stdout[:80])
    p, dt = run([py, str(LAB / "extract_tests.py"), str(E / "scripts" / "validate_extract.py")])
    add("extract validator (quarantined reader)", p.returncode == 0, p.stdout.strip().splitlines()[0] if p.stdout.strip() else p.stderr[-80:])
    import os
    env = dict(os.environ, GIA_EVIDENCE=str(E), GIA_GCGO=str(G), GIA_FRESH=str(F))
    try:
        pt = subprocess.run([py, "-m", "pytest", str(LAB / "tests"), "-q", "-p", "no:cacheprovider"], capture_output=True, text=True, env=env, timeout=900)
        last = pt.stdout.strip().splitlines()[-1] if pt.stdout.strip() else pt.stderr[-80:]
        add("unit tests (pytest)", pt.returncode == 0, last)
    except Exception as e:
        add("unit tests (pytest)", False, str(e)[:80])
    scripts_dirs = [str(E / "scripts"), str(G / "scripts"), str(F / "scripts")]
    pr = subprocess.run([py, "-m", "ruff", "check", "--select", "E9,F,B", "--ignore", "B007,B905,B008", "--output-format", "concise", *scripts_dirs], capture_output=True, text=True)
    if "No module named ruff" in pr.stderr:
        add("lint (ruff)", True, "ruff not installed: skipped", must=False)
    else:
        add("lint (ruff E9,F,B)", pr.returncode == 0, "clean" if pr.returncode == 0 else pr.stdout.strip().splitlines()[0][:100])
    pb = subprocess.run([py, "-m", "bandit", "-q", "-r", *scripts_dirs, "-ll"], capture_output=True, text=True)
    if "No module named bandit" in pb.stderr:
        add("security scan (bandit medium+)", True, "bandit not installed: skipped", must=False)
    else:
        add("security scan (bandit medium+)", pb.returncode == 0, "no medium or high findings" if pb.returncode == 0 else "findings present")
    import ast, glob
    bad39 = []
    for f in sum([glob.glob(d + "/*.py") for d in scripts_dirs], []):
        try: ast.parse(open(f, encoding="utf-8").read(), feature_version=(3, 9))
        except SyntaxError as e: bad39.append(f"{Path(f).name}:{e.lineno}")
    add("Python 3.9 syntax compatibility", not bad39, "all scripts parse" if not bad39 else ", ".join(bad39))
    p, dt = run([py, str(LAB / "run_qa.py"), "--qa", str(E / "scripts" / "qa_scan.py")])
    m = re.search(r"(\d+)/(\d+) passed", p.stdout); add("qa_scan", p.returncode == 0, m.group(0) if m else p.stdout[:80])

    for f, must in (("adversarial_injection.py", True), ("adversarial_injection_blind.py", True), ("adversarial_injection_blind2.py", False)):
        p, dt = run([py, str(LAB / f), str(E / "scripts" / "evidence_injection_scan.py")])
        line = p.stdout.strip().splitlines()[0] if p.stdout.strip() else p.stderr[-80:]
        ok = ("45/45" in line or "30/30" in line) if must else True
        add(f"injection {f}", ok, line[:110], must=must)

    p, dt = run([py, str(LAB / "grade_response.py"), "--self-test"]); add("grader self-test", p.returncode == 0, p.stdout.strip().splitlines()[0])
    p, dt = run([py, str(LAB / "validate_grader.py")], cwd=str(LAB)); add("grader validation (hedged / reworded)", True, p.stdout.strip().splitlines()[0][:130], must=False)

    cmd = [py, str(LAB / "stress.py"), "--evidence", str(E), "--gcgo", str(G), "--work", "/tmp/gia_stress"]
    if not a.full: cmd.append("--quick")
    p, dt = run(cmd, timeout=3000); m = re.search(r"(\d+)/(\d+) passed\s*$", p.stdout.strip()); add("stress" + (" (full)" if a.full else " (quick)"), p.returncode == 0, (m.group(0) if m else p.stdout[-80:]) + f" ({dt:.0f}s)")

    w = max(len(r[0]) for r in rows)
    out = ["# GIA Test Lab scorecard", ""] + [f"{r[1]:5s} {r[0]:<{w}s}  {r[2]}" for r in rows] + ["", "Overall: " + ("ALL REQUIRED SUITES PASS" if ok_all else "FAILURES PRESENT")]
    print("\n".join(out))
    if a.md: Path(a.md).write_text("\n".join(out))
    sys.exit(0 if ok_all else 1)


if __name__ == "__main__":
    main()
