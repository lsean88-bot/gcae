# GOVERNANCE / LEGAL REFERENCE INDEX (VERIFY BEFORE CITING)

Layer map:
- Control environment & delegation of authority → Board / DoA matrix
- Risk assessment → COSO ERM components; risk register + KRIs
- Control activities → ERP permissions, ECN gate, 4-way match, JE approval
- Information & communication → exception dashboard, escalation SLA
- Monitoring → First Line self-check, Second Line oversight, Third Line audit
- Assurance model → IIA Three Lines Model
- Reporting → IIA 5C finding format; Audit Committee escalation protocol

Jurisdiction-dependent items to confirm with counsel:
- Related-party identification, disclosure, approval and register duties
- Revenue/gross-vs-net presentation and inventory valuation standards
- Indirect tax treatment of supplies, job-work/tolling and input credit
- Scrap disposal authorization, weighment and tax invoicing
- Company law duties, record retention, whistle-blower and employment process
- Anti-bribery third-party diligence, gifts/hospitality, conflicts
- Evidence admissibility, data privacy and cross-border transfer

RULE: Output the question to counsel, not a legal conclusion, until
jurisdiction, entity type, period and materiality are confirmed.
