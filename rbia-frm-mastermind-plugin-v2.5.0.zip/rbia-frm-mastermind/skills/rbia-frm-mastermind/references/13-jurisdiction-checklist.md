# 13. Jurisdiction checklist: India, Malaysia, Mexico (questions only, NOT legal content)
This file deliberately contains no statutes, limits or conclusions. Law changes and varies by facts; counsel in each jurisdiction supplies the answers, and each one is recorded in the engagement file with the source and date. Until answered, the plugin marks the item VERIFY JURISDICTION and does not rely on it.

For each entity and each engagement, ask counsel:
1. Mandatory reporting: is there a duty to report this type of fraud to a regulator, police or the statutory auditor, and by when? Does the statutory auditor have its own reporting trigger?
2. Tipping-off / anti-money-laundering: may the subject or counterparty be told? Which steps (payment stops, recall requests, repayment negotiations) could breach it?
3. Whistleblower protection: who is protected, what confidentiality and non-retaliation duties apply, and what must the hotline record?
4. Employment: limits on suspension, pay deduction or set-off, disciplinary process and notice, representation rights, interview rules.
5. Privilege: does legal privilege cover in-house counsel, external counsel and forensic advisers instructed through counsel? How should work be marked and routed?
6. Data protection: lawful basis, notice, proportionality and cross-border transfer rules for reviewing mailboxes, devices, bank data and moving data between group entities.
7. Evidence: admissibility and format rules for electronic records, logs, screenshots and copies; originals versus copies.
8. Limitation periods and any postponement for fraud; deadlines for insurance claims and bank recalls.
9. Recovery: freezing or attachment orders, civil versus criminal route, and the effect of settlement on a criminal referral.
10. Governance: who must approve (Board, Audit Committee, regulators) and whether listing rules require disclosure.
Record: question, jurisdiction, counsel name/firm, date, source cited, validity period, status (ANSWERED / OPEN).
