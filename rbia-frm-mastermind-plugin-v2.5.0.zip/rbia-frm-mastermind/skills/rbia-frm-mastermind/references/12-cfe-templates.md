# 12. CFE method templates (drafts for a qualified human)
All templates are DRAFTS. Nothing here is an accusation, a legal conclusion or an authenticated fact. Fill with evidence references only.

## 12.1 Fraud-theory / ACH matrix
Cycle: hypothesise -> test cheapest evidence -> refine -> amend or drop. Re-rank after every new evidence item; stop when a hypothesis is refuted or when counsel/CFE of record takes over.
| Evidence ref | Description | H1 (scheme A) | H2 (scheme B) | H-benign (process/error) |
|---|---|---|---|---|
| E1 | ... | C / I / N | C / I / N | C / I / N |
C = consistent, I = inconsistent, N = neutral. Weight inconsistencies more than consistencies. A hypothesis with the fewest inconsistencies is leading, not proven. Always keep H-benign as a column.

## 12.2 Intake and case log
Case ID | date received | channel (hotline, audit, management, regulator) | allegation summary (neutral wording) | source reliability (unrated / corroborated) | predication recorded (Y/N, basis) | conflict check on investigators (Y/N) | confidentiality class | counsel informed (Y/N) | Audit Committee chair informed if management implicated (Y/N) | status | closure criteria and approver.
Closure needs: hypothesis refuted or referred, evidence preserved, findings reviewed by a second person, decision recorded by a human.

## 12.3 Preservation checklist (act first, ask later; counsel decides scope)
| Source | Typical retention risk | Owner to freeze | Frozen on (date/time) | Hash / method |
|---|---|---|---|---|
| CCTV | Overwrite cycle (days) | Security | | |
| Mailbox / chat apps | Auto-delete, device wipe | IT | | |
| ERP / audit trail logs | Log rotation, admin edit | IT / Basis | | |
| Bank portal exports | Statement availability | Treasury | | |
| Paper originals | Loss, alteration | Records | | |
| Personal devices | Out of scope unless counsel authorises | Counsel | | |
Record chain of custody for each item. Image devices only through a qualified provider (write-block, hash, time-zone and clock-sync noted). Review of employee mailboxes/devices requires a lawful basis (VERIFY JURISDICTION).

## 12.4 Interview plan (for counsel and a qualified interviewer)
Witness order: records and third parties first, process owners, then corroborating witnesses, subject last. For each interview: purpose, documents to show, open questions, topics not to raise, corporate-counsel and representative-rights points (counsel decides wording), non-retaliation assurance for witnesses, note-taker, recording consent. The plugin never conducts or simulates an interview or assesses credibility.

## 12.5 Discovery sampling (fraud attribute)
n = ln(1 - confidence) / ln(1 - tolerable rate), zero expected errors. 95% / 5% = 59 items; 95% / 2% = 149; 90% / 5% = 45. Any error found means the population is not cleared: extend or go to 100% for that attribute. State population, frame and selection method.

## 12.6 Loss quantification
Use templates/loss-quantification-workbook.xlsx. Keep direct loss, recoverable amount, exposure and investigation cost separate; de-duplicate with the Overlap sheet; label ESTIMATE with Low/Base/High until reconciled.

## 12.7 Engaging a specialist (forensic accountant, document examiner, digital forensics)
Scope letter must state: questions to answer, items provided, chain of custody, independence and conflict declaration, privilege route (via counsel where appropriate), deliverable format, reperformance by a second analyst, timeline and fee basis.

## 12.8 Behavioural red-flag context (indicators only)
Fraud triangle (pressure, opportunity, rationalisation) and fraud diamond (capability). Commonly cited indicators: unusual closeness to a vendor, refusal of leave or rotation, control over records, resistance to audit requests, unexplained change in lifestyle. These are context for prioritising inquiry, never evidence of guilt, and must not be used to profile individuals.
