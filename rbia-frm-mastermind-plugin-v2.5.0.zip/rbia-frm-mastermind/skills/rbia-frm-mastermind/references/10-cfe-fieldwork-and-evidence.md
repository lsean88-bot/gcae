# CFE FIELDWORK AND EVIDENCE GUIDE

What a professional fraud examiner does, which parts this plugin can draft or compute, and which parts only a qualified human (CFE, counsel, forensic specialist, law enforcement) may perform. Legal rules vary by jurisdiction: everything marked `VERIFY JURISDICTION` needs counsel before use. This guide is professional practice guidance, not legal advice.

## 1. Lifecycle and gates
1. Intake and triage (hotline, whistleblower, analytics hit, management referral): record source, date, what was alleged, who knows. Protect the reporter. Keep a need-to-know list.
2. Predication: a documented, proportionate basis to examine (an allegation or red flags that, if true, indicate a scheme). Without predication, do assurance work or fact-finding RFIs, not an investigation. Record the predication before fieldwork.
3. Mandate and privilege: who commissions the work, whether counsel directs it, who receives the report. Decide before collecting evidence, because privilege is hard to add later.
4. Preservation (first, fast, quiet): legal hold, preserve ERP/audit logs, email and chat, CCTV, access logs, original paper, devices. Restrict access to the subject. Do not alert the subject. Preservation is a red-line action when it stops a payment or suspends access.
5. Plan: hypotheses (from 09 MO library), evidence sources, sequence, resources, timeline, budget, interview order, communication rules.
6. Evidence collection and analysis (see 11 analytics playbook).
7. Interviews (section 4).
8. Loss quantification and recovery options (section 6).
9. Reporting (section 7), then remediation, lessons learned, closure.

## 2. Evidence standards
- Hierarchy (strongest first): third-party originals (bank, customer, registry) > system-generated logs with integrity controls > originals held by the subject > copies and exports > assertions and recollection.
- Every item gets: ID, description, source, who collected, when, how (method), hash for files, storage location, custody log (each hand-over: who, when, why).
- Work on copies. Keep originals sealed. Re-perform every analysis from the original export, and keep the script, parameters and file hashes (the toolkit prints them).
- Distinguish: fact (observed in evidence), inference (reasoned from facts), hypothesis (untested), opinion. A report never presents an inference as a fact.
- Corroborate: no finding rests on a single source type. Class D needs three independent types.

## 3. Document and data examination
- Compare original to copy; check metadata (created/modified, author, software), fonts and templates, numbering, signatures, stamps. A genuine-looking scan is not authentication.
- Questioned documents (handwriting, signatures, alterations, ink/paper age): send to a qualified document examiner. The plugin must not give an authentication opinion.
- Digital evidence (laptops, phones, mailboxes, cloud): forensic imaging and analysis by a qualified examiner under counsel direction. The plugin must not instruct anyone to access a person's device or personal accounts.
- Bank and asset tracing: statements of the entity are fair game. Third-party bank records, subject's personal accounts, or net-worth/lifestyle analysis need legal process and counsel (`VERIFY JURISDICTION`, including data-protection law).
- Open-source research (registries, court records, adverse media): lawful, proportionate, relevant, documented, no pretexting or deception.

## 4. Interviews (human only; the plugin drafts the plan)
- Order: custodians and process owners first, witnesses next, the subject last. Move from open, informational questions to corroborating ones; admission-seeking only when evidence is strong and counsel agrees.
- Two interviewers where possible, one asks and one records. Private room, no promises of leniency, no threats, no deception about rights. Offer breaks. Respect local employment law, representation or union rights, and recording/consent rules (`VERIFY JURISDICTION`). Counsel decides on rights-warning wording.
- Prepare: purpose, topics, documents to show (in a planned order), questions that cannot be answered by a document, what would change the plan. Do not reveal evidence early.
- Record: a contemporaneous note, then a summary read back and signed where lawful. Note demeanour only as observation, never as proof of deception.
- Plugin output allowed: interview plan, question lists, document packs. Not allowed: conducting the interview, assessing credibility or deception from text, or drafting a confession.

## 5. Employee-related actions (red line)
Suspension, access removal, termination, disciplinary action, police report and regulatory disclosure are decisions for management, HR and counsel. The plugin prepares the gate (Context / Recommendation / Cost-benefit / Risk of inaction / APPROVE-MODIFY-ABORT-ESCALATE) and never acts. Apply presumption of innocence in language and process.

## 6. Loss quantification and recovery
- Define the measure before the number: direct loss, recoverable amount, exposure (potential), cost of investigation, consequential loss. Report each separately and never sum overlapping findings (one transaction can appear in several tests).
- Method: population, period, inputs, formula, assumptions, range, confidence, exclusions (recovered, disputed, one-off). Label ESTIMATE until reconciled to source. Do not project forward from an unreconciled quantity.
- CAUTION on recovery: set-off or deduction against an employee's pay can be an unlawful wage deduction, a negotiated settlement can waive claims, compromise a criminal referral or breach reporting duties, and AML/tipping-off rules may bar telling the subject or counterparty. All VERIFY JURISDICTION with counsel before any step. Also consider interim freezing/attachment, limitation periods (and fraud postponement), insurer notice conditions and recovery from third-party enablers.
- Recovery routes (counsel and management decide): negotiated repayment, set-off against payables, insurance claim (check notice deadlines early), civil recovery, restitution through criminal process, bank recall for recent payments (act fast). Preserve the claim by acting quickly on dated rights.

## 7. Reporting
- Structure: scope, mandate, methodology, evidence reviewed (index), facts, analysis, findings with the evidence behind each, limitations, loss quantification status, control root causes and fixes, appendices. Keep facts separate from opinions.
- No legal conclusions ("guilty", "stole", "illegal") unless counsel adopts them. Use "the evidence indicates", "is inconsistent with", "has not been explained".
- Reports to be relied on in litigation need counsel review and, where relevant, an expert witness. The plugin does not give expert testimony.

## 8. Controls root cause and remediation
Always close with the enabling weakness (permissions, approval design, master-data governance, monitoring) and a measured fix with owner, date and KRI. The fix, not the case, is the lasting value. Track the action to closure (zeta-remediator in the grc fleet, if installed).

## 9. What requires a human CFE, counsel or specialist
Forensic imaging; document authentication; interviews and rights warnings; legal process for third-party records; surveillance and covert methods; asset tracing beyond the entity's own records; suspension or termination; law-enforcement and regulator contact; expert testimony; any statement of guilt. The plugin may prepare plans, drafts and analyses for these, and must say clearly that a person must perform them.

## 10. Competence limits to state in every fraud-related output
The plugin works on supplied data and documents, cannot verify authenticity, cannot know what was not provided, can mis-parse extracts, and its checks are leads. A qualified CFE should review before any Class D hypothesis, recovery action or Board paper.


## 7. Added after independent CFE review (v2.3.0)
- "Class D needs three independent evidence types" is this plugin's house rule (see references/01-context-triage.md), not an ACFE or legal standard. Independent means different source and different custodian (e.g. bank record + ERP log + third-party confirmation is three; ERP screen + ERP export is one).
- The evidence hierarchy is a weighting heuristic. Weight and admissibility depend on jurisdiction and authenticity; system logs can be altered by administrators.
- Management implicated: route to the Audit Committee chair, wall the implicated executive off from the case file, and check investigator independence before starting.
- Employee mailbox/device review needs a lawful basis (policy notice, proportionality, data-protection law: VERIFY JURISDICTION). Statutory-auditor fraud-reporting duties may override "management decides".
- Interview plans must leave to counsel: corporate-counsel (Upjohn-type) warnings, representative rights, non-retaliation assurance for witnesses; a non-lawyer's notes may not be privileged.
- Discovery sampling for fraud attributes: n = ln(1 - confidence) / ln(1 - tolerable rate), e.g. 59 items for 95% confidence and 5% tolerable rate, zero expected errors.
- Benford thresholds (n >= 300, >= 2 orders of magnitude) are minimum rules of thumb; prefer n >= 1,000 and 3+ orders. Chi-square is over-powered at large n, so rely on MAD and digit-level z-tests; first-two-digit, second-digit and last-two-digit tests are NOT yet implemented.
- Tools column in references/09 names the closest toolkit subcommand; where the capability is partial it must be read as 'partial' and the scheme marked UNTESTED unless the test was actually run.
