# 14. Use-case playbooks (command recipes)
Run Phase 0 Step 0 first. Every command below also takes `--out FILE --log engagement-runlog.jsonl`. Confirm every item in `defaults_used_CONFIRM_WITH_USER` with the user. Results are LEADS. Show each transaction once (overlap discipline). Column names are examples.

## 1. Payroll and workforce (ghost, post-resignation, OT, shared accounts)
Data: HR master (id, join, resign, bank), payroll by month, attendance by month. Tie each file to a control total first (`profile`).
| Question | Command | Reading |
|---|---|---|
| Paid but not on HR master | `overlap --a-file payroll --a-col Emp_ID --b-file hr --b-col Emp_ID --unmatched` | Joiners not yet loaded are benign |
| Paid with no attendance | `unsupported --a-file payroll --b-file attendance --keys Month,Emp_ID --a-val Basic --b-val Days_Present --entity Emp_ID --amount Basic` | Leave, remote work, extract gaps |
| Paid after resignation | `datecheck --mode b-after-a --a-file hr --a-key Emp_ID --a-date Resign --b-file payroll --b-key Emp_ID --b-date PayDate --b-amount Basic` | Final settlement, notice pay, leave encashment |
| OT claimed vs clocked | `recon --direction a-gt-b --keys Month,Emp_ID --a-val OT_Hours --b-val OT_Hours_Clocked --tol-pct <user>` and `unsupported --a-val OT_Pay --b-val OT_Hours_Clocked` | Approved OT without clock, system rounding |
| Repeat OT outliers | `outlier --amount OT_Hours --group Month --entity Emp_ID` | Genuine peak production |
| Attendance after resignation (leaver still working: wrong record or paid presence) | `datecheck --mode b-after-a --a-file hr --a-key Emp_ID --a-date Resign --b-file attendance --b-key Emp_ID --b-date <date col>` (needs daily attendance dates) | Withdrawn resignation, rehire |
| Paid before join date | `datecheck --mode b-before-a --a-file hr --a-date Join --b-file payroll --b-date PayDate` | Back-dated onboarding |
| HR employees not paid (stopped, leave, missed) | `overlap --unmatched --a-file hr --a-col Emp_ID --b-file payroll --b-col Emp_ID` (reverse direction) | Unpaid leave, leavers |
| Shared bank account | `shared --file hr --key Bank --id Emp_ID` | Family, joint accounts |
To show already-flagged people once in a later test use `--exclude Emp_ID=E999|E011`. Use `--quiet --out` to avoid long console output. Keep the run log in the engagement folder as `runlog.jsonl`; it is the evidence appendix to the Decision Log.
Payroll RFI starter: termination records and final settlement for leavers; onboarding file and contract type for IDs missing from HR; OT approval forms and approvers; bank account holder verification and bank payment file; Sept-onward payroll to see whether flagged payments continue.
Not automated: OT rate consistency, proration of final-month pay, statutory deduction anomalies, headcount reconciliation to the general ledger, shift capacity limits.

## 2. Procure-to-pay
`match3` (PO, GRN, invoice) -> `duplicates` (invoice+amount+party) -> `datecheck` (vendor paid before creation; payment before invoice date) -> `sod` (vendor create / bank change / release) -> `overlap --unmatched` (payment accounts vs vendor master) -> `shared` (vendors sharing bank/address/phone with employees via `overlap`) -> `dormant` -> `concentration` -> `splits` (per approval level) -> `ratevar` with dated contract rows.

## 3. Production, scrap and inventory
`recon --direction a-gt-b` (posted scrap vs weighbridge), `ratevar`, `outlier` by part, `blanks` (missing weighbridge/GRN refs). Convert units before reconciling; never project forward from an unreconciled quantity.

## 4. Journal entries and period-end
`je --period-end-days <user> --credit CreditCol --min-flags 1`, `calendar`, `round`, `benford` (only if preconditions pass; first-two digits needs n >= 1,000).

## 5. After the tests
For each lead: predication, MO mapping (reference 09, UNTESTED until evidence), benign explanations, next cheapest evidence, human-only actions (reference 10). Quantify with templates/loss-quantification-workbook.xlsx. Record every run with `--log`.
