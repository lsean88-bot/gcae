# MANUFACTURING / PROCUREMENT TEST LIBRARY

T01 BOM governance: join BOM version → ECN → approver → effective date →
    change log. Test: was Alternate activated by an authorized user?
T02 Route convergence: same parent item with Alternate + Manual issue +
    scrap credit. Output count and parent list; require T01 + T04 before C/D.
T03 Scrap integrity: theoretical backflush vs physical weighbridge vs
    disposal invoice vs buyer receipt vs bank credit. Reconcile by lot/line.
T04 Yield validation: observed weight/quantity per sheet vs BOM assumption
    (e.g. "one sheet = N parts"). Recompute standard; quantify variance only
    after confirming actual production volumes.
T05 UOM/dimension integrity: KGS vs NOS vs thickness/blank mapping;
    recompute theoretical weight from approved drawing, not from remarks.
T06 Four-way match: PO → GRN → Invoice Verification → Payment; plus
    gate log + weighbridge + E-way bill for physical existence.
T07 Related-party: registry beneficial ownership + director/KMP declaration
    + shared address/bank/phone + shared utilities + common breaker/facility.
    Name similarity alone is INSUFFICIENT.
T08 Arm's-length pricing: contract price list + should-cost/conversion-cost
    build-up + comparable third-party quotes + tolling agreement + material
    ownership + yields + processing fee. Requires price data, not BOM data.
T09 Buy/sell-back substance: does goods title/risk transfer? Is it a
    conversion arrangement? Gross vs net presentation; revenue substance.
T10 JE substance: preparer/approver independence, narration specificity,
    support, period, offsetting accounts, repeat "cleanup" entries.
T11 Master-data change fraud: bank/vendor-beneficiary changes near payment,
    segregation of vendor maintenance and payment run.
T12 Segregation & override: requester = approver; planner = BOM maintainer;
    storekeeper = scrap disposer; production = scrap recorder.
