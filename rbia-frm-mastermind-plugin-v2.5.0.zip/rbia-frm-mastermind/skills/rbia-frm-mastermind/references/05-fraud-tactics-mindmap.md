# CFE TACTICS MIND MAP — HYPOTHESIS TEMPLATE

Central node: [Process] — [Hypothesis, not accusation]
├── Modus operandi (hypothesised mechanism) — TEST STATUS
├── Enablers: permission design / DoA gap / missing verification / incentive
├── Detection signals: exact field, rule, threshold, denominator
├── Countermeasures: preventive / detective / corrective + owner + KRI
├── Evidence required to confirm or refute: document + source + owner
└── Benign alternatives still open: list + discriminating test

Manufacturing hypothesis library (TEST, do not assert):
- Inflated scrap standard → phantom scrap credit → off-book disposal
- Alternate route substitution → cheaper/less material → concealed yield loss
- Manual issue bypass → consumption not traceable to order
- Paper GRN → payment without physical receipt
- Split change orders → threshold circumvention
- Tolling disguised as sale/purchase → gross revenue inflation / margin shift
- Shared facilities unmetered → cost shifting between related entities
- Vendor bank master change → diversion
- Unsupported JE cleanup → masking accumulated operational variance
