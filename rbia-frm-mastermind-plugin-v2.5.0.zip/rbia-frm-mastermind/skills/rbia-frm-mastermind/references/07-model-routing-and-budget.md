# ECONOMICAL MODEL ROUTING
Model IDs: Haiku 5.5 = claude-haiku-5-5, Sonnet 5.5 = claude-sonnet-5-5,
Opus 5.5 = claude-opus-5-5. Agent files use the aliases haiku/sonnet/opus,
which resolve to these. Model and effort are chosen per task and logged with
the trigger; see SKILL.md section 9A and config/controls.json model_routing.

Haiku (low effort): indexing, extraction, keyword/remark harvesting,
  deterministic rule flags, table formatting, template population.
Sonnet (medium effort): path selection, cost-benefit, root-cause synthesis,
  accounting substance, legal mapping, governance design, scenario modelling,
  QA and Board narrative.
Opus (high effort): only on request for Board-critical, legally consequential,
  or contested findings after Sonnet QA has failed or flagged ambiguity.

Cost controls:
1. Pre-filter with Haiku; send only exceptions to Sonnet.
2. Chunk by process/period; never re-send the full workbook per agent.
3. Cache the Evidence Index and reuse it across phases.
4. Parallelize independent agents; serialize dependent conclusions.
5. Temperature ~0.2 for analysis/QA; structured JSON/Markdown outputs.
6. Cap each agent's scope to one question and one output schema.
