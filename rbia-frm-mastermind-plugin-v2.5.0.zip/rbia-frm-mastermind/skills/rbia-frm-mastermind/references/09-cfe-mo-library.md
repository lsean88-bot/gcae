# CFE MODUS OPERANDI LIBRARY (HYPOTHESES TO TEST, NEVER FINDINGS)

Organised by the three families of the ACFE occupational fraud classification (asset misappropriation,
corruption, financial statement fraud) plus cyber-enabled and manufacturing-specific schemes.
Every row is `UNTESTED` until evidence says otherwise. A scheme is a hypothesis about a mechanism, not
an accusation. For each one, ask: who could do this (opportunity), what would it leave behind (footprint),
what else could explain the same footprint (benign alternative), and what document or third party settles it.
Tool column = `scripts/fraud_analytics.py` subcommand. Verify classification wording against the current ACFE edition. COVERAGE NOTE: this library is a subset of the ACFE fraud tree (omits register disbursements, false refunds/voids, cash on hand, false sales/shipping, asset requisitions, purchasing/receiving branches, customer-side and healthcare billing); a Tool entry means the nearest subcommand and is often PARTIAL (e.g. near-text duplicates, forged-document detection and third-party quotes are NOT automated). Items marked management override, prompt injection and AI-generated documents are emerging (non-ACFE) categories. Since v2.4.0 the toolkit also has match3, datecheck, dormant, shared, outlier, concentration and Benford first-two digits. A scheme is TESTED only if the test was actually run.

## How to read a row
Footprint = what the scheme leaves in data/documents. Settle with = the evidence that confirms or refutes it.
Benign = innocent explanations that must be ruled out first (see 01-context-triage.md).

## A. Asset misappropriation, cash and disbursements
| Scheme | Mechanism | Footprint / red flags | Tool | Settle with | Benign alternatives |
|---|---|---|---|---|---|
| Shell-company billing | Fictitious vendor invoices paid to an insider-controlled entity | Vendor with PO box/no tax ID, address/bank/phone matching an employee, invoices just under approval limit, no GRN, round or sequential invoice numbers, vendor created and paid by same user | overlap, sod, sequence, round, blanks | Registry and beneficial-owner search, site visit, delivery proof, bank account holder | New small vendor, outsourced accountant address |
| Pass-through | Insider buys from a real supplier via own intermediary at a mark-up | Rate above third-party quotes for same spec, single-source, intermediary with no operations | ratevar, third-party quotes | Comparable quotes, supplier confirmation, ownership search | Genuine value-add (logistics, credit terms) |
| Duplicate / re-submitted invoice | Same invoice paid twice or with altered number | Same amount and vendor within days, number variants, two bank accounts | duplicates | Payment run, bank statement, recovery | ERP migration artefact, credit note netting |
| Invoice splitting | Orders split below approval threshold | Cluster of just-below-limit items to one vendor in days | splits | PO history, approver matrix | Genuine staged deliveries |
| Vendor bank-detail change (diversion) | Beneficiary account altered before a large payment (insider or business-email-compromise) | Change by clerk with no approver or callback, large payment within days, payment to account not on master | sod, overlap --unmatched, calendar | Callback on known number, signed change request, bank beneficiary check, email header review | Genuine vendor bank change |
| Payroll: ghost employee | Payments to non-existent or departed staff | No leave/attendance, shared bank account, address match, resigned but still paid | overlap --unmatched, unsupported, datecheck --mode b-after-a, shared | HR file, attendance, bank account holder, physical verification | Late termination processing |
| Payroll: falsified hours / OT | Inflated overtime or commissions | OT above plausible capacity, pattern by approver | recon --direction a-gt-b, unsupported, outlier --entity | Time clock, production output, supervisor attestation | Genuine peak demand |
| Expense reimbursement | Fictitious, mischaracterised, duplicated, inflated claims | Round amounts, missing receipts, repeats across periods, weekend vendors | duplicates, round, calendar | Original receipts, merchant confirmation | Per-diem policy |
| Payment/cheque tampering, forged approval | Altered payee/amount; forged or shared credentials | Payee changed after approval, approver logged in elsewhere | sod, calendar | Bank image, audit log, access logs | Reissued payment |
| Skimming / larceny (cash receipts) | Receipts not recorded or diverted; lapping | Delayed deposits, short deposits, customer complaints, write-offs of old receivables | recon (receipts vs bank), sequence | Bank deposit vs cash book, customer confirmations | Timing, unapplied cash |

## B. Asset misappropriation, non-cash (manufacturing focus)
| Scheme | Mechanism | Footprint / red flags | Tool | Settle with | Benign alternatives |
|---|---|---|---|---|---|
| Inflated scrap standard / phantom scrap credit | Standard allows scrap above real yield; credit posted but material leaves off-book | Posted scrap > weighbridge, no disposal invoice/bank credit, manual issue + alternate route, change without ECN | recon, sod, blanks | Weighbridge tickets, buyer invoices, bank receipts, physical yield test | Trial runs, UOM conversion, timing |
| Alternate-route substitution | Cheaper/less material used, concealed yield loss | Alternate BOM without ECN, yield claims in remarks | recon | ECN, yield test, production orders | Approved tooling change |
| Inventory theft, false write-off | Stock removed and written off as variance | Cleanup journals, self-approved, narrations like "adjust variance", count-sheet edits | je, recon | Count sheets, CCTV/gate logs, approvals | Genuine shrinkage, count error |
| False receiving / short shipment | Paper GRN without physical receipt | GRN without gate log or weighbridge ticket, round quantities | blanks, recon | Gate log, e-way bill, carrier proof | System downtime backfill |
| Misuse of company assets / tooling | Jobs run for personal gain | Unplanned production, tooling use off-plan | calendar | Production logs, interviews | Authorised sample work |

## C. Corruption
| Scheme | Mechanism | Footprint / red flags | Tool | Settle with | Benign alternatives |
|---|---|---|---|---|---|
| Conflict of interest (purchasing) | Insider has undisclosed interest in a supplier | Undeclared interest, favourable terms, single-source, lifestyle shift | overlap, ratevar | Declarations, registry, bank, related-party register | Coincidental surname/address |
| Kickback | Supplier overprices and shares proceeds | Rate above market, change orders after award, vendor insists on one contact | ratevar, splits | Competitive quotes, bank tracing (needs legal process), informant | Genuine premium for quality/urgency |
| Bid rigging / collusion | Specs tailored, bids coordinated | Identical bid errors, rotating winners, late bidders | duplicates (near-text), recon | Tender file, metadata, bidder ownership | Small market |
| Illegal gratuities / hospitality | Gifts after the fact | Gift register gaps, spend at vendor events | overlap | Gift/hospitality register, expense claims | Policy-compliant hospitality |
| Economic extortion | Demand for payment to award/release | Whistleblower report, unusual fees | n/a (human intelligence) | Hotline report, interviews | Genuine fee |

## D. Financial statement and reporting fraud
| Scheme | Mechanism | Footprint / red flags | Tool | Settle with | Benign alternatives |
|---|---|---|---|---|---|
| Fictitious or premature revenue | Booking sales not earned (bill-and-hold, channel stuffing, side letters) | Spike at period end, returns after year end, customer confirmations differ | calendar, je | Contracts, delivery proof, confirmations | Seasonality |
| Cut-off manipulation | Expenses deferred/ income accelerated | Entries dated just before/after period end, reversals | je, calendar | Source documents, subsequent payments | Genuine accrual |
| Concealed liabilities / expenses | Unrecorded payables, capitalising revenue items | Cleanup journals, large reclasses, no support | je | Vendor statements, subsequent disbursements | Reclass correction |
| Improper valuation (inventory, receivables, reserves) | Over-valued stock, under-provision, cookie-jar reserves | Variances written off in bulk, ageing not provisioned | recon, je | Counts, NRV tests, ageing | Estimation difference (policy, not fraud) |
| Related-party concealment / round-tripping | Transactions with undisclosed related parties; funds circulated | Pricing off market, circular payments, undeclared interests | overlap, ratevar | Registry, bank flows, board minutes | Genuine arm's-length |
| Management override | Top-side entries bypass controls | Entries by senior users, round, unsupported, after hours | je, calendar | JE listing with authority, interviews | Genuine top-side adjustment with approval |

## E. Cyber-enabled and emerging
| Scheme | Mechanism | Footprint / red flags | Tool | Settle with | Benign alternatives |
|---|---|---|---|---|---|
| Business email compromise / invoice fraud | Spoofed email requests bank change or urgent payment | Look-alike domain, urgency, new bank, bypass of callback | overlap --unmatched, sod | Header analysis, callback, IT logs | Real vendor change |
| Synthetic or AI-generated documents | Fabricated invoices, receipts, certificates, voice or video approval | Template uniformity, metadata mismatch, no third-party confirmation, approval only via call/video | profile, duplicates | Document examiner, third-party confirmation, metadata | Genuine scan/export |
| Account takeover / credential misuse | Valid user credentials used by another | Off-hours access, location change, shared accounts | calendar | Access logs, MFA records | Remote work |
| Prompt injection in data fed to AI tools | Instruction-like text planted in remarks/fields to steer an AI assistant | Imperative text addressed to "AI/assistant" inside data | (manual flag) | Source of the entry, IT-security review | Test data left in |
| Insider data theft | Bulk export, personal storage | Large exports, USB/cloud uploads | n/a | DLP logs, IT forensics | Legitimate reporting |

## Using the library in a mind map
For each branch you report: scheme | footprint seen (with refs) | evidence still missing | benign alternatives still open | status (TESTED / PARTIALLY TESTED / UNTESTED). Do not escalate a scheme on footprint alone. Footprint plus an unexplained benefit plus a concealment indicator is the threshold for a Class D hypothesis (01-context-triage.md).
