# CONTEXT-FIRST TRIAGE MATRIX

| Class | Signature | Does NOT prove | Correct response |
|---|---|---|---|
| A Hygiene | "duplicate", "free", "trial", typos, wrong UOM text, obsolete codes | Theft or intent | Master-data cleanup, naming standard, retirement workflow |
| B Inefficiency | Manual workaround, yield mismatch, duplicate effort, off-system calculation | Manipulation | Re-engineer process, correct standard, train, instrument |
| C Control bypass | Unauthorized alternate route, override without ECN, missing approver, self-approval | Fraud | Permission redesign, mandatory approval, exception monitoring |
| D Potential fraud | C + unexplained benefit + concealment + missing/contradictory physical evidence + quantified exposure | Guilt until independently established | Counsel-led forensic scope, preservation, controlled interviews |

RULE: D requires at least three independent evidence types:
(1) authorization/control failure, (2) economic or physical inconsistency,
(3) benefit/concealment indicator. Two of three = C + open question.

MANDATORY BENIGN-EXPLANATION CHECK (record all that apply):
trial production / engineering change pending / ERP migration artifact /
unit-of-measure conversion / subcontract tolling / sample or scrap release /
price fixed by OEM contract / shared facility legitimately metered.

MATERIALITY LADDER: document severity basis before rating.
Immaterial + systemic = process priority, not investigation priority.
Material + isolated = targeted test. Material + systemic + concealed = escalate.
