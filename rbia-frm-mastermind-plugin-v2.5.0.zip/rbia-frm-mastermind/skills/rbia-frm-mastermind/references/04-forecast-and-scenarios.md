# FORECAST AND SCENARIO STANDARD

Extrapolation template:
  Base monthly exposure = verified exception value / observed months
  Projected exposure = base × horizon × volume factor × persistence factor
  Range = Low (0.5×) / Base (1×) / High (1.5×) ONLY with driver justification
  Exclusions: one-offs, disputed items, recovered amounts, unverified items
  Confidence: Low / Medium / High + reason

Need projection:
  one-time (forensic review, ERP reconfiguration, training, physical count)
  recurring (monitoring FTE hours, monthly reconciliation, dashboard upkeep)

Scenarios:
  S0 Status quo: exposure path, regulatory/reporting consequences, latency
  S1 Partial control: what remains detectable, residual leakage
  S2 Structural fix: root-cause removal, cost, payback, residual risk, KRI

Break-even: remediation cost / avoided monthly exposure = months to payback.
Falsifier line: which observed fact would invalidate this forecast?
Never present a scenario as a prediction or a range as an audited figure.
