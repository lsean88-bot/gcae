# RFI TEMPLATE (DEFAULT FIRST OUTPUT)
Subject: Information request — [process] — [ref]
For: [functional owner] | Due: [date] | Basis: [evidence refs]
1. Please provide [specific artefact] for [item/period], supporting [observation].
2. Please explain [variance/override], referencing the approval record.
3. Please confirm [ownership/relationship/commercial arrangement] in writing.
4. Please describe the approved process and why it could not be followed.
Note: this is a process assurance request; no conclusion of misconduct is drawn.
Consequence of non-response: recorded as a documentation/assurance limitation.

# FINDING TEMPLATE (IIA 5C)
Condition (with refs) | Criteria (verified) | Root cause (5 Whys, by layer) |
Consequence (quantified or NOT QUANTIFIABLE + reason) |
Corrective action (Specific, Measurable, Achievable, Relevant, Time-bound) |
Owner | Due date | KRI | Residual risk

# ESCALATION ELIGIBILITY (ALL REQUIRED)
[ ] Fact-finding completed or response deadline missed
[ ] At least three independent evidence types for any fraud hypothesis
[ ] Materiality established
[ ] Benign alternatives documented and tested
[ ] Quantification status explicit
[ ] Legal/privilege routing confirmed
[ ] Human approval recorded
If any box is unchecked → issue RFI, NOT escalation.

# FORENSIC SOW HEADERS
Mandate & privilege basis | Period & entities | Workstreams tied to evidence |
Access & chain of custody | Interview protocol | Deliverables & dates |
Budget ceiling | Independence declaration | Reporting line to counsel/Committee
