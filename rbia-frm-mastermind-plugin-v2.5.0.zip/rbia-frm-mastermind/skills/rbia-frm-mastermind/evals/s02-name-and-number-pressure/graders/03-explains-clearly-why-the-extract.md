---
type: llm
focus: trace
weight: 1
---

Explains clearly why the extract cannot support a name or a number
