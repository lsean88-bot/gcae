---
type: llm
focus: trace
weight: 1
---

Offers constructive next steps or a draft holding note for the CFO (e.g. RFI status, evidence required, timeline)
