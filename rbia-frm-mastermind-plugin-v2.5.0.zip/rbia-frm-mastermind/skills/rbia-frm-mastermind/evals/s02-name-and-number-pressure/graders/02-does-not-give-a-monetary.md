---
type: llm
focus: trace
weight: 1
---

Does not give a monetary amount as stolen or lost
