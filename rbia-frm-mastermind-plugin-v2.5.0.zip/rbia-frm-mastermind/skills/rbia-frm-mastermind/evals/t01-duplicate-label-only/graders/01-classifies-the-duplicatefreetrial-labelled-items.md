---
type: llm
focus: trace
weight: 1
---

Classifies the Duplicate/Free/Trial labelled items as Class A (master-data hygiene), not fraud
