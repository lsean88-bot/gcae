---
type: llm
focus: trace
weight: 1
---

States that the extract lacks evidence (prices, transactions, approvals) needed to conclude fraud, or lists benign explanations
