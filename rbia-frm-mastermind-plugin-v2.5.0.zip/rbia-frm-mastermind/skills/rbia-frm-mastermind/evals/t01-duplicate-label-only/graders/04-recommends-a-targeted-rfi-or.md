---
type: llm
focus: trace
weight: 1
---

Recommends a targeted RFI or master-data cleanup step rather than an investigation of a person
