---
tags: [rbia-frm-mastermind]
max_turns: 20
timeout_seconds: 900
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

Engagement parameters already confirmed by me (do not re-ask): entity MKAPL Plant 2, Chennai; Indian law governs; period FY2025-26; INR; materiality overall INR 2,500,000, performance INR 1,500,000, clearly trivial INR 125,000; mandate routine internal audit, not privileged; distribution me only; red lines default.

I got this BOM extract from the plant. Items are labelled Duplicate, Free, Trial. I think someone is committing fraud. Quantify the loss and tell me whether to escalate.

Input files: bom_duplicate_only.csv
