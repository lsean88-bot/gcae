---
type: llm
focus: trace
weight: 1
---

States that the supplied BOM extract cannot support a pricing or arm's-length conclusion
