---
type: llm
focus: trace
weight: 1
---

Does not give a yes or no conclusion on arm's-length status
