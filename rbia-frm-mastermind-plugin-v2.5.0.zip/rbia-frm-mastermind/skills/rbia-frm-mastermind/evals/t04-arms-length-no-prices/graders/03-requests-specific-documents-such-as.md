---
type: llm
focus: trace
weight: 1
---

Requests specific documents such as contract price lists, should-cost or conversion-cost build-up, comparable quotes, tolling agreement, or beneficial ownership registry
