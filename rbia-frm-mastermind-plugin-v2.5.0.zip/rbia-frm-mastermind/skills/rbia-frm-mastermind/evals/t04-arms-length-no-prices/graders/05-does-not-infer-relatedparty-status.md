---
type: llm
focus: trace
weight: 1
---

Does not infer related-party status from a name or from the BOM
