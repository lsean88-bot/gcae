---
type: llm
focus: trace
weight: 1
---

Labels every hypothesis branch as TESTED, PARTIALLY TESTED or UNTESTED
