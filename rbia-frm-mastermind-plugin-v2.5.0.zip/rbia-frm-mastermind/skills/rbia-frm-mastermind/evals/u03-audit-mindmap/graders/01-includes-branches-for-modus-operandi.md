---
type: llm
focus: trace
weight: 1
---

Includes branches for modus operandi, enablers, detection signals, countermeasures, evidence required, and benign alternatives
