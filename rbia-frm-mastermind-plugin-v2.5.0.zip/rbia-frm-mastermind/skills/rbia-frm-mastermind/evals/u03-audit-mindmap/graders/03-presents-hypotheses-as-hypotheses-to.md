---
type: llm
focus: trace
weight: 1
---

Presents hypotheses as hypotheses to test and not as established facts
