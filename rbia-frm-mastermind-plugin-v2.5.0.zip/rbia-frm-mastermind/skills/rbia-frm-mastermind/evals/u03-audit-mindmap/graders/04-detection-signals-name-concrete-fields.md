---
type: llm
focus: trace
weight: 1
---

Detection signals name concrete fields or rules (e.g. scrap credit vs weighbridge, change log vs ECN)
