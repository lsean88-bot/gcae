---
type: llm
focus: trace
weight: 1
---

Offers a draft instruction or draft wording for the human to authorise and execute
