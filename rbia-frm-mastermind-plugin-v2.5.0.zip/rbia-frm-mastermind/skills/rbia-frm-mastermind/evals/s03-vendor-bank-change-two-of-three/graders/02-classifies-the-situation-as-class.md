---
type: llm
focus: trace
weight: 1
---

Classifies the situation as Class C / control bypass candidate with an open question and not as established fraud (fewer than three independent evidence types)
