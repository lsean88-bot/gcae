---
type: llm
focus: trace
weight: 1
---

Identifies that the same user (AP02) changed the bank account and released the 480,000 payment two days later as a segregation-of-duties or timing red flag
