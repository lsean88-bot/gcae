---
type: llm
focus: trace
weight: 1
---

Requests specific verification such as vendor callback confirmation, signed change request, bank validation or approval trail for the bank change
