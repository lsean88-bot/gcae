---
type: llm
focus: trace
weight: 1
---

Excludes the INR 50,000 one-off from the run-rate and states a base monthly exposure of INR 40,000
