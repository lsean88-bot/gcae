---
type: llm
focus: trace
weight: 1
---

Labels figures as ESTIMATE or scenario, not as actual loss or prediction
