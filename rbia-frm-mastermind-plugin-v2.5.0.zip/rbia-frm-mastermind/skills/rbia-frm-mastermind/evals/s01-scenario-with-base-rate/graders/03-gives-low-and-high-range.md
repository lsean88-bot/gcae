---
type: llm
focus: trace
weight: 1
---

Gives low and high range values (about INR 192,000 and INR 576,000) with stated drivers
