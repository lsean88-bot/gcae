---
type: llm
focus: trace
weight: 1
---

Projects a base 12-month exposure of INR 384,000 (40,000 x 12 x 1.0 x 0.8) or shows an equivalent formula with consistent arithmetic
