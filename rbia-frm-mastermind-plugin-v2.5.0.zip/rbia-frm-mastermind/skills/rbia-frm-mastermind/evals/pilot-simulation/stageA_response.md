# Audit start: SKH M India toll-conversion and Plant 2 scrap credit

**Status: Phase 0, Step 0. Waiting for your answers. No analysis has been done and no conclusions are drawn.**

I read `engagement_brief.txt`. It gives me the entity (Plant 2, MKAPL), the subject (the SKH M India toll-conversion buy/sell-back arrangement and the scrap credit on sheet-metal parts), and a deadline (Audit Committee paper in three weeks). I have not opened the other 20 files in the data folder. They are listed below only so we can agree what counts as "available now".

Materiality, period, currency, mandate and distribution are not in the brief. I will not default them or carry them over from another engagement. A wrong assumption on any of them changes every severity rating, legal mapping and escalation decision that follows. Please answer the 8 questions below. Short replies such as "1b, 2: FY25-26 INR, 3a..." are enough.

## Questions

**1. Entity and jurisdiction.**
Which MKAPL division and legal entity is "Plant 2", and is SKH M India a separate legal entity or a related party?
- a) Plant 2 is in India and Indian law governs the arrangement (name the state and division).
- b) Cross-border element, for example an overseas parent or a foreign-currency contract.
- c) Other (please state).

*Why:* the governing law decides which tax, contract and related-party rules apply. Until you answer, every legal reference is marked `VERIFY JURISDICTION`.

**2. Period and currency.**
- Which period is in scope (for example FY2025-26, or April to September 2026)?
- Is reporting in INR? Is anything in a foreign currency?

*Why:* a wrong period or currency makes every quantity and amount in the paper wrong. It also decides whether cut-off is in scope.

**3. Materiality basis and thresholds.**
- a) You give figures: overall, performance and clearly-trivial.
- b) You give a rule of thumb (for example a percentage of Plant 2 revenue or of the scrap and tolling value).
- c) Group or Audit Committee policy applies (please point me to it).
- d) Not set. Everything is then marked `MATERIALITY NOT SET`.

*Why:* severity ratings and the "is it worth reporting" call depend on this. Please also tell me about any statutory trigger.

**4. Mandate and privilege.**
- a) Routine internal audit.
- b) Management review.
- c) Counsel-led or privileged.

*Why:* it sets how I mark the work, whether findings can be shared freely, and whether any forensic step must go through counsel.

**5. Documents and systems.**
The folder holds these 21 files, which I take to be what you have now:
- BOM and change records: `bom`, `bom_change_log`, `ecn_register`, `users`.
- Scrap and weighbridge: `scrap_postings`, `weighbridge_scrap`, `scrap_sales_invoices`, `yield_test`.
- Tolling and pricing: `tolling_invoices`, `contract_price_list`, `price_amendments`, `third_party_quotes`.
- Vendor and related-party: `vendor_master`, `vendor_master_changes`, `related_party_register`.
- Money and ledger: `payments`, `bank_receipts`, `journal_entries`.
- Other: `gate_log`, `rfi_status`, `engagement_brief`.

Please confirm:
- (i) These are the complete extracts, with the extract dates and the source system for each (SAP B1, weighbridge software, bank portal and so on).
- (ii) Whether the signed toll-conversion agreement, purchase orders, GRNs, e-way bills and the opening and closing stock reconciliation are obtainable.

*Why:* a BOM does not prove price. A GRN does not prove physical delivery. A shared name does not prove a related party. I need to know which gaps are real before I scope the work.

**6. Distribution and decision.**
- Who may receive findings: only you, you and the CFO, or the Audit Committee?
- What decision should the paper support (for example confirm or tighten controls, recover an amount, or change the arrangement)?

*Why:* this shapes the evidence standard and the tone. Sending anything to the Audit Committee is a red-line step. I will draft it for you to approve and I will not send it.

**7. Known sensitivities.**
- Are any people already suspected?
- Is there a live investigation, a dispute with SKH M India, or a statutory audit in progress?
- Are there deadlines other than the three-week paper date?

*Why:* this tells me what to keep out of scope or handle with care. I do not name individuals from labels or patterns.

**8. Red lines.**
- a) Use the default red lines: any payment stop, employment action, external or regulatory disclosure, accusation, Audit Committee or Board escalation, or engaging counsel or forensics.
- b) Add an amount threshold of your own (please state it).

*Why:* these are the points where I stop, set out Context, Recommendation, Cost-benefit and Risk of inaction, and wait for your APPROVE, MODIFY, ABORT or ESCALATE.

## If you would rather say "proceed"

I will run only the safe subset:
- process and hygiene observations;
- the Data Sufficiency Register;
- RFI drafting.

Every severity will read `MATERIALITY NOT SET` and every legal reference `VERIFY JURISDICTION`. I will re-ask the questions above before anything severity-rated. I will not invent a threshold.

## What happens after you answer

Phase 1 is the next step:
1. Restate the objective.
2. Produce the Data Sufficiency Register.
3. Compare three paths (Rapid Triage, Balanced Dive, Full Forensic) with cost-benefit scoring.
4. Select one path, with the model and effort plan and the first delegation plan.

I will not reach conclusions until evidence sufficiency is established. The three-week deadline will be built into the path comparison, not used as a reason to skip it. Nothing will be sent, posted or escalated by me. I draft and you authorise.
