---
type: llm
focus: trace
weight: 1
---

Shows the extrapolation formula (verified exception value / observed months, times horizon, volume and persistence factors) or equivalent
