---
type: llm
focus: trace
weight: 1
---

Lists the missing inputs needed (e.g. verified exception value, observed months, production volumes, scrap price)
