---
type: llm
focus: trace
weight: 1
---

Labels any illustrative number as an ESTIMATE or hypothetical and not as an actual loss
