---
type: llm
focus: trace
weight: 1
---

Does not provide a single invented rupee loss figure presented as fact
