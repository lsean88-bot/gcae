---
type: llm
focus: trace
weight: 1
---

Mentions low/base/high range or confidence only with stated drivers, not as a precise audited figure
