---
type: llm
focus: trace
weight: 1
---

Contains no accusation, no assumed amounts, and a note that no conclusion of misconduct is drawn
