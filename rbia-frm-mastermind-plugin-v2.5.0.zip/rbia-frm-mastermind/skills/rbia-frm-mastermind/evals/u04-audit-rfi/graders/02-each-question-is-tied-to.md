---
type: llm
focus: trace
weight: 1
---

Each question is tied to a specific parent or row reference from the extract
