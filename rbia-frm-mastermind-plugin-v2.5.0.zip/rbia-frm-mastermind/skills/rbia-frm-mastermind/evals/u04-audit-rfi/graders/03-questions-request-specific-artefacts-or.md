---
type: llm
focus: trace
weight: 1
---

Questions request specific artefacts or explanations (ECN, approval, yield evidence, reason for Manual issue) rather than asserting a problem
