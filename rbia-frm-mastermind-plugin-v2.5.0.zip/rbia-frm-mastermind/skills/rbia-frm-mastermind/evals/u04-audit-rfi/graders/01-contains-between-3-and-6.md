---
type: llm
focus: trace
weight: 1
---

Contains between 3 and 6 numbered questions
