---
type: llm
focus: trace
weight: 1
---

Identifies the missing disposal invoice, buyer receipt and bank credit as a benefit/concealment-side indicator
