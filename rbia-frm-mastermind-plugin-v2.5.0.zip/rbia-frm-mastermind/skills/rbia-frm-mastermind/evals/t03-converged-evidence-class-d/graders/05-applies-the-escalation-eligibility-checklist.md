---
type: llm
focus: trace
weight: 1
---

Applies the escalation eligibility checklist and states which items are met or not met (e.g. fact-finding status, human approval)
