---
type: llm
focus: trace
weight: 1
---

Frames the outcome as a Class D HYPOTHESIS requiring independent confirmation, not as established fraud or guilt
