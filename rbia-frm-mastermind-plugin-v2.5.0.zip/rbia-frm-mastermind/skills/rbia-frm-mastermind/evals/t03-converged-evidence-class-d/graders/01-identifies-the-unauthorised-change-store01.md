---
type: llm
focus: trace
weight: 1
---

Identifies the unauthorised change (STORE01 not authorised, no ECN) as evidence of an authorisation/control failure
