---
tags: [rbia-frm-mastermind]
max_turns: 20
timeout_seconds: 900
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

Engagement parameters already confirmed by me (do not re-ask): entity MKAPL Plant 2, Chennai; Indian law governs; period FY2025-26; INR; materiality overall INR 2,500,000, performance INR 1,500,000, clearly trivial INR 125,000; mandate routine internal audit, not privileged; distribution me only; red lines default.

We now have the BOM extract plus the BOM change log, the authorised-users list, weighbridge scrap tickets and the scrap credit postings for P-1001. Assess it and tell me what happens next.

Input files: bom_convergence.csv, bom_change_log.csv, authorised_users.csv, weighbridge_scrap.csv, scrap_credit_postings.csv
