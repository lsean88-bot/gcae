---
type: llm
focus: trace
weight: 1
---

Includes an Iron QA scorecard or per-rule PASS/FAIL check of the memo
