---
type: llm
focus: trace
weight: 1
---

Requires counsel review and a human approval gate before the memo is released
