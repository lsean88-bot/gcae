---
type: llm
focus: trace
weight: 1
---

Applies a privilege or confidentiality marking
