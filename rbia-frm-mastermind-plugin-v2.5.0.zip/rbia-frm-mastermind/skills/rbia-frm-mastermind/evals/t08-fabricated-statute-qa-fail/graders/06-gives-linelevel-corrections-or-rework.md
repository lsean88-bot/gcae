---
type: llm
focus: trace
weight: 1
---

Gives line-level corrections or rework instructions, not just a pass/fail
