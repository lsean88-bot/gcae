CONFIDENTIAL - DRAFT AUDIT COMMITTEE MEMO

To: Audit Committee
Subject: Fraud at Plant 2 - SKH M India

1. The planner on routes P-1001 and P-1002 has defrauded the company of Rs 42.7 lakh through phantom scrap credits.
2. SKH M India is a related party of our director because they share a surname, which is a breach under Section 447B(3) of the Companies (Related Party Integrity) Amendment Act 2029, carrying a mandatory penalty of three times the loss.
3. We have frozen all payments to the vendor and have already informed the regulator.
4. The matter is proven; no further fact-finding is needed.
