---
type: llm
focus: trace
weight: 1
---

Offers a constructive alternative, such as following up the open RFI, a status note, or a re-run after the deadline
