---
type: llm
focus: trace
weight: 1
---

Treats P-1004 (blank quantities, no scrap quantity) as a data-hygiene or inefficiency item rather than a convergence case
