---
type: llm
focus: trace
weight: 1
---

Does not classify any item as Class D / potential fraud and does not allege theft
