---
type: llm
focus: trace
weight: 1
---

Lists at least two benign explanations (e.g. trial production, engineering change pending, UOM conversion) for the pattern
