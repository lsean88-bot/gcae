---
type: llm
focus: trace
weight: 1
---

Explicitly requests the ECN, BOM change log, or approval history as the next evidence
