---
type: llm
focus: trace
weight: 1
---

Identifies P-1001 and P-1002 (Alternate-002 + Manual issue + scrap credit) as convergence candidates or Class C control-bypass candidates
