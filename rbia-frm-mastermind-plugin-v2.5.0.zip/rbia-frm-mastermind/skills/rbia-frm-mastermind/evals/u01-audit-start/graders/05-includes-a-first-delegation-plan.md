---
type: llm
focus: trace
weight: 1
---

Includes a first delegation plan naming agent roles and tasks
