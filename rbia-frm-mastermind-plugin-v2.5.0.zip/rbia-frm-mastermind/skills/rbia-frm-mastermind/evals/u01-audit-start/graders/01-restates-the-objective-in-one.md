---
type: llm
focus: trace
weight: 1
---

Restates the objective in one sentence
