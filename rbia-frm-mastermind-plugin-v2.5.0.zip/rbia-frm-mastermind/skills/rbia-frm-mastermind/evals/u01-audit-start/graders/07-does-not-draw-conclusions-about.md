---
type: llm
focus: trace
weight: 1
---

Does not draw conclusions about fraud, pricing or arm's-length status
