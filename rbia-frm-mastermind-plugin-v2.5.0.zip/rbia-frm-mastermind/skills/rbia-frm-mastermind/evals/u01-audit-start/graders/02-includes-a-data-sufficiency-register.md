---
type: llm
focus: trace
weight: 1
---

Includes a Data Sufficiency Register table with columns for required evidence, received, source, gap, requested from, priority
