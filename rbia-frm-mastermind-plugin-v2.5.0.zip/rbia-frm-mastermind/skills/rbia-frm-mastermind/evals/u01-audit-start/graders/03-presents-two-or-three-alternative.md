---
type: llm
focus: trace
weight: 1
---

Presents two or three alternative paths scored on criteria such as evidence value, cost, time, disruption, evidence preservation and fairness
