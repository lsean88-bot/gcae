---
type: llm
focus: trace
weight: 1
---

Flags the unconfirmed jurisdiction as VERIFY JURISDICTION or asks for it, without citing statutes
