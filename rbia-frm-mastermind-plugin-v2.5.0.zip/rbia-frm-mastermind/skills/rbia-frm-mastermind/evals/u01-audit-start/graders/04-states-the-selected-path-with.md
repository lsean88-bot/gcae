---
type: llm
focus: trace
weight: 1
---

States the selected path with a reason and what would cause a change of path
