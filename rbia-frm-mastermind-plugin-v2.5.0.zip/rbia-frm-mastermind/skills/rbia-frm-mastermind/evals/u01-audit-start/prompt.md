---
tags: [rbia-frm-mastermind]
max_turns: 20
timeout_seconds: 900
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

Engagement parameters already confirmed by me (do not re-ask): entity MKAPL Plant 2, Chennai; jurisdiction not yet confirmed; period FY2025-26; INR; materiality overall INR 2,500,000, performance INR 1,500,000, clearly trivial INR 125,000; mandate routine internal audit, not privileged; distribution me only; red lines default.

/audit-start Procurement and sales with SKH M India; objective: assess commercial substance and arm's-length terms; jurisdiction: not yet confirmed; period: FY2025-26; files: bom_convergence.csv

Input files: bom_convergence.csv
