---
type: llm
focus: trace
weight: 1
---

Notes the yield test is consistent with the BOM (12 parts per sheet; scrap about 0.35 kg per sheet) or otherwise cites specific figures from the yield test file
