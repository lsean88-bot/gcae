---
type: llm
focus: trace
weight: 1
---

Records a lesson or Kaizen action (e.g. a missing step in the process, or that benign explanation was confirmed)
