---
type: llm
focus: trace
weight: 1
---

Provides for each key pattern both a benign explanation and an adverse explanation with a distinguishing test
