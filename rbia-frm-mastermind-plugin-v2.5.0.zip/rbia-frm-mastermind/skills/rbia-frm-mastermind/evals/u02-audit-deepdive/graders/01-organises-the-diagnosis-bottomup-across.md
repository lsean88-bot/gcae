---
type: llm
focus: trace
weight: 1
---

Organises the diagnosis bottom-up across layers L0 to L5 (data lineage, master data, transactions, process, financial reporting, governance)
