---
type: llm
focus: trace
weight: 1
---

Includes an information-gap list or open questions
