---
type: llm
focus: trace
weight: 1
---

Gives each key observation a triage class (A, B or C) and does not use Class D
