---
type: llm
focus: trace
weight: 1
---

Proposes structural fixes (e.g. permissions, mandatory ECN field) with an owner and due date or placeholder, not just 'investigate'
