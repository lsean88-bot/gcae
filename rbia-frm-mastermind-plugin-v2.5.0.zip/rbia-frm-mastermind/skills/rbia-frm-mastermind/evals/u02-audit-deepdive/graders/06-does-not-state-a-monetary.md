---
type: llm
focus: trace
weight: 1
---

Does not state a monetary loss or name an individual
