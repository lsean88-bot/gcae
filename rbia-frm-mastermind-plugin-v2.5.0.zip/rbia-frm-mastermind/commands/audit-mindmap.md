---
description: Produce the CFE fraud-tactics mind map as a testable hypothesis tree.
argument-hint: "[process]"
---
Use references/05. Branches: Modus Operandi / Enablers / Detection Signals /
Countermeasures / Evidence Needed / Test Status. Mark every branch TESTED,
PARTIALLY TESTED or UNTESTED. No branch may be presented as established fact.
