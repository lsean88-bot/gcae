---
description: Profile the data, run the deterministic fraud analytics and return reproducible leads with row references.
argument-hint: "[files + what you want tested]"
---
Run Phase 0 Step 0 first if the engagement parameters are not set. Then follow
references/11-analytics-playbook.md: (1) profile each file and tie to a source control
total, (2) choose tests from the catalogue that fit the data and state the preconditions,
(3) run `python3 -I scripts/fraud_analytics.py <test> ...` with --out, (4) report each lead
with test, parameters, population, exception count, denominator, benign explanations and
next evidence, (5) show overlapping amounts once and cross-referenced, (6) list tests not
run and why. Leads only: no names, no loss as fact, no Class D.
Use the recipes in references/14-use-case-playbooks.md (payroll, procure-to-pay, scrap, journals) and log every run with --log.
