---
description: Build extrapolation, need projection and what-if scenarios with ROI.
argument-hint: "[base metrics + horizon]"
---
Execute Phase 6 per references/04. Three scenarios, Low/Base/High ranges,
formula and assumptions exposed, remediation ROI and payback, falsifiers listed.
