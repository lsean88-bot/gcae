---
description: Run the bottom-up L0–L5 structural diagnosis with parallel specialist agents.
argument-hint: "[scope]"
---
Execute Phases 2–5. Delegate to the nine specialists. Return layered root
cause, triage classification, tested benign alternatives, structural fixes,
and an information-gap list. Never skip the Context-First Triage.
