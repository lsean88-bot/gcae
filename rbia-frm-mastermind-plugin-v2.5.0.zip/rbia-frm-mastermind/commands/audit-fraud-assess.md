---
description: Scheme-based fraud risk assessment for a process, using the CFE MO library, with evidence and interview plans drafted for a human CFE.
argument-hint: "[process + entity]"
---
Run Phase 0 Step 0 first if the engagement parameters are not set. Use the cfe-investigator
role and references/09-cfe-mo-library.md. For the process, list relevant schemes with
inherent risk (likelihood x impact against the user's materiality), existing controls,
detection tests available in the analytics toolkit, evidence gaps, and a test status
(TESTED / PARTIALLY TESTED / UNTESTED). Propose a prioritised test plan and the controls
fixes that remove opportunity. Draft preservation, evidence and interview plans only as
drafts for a qualified human, and list the human-only actions. No accusations.
