---
description: Draft a non-accusatory, evidence-referenced fact-finding request.
argument-hint: "[finding refs]"
---
Draft 3–6 precise questions, each tied to a document/row reference, requesting
the specific artefact or explanation that would distinguish a benign cause
from a control failure. Include deadline, owner and consequence of non-response.
No accusations. No assumed amounts.
