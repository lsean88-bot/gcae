import json, os, subprocess, sys, time, glob
from datetime import datetime, timedelta, timezone
import pathlib, shutil, tempfile
_SRC=pathlib.Path(__file__).resolve().parent.parent
_TMP=tempfile.mkdtemp(prefix='rbia_gate_test_')
P=_TMP+'/plugin'
shutil.copytree(_SRC,P,ignore=shutil.ignore_patterns('evals','.git'))
for _f in pathlib.Path(P,'config','approvals').glob('*.json'): _f.unlink()
if pathlib.Path(P,'audit-log','enforcement.jsonl').exists(): pathlib.Path(P,'audit-log','enforcement.jsonl').unlink()
env=dict(os.environ, CLAUDE_PLUGIN_ROOT=P)
KEY="test-key-123"
def run(tool,inp,key=KEY,e=None):
    en=dict(env); en.pop("RBIA_APPROVAL_KEY",None)
    if key: en["RBIA_APPROVAL_KEY"]=key
    if e: en.update(e)
    r=subprocess.run([sys.executable,"-I",P+"/scripts/enforce_gate.py"],input=json.dumps({"tool_name":tool,"tool_input":inp}),capture_output=True,text=True,env=en)
    d=json.loads(r.stdout)["hookSpecificOutput"]["permissionDecision"] if r.stdout.strip() else "allow"
    return d
def issue(*args,key=KEY):
    en=dict(env,RBIA_APPROVAL_KEY=key)
    return subprocess.run([sys.executable,P+"/scripts/approve.py","--yes",*args],capture_output=True,text=True,env=en)
def clear():
    for f in glob.glob(P+"/config/approvals/*.json"): os.remove(f)
res=[]
def t(name,got,exp): res.append((name,got==exp,got,exp)); print(("PASS" if got==exp else "FAIL"),name,got,"(expected",str(exp)+")")
clear()
# Allow cases
t("read file allowed",run("Read",{"file_path":"/x"}),"allow")
t("safe bash allowed",run("Bash",{"command":"python3 analyse.py data.csv"}),"allow")
t("mcp read allowed",run("mcp__x__list_items",{}),"allow")
t("local write allowed",run("Write",{"file_path":"/home/claude/out/report.md","content":"x"}),"allow")
# Deny without token
t("email send denied",run("Bash",{"command":"echo hi | sendmail cfo@corp.com"}),"deny")
t("curl POST denied",run("Bash",{"command":"curl -X POST https://erp.corp/api/pay -d '{}'"}),"deny")
t("curl GET allowed",run("Bash",{"command":"curl -s https://example.com/data.json"}),"allow")
t("sql update denied",run("Bash",{"command":"psql -c \"UPDATE vendor SET bank='X' WHERE id=1\""}),"deny")
t("rm -rf denied",run("Bash",{"command":"rm -rf /data/evidence"}),"deny")
t("git push denied",run("Bash",{"command":"git push origin main"}),"deny")
t("mcp send denied",run("mcp__claude_ai_Gmail__send_message",{"to":"a@b.com"}),"deny")
t("mcp payment denied",run("mcp__erp__release_payment",{"id":5521}),"deny")
t("mcp unclassified denied",run("mcp__erp__frobnicate",{}),"deny")
t("SendMessage denied",run("SendMessage",{"to":"x","message":"y"}),"deny")
t("python smtplib denied",run("Bash",{"command":"python3 -c \"import smtplib;smtplib.SMTP('mail').sendmail('a','b','c')\""}),"deny")
t("python requests.post denied",run("Bash",{"command":"python3 -c \"import requests;requests.post('https://x',data=1)\""}),"deny")
t("node fetch denied",run("Bash",{"command":"node -e \"fetch('https://x',{method:'POST'})\""}),"deny")
t("analytics toolkit allowed",run("Bash",{"command":"python3 -I scripts/fraud_analytics.py profile --file data.csv"}),"allow")
# Control-plane tamper
t("write approval token denied",run("Write",{"file_path":P+"/config/approvals/x.json","content":"{}"}),"deny")
t("edit controls denied",run("Edit",{"file_path":P+"/config/controls.json","old_string":"a","new_string":"b"}),"deny")
t("edit gate script denied",run("Edit",{"file_path":P+"/scripts/enforce_gate.py","old_string":"a","new_string":"b"}),"deny")
t("run approve.py denied",run("Bash",{"command":"python3 scripts/approve.py --action '*' --tool-glob '*' --approver me --yes"}),"deny")
t("read key via bash denied",run("Bash",{"command":"echo $RBIA_APPROVAL_KEY"}),"deny")
t("rm approvals denied",run("Bash",{"command":"rm -f config/approvals/*.json"}),"deny")
# Tokens
r=issue("--action","external_message","--tool-glob","Bash","--approver","Seaneas","--hours","1"); print(r.stdout.strip(),r.stderr.strip())
t("valid token allows matching action",run("Bash",{"command":"echo hi | sendmail cfo@corp.com"}),"allow")
t("token does not cover other action",run("Bash",{"command":"curl -X POST https://erp/pay -d x"}),"deny")
t("token does not cover other tool",run("mcp__gmail__send_message",{"to":"a"}),"deny")
clear()
# bound to input
call={"command":"echo hi | sendmail cfo@corp.com"}
json.dump(call,open(P+"/call.json","w"))
issue("--action","external_message","--tool-glob","Bash","--approver","Seaneas","--hours","1","--input-file",P+"/call.json")
t("input-bound token allows exact draft",run("Bash",call),"allow")
t("input-bound token rejects changed draft",run("Bash",{"command":"echo different | sendmail ceo@corp.com"}),"deny")
clear()
# expired
issue("--action","external_message","--tool-glob","Bash","--approver","S","--hours","0.0001")
time.sleep(1.2)
t("expired token denied",run("Bash",{"command":"sendmail x@y.z"}),"deny")
clear()
# tampered token
issue("--action","external_message","--tool-glob","Bash","--approver","S","--hours","1")
f=glob.glob(P+"/config/approvals/*.json")[0]; d=json.load(open(f)); d["action"]="*"; json.dump(d,open(f,"w"))
t("tampered token (action widened) denied",run("Bash",{"command":"curl -X POST https://x -d y"}),"deny")
clear()
# wrong key
issue("--action","external_message","--tool-glob","Bash","--approver","S","--hours","1",key="other-key")
t("token signed with other key denied",run("Bash",{"command":"sendmail x@y.z"}),"deny")
clear()
# no key configured => fail closed
issue("--action","external_message","--tool-glob","Bash","--approver","S","--hours","1")
t("no key in env fails closed",run("Bash",{"command":"sendmail x@y.z"},key=None),"deny")
clear()
# lifetime cap
r=issue("--action","external_message","--tool-glob","Bash","--approver","S","--hours","48")
t("lifetime >24h refused",("Token lifetime" in (r.stderr+r.stdout)),True)
# malformed input fails closed
en=dict(env,RBIA_APPROVAL_KEY=KEY); r=subprocess.run([sys.executable,"-I",P+"/scripts/enforce_gate.py"],input="not json",capture_output=True,text=True,env=en)
t("malformed hook input denied","deny" if '"deny"' in r.stdout else "allow","deny")
n=sum(1 for x in res if x[1]); print(f"\n{n}/{len(res)} passed")
print("log lines:",sum(1 for _ in open(P+"/audit-log/enforcement.jsonl")))
sys.exit(0 if n==len(res) else 1)
