#!/usr/bin/env python3
"""Human-only approval issuer. Creates a signed, expiring approval token.

Usage (run by the human, in their own shell, with RBIA_APPROVAL_KEY set):
  python3 scripts/approve.py --action external_message --tool-glob 'mcp__*gmail*send*' \
      --approver "Seaneas" --hours 4 [--input-file proposed_call.json]
The agent cannot run this: enforce_gate.py denies any tool call that references it.
"""
import argparse, hashlib, hmac, json, os, sys, uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
from enforce_gate import canon_sha, sign, load_key  # noqa: E402

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--action", required=True, help="e.g. external_message, external_write, erp_or_db_write, destructive, '*'")
    ap.add_argument("--tool-glob", required=True)
    ap.add_argument("--approver", required=True)
    ap.add_argument("--hours", type=float, default=4.0)
    ap.add_argument("--input-file", help="JSON of the exact tool_input being approved (binds the token to that content)")
    ap.add_argument("--yes", action="store_true", help="skip interactive confirmation (tests only)")
    a = ap.parse_args()
    key = load_key()
    if not key:
        sys.exit("Set RBIA_APPROVAL_KEY (or RBIA_APPROVAL_KEY_FILE) in your own shell first.")
    if a.hours <= 0 or a.hours > 24:
        sys.exit("Token lifetime must be >0 and <=24 hours.")
    if not a.yes:
        if not sys.stdin.isatty():
            sys.exit("Interactive confirmation required (no TTY).")
        if input(f"Type APPROVE to authorise {a.action} on {a.tool_glob} for {a.hours}h as {a.approver}: ").strip() != "APPROVE":
            sys.exit("Not approved.")
    tok = {"id": str(uuid.uuid4()), "action": a.action, "tool_glob": a.tool_glob, "approver": a.approver,
           "issued_utc": datetime.now(timezone.utc).isoformat(),
           "expires_utc": (datetime.now(timezone.utc) + timedelta(hours=a.hours)).isoformat()}
    if a.input_file:
        tok["input_sha256"] = canon_sha(json.loads(Path(a.input_file).read_text()))
    tok["sig"] = sign(tok, key)
    out = ROOT / "config" / "approvals" / f"{tok['id']}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(tok, indent=2))
    print("Issued", out)

if __name__ == "__main__":
    main()
