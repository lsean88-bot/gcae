#!/usr/bin/env python3
"""RBIA-FRM fraud analytics toolkit (Python standard library only).

Deterministic, reproducible tests that output LEADS with exact row references, denominators
and input-file hashes. A flag is never a conclusion: confirm with context, benign-alternative
tests and corroboration (SKILL.md Phase 3).

Usage:  python3 -I scripts/fraud_analytics.py <test> [options]   (add --out result.json to save)
Tests:  profile duplicates benford splits round sequence blanks calendar overlap sod recon je ratevar
Row numbers are file line numbers (header = line 1).
"""
import argparse, csv, hashlib, json, math, re, sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from difflib import SequenceMatcher
from pathlib import Path

LEAD = ("LEAD, NOT A CONCLUSION: confirm with context, benign-alternative tests and corroboration "
        "before any classification. Amounts across different tests overlap and are NOT additive.")


# ----------------------------------------------------------------------------- helpers
def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def read(path):
    raw = open(path, "rb").read()
    for enc in ("utf-8-sig", "cp1252"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            text = None
    if text is None:
        sys.exit(f"ERROR: cannot decode {path}; re-export as UTF-8")
    import io
    first = text.lstrip("\ufeff").split("\n", 1)[0]
    counts = {d: first.count(d) for d in ",;\t|"}
    delim = max(counts, key=counts.get) if max(counts.values()) > 0 else ","
    rd = csv.reader(io.StringIO(text, newline=""), delimiter=delim)
    try:
        header = next(rd)
    except StopIteration:
        return [], []
    header = [h.strip() for h in header]
    if not any(header):
        sys.exit(f"ERROR: {path} is empty or has no header row (a leading blank line?)")
    if len(set(header)) != len(header):
        sys.exit(f"ERROR: duplicate column headers in {path}: {header}")
    rows, prev = [], rd.line_num
    for rec in rd:
        start = prev + 1
        prev = rd.line_num
        if not any(c.strip() for c in rec):
            continue
        d = {h: (rec[i] if i < len(rec) else "") for i, h in enumerate(header)}
        d["_row"] = start
        d["_short_or_long"] = len(rec) != len(header)
        rows.append(d)
    if EXCLUDE:
        for col, vals in EXCLUDE:
            if col in header:
                before = len(rows)
                rows = [r for r in rows if norm(r[col]) not in vals]
                SKIPPED[f"excluded_{col}"] += before - len(rows)
    READ_WARN[path] = {"delimiter": delim, "rows_with_wrong_field_count": sum(1 for r in rows if r["_short_or_long"])}
    return header, rows


READ_WARN = {}


def need(header, *cols):
    for c in cols:
        if c and c not in header:
            sys.exit(f"ERROR: column '{c}' not found. Available columns: {header}")


UNPARSED = Counter()
SKIPPED = Counter()
EXCLUDE = []
DECIMAL_COMMA = False
DATE_ORDER = "dmy"


def num(s):
    if s is None:
        return None
    t = str(s).strip()
    t = re.sub(r"(?i)(?:\brs\.?|\binr|\brm|\bmxn|\busd|\bmyr|[$€£₹])\s*", "", t)
    t = t.replace(".", "").replace(",", ".") if DECIMAL_COMMA else t.replace(",", "")
    if t == "":
        return None
    neg = t.startswith("(") and t.endswith(")")
    t = t.strip("()")
    if t.endswith("-") and not neg:
        neg, t = True, t[:-1]
    try:
        v = float(t)
    except ValueError:
        UNPARSED["numeric"] += 1
        return None
    if math.isnan(v) or math.isinf(v):
        UNPARSED["numeric"] += 1
        return None
    return -v if neg else v


DATE_FORMATS_BASE = ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d", "%d-%b-%Y", "%Y-%m")
DATE_FORMATS_DMY = ("%d/%m/%Y %H:%M:%S", "%d/%m/%Y %H:%M", "%d/%m/%Y", "%d-%m-%Y")
DATE_FORMATS_MDY = ("%m/%d/%Y %H:%M:%S", "%m/%d/%Y %H:%M", "%m/%d/%Y", "%m-%d-%Y")
DATE_FORMATS = DATE_FORMATS_BASE + DATE_FORMATS_DMY


def dt(s):
    t = str(s or "").strip()
    if not t:
        return None
    if "T" in t and re.match(r"\d{4}-\d{2}-\d{2}T", t):
        t = t.replace("T", " ")
        t = re.sub(r"(Z|[+-]\d{2}:?\d{2})$", "", t).split(".")[0]
    m = re.match(r"^(\d{1,2})[/-](\d{1,2})[/-]\d{4}", t)
    if m and int(m.group(1)) <= 12 and int(m.group(2)) <= 12 and m.group(1) != m.group(2):
        UNPARSED["date_ambiguous_day_month_order_" + DATE_ORDER] += 1
    for f in (DATE_FORMATS_BASE + (DATE_FORMATS_MDY if DATE_ORDER == "mdy" else DATE_FORMATS_DMY)):
        try:
            return datetime.strptime(t, f)
        except ValueError:
            pass
    UNPARSED["date"] += 1
    return None


def date_only(s):
    t = str(s or "").strip()
    return not re.search(r"\d{1,2}:\d{2}", t)


def norm(s):
    import unicodedata
    t = unicodedata.normalize("NFKC", str(s or "")).casefold()
    return "".join(ch for ch in t if ch.isalnum())


TOOL_VERSION = "2.5.0"


def emit(a, test, files, params, population, exceptions, extra=None, status="OK"):
    defaults_used = []
    if PARSER is not None:
        for act in PARSER._subparsers._group_actions[0].choices[a.cmd]._actions:
            if act.dest in ("help", "limit", "out") or act.default is None or act.default is False:
                continue
            if not any(arg == o or arg.startswith(o + "=") for arg in sys.argv for o in act.option_strings):
                defaults_used.append({act.dest: act.default})
    try:
        script_hash = sha256(__file__)
    except OSError:
        script_hash = None
    res = {"test": test, "status": status, "tool_version": TOOL_VERSION, "script_sha256": script_hash,
           "command_line": sys.argv[1:], "locale": {"decimal_comma": DECIMAL_COMMA, "date_order": DATE_ORDER}, "files": {p: sha256(p) for p in files}, "params": params,
           "defaults_used_CONFIRM_WITH_USER": defaults_used,
           "input_quality": {"read": READ_WARN, "unparsed_values": dict(UNPARSED), "rows_skipped": dict(SKIPPED)},
           "population": population, "exception_count": len(exceptions),
           "exceptions": exceptions[: a.limit], "truncated": max(0, len(exceptions) - a.limit),
           "note": LEAD, "run_utc": datetime.now(timezone.utc).isoformat()}
    if extra:
        res.update(extra)
    s = json.dumps(res, indent=2, ensure_ascii=False)
    if a.quiet and a.out:
        print(f"{test}: status={status} exceptions={len(exceptions)} -> {a.out}")
    else:
        print(s)
    if a.out:
        Path(a.out).write_text(s, encoding="utf-8")
        print(f"# output sha256: {sha256(a.out)}", file=sys.stderr)
    if getattr(a, "log", None):
        rec = {"run_utc": res["run_utc"], "test": test, "tool_version": TOOL_VERSION, "script_sha256": script_hash,
               "command_line": sys.argv[1:], "files": res["files"], "exception_count": len(exceptions),
               "output_sha256": sha256(a.out) if a.out else None}
        with open(a.log, "a", encoding="utf-8") as lf:
            lf.write(json.dumps(rec, ensure_ascii=False) + "\n")
    return res


PARSER = None


def chi2_sf_df8(x):
    h = x / 2.0
    return math.exp(-h) * sum(h ** k / math.factorial(k) for k in range(4))


# ----------------------------------------------------------------------------- tests
def t_profile(a):
    h, rows = read(a.file)
    cols, empty = {}, []
    for c in h:
        vals = [r[c] for r in rows]
        nb = [v for v in vals if str(v).strip() != ""]
        d = {"non_blank": len(nb), "blank": len(vals) - len(nb), "distinct": len(set(nb))}
        nn = [x for x in (num(v) for v in nb) if x is not None]
        d["numeric_parse_rate"] = round(len(nn) / len(nb), 3) if nb else None
        if nb and len(nn) / len(nb) >= 0.9:
            d.update({"numeric": True, "sum": round(sum(nn), 2), "min": min(nn), "max": max(nn)})
        dd = [x for x in (dt(v) for v in nb) if x]
        d["date_parse_rate"] = round(len(dd) / len(nb), 3) if nb else None
        if nb and len(dd) / len(nb) >= 0.9:
            d.update({"date": True, "min_date": str(min(dd)), "max_date": str(max(dd))})
        if not nb:
            empty.append(c)
        cols[c] = d
    UNPARSED.pop("numeric", None); UNPARSED.pop("date", None)  # type probing is not a data-quality signal; see per-column parse rates
    seen = Counter(tuple(r[c] for c in h) for r in rows)
    dupes = [{"values": list(k), "count": v} for k, v in seen.items() if v > 1]
    emit(a, "profile", [a.file], {}, {"rows": len(rows), "columns": len(h)}, dupes,
         {"columns": cols, "all_blank_columns": empty,
          "control_total_hint": "Record row count and numeric sums; compare to the source-system report before any test."})


def t_duplicates(a):
    h, rows = read(a.file)
    keys = a.key.split(",")
    need(h, *keys, a.amount, a.party, a.date)
    g = defaultdict(list)
    for r in rows:
        g[tuple(norm(r[k]) for k in keys)].append(r)
    ex = []
    for k, v in g.items():
        if len(v) > 1 and any(k):
            item = {"type": "exact_key", "key": {kk: v[0][kk] for kk in keys}, "rows": [r["_row"] for r in v]}
            if a.amount:
                amts = [num(r[a.amount]) or 0 for r in v]
                item["amounts"] = amts
                item["repeat_value_potentially_duplicated"] = round(sum(amts[1:]), 2)
            ex.append(item)
    if a.amount and a.party and a.date:
        byp = defaultdict(list)
        for r in rows:
            byp[norm(r[a.party])].append(r)
        for p, lst in byp.items():
            for i in range(len(lst)):
                for j in range(i + 1, len(lst)):
                    x, y = lst[i], lst[j]
                    if tuple(norm(x[k]) for k in keys) == tuple(norm(y[k]) for k in keys):
                        continue
                    ax, ay = num(x[a.amount]), num(y[a.amount])
                    dx, dy = dt(x[a.date]), dt(y[a.date])
                    if None in (ax, ay, dx, dy) or ax == 0:
                        continue
                    if abs(ax - ay) <= a.tol_pct / 100 * abs(ax) and abs((dx - dy).days) <= a.days:
                        ex.append({"type": "near_duplicate", "party": x[a.party], "rows": [x["_row"], y["_row"]],
                                   "amounts": [ax, ay], "days_apart": abs((dx - dy).days)})
    emit(a, "duplicates", [a.file], {"key": keys, "amount": a.amount, "tol_pct": a.tol_pct, "days": a.days},
         {"rows": len(rows)}, ex)


def t_benford(a):
    h, rows = read(a.file)
    need(h, a.col)
    vals = [abs(v) for v in (num(r[a.col]) for r in rows) if v not in (None, 0)]
    reasons = []
    n = len(vals)
    if n < a.min_n:
        reasons.append(f"population too small (n={n} < {a.min_n})")
    if vals and min(vals) > 0 and max(vals) / min(vals) < 100:
        reasons.append(f"range spans fewer than 2 orders of magnitude (max/min={max(vals) / min(vals):.1f})")
    if vals:
        top, cnt = Counter(vals).most_common(1)[0]
        if cnt / n > 0.20:
            reasons.append(f"dominant repeated value {top} ({cnt / n:.0%}): likely fixed-price or system-set amounts")
    if a.digits == 2:
        fd2 = [int(str(f"{v:.10e}").replace(".", "")[:2]) for v in vals if v >= 10 or v < 10]
        if n < 1000:
            reasons.append(f"first-two-digit test needs n >= 1000 (n={n})")
        if not reasons:
            c2 = Counter(fd2)
            exp2 = {d: math.log10(1 + 1 / d) for d in range(10, 100)}
            mad2 = sum(abs(c2.get(d, 0) / n - exp2[d]) for d in exp2) / 90
            lab2 = ("close conformity" if mad2 <= 0.0012 else "acceptable conformity" if mad2 <= 0.0018 else
                    "marginally acceptable" if mad2 <= 0.0022 else "NONCONFORMITY")
            zs = []
            for d in exp2:
                p0 = exp2[d]
                o = c2.get(d, 0) / n
                z = (abs(o - p0) - 1 / (2 * n)) / math.sqrt(p0 * (1 - p0) / n)
                zs.append((d, round(o, 4), round(p0, 4), round(z, 2)))
            top = sorted(zs, key=lambda x: -x[3])[:10]
            emit(a, "benford", [a.file], {"col": a.col, "min_n": a.min_n, "digits": 2}, {"n": n},
                 [{"digits": d, "observed": o, "expected": e, "z": z} for d, o, e, z in top if z > 1.96] if lab2 == "NONCONFORMITY" else [],
                 {"MAD_first_two": round(mad2, 5), "mad_conformity_nigrini_ft2": lab2,
                  "caveat": "Spikes at digit pairs (e.g. 49, 99) point at threshold-hugging or invented numbers; a lead only. Thresholds conventional (Nigrini)."})
            return
    fd = [int(str(f"{v:.10e}")[0]) for v in vals]
    if len(set(fd)) < 7 and n >= 1:
        reasons.append(f"only {len(set(fd))} distinct leading digits present")
    if reasons:
        emit(a, "benford", [a.file], {"col": a.col, "min_n": a.min_n, "digits": a.digits}, {"n": n}, [],
             {"result": "NOT_APPLICABLE: no statistic reported because it would be an artefact",
              "reasons": reasons, "use_instead": "rate vs contract, quantity vs gate log, invoice vs payment, duplicates, recon"},
             status="NOT_APPLICABLE")
        return
    cnt = Counter(fd)
    exp = {d: math.log10(1 + 1 / d) for d in range(1, 10)}
    obs = {d: cnt.get(d, 0) / n for d in range(1, 10)}
    chi2 = sum(((cnt.get(d, 0) - exp[d] * n) ** 2) / (exp[d] * n) for d in range(1, 10))
    p = chi2_sf_df8(chi2)
    mad = sum(abs(obs[d] - exp[d]) for d in range(1, 10)) / 9
    label = ("close conformity" if mad <= 0.006 else "acceptable conformity" if mad <= 0.012 else
             "marginally acceptable" if mad <= 0.015 else "NONCONFORMITY")
    dev = sorted(((d, obs[d] - exp[d]) for d in range(1, 10)), key=lambda x: -abs(x[1]))[:3]
    emit(a, "benford", [a.file], {"col": a.col, "min_n": a.min_n}, {"n": n},
         [{"digit": d, "observed": round(obs[d], 4), "expected": round(exp[d], 4)} for d, _ in dev] if label == "NONCONFORMITY" else [],
         {"chi_square_df8": round(chi2, 3), "p_value": round(p, 6), "MAD": round(mad, 5), "mad_conformity_nigrini": label,
          "interpretation": "Nonconformity directs where to look (digit/segment drill-down); it is not evidence of fraud. "
                            "Thresholds are conventional (Nigrini); verify against your methodology."})


def t_splits(a):
    h, rows = read(a.file)
    need(h, a.party, a.amount, a.date)
    byp = defaultdict(list)
    for r in rows:
        v, d = num(r[a.amount]), dt(r[a.date])
        if not norm(r[a.party]):
            SKIPPED['blank_party_rows'] += 1
            continue
        if v is not None and d and 0 < v < a.threshold:
            byp[norm(r[a.party])].append((d, v, r))
    ex = []
    for p, lst in byp.items():
        lst.sort(key=lambda x: x[0])
        sets = []
        for i in range(len(lst)):
            win = [j for j in range(i, len(lst)) if (lst[j][0] - lst[i][0]).days <= a.days]
            if len(win) >= 2 and sum(lst[j][1] for j in win) >= a.threshold:
                sets.append(tuple(win))
        keep = [w for w in set(sets) if not any(set(w) < set(o) for o in sets)]
        for w in sorted(keep):
            ex.append({"party": lst[w[0]][2][a.party], "rows": [lst[j][2]["_row"] for j in w],
                       "amounts": [lst[j][1] for j in w], "sum": round(sum(lst[j][1] for j in w), 2),
                       "window_days": a.days, "threshold": a.threshold})
    emit(a, "splits", [a.file], {"threshold": a.threshold, "days": a.days}, {"rows": len(rows)}, ex,
         {"caveat": "Overlapping windows can share rows: do not add the sums. Only items strictly below the threshold are counted; thresholds differ by approver level, so run once per level."})


def t_round(a):
    h, rows = read(a.file)
    need(h, a.amount)
    vals = [(num(r[a.amount]), r["_row"]) for r in rows]
    vals = [(v, rn) for v, rn in vals if v not in (None, 0)]
    n = len(vals)
    shares, flagged_base = {}, None
    for b in sorted((int(x) for x in a.bases.split(",")), reverse=True):
        c = sum(1 for v, _ in vals if abs(v) % b == 0)
        s = c / n if n else 0
        shares[b] = {"count": c, "share": round(s, 4), "expected_if_random": round(1 / b, 4)}
        if flagged_base is None and n >= 30 and c >= 5 and s >= 0.05 and s >= 5 / b:
            flagged_base = b
    ex = [{"row": rn, "amount": v} for v, rn in vals if flagged_base and abs(v) % flagged_base == 0]
    emit(a, "round", [a.file], {"amount": a.amount, "bases": a.bases}, {"n": n}, ex,
         {"shares": shares, "flagged_base": flagged_base,
          "caveat": "Round amounts are normal for contract fees, fixed allowances and deposits; check the payment type first."})


def t_sequence(a):
    h, rows = read(a.file)
    need(h, a.col)
    groups = defaultdict(list)
    for r in rows:
        m = re.search(r"(\d+)\D*$", str(r[a.col]))
        if m:
            groups[str(r[a.col])[: m.start(1)] + f"<width{len(m.group(1))}>"].append((int(m.group(1)), r["_row"]))
    ex, coded_pre = [], []
    for pre, lst in groups.items():
        lst.sort()
        nums = [x for x, _ in lst]
        dup = [k for k, c in Counter(nums).items() if c > 1]
        dup_rows = {k: [rw for x, rw in lst if x == k] for k in dup}
        gaps = []
        for x, y in zip(nums, nums[1:]):
            if y - x > 1:
                gaps.append([x + 1, y - 1, {"after_row": lst[nums.index(x)][1], "before_row": lst[nums.index(y)][1]}])
        coded = False
        if len(nums) >= 2 and all(len(str(x)) == 6 and 1990 <= x // 100 <= 2100 and 1 <= x % 100 <= 12 for x in nums):
            ms = [x % 100 for x in sorted(nums)]
            coded = any(b < a_ for a_, b in zip(ms, ms[1:]))
        if coded:
            gaps = []
            coded_pre.append(pre)
        if dup or gaps:
            ex.append({"prefix": pre, "count": len(nums), "duplicates": dup[:20], "duplicate_rows": dict(list(dup_rows.items())[:20]), "gap_ranges": gaps[:30],
                       "missing_numbers": sum(g[1] - g[0] + 1 for g in gaps)})
    emit(a, "sequence", [a.file], {"col": a.col}, {"rows": len(rows)}, ex,
         {"period_coded_prefixes_gap_check_skipped": coded_pre, "caveat": "Month-coded or year-coded numbers (e.g. INV-202604) produce false gaps; interpret by numbering convention."})


def t_blanks(a):
    h, rows = read(a.file)
    need(h, a.col, a.amount)
    sel = rows
    if a.where:
        k, v = a.where.split("=", 1)
        need(h, k)
        sel = [r for r in rows if str(r[k]).strip() == v]
    ex = [{"row": r["_row"], **({"amount": num(r[a.amount])} if a.amount else {}),
           "id": r.get(h[0])} for r in sel if str(r[a.col]).strip() == ""]
    tot = round(sum(e.get("amount") or 0 for e in ex), 2) if a.amount else None
    emit(a, "blanks", [a.file], {"col": a.col, "where": a.where}, {"rows_tested": len(sel)}, ex, {"total_amount": tot})


def t_calendar(a):
    h, rows = read(a.file)
    need(h, a.date, a.amount)
    wk = {int(x) for x in a.weekend.split(",")}
    hol = {x.strip() for x in a.holidays.split(",") if x.strip()}
    ex = []
    for r in rows:
        d = dt(r[a.date])
        if not d:
            continue
        why = []
        if d.weekday() in wk:
            why.append("weekend")
        if d.strftime("%Y-%m-%d") in hol:
            why.append("holiday")
        if ("%H" in "".join(DATE_FORMATS)) and (d.hour or d.minute) and (d.hour >= a.after or d.hour < a.before):
            why.append("off-hours")
        if why:
            ex.append({"row": r["_row"], "date": str(d), "reasons": why, **({"amount": num(r[a.amount])} if a.amount else {})})
    emit(a, "calendar", [a.file], {"weekend_days(Mon=0)": sorted(wk), "after": a.after, "before": a.before},
         {"rows": len(rows)}, ex, {"caveat": "Set --weekend for the jurisdiction (e.g. 4,5 where Fri-Sat is the weekend) and list public holidays."})


def t_overlap(a):
    ha, ra = read(a.a_file)
    hb, rb = read(a.b_file)
    need(ha, a.a_col)
    need(hb, a.b_col)
    bmap = defaultdict(list)
    for r in rb:
        if norm(r[a.b_col]):
            bmap[norm(r[a.b_col])].append(r)
    ex, seen, blank_a = [], set(), []
    for r in ra:
        k = norm(r[a.a_col])
        if not k:
            blank_a.append(r["_row"])
            continue
        if a.unmatched:
            if k not in bmap:
                ex.append({"a_row": r["_row"], "a_value": r[a.a_col], "issue": "not found in B"})
            continue
        if k in bmap:
            ex.append({"type": "exact", "a_row": r["_row"], "a_value": r[a.a_col], "b_rows": [x["_row"] for x in bmap[k]]})
        elif a.fuzzy and len(ra) * len(bmap) <= 2_000_000:
            for kb, lst in bmap.items():
                s = SequenceMatcher(None, k, kb).ratio()
                if s >= a.fuzzy:
                    ex.append({"type": "fuzzy", "similarity": round(s, 3), "a_row": r["_row"], "a_value": r[a.a_col],
                               "b_value": lst[0][a.b_col], "b_rows": [x["_row"] for x in lst]})
    emit(a, "overlap", [a.a_file, a.b_file], {"a_col": a.a_col, "b_col": a.b_col, "fuzzy": a.fuzzy, "unmatched": a.unmatched},
         {"a_rows": len(ra), "b_rows": len(rb)}, ex,
         {"fuzzy_skipped_population_too_large": bool(a.fuzzy and len(ra) * len(bmap) > 2_000_000), "blank_a_rows_not_tested": blank_a[:50], "blank_a_count": len(blank_a),
          "caveat": "Name/address similarity alone does not establish a related party or conflict: confirm with registry, declarations and bank data."})


def t_sod(a):
    ha, ra = read(a.a_file)
    hb, rb = read(a.b_file)
    need(ha, a.a_key, a.a_actor, a.a_date)
    need(hb, a.b_key, a.b_actor, a.b_date)
    idx = defaultdict(list)
    for r in ra:
        idx[norm(r[a.a_key])].append(r)
    ex = []
    for r in rb:
        for x in idx.get(norm(r[a.b_key]), []):
            if norm(x[a.a_actor]) and norm(x[a.a_actor]) == norm(r[a.b_actor]):
                item = {"entity": r[a.b_key], "actor": r[a.b_actor], "a_row": x["_row"], "b_row": r["_row"]}
                if a.a_date and a.b_date:
                    d1, d2 = dt(x[a.a_date]), dt(r[a.b_date])
                    if d1 and d2:
                        if date_only(x[a.a_date]) or date_only(r[a.b_date]):
                            d1, d2 = d1.replace(hour=0, minute=0, second=0), d2.replace(hour=0, minute=0, second=0)
                        gap = (d2 - d1).total_seconds() / 86400
                        if a.days is not None and not (0 <= gap <= a.days):
                            continue
                        item["days_between"] = round(gap, 2)
                    else:
                        item["date_unparsed"] = True
                ex.append(item)
    by_actor = Counter(e["actor"] for e in ex)
    emit(a, "sod", [a.a_file, a.b_file], {"a": [a.a_key, a.a_actor], "b": [a.b_key, a.b_actor], "days": a.days},
         {"a_rows": len(ra), "b_rows": len(rb)}, ex, {"by_actor": dict(by_actor),
         "caveat": "Same user on incompatible steps is a control-design lead; verify the system role/permission matrix and compensating approvals."})


def t_recon(a):
    ha, ra = read(a.a_file)
    hb, rb = read(a.b_file)
    keys = a.keys.split(",")
    need(ha, *keys, a.a_val)
    need(hb, *keys, a.b_val)
    A, B = defaultdict(float), defaultdict(float)
    for r in ra:
        A[tuple(norm(r[k]) for k in keys)] += num(r[a.a_val]) or 0
    for r in rb:
        B[tuple(norm(r[k]) for k in keys)] += num(r[a.b_val]) or 0
    label = {tuple(norm(r[k]) for k in keys): tuple(r[k] for k in keys) for r in ra + rb}
    ex, tot, gross, pos, neg_ = [], 0.0, 0.0, [], []
    for k in sorted(set(A) | set(B)):
        av, bv = A.get(k), B.get(k)
        if av is None or bv is None:
            ex.append({"key": label[k], "status": "A_ONLY" if bv is None else "B_ONLY", "a": av, "b": bv})
            continue
        diff = av - bv
        pct = (diff / bv * 100) if bv else None
        if (a.direction == "a-gt-b" and diff <= 0) or (a.direction == "a-lt-b" and diff >= 0):
            continue
        if (bv == 0 and av != 0) or (bv != 0 and abs(diff) > a.tol_pct / 100 * abs(bv)):
            ex.append({"key": label[k], "status": "DIFF", "a": round(av, 2), "b": round(bv, 2), "diff": round(diff, 2),
                       "diff_pct_of_b": None if pct is None else round(pct, 1)})
            tot += diff
            gross += abs(diff)
            (pos if diff > 0 else neg_).append(diff)
    emit(a, "recon", [a.a_file, a.b_file], {"keys": keys, "a_val": a.a_val, "b_val": a.b_val, "tol_pct": a.tol_pct},
         {"a_keys": len(A), "b_keys": len(B)}, ex, {"net_difference_over_exceptions": round(tot, 2), "gross_absolute_difference": round(gross, 2),
         "a_greater_than_b_total": round(sum(pos), 2), "a_less_than_b_total": round(sum(neg_), 2),
         "a_only_keys": sum(1 for e in ex if e["status"] == "A_ONLY"), "b_only_keys": sum(1 for e in ex if e["status"] == "B_ONLY"),
         "caveat": "Treat B as the independent source. A difference is an unreconciled quantity until UOM, timing, cut-off and conversion are explained."})


def t_je(a):
    h, rows = read(a.file)
    need(h, a.prepared, a.approved, a.support, a.narr, a.amount, a.date, a.credit)
    kw = [k.strip().lower() for k in a.keywords.split(",") if k.strip()]
    kwre = re.compile("|".join(r"\b" + re.escape(k[:-1]) + r"\b" if k.endswith("$") else r"\b" + re.escape(k) + r"\w*" for k in kw), re.I) if kw else None
    wk = {int(x) for x in a.weekend.split(",") if x != ""}
    tests, flags = defaultdict(list), defaultdict(list)
    for r in rows:
        amt = num(r[a.amount]) or 0
        if a.credit and not amt:
            amt = num(r[a.credit]) or 0
        tag = []
        if norm(r[a.prepared]) and norm(r[a.prepared]) == norm(r[a.approved]):
            tag.append("self_approved")
        if not norm(r[a.approved]):
            tag.append("no_approver")
        if not norm(r[a.support]):
            tag.append("no_support_ref")
        if amt and abs(amt) % a.round_base == 0:
            tag.append("round_amount")
        if kwre and kwre.search(str(r[a.narr])):
            tag.append("adjustment_keyword")
        d = dt(r[a.date])
        if d and d.weekday() in wk:
            tag.append("weekend")
        if d and a.period_end_days:
            nxt = (d.replace(day=28) + timedelta(days=4)).replace(day=1)
            if (nxt - d.replace(hour=0, minute=0, second=0)).days <= a.period_end_days:
                tag.append("period_end")
        for t in tag:
            tests[t].append({"row": r["_row"], "amount": amt})
            flags[r["_row"]].append(t)
    summary = {t: {"count": len(v), "amount_sum": round(sum(x["amount"] for x in v), 2)} for t, v in tests.items()}
    ex = [{"row": rn, "flags": f} for rn, f in flags.items() if len(f) >= a.min_flags]
    emit(a, "je", [a.file], {"round_base": a.round_base, "keywords": kw, "weekend": sorted(wk), "min_flags": a.min_flags,
                             "period_end_days": a.period_end_days}, {"rows": len(rows)}, ex,
         {"flag_summary(not additive)": summary, "exceptions_note": f"exceptions = entries with {a.min_flags} or more flags; single-flag counts are in flag_summary",
          "not_tested": ["debit/credit balance", "posting time", "rarely used accounts", "user seniority"],
          "caveat": "Self-approval can be a small-entity reality; check delegation of authority and compensating review."})


def t_ratevar(a):
    hi, ri = read(a.inv_file)
    hc, rc = read(a.contract_file)
    need(hi, a.party, a.rate, a.qty, a.inv_date, a.inv_service)
    need(hc, a.c_party, a.c_rate, a.c_from, a.c_to, a.c_service)
    crates = defaultdict(list)
    for r in rc:
        key = (norm(r[a.c_party]), norm(r[a.c_service]) if a.c_service else "")
        cf = dt(r[a.c_from]) if a.c_from else None
        ct_ = dt(r[a.c_to]) if a.c_to else None
        if (a.c_from and str(r[a.c_from]).strip() and cf is None) or (a.c_to and str(r[a.c_to]).strip() and ct_ is None):
            SKIPPED["contract_rows_excluded_unparseable_dates"] += 1
            continue
        if ct_ is not None and date_only(r[a.c_to]):
            ct_ = ct_ + timedelta(days=1) - timedelta(seconds=1)
        crates[key].append((cf, ct_, num(r[a.c_rate]), r["_row"]))
    ex, tot, over, under, nocontract, ambiguous = [], 0.0, 0.0, 0.0, [], []
    for r in ri:
        key = (norm(r[a.party]), norm(r[a.inv_service]) if a.inv_service else "")
        ir, q, d = num(r[a.rate]), num(r[a.qty]), (dt(r[a.inv_date]) if a.inv_date else None)
        cands = crates.get(key, [])
        if a.inv_date and d:
            cands = [c for c in cands if (c[0] is None or d >= c[0]) and (c[1] is None or d <= c[1])]
        if not cands:
            nocontract.append(r["_row"])
            continue
        rates = {c[2] for c in cands}
        if len(rates) > 1:
            ambiguous.append({"row": r["_row"], "contract_rows": [c[3] for c in cands], "rates": sorted(x for x in rates if x is not None)})
            continue
        cr = cands[0][2]
        if ir is not None and q is not None and cr is not None and abs(ir - cr) > 0.005:
            var = (ir - cr) * q
            tot += var
            if var > 0:
                over += var
            else:
                under += var
            ex.append({"row": r["_row"], "invoice_rate": ir, "contract_rate": cr, "contract_row": cands[0][3], "qty": q,
                       "variance_vs_contract": round(var, 2)})
    emit(a, "ratevar", [a.inv_file, a.contract_file], {"party": a.party, "dated": bool(a.inv_date), "by_service": bool(a.inv_service)},
         {"invoices": len(ri)}, ex,
         {"net_variance_vs_contract": round(tot, 2), "overcharge_total": round(over, 2), "undercharge_total": round(under, 2),
          "invoice_rows_with_no_applicable_contract_rate": nocontract[:100], "no_contract_count": len(nocontract),
          "ambiguous_multiple_rates_not_tested": ambiguous[:50],
          "caveat": "Variance is against the supplied price list. Put amendments in the price list as dated rows. Check escalation clauses, change orders and the signed agreement before calling it an overcharge."})


def _need_cols(h, *cols):
    need(h, *cols)


def t_match3(a):
    hp, rp = read(a.po_file); hg, rg = read(a.grn_file); hi, ri = read(a.inv_file)
    need(hp, a.po_key); need(hg, a.grn_key); need(hi, a.inv_po_key, a.inv_amount)
    need(hp, a.po_amount)
    po, dupo = {}, set()
    for r in rp:
        k = norm(r[a.po_key])
        if not k:
            SKIPPED["po_rows_blank_key"] += 1
            continue
        if k in po:
            dupo.add(k)
        po[k] = r
    grn = defaultdict(list)
    for r in rg:
        grn[norm(r[a.grn_key])].append(r)
    ex = []
    for r in ri:
        k = norm(r[a.inv_po_key])
        issues = []
        if not k:
            issues.append("invoice_has_no_po_reference")
        elif k not in po:
            issues.append("po_not_in_po_file")
        if k and k not in grn:
            issues.append("no_goods_receipt")
        if k in dupo:
            issues.append("po_number_duplicated_in_po_file")
        elif k and k in po and a.po_amount:
            pa, ia = num(po[k][a.po_amount]), num(r[a.inv_amount])
            if pa is not None and ia is not None and ia > pa * (1 + a.tol_pct / 100):
                issues.append(f"invoice_exceeds_po_by_{round(ia - pa, 2)}")
        if issues:
            ex.append({"row": r["_row"], "po_ref": r[a.inv_po_key], "amount": num(r[a.inv_amount]), "issues": issues})
    emit(a, "match3", [a.po_file, a.grn_file, a.inv_file], {"tol_pct": a.tol_pct}, {"invoices": len(ri), "pos": len(rp), "grns": len(rg)}, ex,
         {"amount_by_issue(not additive)": {i: round(sum(e["amount"] or 0 for e in ex if any(x.startswith(i) for x in e["issues"])), 2)
                                           for i in ("invoice_has_no_po_reference", "po_not_in_po_file", "no_goods_receipt", "invoice_exceeds_po")},
          "caveat": "Services, advances and blanket POs may legitimately lack a GRN; one invoice can carry several issues, so do not add the issue totals."})


def t_datecheck(a):
    ha, ra = read(a.a_file); hb, rb = read(a.b_file)
    need(ha, a.a_key, a.a_date); need(hb, a.b_key, a.b_date, a.b_amount)
    first, present = {}, set()
    for r in ra:
        d = dt(r[a.a_date])
        k = norm(r[a.a_key])
        if k:
            present.add(k)
        if d and k and (k not in first or d < first[k][0]):
            first[k] = (d, r["_row"])
    ex = []
    for r in rb:
        k, d = norm(r[a.b_key]), dt(r[a.b_date])
        if not k:
            SKIPPED["b_rows_blank_key"] += 1
        elif k not in present:
            ex.append({"b_row": r["_row"], "key": r[a.b_key], "issue": "key_not_found_in_A"})
        elif k not in first:
            if any(not str(x[a.a_date]).strip() for x in ra if norm(x[a.a_key]) == k):
                SKIPPED["b_rows_whose_key_has_blank_a_date_no_event"] += 1
            else:
                ex.append({"b_row": r["_row"], "key": r[a.b_key], "issue": "a_date_unparsed"})
        elif d is None:
            ex.append({"b_row": r["_row"], "key": r[a.b_key], "issue": "b_date_unparsed"})
        else:
            gap = (first[k][0].replace(hour=0, minute=0, second=0) - d.replace(hour=0, minute=0, second=0)).days
            if a.mode == "b-after-a":
                gap = -gap
            if gap > a.min_days:
                ex.append({"b_row": r["_row"], "key": r[a.b_key], "b_date": str(d.date()), "a_date": str(first[k][0].date()),
                           "a_row": first[k][1], ("b_later_by_days" if a.mode == "b-after-a" else "b_earlier_by_days"): gap,
                           "amount": num(r[a.b_amount]) if a.b_amount else None})
    by_issue = Counter(e.get("issue", "date_violation") for e in ex)
    amt_by_key = defaultdict(float)
    for e in ex:
        if e.get("issue") is None and e.get("amount") is not None:
            amt_by_key[e["key"]] += e["amount"]
    emit(a, "datecheck", [a.a_file, a.b_file], {"min_days": a.min_days}, {"a_rows": len(ra), "b_rows": len(rb)}, ex,
         {"mode": a.mode, "counts_by_issue": dict(by_issue), "amount_flagged_by_key(not additive across tests)": {k: round(v, 2) for k, v in amt_by_key.items()}, "use": "mode b-after-a: payments after resignation/termination/contract end (A date blank = no event, skipped). Mode b-before-a: B event dated before A creation/issue date: vendor paid before creation, payment before invoice date, receipt before PO, change before approval.",
          "caveat": "Back-dating and migrated records are benign explanations; confirm creation date against system audit trail."})


def t_dormant(a):
    h, rows = read(a.file)
    need(h, a.party, a.date, a.amount)
    byp = defaultdict(list)
    for r in rows:
        d = dt(r[a.date])
        if not norm(r[a.party]):
            SKIPPED['blank_party_rows'] += 1
            continue
        if d:
            byp[norm(r[a.party])].append((d, r))
    ex = []
    for p, lst in byp.items():
        lst.sort(key=lambda x: x[0])
        for (d0, _), (d1, r1) in zip(lst, lst[1:]):
            if (d1 - d0).days >= a.dormant_days:
                ex.append({"party": r1[a.party], "row": r1["_row"], "gap_days": (d1 - d0).days, "last_active": str(d0.date()),
                           "reactivated": str(d1.date()), "amount": num(r1[a.amount]) if a.amount else None})
    emit(a, "dormant", [a.file], {"dormant_days": a.dormant_days}, {"rows": len(rows)}, ex,
         {"caveat": "Seasonal or project-based suppliers legitimately go quiet; check master-data change log and approval for the reactivation."})


def t_shared(a):
    h, rows = read(a.file)
    need(h, a.key, a.id)
    g = defaultdict(dict)
    rr = defaultdict(list)
    lab = {}
    for r in rows:
        k, i = norm(r[a.key]), norm(r[a.id])
        if k and i:
            g[k].setdefault(i, r[a.id])
            rr[k].append(r["_row"])
            lab.setdefault(k, r[a.key])
    ex = [{"shared_value": lab[k], "distinct_ids": len(v), "ids": sorted(v.values())[:20], "rows": rr[k][:20]} for k, v in g.items() if len(v) >= 2]
    emit(a, "shared", [a.file], {"key": a.key, "id": a.id}, {"rows": len(rows)}, ex,
         {"caveat": "Shared bank account/address/phone across employees or vendors is a lead (ghost or related-party), but family members, agents and group companies share legitimately."})


def t_outlier(a):
    h, rows = read(a.file)
    need(h, a.amount, a.group, a.entity)
    grp = defaultdict(list)
    for r in rows:
        v = num(r[a.amount])
        if a.group and not norm(r[a.group]):
            SKIPPED["blank_group_rows"] += 1
            continue
        if v is not None:
            grp[norm(r[a.group]) if a.group else ""].append((v, r))
    ex = []
    for gk, lst in grp.items():
        if len(lst) < a.min_group:
            continue
        vals = sorted(v for v, _ in lst)
        med = vals[len(vals) // 2] if len(vals) % 2 else (vals[len(vals) // 2 - 1] + vals[len(vals) // 2]) / 2
        dev = sorted(abs(v - med) for v in vals)
        mad = dev[len(dev) // 2] if len(dev) % 2 else (dev[len(dev) // 2 - 1] + dev[len(dev) // 2]) / 2
        if mad == 0:
            continue
        for v, r in lst:
            z = 0.6745 * (v - med) / mad
            if abs(z) >= a.z:
                ex.append({"row": r["_row"], "group": r[a.group] if a.group else None, "value": v, "group_median": med, "robust_z": round(z, 2)})
    by_ent = None
    if a.entity:
        ent = defaultdict(lambda: {"rows": [], "periods": 0, "max_abs_z": 0.0})
        rowent = {r["_row"]: r[a.entity] for r in rows}
        for e in ex:
            d = ent[rowent[e["row"]]]
            d["rows"].append(e["row"]); d["periods"] += 1; d["max_abs_z"] = max(d["max_abs_z"], abs(e["robust_z"]))
        by_ent = sorted(({"entity": k, **v} for k, v in ent.items()), key=lambda x: -x["periods"])[:50]
    emit(a, "outlier", [a.file], {"z": a.z, "min_group": a.min_group, "group": a.group, "entity": a.entity}, {"rows": len(rows)}, ex,
         {"by_entity_repeat_outliers": by_ent, "caveat": "Statistical outliers are not errors or fraud; review with the owner. Groups below min_group or with zero MAD are skipped (reported only by absence)."})


def t_unsupported(a):
    ha, ra = read(a.a_file); hb, rb = read(a.b_file)
    keys = a.keys.split(",")
    need(ha, *keys, a.a_val, a.entity); need(hb, *keys, a.b_val)
    B = defaultdict(float)
    for r in rb:
        B[tuple(norm(r[k]) for k in keys)] += num(r[a.b_val]) or 0
    per = defaultdict(lambda: {"periods_claimed": 0, "periods_unsupported": 0, "unsupported_amount": 0.0, "rows": []})
    for r in ra:
        av = num(r[a.a_val])
        if av is None or av <= 0:
            continue
        d = per[r[a.entity]]
        d["periods_claimed"] += 1
        sup = B.get(tuple(norm(r[k]) for k in keys))
        if sup is None or sup <= a.min_support:
            d["periods_unsupported"] += 1
            d["unsupported_amount"] += (num(r[a.amount]) if a.amount and a.amount in r else av) or 0
            d["rows"].append(r["_row"])
    ex = [{"entity": k, **{x: (round(y, 2) if isinstance(y, float) else y) for x, y in v.items() if x != "rows"}, "rows": v["rows"][:12]}
          for k, v in per.items() if v["periods_unsupported"] > 0]
    ex.sort(key=lambda e: (-e["periods_unsupported"], -e["unsupported_amount"]))
    emit(a, "unsupported", [a.a_file, a.b_file], {"keys": keys, "a_val": a.a_val, "b_val": a.b_val, "min_support": a.min_support, "amount": a.amount},
         {"a_rows": len(ra), "entities": len(per)}, ex,
         {"use": "Claims with no independent support: pay with no attendance (ghost), OT claimed but not clocked, receipts with no delivery, expenses with no approval record.",
          "caveat": "Absent support may be a data-extract gap, leave, remote work or timing; confirm the B extract is complete for the period before treating as exception. Amount is per entity and not additive with other tests."})


def t_concentration(a):
    h, rows = read(a.file)
    need(h, a.party, a.amount)
    tot, label = defaultdict(float), {}
    for r in rows:
        v, k = num(r[a.amount]), norm(r[a.party])
        if not k:
            SKIPPED["blank_party_rows"] += 1
            continue
        if v is not None:
            tot[k] += v
            label.setdefault(k, r[a.party].strip())
    grand = sum(tot.values())
    ranked = sorted(tot.items(), key=lambda x: -x[1])
    hhi = sum((v / grand * 100) ** 2 for v in tot.values()) if grand else None
    ex = [{"party": label[k], "amount": round(v, 2), "share_pct": round(v / grand * 100, 1) if grand else None} for k, v in ranked[: a.top]]
    emit(a, "concentration", [a.file], {"top": a.top}, {"rows": len(rows), "parties": len(tot)}, ex,
         {"total": round(grand, 2), "HHI_0_to_10000": None if hhi is None else round(hhi), "negative_totals_present": any(v < 0 for v in tot.values()),
          "caveat": "Concentration is a dependency/related-party lead, not a finding; single-source supply can be contractual."})


def build():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter, allow_abbrev=False)
    sub = p.add_subparsers(dest="cmd", required=True)
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--limit", type=int, default=200)
    common.add_argument("--out")
    common.add_argument("--exclude", action="append", default=[], metavar="COL=v1|v2",
                        help="drop rows (in every file that has COL) whose COL value is listed; use to show already-flagged IDs once. Repeatable")
    common.add_argument("--quiet", action="store_true", help="with --out: write the file and print only a one-line summary")
    common.add_argument("--log", help="append a one-line reproducibility record (JSONL) for the engagement file")
    common.add_argument("--decimal-comma", action="store_true", help="numbers like 1.234,56")
    common.add_argument("--date-order", choices=["dmy", "mdy"], default="dmy", help="order for slashed dates; ISO always accepted")

    HELP = {"tol_pct": "tolerance percent: set with the user, never assumed", "keys": "comma list of join columns present in both files",
            "entity": "column identifying the person/vendor to roll results up to", "min_support": "B value at or below this counts as unsupported (0 = no support)",
            "a_val": "numeric column in file A", "b_val": "numeric column in file B", "amount": "numeric amount column for totals",
            "days": "window in days: set with the user", "threshold": "approval limit: take from the delegation of authority",
            "min_days": "tolerance in days", "mode": "b-before-a: B earlier than A (e.g. paid before vendor created); b-after-a: B later than A (e.g. paid after resignation)",
            "dormant_days": "inactivity period in days: set with the user", "z": "robust z cutoff", "min_group": "skip groups smaller than this",
            "direction": "a-gt-b reports only over-claims in A; a-lt-b the reverse", "unmatched": "report A values with no match in B",
            "fuzzy": "similarity 0-1 for near matches (names only)", "round_base": "amounts divisible by this are flagged: set with the user",
            "min_flags": "list only entries with at least this many flags", "period_end_days": "flag entries within this many days of month end",
            "party": "payee/vendor/supplier column", "date": "date column", "file": "CSV file", "col": "column name", "key": "identifier column",
            "id": "entity identifier column", "top": "how many parties to list", "min_n": "minimum population for Benford", "digits": "1 = first digit, 2 = first two digits (n>=1000)"}
    def add(name, fn, *args):
        s = sub.add_parser(name, parents=[common], allow_abbrev=False)
        for spec in args:
            flags, kw = spec[0], spec[1]
            fl = flags if isinstance(flags, tuple) else (flags,)
            dest = fl[0].lstrip("-").replace("-", "_")
            if "help" not in kw and dest in HELP:
                kw = dict(kw, help=HELP[dest])
            s.add_argument(*fl, **kw)
        s.set_defaults(fn=fn)

    F = lambda **k: (("--file",), dict(required=True, **k))
    add("profile", t_profile, F())
    add("duplicates", t_duplicates, F(), ("--key", dict(required=True)), ("--amount", dict()), ("--party", dict()),
        ("--date", dict()), ("--tol-pct", dict(type=float, default=0.0)), ("--days", dict(type=int, default=7)))
    add("benford", t_benford, F(), ("--col", dict(required=True)), ("--min-n", dict(type=int, default=300)), ("--digits", dict(type=int, choices=[1, 2], default=1)))
    add("splits", t_splits, F(), ("--party", dict(required=True)), ("--amount", dict(required=True)), ("--date", dict(required=True)),
        ("--threshold", dict(type=float, required=True)), ("--days", dict(type=int, default=7)))
    add("round", t_round, F(), ("--amount", dict(required=True)), ("--bases", dict(default="1000,100")))
    add("sequence", t_sequence, F(), ("--col", dict(required=True)))
    add("blanks", t_blanks, F(), ("--col", dict(required=True)), ("--amount", dict()), ("--where", dict()))
    add("calendar", t_calendar, F(), ("--date", dict(required=True)), ("--amount", dict()), ("--weekend", dict(default="5,6")),
        ("--holidays", dict(default="")), ("--after", dict(type=int, default=20)), ("--before", dict(type=int, default=6)))
    add("overlap", t_overlap, ("--a-file", dict(required=True)), ("--a-col", dict(required=True)), ("--b-file", dict(required=True)),
        ("--b-col", dict(required=True)), ("--fuzzy", dict(type=float, default=0.0)), ("--unmatched", dict(action="store_true")))
    add("sod", t_sod, ("--a-file", dict(required=True)), ("--a-key", dict(required=True)), ("--a-actor", dict(required=True)),
        ("--a-date", dict()), ("--b-file", dict(required=True)), ("--b-key", dict(required=True)), ("--b-actor", dict(required=True)),
        ("--b-date", dict()), ("--days", dict(type=float, default=None)))
    add("recon", t_recon, ("--a-file", dict(required=True)), ("--b-file", dict(required=True)), ("--keys", dict(required=True)),
        ("--a-val", dict(required=True)), ("--b-val", dict(required=True)), ("--tol-pct", dict(type=float, default=10.0)),
        ("--direction", dict(choices=["both", "a-gt-b", "a-lt-b"], default="both")))
    add("je", t_je, F(), ("--prepared", dict(required=True)), ("--approved", dict(required=True)), ("--support", dict(required=True)),
        ("--narr", dict(required=True)), ("--amount", dict(required=True)), ("--date", dict(required=True)),
        ("--round-base", dict(type=float, default=10000)), ("--credit", dict()), ("--period-end-days", dict(type=int)),
        ("--weekend", dict(default="5,6")), ("--min-flags", dict(type=int, default=2)),
        ("--keywords", dict(default="adjust,cleanup,clean up,reclass,write-off,write off,plug$,correct,true-up")))
    add("ratevar", t_ratevar, ("--inv-file", dict(required=True)), ("--party", dict(required=True)), ("--rate", dict(required=True)),
        ("--qty", dict(required=True)), ("--contract-file", dict(required=True)), ("--c-party", dict(required=True)),
        ("--c-rate", dict(required=True)), ("--inv-date", dict()), ("--inv-service", dict()), ("--c-from", dict()),
        ("--c-to", dict()), ("--c-service", dict()))
    add("match3", t_match3, ("--po-file", dict(required=True)), ("--po-key", dict(required=True)), ("--po-amount", dict()),
        ("--grn-file", dict(required=True)), ("--grn-key", dict(required=True)), ("--inv-file", dict(required=True)),
        ("--inv-po-key", dict(required=True)), ("--inv-amount", dict(required=True)), ("--tol-pct", dict(type=float, default=0.0)))
    add("datecheck", t_datecheck, ("--a-file", dict(required=True)), ("--a-key", dict(required=True)), ("--a-date", dict(required=True)),
        ("--b-file", dict(required=True)), ("--b-key", dict(required=True)), ("--b-date", dict(required=True)), ("--b-amount", dict()),
        ("--min-days", dict(type=int, default=0)), ("--mode", dict(choices=["b-before-a", "b-after-a"], default="b-before-a")))
    add("dormant", t_dormant, F(), ("--party", dict(required=True)), ("--date", dict(required=True)), ("--amount", dict()),
        ("--dormant-days", dict(type=int, required=True)))
    add("shared", t_shared, F(), ("--key", dict(required=True)), ("--id", dict(required=True)))
    add("outlier", t_outlier, F(), ("--amount", dict(required=True)), ("--group", dict(required=True)), ("--entity", dict()), ("--z", dict(type=float, default=3.5)),
        ("--min-group", dict(type=int, default=8)))
    add("unsupported", t_unsupported, ("--a-file", dict(required=True)), ("--b-file", dict(required=True)), ("--keys", dict(required=True)),
        ("--a-val", dict(required=True)), ("--b-val", dict(required=True)), ("--entity", dict(required=True)), ("--amount", dict()),
        ("--min-support", dict(type=float, default=0.0)))
    add("concentration", t_concentration, F(), ("--party", dict(required=True)), ("--amount", dict(required=True)), ("--top", dict(type=int, default=10)))
    return p


if __name__ == "__main__":
    PARSER = build()
    args = PARSER.parse_args()
    DECIMAL_COMMA, DATE_ORDER = args.decimal_comma, args.date_order
    for ex_ in args.exclude:
        c_, _, v_ = ex_.partition("=")
        EXCLUDE.append((c_, {norm(x) for x in v_.split("|") if norm(x)}))
    args.fn(args)
