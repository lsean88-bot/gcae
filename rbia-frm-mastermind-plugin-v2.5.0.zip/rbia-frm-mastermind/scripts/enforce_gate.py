#!/usr/bin/env python3
"""RBIA-FRM enforcement gate (PreToolUse hook).

Reads the hook JSON on stdin. Denies external / irreversible actions unless a valid,
unexpired, HMAC-signed approval token (issued by a human via approve.py) covers the call.
Fail-closed: any parsing or verification problem on a risky call results in DENY.
Every decision is appended to audit-log/enforcement.jsonl.
"""
import fnmatch, hashlib, hmac, json, os, re, sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(os.environ.get("CLAUDE_PLUGIN_ROOT") or Path(__file__).resolve().parent.parent)
APPROVALS = ROOT / "config" / "approvals"
LOG = ROOT / "audit-log" / "enforcement.jsonl"

READ_VERBS = re.compile(r"(^|[_\-.])(read|list|get|search|fetch|query|find|view|describe|show|status|open|check|preview)([_\-.]|$)", re.I)
WRITE_VERBS = re.compile(r"(^|[_\-.])(send|post|create|update|delete|remove|write|pay|payment|approve|submit|publish|reply|schedule|upload|transfer|release|freeze|block|terminate|invite|share|comment|merge|push|set|put|patch|insert|execute|run)([_\-.]|$)", re.I)

PROTECTED = re.compile(r"(config/approvals|scripts/approve\.py|scripts/enforce_gate\.py|hooks/hooks\.json|config/controls\.json|audit-log/)")

# (regex, action) for Bash commands
BASH_RISKS = [
    (r"\b(sendmail|mailx?|mutt|msmtp|swaks)\b", "external_message"),
    (r"\bcurl\b[^\n|;&]*(\s-X\s*(POST|PUT|PATCH|DELETE)|\s--request\s+(POST|PUT|PATCH|DELETE)|\s-d\b|\s--data|\s-F\b|\s--form|\s-T\b|\s--upload-file)", "external_write"),
    (r"\bwget\b[^\n|;&]*(--post-|--method\s*=?\s*(POST|PUT|DELETE))", "external_write"),
    (r"\b(psql|mysql|sqlcmd|sqlite3|mongosh|bq)\b[^\n]*\b(insert|update|delete|drop|alter|truncate|merge)\b", "erp_or_db_write"),
    (r"\bgh\s+(issue|pr|release|repo|gist)\s+(create|comment|merge|edit|close|delete)\b", "external_write"),
    (r"\bgh\s+api\b[^\n]*(-X|--method)\s*(POST|PUT|PATCH|DELETE)", "external_write"),
    (r"\bgit\s+push\b", "external_write"),
    (r"\b(scp|rsync|sftp|ftp|nc|ncat|telnet)\b", "external_transfer"),
    (r"\b(aws|gcloud|gsutil|az)\b[^\n]*\b(put|cp|sync|rm|delete|create|update|send|publish|invoke)\b", "external_write"),
    (r"\brm\s+(-[a-zA-Z]*r[a-zA-Z]*f|-[a-zA-Z]*f[a-zA-Z]*r)\b", "destructive"),
    (r"\b(mkfs|dd\s+if=|shred)\b", "destructive"),
    (r"\bpython3?\b[^\n]*\b(smtplib|requests\.(post|put|patch|delete)|httpx\.(post|put|patch|delete)|urllib\.request|http\.client|socket\.|paramiko|ftplib)", "external_write"),
    (r"\b(node|deno|bun)\b[^\n]*(fetch\(|axios|nodemailer|XMLHttpRequest|http\.request|https\.request|net\.connect)", "external_write"),
    (r"\b(osascript|xdg-open|open)\b[^\n]*mailto:", "external_message"),
]

def now():
    return datetime.now(timezone.utc)

def log(entry):
    try:
        LOG.parent.mkdir(parents=True, exist_ok=True)
        entry["ts"] = now().isoformat()
        with open(LOG, "a") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except Exception:
        pass

def emit(decision, reason, entry):
    entry.update({"decision": decision, "reason": reason})
    log(entry)
    out = {"hookSpecificOutput": {"hookEventName": "PreToolUse",
           "permissionDecision": decision, "permissionDecisionReason": reason}}
    sys.stdout.write(json.dumps(out))
    sys.exit(0)

def canon_sha(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()

def load_key():
    k = os.environ.get("RBIA_APPROVAL_KEY")
    if k:
        return k.encode()
    kf = os.environ.get("RBIA_APPROVAL_KEY_FILE")
    if kf and Path(kf).is_file():
        return Path(kf).read_bytes().strip()
    return None

def sign(token, key):
    body = {k: token[k] for k in sorted(token) if k != "sig"}
    return hmac.new(key, json.dumps(body, sort_keys=True, separators=(",", ":")).encode(), hashlib.sha256).hexdigest()

def valid_token(action, tool_name, tool_input):
    key = load_key()
    if key is None:
        return None, "no approval key configured; approvals cannot be verified (fail closed)"
    if not APPROVALS.is_dir():
        return None, "no approvals directory"
    reasons = []
    for p in sorted(APPROVALS.glob("*.json")):
        try:
            t = json.loads(p.read_text())
            if not hmac.compare_digest(str(t.get("sig", "")), sign(t, key)):
                reasons.append(f"{p.name}: bad signature"); continue
            exp = datetime.fromisoformat(t["expires_utc"])
            if exp.tzinfo is None:
                exp = exp.replace(tzinfo=timezone.utc)
            if exp < now():
                reasons.append(f"{p.name}: expired"); continue
            if t.get("action") not in (action, "*"):
                reasons.append(f"{p.name}: action {t.get('action')} != {action}"); continue
            if not fnmatch.fnmatch(tool_name, t.get("tool_glob", "")):
                reasons.append(f"{p.name}: tool scope mismatch"); continue
            if t.get("input_sha256") and t["input_sha256"] != canon_sha(tool_input):
                reasons.append(f"{p.name}: draft/input hash mismatch (content changed after approval)"); continue
            return t, "ok"
        except Exception as e:
            reasons.append(f"{p.name}: unreadable ({e.__class__.__name__})")
    return None, "; ".join(reasons) or "no approval token present"

def classify(tool_name, tool_input):
    """Return (action, detail) for risky calls, else (None, '')."""
    text = json.dumps(tool_input, ensure_ascii=False)
    # 1. attempts to touch the control plane
    if tool_name in ("Write", "Edit", "NotebookEdit", "MultiEdit"):
        target = str(tool_input.get("file_path", ""))
        if PROTECTED.search(target):
            return "tamper_control_plane", target
    if tool_name == "Bash":
        cmd = str(tool_input.get("command", ""))
        if PROTECTED.search(cmd) and not re.match(r"\s*(cat|ls|head|tail|grep|python3?\s+-m?\s*json\.tool)\b", cmd):
            return "tamper_control_plane", cmd[:200]
        if re.search(r"RBIA_APPROVAL_KEY", cmd):
            return "tamper_control_plane", "approval key access"
        for rx, action in BASH_RISKS:
            if re.search(rx, cmd, re.I):
                return action, cmd[:200]
        return None, ""
    if tool_name.startswith("mcp__"):
        short = tool_name.split("__", 2)[-1]
        if READ_VERBS.search(short) and not WRITE_VERBS.search(short):
            return None, ""
        if WRITE_VERBS.search(short):
            return "external_write", tool_name
        return "external_write", tool_name + " (unclassified: deny by default)"
    if tool_name in ("SendMessage", "PushNotification"):
        return "external_message", tool_name
    if tool_name in ("Artifact",):
        if str(tool_input.get("action", "publish")) in ("publish", "delete") and "url" in tool_input and tool_input.get("action") == "delete":
            return "external_write", "artifact delete"
        return None, ""
    return None, ""

def main():
    try:
        data = json.load(sys.stdin)
        tool_name = str(data.get("tool_name", ""))
        tool_input = data.get("tool_input") or {}
    except Exception as e:
        emit("deny", f"enforcement gate could not parse the tool call ({e.__class__.__name__}); failing closed", {"tool": "?"})
    action, detail = classify(tool_name, tool_input)
    entry = {"tool": tool_name, "action": action, "detail": detail}
    if action is None:
        entry.update({"decision": "allow", "reason": "not a red-line action"})
        log(entry)
        sys.exit(0)   # silent allow
    if action == "tamper_control_plane":
        emit("deny", "RBIA enforcement: the control plane (approvals, gate, hooks, controls, audit log, approval key) cannot be modified or read for signing by the agent. Ask the human to do this.", entry)
    tok, why = valid_token(action, tool_name, tool_input)
    if tok:
        entry["approver"] = tok.get("approver")
        emit("allow", f"approved by {tok.get('approver')} (action={action}, expires {tok.get('expires_utc')})", entry)
    emit("deny", f"RBIA enforcement: '{action}' is a red-line action and needs a valid human approval token ({why}). Do not retry or work around it. Present the Context / Recommendation / Cost-benefit / Risk of inaction / APPROVE-MODIFY-ABORT-ESCALATE gate and ask the human to run scripts/approve.py.", entry)

if __name__ == "__main__":
    main()
