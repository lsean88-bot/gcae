#!/usr/bin/env python3
"""Tests fraud_analytics.py against the pilot dataset (planted findings) and synthetic Benford populations.
Run: python3 -I scripts/test_analytics.py   (exit 0 = all pass)"""
import csv, json, math, pathlib, random, subprocess, sys, tempfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
TOOL = str(ROOT / "scripts" / "fraud_analytics.py")
D = ROOT / "skills" / "rbia-frm-mastermind" / "evals" / "pilot-simulation" / "data"
res = []


def run(*args):
    r = subprocess.run([sys.executable, "-I", TOOL, *args], capture_output=True, text=True)
    if r.returncode != 0:
        return {"_error": r.stderr.strip()}
    return json.loads(r.stdout)


def t(name, cond, detail=""):
    res.append(cond)
    print(("PASS " if cond else "FAIL ") + name + (f"  [{detail}]" if detail else ""))


f = lambda n: str(D / n)

# 1 duplicate payment of one invoice
r = run("duplicates", "--file", f("payments.csv"), "--key", "Invoice_No", "--amount", "Amount_INR")
ex = [e for e in r["exceptions"] if e["key"]["Invoice_No"] == "SKH-INV-202511"]
t("duplicates: finds invoice paid twice", len(ex) == 1 and abs(ex[0]["repeat_value_potentially_duplicated"] - 373583) < 1, str(ex[:1]))
# 2 missing GRN
r = run("blanks", "--file", f("tolling_invoices.csv"), "--col", "GRN_No", "--amount", "Amount_INR")
t("blanks: invoice without GRN", r["exception_count"] == 1 and abs(r["total_amount"] - 410560) < 1, f"{r['exception_count']} {r['total_amount']}")
# 3 Benford refuses fixed-rate invoices
r = run("benford", "--file", f("tolling_invoices.csv"), "--col", "Amount_INR")
t("benford: NOT_APPLICABLE on 12 fixed-rate invoices, no p-value", r["status"] == "NOT_APPLICABLE" and "p_value" not in r, "; ".join(r.get("reasons", [])))
# 4 SoD: bank change then same user releases payment within 30 days
r = run("sod", "--a-file", f("vendor_master_changes.csv"), "--a-key", "Vendor", "--a-actor", "Changed_By", "--a-date", "Changed_On",
        "--b-file", f("payments.csv"), "--b-key", "Vendor", "--b-actor", "Released_By", "--b-date", "Paid_On", "--days", "30")
t("sod: same user changed bank and released payment", r["exception_count"] >= 1 and set(r["by_actor"]) == {"AP02"}, str(r["by_actor"]))
# 5 SoD: vendor creator also releases payments
r = run("sod", "--a-file", f("vendor_master.csv"), "--a-key", "Vendor_ID", "--a-actor", "Created_By",
        "--b-file", f("payments.csv"), "--b-key", "Vendor", "--b-actor", "Released_By")
t("sod: vendor creator also releases payments", r["exception_count"] > 0 and "AP01" in r["by_actor"], str(r["by_actor"]))
# 6 JE: self-approved, no support
r = run("je", "--file", f("journal_entries.csv"), "--prepared", "Prepared_By", "--approved", "Approved_By", "--support", "Support_Ref",
        "--narr", "Narration", "--amount", "Debit_INR", "--date", "Date")
fs = r["flag_summary(not additive)"]
t("je: 3 self-approved entries totalling 2.1M", fs["self_approved"]["count"] == 3 and fs["self_approved"]["amount_sum"] == 2100000, str(fs.get("self_approved")))
t("je: 3 entries with no support reference", fs["no_support_ref"]["count"] == 3)
# 7 rate variance vs contract
r = run("ratevar", "--inv-file", f("tolling_invoices.csv"), "--party", "Vendor", "--rate", "Rate_INR_per_KG", "--qty", "Qty_KG",
        "--contract-file", f("contract_price_list.csv"), "--c-party", "Vendor", "--c-rate", "Rate_INR_per_KG")
t("ratevar: 7 invoices, variance 235,886", r["exception_count"] == 7 and abs(r["net_variance_vs_contract"] - 235886) < 1, str(r["net_variance_vs_contract"]))
# 8 recon: scrap posted vs weighbridge
r = run("recon", "--a-file", f("scrap_postings.csv"), "--b-file", f("weighbridge_scrap.csv"), "--keys", "Month,Parent",
        "--a-val", "Posted_Scrap_KG", "--b-val", "Weighbridge_KG")
parents = {e["key"][1] for e in r["exceptions"]}
t("recon: only P-1003 exceeds tolerance, net gap 65,107 kg", parents == {"P-1003"} and abs(r["net_difference_over_exceptions"] - 65107) < 1,
  f"{parents} {r['net_difference_over_exceptions']}")
# 9 payments to account not on vendor master
r = run("overlap", "--a-file", f("payments.csv"), "--a-col", "Bank_Account", "--b-file", f("vendor_master.csv"), "--b-col", "Bank_Account", "--unmatched")
t("overlap: payment to bank account not on vendor master", {e["a_value"] for e in r["exceptions"]} == {"XXXX9999"} and len(r["exceptions"]) == 2, str(r["exceptions"][:2]))
# 10 calendar: Saturday payment after bank change
r = run("calendar", "--file", f("payments.csv"), "--date", "Paid_On", "--amount", "Amount_INR")
t("calendar: PAY-5199 date flagged as weekend", any("2026-02-28" in e["date"] for e in r["exceptions"]))
# 11 profile
r = run("profile", "--file", f("payments.csv"))
t("profile: row count and hashes reported", r["population"]["rows"] > 12 and len(list(r["files"].values())[0]) == 64)
# 12 sequence
r = run("sequence", "--file", f("payments.csv"), "--col", "Payment_No")
t("sequence: runs and reports gap ranges", r["status"] == "OK" and r["exception_count"] >= 1)

# 13-15 synthetic: Benford conforming / manipulated / narrow
random.seed(7)
tmp = pathlib.Path(tempfile.mkdtemp(prefix="rbia_an_"))


def write(name, vals):
    p = tmp / name
    with open(p, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["amt"])
        for v in vals:
            w.writerow([round(v, 2)])
    return str(p)


good = [10 ** random.uniform(1, 5) for _ in range(3000)]
r = run("benford", "--file", write("good.csv", good), "--col", "amt")
t("benford: natural population conforms", r["status"] == "OK" and r["MAD"] < 0.006 and r["p_value"] > 0.01, f"MAD={r.get('MAD')} p={r.get('p_value')}")
bad = good[:2100] + [random.uniform(450, 499) for _ in range(900)]
r = run("benford", "--file", write("bad.csv", bad), "--col", "amt")
t("benford: planted manipulation detected", r["status"] == "OK" and r["mad_conformity_nigrini"] == "NONCONFORMITY" and r["p_value"] < 0.001, f"MAD={r.get('MAD')}")
narrow = [random.uniform(300, 480) for _ in range(500)]
r = run("benford", "--file", write("narrow.csv", narrow), "--col", "amt")
t("benford: narrow-range population refused", r["status"] == "NOT_APPLICABLE")

# 16-17 splits, round, near-duplicates
p = tmp / "tx.csv"
with open(p, "w", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["vendor", "amount", "date"])
    for row in [["A", 9000, "2026-01-02"], ["A", 8500, "2026-01-04"], ["B", 9500, "2026-01-02"], ["B", 9500, "2026-02-20"],
                ["C", 10000, "2026-01-05"], ["C", 20000, "2026-01-06"]] + [["D", 1000 * (i + 1), "2026-01-0" + str(i % 9 + 1)] for i in range(40)]:
        w.writerow(row)
r = run("splits", "--file", str(p), "--party", "vendor", "--amount", "amount", "--date", "date", "--threshold", "10000", "--days", "7")
flagged = {e["party"] for e in r["exceptions"]}
t("splits: A flagged (17,500 in 2 days); B (50 days apart) and C (not below threshold) not flagged",
  "A" in flagged and "B" not in flagged and "C" not in flagged, str(sorted(flagged)))
r = run("round", "--file", str(p), "--amount", "amount")
t("round: concentration flagged", r["flagged_base"] == 1000, str(r["shares"]))
r = run("duplicates", "--file", str(p), "--key", "vendor,date", "--amount", "amount", "--party", "vendor", "--date", "date", "--tol-pct", "0", "--days", "3")
t("duplicates: near-duplicate (same vendor, amount, within 3 days) found", any(e["type"] == "near_duplicate" for e in r["exceptions"]) or r["exception_count"] >= 1)

# 18 bad column fails loudly
rr = subprocess.run([sys.executable, "-I", TOOL, "blanks", "--file", f("payments.csv"), "--col", "NoSuchCol"], capture_output=True, text=True)
t("bad column name fails loudly with available columns", rr.returncode != 0 and "Available columns" in rr.stderr)

# 19-26 regression: edge cases found in independent CFE review
tmp = pathlib.Path(tempfile.mkdtemp())
def w(name, text):
    p = tmp / name
    p.write_text(text, encoding="utf-8")
    return str(p)
a1 = w("chg.csv", "Vendor,User,At\nV1,AP02,2026-03-01 17:52:00\n")
b1 = w("pay.csv", "Vendor,User,Paid\nV1,AP02,2026-03-01\nV9,AP02,notadate\n")
r = run("sod", "--a-file", a1, "--a-key", "Vendor", "--a-actor", "User", "--a-date", "At",
        "--b-file", b1, "--b-key", "Vendor", "--b-actor", "User", "--b-date", "Paid", "--days", "3")
t("sod: same-day change-then-pay (timestamp vs date-only) is flagged", len(r["exceptions"]) == 1, str(r["exceptions"]))
cn1 = w("cn1.csv", "Vendor,Amt\n\u6797\u6c0f\u8d38\u6613,100\n")
cn2 = w("cn2.csv", "Vendor,Amt\n\u6797\u6c0f\u8d38\u6613,100\n")
r = run("overlap", "--a-file", cn1, "--a-col", "Vendor", "--b-file", cn2, "--b-col", "Vendor")
t("overlap: non-Latin names match", r["exception_count"] == 1, str(r.get("exceptions")))
z1 = w("z1.csv", "K,V\nA,0\nB,10\n"); z2 = w("z2.csv", "K,V\nA,0\nB,10\n")
r = run("recon", "--a-file", z1, "--b-file", z2, "--keys", "K", "--a-val", "V", "--b-val", "V", "--tol-pct", "0")
t("recon: 0 vs 0 and equal values not flagged", r["exception_count"] == 0, str(r["exceptions"]))
sh = w("short.csv", 'ID,Amt,Note\n1,5\n2,6,"multi\nline"\n3,7,x\n')
r = run("blanks", "--file", sh, "--col", "Note")
rows = sorted(e["row"] for e in r["exceptions"])
t("blanks: short row counted blank and multi-line row numbering correct", rows == [2], str(rows))
r = run("profile", "--file", sh)
t("profile: reports rows with wrong field count", r["input_quality"]["read"][sh]["rows_with_wrong_field_count"] == 1)
sq = w("seq.csv", "Inv\nSKH-INV-202512\nSKH-INV-202601\nSKH-INV-202602\n")
r = run("sequence", "--file", sq, "--col", "Inv")
t("sequence: period-coded numbers produce no false gap", r["exception_count"] == 0, str(r["exceptions"]))
r = run("recon", "--a-file", z1, "--b-file", z2, "--keys", "K", "--a-val", "V", "--b-val", "V")
t("defaults used are disclosed", any("tol_pct" in d for d in r["defaults_used_CONFIRM_WITH_USER"]) and bool(r["script_sha256"]))

# 27+ new tests (v2.4.0)
po = w("po.csv", "PO,Amt\nP1,100\nP2,200\n")
grn = w("grn.csv", "PO\nP1\n")
inv = w("inv.csv", "PO,Amt\nP1,100\nP2,200\nP9,50\n,70\nP1,130\n")
r = run("match3", "--po-file", po, "--po-key", "PO", "--po-amount", "Amt", "--grn-file", grn, "--grn-key", "PO",
        "--inv-file", inv, "--inv-po-key", "PO", "--inv-amount", "Amt")
iss = {e["row"]: set(e["issues"]) for e in r["exceptions"]}
t("match3: no-GRN, unknown PO, missing PO ref, over-PO flagged; clean row not",
  3 in iss and "no_goods_receipt" in iss[3] and "po_not_in_po_file" in iss[4] and "invoice_has_no_po_reference" in iss[5] and any(i.startswith("invoice_exceeds_po") for i in iss[6]) and 2 not in iss, str(iss))
va = w("va.csv", "Vendor,Created\nV1,2026-03-10\n")
vb = w("vb.csv", "Vendor,Paid,Amt\nV1,2026-03-01,500\nV1,2026-03-12,10\n")
r = run("datecheck", "--a-file", va, "--a-key", "Vendor", "--a-date", "Created", "--b-file", vb, "--b-key", "Vendor", "--b-date", "Paid", "--b-amount", "Amt")
t("datecheck: payment before vendor creation flagged (only the early one)", r["exception_count"] == 1 and r["exceptions"][0]["b_earlier_by_days"] == 9, str(r["exceptions"]))
dm = w("dm.csv", "Vendor,Date,Amt\nV1,2025-01-05,10\nV1,2025-01-20,10\nV1,2026-02-01,900\nV2,2026-01-01,5\nV2,2026-02-01,5\n")
r = run("dormant", "--file", dm, "--party", "Vendor", "--date", "Date", "--amount", "Amt", "--dormant-days", "180")
t("dormant: V1 reactivation flagged, V2 not", [e["party"] for e in r["exceptions"]] == ["V1"], str(r["exceptions"]))
sh2 = w("sh.csv", "Emp,Bank\nE1,1234\nE2,1234\nE3,9999\nE1,1234\n")
r = run("shared", "--file", sh2, "--key", "Bank", "--id", "Emp")
t("shared: one bank account shared by two employees (repeat of same employee ignored)", r["exception_count"] == 1 and r["exceptions"][0]["distinct_ids"] == 2)
ol = w("ol.csv", "Grp,Amt\n" + "".join(f"A,{v}\n" for v in [100,102,98,101,99,100,103,97]) + "A,5000\n")
r = run("outlier", "--file", ol, "--amount", "Amt", "--group", "Grp")
t("outlier: only the 5000 value flagged", [e["value"] for e in r["exceptions"]] == [5000.0], str(r["exceptions"]))
cc = w("cc.csv", "V,Amt\nA,900\nB,50\nC,50\n")
r = run("concentration", "--file", cc, "--party", "V", "--amount", "Amt")
t("concentration: top vendor 90% and HHI 8150", r["exceptions"][0]["share_pct"] == 90.0 and r["HHI_0_to_10000"] == 8150, str(r.get("HHI_0_to_10000")))
random.seed(7)
nat = w("nat.csv", "Amt\n" + "".join(f"{math.exp(random.uniform(math.log(10), math.log(9e6))):.2f}\n" for _ in range(3000)))
r = run("benford", "--file", nat, "--col", "Amt", "--digits", "2")
t("benford first-two: runs on a log-uniform population (n=3000) with a label", "mad_conformity_nigrini_ft2" in r, str(r.get("mad_conformity_nigrini_ft2")))
r = run("benford", "--file", nat, "--col", "Amt", "--digits", "2", "--min-n", "300")
rows49 = "".join(f"{random.choice([49,49,49,99,99,48,98])}{random.randint(100,9999)}.00\n" for _ in range(1500)) + "".join(f"{random.randint(10,99)}{random.randint(1000,99999)}.00\n" for _ in range(1500))
mn = w("mn.csv", "Amt\n" + rows49)
r = run("benford", "--file", mn, "--col", "Amt", "--digits", "2")
t("benford first-two: threshold-hugging spike detected", r.get("mad_conformity_nigrini_ft2") == "NONCONFORMITY", str(r.get("mad_conformity_nigrini_ft2")))
lc = w("lc.csv", 'Amt\n"1.234,56"\n"INR 2.000,00"\n"100-"\n')
r = run("profile", "--file", lc, "--decimal-comma")
t("locale: decimal comma parsed (sum 3,134.56)", abs(r["columns"]["Amt"].get("sum", 0) - 3134.56) < 0.01, str(r["columns"]["Amt"]))
dd = w("dd.csv", "D\n04/13/2026\n03/04/2026\n")
r = run("profile", "--file", dd, "--date-order", "mdy")
t("date order mdy: US-style date parsed and ambiguity counted", r["columns"]["D"].get("date") is True and any("ambiguous" in k for k in r["input_quality"]["unparsed_values"]), str(r["input_quality"]))
ct = w("ct.csv", "Vendor,Service,From,To,Rate\nV1,A,2026-01-01,2026-03-31,10\nV1,A,2026-04-01,,12\nV1,B,2026-01-01,,50\n")
iv = w("iv.csv", "Vendor,Service,Date,Rate,Qty\nV1,A,2026-02-01,10,5\nV1,A,2026-05-01,12,5\nV1,A,2026-05-02,10,5\nV1,B,2026-02-01,50,1\nV2,A,2026-02-01,9,1\n")
r = run("ratevar", "--inv-file", iv, "--party", "Vendor", "--rate", "Rate", "--qty", "Qty", "--inv-date", "Date", "--inv-service", "Service",
        "--contract-file", ct, "--c-party", "Vendor", "--c-rate", "Rate", "--c-from", "From", "--c-to", "To", "--c-service", "Service")
t("ratevar: effective-date aware (only row 4 is under-rate; V2 has no contract)", r["exception_count"] == 1 and r["undercharge_total"] == -10.0 and r["no_contract_count"] == 1, str(r["exceptions"]))
cr = w("cr.csv", "ID,By,App,Ref,Narr,Debit,Credit,Date\n1,u1,u2,R,plugin install,0,50000,2026-03-31\n2,u1,u2,R,plug the gap,10000,0,2026-03-15\n")
r = run("je", "--file", cr, "--prepared", "By", "--approved", "App", "--support", "Ref", "--narr", "Narr", "--amount", "Debit", "--credit", "Credit", "--date", "Date", "--period-end-days", "2", "--min-flags", "1")
fl = {e["row"]: set(e["flags"]) for e in r["exceptions"]}
t("je: credit-only entry round-tested, period-end flagged, 'plugin' not a keyword hit, 'plug' is", "round_amount" in fl[2] and "period_end" in fl[2] and "adjustment_keyword" not in fl[2] and "adjustment_keyword" in fl[3], str(fl))

# v2.4.0 adversarial-review regressions
jj = w("jj.csv", "By,App,Ref,Narr,Amt,Date\nu1,u2,R,Year-end adjustment,1,2026-03-10\nu1,u2,R,reclassification of cost,1,2026-03-10\nu1,u2,R,plugin install,1,2026-03-10\n")
r = run("je", "--file", jj, "--prepared", "By", "--approved", "App", "--support", "Ref", "--narr", "Narr", "--amount", "Amt", "--date", "Date", "--min-flags", "1")
fl = {e["row"]: e["flags"] for e in r["exceptions"]}
t("je: inflected keywords (adjustment, reclassification) hit; 'plugin' not", "adjustment_keyword" in fl.get(2, []) and "adjustment_keyword" in fl.get(3, []) and "adjustment_keyword" not in fl.get(4, []), str(fl))
c2 = w("c2.csv", "V,From,To,Rate\nV1,2026-01-01,2026-03-31,10\n")
i2 = w("i2.csv", "V,Date,Rate,Qty\nV1,2026-03-31 14:00,12,10\n")
r = run("ratevar", "--inv-file", i2, "--party", "V", "--rate", "Rate", "--qty", "Qty", "--inv-date", "Date", "--contract-file", c2, "--c-party", "V", "--c-rate", "Rate", "--c-from", "From", "--c-to", "To")
t("ratevar: invoice on contract end date (with time) still covered", r["exception_count"] == 1 and r["net_variance_vs_contract"] == 20.0, str(r["exceptions"]))
p3 = w("p3.csv", "PO,Amt\nP1,100\n,50\nP1,999\n"); g3 = w("g3.csv", "PO\nP1\n"); v3 = w("v3.csv", "PO,Amt\nP1,150\n,70\n")
r = run("match3", "--po-file", p3, "--po-key", "PO", "--po-amount", "Amt", "--grn-file", g3, "--grn-key", "PO", "--inv-file", v3, "--inv-po-key", "PO", "--inv-amount", "Amt")
iss = {e["row"]: e["issues"] for e in r["exceptions"]}
t("match3: duplicate PO flagged; blank invoice ref only 'no PO reference'", "po_number_duplicated_in_po_file" in iss[2] and iss[3] == ["invoice_has_no_po_reference"], str(iss))
cur = w("cur.csv", 'Amt\n"Rs.1,000"\n"Rs. 1,000"\n"(RM 100)"\n"-RM100"\n')
r = run("profile", "--file", cur)
t("num: Rs./RM prefixes parsed (1000+1000-100-100=1800)", abs(r["columns"]["Amt"].get("sum", 0) - 1800) < 0.01, str(r["columns"]["Amt"]))
sq6 = w("sq6.csv", "Inv\n200001\n200002\n200005\n")
r = run("sequence", "--file", sq6, "--col", "Inv")
t("sequence: plain 6-digit numbers still gap-checked, with row references", r["exception_count"] == 1 and r["exceptions"][0]["gap_ranges"][0][:2] == [200003, 200004] and "after_row" in r["exceptions"][0]["gap_ranges"][0][2], str(r["exceptions"]))
r = run("match3", "--po-file", po, "--po-key", "PO", "--po-amount", "Amt", "--grn-file", grn, "--grn-key", "PO", "--inv-file", inv, "--inv-po-key", "PO", "--inv-amount", "Amt")
t("defaults: zero-valued default (tol_pct 0.0) is disclosed", any("tol_pct" in d for d in r["defaults_used_CONFIRM_WITH_USER"]), str(r["defaults_used_CONFIRM_WITH_USER"]))
r = run("outlier", "--file", ol, "--amount", "Amt", "--group", "Grp", "--z=3")
t("defaults: --opt=value form counts as supplied", not any("z" in d for d in r["defaults_used_CONFIRM_WITH_USER"]), str(r["defaults_used_CONFIRM_WITH_USER"]))
rr = subprocess.run([sys.executable, "-I", TOOL, "dormant", "--file", dm, "--party", "Vendor", "--date", "Date", "--amount", "Nope", "--dormant-days", "10"], capture_output=True, text=True)
t("dormant: bad optional column fails cleanly (no traceback)", rr.returncode != 0 and "Traceback" not in rr.stderr and "not found" in rr.stderr)
da = w("da.csv", "V,D\nV2,garbage\n"); db = w("db.csv", "V,D\nV2,2026-01-01\n")
r = run("datecheck", "--a-file", da, "--a-key", "V", "--a-date", "D", "--b-file", db, "--b-key", "V", "--b-date", "D")
t("datecheck: unparseable A date reported as such, not 'not found'", r["exceptions"][0]["issue"] == "a_date_unparsed", str(r["exceptions"]))
cz = w("cz.csv", "P,Amt\nA,100\nA,-100\nacme sdn bhd,10\nACME SDN BHD,10\n,5\n")
r = run("concentration", "--file", cz, "--party", "P", "--amount", "Amt")
t("concentration: zero-net ok, names merged, blank party skipped", r["population"]["parties"] == 2 and r["input_quality"]["rows_skipped"].get("blank_party_rows") == 1, str(r["population"]))
bd = w("bd.csv", "V,Date,Amt\n,2025-01-01,5\n,2026-01-01,5\n")
r = run("dormant", "--file", bd, "--party", "V", "--date", "Date", "--amount", "Amt", "--dormant-days", "100")
t("dormant: blank parties not pooled", r["exception_count"] == 0 and r["input_quality"]["rows_skipped"].get("blank_party_rows") == 2, str(r["input_quality"]))
em = w("em.csv", "\nA,B\n1,2\n")
rr = subprocess.run([sys.executable, "-I", TOOL, "profile", "--file", em], capture_output=True, text=True)
t("empty/leading-blank header fails loudly", rr.returncode != 0 and "no header" in rr.stderr)
c3 = w("c3.csv", "V,From,To,Rate\nV1,2026-01-01,garbage,10\n")
i3 = w("i3.csv", "V,Date,Rate,Qty\nV1,2026-02-01,12,1\n")
r = run("ratevar", "--inv-file", i3, "--party", "V", "--rate", "Rate", "--qty", "Qty", "--inv-date", "Date", "--contract-file", c3, "--c-party", "V", "--c-rate", "Rate", "--c-from", "From", "--c-to", "To")
t("ratevar: contract row with unparseable end date excluded and counted", r["input_quality"]["rows_skipped"].get("contract_rows_excluded_unparseable_dates") == 1 and r["no_contract_count"] == 1, str(r["input_quality"]))

# v2.5.0 use-case (payroll) regression
U = str(ROOT / "skills" / "rbia-frm-mastermind" / "evals" / "usecase-payroll")
r = run("unsupported", "--a-file", U + "/payroll.csv", "--b-file", U + "/attendance.csv", "--keys", "Month,Emp_ID", "--a-val", "Basic", "--b-val", "Days_Present", "--entity", "Emp_ID", "--amount", "Basic")
t("usecase ghost: E999 paid 5 months with zero attendance (16,000)", [(e["entity"], e["periods_unsupported"], e["unsupported_amount"]) for e in r["exceptions"]] == [("E999", 5, 16000.0)], str(r["exceptions"]))
r = run("unsupported", "--a-file", U + "/payroll.csv", "--b-file", U + "/attendance.csv", "--keys", "Month,Emp_ID", "--a-val", "OT_Pay", "--b-val", "OT_Hours_Clocked", "--entity", "Emp_ID")
t("usecase OT: E050 claims OT never clocked", any(e["entity"] == "E050" and e["periods_unsupported"] == 5 for e in r["exceptions"]), str(r["exceptions"][:3]))
r = run("datecheck", "--a-file", U + "/hr_master.csv", "--a-key", "Emp_ID", "--a-date", "Resign", "--b-file", U + "/payroll.csv", "--b-key", "Emp_ID", "--b-date", "PayDate", "--mode", "b-after-a")
t("usecase resign: E011 paid after resignation 3 times; blank resign dates are not noise", sum(1 for e in r["exceptions"] if e["key"] == "E011" and e.get("b_later_by_days")) == 3 and r["exception_count"] < 20, str(r["exception_count"]))
r = run("outlier", "--file", U + "/payroll.csv", "--amount", "OT_Hours", "--group", "Month", "--entity", "Emp_ID")
t("usecase OT outlier: E030 repeats in 5 periods (entity roll-up)", r["by_entity_repeat_outliers"][0]["entity"] == "E030" and r["by_entity_repeat_outliers"][0]["periods"] == 5)
r = run("recon", "--a-file", U + "/payroll.csv", "--b-file", U + "/attendance.csv", "--keys", "Month,Emp_ID", "--a-val", "OT_Hours", "--b-val", "OT_Hours_Clocked", "--tol-pct", "0", "--direction", "a-gt-b")
t("recon --direction a-gt-b reports only over-claims", all(e["status"] != "DIFF" or e["diff"] > 0 for e in r["exceptions"]) and r["a_less_than_b_total"] == 0)

lg = str(tmp / "run.jsonl")
run("shared", "--file", sh2, "--key", "Bank", "--id", "Emp", "--log", lg)
run("shared", "--file", sh2, "--key", "Bank", "--id", "Emp", "--log", lg)
lines = [json.loads(x) for x in open(lg)]
t("--log appends one reproducibility record per run", len(lines) == 2 and lines[0]["script_sha256"] and lines[0]["exception_count"] == 1)
# v2.5.0 friction fixes
r = run("shared", "--file", sh2, "--key", "Bank", "--id", "Emp")
t("shared: shows ids and original case", r["exceptions"][0]["ids"] == ["E1", "E2"] and r["exceptions"][0]["shared_value"] == "1234", str(r["exceptions"]))
r = run("profile", "--file", U + "/hr_master.csv")
t("profile: text columns no longer inflate unparsed counters; per-column parse rates given", "numeric" not in r["input_quality"]["unparsed_values"] and "numeric_parse_rate" in r["columns"]["Basic"])
r = run("unsupported", "--a-file", U + "/payroll.csv", "--b-file", U + "/attendance.csv", "--keys", "Month,Emp_ID", "--a-val", "OT_Pay", "--b-val", "OT_Hours_Clocked", "--entity", "Emp_ID", "--exclude", "Emp_ID=E050")
t("--exclude removes already-flagged entities and counts them", not any(e["entity"] == "E050" for e in r["exceptions"]) and r["input_quality"]["rows_skipped"].get("excluded_Emp_ID") == 10, str(r["input_quality"]["rows_skipped"]))
r = run("datecheck", "--a-file", U + "/hr_master.csv", "--a-key", "Emp_ID", "--a-date", "Resign", "--b-file", U + "/payroll.csv", "--b-key", "Emp_ID", "--b-date", "PayDate", "--b-amount", "Basic", "--mode", "b-after-a")
t("datecheck: counts_by_issue separates violations from not-found; amount by key given", r["counts_by_issue"].get("date_violation") == 3 and r["counts_by_issue"].get("key_not_found_in_A") == 5 and r["amount_flagged_by_key(not additive across tests)"].get("E011") == sum(x["amount"] for x in r["exceptions"] if x["key"] == "E011" and x.get("amount")), str(r["counts_by_issue"]))
qq = subprocess.run([sys.executable, "-I", TOOL, "shared", "--file", sh2, "--key", "Bank", "--id", "Emp", "--out", str(tmp / "q.json"), "--quiet"], capture_output=True, text=True)
t("--quiet prints one line and writes the file", len(qq.stdout.strip().splitlines()) == 1 and (tmp / "q.json").exists())
n = sum(res)
print(f"\n{n}/{len(res)} passed")
sys.exit(0 if n == len(res) else 1)
