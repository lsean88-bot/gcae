# Decision Log and Information Gap Register (engagement template)
Engagement ID: | Entity: | Period: | Currency: | Jurisdiction (COUNTRY KNOWN, LAW NOT VERIFIED / VERIFIED by counsel on date): 
Materiality: overall | performance | clearly trivial | basis and date set | set by:
Mandate / privilege: | Distribution: | Red lines: | Sensitivities:
## Decisions
| # | Date | Decision | Options considered | Decided by | Basis / evidence ref | Model and effort used, trigger |
## Information gaps
| # | Item requested | Why needed | Requested from | Date | Due | Status | Effect on conclusions while open |
## Run log
Tool runs are recorded in `runlog.jsonl` (use `--log runlog.jsonl`): it is the evidence appendix to this log.
