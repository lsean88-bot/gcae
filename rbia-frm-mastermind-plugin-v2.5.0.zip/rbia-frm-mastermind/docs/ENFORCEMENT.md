# Enforcement guide (RBIA-FRM Mastermind v2.2.0)

## What is enforced, and where
| Layer | Control | Strength |
|---|---|---|
| Claude Code host | hooks/hooks.json runs scripts/enforce_gate.py before every tool call; red-line actions are denied without a valid signed approval token | Strong for this host, fail-closed |
| Token | HMAC-signed, expires within 24h, scoped to action + tool, optionally bound to the exact tool input (editing a draft after approval invalidates it) | Strong |
| Control plane | The agent cannot edit approvals, gate, hooks, controls or audit log, run approve.py, or read the signing key via tools | Strong, best-effort pattern match |
| Audit trail | audit-log/enforcement.jsonl records every allow/deny | Detective |
| Instructions | SKILL.md sections 0, 6A, 9B | Soft; relies on the model |

## One-time setup (human)
1. Generate a secret outside the agent's reach (not in the project folder): `openssl rand -hex 32 > ~/.rbia_key; chmod 600 ~/.rbia_key`.
2. Make it available to the HOOK process but not to agent shells where possible: set RBIA_APPROVAL_KEY_FILE=~/.rbia_key in the environment of the Claude Code process, or in a managed settings env. If the agent shell inherits it, a blocked Bash env read still protects the value, but treat the key as sensitive and rotate it if in doubt.
3. Run `python3 scripts/test_gate_unit.py` and `python3 scripts/test_gate_e2e.py` (both must pass) after any change.

## Approving an action (human only, own terminal)
`python3 scripts/approve.py --action external_write --tool-glob "mcp__gmail__send_email" --approver "<name>" --hours 2 --input-file exact_call.json`
Use --input-file so the approval covers that exact draft only. Revoke by deleting the token file.

## Limits you must know
- Hooks protect Claude Code sessions with this plugin loaded. They do not govern claude.ai chat, other clients, or people using systems directly.
- Shell classification is pattern-based. A determined bypass (obfuscated command, unknown tool) can slip through; unknown mcp__ write-like tools are denied by default, unknown Bash is not.
- ERP, banking and e-mail systems must still enforce segregation of duties, dual approval and payment limits themselves. This is the real preventive control; the plugin is a safety net on the AI side.
- Review audit-log/enforcement.jsonl at least weekly (a Second Line task) and after every engagement.
