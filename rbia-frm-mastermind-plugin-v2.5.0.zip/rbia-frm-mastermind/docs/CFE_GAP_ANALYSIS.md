# CFE Gap Analysis and Roadmap (v2.5.0)

Scope: what a professional Certified Fraud Examiner performs versus what this plugin covers, per area requested by the GCAE. Basis: an independent CFE-lens review of v2.2.0 content and the analytics toolkit, plus the pilot simulation. Evidence limits: synthetic data only, single runs, no real-case back-testing.

Status key: COVERED (works now) / PARTIAL / DRAFT (plugin drafts, human decides) / HUMAN (only a qualified person may do it) / EXTERNAL (needs data or systems not in the plugin).

## 1. Fraud audit skill (method)
| CFE activity | Status | Note / next step |
|---|---|---|
| Context-first triage, no fraud conclusion from one anomaly | COVERED | Class A-D, 3 independent evidence types (house rule, not an ACFE standard) |
| Predication and scheme mapping as hypotheses | COVERED | /audit-fraud-assess, agent cfe-investigator |
| Fraud-theory cycle with ACH matrix | COVERED (reference 12.1) | |
| Behavioural red flags, fraud triangle/diamond | COVERED as context only (reference 12.8) | Indicators are never evidence |
| Intake, case log, investigator conflict check, closure criteria | COVERED (reference 12.2) | |
| Management implicated: route to Audit Committee chair | COVERED (v2.4.0) | Reference 10 section 7 |
| Interviews, accusations, credibility, termination, police referral | HUMAN | Plugin drafts plans only |

## 2. Knowledge
| Item | Status | Next step |
|---|---|---|
| MO library (~30 schemes, 5 families) | PARTIAL | Covers a subset of the ACFE tree; missing branches now disclosed. Add register disbursements, false refunds/voids, cash on hand, false sales/shipping, customer-side, healthcare billing (M) |
| Per-jurisdiction legal map | PARTIAL | Reference 13 is a question checklist for counsel with NO legal content by design; counsel-supplied answers are still needed per engagement (EXTERNAL) |
| Recovery cautions (set-off, settlement, tipping-off) | COVERED (v2.4.0) | Reference 10 |
| Overlap with group skills (cae-fraud-investigation, group-cae-fraud, grc-agentic-fleet) | RISK | Portfolio duplication. Decide a single owner for MO knowledge and cross-reference rather than copy |

## 3. Fieldwork engine
| Item | Status | Next step |
|---|---|---|
| Evidence hierarchy, preservation checklist, chain of custody | COVERED (reference 12.3) | Retention periods are the client's, to be filled per source |
| Document pack and interview plan drafts | DRAFT (reference 12.4) | Counsel decides wording |
| Digital forensics: imaging, write-block, hashing, eDiscovery, privilege screen | EXTERNAL/HUMAN | Specialist provider; scope-letter template in reference 12.7 |
| Net-worth, expenditure, bank-deposit methods; link analysis; funds tracing | EXTERNAL/HUMAN | Personal data; not automated and not templated (needs counsel authorisation) |
| Working papers fit for litigation | PARTIAL | Reperformance by a second analyst is required (reference 12.7); toolkit logs script hash, command and file hashes |

## 4. Analysis and data processing
| Item | Status | Next step |
|---|---|---|
| Profile with control totals, duplicates, splits, round, sequence, blanks, calendar, overlap, SoD, recon, JE, rate variance, Benford with preconditions | COVERED | 27 regression checks pass |
| Reader robustness (delimiter, encoding, short rows, multi-line row numbers, ISO timestamps, NaN/inf) | COVERED (v2.4.0) | Fixed after review |
| Non-Latin name matching, same-day change-then-pay, 0 vs 0 recon, gross/absolute recon, no-contract invoices, defaults disclosed, script hash and command logged | COVERED (v2.4.0) | Fixed after review |
| Numeric locale, date order (dmy/mdy) with ambiguity count, ratevar effective dates/amendments/service key, JE credits/period-end/keyword word-match/min-flags and linear runtime, fuzzy-skip disclosed, splits overlapping windows | COVERED (v2.4.0) | 39 regression checks |
| Still open: JE posting-time, rarely-used-account and unbalanced-entry tests; fuzzy matching without legal-suffix stripping/phonetic match; ratevar escalation clauses | OPEN | (M) |
| Added in v2.4.0: Benford first-two digits, robust outliers, concentration/HHI, three-way match, date-order checks (vendor paid before creation, payment before invoice), dormant reactivation, shared bank/address across ids | COVERED | |
| Still missing: Benford second/last-two digits, lapping, payroll headcount/attendance reconciliation, credit-note/refund abuse, inventory count/shrinkage analytics | GAP | (L) |
| Independent second-method check (pandas/awk) in CI | GAP | (M) |

## 5. Modus operandi interpretation
| Item | Status | Next step |
|---|---|---|
| Footprint to scheme to benign alternative to settling evidence | COVERED | Tool column may be PARTIAL; scheme is TESTED only if a test actually ran |
| Interpretation guardrails: overlap not additive, no projection from unreconciled quantity, leads not findings | COVERED | |
| Loss-quantification templates | COVERED (templates/loss-quantification-workbook.xlsx) | Inputs only; formulas recompute |
| False-positive tracking and back-testing on closed cases | GAP | Highest-value validation; needs anonymised closed cases (M, EXTERNAL) |

## 5A. Added in v2.5.0 (use-case driven)
unsupported (claims without support per entity), datecheck b-after-a, recon direction, outlier entity roll-up, --exclude, --quiet, --log, decision-log template, payroll playbook. See docs/USE_CASE_REVIEW.md for remaining weaknesses and next functionality.

## 6. Prioritised next steps
1. Back-test on 3-5 closed cases and record false-positive rate (EXTERNAL data, M).
2. Jurisdiction supplement reviewed by counsel (L).
3. Close the remaining OPEN analytics items (posting-time JE, lapping, payroll reconciliation) (L).
4. Counsel to answer the reference-13 questions per entity, and the sample-size and retention fields to be filled with the client's actual values (M).
5. Run the skill description-trigger optimiser (not yet run) and resolve overlap with existing group skills (S/M).

## 7. Limits
Synthetic data; single runs; the pilot QA was self-applied; hooks protect only Claude Code sessions with the plugin loaded; the plugin cannot authenticate documents, assess credibility or give legal conclusions.
