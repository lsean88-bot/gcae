#!/usr/bin/env python3
"""post_install_check.py - after you install (or replace) the plugin, prove the installed copy works and is the only one.

  python tools/post_install_check.py [--expect 2.0.2] [--lib <existing library, optional>]
  python tools/post_install_check.py --selftest

What it checks (read-only except inside a throwaway temp library):
  1 every installed copy of akos-graphify-bridge on this machine: where, which version, whether it is the expected one
  2 duplicates: more than one copy => two routers for the same prompts (exit 1)
  3 each copy's own self-test: validate a sample graph at the FINAL gate, create a library, add a shelf, capture, recall,
    seal, anchor-record/anchor-check, verify, guard, lockdown, doctor (in a temp folder)
  4 the slash commands present for a Claude Code install
  5 optionally, your real library: doctor + guard + verify (read-only)
The Claude desktop app's own plugin store cannot be driven from a script; this reads its folder on disk.
"""
import argparse, json, os, re, subprocess, sys, tempfile
from pathlib import Path

NAME = "akos-graphify-bridge"
HOME = Path.home()
ROOTS = [HOME / ".claude/skills", HOME / ".claude/plugins", HOME / "AppData/Roaming/Claude/rpm", HOME / "Library/Application Support/Claude/rpm", HOME / ".config/Claude/rpm"]
ROOTS += [Path(x) for x in os.environ.get("GIA_DUP_SCAN_EXTRA", "").split(os.pathsep) if x]
SMOKE_KG = {"engagement": "post-install smoke", "nodes": [
    {"id": "A", "type": "Risk", "label": "a", "entity": "Group", "created_date": "2026-01-01", "confidence": "High", "source_location": "x"},
    {"id": "B", "type": "Control", "label": "b", "entity": "Group", "created_date": "2026-01-01", "confidence": "High", "source_location": "x"}],
    "edges": [{"from": "A", "to": "B", "relationship": "mitigates", "evidence": "e", "confidence": "High"}]}


def find_copies(roots=None):
    out = []
    for r in roots or ROOTS:
        if r.exists():
            for f in r.rglob("SKILL.md"):
                head = f.read_text(encoding="utf-8", errors="replace")[:4000]
                if re.search(rf"^name:\s*[\"']?{NAME}[\"']?\s*$", head, re.M) and (f.parent / "scripts/brain.py").exists():
                    v = re.search(r'^\s*version:\s*"?([\d.]+)"?', head, re.M)
                    out.append((f.parent, v.group(1) if v else "?"))
    return out


def run(py, script, *args, env=None):
    e = {**os.environ, "PYTHONUTF8": "1", "GIA_NO_FSYNC": "1", **(env or {})}
    return subprocess.run([py, str(script), *map(str, args)], capture_output=True, text=True, encoding="utf-8", errors="replace", env=e)


def smoke(skill: Path):
    py, brain, akg = sys.executable, skill / "scripts/brain.py", skill / "scripts/akos_graph.py"
    steps, d = [], Path(tempfile.mkdtemp(prefix="gia-pic-"))
    kg = d / "k.json"; kg.write_text(json.dumps(SMOKE_KG), encoding="utf-8")
    lib, anchor = d / "lib", d / "outside" / "anchors.jsonl"

    def step(label, r, ok=(0,)):
        steps.append((label, r.returncode in ok, (r.stdout + r.stderr).strip().splitlines()[-1][:90] if (r.stdout + r.stderr).strip() else ""))
    step("validate a sample graph at the FINAL gate", run(py, akg, "validate", kg, "--gate", "final"))
    step("create a library", run(py, brain, "init", lib))
    step("add a project shelf", run(py, brain, "shelf-add", lib, "proj", "--kind", "project", "--entity", "Group"))
    step("add an investigation shelf", run(py, brain, "shelf-add", lib, "inv-t", "--kind", "investigation", "--entity", "MKSDL"))
    step("capture a note", run(py, brain, "capture", lib, "--shelf", "proj", "--text", "post install smoke note", "--project", "SMOKE"))
    step("recall finds it", run(py, brain, "recall", lib, "smoke note", "--shelf", "proj"))
    step("seal + anchor off-library", run(py, brain, "seal", lib, "--shelf", "proj", "--reason", "smoke", "--anchor-file", anchor))
    step("anchor-check", run(py, brain, "anchor-check", lib, "--file", anchor))
    step("verify audit trail", run(py, brain, "verify", lib))
    step("lockdown", run(py, brain, "lockdown", lib))
    step("guard (owner-only holds)", run(py, brain, "guard", lib))
    r = run(py, brain, "doctor"); fails = [l for l in r.stdout.splitlines() if l.startswith("[FAIL")]
    steps.append(("doctor: no FAIL", not fails, "; ".join(fails)[:90]))
    return steps


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--expect", default=None); ap.add_argument("--lib"); ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args(argv)
    if a.selftest:                                       # run against this package's own skill folder, no machine-wide scan
        skill = Path(__file__).resolve().parent.parent / "01-skill" / NAME
        s = smoke(skill)
        bad = [x for x in s if not x[1]]
        for lbl, ok, ev in s:
            print(f"[{'OK' if ok else 'FAIL':<4}] {lbl} {('- ' + ev) if not ok else ''}")
        print("post_install_check selftest " + ("OK" if not bad else "FAILED")); return 1 if bad else 0
    copies = find_copies()
    bad = 0
    print(f"found {len(copies)} installed copy(ies) of {NAME}:")
    for p, v in copies:
        flag = "" if not a.expect or v == a.expect else f"  <-- expected {a.expect}"
        print(f"  {v:<8} {p}{flag}"); bad += bool(flag)
    if not copies:
        print("  none: install first (see INSTALL.md)"); return 2
    if len(copies) > 1:
        print("FAIL: more than one copy installed = two routers for the same prompts. Remove all but one."); bad += 1
    for p, v in copies:
        print(f"\nself-test of {p}")
        for lbl, ok, ev in smoke(p):
            print(f"  [{'OK' if ok else 'FAIL':<4}] {lbl} {('- ' + ev) if not ok else ''}"); bad += (not ok)
    cmds = HOME / ".claude/commands"
    if cmds.exists():
        n = len(list(cmds.glob("akos-brain-*.md")))
        print(f"\nslash commands in {cmds}: {n} akos-brain-* (expect 13 for 2.0.2: 7 original + 6 new)")
    if a.lib:
        brain = copies[0][0] / "scripts/brain.py"
        for c in ("doctor", "guard", "verify"):
            r = run(sys.executable, brain, c, a.lib); print(f"  library {c}: exit {r.returncode}"); bad += r.returncode not in (0,)
    print("\n" + ("POST-INSTALL CHECK PASSED" if not bad else f"POST-INSTALL CHECK: {bad} problem(s)"))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
