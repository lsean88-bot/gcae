#!/usr/bin/env python3
"""make_manifest.py - (re)write MANIFEST.sha256 for a package folder: SHA-256 of every file, POSIX paths, sorted.
   python tools/make_manifest.py [folder]      (default: this package)"""
import hashlib, sys
from pathlib import Path
root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent
SKIP = ("__pycache__", ".pytest_cache", ".pyc", "RELEASE_REPORT.json", "MANIFEST.sha256")
files = sorted(p for p in root.rglob("*") if p.is_file() and not any(s in str(p) for s in SKIP))
with open(root / "MANIFEST.sha256", "w", encoding="utf-8", newline="\n") as fh:   # LF on every OS, or `sha256sum -c` fails on Linux/macOS
    fh.write("".join(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(root).as_posix()}\n" for p in files))
print(f"{len(files)} files hashed -> {root / 'MANIFEST.sha256'}")
