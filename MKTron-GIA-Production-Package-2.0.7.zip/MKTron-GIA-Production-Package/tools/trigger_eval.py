#!/usr/bin/env python3
"""trigger_eval.py - does the skill's description route the right prompts to it, and not take over other skills' work?

This is a LEXICAL PROXY (TF-IDF cosine between a prompt and every skill description in your catalog). It is cheap, repeatable and
catches the failures that matter first: description collisions, a missing 'Not for' boundary, a description that loses to a neighbour
for its own core prompts. It is NOT Claude's real routing decision. The 13 behavioural evals in evals/evals.json still need a live
run with subagents; this tool tells you whether it is worth running them.

  python tools/trigger_eval.py --catalog <dir> [<dir> ...]  [--skill akos-graphify-bridge] [--json out.json]

Exit 0: no collisions, every positive prompt routed to this skill, no negative prompt routed to it.  Exit 1 otherwise.
"""
import argparse, json, math, re, sys
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
DEFAULT_SKILL = "akos-graphify-bridge"
STOP = set("the a an of and or to in on for with by is are was be it as at from that this what which who how why do does did we our your their there any all into than then use used using when not also".split())
COLLISION = 0.30          # description-to-description cosine above this is flagged
MARGIN = 1.15             # this skill must beat the runner-up by this factor to count as "routed"


def _stem(w: str) -> str:
    for suf in ("ing", "ed", "es", "s"):
        if w.endswith(suf) and len(w) - len(suf) >= 4 and not w.endswith("ss"):
            return w[: -len(suf)]
    return w


def tok(t: str) -> list[str]:
    """Words, hyphen-split, lightly stemmed (graphs -> graph, merging -> merg): enough for a routing proxy, nothing more."""
    return [_stem(w) for w in re.findall(r"[a-z][a-z0-9]{2,}", t.lower()) if w not in STOP]


def read_skill(p: Path):
    t = p.read_text(encoding="utf-8", errors="replace")
    m = re.match(r"^---\s*\n(.*?)\n---", t, re.S)
    if not m:
        return None
    fm = m.group(1)
    name = re.search(r"^name:\s*(.+)$", fm, re.M)
    d = re.search(r"^description:\s*(.*?)(?=^\w[\w-]*:|\Z)", fm, re.M | re.S)
    if not name or not d:
        return None
    desc = re.sub(r"^[>|][-+]?\s*", "", d.group(1).strip())
    desc = re.sub(r"\s+", " ", desc).strip().strip('"').strip("'")
    return name.group(1).strip().strip('"'), desc


def load_catalog(dirs):
    skills = {}
    for d in dirs:
        for p in Path(d).rglob("SKILL.md"):
            try:
                r = read_skill(p)
            except OSError:
                continue
            if r:
                skills.setdefault(r[0], r[1])                  # one entry per name: duplicates are a portfolio problem, not ours
    return skills


class Index:
    def __init__(self, docs: dict[str, str]):
        self.tf = {n: Counter(tok(d)) for n, d in docs.items()}
        df = Counter(w for c in self.tf.values() for w in c)
        N = len(docs)
        self.idf = {w: math.log(1 + N / n) for w, n in df.items()}
        self.vec = {n: self._v(c) for n, c in self.tf.items()}

    def _v(self, c: Counter):
        v = {w: (1 + math.log(f)) * self.idf.get(w, math.log(1 + len(self.tf))) for w, f in c.items()}
        norm = math.sqrt(sum(x * x for x in v.values())) or 1.0
        return {w: x / norm for w, x in v.items()}

    def query(self, text: str):
        q = self._v(Counter(tok(text)))
        return sorted(((sum(x * self.vec[n].get(w, 0.0) for w, x in q.items()), n) for n in self.vec), reverse=True)

    def sim(self, a: str, b: str) -> float:
        va, vb = self.vec[a], self.vec[b]
        return sum(x * vb.get(w, 0.0) for w, x in va.items())


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--catalog", nargs="+", required=True, help="folders to scan recursively for SKILL.md")
    ap.add_argument("--skill", default=DEFAULT_SKILL)
    ap.add_argument("--cases", default=str(HERE / "01-skill/akos-graphify-bridge/evals/trigger_cases.json"))
    ap.add_argument("--json")
    a = ap.parse_args(argv)
    skills = load_catalog(a.catalog)
    own = read_skill(HERE / "01-skill/akos-graphify-bridge/SKILL.md")
    if not own:
        print("cannot read this package's SKILL.md"); return 2
    skills[a.skill] = own[1]                                   # always test THIS package's description
    idx = Index(skills)
    findings, rows = [], []
    print(f"catalog: {len(skills)} skills from {len(a.catalog)} folder(s); testing {a.skill!r} ({len(own[1])} chars)\n")
    if len(own[1]) > 1024:
        findings.append(f"description is {len(own[1])} chars (limit 1024)")
    if not re.search(r"\bnot for\b", own[1], re.I):
        findings.append("description has no 'Not for ...' boundary")

    near = sorted(((idx.sim(a.skill, n), n) for n in skills if n != a.skill), reverse=True)[:5]
    print("closest descriptions (cosine):")
    for s, n in near:
        flag = "  <-- COLLISION" if s >= COLLISION else ""
        print(f"  {s:.2f}  {n}{flag}")
        if s >= COLLISION:
            findings.append(f"description overlaps {n!r} at {s:.2f} (>= {COLLISION})")

    cases = json.loads(Path(a.cases).read_text(encoding="utf-8"))
    print("\nrouting (top-1 among the whole catalog; a lead under %.0f%% is reported as a NEAR-TIE):" % ((MARGIN - 1) * 100))
    bad, warn = 0, []
    for kind in ("positive", "negative"):
        for c in cases[kind]:
            ranked = idx.query(c["prompt"])
            top, runner = ranked[0], ranked[1]
            first = top[1] == a.skill and top[0] > 0.05
            shared = c.get("shared")                          # a neighbour that legitimately owns part of this prompt
            if kind == "positive":
                ok = first or (shared and top[1] == shared)
                note = ""
                if first and top[0] < MARGIN * runner[0]:
                    note = f"NEAR-TIE with {runner[1]} ({runner[0]:.2f} vs {top[0]:.2f})"
                elif not first and ok:
                    note = f"SHARED with {shared}: a routing decision for the portfolio owner"
                if note:
                    warn.append(f"{note} | {c['prompt'][:70]}")
            else:
                ok = top[1] != a.skill
            rows.append({"kind": kind, "prompt": c["prompt"], "top": top[1], "score": round(top[0], 3), "ok": bool(ok)})
            if not ok:
                bad += 1
                print(f"  {'MISS ' if kind == 'positive' else 'STEAL'} [{kind}] top={top[1]} ({top[0]:.2f}) | {c['prompt'][:90]}")
    for w in warn:
        print(f"  WARN  {w}")
    pos = sum(r["ok"] for r in rows if r["kind"] == "positive"); npos = sum(r["kind"] == "positive" for r in rows)
    neg = sum(r["ok"] for r in rows if r["kind"] == "negative"); nneg = sum(r["kind"] == "negative" for r in rows)
    print(f"\npositive prompts routed to this skill: {pos}/{npos}    negative prompts correctly NOT routed to it: {neg}/{nneg}")
    if bad:
        findings.append(f"{bad} routing case(s) failed")
    print("\n" + ("TRIGGER EVAL PASSED" if not findings else "TRIGGER EVAL: findings\n  - " + "\n  - ".join(findings)))
    if a.json:
        Path(a.json).write_text(json.dumps({"findings": findings, "near": near, "rows": rows}, indent=2), encoding="utf-8")
    return 1 if findings else 0


if __name__ == "__main__":
    sys.exit(main())
