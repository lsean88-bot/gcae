#!/usr/bin/env python3
"""pilot_sampler.py - makes the CLD-14 pilot (docs/PILOT-CLD-14.md) quick and unbiased.

  sample   draw N random nodes from a shelf into a CSV check sheet (P1 precision) with blank reviewer columns
  recall   score a question list against the library (P4 recall quality, P5 trust labels)
  score    read the filled-in check sheet and print the P1 result against the pass line
  --selftest   prove the tool works on a synthetic library (used by the release gate)

The sampler never writes to the library. Confidential shelves are refused: the pilot uses the CLD-14 engagement only.

  python tools/pilot_sampler.py sample <lib> --shelf clld14 --n 40 --seed 7 --out p1_sheet.csv
  python tools/pilot_sampler.py recall <lib> --questions p4_questions.csv --shelf clld14      (CSV columns: question,expected_id,expected_trust)
  python tools/pilot_sampler.py score p1_sheet.csv
"""
import argparse, csv, json, os, random, sys, tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = ROOT / "01-skill/akos-graphify-bridge/scripts"
sys.path.insert(0, str(SCRIPTS))
os.environ.setdefault("GIA_NO_FSYNC", "1")
import brain  # noqa: E402

COLS = ["id", "label", "type", "entity", "confidence", "evidence_rank", "source_location", "label_ok", "type_ok", "source_ok", "notes"]


def sample(lib, shelf, n, seed, out):
    meta = brain.shelf_meta(lib, shelf)
    if meta["confidential"]:
        sys.exit("refused: the pilot never samples a confidential shelf")
    nodes = brain.shelf_kg(lib, shelf).get("nodes", [])
    if not nodes:
        sys.exit("the shelf has no nodes yet: ingest first")
    pick = random.Random(seed).sample(nodes, min(n, len(nodes)))
    with open(out, "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.writer(fh)
        w.writerow(COLS)
        for x in pick:
            w.writerow([x.get("id"), x.get("label"), x.get("type"), x.get("entity"), x.get("confidence"), x.get("evidence_rank") or "",
                        x.get("source_location"), "", "", "", ""])
    print(f"wrote {len(pick)} of {len(nodes)} nodes to {out} (seed {seed}). Fill label_ok/type_ok/source_ok with Y or N against the source document.")


def score(sheet):
    rows = list(csv.DictReader(open(sheet, encoding="utf-8-sig")))
    done = [r for r in rows if (r["label_ok"] + r["type_ok"] + r["source_ok"]).strip()]
    if not done:
        sys.exit("no rows are filled in yet")
    ok = [r for r in done if all(r[c].strip().upper() == "Y" for c in ("label_ok", "type_ok", "source_ok"))]
    pct = 100 * len(ok) / len(done)
    print(f"P1 extraction precision: {len(ok)}/{len(done)} fully correct = {pct:.0f}%  (pass line 90%)  -> {'PASS' if pct >= 90 else 'FAIL'}")
    bad = [r["id"] for r in done if r not in ok]
    if bad:
        print("incorrect or partly incorrect:", ", ".join(bad[:20]))
    return 0 if pct >= 90 else 1


def recall_check(lib, questions, shelf):
    rows = list(csv.DictReader(open(questions, encoding="utf-8-sig")))
    hit5 = trust_ok = trust_n = 0
    for r in rows:
        res = brain.recall(lib, r["question"], [shelf] if shelf else None, limit=5)["results"]
        ids = [x["id"] for x in res]
        hit = r["expected_id"] in ids
        hit5 += hit
        if r.get("expected_trust"):
            trust_n += 1
            got = next((x["trust"] for x in res if x["id"] == r["expected_id"]), None)
            trust_ok += got == r["expected_trust"].strip().upper()
        print(f"{'HIT ' if hit else 'MISS'} top5={ids[:5]} want={r['expected_id']} | {r['question'][:60]}")
    pct = 100 * hit5 / max(len(rows), 1)
    print(f"\nP4 recall quality: {hit5}/{len(rows)} = {pct:.0f}% in top 5 (pass line 80%) -> {'PASS' if pct >= 80 else 'FAIL'}")
    if trust_n:
        print(f"P5 trust labels:  {trust_ok}/{trust_n} correct (pass line 100%) -> {'PASS' if trust_ok == trust_n else 'FAIL'}")
    return 0 if pct >= 80 and trust_ok == trust_n else 1


def selftest():
    import akos_graph as ag
    d = Path(tempfile.mkdtemp())
    lib = d / "lib"
    brain.init_library(lib)
    brain.add_shelf(lib, "clld14", "engagement", "MKAPL-DC")
    brain.add_shelf(lib, "inv-x", "investigation", "MKSDL")
    p = lib / "shelves/clld14/KNOWLEDGE_GRAPH.json"
    kg = json.loads(p.read_text(encoding="utf-8"))
    kg["nodes"] = [{"id": f"N-{i}", "type": "Control", "label": f"Contract labour control number {i} written agreement", "entity": "MKAPL-DC",
                    "created_date": "2026-01-01", "confidence": "High", "source_location": "x", "evidence_rank": "R2"} for i in range(60)]
    ag.atomic_write_json(p, kg, 0o644)
    out = d / "sheet.csv"
    sample(lib, "clld14", 40, 7, out)
    sample(lib, "clld14", 40, 7, d / "again.csv")
    assert out.read_bytes() == (d / "again.csv").read_bytes(), "the same seed must give the same sample"
    rows = list(csv.DictReader(open(out, encoding="utf-8-sig")))
    assert len(rows) == 40 and len({r["id"] for r in rows}) == 40
    for r in rows[:36]:
        r["label_ok"] = r["type_ok"] = r["source_ok"] = "Y"
    for r in rows[36:]:
        r["label_ok"], r["type_ok"], r["source_ok"] = "N", "Y", "Y"
    with open(out, "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, COLS)
        w.writeheader()
        w.writerows(rows)
    assert score(out) == 0                                   # 36/40 = 90% passes exactly at the line
    q = d / "q.csv"
    q.write_text("question,expected_id,expected_trust\ncontract labour control number 7,N-7,CONFIRMED\nwritten agreement control number 33,N-33,CONFIRMED\n", encoding="utf-8")
    assert recall_check(lib, q, "clld14") == 0
    try:
        sample(lib, "inv-x", 5, 1, d / "no.csv")
        raise AssertionError("a confidential shelf must be refused")
    except SystemExit as e:
        assert "refused" in str(e)
    print("pilot_sampler selftest OK")
    return 0


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        sys.exit(selftest())
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("sample"); p.add_argument("lib"); p.add_argument("--shelf", required=True); p.add_argument("--n", type=int, default=40)
    p.add_argument("--seed", type=int, default=7); p.add_argument("--out", required=True)
    p = sub.add_parser("recall"); p.add_argument("lib"); p.add_argument("--questions", required=True); p.add_argument("--shelf")
    p = sub.add_parser("score"); p.add_argument("sheet")
    a = ap.parse_args()
    if a.cmd == "sample":
        sample(a.lib, a.shelf, a.n, a.seed, a.out)
    elif a.cmd == "recall":
        sys.exit(recall_check(a.lib, a.questions, a.shelf))
    else:
        sys.exit(score(a.sheet))
