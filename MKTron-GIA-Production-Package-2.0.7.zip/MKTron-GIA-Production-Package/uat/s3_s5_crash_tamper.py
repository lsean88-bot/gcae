import json, os, random, shutil, signal, subprocess, sys, tempfile, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from uatlib import *
results = []
def check(name, ok, evidence=""):
    results.append((name, bool(ok), evidence)); print(f"{'PASS' if ok else 'FAIL'} | {name} | {evidence}")
rnd = random.Random(11)
base = Path(tempfile.mkdtemp()); L0 = base / "lib"; build_group_library(L0, per_shelf=500, hostile=False); assert cli("brain.py", "index", L0).returncode == 0
def kill_run(L, args, delay):
    p = subprocess.Popen([sys.executable, str(CODE / "brain.py"), *map(str, args)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, env={**ENV, "GIA_TMP_MAX_AGE": "0"})
    time.sleep(delay)
    killed = p.poll() is None
    if killed: p.kill()
    p.wait(); return killed
def all_json_ok(L):
    bad = []
    for p in L.rglob("*.json"):
        try: json.loads(p.read_bytes())
        except Exception: bad.append(str(p.relative_to(L)))
    return bad
cmds = {"index": lambda L, i: ["index", L], "remember": lambda L, i: ["remember", L, "--shelf", "clrw-dc", "--question", f"crash q{i}?", "--answer", "a", "--outcome", "useful"],
        "seal": lambda L, i: ["seal", L, "--shelf", "frameworks", "--reason", f"crash seal {i}"], "shelf-add": lambda L, i: ["shelf-add", L, f"crash-{i}", "--kind", "reference", "--entity", "Group"],
        "reflect": lambda L, i: ["reflect", L], "dashboard": lambda L, i: ["dashboard", L, "--out", L.parent / "rep", "--today", "2026-10-03"]}
ONLY = sys.argv[1] if len(sys.argv) > 1 else "all"
for name, mk in (cmds.items() if ONLY in ("all", "s3") else []):
    L = base / f"lib-{name}"; shutil.copytree(L0, L)
    if name == "reflect": cli("brain.py", "remember", L, "--shelf", "clrw-dc", "--question", "seed?", "--answer", "a", "--outcome", "corrected", "--correction", "c")
    killed_n, problems = 0, []
    for i in range(6):
        killed_n += kill_run(L, mk(L, i), rnd.uniform(0.02, 1.2) if name != "shelf-add" else rnd.uniform(0.02, 0.5))
        st = cli("brain.py", "status", L)
        if st.returncode not in (0, 2) or "Traceback" in st.stderr: problems.append(f"status after kill {i}: exit {st.returncode}")
        bad = all_json_ok(L)
        if bad: problems.append(f"corrupt JSON after kill {i}: {bad[:2]}")
        heal = cli("brain.py", *mk(L, 100 + i)[:])        # re-run the same command to completion
        if name == "index" and heal.returncode != 0: problems.append(f"re-index failed: {heal.stderr[-100:]}")
    cli("brain.py", "index", L)                           # final heal
    if name in ("remember",): cli("brain.py", "remember", L, "--shelf", "clrw-dc", "--question", "adopt?", "--answer", "a", "--outcome", "useful")
    g = cli("brain.py", "guard", L); v = cli("brain.py", "verify", L); bad = all_json_ok(L)
    stray = [p for p in L.rglob("*") if p.is_file() and p.name.endswith(".tmp")] + list(L.rglob("*.old-*")) + [p for p in L.rglob("*") if ".staging" in p.name]
    errs = [l for l in (g.stdout + v.stdout).splitlines() if l.startswith("[ERROR")]
    check(f"S3 {name}: 6 SIGKILLs ({killed_n} landed mid-run), library recovers with no corrupt JSON and no ERROR findings",
          not problems and not bad and not errs and g.returncode == 0 and v.returncode == 0 and not stray, f"problems={problems[:2]} bad={bad[:2]} errors={errs[:2]} stray={len(stray)}")
# ---------------- S5 tamper campaign
if ONLY == "s3":
    print(f"\nS3 SUMMARY: {sum(o for _, o, _ in results)}/{len(results)} passed"); sys.exit(0 if all(o for _, o, _ in results) else 1)
T = base / "tamper"; shutil.copytree(L0, T)
for s in ("clrw-dc", "frameworks"): assert cli("brain.py", "seal", T, "--shelf", s, "--reason", f"baseline {s}").returncode == 0
anchor = json.loads(cli("brain.py", "status", T).stdout)["audit"]["head"]
def attack(label, fn, expect):
    A = base / f"att-{label}"; shutil.copytree(T, A); fn(A)
    v = cli("brain.py", "verify", A, "--anchor", anchor, "--strict"); g = cli("brain.py", "guard", A)
    import re; codes = {m.group(1) for l in v.stdout.splitlines() for m in [re.match(r"\[[A-Z ]+\]\s+(\w+)", l)] if m}
    check(f"S5 tamper '{label}' is detected", v.returncode == 1 and expect in codes, f"verify exit={v.returncode} codes={sorted(codes)}")
lines = lambda A: (A / "audit.log").read_text().splitlines()
def wr(A, ls): (A / "audit.log").write_text("\n".join(ls) + "\n")
def edit_entry(A): ls = lines(A); e = json.loads(ls[4]); e["actor"] = "intruder"; ls[4] = json.dumps(e, separators=(",", ":")); wr(A, ls)
def kgedit(A):
    f = A / "shelves/clrw-dc/KNOWLEDGE_GRAPH.json"; k = json.loads(f.read_text()); k["nodes"][10]["confidence"] = "100%"; k["nodes"][10]["label"] = "FORGED"; f.write_text(json.dumps(k))
def rewrite_all(A):
    prev, out = audit_zero, []
    for l in lines(A):
        e = json.loads(l); e["actor"] = "forged"; e["prev"] = prev; e["hash"] = ent_hash(e); prev = e["hash"]; out.append(json.dumps(e, separators=(",", ":")))
    wr(A, out)
sys.path.insert(0, str(CODE)); import audit as _a; audit_zero, ent_hash = _a.ZERO, _a.entry_hash
snap = lambda A, s="clrw-dc": next((A / f"shelves/{s}/.seals").glob("*.json"))
attack("edit an audit entry", edit_entry, "AUDIT_CHAIN_BROKEN")
attack("delete a middle entry", lambda A: wr(A, lines(A)[:3] + lines(A)[4:]), "AUDIT_CHAIN_BROKEN")
attack("reorder two entries", lambda A: wr(A, lines(A)[:3] + [lines(A)[4], lines(A)[3]] + lines(A)[5:]), "AUDIT_CHAIN_BROKEN")
attack("insert a duplicate entry", lambda A: wr(A, lines(A)[:4] + [lines(A)[3]] + lines(A)[4:]), "AUDIT_CHAIN_BROKEN")
attack("truncate the tail", lambda A: wr(A, lines(A)[:-3]), "AUDIT_ANCHOR_MISMATCH")
attack("truncate the log to empty", lambda A: (A / "audit.log").write_text(""), "AUDIT_ANCHOR_MISMATCH")
attack("delete the log", lambda A: (A / "audit.log").unlink(), "AUDIT_ABSENT")
attack("rewrite the whole log consistently", rewrite_all, "AUDIT_ANCHOR_MISMATCH")
attack("garbage line injected mid-log", lambda A: wr(A, lines(A)[:3] + ["{not json"] + lines(A)[3:]), "AUDIT_CHAIN_BROKEN")
attack("raise a confidence after the seal", kgedit, "UNSEALED_CHANGES")
attack("delete a sealed Knowledge Graph", lambda A: (A / "shelves/clrw-dc/KNOWLEDGE_GRAPH.json").unlink(), "SEALED_FILE_MISSING")
attack("modify the seal snapshot", lambda A: snap(A).write_text(snap(A).read_text().replace("CLRA", "XXXX")), "SEAL_SNAPSHOT_TAMPERED")
attack("delete the seal snapshot", lambda A: snap(A).unlink(), "SEAL_SNAPSHOT_TAMPERED")
A = base / "att-flags"; shutil.copytree(T, A); kgedit(A)
ch = json.loads(cli("brain.py", "changes", A, "--shelf", "clrw-dc").stdout)
check("S5 'changes' pinpoints the forged confidence raise", any(f["code"] == "CONFIDENCE_RAISED" and f["to"] == "100%" for f in ch["flags"]) and any(c["fields"].get("label") for c in ch["nodes_changed"]), f"{[f['code'] for f in ch['flags']]}")
ok = cli("brain.py", "verify", T, "--anchor", anchor, "--strict"); check("S5 control: the untouched library verifies clean against the anchor", ok.returncode == 0, ok.stdout.strip().splitlines()[-1])
print(f"\nS3+S5 SUMMARY: {sum(o for _, o, _ in results)}/{len(results)} passed")
json.dump([{"name": n, "ok": o, "evidence": e} for n, o, e in results], open(os.path.join(__import__("tempfile").gettempdir(), "uat_s3s5.json"), "w"), indent=1)
sys.exit(0 if all(o for _, o, _ in results) else 1)
