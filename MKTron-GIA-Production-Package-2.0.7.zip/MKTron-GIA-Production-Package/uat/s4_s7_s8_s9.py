import json, os, random, re, shutil, subprocess, sys, tempfile, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent)); from uatlib import *
sys.path.insert(0, str(CODE))
which = sys.argv[1]; results = []
if which == "s9" and os.name == "nt":
    print("S9 SKIPPED on Windows: it SIGKILLs the patch tool, which targets the Linux plugin:skill catalog (run it in the Linux/Cowork sandbox)"); sys.exit(0)
def check(name, ok, evidence=""):
    results.append((name, bool(ok), evidence)); print(f"{'PASS' if ok else 'FAIL'} | {name} | {evidence}")
base = Path(tempfile.mkdtemp()); rnd = random.Random(5)
def clean(r): return "\x1b" not in r.stdout + r.stderr and "\x00" not in r.stdout + r.stderr and "Traceback" not in r.stderr
if which == "s7":
    L = base / "lib"; build_group_library(L, per_shelf=300, hostile=False); cli("brain.py", "index", L)
    INV = "inv-mksdl-tooling"; captured = {}
    def run(label, script, *a):
        r = cli(script, *a); captured[label] = r.stdout + r.stderr; return r
    run("remember-conf", "brain.py", "remember", L, "--shelf", INV, "--question", "Is ACMEKICKBACK paying SECRET-TOOLING-7731?", "--answer", "PHANTOMTREATMENT likely", "--outcome", "corrected", "--correction", "ACMEKICKBACK confirmed SECRET-TOOLING-7731")
    run("remember-shared", "brain.py", "remember", L, "--shelf", "clrw-dc", "--question", "shared q?", "--answer", "a", "--outcome", "corrected", "--correction", "shared fix")
    run("seal-conf", "brain.py", "seal", L, "--shelf", INV, "--reason", "Reviewed ACMEKICKBACK SECRET-TOOLING-7731 with the CAE")
    for lab, args in {"index": ["brain.py", "index", L], "reflect": ["brain.py", "reflect", L], "status": ["brain.py", "status", L], "guard": ["brain.py", "guard", L], "verify": ["brain.py", "verify", L],
                      "stale": ["brain.py", "stale", L], "doctor": ["brain.py", "doctor", L], "mcp": ["brain.py", "mcp-config", L], "dashboard": ["brain.py", "dashboard", L, "--out", base / "rep", "--today", "2026-10-03"],
                      "recall-default": ["brain.py", "recall", L, "ACMEKICKBACK PHANTOMTREATMENT SECRET-TOOLING-7731 kickback"], "recall-idf": ["brain.py", "recall", L, "ACMEKICKBACK", "--ranking", "idf", "--limit", "1000"],
                      "export-shared": ["akos_graph.py", "export-xlsx", L / "shelves/clrw-dc/KNOWLEDGE_GRAPH.json", "--out", base / "x.xlsx"],
                      "validate-shared": ["akos_graph.py", "validate", L / "shelves/clrw-dc/KNOWLEDGE_GRAPH.json", "--json"]}.items(): run(lab, *args)
    r = run("merge-attempt", "akos_graph.py", "merge", L / "shelves/clrw-dc/KNOWLEDGE_GRAPH.json", L / f"shelves/{INV}/KNOWLEDGE_GRAPH.json", "--out", base / "m.json")
    check("S7.1 merging a confidential graph with a shared one is refused", r.returncode == 2 and not (base / "m.json").exists(), r.stderr.strip()[:80])
    def body(k, v):                       # recall echoes the caller's own question; judge the RESULTS, not the echo
        if k.startswith("recall"):
            try: return json.dumps(json.loads(v)["results"]) + json.dumps(json.loads(v).get("expanded_terms"))
            except Exception: return v
        return v
    leaked = {k: [s for s in SECRETS if s in body(k, v)] for k, v in captured.items() if any(s in body(k, v) for s in SECRETS) and k not in ("remember-conf", "seal-conf")}
    check("S7.2 no shared-path command OUTPUT contains a confidential token", not leaked, f"{len(captured)} outputs checked; leaks={leaked}")
    hits = grep_tree(L, SECRETS, skip_dirs=[L / "shelves" / s for s in ("inv-mksdl-tooling", "inv-nmsb-billing")]) + grep_tree(base / "rep", SECRETS) + grep_tree(base, SECRETS, skip_dirs=[L])
    check("S7.3 no confidential token in ANY file outside the confidential shelves (library, reports, exports)", not [h for h in hits if "lib/shelves/inv" not in h[0]], f"{hits[:3]}")
    sh = (L / "lessons/PROPOSED_LESSONS.md").read_text()
    check("S7.4 shared lessons file contains the shared candidate and withholds the confidential one", "shared fix" in sh and "withheld" in sh and not any(s in sh for s in SECRETS), "ok")
    own = (L / f"shelves/{INV}/PROPOSED_LESSONS.md").read_text()
    check("S7.5 the confidential lessons are available to the shelf owner, owner-only", "ACMEKICKBACK" in own and not __import__("fsutil").loose_files(L / f"shelves/{INV}"), "owner-only")
    ch = json.loads(cli("brain.py", "changes", L, "--shelf", INV).stdout)
    check("S7.6 the seal reason is retrievable by the owner but absent from the shared audit log", "ACMEKICKBACK" in ch["reason"] and "ACMEKICKBACK" not in (L / "audit.log").read_text(), "ok")
    g = cli("brain.py", "guard", L); check("S7.7 guard clean after the whole exercise", g.returncode == 0, g.stdout.strip().splitlines()[-1])
if which == "s4":
    L = base / "lib"; build_group_library(L, per_shelf=300, hostile=True); r = cli("brain.py", "index", L)
    check("S4.1 hostile-content library indexes without a crash", r.returncode in (0, 1) and clean(r), f"exit={r.returncode}")
    outs = [cli("brain.py", *a) for a in (["guard", L], ["status", L], ["stale", L], ["verify", L], ["doctor", L], ["dashboard", L, "--out", base / "rep"], ["recall", L, "script alert evil payroll"], ["recall", L, "x" * (20000 if os.name == "nt" else 100000)])]
    outs.append(cli("akos_graph.py", "validate", L / "shelves/tn-statutory/KNOWLEDGE_GRAPH.json")); outs.append(cli("akos_graph.py", "export-xlsx", L / "shelves/tn-statutory/KNOWLEDGE_GRAPH.json", "--out", base / "x.xlsx"))
    check("S4.2 no command echoes control characters or tracebacks on hostile data", all(clean(o) for o in outs) and all(o.returncode in (0, 1, 2) for o in outs), f"{[o.returncode for o in outs]}")
    html = (base / "rep/brain-dashboard.html").read_text(encoding="utf-8")
    check("S4.3 dashboard HTML has no executable markup", "<script" not in html.lower().replace("&lt;script", "") and "onerror" not in html.replace("&quot;", ""), "escaped")
    from openpyxl import load_workbook
    live = [c.value for f in (base / "rep/brain-dashboard.xlsx", base / "x.xlsx") for s in load_workbook(f) for row in s.iter_rows() for c in row if isinstance(c.value, str) and c.value.startswith("=") and not c.value.startswith(("=SUM(", "=COUNT"))]
    check("S4.4 no live Excel formula derived from hostile data", live == [], f"{live[:2]}")
    hq = ["\x1b[2J\x1b]0;pwned\x07", "' OR 1=1 --", "../../../etc/passwd", "; rm -rf / #", "$(touch /tmp/pwned)", "`id`", "%s%s%s%n", "\u202eevil", "👩‍💻 payroll", "ஊதிய 薪资 Nómina", "", " ", "a" * 5000]
    rs = [cli("brain.py", "recall", L, q) for q in hq]
    check("S4.5 13 hostile query strings: exit contract kept, nothing executed", all(r.returncode in (0, 2) and clean(r) for r in rs) and not Path(__import__("tempfile").gettempdir(), "pwned").exists(), f"{[r.returncode for r in rs]}")
    cmds = [("brain.py", ["init", "init-x", "recall", "stale", "status", "guard", "shelf-add", "seal", "changes", "verify", "doctor", "index", "remember", "reflect", "dashboard", "mcp-config"]), ("akos_graph.py", ["validate", "stats", "merge", "deliverable", "to-graphify", "from-graphify", "export-xlsx"])]
    junk = ["--limit", "-5", "999999999999", "--today", "x", "--shelf", "../..", "--out", "/dev/null", "--gate", "--max-rank", "R9", "--ranking", "\x00", "--bogus", "-", "--", str(base)]
    bad = []
    for _ in range(150):
        script, subs = rnd.choice(cmds); argv = [rnd.choice(subs)] + [rnd.choice(junk + [str(L), str(L / "brain.json")]) for _ in range(rnd.randrange(0, 5))]
        try: r = cli(script, *[a.replace("\x00", "") for a in argv], timeout=60)
        except subprocess.TimeoutExpired: bad.append((script, argv, "timeout")); continue
        if r.returncode not in (0, 1, 2) or "Traceback" in r.stderr or "\x1b" in r.stdout + r.stderr: bad.append((script, argv, r.returncode, r.stderr[-80:]))
    check("S4.6 150 random argument combinations: never exit 3, never a traceback", not bad, f"{bad[:2]}")
    check("S4.7 the library is intact after the random-argument barrage", cli("brain.py", "verify", L).returncode == 0 and not [p for p in L.rglob("*.tmp")], "verify clean")
if which == "s8":
    sys.path.insert(0, str(CODE)); os.environ["GIA_NO_FSYNC"] = "1"; import brain, akos_graph as ag, audit
    L = base / "lib"; brain.init_library(L)
    for n in ("a", "b", "c"): brain.add_shelf(L, f"soak-{n}", "engagement", "MKAPL-DC")
    nodes = {n: [] for n in "abc"}; times = []; N = 60
    for cyc in range(N):
        t = time.time()
        for n in "abc":
            base_i = len(nodes[n])
            nodes[n] += [{"id": f"{n.upper()}-{base_i+i:05d}", "type": "Risk", "label": f"soak {rnd.choice(WORDS)} {rnd.choice(WORDS)} {base_i+i}", "entity": "MKAPL-DC", "created_date": "2026-10-01", "confidence": "High", "source_location": "x"} for i in range(25)]
            edges = [{"from": nodes[n][i]["id"], "to": nodes[n][(i * 3 + 1) % len(nodes[n])]["id"], "relationship": "relates_to", "evidence": "e", "confidence": "High"} for i in range(len(nodes[n]))]
            ag.atomic_write_json(L / f"shelves/soak-{n}/KNOWLEDGE_GRAPH.json", {"engagement": f"soak-{n}", "last_updated": "2026-10-01", "nodes": nodes[n], "edges": edges})
        rep = brain.index_library(L); assert not rep["failed_shelves"], rep
        brain.remember(L, "soak-a", f"cycle {cyc} question?", "a", "useful")
        if cyc % 10 == 9: brain.seal(L, "soak-b", f"cycle {cyc} review"); assert brain.verify(L) == [], brain.verify(L)
        assert brain.recall(L, "soak payroll")["results"] is not None
        times.append(time.time() - t)
    first, last = sum(times[:10]) / 10, sum(times[-10:]) / 10; entries, _ = audit.read(L)
    check("S8.1 60 full lifecycle cycles completed (4,500 nodes, 60 saved answers, 6 seals)", len(entries) > 120, f"{len(entries)} audit entries")
    check("S8.2 cycle time grows with data, not explosively", last < max(8 * first, 12), f"first-10 avg {first:.2f}s, last-10 avg {last:.2f}s for 3x{len(nodes['a'])} nodes")
    check("S8.3 chain, guard and index report stay valid", audit.verify(L) == [] and brain.guard(L) == [], "valid")
    mem = len(list((L / "shelves/soak-a/graphify-out/memory").glob("query_*.md"))); idx = len(json.loads((L / "shelves/soak-a/memory_index.json").read_text()))
    check("S8.4 no leakage of files: memory files == index entries == 60", mem == idx == 60, f"{mem}/{idx}")
    check("S8.5 audit log stays small", (L / "audit.log").stat().st_size < 400_000, f"{(L/'audit.log').stat().st_size//1024} KB")
    check("S8.6 no temp or swap debris", not [p for p in L.rglob("*") if p.name.endswith(".tmp") or ".old-" in p.name or ".staging" in p.name], "clean")
if which == "s9":
    REAL = Path(os.environ.get("GIA_REAL_CATALOG", "/mnt/skills")); PATCH = Path(__file__).resolve().parent.parent / "03-ecosystem-patch/gia-ecosystem-patch"
    def mkcat(p):
        p.mkdir(parents=True)
        for d in ("user", "plugins", "public"): shutil.copytree(REAL / d, p / d)
    def snap(root): return {str(p.relative_to(root)): ("D" if p.is_dir() else __import__("hashlib").sha256(p.read_bytes()).hexdigest()) for p in sorted(root.rglob("*")) if not p.is_symlink() and p.name != ".gia-patch.lock"}
    ref = base / "ref"; mkcat(ref); pristine = snap(ref)
    t0 = time.time(); r = subprocess.run([sys.executable, str(PATCH / "apply_patch.py"), "--catalog", str(ref), "--backup-dir", str(base / "refbk"), "--apply"], capture_output=True, text=True, env=ENV); T = time.time() - t0; done = snap(ref)
    print(f"uninterrupted apply takes {T:.2f}s wall (incl. interpreter start); kills are aimed inside 0.12s..{T:.2f}s")
    check("S9.1 reference uninterrupted apply succeeds", r.returncode == 0 and done != pristine, f"exit {r.returncode}")
    WRAP = ("import os, signal, sys; sys.path.insert(0, %r); import apply_patch as ap, fsutil\n"
            "point, n = sys.argv[1], int(sys.argv[2]); c = {'n': 0}\n"
            "def die(): os.kill(os.getpid(), signal.SIGKILL)\n"
            "def tick(kind):\n"
            "    if kind == point:\n"
            "        c['n'] += 1\n"
            "        if c['n'] == n: die()\n"
            "ob, oc, orp = ap.Patcher._begin, ap.Patcher._commit, fsutil.replace_dir\n"
            "def b(self, *a, **k): e = ob(self, *a, **k); tick('begin'); return e\n"
            "def cm(self, e, p): tick('commit'); return oc(self, e, p)\n"
            "def rp(x, y): tick('swap'); return orp(x, y)\n"
            "ap.Patcher._begin, ap.Patcher._commit, fsutil.replace_dir = b, cm, rp\n"
            "sys.exit(ap.main(sys.argv[3:]))\n") % str(PATCH)
    landed_n = 0; trial = 0
    for point, ns in (("begin", (1, 2, 3, 4, 5)), ("swap", (1, 2, 3)), ("commit", (1, 2, 3, 4, 5))):   # the patch makes exactly 3 folder swaps
        for n in ns:
            C = base / f"c{trial}"; mkcat(C); bk = base / f"bk{trial}"
            p = subprocess.run([sys.executable, "-c", WRAP, point, str(n), "--catalog", str(C), "--backup-dir", str(bk), "--apply"], capture_output=True, text=True, env=ENV)
            landed = p.returncode == -9; landed_n += landed
            mid = snap(C) != pristine and snap(C) != done
            r2 = subprocess.run([sys.executable, str(PATCH / "apply_patch.py"), "--catalog", str(C), "--backup-dir", str(bk), "--apply"], capture_output=True, text=True, env=ENV)
            check(f"S9 SIGKILL at {point} #{n}: {'killed (rc -9)' if landed else 'not reached'}{', catalog was half-patched' if mid else ''}; re-run converges to the reference result", landed and r2.returncode == 0 and snap(C) == done, f"rc={p.returncode} rerun={r2.returncode} identical={snap(C) == done}")
            r3 = subprocess.run([sys.executable, str(PATCH / "apply_patch.py"), "--catalog", str(C), "--rollback", str(bk)], capture_output=True, text=True, env=ENV)
            check(f"S9 SIGKILL at {point} #{n}: rollback after the recovered run restores the pristine catalog byte for byte", r3.returncode == 0 and snap(C) == pristine, f"rc={r3.returncode} identical={snap(C) == pristine}")
            trial += 1
if which == "s9": check("S9.0 every one of the 13 deterministic kill points landed mid-apply (otherwise this scenario proves nothing)", landed_n == 13, f"{landed_n} of 13 kills landed")
print(f"\n{which.upper()} SUMMARY: {sum(o for _, o, _ in results)}/{len(results)} passed")
json.dump([{"name": n, "ok": o, "evidence": e} for n, o, e in results], open(os.path.join(__import__("tempfile").gettempdir(), f"uat_{which}.json"), "w"), indent=1)
sys.exit(0 if all(o for _, o, _ in results) else 1)
