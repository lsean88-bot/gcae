"""Portability layer (2.0.2). The suite was written on Linux. On Windows:
  * a few tests need things NTFS does not allow or Windows does not grant by default (symlinks without Developer Mode,
    ':' or ESC in file names). They are SKIPPED WITH A STATED REASON - a skip is not a pass, and the gate prints the count.
  * very long parametrize ids overflow Windows' 32,767-character environment limit (pytest puts the test id in the environment).
"""
import hashlib
import inspect
import os
import tempfile
from pathlib import Path

import pytest


def _can_symlink() -> bool:
    d = Path(tempfile.mkdtemp())
    try:
        (d / "t").write_text("x")
        os.symlink(d / "t", d / "l")
        return True
    except (OSError, NotImplementedError):
        return False


CAN_SYMLINK = _can_symlink()


def pytest_make_parametrize_id(config, val, argname):
    if isinstance(val, (str, bytes)) and len(val) > 40:
        raw = val if isinstance(val, bytes) else val.encode("utf-8", "replace")
        return f"{argname}-{hashlib.sha1(raw).hexdigest()[:10]}"
    return None


def pytest_collection_modifyitems(config, items):
    for it in items:
        fn = getattr(it, "function", None)
        if fn is None:
            continue
        try:
            src = inspect.getsource(fn)
        except (OSError, TypeError):
            continue
        if not CAN_SYMLINK and "symlink" in src:
            it.add_marker(pytest.mark.skip(reason="needs symlink privilege (enable Windows Developer Mode, or run as administrator)"))
        if os.name == "nt" and ("data:build-dashboard" in src or "x1b[2Jfolder" in src or "\x1b[2Jfolder" in src):
            it.add_marker(pytest.mark.skip(reason="the test creates a file name NTFS forbids (':' or a control character)"))


# --- patch tool only -----------------------------------------------------------------------------------------------
# apply_patch.py works on the Linux/Cowork skills catalog (/mnt/skills/{user,plugins,public}) whose plugin folders are named
# "plugin:skill". ':' cannot exist in an NTFS folder name, so on Windows there is no such catalog to patch and these tests
# cannot be built. They are skipped (not passed). Run them in the Linux/Cowork sandbox.
_orig_modify = pytest_collection_modifyitems


def pytest_collection_modifyitems(config, items):          # noqa: F811
    _orig_modify(config, items)
    if os.name == "nt":
        for it in items:
            it.add_marker(pytest.mark.skip(reason="patch tool targets the Linux plugin:skill catalog (':' is illegal in NTFS names); run in the Linux/Cowork sandbox"))
