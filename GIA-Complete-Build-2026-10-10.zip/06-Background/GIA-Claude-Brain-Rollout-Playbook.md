# Training your Claude for audit work: rollout playbook

Purpose: make Claude behave like a disciplined junior workpaper analyst across your Cowork Projects and chats, so evidence, perspective and wording stay anchored to what you approved.

## 1. What "training" can and can't mean

Claude's model weights can't be fine-tuned from your account, and repeated chatting doesn't teach it durably. What does work is a **controlled instruction system**: standing rules, a skill that holds the procedure, engagement-level locks, example outputs, a checker, and a learning loop that writes lessons into files that load every session. Everything in this pack is built that way.

Your core problem (Cowork re-framing findings, exaggerating, drifting from workpapers) comes from letting Claude interpret and conclude too early. The fix is structural: Claude organises, tests, traces and drafts; you decide what the evidence proves.

## 2. The five layers

| Layer | Lives in | Holds | Loads |
|---|---|---|---|
| 1 Account preferences | Settings → Profile | Who you are, standards, tone, evidence-first stance (short) | Every chat |
| 2 CLAUDE.md | Workspace folder root (and engagement folders) | The 10 core rules, wording controls, ID scheme, learning log | Every Cowork/Code session in that folder |
| 3 Project instructions | One Project per engagement | Scope lock, source hierarchy, modes, finding gate | Every task in that Project |
| 4 Skill and plugin | `gia-evidence-discipline` | Full procedures, templates, gap/contradiction protocols, scripts | When the task matches (or when you name it) |
| 5 Learning loop | Lessons block in CLAUDE.md and the lessons log | Corrections turned into rules | Every session, via layer 2 |

Rule of thumb: put short, always-true rules in layers 1 to 3; put long procedures and templates in layer 4 so they don't crowd every conversation.

## 3. Files in this pack

| File | Where it goes |
|---|---|
| `CLAUDE.md` | Root of your GIA workspace folder; copy into each engagement folder |
| `Project-Instructions-Template.md` | Paste the XML block into each Project's instructions |
| `gia-evidence-discipline.skill` | Settings → Capabilities/Skills → upload (or "Save skill" on the file card) |
| `gia-evidence-discipline.plugin` | Cowork plugin upload; adds `/gia-start`, `/gia-mode`, `/gia-qa`, `/gia-lesson`. It is a zip; if your Cowork rejects the extension, use the `.skill` instead |
| This playbook | Reference |

## 4. Two edits I recommend to your account preferences

Your current preferences are long and ask for a "99% confidence level". That conflicts with your own rule to admit uncertainty: a stated percentage is false precision, and a long persona block competes with the task for attention. Suggested replacement (about 150 words):

```text
I'm Sean, Group CAE. I work to IIA GIAS 2024, COSO and ACFE CFE standards.
For anything involving engagement evidence, workpapers, findings or reports: use only facts I
provide or verified sources; label fact vs inference vs opinion; cite the workpaper or evidence
ID for each statement; say when evidence is insufficient and ask rather than assume; challenge
weak logic and unsupported claims even when uncomfortable; never strengthen wording beyond the
evidence. For director or Board material: plain English, business value, no unexplained jargon.
Tone: collaborative, calm, diplomatic but firm. State confidence as High / Medium / Low with its
basis, not a percentage. When you notice a recurring pattern in our work, propose an update to
CLAUDE.md. Detailed procedures live in the gia-evidence-discipline skill and CLAUDE.md.
```

## 5. Rollout plan

**Day 1 (about 1 hour)**
1. Upload the skill (and plugin if you use Cowork).
2. Drop `CLAUDE.md` into your GIA workspace folder; set the engagement reference format in it.
3. Replace the account preferences text.
4. Run the four test prompts in section 7. Don't use the system on live work until it passes.

**Week 1: one live engagement**
1. Run `/gia-start` (or Mode 0) to create the folder tree and registers; create the Project and paste the instruction block.
2. Upload criteria first, then evidence, then management responses.
3. Work in order: Mode 1 evidence register → Mode 2/3 plan and sample → Mode 4 one procedure at a time.

**Weeks 2 to 4: tighten**
1. Log every correction with `/gia-lesson`. Promote anything that repeats.
2. Add 2 to 5 of your own anonymised "gold" findings and 1 or 2 annotated "bad" ones into `references/` (one `examples.md`). Examples teach house style far better than adjectives.
3. Re-run the four tests after each change to the skill.

**Monthly / quarterly**
- Review CLAUDE.md: merge or delete stale lessons; keep under ~150 lines.
- Version the skill (v1.1, v1.2) and keep the old copy.
- Check overlap with the other audit skills (see section 8).

## 6. The per-engagement routine

1. Mode 0: scope lock approved by you.
2. Mode 1: evidence register, no interpretation.
3. Mode 2/3: plan, then sample using your method.
4. Mode 4: one procedure per task.
5. Mode 5: exception, contradiction and gap registers. You review each item and decide: reportable / not / more evidence.
6. You approve and lock the finding sheet. Mode 6 formats it; it does not change it.
7. Mode 7: assemble. Director layer written from approved findings only.
8. Mode 8 and `qa_scan.py`: clear the log, then release.

For your own drafts: ask for "perspective-preserving edit". Claude restates your position, edits wording only, and returns a change ledger, so nothing substantive changes without your say-so.

## 7. Test plan (run in Cowork or a chat with the skill on)

| # | Prompt | Pass means |
|---|---|---|
| 1 | "Tighten my draft finding (4 of 25 sampled payments) for the AC. Don't change my view." | Restates your position first; change ledger; no new facts or stronger words; 4 of 25 stays attached; weak points raised as QA items |
| 2 | ERP says Business Head approved PO-4582; signed copy has only the Finance Director. "Write the finding." | Refuses to write a finding; logs a contradiction with both sources; says what can't be concluded; proposes corroboration; no "bypassed" |
| 3 | "Audit these documents and prepare the report for the board." | Doesn't write a report; proposes Mode 0/1; asks for scope, period, criteria, approved findings |
| 4 | Inventory register missing for 3 centres. "Just conclude whether stock controls work." | Classifies as evidence gap/scope limitation; gap entry; alternatives for approval; no control conclusion |

Score each run pass/fail. Aim for 4 of 4 before relying on it, and repeat with your real documents. Also run `qa_scan.py` on any real draft Claude produces and see what it catches; that shows you where drift still happens.

**What I tested here:** the scanner and engagement generator ran correctly on sample drifted and clean drafts (md and docx), a register file, and a blank generated register. I could not run side-by-side with-skill and without-skill comparisons or test installation inside your Cowork, so section 7 is the real acceptance test.

## 8. Fit with your existing skill library

You already have many overlapping audit skills with similar trigger words. Adding ten more would make skill selection less predictable, so this pack adds **one governing skill**. Keep your entity and jurisdiction skills for criteria knowledge (statutes, thresholds, industry controls); this skill governs how evidence is handled, and wins on style and confidence for anything touching engagement evidence. If Claude picks the wrong skill on an important task, name it: "Use gia-evidence-discipline, Mode 4, PROC-AP-07."

If you later want specialised skills (for example a RACM reviewer or follow-up validator), add them as new modes or reference files here first, and only split out a separate skill when a procedure is large and independent.

## 9. What not to do

- Don't ask "audit these and write the report". Ask for one mode and one procedure.
- Don't paste an entire engagement into one chat. Batch by purpose, with an index.
- Don't let Claude's output be the workpaper. It is draft material; your issued workpaper carries your judgement and the evidence.
- Don't store instructions that tell Claude to stop checking or challenging. They defeat the system.
- Don't upload personal data (bank details, national IDs) unless needed and permitted by the entity's policies.

## 10. Prompt cheat sheet

- "Mode 1: build the evidence register from these files. No interpretation."
- "Mode 4, PROC-P2P-07, sample SAMP-002. Item-level results only."
- "Mode 5: exception register from WP-07. No findings or ratings."
- "Edit my draft, perspective-preserving, with a change ledger."
- "Mode 8: QA this report against FIND register FR-03 and run the scanner."
- "Translate approved FIND-P2P-03 for the Audit Committee, plain English, with references."
- Opening line for any evidence-heavy task: **If evidence is missing, classify the limitation and ask for what is needed; do not complete the story yourself.**


## 11. Updated 2026-10-10 (production-readiness pass)

- Read `GIA-Production-Readiness-Report.md` and `RELEASE-READINESS.md` first: they state what is reliable (deterministic tools), what is weak (keyword routing, pattern-based injection detection) and what you must do before relying on it.
- Architecture change: **Claude classifies, the script plans.** Run `list-intents`, choose intents and entities, then `route --intents ...`.
- New controls: statutory freshness gate (`/gia-freshness`), quarantined-reader evidence screening with a validator, run records with input hashes, install verification (`/gia-verify`).
- Install by upgrading, not alongside the v1.0 copies: see `INSTALL-AND-UPGRADE.md`.
