# Relationship map: how the installed library actually fits together

> Resolution status: a pack that resolves findings 2 to 12 is staged (see `resolution-log.md`). This document describes the library as scanned on 2026-10-04, before the pack is applied.

Basis: scan of 243 installed SKILL.md files on 2026-10-04 (`scripts/library_inventory.py`), plus a read of the routing and orchestration documents. Raw output: `library-health-2026-10-04.md`. Roles are Claude's reading of the files; items marked "inferred" need Sean's confirmation.

Contents: 1. Shape of the library · 2. Clusters and how they relate · 3. Findings · 4. Decisions for Sean · 5. What GCGO does about each

## 1. Shape of the library

| Group | Count | Relationship to GIA work |
|---|---|---|
| GIA core (governors, engines, fieldwork, reporting, fraud, ITGC, monitoring, file catalog) | about 40 | The audit method itself |
| Entity and jurisdiction specialists | 16 including legacy and one duplicate | Criteria knowledge for MY, IN-TN, IN-MH, MX, plus entities |
| Document and general tools | 8 public, 13 useful examples | Execution surfaces (docx, pdf, pptx, xlsx, research, skill-creator) |
| Market and data families: bigdata-com 27, daloopa 21, brightdata 21, lseg 16, nimble 16, data 10, legal 9, finance 8, enterprise-search 5, productivity 4, sp-global 3 | 140 | Supporting evidence-gathering and analysis; not audit methodology |
| Consumer-oriented examples (groceries, refunds, etc.) | about 21 | Not relevant to GIA; ignored by the registry |

82 skills are registered individually; the 140 family skills are registered by pattern, each with a "use for GIA" line and a caution.

## 2. Clusters and how they relate

```mermaid
flowchart TD
  S[Sean: Group CAE] --> G[GCGO front door]
  G --> GOV[Governors: gia-evidence-discipline, self-learning-loop]
  G --> FN[Function: grc-function, qaip]
  G --> ENG{One methodology engine}
  ENG --> L99[super-grc-audit-plugin-l99 v3.0]
  ENG --> MAS[master-audit-superagent]
  G --> FW[Fieldwork: cae-cowork-ai-plugin v6]
  G --> FL[Fleet: 11 subagents]
  G --> AK[AKOS memory and graph]
  G --> SP[Specialists]
  SP --> ENT[Entity and jurisdiction skills]
  SP --> FR[Fraud v2, ITGC, vendor, monitoring]
  SP --> RP[Reporting: board briefing, report conversion, external reporting]
  SP --> TL[Spreadsheet, data, finance, file catalog]
  SP --> MK[Market-data families]
  GOV -. rules apply to .-> SP
  FL -. returns reviewed by .-> G
```

Working relationships in plain terms:

- **Governors apply to everyone.** `gia-evidence-discipline` constrains how any specialist or engine handles evidence. `self-learning-loop` is the one place corrections are recorded.
- **Engines are alternatives, not partners.** L99 and master-audit-superagent each claim to run a whole lifecycle. Pick one per engagement.
- **Fieldwork tool sits under an engine.** `cae-cowork-ai-plugin` (v6.0) is the practical execution tool; `cae-command-centre` takes over after fieldwork for tracking and follow-up.
- **The fleet is a delegation mechanism, not a method.** Its eleven subagents (scout, analyst, mapper, validator, strategist, remediator, compliance, simulator, kaizen, linguist, cyber) do isolated work for whichever engine is in charge, and Sean or GCGO reviews each return.
- **AKOS is memory, not method.** It states that it does not replace any content skill; it holds project memory across sessions and entities.
- **Specialists supply criteria knowledge.** Entity and jurisdiction skills say what rules and typical controls apply; they should not decide how tests or findings are structured.
- **Reporting skills format approved content.** They come after the finding gate and before QA; they must not add or strengthen content.
- **Market-data families are suppliers.** Used for vendor or counterparty research and benchmarking, with privacy limits.

## 3. Findings

| # | Finding | Evidence | Why it matters |
|---|---|---|---|
| 1 | Seven orchestration or routing layers with overlapping roles | L99 Module 20, master-audit-superagent, fleet-orchestrator, AKOS, orchestration-protocol, grc-function directory, navigator | Which one runs is unpredictable; a new orchestrator would be an eighth. GCGO instead selects one conductor and consolidates routing |
| 2 | Installed L99 is v3.0 (20 modules); routing documents describe v5.0 (27-Article constitution, Module 24) | Version field and module list in the installed file; navigator and directory text | The constitution and the reconciliation are not in this environment; documents point at content that is not installed |
| 3 | Eight references to skills that are not installed in this environment | `library_inventory.py` dangling list: audit-risk-ecosystem, cae-fraud-investigation, cae-verification-discipline, epm-knowledge-graph, iar-universal-template, mac-audit-constitution-l99, my-healthcare-clinical-dialysis-audit, my-mfg-diecast-stamping-audit. (An earlier scan listed ten; two were false positives from the scanner: `data-quality-specialist` is an AKOS subagent file and `grc-agentic-fleet` is a plugin name. The scanner is fixed.) | The skills may exist in Sean's account but be disabled here, so the fix is install-aware routing, not deletion. Navigator prefers a dialysis skill that is not installed; report conversion cites a template that is not installed |
| 4 | Five identical duplicate skills | akos (user and plugin), gia-file-catalog (user and plugin), charlie-hills-code, debugger, pune-india-ops-audit | Double-matching on triggers; edits to one copy will not reach the other |
| 5 | "Legacy" skills are still the most-referenced | group-cae-fraud referenced by 11 skills; group-cae-reporting by 10; the directory marks both superseded | Archiving them without updating references would break pointers; the supersession was declared but not executed |
| 6 | Trigger overlap inside the GIA cluster | Description-word similarity: chennai-hr vs pune-hr 0.67; group-cae vs group-cae-core 0.59; chennai-ops vs pune-ops 0.59; group-cae-fraud vs v2 0.31; L99 vs managing-internal-audit 0.29 | Several skills match the same request; routing by trigger alone is unreliable |
| 7 | Four-version fieldwork cluster with colliding labels, and a wrong supersession claim | cae-audit-cowork-plugin (documents v3.0), v4, cae-cowork-plugin-v5, cae-cowork-ai-plugin (v6.0). Topic counts for walkthrough / ToD / ToE / sampling: 17 / 24 / 28 / 18 in v4 versus 1 / 3 / 3 / 1 in v6 | The navigator said v6 replaces v4; it does not. v4 is the detailed field-execution engine, v6 is the panel / AI / learning tool. Resolution: keep both, retire the unsuffixed original, absorb v5 into v6 |
| 8 | Orphans: nothing routes to them on purpose | master-audit-superagent, vendor-third-party-risk, audit-xls-review, pune-vda-tracker, payroll-ot-claims-audit | Reachable only by trigger match; registry now points at them from playbooks |
| 9 | Four learning mechanisms and overlapping rule sets | self-learning-loop, L99 Module 19, AKOS Module 7, /gia-lesson; Iron/Golden Rules vs evidence-discipline | Lessons get recorded in different places; rules can conflict. Proposed: self-learning-loop records, the others read |
| 10 | Directory and navigator are stale | Directory dated 2026-07-19 counts 28 items; 243 are installed | They cannot be the live map. Registry plus `library_inventory.py` replaces them as source of truth, subject to Sean's approval |
| 11 | One description over the 1024-character limit | brightdata-plugin:scraper-studio, 1,229 characters | Outside the library's own design principle; not a GIA skill |
| 12 | Nine skills fail the structural validator | `version` and `tags` as top-level frontmatter keys (cae-cowork-ai-plugin, cae-audit-cowork-plugin and v4, cae-command-centre, managing-internal-audit, my-phc-clinic-audit, payroll-ot-claims-audit, racm-ecosystem, super-grc-audit-plugin-l99). Five more flagged were plugin command files, a false positive | They load today, but packaging tools reject them. Mechanical fix: move the keys under `metadata:` |
| 13 | Coverage gaps | No skill for India outside TN and MH (for example Puducherry); entities MKSDL, MABI, Fleet Parade, SAPL, BCP, Jacks named in skill text but absent from the file taxonomy; engagement ID ordering varies | Statutory content for those must come from verified sources; entity codes need a decision |

## 4. Decisions for Sean (GCGO recommends; it changes nothing itself)

1. **Restore or confirm the L99 master.** Is v5.0 (with the 27 Articles) the intended master? If yes, re-upload it. If v3.0 is current, correct the navigator and directory.
2. **Archive the five duplicates**, keeping the plugin-tier copies, then re-scan.
3. **Execute or retract the supersession claims.** Either archive group-cae, group-cae-core, group-cae-fraud, managing-internal-audit (and update the 10 to 11 skills that reference them), or mark them "supported fallback" so the status is honest.
4. **Fieldwork tools:** keep v4 (detailed execution) and v6 (panels, AI, learning); retire the unsuffixed original; absorb v5 into v6.
5. **Pick the learning mechanism of record** (recommended: `self-learning-loop`).
6. **Choose the dialysis skill** (my-hc-dialysis-audit is installed; the navigator's preferred one is not) and the report template source.
7. **Supersede the navigator and directory** with the GCGO registry, or keep them and let GCGO treat them as read-only references.
8. **Add entity codes** for MKSDL, MABI, Fleet Parade, SAPL, BCP, Jacks if they are audit entities, and pick one engagement-ID format.
9. **Decide whether to commission** a Puducherry / other-state jurisdiction skill, given the Gencor matter is outside TN and MH.

## 5. What GCGO does about each

| Finding | Behaviour now |
|---|---|
| 1 | Chooses one conductor and one engine per engagement; others become supporting references |
| 2, 3 | Names the missing skill, uses the stated fallback, logs drift; does not pretend v5.0 is installed |
| 4 | Resolves to the registry's canonical copy and flags the duplicate |
| 5 | Uses legacy skills only as fallback or where nothing current covers the task |
| 6 | Entity-specific skill leads; generic supports; the router shows which was chosen and why |
| 7 | Routes detailed test execution to v4 and panels/analysis to v6; both appear in the fieldwork playbook |
| 8 | Routes to orphans deliberately through playbooks |
| 9 | Sends corrections to `self-learning-loop`; evidence rules win on conflict |
| 10 | Re-scan command and registry replace the stale directory |
| 12 | Not a routing issue; fixed in the resolution pack (Phase 3) |
| 13 | Warns when a state or entity outside coverage is named |
