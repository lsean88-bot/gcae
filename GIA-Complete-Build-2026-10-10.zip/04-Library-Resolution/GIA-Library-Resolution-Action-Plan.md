# GIA skill library: action plan and resolution (2026-10-04)

Prepared for Sean, Group CAE. Basis: scan of 243 installed skills, topic-coverage checks on every legacy skill before retiring it, and a simulation of the resulting library.


## Update 2026-10-10: what changed since this plan was first issued

- **A new, higher-priority finding:** at least eight installed India payroll skills still present the EPF wage ceiling as INR 15,000 "current". It reportedly became INR 25,000 on 17 September 2026 (verified across several independent professional sources; the Gazette itself was not opened). Phase 2 and Phase 3 packages for `chennai-india-ops-audit`, `pune-india-ops-audit`, `cae-cowork-ai-plugin`, `payroll-ot-claims-audit` and `in-manufacturing-audit` now carry a dated **Statutory change notice**, and the new `gia-statutory-freshness` skill is the gate. Treat any EPF test for pay periods from 17 September 2026 as unverified until the notice is installed.
- **Upgrade, not first install:** your account already holds v1.0 copies of `gcgo-orchestrator` (with its command skills `gcgo`, `gcgo-brief`, `gcgo-health`, `gcgo-selftest`, `gcgo-status`) and `gia-evidence-discipline`. Install the new versions by **replacing** the old ones (delete the old copy first), then run `verify_install.py` (or `/gia-verify`); it warns about older or duplicate copies. See `INSTALL-AND-UPGRADE.md`.
- **New skills to install:** `gia-statutory-freshness` and `puducherry-india-ops-audit` (research-grade). Either install the single `gia-governance-suite.plugin` or the four `.skill` files, not both.
- Phase 3 now also includes `in-manufacturing-audit` (change notice).
- Open items needing you are unchanged except that a Puducherry skill now exists (research-grade; verify before use).

## 1. Bottom line

I resolved what can be resolved from here and staged it as an upload pack. **Nothing has been applied to your account.** The sandbox cannot change your installed skills, so each fix is a file you upload, with a full backup for rollback.

| Status | Items |
|---|---|
| Fixed in the pack (verified by simulation) | 5 duplicate installs, 8 references to absent skills, stale navigator and directory, 8 legacy skills consolidated, 9 skills failing the validator, wrong supersession claim for the v4 fieldwork plugin |
| Needs your action (clicks, not information) | Deleting the duplicates, uploading the pack, checking whether 8 "absent" skills are only disabled |
| Needs information only you have | L99 v5.0 file, blank IAR template (v8.2), entity list confirmation, whether to commission a Puducherry skill |

Two corrections to what I told you earlier: the dangling-reference count is **eight, not ten** (two were scanner false positives, now fixed), and **`cae-audit-cowork-plugin-v4` is not replaced by v6** (its walkthrough, ToD, ToE and sampling detail is 17/24/28/18 mentions against 1/3/3/1 in v6), so it stays.

## 2. Verified result (simulated library after the pack)

| Measure | Now | After |
|---|---|---|
| Installed skills | 243 | 239 |
| Identical duplicate groups | 5 | 0 |
| References to absent skills in routing docs | 8 | 1 (see Phase 3 optional) |
| Overlapping trigger pairs (similarity 0.5 or more) in the GIA cluster | 10 | 2 (chennai vs pune ops, which differ by state; two plugin commands) |
| Registry drift | 0 | 0 |
| Staged skills passing structural validation | n/a | 22 of 22 |

This verifies structure and references. It does not prove the model routes correctly on real requests; the acceptance prompts in section 6 do that.

## 3. Action plan

### Phase 0: before touching anything (about 20 minutes, you)
1. Save `0-backup/backup-originals-2026-10-04.zip` outside Claude. It holds the original of every skill the pack changes. This is your rollback.
2. In your Skills settings, check whether these exist but are disabled or sit in another workspace: `my-healthcare-clinical-dialysis-audit`, `my-mfg-diecast-stamping-audit`, `iar-universal-template`, `epm-knowledge-graph`, `mac-audit-constitution-l99`, `audit-risk-ecosystem`, `cae-fraud-investigation`, `cae-verification-discipline`; and which version of `super-grc-audit-plugin-l99` is yours (installed here: v3.0, 20 modules; the navigator describes v5.0 with a 27-Article constitution). Enable or upload what exists. Tell me what you find and I will update the registry.

### Phase 1: remove duplicates and fix routing (about 45 minutes, you)
Resolves findings 3, 4, 9, 10.
1. Delete the duplicate installs, keeping the canonical copy: standalone `debugger`, standalone `charlie-hills-code`, the user-level `akos-enterprise-orchestrator`, the user-level `gia-file-catalog`. In the `mktron-pune-vda-compliance` plugin, disable its bundled `pune-india-ops-audit` (the standalone copy is the one Phase 2 upgrades).
2. Standalone skills: delete the installed version, then upload from `1-phase1-standalone/` (`mktron-grc-function`, `grc-engagement-charter`, `master-audit-superagent`).
3. Plugin-bundled skills cannot be replaced one by one: copy the folders in `1-phase1-plugin-source-patches/` over your plugin sources (`mktron-sentinel` for the navigator, the AKOS plugin for `akos-enterprise-orchestrator`) and re-upload those plugins. If your plugin layout differs from `skills/<name>/`, adjust the path.
4. Install `gcgo-orchestrator.skill` (or the `.plugin`) and the updated `CLAUDE.md`.
5. Verify: run `/gcgo-health`. Expect no duplicate groups and no registry drift.

What changed: every reference to an absent skill now reads "(if installed)" with a stated fallback; the navigator and directory are regenerated from the scan; the master-audit-superagent note says to use one engine per engagement; AKOS names `self-learning-loop` as the learning mechanism of record.

### Phase 2: consolidate legacy skills (about 60 minutes, you; after Phase 1 is verified)
Resolves findings 5, 6, 7.
Upload order matters so no content is ever missing: **successors first, then redirects.**
1. Upload `chennai-india-ops-audit`, `pune-india-ops-audit` (now carrying the full legacy HR skills under `references/legacy-hr-audit/`) and `cae-cowork-ai-plugin` (carrying v5 under `references/legacy-v5/`).
2. Then upload the redirects: `chennai-hr-audit`, `pune-hr-audit`, `cae-cowork-plugin-v5`, `group-cae`, `group-cae-core`, `managing-internal-audit`, `group-cae-fraud`, `cae-audit-cowork-plugin`. Each is a short stub pointing to its successor, so existing references still resolve.
3. Kept on purpose: `cae-audit-cowork-plugin-v4`, `group-cae-reporting`, `board-chairman-briefing`, `my-hc-dialysis-audit`.
4. Verify: `/gcgo-health`, then the acceptance prompts.

Why these choices (evidence, not assumption): `group-cae-fraud-v2` covers every sampled topic at equal or higher depth; L99 covers the persona skills (the full originals remain in the backup because L99 is thinner on SOX, COBIT and ERM); the HR skills are deeper on contract labour (10 vs 3 and 12 vs 5 mentions), so they are absorbed, not discarded. The keyword method is a proxy; the backup is the safety net.

### Phase 3: validator hygiene (about 20 minutes, you; low priority)
Resolves finding 12. Five skills have `version` and `tags` at the top level of their frontmatter, which packaging tools reject (the skills load today). Upload the five in `3-phase3-hygiene/`. The L99 patch is in a separate folder: **apply it only if v3.0 stays your master.** If you restore v5.0, make the same one-line change to that file instead (move `version` and `tags` under `metadata:`).

### Phase 4: needs your input
| Item | What I need | What I will do |
|---|---|---|
| L99 master | The v5.0 file, or confirmation v3.0 is current | Update the registry, directory and navigator wording |
| IAR template | The blank template file (v8.2) | Rebuild `iar-universal-template` so report conversion stops pointing at an absent skill |
| Entity codes | Are MKSDL, MABI, Fleet Parade, SAPL, BCP and Jacks audit entities? | Add them to the registry and file taxonomy |
| Other Indian states | Whether to commission a Puducherry (or other state) skill, given the Gencor matter is outside TN and MH | Scope it as a separate project: statutory research must be sourced and dated, so it should not be rushed |
| `scraper-studio` description | Optional | Trim from 1,229 to 1,024 characters (not a GIA skill) |

## 4. Decisions I took on your behalf (reverse any you disagree with)

You asked me to resolve everything, so I adopted the recommended option on each decision from the relationship map:

1. L99: keep v3.0 as the working engine until you supply v5.0.
2. Duplicates: delete the five.
3. Supersession: execute for eight skills, keep three with documented reasons.
4. Fieldwork tools: keep v4 (detail) and v6 (panels); retire the unsuffixed original; absorb v5.
5. Learning mechanism of record: `self-learning-loop`.
6. Dialysis: `my-hc-dialysis-audit` until the other skill is confirmed to exist.
7. Navigator and directory: rewritten as install-aware lookups; the registry plus scan is the live map.
8. Engagement IDs: `GIA-<ENTITY>[-<SITE>]-<YYYY>-<MMM>-<TOPIC>-<NNN>` for new engagements only; issued IDs are never renamed.
9. Puducherry skill: recommended as a separate project, not started.

## 5. Risks and how they are handled

| Risk | Handling |
|---|---|
| Replacing a skill loses content | Full backup zip; absorbed content kept in `references/`; redirects instead of deletions |
| An upload overwrites a newer version in another environment | Phase 0 check; L99 patch kept optional |
| Redirect stubs confuse routing | They carry no task vocabulary and name their successor; test with prompt 4 below |
| Keyword coverage is only a proxy | Backup; run real tasks on each absorbed skill before relying on it |
| Plugin-bundled skills cannot be swapped singly | Source patches provided; plugin re-upload required |

## 6. Acceptance tests (after Phases 1 and 2)

| # | Prompt | Pass means |
|---|---|---|
| 1 | "GCGO, route: start the MKAPL Pune stamping audit, delegate the data forensics, and get it board-ready" | Setup, analytics and board pack in that order; Maharashtra skill chosen; gates marked; board pack only from approved findings |
| 2 | "Which skill for contract labour in a Chennai payroll audit?" | `chennai-india-ops-audit`, pointing to its legacy HR reference |
| 3 | "Whistleblower allegation about a vendor at MKPC" | Confidentiality gate first; no lookups on named people; fraud classification left to you |
| 4 | "Use group-cae to draft an audit plan" | Redirects to L99 without losing the task |
| 5 | "Audit these documents and prepare the board report" | Stops and scopes (Mode 0 or 1) |
| 6 | `/gcgo-health` | No duplicates, no drift, at most one absent-skill reference |

## 7. Keeping it resolved

Monthly: run `/gcgo-health`; resolve every drift line; review the lessons block in `CLAUDE.md`. After any skill is added, renamed or retired, update the registry (`scripts/build_registry.py`) and re-scan. Record why each change was made in `references/resolution-log.md`.

## 8. Limits

The pack was built and validated in a sandbox; I could not test installation or routing inside your account. Skill roles in the registry are my reading of the files. Where I say a skill is covered by its successor, that rests on topic counts plus the skills' own stated supersession, not on reading every line.
