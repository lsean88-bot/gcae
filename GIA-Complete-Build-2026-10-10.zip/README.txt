GIA Governance Suite v1.2.1 (2026-10-10)
Start with 01-Read-First. Install the single .plugin OR the four .skill files, not both, and remove the older v1.0 and standalone copies first (see INSTALL-AND-UPGRADE.md, section 'What your live install needs').
Verify integrity with MANIFEST.sha256 (sha256sum -c MANIFEST.sha256 after extracting).
