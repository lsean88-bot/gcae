---
description: "Start an engagement: independence check, strategy posture, plan, RACM seed."
argument-hint: "[entity or plant] [period]"
---
Delegate to the audit-planner agent or skill. Collect entity, scope and period. Run the independence check, choose the posture, draft the plan, run plan_consistency.py. List open dependencies. Follow gia-core:iron-rules. Do not state statutory rates; cite the register.
