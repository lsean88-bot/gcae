---
description: "Track plant readiness: PBC received, statutory register status, open dependencies."
argument-hint: "[entity or plant] [period]"
---
Delegate to the gia-fieldworker agent or skill. For India follow gia-audit:gia-pack-india references/plant-readiness-tracker.md (statutory and certification workstreams stay separate). Read the relevant pack register and PBC list. Output one row per plant with counts of VERIFIED, SECONDARY-ONLY and UNVERIFIED rows and outstanding PBC items. Follow gia-core:iron-rules. Do not state statutory rates; cite the register.
