---
description: "Run the monthly audit cycle: status, plan variance, evidence chain, follow-up."
argument-hint: "[entity or plant] [period]"
---
Delegate to the gia-audit-lifecycle agent or skill. Follow references/phase-map.md for the current month. Report plan variance, open follow-ups, and register rows past their verified-on date. Follow gia-core:iron-rules. Do not state statutory rates; cite the register.
