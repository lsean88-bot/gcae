---
description: "Compute an ASSUMED ToE sample size from frequency, risk, triggers and population."
argument-hint: "[entity or plant] [period]"
---
Delegate to the racm-mapper agent or skill. Run scripts/sample_size.py with the inputs. Print the result and state that the table is ASSUMED until sourced. Follow gia-core:iron-rules. Do not state statutory rates; cite the register.
