---
description: "Generate the PBC request list for a process or plant."
argument-hint: "[entity or plant] [period]"
---
Delegate to the gia-fieldworker agent or skill. Use references/pbc-presets.md in gia-fieldwork-workpapers. Output a table of item, owner role, due date, status. Follow gia-core:iron-rules. Do not state statutory rates; cite the register.
