# gia-audit

Audit execution plugin (S2).

## Contents
- 8 skills: lifecycle, engagement planning, RACM/ICFR testing, fieldwork workpapers, standards navigator, packs for India, Mexico, Malaysia.
- 6 agents: audit-planner, racm-mapper, gia-fieldworker, statutory-validator, horizon-scanner, itgc-erp-reviewer.
- 5 commands: gia-engage-start, gia-monthly-cycle, gia-pbc, gia-sample-size, gia-plant-readiness-tracker.
- Scripts: sample_size.py, deficiency_aggregation_check.py, plan_consistency.py.

## Conventions
- Deficiency scale CD / SD / MW.
- Statutory values live only in each pack's statutory-register file.
- Register status: VERIFIED, SECONDARY-ONLY or [UNVERIFIED], with source URL and verified-on date.
- India: Labour Codes in force from 21-Nov-2025; pre-Code Act citations are flagged "superseded — re-map".
- Sample sizes are ASSUMED until sourced.

## Tests
Run each file in tests/ with `python3 -I`. Results in tests/RESULTS.md.

## Cross-suite
Uses gia-core:iron-rules, gia-fraud:gia-fraud-analytics, gia-report-qa:gia-ia-report.
