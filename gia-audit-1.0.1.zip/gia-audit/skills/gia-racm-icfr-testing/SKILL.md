---
name: gia-racm-icfr-testing
description: "RACM, control matrix, ICFR, COSO 2013, ToD, ToE, sample size, deficiency, material weakness, key control. Use when building a RACM or testing control design or operation. Do NOT use for statutory field tests such as payroll or GST (use gia-audit:gia-fieldwork-workpapers), ITGC detail (use the gia-audit:itgc-erp-reviewer agent) or fraud (use gia-fraud:gia-fraud-investigation)."
---

# RACM and ICFR testing

## Method in order
1. Build or review the RACM: `references/racm-standard.md` (record structure, assertions, rating scale, residual rule, control classification, common mistakes). Row completeness is checked by agent `racm-mapper`.
2. Map to COSO IC 2013: `references/coso-ic-map.md`. Where ICFR reporting under the ICAI guidance note applies: `references/icai-gn.md`. US-style SOX framing only if the engagement is in that regime: `references/coso-sox-testing.md`.
3. Test of design: `references/tod.md`. ToD precedes ToE; a design-deficient control is not ToE-tested.
4. Test of operating effectiveness: `references/toe.md` (procedure) and `references/toe-sampling.md` (single sample-size table).
5. Classify and aggregate deficiencies: `references/deficiency-aggregation.md`. Scale is **CD, SD, MW**. The older "minor" label maps to CD. Use SD and MW wording only where ICFR or SOX-style reporting applies; otherwise use CD plus a severity rating and say so.
6. Surveillance and collaboration: `red-flags.md`, `3lod.md` (both under `references/`). Version snapshots: `references/version-control.md`.
7. Prompt blocks for analysis: `references/prompt-blocks.md`. Framework additions (DE/OE, SOX 302/404 and top-down steps, technique-by-situation, analytics and sampling choices, fraud concepts, interview techniques): `references/framework-reference-additions.md`.

## Scripts
- `scripts/sample_size.py`: ToE sample size by frequency, risk band and triggers. **Every number is ASSUMED** (not sourced to AS 2201, ICAI GN or any primary text); the output says so. Both source tables are recorded in `references/toe-sampling.md` for the CAE decision.
  `python3 -I ${CLAUDE_PLUGIN_ROOT}/skills/gia-racm-icfr-testing/scripts/sample_size.py --frequency monthly --risk high --triggers first_time,manual`
- `scripts/deficiency_aggregation_check.py`: completeness check of the aggregation register (required fields, class values, aggregated class never below standalone, related ids resolve, management response on SD and MW, CD and SD aggregation triggers, ITGC dependency).
  `python3 -I ${CLAUDE_PLUGIN_ROOT}/skills/gia-racm-icfr-testing/scripts/deficiency_aggregation_check.py register.csv`

## Rules specific to this skill
- Evidence grades and the strict R3 test come from `gia-core:iron-rules`. Do not re-rank evidence locally.
- RACM rule identifiers use the `RACM-nn` namespace defined in `gia-core:iron-rules`; do not create a local numbered rule list.
- Critical inherent risk is never rated below High residual. If ToD is inadequate, residual equals inherent.
- Automated controls cannot be relied on if ITGC is ineffective.
- Final deficiency class is assigned only after the aggregation register is complete.
- Owners are named roles or people, never a department.
- A walkthrough is not a ToE sample.

## Hand-offs
Statutory compliance tests: `gia-audit:gia-fieldwork-workpapers`. Findings in 5C: same. Report: `gia-report-qa:gia-ia-report`. Fraud indicators in a RACM scan: `gia-fraud:gia-fraud-investigation`.

## Open decisions for the CAE
Confirm or replace the ASSUMED sample-size table; confirm whether the SD/MW pair applies to each entity's reporting regime.
