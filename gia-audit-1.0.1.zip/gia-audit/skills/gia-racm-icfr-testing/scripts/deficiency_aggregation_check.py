#!/usr/bin/env python3
"""Deficiency aggregation register completeness check (CD / SD / MW).

Input: CSV or JSON list of rows. Column names are matched case-insensitively with
non-alphanumerics ignored (Def ID, def_id, DefID all match).
Required: def_id, control_id, finding_ref, process, coso_component, standalone_class,
          aggregated_class, rationale
Optional: related_to (comma/semicolon list of def_ids), mgmt_response_ref,
          itgc_dependent_controls (count or list), itgc_failure (yes/no)

Usage: python3 -I deficiency_aggregation_check.py register.csv [--json]
Exit code 1 if any ERROR is raised, 0 otherwise (warnings do not fail).
"""
import csv
import json
import re
import sys
from collections import defaultdict

CLASSES = {"CD": 1, "SD": 2, "MW": 3}
REQUIRED = ["defid", "controlid", "findingref", "process", "cosocomponent",
            "standaloneclass", "aggregatedclass", "rationale"]
CD_TO_SD = 3     # three or more CDs in the same process may constitute an SD
SD_TO_MW = 2     # two or more SDs in the same COSO component may constitute an MW
ITGC_MW = 3      # ITGC failure with more than 3 dependent automated controls -> MW trigger


def norm(k):
    return re.sub(r"[^a-z0-9]", "", str(k).lower())


def load(path):
    if path.lower().endswith(".json"):
        with open(path, encoding="utf-8") as f:
            rows = json.load(f)
    else:
        with open(path, newline="", encoding="utf-8-sig") as f:
            rows = list(csv.DictReader(f))
    return [{norm(k): ("" if v is None else v) for k, v in r.items()} for r in rows]


def split_ids(v):
    if isinstance(v, list):
        return [str(x).strip() for x in v if str(x).strip()]
    return [x.strip() for x in re.split(r"[;,]", str(v)) if x.strip()]


def count_dep(v):
    if isinstance(v, list):
        return len(v)
    s = str(v).strip()
    if not s:
        return 0
    if s.isdigit():
        return int(s)
    return len(split_ids(s))


def check(rows):
    issues = []

    def add(sev, rid, msg):
        issues.append({"severity": sev, "row": rid, "message": msg})

    if not rows:
        add("ERROR", "-", "register is empty")
        return issues
    ids = [str(r.get("defid", "")).strip() for r in rows]
    seen = set()
    for i, r in enumerate(rows):
        rid = ids[i] or "row%d" % (i + 1)
        for f in REQUIRED:
            if str(r.get(f, "")).strip() == "":
                add("ERROR", rid, "missing required field: %s" % f)
        if ids[i] in seen:
            add("ERROR", rid, "duplicate def_id")
        seen.add(ids[i])
        sc = str(r.get("standaloneclass", "")).strip().upper()
        ac = str(r.get("aggregatedclass", "")).strip().upper()
        for label, c in (("standalone_class", sc), ("aggregated_class", ac)):
            if c and c not in CLASSES:
                hint = " (MN is retired; map to CD)" if c == "MN" else ""
                add("ERROR", rid, "%s '%s' not in CD/SD/MW%s" % (label, c, hint))
        if sc in CLASSES and ac in CLASSES and CLASSES[ac] < CLASSES[sc]:
            add("ERROR", rid, "aggregated class %s is below standalone class %s" % (ac, sc))
        for rel in split_ids(r.get("relatedto", "")):
            if rel not in ids:
                add("ERROR", rid, "related_to '%s' does not resolve to a def_id" % rel)
            elif rel == ids[i]:
                add("ERROR", rid, "related_to refers to itself")
        if ac in ("SD", "MW") and not str(r.get("mgmtresponseref", "")).strip():
            add("ERROR", rid, "%s requires a management response reference" % ac)
        if str(r.get("itgcfailure", "")).strip().lower() in ("yes", "y", "true", "1"):
            n = count_dep(r.get("itgcdependentcontrols", ""))
            if n == 0:
                add("ERROR", rid, "ITGC failure recorded without dependent automated controls listed")
            elif n > ITGC_MW and ac != "MW":
                add("WARN", rid, "ITGC failure with %d dependent controls: MW trigger, aggregated class is %s" % (n, ac or "blank"))

    # aggregation triggers
    by_proc = defaultdict(list)
    by_comp = defaultdict(list)
    for i, r in enumerate(rows):
        sc = str(r.get("standaloneclass", "")).strip().upper()
        if sc == "CD":
            by_proc[str(r.get("process", "")).strip().lower()].append(i)
        if sc == "SD":
            by_comp[str(r.get("cosocomponent", "")).strip().lower()].append(i)
    for proc, idx in by_proc.items():
        if proc and len(idx) >= CD_TO_SD:
            ok = any(str(rows[i].get("aggregatedclass", "")).strip().upper() in ("SD", "MW") for i in idx)
            if not ok:
                add("WARN", ",".join(ids[i] for i in idx),
                    "%d CDs in process '%s': aggregation to SD must be considered and the decision recorded in the rationale" % (len(idx), proc))
    for comp, idx in by_comp.items():
        if comp and len(idx) >= SD_TO_MW:
            ok = any(str(rows[i].get("aggregatedclass", "")).strip().upper() == "MW" for i in idx)
            if not ok:
                add("WARN", ",".join(ids[i] for i in idx),
                    "%d SDs in COSO component '%s': aggregation to MW must be considered and the decision recorded in the rationale" % (len(idx), comp))
    return issues


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if not argv or argv[0] in ("-h", "--help"):
        print(__doc__)
        return 2
    as_json = "--json" in argv
    path = [a for a in argv if not a.startswith("--")][0]
    issues = check(load(path))
    errs = [i for i in issues if i["severity"] == "ERROR"]
    if as_json:
        print(json.dumps({"errors": len(errs), "issues": issues}, indent=2))
    else:
        for i in issues:
            print("%-5s %-14s %s" % (i["severity"], i["row"], i["message"]))
        print("RESULT: %s (%d errors, %d warnings)" % ("FAIL" if errs else "PASS", len(errs), len(issues) - len(errs)))
    return 1 if errs else 0


if __name__ == "__main__":
    sys.exit(main())
