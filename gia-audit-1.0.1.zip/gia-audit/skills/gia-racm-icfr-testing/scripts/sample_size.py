#!/usr/bin/env python3
"""ToE sample-size calculator (single table). Every number is ASSUMED.

The table is a house convention taken from the lifecycle spine skill. Neither source
skill cites PCAOB AS 2201, ICAI GN or any primary text for the values. See
references/toe-sampling.md for both source tables and the decision log.

Usage:
  python3 -I sample_size.py --frequency monthly --risk high --triggers first_time,manual
  python3 -I sample_size.py --frequency daily --risk standard --population 240 --json
"""
import argparse
import json
import math
import sys

ASSUMED_NOTE = ("ASSUMED: sample sizes are a house convention, not sourced to AS 2201, "
                "ICAI GN or other primary text. CAE to confirm before external use.")

# frequency -> (annual population, standard, high, low)
TABLE = {
    "daily": (250, 25, 30, 15),
    "weekly": (52, 20, 25, 10),
    "monthly": (12, 5, 8, 3),
    "quarterly": (4, 2, 4, 2),
    "annual": (1, 1, 1, 1),
}
FREQUENCIES = list(TABLE) + ["continuous", "adhoc"]
# trigger -> percentage change applied on top of the risk-band value
UPLIFTS = {"first_time": 25, "prior_exceptions": 50, "key_fs": 25, "manual": 25}
REDUCTIONS = {"prior_clean": -25}  # only for low-risk, unchanged control
RISKS = ("low", "standard", "high")


class SampleError(ValueError):
    pass


def compute(frequency, risk="standard", triggers=(), population=None, itgc_effective=None):
    if frequency not in FREQUENCIES:
        raise SampleError("unknown frequency: %s" % frequency)
    if risk not in RISKS:
        raise SampleError("unknown risk band: %s" % risk)
    triggers = [t for t in triggers if t]
    for t in triggers:
        if t not in UPLIFTS and t not in REDUCTIONS:
            raise SampleError("unknown trigger: %s (valid: %s)" %
                              (t, ", ".join(list(UPLIFTS) + list(REDUCTIONS))))
    if "prior_clean" in triggers and risk != "low":
        raise SampleError("prior_clean reduction applies only to risk band 'low'")
    if population is not None and population < 1:
        raise SampleError("population must be at least 1")

    out = {"frequency": frequency, "risk": risk, "triggers": triggers, "assumed": True,
           "note": ASSUMED_NOTE, "sample": None, "method": "attribute sample", "basis": ""}

    if frequency == "continuous":
        if itgc_effective is None:
            raise SampleError("continuous (automated) control requires --itgc-effective yes|no")
        if itgc_effective:
            out.update(sample=1, method="configuration inspection or re-performance",
                       basis="Automated control, ITGC effective: test once per period (table value 1; "
                             "source range 1 to 3).")
        else:
            out.update(sample=None, method="manual compensating control at full sample",
                       basis="ITGC not effective: automated control cannot be relied on. Test the "
                             "manual compensating control using its own frequency row and raise the "
                             "ITGC failure as a deficiency.")
        return out
    if frequency == "adhoc":
        method = {"high": "stratified random or MUS", "standard": "MUS or random",
                  "low": "judgmental"}[risk]
        out.update(sample=None, method=method,
                   basis="Ad hoc / transaction population: no numeric table value; size by method and "
                         "document the basis.")
        return out

    pop_default, std, high, low = TABLE[frequency]
    pop = population if population is not None else pop_default
    base = {"standard": std, "high": high, "low": low}[risk]
    pct = sum(UPLIFTS.get(t, 0) + REDUCTIONS.get(t, 0) for t in triggers)
    raw = base * (100 + pct) / 100.0
    # round half up, never below 1, never above population
    n = max(1, int(math.floor(raw + 0.5)))
    capped = n > pop
    n = min(n, pop)
    parts = ["table value for %s/%s = %d" % (frequency, risk, base)]
    if triggers:
        parts.append("triggers %s = %+d%%" % (",".join(triggers), pct))
    if capped:
        parts.append("capped at population %d" % pop)
    if frequency == "annual" and risk == "high":
        parts.append("also inspect the prior-year instance")
    out.update(sample=n, population=pop, basis="; ".join(parts) + ".")
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--frequency", required=True, choices=FREQUENCIES)
    ap.add_argument("--risk", default="standard", choices=RISKS)
    ap.add_argument("--triggers", default="", help="comma list: %s" %
                    ",".join(list(UPLIFTS) + list(REDUCTIONS)))
    ap.add_argument("--population", type=int)
    ap.add_argument("--itgc-effective", choices=("yes", "no"))
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)
    itgc = None if a.itgc_effective is None else a.itgc_effective == "yes"
    try:
        r = compute(a.frequency, a.risk, a.triggers.split(","), a.population, itgc)
    except SampleError as e:
        print("ERROR: %s" % e, file=sys.stderr)
        return 2
    if a.json:
        print(json.dumps(r, indent=2))
    else:
        print("Sample: %s" % (r["sample"] if r["sample"] is not None else "n/a"))
        print("Method: %s" % r["method"])
        print("Basis : %s" % r["basis"])
        print(r["note"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
