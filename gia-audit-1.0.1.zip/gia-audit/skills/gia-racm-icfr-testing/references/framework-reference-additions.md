# Framework reference additions (ported from the retired framework-reference skill)

Content from the retired framework reference that the RACM references did not yet carry. Framework detail that already lives elsewhere is pointed to, not copied: COBIT and ITAF in `gias-navigator/references/it-audit-cobit.md`, GARP risk tools in `gias-navigator/references/garp-risk-tools.md`, GIAS domains, standards and topical requirements in `gias-navigator`, SOX phases and scripts in `coso-sox-testing.md`, fraud method in `gia-fraud:gia-fraud-investigation`.

## Contents
- Design versus operating effectiveness
- SOX 302 and 404, top-down risk assessment
- Testing techniques by situation
- Data analytics and sampling choices
- Fraud concepts used when scoping
- Interview techniques
- Finding rating labels
- Pre-issuance checklist items beyond the Quality Gate
- Not ported, and why

## Design versus operating effectiveness
- Design effectiveness (DE): if the control operates as designed, would it prevent or detect a material misstatement? Techniques: walkthrough, inquiry, inspection of design documents, observation.
- Operating effectiveness (OE): did it operate as designed over the test period? Techniques: re-performance, inspection of evidence, sample testing, re-execution.
Procedure: `tod.md`, `toe.md`, `toe-sampling.md`. The report distinguishes a design deficiency from an operating failure.

## SOX 302 and 404, top-down risk assessment
Use only where the engagement is in a SOX-style regime (decide and state applicability first; see `deficiency-aggregation.md`).
- Section 302: CEO and CFO certify the financial statements, the effectiveness of disclosure controls and procedures, and any significant changes or material weaknesses, each quarter and year. Internal audit role: review the disclosure committee process, test process-owner sub-certifications, and check that disclosure-control deficiencies are escalated into the certification. Testing rhythm in the source: quarterly review controls plus annual roll-forward.
- Section 404(a): management assesses and reports on ICFR annually. 404(b): external auditor attestation using the PCAOB AS 2201 top-down approach.
- Top-down steps: (1) financial-statement level: material accounts, disclosures, assertions; (2) process level: map risks to processes; (3) key controls addressing what could go wrong for each assertion; (4) test design, then operating effectiveness; (5) evaluate deficiencies (CD, SD, MW).
- Criteria wording in the source: SD is a more-than-remote chance that a more-than-inconsequential misstatement is not prevented or detected; MW is a reasonable possibility that a material misstatement is not prevented or detected and needs disclosure. These paraphrases are [UNVERIFIED] against the standard; confirm before quoting.

## Testing techniques by situation
| Situation | Technique |
|---|---|
| Design effectiveness, once per year | Walkthrough: inquiry, observation, inspection, re-performance |
| Key-control operating effectiveness | Sample testing, statistical (monetary unit or random) or judgmental |
| High-risk manual controls | Auditor re-performance |
| Standard controls | Inspection of approvals, reconciliations, reports |
| Automated preventive controls | Confirm ITGC effective first (`itgc-erp-reviewer`), then reduce manual samples; if ITGC fails, no reliance |
| Interim to year-end | Roll-forward of earlier testing for changes in the period |
| Stable low-risk automated controls | Benchmarking of unchanged controls (efficiency only) |
Sample sizes: the single ASSUMED table in `toe-sampling.md`, not a table from the source framework.

## Data analytics and sampling choices
- Analytics: Benford digit analysis (journal entries, vendor payments, expenses; run via `gia-fraud:gia-fraud-analytics`); duplicate detection (vendor master and invoices, employee name and bank account); stratification and outlier analysis; gap testing of sequences (cheques, invoices, purchase orders); trend and ratio analysis; continuous auditing and monitoring (rule-based monitoring in the ERP, see `gia-analytics:gia-continuous-assurance`); machine-learning risk scoring and text review (treat as indicators only, never a conclusion).
- Sampling methods: monetary unit sampling (balances where risk follows value); random (homogeneous populations); judgmental (small populations, specific risk); systematic (sequential populations such as invoices); stratified (heterogeneous populations with distinct risk bands). Document the method and why it is defensible.

## Fraud concepts used when scoping
- Fraud triangle (Cressey): pressure, opportunity, rationalisation. Fraud diamond (Wolfe and Hermanson) adds capability.
- Fraud tree categories: asset misappropriation (cash schemes such as skimming, lapping, billing, payroll, expense reimbursement; non-cash theft and misuse), corruption (bribery, conflicts of interest, economic extortion, illegal gratuities), financial statement fraud (revenue overstatement, asset overstatement, liability understatement). Detail: `gia-fraud:gia-fraud-investigation` (`fraud-tree.md`).
- Source statistics on fraud (median loss, detection by tips, share of cases per category, control absence) came from a 2024 survey report and were not re-checked: [UNVERIFIED]. Do not quote them in a deliverable without opening the publication.
Rules for wording stay with `gia-core:iron-rules` (fraud ladder).

## Interview techniques
Structured versus semi-structured design; open questions first, then closed probing; cognitive interview technique for factual recall; PEACE model for investigation interviews (preparation and planning, engage and explain, account, closure, evaluate); deception indicators are leads, never evidence. Process interviews: `gia-fieldwork-workpapers/references/interview-guides.md`. Investigation interviews are run under `gia-fraud:gia-fraud-investigation`.

## Finding rating labels
The source maps severity to priority: Critical (P1), High (P2), Medium (P3), Low (P4). Use the entity's own rating scale from `racm-standard.md`; the P-labels are an optional alias for action-plan sorting. Findings use the five components (condition, criteria, cause, effect, recommendation) with a SMART recommendation: `gia-fieldwork-workpapers/references/5c-finding.md`.

## Pre-issuance checklist items beyond the Quality Gate
The Quality Gate is in `gia-core:iron-rules`. Additional audit-quality prompts from the source: root causes go beyond the surface symptom and are validated with the process owner; deficiency ratings match the entity's evaluation framework; sampling method documented; report separates design deficiency from operating failure; independence, objectivity and due professional care confirmed; action plans have named role owners, realistic dates and measurable milestones; fraud risk considered in scope; IT and cyber risk scoped against COBIT and the cybersecurity topical requirement (`gias-navigator`); accounting-standard assertions mapped for financial audits; Board and Audit Committee package prepared.

## Not ported, and why
- The source output-standards table cited GIAS "Std 21-25", "26-30", "31-37", "Std 9" and "Std 11.1". Those numbers do not match the 2024 standards structure used in `gias-navigator`; cite sub-clauses from `gias-navigator/references/standards-map.md` instead.
- The source listed "Standard 6.2 Internal Audit Strategy" and "Standard 9.2 Audit Strategy" as separate items; `gias-navigator` carries 6.1 (mandate) and 9.2 (strategy). Use that file.
- The source heading said "20 Principles" for COSO IC 2013; the framework has 17 (`coso-ic-map.md`).
- Named analytics tools (ACL, IDEA, Power BI and similar) were not carried: tool choice is the engagement's.
