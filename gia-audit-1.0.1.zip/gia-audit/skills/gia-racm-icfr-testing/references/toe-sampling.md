# ToE sampling - the single sample-size table and its source conflict

Status: the sample sizes below are **ASSUMED** (house convention). Neither source skill cites PCAOB AS 2201, ICAI GN or any other primary text for the numbers. The CAE must confirm or replace them before they are quoted to the Audit Committee or an external auditor. `scripts/sample_size.py` encodes the table in this file.

## Contents
- Adopted table (ASSUMED)
- Uplift and reduction triggers (ASSUMED)
- Both source tables, side by side
- Rules that do not change with the table
- Decision log

## Adopted table (ASSUMED)
| Control frequency | Annual population | Standard sample | High-risk | Low-risk |
|---|---|---|---|---|
| Continuous / automated | n/a | 1 if ITGC effective, otherwise manual-compensating full sample | n/a | n/a |
| Daily | about 250 | 25 | 30 | 15 |
| Weekly | about 52 | 20 | 25 | 10 |
| Monthly | 12 | 5 | 8 | 3 |
| Quarterly | 4 | 2 | 4 | 2 |
| Annual | 1 | 1 | 1 (plus prior year) | 1 |
| Ad hoc / transaction | varies | MUS or random, stratified for high risk, judgmental for low risk | | |

## Uplift and reduction triggers (ASSUMED)
- Uplift: first-time testing (+25%), high-risk or fraud area (+25%), prior exceptions (+50%), key financial-statement control (+25%), manual control (+25%).
- Reduction: confirmed ITGC for an automated control (1 to 3 items); prior period with no exceptions on an unchanged low-risk control (-25%).
- The script applies the table value for the stated risk band first, then the triggers, capped at the population size. It always prints the basis string and the ASSUMED flag.

## Both source tables, side by side
| Frequency | Source A: lifecycle spine (super-grc Module 7) | Source B: control-testing Section 7 (labelled PCAOB AS 2201 / ICAI GN) |
|---|---|---|
| Annual | 1 | 1 |
| Quarterly | 2 (high 4, low 2) | 2 |
| Monthly | 5 (high 8, low 3) | 3 to 5 |
| Weekly | 20 (high 25, low 10) | 5 to 8 |
| Daily | 25 (high 30, low 15) | 15 to 25 |
| Per transaction, population over 1,000 | MUS or random | 25 to 40 |
| Automated, ITGC effective | 1 (or 25 where ITGC not confirmed) | 1 |
Source B's attribution to AS 2201 / ICAI GN is itself unverified: AS 2201 does not publish a sample-size table. Weekly is the largest gap (20 versus 5 to 8).

## Rules that do not change with the table
- ToD must pass before ToE; a design-deficient control is not ToE-tested.
- A walkthrough is not a ToE sample (the walkthrough may count as one item only where the control runs once a period).
- If ITGC is ineffective, an automated control cannot be relied on; test the manual compensating control at full sample.
- Document population, selection method, random seed, sample list and result for every ToE.
- Interim testing needs a roll-forward: confirm no control change, inspect one or two recent instances, expand the sample for the post-interim period if exceptions arose.

## Decision log
| Item | Decision | Owner | Status |
|---|---|---|---|
| Adopt Source A numbers as the single table | Proposed 29-Oct-2026 | CAE | Open: confirm or replace with a sourced table |
| Source of weekly and daily numbers | None found in either skill | CAE | Open |
