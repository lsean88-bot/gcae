# Red-flag surveillance on a RACM (8 rules)

The Red Flag Monitor scans the RACM dataset automatically on each run.
Eight built-in rules with configurable on/off toggles:

| Rule ID | Rule | Severity | Trigger Condition |
|---------|------|----------|------------------|
| RF-01 | No-Owner Controls | HIGH | Key control with no control owner assigned |
| RF-02 | Missing SoD | CRITICAL | High-risk process with <2 SoD controls |
| RF-03 | No Detective Controls | HIGH | Process with only preventive controls (no detective layer) |
| RF-04 | Manual-Only Key Controls | MEDIUM | Key ICFR process with no automated controls |
| RF-05 | Stale Controls | MEDIUM | Key control not reviewed/updated in >12 months |
| RF-06 | COSO Component Gap | CRITICAL | Any COSO component with zero control coverage |
| RF-07 | ELC Coverage Gap | HIGH | Zero entity-level controls identified |
| RF-08 | ITGC Gap | CRITICAL | No ITGCs but automated controls exist in RACM |

### Red Flag Response Protocol
```
CRITICAL flag → Immediate escalation to CAE; pause reliance on affected controls
HIGH flag     → Remediate within 30 days; compensating control required
MEDIUM flag   → Remediate within 90 days; document acceptance of residual risk
LOW flag      → Monitor; include in next RACM update cycle

Manual flags: CAE or auditor can raise additional flags outside the 8 rules.
All flags remain in the log even after resolution (audit trail requirement).
```

---

