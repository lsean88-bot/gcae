# Test of Design (ToD) methodology

### Purpose
Determine whether each control is designed effectively — i.e., whether, if operating
as designed, the control would prevent or detect a material misstatement.

### ToD Procedure (apply to every key control)
```
STEP 1 — UNDERSTAND: Read the control description. Confirm it addresses the risk statement.
STEP 2 — WALKTHROUGH: Perform one end-to-end walkthrough of the control execution.
          • Interview the control owner and performer
          • Observe or re-perform one instance of the control
          • Obtain one sample of evidence (document, system screenshot, sign-off)
STEP 3 — ASSERT: For each FS assertion the control addresses, ask:
          "Would a competent person executing this control as written catch the error/fraud?"
STEP 4 — EVALUATE DESIGN: Use the three-question test:
          Q1: Does the control address the RIGHT risk? (completeness)
          Q2: Is the control PRECISE enough to catch the error? (precision)
          Q3: Does the control OWNER have the authority and competence? (capability)
STEP 5 — CONCLUDE:
          ✅ ADEQUATE    — Passes all three questions. Proceed to ToE.
          ⚠ ENHANCEMENT — Minor design gap; improvement recommended. Proceed to ToE with caveat.
          ❌ INADEQUATE  — Fails one or more questions. Do NOT proceed to ToE. Raise deficiency.
```

### ToD Sampling
```
ToD = 1 walkthrough per control per period (not statistically sampled)
If the control operates multiple times: walkthrough counts as 1 of the ToE samples
If control operates annually: walkthrough satisfies both ToD and ToE
```

---

