# RACM version control protocol

### Mandatory Snapshot Events (save a named version before):
```
1. Any bulk import or update of controls (>10 records)
2. Before and after each RACM review cycle
3. Before presenting to Audit Committee or Board
4. Before any RACM restoration
5. At year-end (annual archive)
```

### Version Naming Convention
```
Format: [EntityCode]-RACM-[YYYY-MM-DD]-[Event]
Examples:
  <ENTITY>-RACM-2026-03-31-Q1-Review
  <ENTITY>-RACM-2026-06-30-Pre-AC-Presentation
  <ENTITY>-RACM-2026-12-31-Year-End-Archive
  <ENTITY>-RACM-2026-07-15-Pre-Restore-Backup
```

### Version Diff Review (before restoring any prior version):
```
Check: Control count change (additions / deletions)
Check: Risk rating changes (upgrades / downgrades)
Check: Key Control Y/N changes
Check: COSO component mapping changes
Check: Control owner changes
If material changes found → escalate to CAE before restoring
```

### Export / Import Protocol
```
Export format: JSON with _meta block containing:
  {app, version, exportedAt, versionName, versionId}
Import: Creates a new version entry (does NOT auto-restore)
  → Always review diff before applying imported state
File naming: [EntityCode]_RACM_[VersionName]_[ID].json
```

---

