# RACM standard, risk rating and control classification


## Contents
- SECTION 3 — RISK RATING METHODOLOGY
- SECTION 4 — CONTROL CLASSIFICATION
- SECTION 16 — COMMON MISTAKES AND CORRECTIONS

> Ported from the retired control-testing skill (Sections 1, 3, 4, 16). Deficiency scale is CD/SD/MW (see deficiency-aggregation.md). Ownership by role, not by name.

### What Is a RACM?

A Risk and Control Matrix (RACM) — also called Risk Control Matrix (RCM) — is the
central governance document that maps business risks to the controls designed to
prevent or detect material misstatements, fraud, or operational failures. 

**RACM Record Structure (12 core fields):**
```
Control ID     : Unique identifier (e.g. CTL-AP-015)
Process        : Business process (e.g. Procure to Pay)
Sub-Process    : Specific sub-process within the process
Risk Statement : What could go wrong — the inherent risk
COSO Component : Control Environment | Risk Assessment | Control Activities |
                 Information & Communication | Monitoring
Risk Rating    : CRITICAL | HIGH | MEDIUM | LOW
Control Description : What the control does — precise, verifiable
Control Type   : Preventive | Detective | Corrective | Directive
Control Nature : Manual | Automated | IT-Dependent Manual
Key Control    : Y (key / ICFR relevant) | N (non-key)
Control Owner  : Named individual responsible for execution
Control Frequency: Daily | Weekly | Monthly | Quarterly | Annual | Per Transaction
```

### Financial Statement Assertions Mapped in RACM
Each control addresses one or more FS assertions:
- **Existence** — recorded items exist
- **Completeness** — all items that should be recorded are recorded
- **Valuation** — amounts are appropriate
- **Rights & Obligations** — entity has rights to recorded assets
- **Presentation & Disclosure** — classification and disclosure is appropriate
- **Occurrence** — transactions that have been recorded have occurred

---


## SECTION 3 — RISK RATING METHODOLOGY

### Inherent Risk Rating Scale
| Rating | Definition | Testing Priority |
|--------|-----------|-----------------|
| CRITICAL | High likelihood AND high impact; material misstatement probable | ToD + ToE mandatory; no rotation |
| HIGH | Significant risk; material misstatement possible | ToD + ToE mandatory; no rotation |
| MEDIUM | Moderate risk; misstatement unlikely but possible | ToD mandatory; ToE risk-based |
| LOW | Low likelihood and impact | ToD may suffice; ToE rotational |

### Residual Risk Assessment
```
Residual Risk = Inherent Risk after considering control effectiveness
CRITICAL inherent + effective control → HIGH residual (never below HIGH)
HIGH inherent + effective control     → MEDIUM residual
MEDIUM inherent + effective control   → LOW residual
If ToD = Inadequate: Residual risk = Inherent risk (control not credited)
```

### Risk Heat Map (Likelihood × Impact)
```
Impact →        Minor    Moderate   Significant   Critical
Likelihood ↓
Almost Certain  MEDIUM    HIGH        CRITICAL     CRITICAL
Likely          LOW       MEDIUM       HIGH        CRITICAL
Possible        LOW       LOW          MEDIUM       HIGH
Rare            LOW       LOW          LOW          MEDIUM
```

---

## SECTION 4 — CONTROL CLASSIFICATION

### Control Type
| Type | Definition | Example |
|------|-----------|---------|
| Preventive | Stops errors/fraud before they occur | Dual authorisation on payments |
| Detective | Identifies errors/fraud after they occur | Monthly bank reconciliation |
| Corrective | Fixes errors after detection | Journal entry reversal process |
| Directive | Guides behaviour to achieve outcomes | Procurement policy approval |

### Control Nature
| Nature | Definition | Testing Implication |
|--------|-----------|-------------------|
| Manual | Performed by a person without system dependency | Sample-based testing; human competency critical |
| Automated | Performed entirely by IT system | Test once per period if ITGC effective |
| IT-Dependent Manual | Person uses system output in manual judgement | Test both the IT output AND manual review |

### Key Control Designation (Y/N)
**Key Control (Y):** Required for ICFR / SOX reliance. Directly addresses a significant risk.
Must be included in ToD and ToE. Must have named owner and documented frequency.

**Non-Key Control (N):** Provides additional assurance but is not relied upon for ICFR opinion.
May be tested on a rotational basis or as supporting procedures.

**Key Control designation rules:**
```
→ Only ONE key control per significant risk is required (avoid over-reliance)
→ Key controls must be PREVENTIVE where possible (detective alone insufficient for ICFR)
→ Entity-Level Controls (ELCs) are ALWAYS key controls
→ ITGCs that underpin automated application controls are ALWAYS key controls
→ Key controls with no owner assigned: FLAG immediately (governance gap)
```

---


## SECTION 16 — COMMON MISTAKES AND CORRECTIONS

| Mistake | Correct Approach |
|---------|----------------|
| ToE performed without ToD pass | Always perform ToD first; if design inadequate, raise deficiency without ToE |
| Only one control mapped to multiple COSO components | Each control maps to its PRIMARY component only |
| Automated control tested with full sample size | Automated controls need only 1 test if ITGC is effective |
| Key control with no frequency | All key controls must have documented frequency |
| SD raised but no management response obtained | SD requires management response before Audit Committee reporting |
| ITGC failure treated as isolated | ITGC failure impacts ALL automated controls relying on that system — aggregate |
| Control owner = "Finance Department" | Owner must be a named individual, not a department |
| Risk rating = MEDIUM for financial close controls | Financial close is inherently HIGH/CRITICAL — override required |
| Version not saved before AC presentation | Mandatory snapshot event — non-negotiable |
| Red flag ignored because "it has always been this way" | All red flags require documented investigation; prior practice is not an excuse |

---

