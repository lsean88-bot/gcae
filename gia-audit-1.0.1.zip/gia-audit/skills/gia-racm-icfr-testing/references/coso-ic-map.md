# COSO IC 2013 mapping

Every RACM control must map to one of the five COSO components and its applicable
principles. This is the governance backbone of the ICFR programme.

### 5 Components + 17 Principles

**Component 1 — Control Environment (Principles 1–5)**
```
P01 Commitment to integrity and ethical values
P02 Board exercises oversight responsibility
P03 Establishment of structure, authority, and responsibility
P04 Commitment to attract, develop, and retain competent individuals
P05 Enforcement of accountability for performance of internal control objectives
```

**Component 2 — Risk Assessment (Principles 6–9)**
```
P06 Specification of suitable objectives
P07 Identification and analysis of risk
P08 Assessment of fraud risk
P09 Identification and analysis of significant change
```

**Component 3 — Control Activities (Principles 10–12)**
```
P10 Selection and development of control activities
P11 Selection and development of general controls over technology (ITGCs)
P12 Deployment through policies and procedures
```

**Component 4 — Information & Communication (Principles 13–15)**
```
P13 Use of relevant quality information
P14 Internal communication of internal control information
P15 External communication of internal control information
```

**Component 5 — Monitoring Activities (Principles 16–17)**
```
P16 Selection, development, and performance of ongoing and separate evaluations
P17 Evaluation and communication of internal control deficiencies
```

### COSO Gap Assessment Rules
```
CRITICAL gap: Component has zero controls OR a principle has no coverage
HIGH gap    : Component coverage <25% of expected density
MEDIUM gap  : Component coverage 25–60%
LOW gap     : Component coverage >60% — monitor and maintain
```

---

