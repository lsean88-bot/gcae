# Prompt blocks for RACM analysis


## Contents

### Block A — RACM Health Assessment
```
RACM HEALTH ASSESSMENT REQUEST

CHARLIE HILLS PLAN: Read RACM data → assess completeness and quality →
identify gaps → prioritise remediation.

Dataset: [N] controls | Entity: [Name] | Period: [Date]

INSTRUCTION:
1. Summarise control count by: COSO component, risk rating, key/non-key, type, nature
2. Identify COSO component gaps (any component with <10% coverage)
3. Identify processes with CRITICAL risk but no key control
4. Check ICAI GN four areas: ELC, SoD, Physical Verification, Cross-Division
5. List top 5 remediation priorities
6. Produce a RACM Health Scorecard (Red/Amber/Green per assessment area)
Output: Executive-ready 1-page summary + scorecard table
```

### Block B — Deficiency Analysis
```
DEFICIENCY ANALYSIS AND CLASSIFICATION REQUEST

Finding: [Control ID / Description]
Test result: [ToD / ToE outcome — what failed and why]
Risk rating: [CRITICAL / HIGH / MEDIUM / LOW]
Process: [Process name]
COSO component: [Component]

INSTRUCTION:
1. Classify the deficiency: SD / MW / MN — with rationale
2. Perform aggregation analysis: does this combine with other known deficiencies to
   elevate classification?
3. Draft root cause analysis: Design gap OR Operating failure OR Management override
4. Draft management response template with: root cause, corrective action, owner, target date
5. Recommend compensating control (if SD or MW)
6. State reporting obligations: Audit Committee / Board / External Auditor / Public disclosure
Charlie Hills CHECK: Is the classification defensible to PCAOB / ICAI standards?
```

### Block C — ICAI GN Gap Analysis
```
ICAI GN ALIGNMENT ASSESSMENT

Entity: [Name] | Listed entity: Y/N | Year: [YYYY]

INSTRUCTION:
1. Assess Entity-Level Control (ELC) coverage:
   - Count ELC controls; check each of the 5 COSO components is addressed
   - Flag if tone-at-top, board oversight, or risk assessment ELC is missing
2. Assess Segregation of Duties (SoD) coverage:
   - For each high-risk process (P2P, O2C, Financial Close, Fixed Assets):
     list SoD controls; flag if any process has <2 SoD controls
3. Assess Physical Verification controls:
   - Check Inventory and Fixed Assets processes; flag if no physical count controls
4. Assess Cross-Division / Intercompany controls:
   - Check if intercompany elimination and related party controls exist
5. Produce ICAI GN Compliance Matrix: 4 areas × Red/Amber/Green status + gap narrative
Output: Board-ready ICAI GN compliance assessment
```

### Block D — Audit Plan Generation
```
RISK-BASED AUDIT PLAN REQUEST

RACM data: [N] controls across [N] processes
Planning period: [YYYY]
Team capacity: [N] audit days available

INSTRUCTION:
1. Rank all processes by risk score: (CRITICAL×4) + (HIGH×2) + (MEDIUM×1)
2. Assign engagements to quarters per risk priority:
   - CRITICAL processes: Q1 or Q2, no rotation
   - HIGH processes: Q2 or Q3, biennial rotation max
   - MEDIUM: Q3 or Q4, triennial rotation
   - LOW: risk-based rotation
3. Validate: ELC reviewed annually; ITGC reviewed every period
4. Budget days per engagement based on control count and risk
5. Produce Annual Audit Plan table: Engagement | Process | Priority | Quarter | Days | Rationale
6. Flag any coverage gaps (unaudited CRITICAL processes in the plan year)
Output: AC-ready Annual Audit Plan with risk-based justification
```

### Block E — Red Flag Investigation
```
RED FLAG INVESTIGATION REQUEST

Flag ID: [ID]
Rule triggered: [Rule description]
Affected area: [Process / Control ID]
Severity: [CRITICAL / HIGH / MEDIUM]

INSTRUCTION:
1. Confirm whether the flag is a true positive or false positive (state basis)
2. If true positive:
   a. Identify all controls affected
   b. Classify as SD / MW / MN
   c. Draft compensating control recommendation
   d. Draft management action plan with owner and deadline
   e. State whether ICFR opinion is impacted
3. If false positive: state reason and close the flag with documented rationale
4. Log investigation outcome for audit trail
Charlie Hills CHECK: Is the investigation conclusion defensible to Audit Committee?
```

---

