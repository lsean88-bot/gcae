# Three Lines collaboration and management response standards

### Line Responsibilities in RACM Context

**Line 1 — Business Management (Green)**
```
Role: Control execution and self-assessment
RACM responsibilities:
• Execute controls daily as documented
• Maintain and update control evidence
• Perform Control Self-Assessment (CSA) quarterly
• Submit management responses to deficiencies within agreed timelines
• Report exceptions and control failures to Line 2 immediately
• Update RACM for process changes (new controls, retired controls)
```

**Line 2 — Risk & Compliance (Blue)**
```
Role: Oversight, standards, and escalation
RACM responsibilities:
• Define and maintain risk appetite and tolerance thresholds
• Review and challenge Line 1 CSA results
• Monitor KRI thresholds; escalate breaches
• Sign off on RACM risk rating accuracy (annual certification)
• Perform independent ToD assessment for medium/high risk controls
• Regulatory compliance monitoring and ICAI GN gap tracking
```

**Line 3 — Internal Audit (Purple)**
```
Role: Independent assurance and advisory
RACM responsibilities:
• Design and execute risk-based ToD and ToE testing programmes
• Report independently to Audit Committee on ICFR effectiveness
• Classify and communicate deficiencies per PCAOB / ICAI GN standards
• Root cause analysis on control failures
• Follow up on agreed management action plans (IIA GIAS Standard 15)
• Provide advisory on RACM design improvements (not ownership)
```

### Interaction Log Protocol
```
All cross-line communications on RACM matters must be logged:
• Escalations from L1 → L2 or L1 → L3
• Challenge or query from L2 → L1
• Deficiency communication from L3 → L1 and L2
• Management response submission from L1 → L3
Log fields: Date | From Line | To Line | Topic | Control ID | Status
```

### Management Response Standards
```
MANDATORY for all deficiencies rated SD or MW:
• Finding Reference: e.g. FIND-2026-001
• Root cause acknowledgment (design gap OR operating failure)
• Specific corrective action (not generic)
• Named responsible owner (job title)
• Target completion date (not vague: "Q3 2026", not "soon")
• Status: Open → Submitted → Agreed → Closed
No management response within 30 days (SD) or 14 days (MW) → auto-escalate to CAE
```

---

