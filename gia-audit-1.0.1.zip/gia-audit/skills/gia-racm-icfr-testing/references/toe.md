# Test of Operating Effectiveness (ToE) procedure

Sample sizes: `toe-sampling.md` (single table, ASSUMED). Deficiency classification: `deficiency-aggregation.md`. Evidence grading uses the canonical R1-R5 scale in `gia-core:iron-rules`; do not re-rank evidence locally.

## Procedure
1. Define the population: every instance of control execution in the audit period (typically 12 months for ICFR). Reconcile the population to a system total before sampling.
2. Select the sample: random, systematic or stratified. Record the method, the seed and the sample list. A haphazard selection needs a stated reason.
3. Obtain evidence for each item and grade it R1-R5. An R5 (verbal) item cannot support a pass or a finding; obtain documentary evidence or record the item as an exception or scope limitation.
4. Evaluate each item: Pass (executed as designed, evidence sufficient), Fail (not executed or evidence missing), Exception (partial execution; investigate cause).
5. Conclude: zero exceptions is a pass; a single exception on a low-risk control is a pass with observation and an expanded sample; any exception on a medium or high-risk control, or two or more on any control, is a fail and is raised as a deficiency for classification.
6. Roll forward if testing was at an interim date.

## Automated controls
- ITGC effective (access, change management, operations): test the automated control once per period by configuration inspection or re-performance. No statistical sample.
- ITGC not effective: the automated control cannot be relied on. Test the manual compensating control at full sample and raise the ITGC failure as a deficiency affecting every control that depends on that system.

## Workpaper minimum
Control ID, objective, population and its reconciliation, selection method, sample list, attributes tested, per-item result and evidence grade, exceptions with cause, conclusion, preparer and reviewer role, date.
