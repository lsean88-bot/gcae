# COSO IC 2013 & SOX Testing Reference

## COSO IC 2013 — 17 Principles Audit Assessment Guide

### Principle-Level Testing Approach

| Principle | Key Audit Tests |
|---|---|
| P1 Integrity & Ethics | Code of conduct acknowledgement; whistleblower hotline usage; tone at top assessment |
| P2 Board Oversight | AC charter review; AC minutes; board risk oversight evidence |
| P3 Organisational Structures | Org chart; authority matrix; delegation of authority policy |
| P4 Competency | Job descriptions; performance evaluations; training records |
| P5 Accountability | Performance KPIs; consequences for control failures |
| P6 Financial Reporting Objectives | Management's assertion; financial close process documentation |
| P7 Risk Identification | Risk inventory; WCGW analysis at process level |
| P8 Fraud Risk | Fraud risk assessment; management override controls |
| P9 Change Risk | Change management log; recent acquisition integration testing |
| P10 Control Selection | RACM review; are controls appropriately designed? |
| P11 Technology Controls | ITGC effectiveness; automated vs manual control reliance |
| P12 Policies and Procedures | Policy currency and dissemination; exception handling |
| P13 Quality Information | Data quality controls; ERP access and input validation |
| P14 Internal Communication | Whistleblower programme; escalation channels |
| P15 External Communication | MD&A disclosures; regulatory correspondence controls |
| P16 Ongoing Monitoring | Dashboards; reconciliation frequency; KPI monitoring |
| P17 Deficiency Communication | Deficiency log; escalation to AC; management action tracking |

---

## SOX §302 Quarterly Testing Programme

### Controls to Test
1. **Disclosure Committee**: Minutes documenting review of material items; sub-certifications from process owners
2. **CEO/CFO Certification Process**: Review of attestation checklist; escalation process for findings
3. **Quarterly Close Process**: Journal entry review controls; account reconciliation sign-offs; variance analysis
4. **DC&P Effectiveness Assessment**: Documented management conclusion with supporting evidence

### Test Scripts — §302
| Control | Test Procedure | Evidence |
|---|---|---|
| Sub-certifications signed | Inspect signed sub-cert forms from all material process owners | Sub-cert log; signatures |
| Disclosure committee meeting | Inspect minutes; verify material items discussed | AC minutes |
| Management review of draft financials | Inspect review sign-offs on draft 10-Q/10-K | Annotated draft; approval email |
| Disclosure controls effectiveness conclusion | Inspect documented CEO/CFO assessment | Assessment memo |

---

## SOX §404 Annual ICFR Testing Programme

### Phase 1 — Scoping (TDRA)
1. Identify material financial statement accounts and disclosures (quantitative + qualitative)
2. Map to relevant business processes and sub-processes
3. Identify relevant financial statement assertions per account/disclosure
4. Identify key controls (preventive and detective) that address WCGW per assertion
5. Determine test approach: rely on automated controls (if ITGC effective) or manual testing

### Phase 2 — RACM Design Template

| Account | Assertion | WCGW | Control ID | Control Owner | Control Type | Frequency | Test Procedure | Sample Size |
|---|---|---|---|---|---|---|---|---|
| Revenue | Occurrence | Revenue recorded without shipment | C-REV-001 | VP Finance | Preventive — system automated | Each transaction | Inspect system configuration and ITGC | ITGC reliance |
| AP | Completeness | Invoices not recorded | C-AP-002 | AP Manager | Detective — 3-way match exception report | Weekly | Reperform exception report for sample period | 25 items |

### Phase 3 — Sample Sizes (AS 2201 / AICPA Guidance)

| Control Frequency | Low Risk Sample | Medium Risk Sample | High Risk Sample |
|---|---|---|---|
| Annual | 1 | 1–2 | 2 |
| Quarterly | 2 | 2–4 | 4 |
| Monthly | 3 | 5–8 | 8 |
| Weekly | 5 | 8–15 | 15–25 |
| Daily | 15 | 25–40 | 40–60 |
| Multiple times/day (automated) | Rely on ITGC; inspect configuration | Same | Same |

### Phase 4 — Deficiency Evaluation Framework

**Step 1**: Identify the deficiency (design or operating)
**Step 2**: Determine the magnitude of potential misstatement (remote / reasonably possible / likely)
**Step 3**: Determine quantitative materiality threshold (typically 5% of pre-tax income; 0.5% of total assets as secondary measure)
**Step 4**: Assess compensating controls
**Step 5**: Classify: Control Deficiency / Significant Deficiency / Material Weakness
**Step 6**: Aggregate related deficiencies — combined impact may elevate classification

### Phase 5 — SOX Report Language

**Unqualified (Effective ICFR)**:
> "Management has concluded that, as of [date], the Company's internal control over financial reporting is effective, based on criteria established in the Internal Control — Integrated Framework issued by COSO."

**Adverse Opinion (Material Weakness identified)**:
> "Management has concluded that, as of [date], the Company's internal control over financial reporting is not effective due to the material weakness described below."

---

## Common Material Weakness Areas (KPMG/PCAOB 2024)
1. Financial Close and Reporting processes
2. Control Environment (tone at top, competency, accountability)
3. Non-Routine and Complex Transactions
4. Journal Entry controls
5. IT General Controls (access management, change management)
6. Revenue recognition (IFRS 15 / ASC 606 application)
