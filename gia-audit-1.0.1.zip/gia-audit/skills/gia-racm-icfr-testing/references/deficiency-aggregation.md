# Deficiency classification and aggregation (CD / SD / MW)

Scale: **CD** control deficiency, **SD** significant deficiency, **MW** material weakness. The older "minor / observation (MN)" label maps to CD. Use the SD / MW pair only where ICFR or SOX-style reporting applies; for other engagements state the applicability decision explicitly and use CD with a severity rating.

## Contents
- Classification tree
- Evaluation factors
- Triggers by class
- Aggregation rules and register
- Reporting routes
- Checks run by scripts/deficiency_aggregation_check.py

## Classification tree
```
Gap in design, or failure in operation?
  NO  -> no deficiency; document and close
  YES -> CD
         More than remote likelihood AND more than inconsequential magnitude?
           NO  -> remains CD
           YES -> SD
                  Reasonable possibility of material misstatement not prevented or detected?
                    NO  -> remains SD
                    YES -> MW
Always test whether aggregation raises the class.
```

## Evaluation factors
| Factor | Question |
|---|---|
| Nature | Design gap or operating failure? Design gaps are usually more severe |
| Magnitude | Maximum potential misstatement; quantify where possible |
| Likelihood | Remote / reasonably possible / probable, using the framework's definitions |
| Pervasiveness | One control and period, or systemic? |
| Compensating controls | Do other controls reduce residual risk? Test them; do not assume |
| Fraud risk | Does the deficiency create a fraud opportunity? If yes, escalate per the fraud ladder in gia-core:iron-rules |
| Prior history | Repeat failure raises severity |
| Management awareness | Known and not acted on raises governance risk |

## Triggers by class (starting points; professional judgement documented in the workpaper)
| Class | Typical triggers |
|---|---|
| CD | ToE failure on a low-risk control; ToD enhancement recommendation; documentation gap with no effect on operation; non-key control failure |
| SD | ToE failure on a high-risk key control (first instance); ToD inadequate on a medium-risk key control; SoD violation with no compensating control; competency gap on a key control; ITGC failure affecting fewer than 3 automated controls |
| MW | ToE failure on a critical-risk key control; multiple SDs indicating pervasive failure; ITGC failure affecting more than 3 dependent automated controls; no key control for a significant risk (design gap); management override without compensating procedure; restatement of prior-period statements |

## Aggregation rules and register
- Three or more CDs in the same process may constitute an SD.
- Two or more SDs in the same COSO component may constitute an MW.
- An ITGC failure is aggregated across every automated control relying on that system.
- Final classification is assigned only after the aggregation register is complete.

| Def ID | Control ID | Finding ref | Process | COSO component | Standalone class | Related to | Aggregated class | Rationale | Mgmt response ref |
|---|---|---|---|---|---|---|---|---|---|

Management response is required for every SD and MW before the report advances; the response is recorded verbatim, with a named owner and a dated action.

## Reporting routes
| Class | Route |
|---|---|
| CD | Management letter; corrective action within the audit cycle |
| SD | Audit Committee; management response within the agreed window |
| MW | Board / Audit Committee and external auditor; disclosure obligations per the applicable regime |

## Checks run by scripts/deficiency_aggregation_check.py
Required fields present; class in {CD, SD, MW}; aggregated class never below standalone class; every related-to reference resolves; three-or-more-CD and two-or-more-SD triggers have a recorded aggregation decision; SD and MW rows carry a management response reference; ITGC-linked rows list dependent controls.
