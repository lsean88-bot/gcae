# ICAI Guidance Note on ICFR (India listed entities)

> Apply only where ICFR reporting under the ICAI GN is in scope. Statutory applicability tests are in the India statutory register.

For Indian listed entities, the RACM must address ICAI GN specific requirements
in addition to COSO. Four priority areas:

### 1. Entity-Level Controls (ELC)
- Tone at the top, board oversight, code of conduct
- Risk assessment process, internal audit function
- **Gap alert if:** Zero ELC controls OR ELC not mapped to COSO Component 1

### 2. Segregation of Duties (SoD)
- No single person should initiate, authorise, execute, AND record a transaction
- SoD controls must exist in all high-risk processes (P2P, O2C, Financial Close)
- **Gap alert if:** SoD coverage <3 controls per high-risk process

### 3. Physical Verification Controls
- Physical existence of assets (inventory, fixed assets, cash)
- Reconciliation of physical count to system records
- **Gap alert if:** No physical verification controls in Inventory or Fixed Assets process

### 4. Cross-Division / Intercompany Controls
- Controls over transactions between group entities, intercompany eliminations
- Related party transaction controls and disclosure
- **Gap alert if:** No cross-division controls where group structure exists

---

