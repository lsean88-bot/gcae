> Ported workflow from the retired Mexico manufacturing skill. Statutory values live only in `statutory-register-mexico.md`. Evidence ranking uses the canonical R1-R5 scale in `gia-core:iron-rules`; the bracket tags are source-type labels.
## Contents
- Step 0 — Evidence Standard (Read First — Non-Negotiable)
- Step 1 — Establish Company Context
- Step 2 — Document Scan (if files provided)
- Step 3 — Web-Validate Current Regulations
- Step 4 — Execute Audit Tests Across All Sixteen Domains
- Step 5 — Report structure
- Step 6 — Optional: data:analyze Customization
- Validation Standards — Non-Negotiable


# /mx-manufacturing-audit — Mexican Manufacturing Internal Audit

Conduct a rigorous internal audit of a Mexican manufacturing plant, validated against current
Mexican regulations (SAT, IMSS, CINIF, SEMARNAT, STPS, REPSE, INM, BANXICO, CFCRL) and
international standards. Output follows **2024 IIA Global Internal Audit Standards** (effective
January 9, 2025). **All findings must be grounded in sufficient appropriate audit evidence —
zero assumptions, zero fuzzy logic, zero unverified claims.**

Finding structure: **Condition → Criteria → Cause → Effect → Recommendation**
Each finding must additionally state: **Evidence Basis** and **Assertion(s) Tested**

---

## Step 0 — Evidence Standard (Read First — Non-Negotiable)

**Before any audit test, read `references/mx-audit_evidence_methodology.md`.**

This defines the seven evidence types (`[INS]` `[PHY]` `[CON]` `[REP]` `[REC]` `[OBS]` `[ANA]`),
nine assertion codes (`EX` `CO` `AC` `VA` `CU` `RO` `CL` `PR` `CP`), reliability hierarchy,
professional skepticism rules, and anti-assumption prohibitions.

**Operational rules — apply to every test in every domain:**
1. **`[INQ]` (inquiry) alone is never sufficient** — always corroborate with a second evidence type
2. **Every 🔴 Critical finding requires at least one `[CON]` or `[PHY]` evidence item**
3. **All monetary findings must be quantified in MXN** (or kg for material findings)
4. **Full-population testing is preferred** over sampling wherever ERP/system data is available
5. **"Cannot be verified" is a valid finding** — state what was requested, what was unavailable, and why that absence is itself a risk

---

## Step 1 — Establish Company Context

Collect or confirm the following before auditing. Ask in a single concise question.

| Field | Why It Matters |
|-------|---------------|
| **Industry sub-type** | Metal stamping vs. injection molding affects NOMs, IMSS risk class, scrap rates |
| **Trade regime** | IMMEX triggers Annex 24, export ratio, merma declaration, 18-month limit |
| **State of operation** | ISN rate ([MX-034]) + border zone IVA/ISR stimulus eligibility |
| **Border zone?** | Eligible municipalities: IVA ([MX-003]) / ISR ([MX-009]) — renewed DOF 31-Dec-2025 |
| **Fiscal year under review** | Determines which SAT reform version applies |
| **Documents available?** | If none: framework only (label prominently). If present: line-item findings |
| **Foreign parent?** | Triggers TP, DIOR, thin cap, FX, shadow payroll |
| **Expatriates on-site?** | Triggers Domain 13 — INM permits, shadow payroll, ISR residency |
| **Union / CCT?** | Triggers Domain 13 — CCT at CFCRL, T-MEC LVC, strike risk |
| **Subcontractors?** | Triggers Domain 9 — REPSE compliance |
| **Customer base?** | Determines CSRs: GM BIQS, Ford Q1, VDA 6.3, Stellantis |
| **IATF 16949 certified?** | Depth of Domain 10 |
| **FCPA / UKBA exposure?** | US/UK parent escalates Domain 11 |
| **Prior ABAC incidents?** | Domain 11 = highest priority; legal counsel required |

Default to **metal stamping** if plant type unstated — state assumption prominently.

---

## Step 2 — Document Scan (if files provided)

Read `references/mx-document_scan_guide.md`. For each document type, apply the evidence tag:
- CFDIs → `[INS]` original XML preferred over PDF
- SUA reports → `[CON]` if pulled directly from IMSS portal; `[INS]` if management-supplied
- Bank statements → `[CON]` if confirmed directly with bank; `[INS]` if from management
- Annex 24 system export → `[INS]` from IMMEX software; cross-validate against `[CON]` pedimento data
- Weigh-gate log → `[INS]`; higher reliability if system-generated vs. manual entry

If no documents: label report **"FRAMEWORK ONLY — No Documents Reviewed — No Line-Item Findings"**.
Do not state findings as facts when no evidence has been obtained.

---

## Step 3 — Web-Validate Current Regulations

Always search before writing. Validation is `[CON]` — obtained from independent regulatory
portals, not from management:

- CFDI v4.0 requirements: `sat.gob.mx` (official source)
- Current IMSS UMA value + SBC caps: `imss.gob.mx`
- EFOS list: `efos.sat.gob.mx` — query each vendor RFC directly `[CON]`
- ISN rate for plant's state: state Secretaría de Finanzas official portal
- IMMEX decree + IVA/IEPS certification: `anam.gob.mx`
- REPSE STPS inspection protocol: `registros.stps.gob.mx`
- **Border decree:** status and validity per register row MX-003; verify padrón status
- BANXICO FIX rate: `banxico.org.mx/tipcamb` — current date
- CONASAMI minimum wage: `conasami.gob.mx`
- T-MEC labour value content wage: register row MX-035
- CFCRL CCT registry: `registrodectt.stps.gob.mx`

---

## Step 4 — Execute Audit Tests Across All Sixteen Domains

For every test: state the assertion, obtain evidence from highest-reliability source available,
quantify the finding, then write the condition. Never reverse this sequence.

### Domain 1 — SAT / Fiscal Compliance
Read: `references/mx-sat_fiscal.md` + `references/mx-tax_rates_vat.md`

| Test | Evidence | Assertion |
|------|---------|-----------|
| CFDI v4.0 compliance for all transactions | `[CON]` SAT descarga masiva — pull all CFDIs from SAT portal directly | AC, CP |
| EFOS vendor blacklist check | `[CON]` query each supplier RFC at `efos.sat.gob.mx` | CP |
| IVA rate applied (general [MX-001] vs. border [MX-003] vs. export [MX-002]) | `[INS]` CFDI XML + `[CON]` padrón fronterizo status from SAT portal | AC, CP |
| IVA retention on REPSE invoices ([MX-004] or [MX-005]) | `[REC]` recalculate retention per LIVA Art. 1-A on each REPSE invoice | AC, CP |
| ISR provisional payment (monthly) | `[CON]` SAT declaración extract + `[REC]` recalculate using coefficient × accumulated income | AC, CO |
| DIOR transfer pricing filed | `[CON]` SAT acuse de recibo + `[INS]` contemporaneous TP study | CO, CP |
| Thin cap ratio (LISR Art. 28 XXVII) | `[REC]` calculate related-party debt ÷ fiscal equity from financial statements + loan agreements `[INS]` | AC, CP |
| T-MEC LVC wage certification | `[REC]` average SBC ÷ contracted hours × BANXICO FIX + `[INS]` payroll CFDI | AC, CP |

### Domain 2 — Payroll & Labor
Read: `references/mx-payroll_labor.md`

| Test | Evidence | Assertion |
|------|---------|-----------|
| SBC completeness (all integrated salary components) | `[REC]` recalculate SBC for sample of 25 workers using payroll CFDI + benefit schedules | CO, AC |
| IMSS registration completeness | `[CON]` IMSS SUA portal extract vs. HR headcount list | EX, CO |
| Nómina CFDI issued every pay period | `[CON]` SAT descarga masiva nómina complement — 100% population | CO, CP |
| PTU calculation ([MX-033] × taxable profit) | `[REC]` recalculate from ISR annual return base + `[INS]` payment receipt | AC, VA |
| CONASAMI minimum wage compliance | `[REC]` compare lowest salary in payroll CFDI to current CONASAMI rate `[CON]` | AC, CP |

### Domain 3 — Customs & IMMEX
Read: `references/mx-immex_customs.md`

| Test | Evidence | Assertion |
|------|---------|-----------|
| Annex 24 balance vs. physical + ERP inventory | `[REC]` reconcile Annex 24 system export + `[PHY]` physical count + `[INS]` ERP balance | EX, CO, AC |
| Export ratio (≥60%/80%) | `[REC]` exported value ÷ total production from pedimentos + `[INS]` production records | AC, CP |
| Pedimento archive completeness | `[INS]` pedimento register vs. `[CON]` ANAM customs system records | CO, CP |

### Domain 4 — Financial Reporting
Read: `references/mx-nif_accounting.md`

| Test | Evidence | Assertion |
|------|---------|-----------|
| Inventory at lower of cost or NRV (NIF C-4) | `[INS]` costing run + `[ANA]` compare unit cost vs. current sale price from customer PO | VA |
| Customer-owned dies excluded from balance sheet | `[INS]` die master register ownership column + `[CON]` customer die ownership confirmation | RO, EX |
| Severance reserve adequacy (NIF D-3) | `[INS]` actuarial study + `[REC]` recalculate using headcount × tenure × salary | VA |
| FX restatement (NIF B-15) | `[REC]` closing BANXICO FIX rate × USD monetary balances + `[CON]` BANXICO FIX history | AC, VA |

### Domain 5 — Environmental
Read: `references/mx-environmental.md`

| Test | Evidence | Assertion |
|------|---------|-----------|
| LAU / COA currency | `[CON]` SEMARNAT permit registry check | CP, EX |
| Hazardous waste manifests | `[INS]` manifests (NOM-052) + `[CON]` SEMARNAT RETC filing | CO, CP |

### Domain 6 — Workplace Safety
Read: `references/mx-safety_noms.md`

| Test | Evidence | Assertion |
|------|---------|-----------|
| Press guard functionality (NOM-004-STPS) | `[OBS]` observe press operation; test guard interlock during run | CP |
| Noise / audiometry program (NOM-011-STPS) | `[INS]` audiometry records + `[CON]` STPS inspection file | CO, CP |
| Forklift operator certification (NOM-009-STPS) | `[INS]` operator certificate + `[CON]` STPS-authorized trainer certificate | CP |

### Domain 7 — Internal Controls & Anti-Fraud
Read: `references/mx-internal_controls.md`

| Test | Evidence | Assertion |
|------|---------|-----------|
| Cash payments >USD 2,000 (CFF Art. 31-A) | `[INS]` payment register filtered for cash transactions; `[ANA]` Benford on amounts | CO, AC |
| Phantom vendor detection | `[ANA]` vendor RFC vs. employee RFC full population match; `[CON]` SAT RFC validation | EX, CO |
| Journal entry testing | `[INS]` ERP journal extract — unusual entries by finance staff, off-cycle, round amounts | AC, CP |

### Domain 8 — ERM
Read: `references/mx-erm_risk_management.md`

| Test | Evidence | Assertion |
|------|---------|-----------|
| Risk register completeness | `[INS]` risk register + `[OBS]` risk committee meeting; verify all 16 audit domain risk areas are represented | CO, CP |
| KRI monitoring active | `[INS]` KRI dashboard last 6 months; verify breach actions documented | CO, CP |

### Domain 9 — REPSE / Subcontracting
Read: `references/mx-repse_subcontracting.md`

| Test | Evidence | Assertion |
|------|---------|-----------|
| REPSE registration of each contractor | `[CON]` query each contractor RFC at `registros.stps.gob.mx` | CP, EX |
| SISUB quarterly filing | `[CON]` SAT SISUB submission acknowledgment (acuse) | CO, CP |
| IVA retention on REPSE invoices | `[REC]` recalculate [MX-004] (persona moral) or [MX-005] (persona física) per LIVA Art. 1-A on each invoice | AC, CP |

### Domain 10 — Operational / Quality
Read: `references/mx-operational_quality.md`

| Test | Evidence | Assertion |
|------|---------|-----------|
| OEE calculation integrity | `[REC]` recalculate OEE = Availability × Performance × Quality Rate from raw machine log | AC |
| Die master register vs. physical count | `[PHY]` count all dies; agree to register; note unexplained gaps | EX, CO |
| PPAP approval before production | `[INS]` PPAP file with customer sign-off; cross-match to active production parts list | CP |
| Gauge calibration currency | `[INS]` calibration certificates; `[CON]` calibration lab accreditation certificate | CP |
| MSA (Gauge R&R) validity | `[REC]` recalculate %GRR from raw study data; verify ≤10% threshold | AC, CP |

### Domain 11 — ABAC / Ethics
Read: `references/mx-ethics_antibribery.md`

| Test | Evidence | Assertion |
|------|---------|-----------|
| OFAC / SHCP sanctions screening | `[CON]` screen each vendor and government contact against OFAC SDN list + SHCP lista negra | CP |
| Gift register vs. contract award correlation | `[ANA]` cross-tabulate gift register entries with vendor contract award dates | CP |
| Benford's Law on payments | `[ANA]` apply to full payment population from ERP; flag first-digit anomalies | AC, CO |
| COI declarations completeness | `[INS]` signed COI declarations for all management vs. `[INS]` employee master list | CO, CP |

### Domain 12 — Banking, Finance & Treasury
Read: `references/mx-banking_finance.md`

| Test | Evidence | Assertion |
|------|---------|-----------|
| Bank account completeness | `[CON]` request bank confirmation letters from all banks; cross to SAT electronic accounting catálogo | EX, CO |
| Bank reconciliation independence | `[INS]` reconciliations + `[OBS]` or `[INQ]` (corroborated) who prepared vs. who approved | CP |
| LFPIORPI UIF reports | `[INS]` UIF filing acknowledgments + `[ANA]` cash receipt log for transactions >USD 7,500 | CO, CP |
| Thin cap ratio | `[REC]` related-party debt ÷ fiscal equity; `[INS]` all intercompany loan agreements | AC, CP |
| Wire transfer BANXICO compliance | `[CON]` bank SWIFT/SPEI confirmations for all foreign wires | CO, CP |

### Domain 13 — Expat, Union & Manpower
Read: `references/mx-expat_union_hr.md`

| Test | Evidence | Assertion |
|------|---------|-----------|
| INM work permit — all expats | `[CON]` verify each tarjeta at INM portal `tramites.gob.mx/INM`; confirm employer match + expiry | EX, CP |
| Shadow payroll — tax residents (>183 days) | `[REC]` days-in-Mexico log + `[CON]` SAT nómina CFDI descarga masiva for expat RFC | CO, AC, CP |
| CCT registered at CFCRL | `[CON]` query `registrodectt.stps.gob.mx` for entity RFC | CP |
| CCT ratification secret vote | `[INS]` tally sheet (escrutinio) signed by union committee and management | CP |
| Wages ≥ CCT tabulator | `[REC]` compare payroll CFDI per category to CCT wage schedule `[INS]` | AC, CP |
| 4-way headcount reconciliation | `[CON]` IMSS SUA + `[INS]` payroll CFDI + `[INS]` HR records + `[INS]` badge access log; count discrepancy per worker ID | EX, CO |
| Ghost employee — dual CLABE | `[ANA]` full-population CLABE analysis from payroll CFDI; flag any CLABE shared by ≥2 workers | EX |
| NIF D-3 severance reserve | `[INS]` actuarial study + `[REC]` recalculate liability vs. balance sheet | VA |

### Domain 14 — S&OP & Production Planning
Read: `references/mx-sales_sop_planning.md`

| Test | Evidence | Assertion |
|------|---------|-----------|
| S&OP governance documentation | `[INS]` meeting minutes last 6 months; verify executive attendance and decision log | CP |
| EDI release loaded to ERP | `[REP]` trace 5 customer EDI files (830/862) to MPS entries in ERP | AC, CO |
| Forecast accuracy (MAPE) | `[REC]` calculate MAPE from ERP production actuals vs. demand plan for last 12 months | AC |
| MPS capacity vs. press line capacity | `[REC]` MPS units × cycle time vs. available machine hours (from OEE records) | AC |
| BOM yield in MRP vs. actual scrap | `[REC]` compare BOM yield factor in ERP to actual scrap rate from Domain 16 reconciliation | AC |

### Domain 15 — Warehouse & Inventory
Read: `references/mx-warehouse_operations.md`

| Test | Evidence | Assertion |
|------|---------|-----------|
| Physical coil inventory count | `[PHY]` count and weigh sample of coils; agree to ERP balance | EX, AC |
| FIFO compliance — coil issuance sequence | `[INS]` ERP issuance records; verify consumption date ≥ receipt date for same heat | CP, AC |
| Cycle count independence | `[INS]` cycle count records; verify counter name ≠ warehouse keeper | CP |
| Carta Porte CFDI on domestic shipments | `[CON]` SAT descarga masiva — verify Carta Porte complement on all freight CFDIs | CO, CP |
| SLOB inventory write-down | `[INS]` ERP aging report; `[REC]` NRV calculation for zero-movement items >90 days | VA |
| IMMEX 18-month rule compliance | `[REC]` Annex 24 aging report; flag items imported >18 months with no exit | CP, VA |

### Domain 16 — Material Balance & Scrap Reconciliation
Read: `references/mx-material_balance_scrap.md`

| Test | Evidence | Assertion |
|------|---------|-----------|
| Monthly material balance | `[REC]` opening stock + GRN − issuances = closing; `[PHY]` physical count at month-end | EX, CO, AC |
| BOM theoretical vs. actual scrap | `[REC]` BOM blank weight × production qty vs. `[INS]` weigh-gate log (100% population) | AC |
| Scrap revenue reconciliation | `[REC]` weigh-gate kg × market price; `[CON]` SAT CFDI descarga masiva for scrap sales | CO, AC |
| Scrap buyer RFC — related-party check | `[ANA]` scrap buyer RFC vs. employee/management RFC list (full population); `[CON]` SAT RFC validation | CP |
| Benford on weigh-gate entries | `[ANA]` first-digit frequency of all scrap weight entries (full population) | AC, CO |
| Annex 24 merma vs. actual scrap | `[REC]` declared merma rate × imported volume vs. actual scrap weighed | CP, AC |
| CFDI for every scrap sale | `[CON]` SAT descarga masiva — compare scrap CFDI count to weigh-gate exit count | CO, CP |

---

## Step 5 — Report structure

Owned by `gia-report-qa:gia-ia-report` (standard concise report plus Excel working paper). This pack emits a findings register only. Include the regulatory calendar and the pack's open-dependency table in the working paper.

---

## Step 6 — Optional: data:analyze Customization

Read `references/mx-analyze_skill_template.md`. Output `[COMPANY]_analyze_skill_customization.md`
covering: KPI definitions, regulatory thresholds as auto-flag logic, ERP data source inventory
(MES, CFDI XML, SUA, SISUB, Annex 24, weigh-gate), and analysis templates for Tax Dashboard,
Material Balance, S&OP Performance, Scrap Reconciliation, REPSE Monitor, Risk Dashboard.

---

## Validation Standards — Non-Negotiable

| Standard | Rule |
|----------|------|
| **Evidence first** | No finding stated before evidence obtained and documented |
| **Quantify always** | Every finding states the exposure in MXN, kg, or % — or explains why it cannot be quantified |
| **Cite specifically** | Law + article + year; IIA Standard + number; no vague references |
| **Tag evidence** | Every test tagged: `[INS]` `[PHY]` `[CON]` `[REP]` `[REC]` `[OBS]` `[ANA]` |
| **Challenge always** | Apply professional skepticism; corroborate management explanations |
| **No assumed plant facts** | Plant type, state and border status that are not supplied are carried as open dependencies in the working paper, not assumed |
| **No inference as finding** | "Appears to" / "likely" / "probably" are prohibited in findings |
| **Regulatory calendar** | Always include next 3–5 filing deadlines |
| **IIA 2024 alignment** | All process observations reference specific IIA Standards |
| **Disclaimer** | Every report includes the CPR / attorney review disclaimer |
