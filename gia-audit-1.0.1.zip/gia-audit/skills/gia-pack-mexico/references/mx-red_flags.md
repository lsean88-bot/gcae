> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-mexico.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules; the [INS]/[CON]/[ANA] tags are source-type labels, not evidence ranks.
## Contents
- How to Use This File
- SAT / Fiscal Red Flags
- Payroll / Labor Red Flags
- IMMEX / Customs Red Flags
- Financial Reporting (NIF) Red Flags
- Environmental Red Flags (SEMARNAT)
- Safety Red Flags (STPS NOMs)
- Internal Controls / Anti-Fraud Red Flags
- ERM / Risk Management Red Flags
- REPSE / Subcontracting Red Flags
- Operational / Quality Red Flags
- Ethics, Anti-Bribery & Anti-Corruption (ABAC) Red Flags
- Metal Stamping / Tooling Specific Red Flags


# Red Flag Logic — Mexican Manufacturing Audit

## How to Use This File
Apply these checks across all seven domains. When a red flag condition is met (or cannot be
ruled out due to missing data), include it as a finding in the report with the appropriate
priority level.

---

## SAT / Fiscal Red Flags

| Condition | Priority | Regulatory Basis |
|-----------|----------|-----------------|
| Any CFDI still on version 3.3 | 🔴 | SAT — version 4.0 mandatory |
| Supplier RFC on EFOS blacklist | 🔴 | CFF Art. 69-B — criminal liability |
| CFDI not validated against SAT portal | 🔴 | 2026 Tax Reform — false CFDI = criminal |
| Cash payments >USD 2,000 per transaction | 🔴 | CFF Art. 31-A — non-deductible |
| Monthly contabilidad electrónica uploaded late | 🟠 | CFF Art. 28 — fines per day |
| ISR provisional payment below coefficient | 🟠 | LISR Art. 14 — recargos + actualization |
| IVA saldo a favor above the [MX-052] threshold | 🟠 | LIVA — triggers SAT refund audit |
| Tooling/dies capitalized inconsistently | 🟡 | LISR Art. 34 — depreciation dispute |
| Missing CFDI for deductible expenses | 🟠 | LISR Art. 27 III — non-deductible |
| Annual ISR return filed after March 31 | 🟠 | CFF Art. 81 — automatic fine |
| Transfer pricing study missing or >3 years old | 🟡 | LISR Art. 76 IX — DIOR required |

## Payroll / Labor Red Flags

| Condition | Priority | Regulatory Basis |
|-----------|----------|-----------------|
| IMSS registered workers < payroll headcount | 🔴 | LSS Art. 15 — back contributions + fines |
| SBC < (base salary × 1.10) for manufacturing | 🔴 | LSS Art. 27 — integrated salary underreporting |
| IMSS risk class not III or IV for metal stamping | 🟠 | LSS Art. 74 — incorrect premium |
| Payroll CFDIs missing for any pay period | 🔴 | [MX-040] |
| PTU not accrued on balance sheet | 🟠 | LFT Art. 120 — [MX-033] |
| IMSS alta/baja not reported within 5 days | 🟡 | LSS Art. 15 I — fines per worker |
| ISN rate differs from state-published rate | 🟡 | State fiscal codes — varies |
| Sunday premium ([MX-055]) missing from payroll | 🟡 | LFT Art. 71 |
| Overtime >3 hours/day or >3 days/week | 🟠 | LFT Art. 68 — double/triple pay required |
| Vacation premium ([MX-032]) not paid on anniversary | 🟡 | LFT Art. 80 |
| PTU paid more than 60 days after ISR filing | 🟠 | LFT Art. 122 |

## IMMEX / Customs Red Flags

| Condition | Priority | Regulatory Basis |
|-----------|----------|-----------------|
| Annex 24 inventory not reconciled monthly | 🔴 | Decreto IMMEX Art. 24 — program cancellation |
| Export ratio <60% (or <80% for Annex II goods) | 🔴 | Decreto IMMEX Art. 11 — cancellation risk |
| IVA/IEPS certification expired or not obtained | 🔴 | LIVA Art. 28-A — full IVA on temp imports |
| IMMEX registration not covering all product lines | 🟠 | SE Decreto — unauthorized manufacturing |
| Pedimentos not archived 5 years | 🟡 | CFF Art. 30 |
| Transfer of temporarily imported goods without pedimento | 🔴 | Ley Aduanera Art. 106 |

## Financial Reporting (NIF) Red Flags

| Condition | Priority | Regulatory Basis |
|-----------|----------|-----------------|
| Physical inventory count >12 months ago | 🟠 | NIF C-4 — requires periodic count |
| Scrap not written off from inventory | 🟠 | NIF C-4 — overstatement |
| Dies/tooling not tested for impairment annually | 🟡 | NIF C-15 |
| WIP balance static >30 days | 🟡 | NIF C-4 — investigate completion |
| Depreciation rate for presses differs from [MX-047] | 🟠 | LISR Art. 34 (fiscal) / NIF C-6 (book) |
| Actuarial study for seniority premium not obtained | 🟡 | NIF D-3 |
| Deferred ISR (ISR diferido) not recorded | 🟠 | NIF D-4 |
| NIS sustainability data not collected for 2025 | 🟡 | CINIF NIS — mandatory 2026 disclosure |
| Revenue recognized before delivery/acceptance | 🟠 | NIF C-23 (IFRS 15 aligned) |

## Environmental Red Flags (SEMARNAT)

| Condition | Priority | Regulatory Basis |
|-----------|----------|-----------------|
| LAU or COA expired or not filed | 🔴 | LGEEPA — plant shutdown risk |
| Hazardous waste (metalworking fluids, oils) not manifested | 🔴 | NOM-052-SEMARNAT-2005 |
| Wastewater discharge without treatment | 🔴 | NOM-001-SEMARNAT / NOM-002-SEMARNAT |
| Hazardous waste carrier not authorized by SEMARNAT | 🔴 | LGEEPA Art. 151 |
| COA (Cédula de Operación Anual) not filed annually | 🟠 | LGEEPA |

## Safety Red Flags (STPS NOMs)

| Condition | Priority | NOM |
|-----------|----------|-----|
| Stamping press without two-hand control or guard | 🔴 | NOM-004-STPS-1999 |
| No audiometric testing in high-noise areas | 🟠 | NOM-011-STPS-2001 |
| PPE not provided or documented | 🟠 | NOM-017-STPS-2008 |
| Electrical panels unlabeled or unsafe | 🟠 | NOM-001-STPS-2008 |
| Lighting below minimum lux levels | 🟡 | NOM-025-STPS-2008 |
| Workplace accident not reported to IMSS (RT-01) | 🔴 | LSS / STPS |
| STPS re-inspection order unresolved | 🟠 | STPS enforcement |

## Internal Controls / Anti-Fraud Red Flags

| Condition | Priority | Notes |
|-----------|----------|-------|
| Scrap sold without CFDI | 🔴 | SAT — unreported income; IVA not charged |
| Scrap sold (kg) vs. BOM theoretical scrap gap >10% | 🟠 | Theft or recording error |
| Vendor in AP with no RFC, no address, or duplicate bank account | 🔴 | Phantom vendor / fraud |
| Steel/aluminum purchase price >15% above LME | 🟠 | Possible above-market / related party |
| Bank reconciliation prepared by same person who handles cash | 🟠 | Control weakness |
| No dual authorization for wire transfers | 🟠 | Control weakness |
| Purchases >threshold without 3 competitive quotes | 🟡 | Procurement policy gap |
| Intercompany loans not disclosed in financial statements | 🟠 | NIF C-3 / related party disclosure |

## ERM / Risk Management Red Flags

| Condition | Priority | Basis |
|-----------|----------|-------|
| No risk register exists at all | 🔴 | IIA 2024 Standard 9.2 — risk-based audit planning required |
| Risk register not updated in >12 months | 🟠 | COSO ERM 2017 Component 4 — Review & Revision |
| No risk owner assigned to any risk | 🟠 | COSO ERM 2017 — accountability required per principle |
| Internal audit plan not aligned to risk register | 🟠 | IIA 2024 Standard 9.2 |
| No audit committee or risk oversight body | 🔴 | IIA 2024 Standard 11.1; CMPC best practice |
| Risk appetite not documented or not communicated | 🟠 | COSO ERM 2017 Component 1 — Governance & Culture |
| No whistleblower channel or channel never used/reported | 🟠 | IIA 2024 anti-fraud standards; best practice |
| Prior audit findings open >90 days without remediation plan | 🟠 | IIA 2024 Standard 12.2 — performance accountability |
| CAE (Chief Audit Executive) reports only to CFO, not audit committee | 🟠 | IIA 2024 — independence requirement |

## REPSE / Subcontracting Red Flags

| Condition | Priority | Legal Basis |
|-----------|----------|-------------|
| Service provider NOT registered in REPSE | 🔴 | LFT Art. 15-C; LISR Art. 27 — non-deductible expense |
| REPSE certificate expired during service period | 🔴 | LFT Art. 15-C — equivalent to unregistered |
| ISR retention ([MX-041]) not withheld from provider invoices | 🔴 | LISR Art. 27 — ISR liability + fines |
| IVA retention ([MX-041]) not withheld (when applicable) | 🔴 | LIVA Art. 32 Frac. VIII |
| SISUB not filed quarterly with SAT | 🔴 | CFF — criminal fraud risk for simulated operations |
| Services contracted are NOT specialized (core business outsourced) | 🔴 | LFT Art. 13 — prohibited general outsourcing |
| No written service contract on file | 🟠 | LFT Art. 15-B |
| Provider IMSS/INFONAVIT compliance not obtained monthly | 🟠 | LSS Art. 15-A — joint beneficiary liability |
| STPS 2025 inspection readiness not assessed | 🟠 | STPS Protocol November 2025 |

## Operational / Quality Red Flags

| Condition | Priority | Basis |
|-----------|----------|-------|
| OEE <65% with no documented improvement plan | 🔴 | Operational efficiency — customer/business risk |
| Customer OTIF (On-Time In-Full) <90% without waiver | 🟠 | Customer contract breach risk |
| PPAP not approved before production of new part | 🔴 | IATF 16949 / customer CSR — customer recall risk |
| ISO 9001 internal audits not conducted in 12+ months | 🟠 | ISO 9001:2015 cl. 9.2 — certification at risk |
| Non-conforming material not physically segregated | 🟠 | ISO 9001:2015 cl. 8.7; NIF C-4 inventory integrity |
| BOM material yield variance >10% without explanation | 🟠 | Scrap/theft risk; NIF C-4 costing error |
| No supplier approved list or qualification process | 🔴 | Incoming quality risk; customer CSR violation |
| Customer-owned tooling on company's balance sheet | 🔴 | NIF C-6 — asset misstatement; customer ownership dispute |
| No warranty reserve despite contractual warranty exposure | 🟠 | NIF C-9 — liability understatement |
| Gauge calibration records expired or missing | 🟡 | ISO 9001:2015 cl. 9.1 — measurement integrity |

## Ethics, Anti-Bribery & Anti-Corruption (ABAC) Red Flags

| Condition | Priority | Basis |
|-----------|----------|-------|
| No Code of Ethics or ABAC Policy exists | 🔴 | LGRA Art. 25 — no compliance program mitigator; FCPA/UKBA exposure |
| Government official in vendor list or receiving payments | 🔴 | CPF Arts. 222–224 (cohecho); FCPA criminal liability; LGRA Art. 21 |
| No third-party due diligence for agents, customs brokers, or government-relations consultants | 🔴 | FCPA — company liable for agent's bribery; UKBA Section 7 |
| PEP (Politically Exposed Person) identified in vendor chain but not escalated | 🔴 | FCPA; LGSNA; LFPIORPI AML risk |
| Company funds used for political contributions | 🔴 | LFACP; LGSNA — disqualification and criminal risk |
| Facilitation payments made to public officials | 🔴 | LGRA Art. 21; UKBA absolute prohibition |
| Conflicts of interest (COI) declarations not completed annually | 🟠 | IIA 2024 Standard 8.2; ISO 37001 conflict-of-interest clause [MX-037] |
| Gift & hospitality register not maintained or not reviewed in 12+ months | 🟠 | ISO 37001 gift and hospitality control clause [MX-037]; FCPA adequate procedures defense |
| ABAC training not conducted for procurement, customs, or logistics staff | 🟠 | ISO 37001 training clause [MX-037]; FCPA adequate procedures |
| Whistleblower channel inactive, unknown to employees, or managed by HR/CFO | 🟠 | ACFE RTTN 2024; IIA 2024 Standard 8.2; ISO 37002:2021 |
| No ABAC clause (right-to-audit, termination-for-cause) in third-party contracts | 🟠 | FCPA; UKBA "adequate procedures" defense |
| Employee lifestyle inconsistent with salary (car, home, travel) without explanation | 🟠 | CFE behavioral red flag — embezzlement or kickback indicator |
| Key procurement/finance employee has not taken vacation in >2 years | 🟠 | ACFE — fraud perpetrators avoid absence; classic red flag |
| Single approver for vendor setup + PO approval + payment release | 🔴 | SOD failure — direct fraud enabler; IIA 2024 Standard 9.2 |
| Vendor RFC matches employee RFC or family member name | 🔴 | Undisclosed conflict of interest; phantom vendor risk |
| No investigation protocol for fraud allegations | 🟠 | CFE standards; IIA 2024 — risk of mishandled / inadmissible evidence |
| Whistleblower channel has zero reports in >24 months | 🟠 | ACFE — likely unknown/untrusted, not necessarily clean; investigate channel awareness |

## Metal Stamping / Tooling Specific Red Flags

| Condition | Priority | Basis |
|-----------|----------|-------|
| No die master register or physical die count not performed in >12 months | 🔴 | Asset control; NIF C-6 — fixed asset misstatement |
| Customer-owned dies included on company's balance sheet | 🔴 | NIF C-6 — asset misstatement; customer ownership dispute |
| No written customer tooling agreement for customer-owned dies | 🟠 | Contract risk; liability on die damage or loss |
| IATF 16949 certificate expired or surveillance audit overdue | 🔴 | Customer may suspend or disqualify supplier immediately |
| No PFMEA or control plan for an active production part | 🔴 | IATF 16949 cl. 8.5.1.1; customer CSR violation; recall risk |
| PPAP not approved by customer before SOP (start of production) | 🔴 | IATF 16949 cl. 8.6.4; customer rejection / chargeback risk |
| Gauge R&R >30% on a special characteristic gauge in production use | 🔴 | AIAG MSA — measurement invalid; production decisions unreliable |
| Cpk <1.33 for special characteristic in production without customer deviation | 🔴 | OEM CSR violation; field nonconformance risk |
| No coil material test certificate (MTC) on file for a production heat | 🟠 | Traceability failure; IATF 16949 cl. 8.5.2; automotive recall exposure |
| Out-of-spec MTC accepted into production without engineering deviation | 🔴 | Material nonconformance; safety/regulatory risk for automotive parts |
| Press tonnage monitoring bypassed or overload protection non-functional | 🔴 | NOM-004-STPS safety; die damage; operator injury risk |
| HSS/AHSS parts produced with no springback compensation or control plan | 🟠 | Dimensional nonconformance; customer return risk |
| Die PM program not followed — overdue maintenance per stroke counter | 🟠 | Unplanned downtime risk; die damage; production interruption |
| CSRs not reviewed after known OEM revision (e.g., GM CSR 2024, Ford CSR) | 🟠 | Compliance gap; customer audit finding risk |
| Customer OTIF <98% for Tier 1 automotive customer without approved deviation | 🟠 | Customer scorecard; potential D0D (Delivery 0 Defects) violation |
| Open 8D corrective action past customer-agreed submission deadline | 🟠 | Customer escalation; potential shipment hold |
| No first-off / last-off inspection records for production runs | 🟠 | IATF 16949 cl. 8.6.1; quality escape risk |
| Coil inventory consumed out of FIFO order (heat traceability lost) | 🟠 | IATF 16949 traceability; automotive customer recall exposure |
| No approved supplier list or non-approved material supplier used without deviation | 🔴 | IATF 16949 cl. 8.4.1; incoming quality risk; customer CSR violation |
| KPI dashboard (OEE, PPM, OTIF, scrap rate) not reviewed at management review | 🟠 | IATF 16949 cl. 9.3 violation; blind operational governance |
