> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-mexico.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules; the [INS]/[CON]/[ANA] tags are source-type labels, not evidence ranks.
## Contents
- Why Operational Audit Matters for Manufacturing
- OEE — Overall Equipment Effectiveness
- Production Planning & Scheduling Controls
- Non-Conforming Product Controls (ISO 9001 cl. 8.7 / NIF C-4)
- ISO 9001:2015 — Key Audit Areas for Manufacturing
- Customer Contract Compliance
- Supplier Qualification & Performance Controls
- Warranty Reserve Adequacy
- BOM Accuracy vs. Actual Production Consumption
- IATF 16949:2016 — Automotive Quality Management System
- AIAG Core Tools — Audit Requirements for Auto Parts Stamping
- Metal Stamping Specific — Tooling & Die Governance
- Operational Governance — Board & Management Reporting


# Operational Audit — Manufacturing, Quality & Contract Management

## Why Operational Audit Matters for Manufacturing
Financial and compliance audits catch regulatory exposure. Operational audits catch whether the
plant is actually producing efficiently, meeting customer commitments, and managing quality
systemically. In a Mexican manufacturing context, operational failures drive scrap costs (NIF C-4
inventory hits), warranty reserves (income statement), and customer penalties (revenue leakage).

---

## OEE — Overall Equipment Effectiveness

OEE = Availability × Performance × Quality Rate

| Component | Formula | Benchmark (World-Class) |
|-----------|---------|------------------------|
| **Availability** | Uptime / Planned production time | ≥ 90% |
| **Performance** | (Actual output × Ideal cycle time) / Uptime | ≥ 95% |
| **Quality Rate** | Good parts / Total parts produced | ≥ 99.5% |
| **OEE** | Availability × Performance × Quality | ≥ 85% world-class; <65% = 🔴 |

**Audit procedure:**
- Request OEE reports for all major presses/machines for the review period
- Compare actual OEE to plant target — if no target exists, that is itself a finding
- Identify top 3 downtime causes (Pareto analysis); verify corrective actions are open and tracked
- Compare theoretical capacity to actual throughput; unexplained gap may indicate production
  recording errors or unreported rework

**Red flags:**
- OEE <65% with no documented improvement plan: 🔴
- OEE tracked manually with no system data: 🟠 (data integrity risk)
- Downtime recorded as "miscellaneous" without root cause: 🟠
- Cycle time consistently slower than engineered standard without explanation: 🟡

---

## Production Planning & Scheduling Controls

| Control | Audit Test |
|---------|-----------|
| Customer orders matched to production schedule | Compare customer PO delivery dates to production plan; identify stockouts or late deliveries |
| BOM (Bill of Materials) approved and version-controlled | Request BOM master; check last revision date and approval signature; compare to actual production consumption |
| Engineering Change Notice (ECN) process | Any BOM or drawing change must have ECN signed by engineering AND customer (if customer-specific part) before production |
| Work-in-process (WIP) control | WIP >30 days static in any work center = production bottleneck or write-off needed (NIF C-4) |
| Expedite/premium freight tracking | Any premium freight must be approved and cost allocated to root cause — customer fault vs. internal fault |

---

## Non-Conforming Product Controls (ISO 9001 cl. 8.7 / NIF C-4)

Non-conforming product must be:
1. **Identified** — physically tagged or quarantined; not mixed with good inventory
2. **Segregated** — non-conforming bin/area separate from production flow
3. **Dispositioned** — rework, scrap, or return to supplier — with documented approval
4. **Recorded** — every NCR (Non-Conformance Report) logged in system
5. **Valued correctly** — scrapped product written off NIF C-4 inventory immediately

**Red flags:**
- NCR log has gaps or is not updated regularly: 🟠
- Rework performed without documented approval or re-inspection: 🟠
- Customer returns (RMAs) not matched back to NCR for root cause: 🟠
- Scrap disposition undocumented (material just disappears from inventory): 🔴

---

## ISO 9001:2015 — Key Audit Areas for Manufacturing

If the plant holds ISO 9001 certification, the following are required:

| Clause | Requirement | Audit Test |
|--------|-------------|-----------|
| **4.2** | Document control | Are documents version-controlled? Is obsolete version removed from production floor? |
| **6.1** | Risks and opportunities | Risk register aligned to Quality Management System (QMS)? |
| **7.2** | Competence | Are operators trained and records maintained? Are training records current? |
| **8.3** | Design & development | Is ECN process documented? Customer approval for changes? |
| **8.4** | External providers | Is supplier approved list maintained? Supplier audits performed? |
| **8.7** | Nonconforming outputs | See section above |
| **9.1** | Monitoring & measurement | Are gauges calibrated? Calibration certificates current? |
| **9.2** | Internal audit | Are QMS internal audits performed annually? Findings closed? |
| **9.3** | Management review | Is management review conducted annually with required inputs? |
| **10.2** | Corrective action (CAPA) | Are CAPAs opened for all significant nonconformances? Are they closed on time? |

**Red flags:**
- Surveillance audit findings from registrar body not fully closed: 🟠
- No internal QMS audits in past 12 months (ISO 9001 cl. 9.2 violation): 🟠
- Customer-specific requirements (CSR) not documented in work instructions: 🟠
- Calibration records for gauges/measurement tools missing or expired: 🟡

---

## Customer Contract Compliance

| Area | Audit Test | Red Flag |
|------|-----------|---------|
| **Delivery performance (OTIF)** | Request OTIF report for past 12 months | OTIF <95% without customer waiver: 🟠 |
| **Penalty clauses** | Review customer contracts for penalty terms; compare to actual charge-backs received | Charge-backs not tracked or accrued: 🟠 |
| **Price escalation clauses** | Are raw material escalation clauses invoked when steel/aluminum exceeds threshold? | Failure to invoice escalation = revenue leakage: 🟠 |
| **Customer-owned tooling** | Customer-owned dies/tooling must be tracked separately; not on company balance sheet | Commingling: 🔴 (misstatement of assets) |
| **Quality agreements (CSR)** | IATF 16949 / customer-specific requirements documented and trained | CSRs not maintained in QMS: 🟠 |
| **PPAP / FAI** | Production Part Approval Process for new parts — approved by customer before production | Running production without PPAP approval: 🔴 |
| **Annual re-pricing (Amortización)** | Are customer-requested annual price reductions (typical in auto industry) properly reflected in revenue recognition? | Unpresented credits = revenue overstatement: 🟠 |

---

## Supplier Qualification & Performance Controls

| Control | Requirement |
|---------|------------|
| **Approved supplier list (ASL)** | All production material suppliers must be on approved list; non-approved suppliers require written waiver |
| **Supplier quality audits** | Critical suppliers (single-source, long-lead-time) should be audited at least annually |
| **Incoming inspection** | First article inspection for new suppliers or new parts; skip-lot for approved stable suppliers |
| **Supplier PPAP** | If supplying to Tier 1 / OEM customers: require PPAP from your own sub-suppliers for critical components |
| **Supplier score card** | Formal score card (quality PPM, delivery, responsiveness) reviewed quarterly |
| **Single-source risk** | Any single-source critical material = documented risk mitigation plan required (ERM register) |

**Red flags:**
- Steel/aluminum purchased from supplier NOT on approved list without waiver: 🟠
- No supplier qualification process — anyone can be added to AP master: 🔴
- Critical supplier visited last >2 years ago with no audit: 🟡

---

## Warranty Reserve Adequacy

For plants that ship parts with warranty obligations (common in auto supply):
- **Warranty reserve** must be accrued at time of sale (NIF C-9 / NIF C-23)
- Reserve should be based on historical warranty claim rate × revenue
- Reserve must be reviewed at each reporting period
- Large unexpected warranty claims (e.g., field recall) must be assessed for additional accrual

**Red flag:** No warranty reserve despite known warranty exposure with customer contracts = NIF C-9
understatement of liabilities: 🟠

---

## BOM Accuracy vs. Actual Production Consumption

| Test | Method |
|------|--------|
| **Material yield variance** | Compare actual material consumed per part to BOM-standard consumption — variance >5% requires investigation |
| **BOM completeness** | Spot-check production orders; verify all BOM components are listed and correct quantities |
| **Labor routing accuracy** | Compare actual labor hours per production order to routing standard |
| **Overhead absorption** | If plant uses standard costing: actual overhead vs. absorbed overhead gap should be explained |

**Why it matters:** Inaccurate BOMs lead to: (1) inventory costing errors (NIF C-4), (2) incorrect
cost of goods sold, (3) incorrect pricing/quoting for new business, and (4) masking of scrap or
theft (if material disappears and no BOM variance is flagged).

---

## IATF 16949:2016 — Automotive Quality Management System

IATF 16949 supersedes ISO/TS 16949 and is **mandatory** for Tier 1 and Tier 2 automotive
suppliers. It adds customer-specific requirements (CSR) on top of ISO 9001 clauses.

### Critical IATF 16949 Audit Areas

| Clause | Requirement | Audit Test |
|--------|-------------|-----------|
| **4.3.2** | Customer-specific requirements | CSRs from each OEM/Tier 1 customer documented, approved, and incorporated into work instructions and control plans |
| **6.1.2.3** | Contingency plans | Documented plans for machine breakdown, material shortage, key personnel absence, natural disaster — reviewed annually |
| **7.2.1** | Competency on-the-job training | Operator certification records for each press/operation; evidence of training effectiveness evaluation |
| **7.2.3** | Internal auditor competency | Automotive auditors must be trained to IATF 16949 and CSR requirements specifically |
| **8.3.3.3** | Special characteristics | All special characteristics (safety, regulatory, fit/function) identified on drawings, PFMEA, control plan, and work instructions — symbol consistency required |
| **8.3.4.1** | Monitoring (APQP) | Advanced Product Quality Planning gate reviews documented for all new programs |
| **8.5.1.1** | Control plan | Every part must have a control plan (pre-launch and production) cross-referenced to PFMEA and work instructions |
| **8.5.2.1** | Standardized work | Work instructions available at point of use, in Spanish (or operator's language), with visual aids |
| **8.6.1** | Acceptance criteria | Acceptance criteria documented for every inspection operation; go/no-go gauges correlated to drawing tolerances |
| **8.6.2** | Layout inspection/functional testing | Full-dimensional layout at customer-required frequency (typically annual per CSR) |
| **9.1.1.1** | Manufacturing process monitoring | Statistical data (SPC charts) for all special characteristics during production |
| **10.2.3** | Problem solving | Structured 8D methodology required for all customer-reported nonconformances |
| **10.2.4** | Error-proofing | Poka-yoke devices documented and tested at defined frequency; failure of error-proofing device = stop production |
| **10.3.1** | Continual improvement plan | Formal improvement plan with measurable targets reviewed at management review |

**Red flags:**
- IATF 16949 certificate expired or surveillance audit overdue: 🔴 (customer may suspend shipments)
- CSRs not reviewed after customer update (e.g., GM CSR 2024 revision, Ford CSR Q1): 🟠
- No PFMEA or control plan for a current production part: 🔴
- 8D corrective action not submitted to customer within agreed timeframe: 🟠

---

## AIAG Core Tools — Audit Requirements for Auto Parts Stamping

### APQP (Advanced Product Quality Planning)

| Phase | Key Deliverable | Audit Test |
|-------|----------------|-----------|
| Phase 1 — Plan & Define | VOC, design goals, preliminary BOM | Evidence that customer requirements were reviewed at program launch |
| Phase 2 — Product Design & Development | DFMEA (if design responsible), design validation plan | Design changes documented; customer approval on record |
| Phase 3 — Process Design & Development | PFMEA, flow diagram, control plan (pre-launch), work instructions, MSA plan, SPC plan | All four documents cross-referenced consistently |
| Phase 4 — Product & Process Validation | MSA results, SPC studies, PPAP, production trial run | PPAP approved by customer before SOP |
| Phase 5 — Feedback & Corrective Action | Warranty tracking, customer scorecard review, lessons learned | Regular management review of Phase 5 KPIs |

**Red flag:** No APQP record for a program launched in past 3 years: 🟠 (IATF 16949 cl. 8.3.4.1)

### PFMEA (Process Failure Mode & Effects Analysis)

- Must be completed before production launch
- Based on **AIAG-VDA FMEA Handbook (2019)** — 7-step methodology
- All Severity ≥ 8 or RPN ≥ 100 must have documented risk mitigation actions
- Must be updated when: new part, process change, customer complaint, field failure

**Audit procedure:**
1. Request PFMEA for a high-volume, high-risk part (highest scrap or highest OEM complaint rate)
2. Verify all process steps in the process flow diagram appear in the PFMEA
3. Verify all Special Characteristics have Severity ≥ 9 or 10 (safety) or 7–8 (functional)
4. Verify Recommended Actions have owners and closure dates
5. Verify revision date reflects most recent process change

### MSA (Measurement System Analysis)

- Gauge R&R study required for all measurement gauges on special characteristics
- **Acceptance threshold:** %GRR ≤ 10% acceptable; 10–30% conditionally acceptable; >30% = gauge unacceptable for production use
- Gauge must be recalibrated per schedule; calibration certificate on file
- Attribute gauges (go/no-go) require Attribute Agreement Analysis (kappa study)

**Red flag:**
- Gauge used in production with %GRR >30%: 🔴 (measurement invalid — production decisions unreliable)
- Gauge calibration certificate expired: 🟡
- No MSA study on record for a special characteristic gauge: 🟠

### SPC (Statistical Process Control)

- Required for all special characteristics (IATF 16949 cl. 9.1.1.1)
- **Cpk ≥ 1.67** required for special characteristics (most OEM CSRs); minimum Cpk ≥ 1.33 for general characteristics
- Control charts reviewed by operator every shift; action taken on out-of-control points (Western Electric rules)
- Pre-control charts acceptable for short-run production if Cpk study is not feasible

**Audit procedure:**
1. Request last 30 days of SPC data for top special characteristics
2. Calculate Cpk from available data; compare to CSR requirement
3. Check for out-of-control signals with no documented response
4. Verify control limits are recalculated after significant process changes

---

## Metal Stamping Specific — Tooling & Die Governance

Tooling/die governance is a critical operational and financial risk area unique to metal stamping.
Dies are capital assets (sometimes >USD 500,000 per die) with complex ownership, maintenance,
and lifecycle considerations.

### Die Inventory & Ownership Control

| Control | Requirement | Audit Test |
|---------|------------|-----------|
| **Die master register** | Every die catalogued: die number, part number, customer, material, press tonnage, owned by (company vs. customer), location, condition | Compare physical count to register; unexplained gaps = 🔴 |
| **Customer-owned die segregation** | Customer-owned dies physically tagged, stored separately, excluded from company balance sheet (NIF C-6) | Dies on balance sheet that customer paid for = asset misstatement: 🔴 |
| **Customer die agreement** | Written agreement with each customer for customer-owned tooling: ownership confirmation, maintenance responsibility, insurance, liability on damage | No written agreement: 🟠 |
| **Annual customer die confirmation** | Customer confirms in writing the die inventory held on their behalf | Not confirmed >12 months: 🟠 |
| **Insurance** | Dies insured at replacement value (company-owned: in property policy; customer-owned: verify customer's policy or indemnity clause) | Uninsured die loss = unbudgeted expense: 🟠 |

### Die Maintenance Program

| Element | Best Practice | Audit Test |
|---------|--------------|-----------|
| **Preventive maintenance (PM) schedule** | Each die has a PM schedule based on stroke count (e.g., PM every 50,000 hits) | Request PM schedule and maintenance log for top 5 dies by production volume |
| **Stroke counter / hit counter** | Every active die has a stroke counter; PM triggered by counter reading, not calendar | Dies without stroke counters: 🟡 |
| **Die condition rating** | Dies rated A/B/C or equivalent scale after each PM; C-rated dies have improvement plan | No condition rating system: 🟡 |
| **Die repair log** | Every repair documented: date, repair type, parts replaced, estimated remaining life | No repair log: 🟠 |
| **Critical spare parts inventory** | Critical die components (punches, pilots, lifters) stocked to avoid extended downtime | No spare parts for single-source or long-lead components: 🟠 |
| **Try-out records** | Every die modification requires documented try-out results (dimensional check, first article inspection) | Modifications made without documented try-out: 🟠 |

### Die Cost Accounting & Capitalization

| Issue | Requirement | Audit Test |
|-------|------------|-----------|
| **Capitalization threshold** | Company policy defines minimum die cost for capitalization (typically MXN 20,000–50,000); below = expense | Verify policy exists and is applied consistently (NIF C-6) |
| **Amortization method** | Dies depreciated by units-of-production method (strokes) or straight-line over estimated useful life | Compare method to LISR Art. 34 (fiscal rate per [MX-047]) and company policy |
| **Customer-funded tooling** | If customer pays for tooling, recognize as deferred revenue and amortize over production life — or set off against die cost | Improper treatment = revenue/asset misstatement |
| **Tooling write-off** | Obsolete dies (program ended, customer moved out) must be written off or written down (NIF C-15 impairment) | Dies for cancelled programs still on balance sheet: 🟠 |
| **Tooling in progress (TIP)** | Die build costs accumulated in WIP until die is production-ready; transfer to fixed assets upon PPAP approval | Dies in TIP >18 months without PPAP: 🟠 |

### Stamping-Specific Production Controls

| Control | Purpose | Audit Test |
|---------|---------|-----------|
| **Blank weight control** | Each blank weighed or verified against theoretical blank weight; deviation triggers coil traceability review | Weight variance >3% per coil = possible wrong material: 🟠 |
| **Coil FIFO tracking** | Coils consumed in FIFO order; heat number and certificate matched to production order | Mixed heats or non-FIFO consumption = traceability failure for automotive: 🟠 |
| **Material certification (MTC) on file** | Mill test certificate on file for every coil heat; grade, thickness, yield strength, tensile strength verified against drawing requirements | No MTC on file: 🟠; out-of-spec MTC accepted without deviation: 🔴 |
| **Coil remnant (tailings) control** | Coil remnants tagged with heat number and weight; stored separately; accounted for in BOM variance | Untagged remnants = inventory reconciliation risk: 🟡 |
| **Springback monitoring** | For high-strength steel (HSS/AHSS) parts: springback measured and compensated; die re-try documented | HSS parts with no springback control plan: 🟠 (dimensional non-conformance risk) |
| **Press tonnage monitoring** | Press tonnage set and monitored per die specification; overload protection functional | No tonnage monitoring or overload bypass: 🔴 (NOM-004-STPS safety + die damage) |
| **First-off / last-off inspection** | First and last part of every production run inspected dimensionally; results in production record | No first-off inspection records: 🟠 |
| **Lubrication control** | Draw lubricant type, viscosity, and application rate specified per die; deviations recorded | No lubrication specification: 🟡 |

### Customer-Specific Requirements (CSR) — Key Automotive OEMs

| Customer | Key CSR References | Critical Requirements |
|---------|-------------------|----------------------|
| **General Motors** | GM1927 / BIQS (Buick-level Supplier Quality Standard) | BIQS certification required for preferred supplier status; specific PFMEA and control plan format requirements |
| **Ford Motor Company** | Ford CSR Q1 / FCPA (Ford Customer-Specific Attributes) | Q1 certification required; AIAG FMEA Handbook 2019 mandatory; MMOG/LE logistics requirements |
| **Stellantis** | Bronze/Silver/Gold certification | Tiered supplier development; supplier portal SQP compliance |
| **Volkswagen Group** | VDA 6.3 process audit | VDA 6.3:2023 process audit required; P4–P7 process elements; VDA FMEA format (aligned with AIAG-VDA) |
| **Nissan/Renault** | Alliance Production Way | Requires DOJO training compliance; specific production readiness reviews |
| **Toyota** | TSSC (Toyota Supplier Support Center) criteria | TPS-aligned production system; standardized work emphasis; abnormality management |

**Audit procedure:** Request list of all active OEM customers → pull applicable CSR document → verify plant QMS documentation is current vs. latest CSR revision date.

---

## Operational Governance — Board & Management Reporting

### KPI Dashboard — Minimum Required for Management Review

| KPI | Target | Frequency |
|-----|--------|-----------|
| OEE by machine/press line | ≥85% world-class | Weekly / monthly |
| OTIF (On-Time In-Full delivery) | ≥98% for auto Tier 1 | Weekly |
| Customer PPM (Parts Per Million defective) | <50 PPM (Tier 1 typical target) | Monthly |
| Internal scrap rate % | <2% (by material weight) | Weekly |
| First-pass yield | ≥98% | Daily / weekly |
| Die downtime % | <5% of scheduled production | Monthly |
| DPPM (Delivered PPM to end customer) | Defined per CSR | Monthly |
| Material yield efficiency | ≥actual vs. BOM standard ±2% | Monthly |
| Press utilization | Compare actual vs. theoretical capacity | Monthly |
| Open corrective action (8D) past due | 0 past due | Weekly |

**Red flag:** No formal KPI dashboard reviewed at management review: 🟠 (IATF 16949 cl. 9.3 violation)

