> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-mexico.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules; the [INS]/[CON]/[ANA] tags are source-type labels, not evidence ranks.
## Contents
- Why Material Balance Is Critical
- Material Flow Diagram — Metal Stamping
- BOM-Based Theoretical Yield Calculation
- Monthly Material Balance Reconciliation
- IMMEX Material Balance (Annex 24 Reconciliation)
- Scrap Categories & SAT Tax Treatment
- Scrap Diversion Fraud — Detection Protocol
- Excel Scrap Reconciliation Template Logic
- Material Balance Reporting — IIA Standard Requirements
- Regulatory Calendar — Material Balance
- Evidence-Annotated Test Programme — Material Balance & Scrap


# End-to-End Material Balance & Scrap Reconciliation — Metal Stamping Manufacturing

## Why Material Balance Is Critical

In metal stamping, raw material (steel coil) typically represents **60–75% of COGS**. Even a 1% unexplained variance in material yield = significant P&L exposure. Key risks:

- **Scrap diversion fraud:** Skeleton scrap and turnings sold off-book or by unauthorized personnel
- **BOM yield errors:** Incorrect yield factors causing systematic under-ordering (production stoppages) or over-ordering (excess inventory)
- **IMMEX compliance:** Imported materials must be accounted for through production, export, or destruction. Unexplained losses = potential customs fraud
- **NIF C-4:** Inventory must be valued correctly; unreconciled material variance = potential financial misstatement
- **SAT scrutiny:** Scrap revenue must have CFDI; unexplained scrap without CFDI = income omission

---

## Material Flow Diagram — Metal Stamping

```
PURCHASED COIL (kg)
        │
        ▼
[GRN / Receiving] → Tagged with heat number, MTC, weight
        │
        ▼
[Raw Material Stores] → FIFO queue by heat/grade
        │
[Material Issuance] → Issued to Production Order (kg per order)
        │
        ▼
┌─────────────────────────────────────┐
│           PRESS OPERATION           │
│  Blanking / Progressive Die / Fine  │
├─────────────────────────────────────┤
│  Input: Coil weight issued          │
│  Output A: Good parts (kg)          │
│  Output B: Skeleton / skeletal scrap│
│  Output C: Coil edge trim (turnings)│
│  Output D: Rework parts             │
│  Output E: Rejected / scraped parts │
└─────────────────────────────────────┘
        │
        ▼
[Good Parts] → Finished Goods / Next Operation
[Scrap Streams] → Scrap Yard (by category)
        │
        ▼
[Scrap Weigh-Gate] → Weighed by category
        │
        ▼
[Scrap Sale] → CFDI issued to scrap buyer
```

---

## BOM-Based Theoretical Yield Calculation

For each stamped part, the BOM defines the **theoretical material yield**:

```
Theoretical Part Weight (kg) = Blank weight per part × (1 + Scrap factor)

Blank Weight (kg) = Blank Length (mm) × Blank Width (mm) × Thickness (mm) × Steel density (7.85 g/cm³) ÷ 1,000,000

Scrap Factor = (Input Material − Good Part Weight) ÷ Input Material
            = (Skeleton + Edge Trim + Rework + Reject) ÷ Total Input
```

**Typical stamping scrap rates by process:**
| Process | Typical Scrap Rate | Notes |
|---------|-------------------|-------|
| Progressive die blanking | 15–25% | Skeleton scrap is primary loss |
| Transfer die | 8–15% | Less skeletal scrap; pre-blanked |
| Fine blanking | 20–35% | Higher material utilization but more edge scrap |
| Deep draw | 10–20% | Trimmed flanges = scrap |
| Roll forming | 2–5% | Very low scrap — primarily trim ends |

---

## Monthly Material Balance Reconciliation

### Step 1: Opening and Closing Inventory

```
Opening Raw Material Inventory (kg)
+ Purchases Received (kg) [from GRN register]
− Issued to Production (kg) [from material issuance register]
= Closing Theoretical Raw Material Inventory (kg)

Variance = Closing Physical Count (kg) − Closing Theoretical (kg)
```

**Acceptable variance:** ±0.5% of throughput volume  
**Investigate:** >1%  
**Critical:** >3% = potential fraud or systematic BOM error: 🔴

### Step 2: Production Yield Reconciliation

```
Total Material Issued to Production (kg)
− Theoretical Good Parts Weight (parts produced × BOM part weight)
= Theoretical Scrap (kg)

Variance = Theoretical Scrap − Actual Scrap Weighed at Yard (kg)
```

**Acceptable variance:** ±2% of total scrap volume  
**Investigate:** >5%  
**Critical:** >10% = scrap diversion or unrecorded production: 🔴

### Step 3: Scrap Revenue Reconciliation

```
Scrap Weighed at Gate (kg by category: skeletal, turnings, reject parts)
× Market price (MXN/kg for each category — validate against LME/AHMSA price)
= Expected Scrap Revenue (MXN)

Compare to: Scrap CFDI revenue in SAT CFDI universe for period
```

**Red flags:**
- Scrap sold below market price to related buyer: 🔴 (possible kickback or related-party fraud)
- Scrap weight at gate does not reconcile to BOM theoretical scrap: 🔴
- Scrap CFDI for previous month not yet issued: 🟠 (SAT income omission exposure)
- Scrap buyer has only one or two CFDI per year — possible consolidation/non-reporting: 🟠

---

## IMMEX Material Balance (Annex 24 Reconciliation)

For IMMEX plants, ALL imported raw materials are tracked in the Annex 24 virtual inventory system:

### Annex 24 Material Balance
```
Opening Annex 24 Balance (kg)
+ Imports in Period (pedimentos de importación temporal)
− Exports (pedimentos de exportación — parts in finished goods)
− Mermas (authorized shrinkage/scrap — reported to ANAM)
− Destructions (authorized destruction with ANAM notary supervision)
− Domestic Sales (transfer to domestic operation with duty payment)
= Closing Annex 24 Balance (kg)

Compare to: Physical + ERP inventory balance
```

**Mermas (Authorized Shrinkage):** The percentage of imported material that is expected to become scrap in the production process. The merma rate must be:
- Declared to ANAM in advance
- Consistent with BOM yield factors
- Documented in the Programa IMMEX registration

**Audit test:**
1. Pull Annex 24 report (from IMMEX software — Tradelink, ERP customs module, or manual)
2. Reconcile to physical inventory count
3. Verify merma rate declared vs. actual scrap rate per production records
4. Calculate export ratio: Exported value ÷ Total production value ≥ 60% (or 80% for certain sectors)

**Critical red flags:**
- Annex 24 balance does not reconcile to physical + production records: 🔴 (ANAM customs violation; potential AML)
- Merma rate not declared or rate exceeds declared limit: 🔴
- Imported materials not exported or destroyed within 18-month maximum term: 🔴 (duty liability)
- Export ratio below threshold: 🔴 (loss of IMMEX authorization)

---

## Scrap Categories & SAT Tax Treatment

### Scrap Tax Classification — Mexico

| Scrap Category | SAT Product Key (ClaveProdServ) | IVA Rate | ISR Treatment |
|---------------|--------------------------------|----------|--------------|
| Acero chatarra (ferrous scrap) | 72041090 | [MX-046] | Revenue recognized on CFDI date; ISR accrual |
| Aluminio chatarra | 76020000 | 16% | Same |
| Turnings / viruta de acero | 72043000 | 16% | Same |
| Recortes de lámina (stampings trim) | 72042990 | 16% | Same |
| Chatarra de cobre | 74040000 | 16% | Same |

**CFDI requirement:** Every scrap sale, regardless of size, requires CFDI v4.0. Even cash scrap sales at the gate require CFDI. Failure = income omission.

**IVA on scrap sales:** Unlike some agricultural or basic goods, scrap metal is taxed at the full rate ([MX-046]). This is a common compliance error — some plants try to classify scrap as "waste" to avoid IVA, which is incorrect.

**REPSE consideration:** If the scrap buyer provides segregation/loading services at the plant, those services are subject to REPSE registration and IVA retention requirements.

---

## Scrap Diversion Fraud — Detection Protocol

This is one of the most common fraud schemes in Mexican manufacturing (ACFE Fraud Tree — Asset Misappropriation: Inventory Theft).

### Common Schemes
1. **Short-weighting at gate:** Weigh-gate scale calibrated incorrectly or manipulated; less scrap recorded = difference pocketed
2. **Off-gate sales:** Scrap removed through a secondary gate not covered by weigh-gate; sold without CFDI
3. **Reclassification fraud:** Premium scrap (copper, aluminum) reclassified as low-value iron scrap on records; difference paid in cash
4. **Phantom production losses:** Production orders show higher scrap than actually generated; real scrap sold separately without CFDI
5. **Buyer collusion:** Scrap sold at below-market price to buyer owned by plant supervisor/manager (conflict of interest)

### Detection Analytics
| Test | Data Source | Red Flag Threshold |
|------|------------|-------------------|
| BOM theoretical scrap vs. weigh-gate | ERP + weigh-gate log | >5% unexplained gap per part/month |
| Scrap revenue per kg vs. market price | CFDI archive + LME/AHMSA price index | Price <90% of market = potential kickback |
| Weigh-gate entries per day vs. production days | Weigh-gate log | Days with zero scrap but active production = diversion risk |
| Scrap buyer RFC — related-party check | SAT RFC database + employee/management RFC list | Any match = 🔴 conflict of interest investigation |
| Year-over-year scrap rate trend | Production + ERP | Declining scrap rate year-on-year without process change = possible under-reporting |
| Benford's Law on scrap weights | Weigh-gate log | First-digit anomalies in transaction weights = possible fabrication |

---

## Excel Scrap Reconciliation Template Logic

For auditors building a scrap reconciliation workbook:

```
Column Layout (monthly by part number):
A: Part Number
B: Production Qty (units)
C: BOM Part Weight (kg/unit)
D: Theoretical Good Part Output (kg) = B × C
E: Issued to Production (kg) [from ERP material issuance]
F: Theoretical Scrap (kg) = E − D
G: Theoretical Scrap Rate (%) = F / E × 100%
H: Actual Scrap Weighed (kg) [from weigh-gate by part/press line]
I: Variance (kg) = F − H
J: Variance (%) = I / F × 100%
K: Variance Flag = IF(ABS(J)>5%, "🔴 INVESTIGATE", IF(ABS(J)>2%, "🟠 Review", "✅ OK"))
L: Scrap Revenue @ Market Price = H × Market Price (MXN/kg)
M: Actual CFDI Scrap Revenue [from CFDI archive]
N: Revenue Variance = L − M
O: Revenue Variance Flag = IF(ABS(N/L)>10%, "🔴 INVESTIGATE", "✅ OK")
```

**Automation tip:** Use VLOOKUP or XLOOKUP to pull material issuance from ERP export; use data validation to flag scrap buyer RFC against employee roster.

---

## Material Balance Reporting — IIA Standard Requirements

Per IIA 2024 Global Internal Audit Standards:
- **Standard 10.2 (Audit Report Quality):** Material balance findings must quantify financial exposure (kg × MXN/kg = MXN exposure)
- **Standard 9.1 (Risk Assessment):** Scrap diversion is classified as Asset Misappropriation under ACFE Fraud Tree — must be explicitly included in risk assessment
- **Standard 11.1 (Escalation):** If forensic indicators are present (Benford anomalies + buyer related-party match), escalate to Audit Committee immediately; engage forensic accountant

---

## Regulatory Calendar — Material Balance

| Obligation | Deadline | Regulatory Basis |
|-----------|---------|-----------------|
| Annex 24 reconciliation (monthly) | 10th of following month | IMMEX Operating Manual |
| Merma rate declaration renewal | Annual (program year) | ANAM / IMMEX Decree |
| Export ratio certification | Annual (January for prior year) | IMMEX Decreto Art. 29 |
| SAT contabilidad electrónica (including inventory accounts) | 25th of following month | CFF Art. 28 |
| Annual ISR return (inventory-driven COGS) | March 31 | LISR Art. 9 |
| Annual physical inventory (NIF C-4) | Within 2 months of fiscal year end | NIF C-4 para. 55 |

---

## Evidence-Annotated Test Programme — Material Balance & Scrap

Every test below states: Evidence Type | Assertion | Population | Procedure | Expected vs. Actual

### TEST MB-01: Monthly Raw Material Balance
- **Assertion:** CO (Completeness), AC (Accuracy), EX (Existence)
- **Evidence:** `[INS]` ERP goods receipt (GRN) report + `[INS]` material issuance report + `[PHY]` physical count
- **Population:** All coil movements in period (100% — system extract)
- **Procedure:** Opening stock (ERP) + GRN total (kg) − Issuances (kg) = Theoretical closing. Compare to physical count kg.
- **Expected:** Variance ≤0.5% of throughput
- **Finding trigger:** Variance >1% → investigate root cause before stating finding. Variance >3% with no explanation → 🔴 (quantify: kg × MXN/kg = exposure)
- **Prohibited:** Do NOT state "there may be a variance" without running the calculation

### TEST MB-02: BOM Theoretical vs. Actual Scrap
- **Assertion:** AC (Accuracy), CO (Completeness)
- **Evidence:** `[REC]` BOM recalculation + `[INS]` production order completions + `[INS]` weigh-gate log (100% population)
- **Population:** All production orders in period
- **Procedure:** For each part: (issued kg − good parts kg) = theoretical scrap. Compare to actual weigh-gate entry for same production order.
- **Expected:** Variance ≤2% of total scrap volume per part
- **Finding trigger:** >5% unexplained → 🟠. >10% → 🔴. Quantify: (Variance kg × scrap market price MXN/kg) = unsupported revenue exposure

### TEST MB-03: Scrap Revenue vs. CFDI Universe
- **Assertion:** CO (Completeness), AC (Accuracy)
- **Evidence:** `[CON]` SAT descarga masiva (scrap CFDIs issued) + `[INS]` weigh-gate exit log + `[REC]` price × weight
- **Population:** All weigh-gate exits in period (100%)
- **Procedure:** Count weigh-gate exits by buyer; sum kg. Pull scrap CFDIs from SAT portal. Match: each weigh-gate exit should have a corresponding CFDI. Any exit without CFDI = unreported income.
- **Expected:** CFDI count = weigh-gate exit count. CFDI revenue ≥ weigh-gate weight × market floor price
- **Finding trigger:** Any exit without CFDI → 🔴 (SAT income omission). Price <90% market → 🔴 (under-invoicing / kickback)

### TEST MB-04: Scrap Buyer RFC — Conflict of Interest Screen
- **Assertion:** CP (Compliance)
- **Evidence:** `[ANA]` full-population RFC match + `[CON]` SAT RFC validation for each buyer
- **Population:** All scrap buyers in period (from CFDI buyer RFC list)
- **Procedure:** Extract unique buyer RFCs from scrap CFDIs. Compare to employee/management RFC list. Validate each buyer RFC at `rfc.sat.gob.mx` — confirm legal entity exists and is active.
- **Expected:** Zero matches between buyer RFC and employee roster. All buyer RFCs active and valid.
- **Finding trigger:** Any RFC match → 🔴 (conflict of interest investigation required per Domain 11). Invalid RFC → 🔴 (potential phantom buyer / income concealment)

### TEST MB-05: Annex 24 Merma Compliance
- **Assertion:** CP (Compliance), AC (Accuracy)
- **Evidence:** `[INS]` Annex 24 system export + `[REC]` actual scrap rate vs. declared merma rate + `[CON]` ANAM/IMMEX programme file
- **Population:** All import pedimentos in period
- **Procedure:** Pull declared merma % from IMMEX programme. Calculate actual scrap % from MB-02. Compare. Calculate exposure: (Actual merma − Declared merma) × CIF value of imports × applicable tariff rate = customs duty exposure.
- **Expected:** Actual merma ≤ declared merma + 2% tolerance
- **Finding trigger:** Actual >declared → 🔴. Quantify duty exposure in MXN. Do NOT speculate — use actual tariff rate from pedimento.

### TEST MB-06: Benford's Law — Weigh-Gate Entries
- **Assertion:** AC (Accuracy), CO (Completeness)
- **Evidence:** `[ANA]` statistical test on 100% of weigh-gate weight entries
- **Population:** All weigh-gate entries in period
- **Procedure:** Benford and digit tests: run through `gia-fraud:gia-fraud-analytics` (Nigrini MAD primary with per-digit z-scores; chi-square supplementary for small populations). Confirm the preconditions (population size, range across orders of magnitude, no assigned or bounded numbers), segment fixed-amount populations first, and record the MAD table version in the workpaper. A deviation is an indicator, never a conclusion. Inline thresholds from the retired source were removed.
- **Expected:** MAD and per-digit z-scores within the bands recorded in the analytics output.
- **Finding trigger:** Indicator only. Do NOT conclude fraud from Benford alone; combine with MB-03 and MB-04 before escalating.
- **Note:** Benford deviation is a red flag requiring additional `[INS]` or `[PHY]` corroboration before a finding is stated as confirmed.
