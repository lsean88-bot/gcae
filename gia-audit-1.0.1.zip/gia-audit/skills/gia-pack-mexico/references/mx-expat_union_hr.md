> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-mexico.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules; the [INS]/[CON]/[ANA] tags are source-type labels, not evidence ranks.
## Contents
- PART A: EXPATRIATE WORKFORCE
- PART B: UNION LAW & COLLECTIVE BARGAINING
- PART C: MANPOWER CONTROLS
- Evidence-Annotated Test Programme — Expat, Union & Manpower


# Expat Hire, Union Law & Manpower Controls — Mexican Manufacturing

## PART A: EXPATRIATE WORKFORCE

### Immigration — Work Authorization (INM)
**Instituto Nacional de Migración (INM) — Ley de Migración 2011**

| Permit Type | Applicable Situation | Duration |
|------------|---------------------|---------|
| **Residente Temporal con permiso para trabajar** | Expat employed by Mexican entity; most common for plant managers, engineers | Up to 4 years, renewable |
| **Residente Permanente** | After 4 years as Residente Temporal, or if married to Mexican national | Indefinite |
| **Visitante con permiso para realizar actividades remuneradas** | Short-term technical assistance, training assignments | Max 180 days; non-renewable |
| **Visa APEC Business Travel Card (ABTC)** | Korean, Japanese nationals — business meetings only; NO work authorization | Short visits only |

**Critical:** Working in Mexico without valid INM work authorization violates Ley de Migración Art. 148. Sanction: expat deportation + company fine up to 10,000 UMA. Korean nationals seconded to Mexico from parent companies are frequently non-compliant.

**Audit procedure:**
1. Request list of all foreign nationals on-site (including on-loan/seconded)
2. Verify each has current Residente Temporal card (tarjeta) with "permiso para trabajar"
3. Verify the employer on the card matches the Mexican legal entity
4. Check expiry dates — INM notices are typically 30 days before expiry
5. Verify COMAR asylum status if applicable (rare in manufacturing)

**Red flags:**
- Expat working under tourist visa or ABTC: 🔴 (Ley de Migración violation)
- Expat permit registered to parent company rather than Mexican entity: 🔴
- Permit expired >30 days with no renewal in process: 🟠
- No immigration compliance officer or external immigration counsel appointed: 🟡

---

### Expat Tax Compliance — Residencia Fiscal

**Resident vs. Non-Resident threshold:** 183 days (continuous or intermittent) in a calendar year in Mexican territory (LISR Art. 9).

| Status | ISR Treatment | IMSS |
|--------|--------------|------|
| **Tax Resident (≥183 days)** | Subject to Mexican ISR at progressive rates ([MX-042]) on worldwide income | Must be registered; SBC applies to total compensation |
| **Tax Non-Resident (<183 days)** | withholding on Mexico-source salary per [MX-042] | Not mandatorily registered (but check if permanent establishment risk) |

**Shadow Payroll:** If expat is still on parent company payroll (Korea, Malaysia, etc.) but works >183 days in Mexico, Mexican entity must operate a "shadow payroll" to:
- Calculate and withhold Mexican ISR on equivalent salary
- Remit IMSS (if applicable) based on Mexican SBC
- Issue Mexican payroll CFDI (nómina)
- File annual ISR return on behalf of the expat (if tax resident)

**Cost Equalization:** Many MNCs use tax equalization (TEQ) so expat pays no more tax than in home country. The TEQ gross-up creates a CFDI reporting issue — the hypothetical tax deduction must be clearly documented.

**Audit procedure:**
1. Request list of expats with hire date, nationality, days in Mexico (calendar year)
2. For any expat >183 days: verify shadow payroll is active and IMSS registered
3. Verify nómina CFDI issued for expat compensation equivalent
4. Verify ISR withheld and remitted monthly to SAT
5. Review expatriate expense reimbursements — housing, school fees, car — assess if these constitute additional SBC (IMSS) and taxable income (SAT)

**Red flags:**
- No shadow payroll for expat resident >183 days: 🔴 (ISR non-compliance + IMSS exposure)
- Expat housing allowance not included in SBC: 🟠
- Parent company charges management fees instead of salary allocation — check substance vs. withholding tax avoidance: 🔴

---

### Expat Benefits — Common Issues

| Benefit | Tax Treatment | Audit Risk |
|---------|--------------|-----------|
| Housing allowance | Partially exempt up to the limit in [MX-042]; excess = SBC and ISR | Frequently over-excluded |
| School fees for dependents | Fully taxable if paid by company | Often omitted from nómina |
| Home leave flights | Non-taxable if in employment contract as part of assignment package | Verify written policy |
| Club memberships | Fully taxable — "prestaciones en especie" | Often expensed without income recognition |
| Vehicle (company car for personal use) | Taxable in kind (LISR Art. 94 IV) | Frequently omitted |

---

## PART B: UNION LAW & COLLECTIVE BARGAINING

### Legal Framework
| Law | Scope |
|-----|-------|
| **LFT Arts. 356–404** | Union formation, registration, dues, strikes |
| **LFT Arts. 386–403** | Collective Bargaining Agreement (CCT — Contrato Colectivo de Trabajo) |
| **LFT 2019 Labor Reform (Reforma Laboral)** | Democratización sindical: free and secret vote required for CCT ratification |
| **T-MEC / USMCA Annex 23-A** | Labor chapter: effective worker voice, freedom of association, LVC |
| **STPS / CFCRL** | Centro Federal de Conciliación y Registro Laboral — new CCT registration since May 2023 |

### CCT — Contrato Colectivo de Trabajo Audit

**Required contents (LFT Art. 391):**
- Names of signatory parties (union and employer)
- Plants/establishments covered
- Duration (fixed or indefinite — most CCTs are 2-year terms)
- Working conditions: hours, shifts, wages by category, vacations, bonuses
- Training provisions (Capacitación y adiestramiento — LFT Art. 153)

**Audit procedure:**
1. Request copy of current CCT registered with CFCRL (or JLCA for legacy)
2. Verify registration is current (CCT must be re-registered every 2 years)
3. Compare actual wages per category to CCT tabulator — underpayment vs. CCT = labor litigation risk
4. Verify CCT ratification was done by **free and secret vote** of workers (post-2019 reform requirement)
5. Check for "white union" (sindicato de protección): verify union has actual worker membership, not just paper existence
6. Review "cláusula de exclusión" (closed shop): note that exclusion for admission remains legal; exclusion for separation was eliminated by 2019 reform

**Red flags:**
- CCT not registered at CFCRL (new system since May 2023): 🔴 (CCT has no legal effect)
- CCT ratification vote not documented with tally (escrutinio): 🔴 (T-MEC compliance risk + STPS sanction)
- Wages paid below CCT tabulator: 🔴 (retroactive liability + litigation)
- No CTF (Comisión Mixta de Capacitación y Adiestramiento) established: 🟠 (LFT Art. 153-E)

### Strike Risk Assessment (Huelga)
| Trigger | Threshold | Impact |
|---------|-----------|--------|
| Union demands (emplazamiento a huelga) | Filed with CFCRL | Plant shutdown if not resolved within 10 days of strike date |
| CCT revision or salary review refusal | Biennial CCT revision (revisión salarial annually) | Non-response = automatic grounds |
| T-MEC rapid response mechanism | US/Canadian government petition if workers' rights violated | Trade sanctions; shipment delays |

**Audit test:** Review last 3 years of emplazamientos (CFCRL registry); verify each was resolved with signed agreement or arbitration ruling.

---

## PART C: MANPOWER CONTROLS

### Headcount Reconciliation

A complete headcount audit for a manufacturing plant:

| Step | Test | Red Flag |
|------|------|---------|
| 1. HR headcount vs. IMSS SUA | Pull SUA extract; count registered workers by category | Headcount gap (SUA > payroll or vice versa): 🔴 |
| 2. Payroll vs. physical badge access | Compare names on payroll to badge access database | Worker on payroll with no badge access in 30 days: ghost employee 🔴 |
| 3. REPSE contractor headcount vs. payroll | Contractor invoices + REPSE portal headcount vs. service agreement | Undisclosed workers: 🔴 REPSE violation |
| 4. Temporary worker ratio | Temporary vs. permanent contracts (LFT Art. 39); temporary share above the [MX-055] level without justification: risk of permanence demand | Over-use of temporales: 🟠 |
| 5. Apprentice/trainee ratio | Maximum ratio per [MX-051] (LFT Art. 22-A) | Exceeding ratio: fine + retroactive permanent contract: 🟠 |

### Ghost Employee Detection Protocol
1. Extract payroll CFDI complement data: all workers, RFC, CURP, start date, department
2. Cross-match with IMSS SUA: every IMSS-registered worker must be on payroll; every payroll worker must be in IMSS
3. Cross-match with HR records: verify start date, termination date consistent across payroll, IMSS, HR
4. Badge access cross-check: active employees with no badge activity in 30 days
5. Bank account cross-check: two or more employees with same CLABE (bank account number) = ghost employee or direct family benefit scheme: 🔴
6. Deceased worker check: cross CURP with RENAPO death registry (formal audit engagement)

### Severance Liability (Pasivo Laboral) — NIF D-3
Mexico has mandatory severance for all terminations:

| Reason for Termination | Severance | Basis |
|----------------------|-----------|-------|
| **Without justified cause (despido injustificado)** | 3 months salary + 20 days/year of service + seniority premium (12 days/yr) | LFT Art. 50 |
| **Resignation (renuncia voluntaria)** | Seniority premium only if >15 years, or if disability/death | LFT Art. 162 |
| **Justified cause (rescisión)** | No severance; but risk of successful dispute | LFT Art. 47 |

**Actuarial reserve (NIF D-3):** The company must accrue a liability for expected severance based on:
- Current headcount and tenure distribution
- Annual salary level
- Actuarial turnover assumption
- Discount rate (Mexican government bond yield)

**Audit test:** Request actuarial study (actuaría NIF D-3); verify assumptions are reasonable; verify the liability on the balance sheet matches the actuarial calculation; any variance >10% is a material misstatement risk.

### Training Obligations (Capacitación y Adiestramiento) — LFT Art. 153
- All workers must receive job-specific training within 60 days of hire
- Joint training committee (Comisión Mixta) must be established and registered with STPS
- Annual training plan (Planes y Programas de Capacitación) filed with STPS
- Training records per employee must be maintained ≥5 years
- **Audit test:** Verify Comisión Mixta registration certificate; pull 10% sample of worker training records; verify new hire training within 60-day window

---

## Evidence-Annotated Test Programme — Expat, Union & Manpower

### TEST HR-01: INM Work Permit — All Foreign Nationals
- **Assertion:** EX (Existence), CP (Compliance)
- **Evidence:** `[CON]` INM portal verification (`tramites.gob.mx/INM`) for each expat RFC/CURP + `[INS]` physical Tarjeta de Residente copy
- **Population:** 100% of foreign nationals on HR list
- **Procedure:** Obtain full list of all non-Mexican employees from HR. For each: verify Tarjeta de Residente Temporal status at INM portal. Confirm: (a) card is not expired; (b) employer on card matches legal entity; (c) permit type = "con permiso para trabajar". Physical card inspection `[PHY]`.
- **Finding trigger:** Any expat without valid card → 🔴. Card expired >30 days → 🔴. Employer mismatch → 🔴.
- **Prohibited:** Do not accept HR manager's verbal confirmation that permits are current. This is `[INQ]` only. Must verify at INM portal.

### TEST HR-02: Shadow Payroll — Tax Residency (>183 Days)
- **Assertion:** CO (Completeness), AC (Accuracy), CP (Compliance)
- **Evidence:** `[INS]` entry/exit records (passport stamps, IMSS registration dates, company travel records) + `[CON]` SAT nómina CFDI descarga masiva for expat RFC + `[REC]` ISR calculation
- **Population:** All expats with cumulative Mexico days potentially ≥183 in tax year
- **Procedure:** Build day-count calendar for each expat using travel records and badge access log. Any expat ≥183 cumulative days: verify shadow payroll nómina CFDI exists in SAT. If absent: `[REC]` calculate unwithheld ISR = Mexican-source income × applicable rate = exposure.
- **Finding trigger:** No shadow payroll for tax-resident expat → 🔴. Quantify: missed ISR withheld + IMSS contributions.

### TEST HR-03: CCT Registration at CFCRL
- **Assertion:** CP (Compliance), EX (Existence)
- **Evidence:** `[CON]` query `registrodectt.stps.gob.mx` using company RFC
- **Procedure:** Navigate to CFCRL public registry. Search by company RFC. Confirm CCT exists and shows active/registered status. Screenshot and timestamp as working paper evidence.
- **Finding trigger:** Not found at CFCRL → 🔴 (CCT legally void since May 2023 without CFCRL registration — LFT Art. 390 bis). Wages paid under void CCT = no union protection.

### TEST HR-04: CCT Ratification Secret Vote
- **Assertion:** CP (Compliance)
- **Evidence:** `[INS]` tally sheet (escrutinio) signed by union committee and management witnesses
- **Procedure:** Request the ratification vote records for the current and immediately prior CCT. The escrutinio must show: date, number of eligible workers, number voting yes/no, independent observer signature. Verify voting was secret (no individual identification on ballots).
- **Finding trigger:** No escrutinio on file → 🔴 (2019 Reforma Laboral violation; T-MEC Chapter 23 compliance risk). Escrutinio shows <50% approval → 🔴 (CCT not validly ratified).

### TEST HR-05: 4-Way Headcount Reconciliation
- **Assertion:** EX (Existence), CO (Completeness)
- **Evidence:** `[CON]` IMSS SUA portal extract + `[INS]` payroll CFDI nómina (descarga masiva) + `[INS]` HR system headcount + `[INS]` badge access active list
- **Population:** 100% — do not sample headcount
- **Procedure:**
  1. Export IMSS SUA list: all registered RFCs + worker names
  2. Export payroll CFDI nómina: all RFCs receiving payment in period
  3. Export HR system: all active employees
  4. Export badge access: all RFCs with access events in last 30 days
  5. Build 4-column matrix; flag: workers in payroll NOT in IMSS (ghost + non-registered); workers in IMSS NOT in payroll (registered but unpaid); workers in HR NOT in either (administrative error or new hire gap)
- **Finding trigger:** Any name in payroll but not in IMSS → 🔴. Any name in payroll with no badge access 30+ days → 🔴 investigate. Quantify exposure: ghost salary × months.

### TEST HR-06: Wages vs. CCT Tabulator
- **Assertion:** AC (Accuracy), CP (Compliance)
- **Evidence:** `[INS]` current CCT wage tabulator (signed version) + `[REC]` compare payroll CFDI salary per worker category
- **Population:** 100% of workers via payroll CFDI extract
- **Procedure:** Extract salary per worker from nómina CFDI. Assign each worker to CCT job category. `[REC]` calculate: (CCT minimum − Actual salary) for any worker below minimum. Sum = retroactive liability exposure.
- **Finding trigger:** Any worker below CCT minimum → 🔴. Quantify: gap × workers × months at risk.
- **Prohibited:** Do not accept HR statement that "all wages comply" — verify arithmetically.
