> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-mexico.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules; the [INS]/[CON]/[ANA] tags are source-type labels, not evidence ranks.
## Contents
- IVA — Impuesto al Valor Agregado: Complete Rate Schedule
- IEPS — Impuesto Especial sobre Producción y Servicios
- IVA Acreditable (Input VAT Recovery) — Audit Tests
- ISR Tax Rates — Complete Schedule
- IVA Monthly Return — Audit Controls
- IETU / IDE / IMPAC — Note for Legacy Periods
- T-MEC / USMCA Labor Value Content (LVC) — Tax/Compliance Intersection


# Tax Rates & VAT/IVA Compliance Reference — Mexican Manufacturing

## IVA — Impuesto al Valor Agregado: Complete Rate Schedule

| Activity / Location | Rate | Legal Basis |
|--------------------|------|------------|
| General domestic sales & services | [MX-001] | LIVA Art. 1 |
| Exports of goods (manufactura para exportación) | [MX-002] | LIVA Art. 29 |
| Export of services (rendering abroad) | [MX-044] | LIVA Art. 29 IV |
| Border region Norte (46 municipalities: BC, Son, Chih, Coah, NL, Tamps) | [MX-003] | Decreto DOF 31-Dec-2018; renewed DOF 31-Dec-2025 |
| Border region Sur (Qroo, Chis, Camp, Tab) | [MX-003] | Decreto DOF 30-Dec-2020; renewed 31-Dec-2025 |
| Sale of land and residential housing | **Exempt** | LIVA Art. 9 |
| Sale of food products (basic basket / canasta básica) | [MX-044] | LIVA Art. 2-A |
| Medicines and medical supplies | [MX-044] | LIVA Art. 2-A IV |
| Agricultural machinery, fertilizers, pesticides | [MX-044] | LIVA Art. 2-A I |
| Gold, silver, platinum bullion | **Exempt** | LIVA Art. 9 V |

### Critical: Border Zone IVA ([MX-003]) — Audit Requirements (2026)
The decree was renewed December 31, 2025, valid through **December 31, 2026**.

**Eligibility conditions (all must be met):**
- Fiscal domicile established in border region for ≥18 months
- Operations performed **physically** within the border zone (not remote/digital)
- Registered in the SAT "Padrón de Beneficiarios Región Fronteriza" — annual renewal required
- Not on EFOS, EDOS, or firm tax-credit cancellation lists
- Must file notice (aviso) through SAT portal to maintain padrón status

**NOT eligible for the border rate:** intangible goods, digital services, goods delivered outside border zone

**Audit red flags:**
- CFDI issued at the border rate but customer or delivery location is outside border zone: 🔴 (IVA underpayment)
- Company has padrón registration but cannot demonstrate ≥18 months of domicile: 🔴
- Padrón registration lapsed; company continues applying the border rate: 🔴
- Mixed revenue streams (border and non-border) without proper IVA apportionment: 🟠

---

## IEPS — Impuesto Especial sobre Producción y Servicios

IEPS affects manufacturing primarily through:

| Item | IEPS Rate | Notes |
|------|-----------|-------|
| Diesel (industrial use) | Varies by IEPS stimulus; border rate reduced | Verify current DOF rate — monthly adjustment |
| Gasoline (company vehicles, fleet) | Varies | IEPS credit available for industrial diesel (verify with CPR) |
| Pesticides (>Class I) | rate per applicable regulation | Relevant if plant has hazardous chemical cleaning agents classified |
| Energy drinks / sweetened beverages | Not relevant for manufacturing sales |  |

**IEPS on Scrap Sales:** Scrap metal (chatarra) sold domestically is **not subject to IEPS**. However, IEPS-relevant packaging or components embedded in waste may trigger classification issues — confirm with customs broker.

**IEPS Industrial Diesel Credit:** Manufacturers can credit IEPS paid on diesel used in production processes (not transportation) against their monthly IEPS return. Requires CFDI with correct concept code and production use documentation.

---

## IVA Acreditable (Input VAT Recovery) — Audit Tests

IVA paid on purchases is only recoverable (acreditable) when ALL conditions are met:

1. **CFDI v4.0** with correct RFC, name, and tax regime of both parties
2. Expense is **strictly indispensable** for the taxable activity (LIVA Art. 5 I)
3. Paid via **banking system** (CFF Art. 31-A — cash payments lose IVA credit)
4. **Not exempt or zero-rated activities** on the expense side

**IVA Non-Acreditable — Manufacturing Common Errors:**
| Error | Effect | Frequency |
|-------|--------|-----------|
| IVA on employee meals / entertainment claimed as acreditable | IVA credit disallowed; surcharge + interest | High |
| IVA on personal use assets (vehicles >3,500 kg) — only partly acreditable | Under-recovery | Medium |
| IVA on REPSE contractor invoices without retention (Arts. 1-A and 3) | Non-acreditable; penalty | High |
| IVA paid to EFOS vendor (SAT blacklist) | fully disallowed; potential criminal liability | Critical |

### IVA Retention Obligations (Manufacturing-Specific)
Per LIVA Art. 1-A:

| Provider Type | IVA Retention Rate |
|--------------|-------------------|
| REPSE / specialized service provider (person moral) | [MX-004] (of the service value, not the IVA amount) — effective since 2021 |
| REPSE provider (persona física) | [MX-005] |
| Commission agents (comisionistas — personas físicas) | Full IVA ([MX-001]) |
| Foreign digital service providers (if applicable) | Full IVA withheld by financial institution |

**Audit test:** Pull all REPSE/specialized service CFDIs; verify retención IVA code appears on each CFDI; cross-match against SISUB quarterly filing to SAT.

---

## ISR Tax Rates — Complete Schedule

| Taxpayer Type | Rate | Notes |
|--------------|------|-------|
| Corporation (general) | [MX-008] | LISR Art. 9 |
| Corporation in border region Norte/Sur | [MX-009] | Decreto fronterizo; DOF 31-Dec-2025 |
| Dividends distributed to resident individuals | [MX-010] | LISR Art. 140 |
| Dividends to foreign residents (no tax treaty) | [MX-011] | LISR Art. 164 |
| Dividends to foreign residents (with treaty — e.g., Korea 0–5%) | [MX-011] | Verify applicable CMAP treaty |
| Royalties paid abroad | [MX-012] | LISR Art. 167; treaty reduction possible |
| Technical services paid abroad | [MX-013] | LISR Art. 167 |
| Interest paid to foreign related party | [MX-043] | Thin cap rules apply (LISR Art. 28 XXVII) |
| Wages — workers | [MX-042] | LISR Art. 152; employers withhold |
| Expatriate salary (resident for tax) | Same as residents (>183 days) | |
| Expatriate salary (non-resident) | [MX-042] | LISR Art. 154; treaty may reduce |

### ISR Thin Capitalization (Subcapitalización) — LISR Art. 28 XXVII
- Interest on related-party debt exceeding 3:1 debt-to-equity ratio is **non-deductible**
- Exception for financial entities, regulated infrastructure
- Audit test: Calculate total related-party debt vs. fiscal equity; flag if ratio >3:1

### Transfer Pricing — TP Penalties (2026)
- Penalty for not maintaining contemporaneous TP study: penalty per [MX-015]
- DIOR must be filed with annual ISR return (March 31)
- Country-by-Country Report (CbCR) mandatory for multinational groups with consolidated revenue above the threshold in [MX-016]

---

## IVA Monthly Return — Audit Controls

**Filing deadline:** 17th of following month (or next business day)

**Reconciliation chain:**
1. Total IVA charged (causado) on sales CFDIs issued
2. Less: IVA acreditable on purchases (valid CFDIs received)
3. Net = IVA a pagar (positive) or saldo a favor (negative)

**Common discrepancies auditors must test:**
- IVA en declaración ≠ IVA from CFDI universe download (SAT portal) — use `descarga_masiva` tool to pull all CFDIs and reconcile
- IVA claimed on cancelled CFDIs (CFDI with cancellation note) — credit must be reversed
- IVA saldo a favor not properly applied or refunded — cash flow exposure
- IVA refund pending beyond the period in [MX-052] — potential SAT audit trigger

---

## IETU / IDE / IMPAC — Note for Legacy Periods
These taxes were repealed in 2014 (IETU, IMPAC) and 2014 (IDE). They do not apply to current-period audits. If reviewing pre-2014 periods, consult legacy tax reference.

---

## T-MEC / USMCA Labor Value Content (LVC) — Tax/Compliance Intersection

**For automotive manufacturers exporting to US/Canada:**
- LVC requirement: per [MX-053]
- Non-compliance = loss of T-MEC preferential tariff treatment
- **Audit implication:** Payroll records, wage certification, and production allocation must support LVC calculation
- Documentation: Annual wage certification (Annex 23-A of T-MEC); auditor tests payroll vs. LVC threshold workers
- Wage averaging: Mexican plants often average plant-wide wage to verify ≥USD 16/hr (at BANXICO exchange rate)

**TMEC Annex 23-A LVC Audit Tests:**
1. Identify "production workers" vs. supervisory (per T-MEC definition)
2. Calculate average hourly wage using SBC ÷ contracted hours
3. Apply prevailing BANXICO FIX rate to convert MXN to USD
4. If average <USD 16/hr: red flag — potential tariff exposure for exporter customer
5. Verify customer notification if LVC certification cannot be met
