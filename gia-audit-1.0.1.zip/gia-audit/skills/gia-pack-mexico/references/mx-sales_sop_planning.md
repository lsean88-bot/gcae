> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-mexico.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules; the [INS]/[CON]/[ANA] tags are source-type labels, not evidence ranks.
## Contents
- Why This Domain Is Audit-Critical
- S&OP Process Architecture
- Customer Demand Signals — Automotive EDI
- Master Production Schedule (MPS) Controls
- MRP (Material Requirements Planning) Controls
- Production Capacity Planning
- Forecast Accuracy KPIs — Audit Scorecard
- S&OP Governance — IIA Audit Standard Alignment
- Revenue Recognition Link (NIF C-23 / IFRS 15)


# Sales Forecasting, S&OP & Production Planning Reference — Mexican Manufacturing

## Why This Domain Is Audit-Critical

In automotive Tier 1/2 manufacturing, S&OP failures translate directly into:
- Premium freight charges (air freight vs. sea = 10–20× cost differential)
- Customer penalty clauses for late delivery
- Over/under-production creating inventory write-offs (NIF C-4)
- Capacity investment decisions driven by incorrect forecasts (CAPEX misallocation)
- IMMEX compliance risk (over-importing raw materials against export ratio)

---

## S&OP Process Architecture

### Standard S&OP Cycle (Monthly)
| Week | Activity | Participants | Output |
|------|----------|-------------|--------|
| W1 | Demand Review | Sales, Customer Service, Planning | Demand consensus forecast by customer/part |
| W2 | Supply Review | Production, Engineering, Procurement | Capacity constraints, supply bottlenecks |
| W3 | Pre-S&OP Meeting | Finance, Operations, Supply Chain | Financial gap analysis vs. budget |
| W4 | Executive S&OP | GM/CEO, CFO, VP Sales, VP Operations | Decisions, actions, approved plan |

**Audit test:** Verify S&OP meeting minutes, attendance, and decision log for last 6 months. Missing months = governance gap: 🟠. No executive participation = S&OP without authority: 🟠.

---

## Customer Demand Signals — Automotive EDI

| Signal Type | EDI Transaction | Horizon | Binding? |
|------------|----------------|---------|---------|
| **Firm release / shipping schedule** | 830 (Forecast) / 862 (Shipping schedule) | 1–13 weeks | Firm for 4 weeks; forecast beyond |
| **Kanban pull** | 862 / specific customer portal | Daily / weekly | Firm — triggers immediate shipment |
| **Annual program forecast** | Customer Annual Volume Letter / BPCS | 12–24 months | Non-binding; planning only |
| **Spot order / engineering sample** | Manual PO or portal | Immediate | Firm |

**Audit test:**
1. Request last 12 months of customer EDI releases (830/862) for top 5 parts
2. Compare to actual production schedule and shipments
3. Calculate forecast accuracy: (Actual shipment − Forecast) / Forecast × 100%
4. Benchmark: ≤±10% forecast accuracy at 4-week horizon = acceptable

**Red flags:**
- No formal EDI integration; customer releases managed via email: 🟠 (data integrity risk)
- Forecast accuracy >±30% for more than 3 consecutive months: 🟠
- Customer releases downloaded but not loaded into ERP/MRP: 🔴 (planning disconnect)
- Production built to a verbal customer request without written release: 🔴

---

## Master Production Schedule (MPS) Controls

| Control | Best Practice | Audit Test |
|---------|--------------|-----------|
| MPS frozen horizon | Minimum 2 weeks frozen; changes require authorized ECR | Request MPS change log; count unauthorized changes |
| Capacity verification | MPS must not exceed demonstrated press/machine capacity | Compare MPS units × cycle time vs. available capacity hours |
| Make-to-stock vs. make-to-order | Clear policy per customer; avoid uncontrolled finished goods build | Review finished goods aging; identify non-order-backed inventory |
| MPS approval authority | Production Manager + Engineering sign-off on new part introduction | Request authorization matrix for new parts entering MPS |
| MPS-BOM link | Every MPS line must link to approved BOM in ERP | Select 5 MPS entries; verify BOM linkage and BOM approval status |

**Red flags:**
- MPS maintained in Excel separate from ERP/MRP: 🔴 (no single source of truth)
- Frozen horizon not enforced; daily schedule changes distort material requirements: 🟠
- No demonstrated capacity vs. MPS reconciliation: 🟠

---

## MRP (Material Requirements Planning) Controls

MRP converts MPS demand into raw material purchase orders and work orders:

| MRP Parameter | Correct Setting | Audit Test |
|--------------|----------------|-----------|
| **Lead time accuracy** | Each raw material has accurate vendor lead time in ERP | Compare ERP lead time to last 6 purchase orders; flag >25% variance |
| **Safety stock levels** | Based on demand variability × supplier lead time variability; reviewed quarterly | Request safety stock policy; verify coverage calculation is documented |
| **Lot sizing rules** | Min order quantity (MOQ) per supplier agreement; avoid excessive over-ordering | Review coil purchase orders vs. MRP-suggested quantities |
| **BOM accuracy** | BOM yield factors reflecting actual scrap rates | Compare BOM standard scrap % vs. actual scrap rate by part; if variance >5%, BOM is stale |
| **Exception messages** | MRP generates action messages (reschedule in/out, cancel) — must be reviewed daily by planner | Interview planners; verify exception message review frequency |

**Critical audit risk:** If BOM yield factor does not reflect actual scrap, MRP will consistently under-order raw materials, causing production stoppages and emergency purchases at premium cost.

---

## Production Capacity Planning

### Capacity Analysis Framework
```
Available Capacity (hours/month) =
  (Shifts × Hours/shift × Working days) × (1 − Planned downtime %)

Required Capacity (hours/month) =
  Σ (MPS quantity × Standard cycle time per press/work center)

Utilization % = Required ÷ Available × 100%
```

**Benchmarks:**
- Utilization 75–85%: Optimal (buffer for variability)
- Utilization >90%: Risk zone — no buffer for downtime or expedite
- Utilization <60%: Over-capacity — review fixed cost absorption

**Audit test:** Request capacity plan for all major press lines; calculate utilization using above formula; compare to MPS for next 90 days.

**Red flags:**
- No formal capacity plan: 🟠 (IIA Standard 12.1 — operations planning control)
- Consistently >90% utilization with no mitigation plan: 🟠 (delivery risk)
- CAPEX investment in new press not tied to documented capacity gap: 🟠

---

## Forecast Accuracy KPIs — Audit Scorecard

| KPI | Formula | Benchmark | Frequency |
|-----|---------|-----------|-----------|
| **Forecast Accuracy (FA)** | 1 − |Forecast − Actual| / Actual | ≥85% at 4-week horizon | Monthly |
| **MAPE** (Mean Absolute % Error) | Avg |Forecast − Actual| / Actual × 100% | ≤15% | Monthly |
| **Customer OTIF** | On-time and in-full deliveries / total deliveries | ≥98% for Tier 1 auto | Weekly |
| **Finished goods turn (FGT)** | COGS / Avg FG Inventory | ≥12× per year | Monthly |
| **WIP days** | WIP balance / (COGS / 365) | ≤5 days | Monthly |
| **Expedite freight ratio** | Air freight cost / Total freight cost | <5% | Monthly |
| **Unplanned overtime %** | Unplanned OT hours / Total OT hours | <20% | Monthly |

**Audit test:** Request management KPI dashboard; verify each KPI is calculated consistently; identify trends; request root cause analysis for any KPI breached in last 6 months.

---

## S&OP Governance — IIA Audit Standard Alignment

Per IIA 2024 Global Standards, S&OP planning controls are assessed under:
- **Standard 9.1 (Risk Identification):** Forecast risk, customer concentration risk, single-source material risk
- **Standard 12.1 (Operations):** Adequacy of planning processes to meet operational objectives
- **Standard 13.1 (Reporting):** Accuracy of production reports to management

**Control environment assessment:** Does the plant have an S&OP process with documented procedures, defined roles, and executive oversight? Absence = significant control gap in operational governance.

---

## Revenue Recognition Link (NIF C-23 / IFRS 15)

For Mexican plants with domestic customers:
- Revenue recognized when performance obligation satisfied (delivery + customer acceptance)
- Bill-and-hold arrangements require strict criteria (NIF C-23 paras. 83–86)
- Consignment inventory at customer site is **not revenue until customer uses/sells it**

**Audit test:** Select 10 largest invoices in last month; verify shipment documentation (remisión + sign-off) precedes or coincides with CFDI date. Any CFDI issued before shipment = early revenue recognition: 🔴
