# Statutory register - Mexico

Single dated source for every statutory rate, threshold and date used by the Mexico pack. Skill and reference text must point here and must not restate values.

Owner: statutory-validator agent (fills `source URL`, `verified-on`, `status`); freshness gate: `python3 -I ${CLAUDE_PLUGIN_ROOT}/skills/gias-navigator/scripts/check_rates.py` (rows older than 180 days or not VERIFIED are flagged).
Seeded: 2026-10-29 from the retired source skills, **not web-checked**. Every row is `[UNVERIFIED]` until the validator replaces the status with `VERIFIED`, `CORRECTED` or `CONFLICT` and fills `verified-on`.

Column notes:
- `id` is the stable row identifier cited by pointers in the pack (`[MX-nnn]`). Never renumber or reuse an id; append new rows with the next number.
- `value` is copied as stated in the source skill, including its own caveats.
- `source URL` holds the portal named in the source skill; the validator replaces it with the primary-source deep link (gazette, notification, circular).
- Rows with a conflict note are listed in the conflict table at the end. A finding must not cite a row whose status is `[UNVERIFIED]` or `CONFLICT` (see `gia-core:iron-rules`, evidence rules).

## Contents
- Indirect and direct tax
- Payroll, social security and labour
- Standards and penalties
- Conflicts to resolve
- Open dependencies

## Indirect and direct tax
| id | item | Act/section | value | effective date | source URL | verified-on | status |
|---|---|---|---|---|---|---|---|
| MX-001 | IVA general rate | LIVA Art. 1 | 16% | Current | sat.gob.mx | | [UNVERIFIED] |
| MX-002 | IVA on exports of goods and services | LIVA Art. 29 | 0% | Current | sat.gob.mx | | [UNVERIFIED] |
| MX-003 | IVA border-region rate (Norte and Sur) | Decreto DOF 31-Dec-2018 (Norte), DOF 30-Dec-2020 (Sur), renewed DOF 31-Dec-2025 | 8%; valid through 31-Dec-2026; eligibility needs 18 months of border domicile and padron registration | 01-Jan-2026 to 31-Dec-2026 | sat.gob.mx | | [UNVERIFIED] |
| MX-004 | IVA retention on REPSE providers (legal entity) | LIVA Art. 1-A | 6% of the service value | Since 2021 | sat.gob.mx | | [UNVERIFIED] |
| MX-005 | IVA retention on REPSE providers (individual) | LIVA Art. 1-A | 16% of the service value | Since 2021 | sat.gob.mx | | [UNVERIFIED] |
| MX-006 | monthly IVA return due date | LIVA | 17th of the following month (or next business day) | Current | sat.gob.mx | | [UNVERIFIED] |
| MX-007 | cash payment and IVA credit | CFF Art. 31-A; LIVA Art. 5 I | Payments outside the banking system lose the IVA credit; expense must be strictly indispensable | Current | sat.gob.mx | | [UNVERIFIED] |
| MX-008 | corporate income tax | LISR Art. 9 | 30% | Current | sat.gob.mx | | [UNVERIFIED] |
| MX-009 | border-region ISR stimulus | Decreto fronterizo, DOF 31-Dec-2025 | 20%; valid 2026 | 2026 | sat.gob.mx | | [UNVERIFIED] |
| MX-010 | dividend tax, resident individuals | LISR Art. 140 | 10% additional | Current | sat.gob.mx | | [UNVERIFIED] |
| MX-011 | dividend withholding, non-residents without treaty | LISR Art. 164 | 10%; treaty rate 0-5% (e.g. Korea) to be verified | Current | sat.gob.mx | | [UNVERIFIED] |
| MX-012 | royalties paid abroad | LISR Art. 167 | 25-35%; treaty reduction possible | Current | sat.gob.mx | | [UNVERIFIED] |
| MX-013 | technical services paid abroad | LISR Art. 167 | 25% | Current | sat.gob.mx | | [UNVERIFIED] |
| MX-014 | thin capitalisation | LISR Art. 28 XXVII | Related-party debt above 3:1 debt-to-equity: interest non-deductible | Current | sat.gob.mx | | [UNVERIFIED] |
| MX-015 | transfer pricing documentation penalty | TP provisions (instrument not stated in source) | 55% to 75% of omitted tax | 2026 (per source) | sat.gob.mx | | [UNVERIFIED] |
| MX-016 | country-by-country report threshold | Instrument not stated in source | Consolidated revenue above MXN 12 billion | Current | sat.gob.mx | | [UNVERIFIED] |
| MX-017 | CFDI e-invoice version | CFF Art. 29, 29-A | CFDI 4.0 mandatory; 2026 reform escalates criminal liability for false CFDIs (to be confirmed) | 2026 | sat.gob.mx | | [UNVERIFIED] |
| MX-018 | IMMEX / Annex 24 programme status | IMMEX Decree | Verify programme status at audit date | Verify | sat.gob.mx | | [UNVERIFIED] |

## Payroll, social security and labour
| id | item | Act/section | value | effective date | source URL | verified-on | status |
|---|---|---|---|---|---|---|---|
| MX-019 | UMA daily value for the audit year | Ley para Determinar el Valor de la UMA (INEGI) | 2026: daily MXN 117.31; monthly MXN 3,566.22; annual MXN 42,794.64 | 01-Feb-2026 | https://www.inegi.org.mx/contenidos/saladeprensa/boletines/2026/uma/uma2026.pdf | 29-Oct-2026 | VERIFIED (2026 only; other years remain [UNVERIFIED]) |
| MX-020 | general minimum wage 2026 | CONASAMI resolution, DOF 09-12-2025 | MXN 315.04/day (2025: MXN 278.80) | 01-Jan-2026 | https://sidof.segob.gob.mx/notas/docFuente/5775534 | 29-Oct-2026 | VERIFIED |
| MX-021 | border-zone (ZLFN) minimum wage 2026 | CONASAMI resolution, DOF 09-12-2025 | MXN 440.87/day (2025: MXN 419.88) | 01-Jan-2026 | https://sidof.segob.gob.mx/notas/docFuente/5775534 | 29-Oct-2026 | VERIFIED |
| MX-022 | IMSS sickness and maternity, employer | Ley del Seguro Social | About 1.05% to 7.03% (source note: 2025, validate against current UMA) | 2025 per source | imss.gob.mx | | [UNVERIFIED] |
| MX-023 | IMSS sickness and maternity, worker | Ley del Seguro Social | 0.375% | 2025 per source | imss.gob.mx | | [UNVERIFIED] |
| MX-024 | IMSS disability and life, employer | Ley del Seguro Social | 1.75% | 2025 per source | imss.gob.mx | | [UNVERIFIED] |
| MX-025 | IMSS disability and life, worker | Ley del Seguro Social | 0.625% | 2025 per source | imss.gob.mx | | [UNVERIFIED] |
| MX-026 | SAR retirement, employer | Ley del Seguro Social | 2.00% | 2025 per source | imss.gob.mx | | [UNVERIFIED] |
| MX-027 | childcare and social benefits, employer | Ley del Seguro Social | 1.00% | 2025 per source | imss.gob.mx | | [UNVERIFIED] |
| MX-028 | work-risk premium | LSS; DCSST filing | Variable by risk class (metal stamping class III or IV per source); DCSST filed each February | Annual | imss.gob.mx | | [UNVERIFIED] |
| MX-029 | housing fund, employer | LINFONAVIT | 5% of SBC | Current | infonavit.org.mx | | [UNVERIFIED] |
| MX-030 | registration, termination, salary change | LSS | 5 business days for alta, baja and salary modification; SUA payment by the 17th of the following month | Current | imss.gob.mx | | [UNVERIFIED] |
| MX-031 | holiday bonus | LFT | Minimum 15 days salary, paid before 20 December | Current | stps.gob.mx | | [UNVERIFIED] |
| MX-032 | vacation premium | LFT | 25% of vacation salary; vacation per the 2023 reform schedule (12 days in year 1 per source) | Current | stps.gob.mx | | [UNVERIFIED] |
| MX-033 | profit sharing | LFT | 10% of taxable profit | Current | stps.gob.mx | | [UNVERIFIED] |
| MX-034 | state payroll tax | State fiscal codes | Typically 2.0% to 3.0%; source table: Nuevo Leon 3.0, Chihuahua 2.0, Coahuila 2.5, Sonora 2.0, Tamaulipas 2.0, Baja California 2.5, Estado de Mexico 3.0, Jalisco 3.0, CDMX 3.0 | Verify by state and year | State Secretaria de Finanzas | | [UNVERIFIED] |
| MX-035 | T-MEC (USMCA) labour value content wage | T-MEC automotive rules of origin | USD 16 per hour (as stated in source) | Current | gob.mx/stps / USTR | | [UNVERIFIED] |
| MX-036 | specialised services registration | LFT reform 2021 | Registration mandatory for specialised service and work providers | 2021 | stps.gob.mx | | [UNVERIFIED] |

## Standards and penalties
| id | item | Act/section | value | effective date | source URL | verified-on | status |
|---|---|---|---|---|---|---|---|
| MX-037 | ISO 37001 current edition (anti-bribery management systems) | ISO 37001:2025, which revised ISO 37001:2016 | 2025 edition is current; Amd 1:2024 withdrawn. Clause numbers cited in the pack come from the 2016 edition and must be mapped to the current edition before use. Publication month and transition deadline not found | Not stated on page fetched | https://www.iso.org/standard/65034.html | 29-Oct-2026 | VERIFIED (edition only) |
| MX-038 | REPSE subcontracting fine range | LFT / REPSE rules (instrument not stated in source) | Fine of 2,000 to 50,000 UMA per worker affected (as stated in pack source); compute in MXN with the UMA row for the period under review | Current | stps.gob.mx | | [UNVERIFIED] |
| MX-039 | cash payment threshold and deductibility loss | LISR Art. 27 (as stated in pack source) | Cash payments above USD 2,000 equivalent (DOF FIX rate on payment date) are flagged; deductibility lost is the payment multiplied by the ISR rate (MX-008, or MX-009 in the border zone) | Current | sat.gob.mx | | [UNVERIFIED] |
| MX-040 | payroll CFDI and deductibility | LISR Art. 27 XI | Payroll without a payroll CFDI is 100% non-deductible for ISR | Current | sat.gob.mx | | [UNVERIFIED] |
| MX-041 | ISR retention on REPSE provider invoices (as stated in pack source) | LISR Art. 27 (as cited in pack source) | 6% retention shown as ISR in the red-flag, REPSE and workflow sources; MX-004 states the same 6% as an IVA retention: see MX-C4. IVA retention 16% when required (LIVA Art. 32 Frac. VIII); exception where the provider is IVA certified | Current | sat.gob.mx | | [UNVERIFIED] |
| MX-042 | ISR withholding on wages and expatriate salary | LISR Art. 152, 154 | Residents: progressive 1.92% to 35%; non-residents: 15% on Mexico-source salary up to 125 UMA per day, 30% above; treaty may reduce. Housing allowance partially exempt up to 15% of salary | Current | sat.gob.mx | | [UNVERIFIED] |
| MX-043 | interest paid to foreign related party | LISR Art. 28 XXVII; Art. 166 | 4.9% to 35%; thin-capitalisation rule per MX-014 | Current | sat.gob.mx | | [UNVERIFIED] |
| MX-044 | IVA zero-rate goods | LIVA Art. 2-A | 0% on basic-basket food, medicines and medical supplies, agricultural machinery, fertilisers and pesticides; 0% on export of services rendered abroad (Art. 29 IV) | Current | sat.gob.mx | | [UNVERIFIED] |
| MX-045 | IVA credit on temporary imports (IMMEX) | IMMEX Decree; LIVA | 100% IVA credit on temporary imports where the programme holds IVA and IEPS certification; without certification the company pays IVA at the general rate on temporary imports and requests a refund | Current | sat.gob.mx | | [UNVERIFIED] |
| MX-046 | IVA on scrap sales | LIVA Art. 1 | Scrap metal is taxed at the general rate (MX-001), or the border rate (MX-003) in the border zone; CFDI required for every scrap sale | Current | sat.gob.mx | | [UNVERIFIED] |
| MX-047 | fiscal depreciation rates | LISR Art. 34 | Tooling 25% per year; presses 10% per year (pack source) | Current | sat.gob.mx | | [UNVERIFIED] |
| MX-048 | IMSS surcharge on omitted contributions | LSS | 20% surcharge plus inflation update on understated SBC (as stated in pack source) | Current | imss.gob.mx | | [UNVERIFIED] |
| MX-049 | overtime pay | LFT Art. 67 to 68 | First 9 extra hours per week at 200% of the hourly rate; beyond 9 hours at 300% | Current | stps.gob.mx | | [UNVERIFIED] |
| MX-050 | exempt food allowance | LISR; LSS (SBC exclusion) | Food allowances up to 40% of UMA are excluded from SBC (as stated in pack source) | Current | sat.gob.mx | | [UNVERIFIED] |
| MX-051 | apprentice and trainee ratio | LFT Art. 22-A | Maximum 10% of the total workforce; breach: fine and retroactive permanent contract | Current | stps.gob.mx | | [UNVERIFIED] |
| MX-052 | IVA refund audit trigger | LIVA (as stated in pack source) | IVA balance in favour above MXN 1,000,000 triggers SAT refund review; refund pending more than 40 business days is a SAT audit trigger | Current | sat.gob.mx | | [UNVERIFIED] |
| MX-053 | T-MEC regional value content | T-MEC automotive rules of origin (as stated in pack source) | Vehicles 40% to 45% regional value content, parts 25% to 30%; labour value content from workers earning USD 16 per hour or more (see MX-035) | Current | economia.gob.mx | | [UNVERIFIED] |
| MX-054 | gift and procurement approval limits | Company policy illustrations in pack source (not statutory) | Policy examples only: gift MXN 500; business meal MXN 1,500; quotes MXN 10,000 to 100,000 two quotes, above MXN 100,000 three quotes plus CFO approval; die capitalisation MXN 20,000 to 50,000. Each entity's own policy governs | Policy | n/a | | [UNVERIFIED] |
| MX-055 | Sunday premium and temporary-contract share | LFT Art. 71; Art. 39 | Sunday premium 25%; temporary contracts above 25% of the workforce without justification raise a permanence-claim risk (as stated in pack sources) | Current | stps.gob.mx | | [UNVERIFIED] |

## Conflicts to resolve
| id | topic | values in source skills | action for validator |
|---|---|---|---|
| MX-C1 | ISN rate by state | Source gives a single approximate rate per state with 'validate current' | Confirm each state's current rate for the plant's state |
| MX-C2 | UMA value | 2026 verified; other years not supplied | Add UMA for each other year in audit scope |
| MX-C3 | Border IVA / ISR decree validity | Valid through 31-Dec-2026 per source | Confirm DOF text and any extension before FY2027 planning |
| MX-C4 | 6% REPSE retention: ISR or IVA | MX-004 and MX-041: IVA retention (tax rates source) versus ISR retention (red flags, REPSE, workflow sources) | Confirm against LIVA Art. 1-A and LISR before using either label in a finding |

## Open dependencies
- Plant state and border-zone status for the Mexico entity are not supplied in this pack; supply them before using MX-ISN or the border rows.
- Entity code is MKSDL (alias MKSLD in older source text); confirm the code used in engagement files.
- UMA and ISN are year-sensitive; add one row per audit year.
