> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-mexico.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules; the [INS]/[CON]/[ANA] tags are source-type labels, not evidence ranks.
## Contents
- Governing Body
- NIF C-4 — Inventories
- NIF C-6 — Fixed Assets / Property, Plant & Equipment
- NIF D-3 — Employee Benefits
- NIF D-4 — Income Taxes (ISR Diferido)
- NIF C-23 — Revenue Recognition (aligned with IFRS 15)
- NIS — Normas de Información de Sostenibilidad (2026)
- Mexican Income Statement Structure (NIF terminology)


# NIF Financial Reporting Reference — Mexican Manufacturing

## Governing Body
**CINIF** — Consejo Mexicano de Normas de Información Financiera
Standards: NIF (Normas de Información Financiera), converging with IFRS but with local
adjustments. Private companies may elect IFRS instead, but most mid-size Mexican manufacturers
use NIF.

---

## NIF C-4 — Inventories

**Cost Methods Allowed:** FIFO (PEPS) or Average Cost — must be applied **consistently**.
Changing methods requires disclosure and retroactive restatement.

**Manufacturing Inventory Components:**
- Raw material (materia prima): steel/aluminum coils at purchase cost + freight + handling
- Work in Process (WIP): material + direct labor + absorbed overhead
- Finished Goods: full standard/actual cost

**Scrap (Desperdicio):**
- Metal scrap from stamping must be valued at net realizable value (scrap price)
- Removed from WIP/finished goods when generated
- Scrap sold must trigger CFDI and IVA ([MX-046]); it is taxable income

**Physical Count:**
- At minimum annually for annual financial statements
- Count sheets must be signed by counters and supervisors
- Differences between count and ERP must be investigated, not just "adjusted"

**Obsolescence:**
- Slow-moving dies, tooling, or raw material not used in >12 months should be tested
- Write-down to NRV if carrying value exceeds recoverable amount

---

## NIF C-6 — Fixed Assets / Property, Plant & Equipment

**Recognition:** Capitalize if cost is material AND the asset will generate future economic
benefits beyond one year. Maintenance/repair costs that do not extend useful life = expense.

**Fiscal vs. Book Depreciation:** These are DIFFERENT.
- Book (NIF C-6): useful life estimated by management; straight-line most common
- Fiscal (LISR Art. 34): fixed SAT rates (see sat_fiscal.md); used only for tax calculation

**Component Approach:** Major components of a stamping press with different useful lives must
be depreciated separately (e.g., frame vs. hydraulic system vs. controls).

**Common Manufacturing Fixed Asset Categories:**
| Asset | Book Life (typical) | Fiscal Rate |
|-------|---------------------|------------|
| Stamping presses | 10–20 years | 10% |
| Progressive/transfer dies | 3–5 years | 25% |
| Building structures | 30–40 years | 5% |
| Forklifts / material handling | 5–8 years | 25% |
| Computer / ERP | 3–5 years | 30% |

**Impairment (NIF C-15):**
- Annual test required for all long-lived assets, or when indicators of impairment exist
- Impairment indicators for stamping: lost customer program, die retired from service, press
  decommissioned, major production line shutdown

---

## NIF D-3 — Employee Benefits

**Short-term:** Accrue vacation, vacation premium, aguinaldo, PTU in the period earned.
**Long-term:** Require actuarial study by qualified actuary.

**Seniority Premium (Prima de Antigüedad):**
- 12 days salary per year of service
- Accrues for all employees regardless of reason for separation
- Must be actuarially valued annually
- Discount rate: typically using Mexican government bond rates

**Pension obligations:** If plant has a defined benefit pension plan (uncommon but present in
older Tier 1 suppliers), full actuarial valuation required annually.

---

## NIF D-4 — Income Taxes (ISR Diferido)

**Deferred Tax:** Arises from temporary differences between book and fiscal values.

**Common sources in manufacturing:**
- Accelerated fiscal depreciation vs. longer book depreciation → deferred tax liability
- PTU accrual (book) vs. PTU deductible when paid (fiscal) → deferred tax asset
- Provision for doubtful accounts (book) vs. deductible only when written off (fiscal)

**Effective Tax Rate Reconciliation:** Annual financial statements should include a reconciliation
of the statutory rate [MX-008] to the actual effective rate.

---

## NIF C-23 — Revenue Recognition (aligned with IFRS 15)

**Core principle:** Recognize revenue when control transfers to the customer.

**For metal stamping:**
- Revenue recognized upon delivery and written/EDI customer acceptance
- Customer-funded tooling: if ownership transfers to customer at completion, tooling recovery
  is NOT company revenue — it is a reimbursement/reduction of tooling cost
- Price adjustments, retroactive price reductions, quality chargebacks must be estimated and
  netted against revenue in the period of the underlying sale

---

## NIS — Normas de Información de Sostenibilidad (2026)

**Effective:** Financial statements for fiscal year 2025, disclosed in 2026 annual report
**Scope:** All companies reporting under NIF
**Required:** 30 ESG indicators in the notes to financial statements

**Key indicators for metal stamping:**
- Scope 1 emissions (direct: combustion in plant operations)
- Scope 2 emissions (indirect: purchased electricity for presses)
- Water consumption and recycling rates
- Hazardous waste generated and disposed (kg/year)
- Workplace accident rate (IMSS RT-01 data)
- Female workforce percentage, wage gap metrics
- Energy intensity (kWh per ton stamped)

**Immediate action:** Start collecting 2025 data now if not already doing so.

---

## Mexican Income Statement Structure (NIF terminology)

```
Ventas Netas (Net Sales)
− Costo de Ventas (Cost of Goods Sold)
= Utilidad Bruta (Gross Profit)
− Gastos de Venta (Selling Expenses)
− Gastos de Administración (G&A Expenses)
= Utilidad de Operación (Operating Profit / EBIT)
± Resultado Integral de Financiamiento (RIF)
  [Interest income/expense, FX gain/loss, inflation effect]
= Utilidad antes de ISR y PTU
− ISR Causado (Current Tax)
± ISR Diferido (Deferred Tax)
− PTU Causada
± PTU Diferida
= Utilidad Neta (Net Income)
```
