# UMA, minimum wage and ISN year-check

Purpose: stop a prior year's figure being reused. Complete one row per audit year before any payroll, IMSS or ISN recompute. The `statutory-validator` agent fills the cells from primary sources; until a row is `VERIFIED` its values cannot be used in a finding. 2026 rows come from the validated-facts run of 29-Oct-2026; blanks stay unverified.

## Contents
- Year-check table
- ISN by state
- Procedure

## Year-check table
| Audit year | UMA daily | UMA effective date | General minimum wage daily | Border-zone minimum wage daily | Minimum wage effective date | Source URL | verified-on | status |
|---|---|---|---|---|---|---|---|---|
| 2025 | [MX-019] | | [MX-020] | [MX-021] | | | | [UNVERIFIED] (UMA 2025 not supplied) |
| 2026 | [MX-019] | per register | [MX-020] | [MX-021] | per register | see register rows | | per register |

## ISN by state
| State of operation | Year | ISN rate | Effective date | Source URL | verified-on | status |
|---|---|---|---|---|---|---|
| (plant state, to be supplied) | 2025 | | | | | [UNVERIFIED] |
| (plant state, to be supplied) | 2026 | | | | | [UNVERIFIED] |
If the plant operates workers in more than one state, add one row per state and apportion per the payroll reference.

## Procedure
1. Confirm the plant state and border status with the engagement owner; do not assume.
2. Fill the table from the official publications (UMA from the statistics institute, minimum wage from the commission resolution, ISN from the state finance authority).
3. Record effective dates, because the UMA and the minimum wage change on different dates within the year.
4. Use the pay-period-wise value for periods that straddle a change.
5. Add the year to the register `statutory-register-mexico.md` rows MX-019 and MX-034.
