> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-mexico.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules; the [INS]/[CON]/[ANA] tags are source-type labels, not evidence ranks.
## Contents
- Why This Matters for Manufacturing
- Scrap Revenue Controls (Highest Risk Area)
- Procurement Controls
- Phantom Vendor Detection
- Raw Material Purchasing Controls
- Cash & Banking Controls
- Fixed Asset Controls
- Related Party Transactions (NIF C-3)
- Anti-Fraud Forensic Controls (IIA 2024 / COSO ERM)
- CFE Proactive Data Analytics (ACFE Best Practice)
- Ethics, Anti-Bribery & Anti-Corruption (ABAC)


# Internal Controls & Anti-Fraud Reference — Metal Stamping

## Why This Matters for Manufacturing
Metal stamping plants have specific fraud and control risks not found in service businesses:
high-value raw material (steel coils), bulk scrap with cash-equivalent value, expensive dies,
and complex cost structures that can mask overstatements or understatements.

---

## Scrap Revenue Controls (Highest Risk Area)

Metal scrap (desperdicio de metal) is the #1 internal fraud vector in stamping plants.
Scrap has cash value and is easily diverted before it reaches the official weighbridge.

**Required controls:**
1. **BOM-based theoretical scrap calculation:** For every production order, calculate expected
   scrap: `(blanks × blank weight) − (parts × part weight) = theoretical scrap kg`
2. **Physical scrap weighing:** Every scrap container weighed on certified scale before removal
3. **Scale independent from production:** Scale operator should not report to production manager
4. **Scrap removal log:** Scrap buyer truck weigh ticket matched to internal weight record
5. **CFDI for every scrap sale:** SAT requires CFDI for all scrap sales (taxable income, IVA per [MX-046])
6. **Monthly reconciliation:** `Theoretical scrap = Actual scrap sold ± ending scrap inventory`

**Red flag thresholds:**
- Gap >5% between theoretical and actual: investigate; >10%: 🔴 critical finding
- Any scrap removal without internal weight record: 🔴 critical
- Scrap sold to buyer without written contract / recurring buyer: 🟠 elevated risk
- Cash payment for scrap without CFDI from buyer: 🔴 tax evasion risk

---

## Procurement Controls

**Segregation of duties minimum:**
- Purchase request → department head
- Purchase order authorization → purchasing manager (above threshold: CFO/CEO)
- Goods receipt → warehouse (independent of purchasing)
- Invoice approval → accounting (matches PO and receipt)
- Payment release → treasury (independent of accounting entry)

**Competitive bidding thresholds:** Document company policy; typical:
- <MXN 10,000: single quote acceptable
- MXN 10,000–100,000: minimum 2 quotes
- >MXN 100,000: minimum 3 quotes + approval by CFO

**Related-party vendor risk:**
- Run AP vendor master against IMSS employee registry for name/RFC matches
- Check if any vendor RFC = a shareholder, director, or family member RFC
- Any match must be disclosed in financial statements (NIF C-3 related party)

---

## Phantom Vendor Detection

Signs of a phantom (fictitious) vendor in AP master:
- RFC does not exist in SAT's RFC registry
- Vendor address is a residential address or PO Box
- Same bank account number appears for multiple vendors
- Vendor was added without competitive quotes and payment started immediately
- No written contract on file
- CFDI cannot be validated at SAT portal

**Procedure:** Periodically export AP vendor master and run against:
1. SAT RFC validation service
2. SAT EFOS blacklist
3. Internal employee RFC list

---

## Raw Material Purchasing Controls

**Market price anchoring:**
- Steel HRC (hot-rolled coil): benchmark against TERNIUM, AHMSA, Villacero published price lists
- Aluminum: benchmark against LME spot + local premium
- If purchase price >10% above market benchmark: flag for review
- If consistently above market from same supplier: possible kickback or related-party arrangement

**Receiving controls:**
- Each coil arrival: weight verified on certified truck scale vs. supplier certificate
- Coil dimensions and grade certified at receipt; deviation = credit memo request
- No payment released without matching: PO → receipt → certified weight → CFDI

---

## Cash & Banking Controls

**CFF Art. 31-A limit:** USD 2,000 per transaction in cash (efectivo) — above this, expenses
lose ISR deductibility. Use as an audit test: any cash payment above this limit in AP records.

**Bank reconciliation:**
- Prepared monthly within 5 business days of month-end
- Prepared by accounting staff with NO check-signing authority or cash-handling role
- Reviewed by CFO or Controller
- Outstanding items >60 days should be individually investigated

**Wire transfer authorization:**
- Dual control: initiated by one authorized user, released by a separate authorized user
- Bank tokens should be held by different individuals
- Wire limit per transaction without additional approval: define and document

---

## Fixed Asset Controls

**Physical asset tagging:** All assets >MXN 5,000 should have a physical asset tag with asset number
**Annual physical inventory of fixed assets:**
- Compare tag to asset register
- Ghost assets (in register but not physically present): write off
- Unregistered assets (physical but not in register): capitalize or investigate

**Die and tooling custody:**
- Dies owned by customers must be tracked separately (NOT on company's balance sheet)
- Dies must be identified as customer-owned; stored separately from company dies
- Annual die inventory confirmed in writing with customer

---

## Related Party Transactions (NIF C-3)

**Disclosure required in financial statement notes for:**
- Sales or purchases with parent, subsidiaries, or affiliates
- Management compensation (salaries of directors, CEO, CFO)
- Loans between company and shareholders or related entities
- Guarantee or pledge arrangements with related parties

**Red flag:** Any intercompany loan with no written agreement, no interest rate, or interest
rate clearly below market (SAT publishes annual intercompany interest rate benchmarks).
Undocumented intercompany loans = potential deemed dividend = ISR withholding exposure.

---

## Anti-Fraud Forensic Controls (IIA 2024 / COSO ERM)

### Fraud Triangle Assessment

Every audit must assess the three conditions that enable fraud (Donald Cressey's Fraud Triangle):

1. **Pressure / Incentive** — Does the person have a motive?
   - Financial pressure (personal debts, lifestyle mismatch with salary)
   - Performance pressure (unrealistic production or cost targets)
   - Compensation incentives tied to metrics that can be manipulated

2. **Opportunity** — Does the person have access and weak controls?
   - Segregation of duties failures (same person authorizes + pays)
   - Lack of independent reconciliation
   - Override ability without detection (e.g., manual journal entries without approval)

3. **Rationalization** — Does the person justify the behavior?
   - "Everyone does it here"
   - "I'm owed this for years of underpayment"
   - Weak tone at the top that normalizes bending rules

**Audit approach:** For each high-risk area (scrap, procurement, cash), assess which fraud
triangle elements are present and how controls address them.

---

### Ghost Employee Detection

Ghost employees are fictitious workers on the payroll who receive salary but perform no work.
This is a critical risk in high-headcount manufacturing plants.

**Detection tests:**
1. **Headcount reconciliation:** IMSS registered workers (SUA report) vs. HR payroll list vs.
   physical access control log — any person on payroll but not in IMSS and not physically
   present is a ghost employee candidate
2. **Bank account analysis:** Multiple employees paid to same bank account number = red flag
3. **RFC duplicates:** Multiple employees with same RFC = fraud or data entry error
4. **Phantom CURP:** CURP that does not match name or date of birth in RENAPO
5. **New hire pattern:** Employee added by HR person who is also the approver — no second
   review of new hire setup
6. **Terminated employee:** Employee terminated but salary continues for 1+ pay cycles

---

### Journal Entry Testing

Fraudulent financial reporting often appears in manual journal entries. Test:

| Test | What It Catches |
|------|----------------|
| JEs posted by CFO or Controller directly (not accounting staff) | Management override |
| JEs with no supporting document attached | Unsupported entries |
| JEs posted on weekends, holidays, or after midnight | Unusual timing — possible concealment |
| JEs that reverse the following month without explanation | Window-dressing / round-tripping |
| JEs to cash, related-party accounts, or expense accounts in round numbers | Disguised payments |
| JEs that credit revenue and debit intercompany at period-end | Revenue inflation |

**Procedure:** Export all manual JEs for the period; filter by poster = management; sort by date
(look for off-cycle); sort by amount (look for round numbers); require supporting document for
any JE >MXN 50,000 without attached voucher.

---

### Vendor Kickback Indicators

Kickbacks are payments (cash, gifts, or commissions) from vendors to employees who steer
business to them. Red flags:

- Vendor consistently wins without competitive quotes across multiple years
- Vendor charges consistently above market benchmark (material or service)
- Vendor contact shares last name with an employee or manager
- Vendor address is a residential property (detected via Google Maps / SAT address)
- Employee lifestyle (car, house, travel) inconsistent with declared salary
- Vendor added to AP master by same employee who approves their invoices
- Sole-source justification written by the same person who receives the goods/services

---

### Tone at the Top Evaluation

Internal audit must assess whether management culture enables or discourages fraud:

- Does the CEO/CFO override controls without explanation?
- Are audit findings from prior years dismissed without remediation?
- Are employees who raise concerns (via whistleblower) retaliated against?
- Does management set targets that are achievable only through manipulation?
- Is the internal audit function under-resourced or understaffed intentionally?
- Is the audit committee truly independent, or dominated by management-affiliated directors?

**Reporting:** Tone-at-the-top concerns should be reported to the audit committee directly,
bypassing management if necessary (IIA 2024 Standard 11.1 — direct communication to governance).

---

## CFE Proactive Data Analytics (ACFE Best Practice)

Run these tests on every engagement using ERP/accounting data exports. No specialist software
required — all executable in Excel or basic SQL:

| Test | Data Required | Target Finding |
|------|--------------|---------------|
| **Benford's Law** on invoice amounts | All vendor invoices for review period | Non-natural leading-digit distribution = fabricated invoices |
| **Duplicate payment** | AP payment file: vendor, amount, date, invoice # | Same invoice paid twice; duplicate vendor payments |
| **Round-number clustering** on expenses | Employee expense reports | Excessive MXN 500/1,000/2,000 entries = fabricated amounts |
| **Split transaction** (threshold avoidance) | PO and invoice data | Multiple invoices just below bid/approval threshold from same vendor, same day |
| **New vendor + immediate payment** | Vendor creation date vs. first payment | Vendor paid <30 days of creation without competitive bid |
| **Weekend/holiday payments** | AP payment dates | Payments on Saturday, Sunday, or Mexican holidays without business justification |
| **Payroll vs. IMSS SUA headcount** | Payroll list vs. SUA employee report | Workers on payroll not in IMSS system = ghost employee candidates |
| **Payroll bank account duplicates** | Payroll file — CLABE (bank account) | Multiple employees sharing same CLABE = ghost employees or fraud |
| **Vendor-employee RFC match** | AP vendor master RFC vs. HR payroll RFC | Undisclosed related-party vendors |
| **Scrap delta by press/SKU** | BOM theoretical scrap vs. actual scrap sold | Variance >5% per press = diversion indicator |
| **Sole-source frequency by buyer** | PO file — buyer ID vs. vendor ID | Same buyer-vendor pair without competition >3× per year = kickback risk |

**Procedure:** Export required data → run filters → document all hits → assign to sample for
manual follow-up. Document the test, population, sample, exceptions found, and disposition.
Always retain the data extract and workbook in the audit file (IIA 2024 Standard 10.1 — workpaper
documentation standards).

---

## Ethics, Anti-Bribery & Anti-Corruption (ABAC)

For full ABAC audit procedures, CFE investigation protocols, third-party due diligence,
whistleblower program audit, and behavioral red flags: **Read `references/mx-ethics_antibribery.md`**

This is now a standalone domain (Domain 11) and must be assessed in every engagement. Key
cross-references:
- Conflicts of interest: always cross-reference AP vendor master against employee RFC list
- Gift & hospitality register: request and review before concluding procurement audit (Domain 7)
- Whistleblower channel: assess independence and usage statistics as part of anti-fraud assessment
- Third-party due diligence: coordinate with REPSE review (Domain 9) for contractor ABAC screening
