> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-mexico.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules; the [INS]/[CON]/[ANA] tags are source-type labels, not evidence ranks.
## Contents
- What is IMMEX?
- Export Ratio Requirements
- Annex 24 — Inventory Control System
- IVA / IEPS Certification
- Pedimentos (Customs Entries)
- Key Compliance Checks
- IMMEX Cancellation Triggers (High Risk)


# IMMEX / Customs Compliance Reference — Mexican Manufacturing

## What is IMMEX?
The IMMEX program (Industria Manufacturera, Maquiladora y de Servicios de Exportación) allows
companies to temporarily import raw materials, components, machinery, and equipment into Mexico
without paying import duties or IVA — provided the goods are used to manufacture products
for export.

**Governing decree:** Decreto IMMEX (DOF 2006, with amendments through 2025-2026)
**Administering agencies:** SE (Secretaría de Economía) for program; SAT for fiscal compliance

---

## Export Ratio Requirements

| Goods Category | Minimum Export Ratio |
|----------------|---------------------|
| Standard manufactured goods | 60% of total value of temporarily imported goods |
| Annex II goods (sensitive: textiles, footwear, electronics) | 80% |
| Services companies | 90% of total annual billings must be to foreign customers |

**2025-2026 Reform:** New trade rules require companies with Annex II goods to be registered
under specific tariff annexes. Metal stamping companies should verify their tariff codes are
correctly classified.

---

## Annex 24 — Inventory Control System

**Requirement:** All temporarily imported materials must be tracked in a SAT-authorized Annex 24
system. This is essentially a virtual customs inventory showing every coil/part/component
imported, consumed in production, and exported.

**Monthly reconciliation required:**
- Materials imported (pedimentos de importación temporal)
- Materials consumed in production (matched to BOM)
- Materials exported as finished goods (pedimentos de exportación)
- Materials destroyed, scrapped, or transferred (separate procedures required)

**Balance = Imports − Consumption − Exports − Authorized disposals**
Any positive unexplained balance = goods "deemed exported" → triggers duties + fines.

**Common audit failures:**
- BOM in Annex 24 doesn't match actual production BOM in ERP
- Scrap not formally destroyed via authorized procedure (SEDESOL/SE permit required)
- Materials transferred to sub-contractors without a pedimento de retorno virtual
- System not updated in real time (batch entries → gaps in audit trail)

---

## IVA / IEPS Certification

**Separate from IMMEX registration.** Companies must apply to SAT for IVA/IEPS certification
to receive the IVA credit on temporary imports ([MX-045]).

**Without certification:** Company must pay IVA ([MX-001]) on all temporary imports and then request
a refund — tying up working capital and triggering SAT refund audits.

**Certification validity:** 1 year (renewable); SAT can revoke for non-compliance.
**Requirements to maintain:** Positive tax opinion, no outstanding tax debts, compliance with
Annex 24, minimum 10 IMSS-registered employees.

---

## Pedimentos (Customs Entries)

Every import and export movement requires a pedimento filed by a licensed customs broker
(agente aduanal).

**Types relevant to manufacturing:**
- A1 — Importación definitiva (permanent import: machinery, office supplies)
- A4 — Importación temporal IMMEX (raw material, components)
- V1 — Exportación definitiva (export of finished goods)
- RT — Retorno de temporales (return of unused temporary imports)
- IN — Introducción a depósito fiscal

**Archive requirement:** Pedimentos + supporting documentation must be archived for 5 years
(CFF Art. 30). Digital archives accepted if properly certified.

---

## Key Compliance Checks

1. **Monthly:** Reconcile Annex 24 system to production BOM and ERP consumption
2. **Monthly:** Verify export ratio is on track for annual minimum
3. **Quarterly:** Review pedimento archive completeness
4. **Annually:** Confirm IVA/IEPS certification renewal
5. **Annually:** Verify IMMEX registration covers all product lines and tariff codes
6. **Ongoing:** Track any SE cancellation notices or audit visits

---

## IMMEX Cancellation Triggers (High Risk)

SE has been actively canceling registrations. Top reasons for cancellation:
- Annex 24 discrepancies not resolved within SE deadline
- Failure to meet annual export ratio
- Company becomes a tax debtor (SAT opinion goes negative)
- Change in corporate structure not notified to SE within 30 days
- Manufacturing at locations not registered under IMMEX decree
- IVA/IEPS certification lapses and not renewed
