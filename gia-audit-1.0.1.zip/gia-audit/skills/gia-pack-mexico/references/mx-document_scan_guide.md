> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-mexico.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules; the [INS]/[CON]/[ANA] tags are source-type labels, not evidence ranks.
## Contents
- CFDI XML Files / CFDI Reports
- SUA Reports (IMSS / INFONAVIT)
- Payroll Ledger / Payroll Summary
- Financial Statements (Balance Sheet / Income Statement)
- Bank Statements / Bank Reconciliation
- Customs Pedimentos
- Environmental Permits (LAU / COA)
- IMSS Risk Premium Letter (Prima de Riesgo)


# Document Scan Guide — What to Look for in Each Document Type

When the user provides documents, apply these specific checks before writing findings.

---

## CFDI XML Files / CFDI Reports

Look for:
- Version attribute: must be "4.0" — any "3.3" = invalid/expired
- RFC in `<cfdi:Emisor>` and `<cfdi:Receptor>`: validate both exist and match SAT records
- `<cfdi:TimbreFiscalDigital>` present on every CFDI: missing = not sealed = invalid
- `NoCertificadoSAT` field: 20-digit certificate number; validate against SAT
- UUID (Folio Fiscal): unique per CFDI; duplicates = fraud indicator
- `UsoCFDI` code: verify appropriate for the transaction type
- Compare CFDI date vs. transaction date: >72 hour gap = late sealing

For payroll CFDIs (nómina):
- Complement version = 1.2 (2026 requirement)
- All percepciones and deducciones have valid SAT catalog codes
- `TotalPercepciones` matches net pay deposited to workers

---

## SUA Reports (IMSS / INFONAVIT)

Look for:
- Worker count on SUA matches payroll headcount
- SBC for each worker: cross-reference to payroll gross amounts
- Risk premium rate on SUA header: verify matches IMSS-assigned class
- Payment receipts (acuses): confirm payments made by 17th of each month
- Check for any workers with SBC below minimum wage (violation)
- Compare worker list to HR headcount report — any gaps indicate unregistered workers

---

## Payroll Ledger / Payroll Summary

Look for:
- Total gross payroll: reconcile to nómina CFDI total percepciones
- IMSS employer contribution: verify as % of SBC total matches contribution table
- ISR withheld: matches tax table for each salary level
- PTU provision: accrued at the [MX-033] rate on pre-PTU taxable income month-to-date
- Overtime: hours × rate × premium; confirm premium rates (double for first 9 hrs/wk)
- ISN: gross payroll × state rate; verify remittance to state government

---

## Financial Statements (Balance Sheet / Income Statement)

Look for:
- Inventory: compare to prior period — significant drop without production stop = possible understatement
- WIP balance: if large and static month-over-month, investigate
- Fixed assets: gross value, accumulated depreciation, net book value; tie to fixed asset register
- Deferred ISR: asset or liability? Reconcile to book/fiscal temporary differences
- PTU liability: should be accrued as current liability if annual return filed within 60 days
- Related party balances: any receivable/payable to shareholder or affiliate?
- Cash balance: reconcile to bank statement; significant unexplained cash = flag

Income Statement:
- Gross margin: for metal stamping, typical range is 15–30%; outside this range = investigate
- Scrap revenue: should appear as a separate line or netted against COGS; confirm CFDI
- Unusual one-time items: ask for documentation
- Effective tax rate: close to the [MX-008] rate expected; significantly lower = possible underreporting

---

## Bank Statements / Bank Reconciliation

Look for:
- Reconciling items >60 days outstanding
- Checks issued but not cashed >90 days: stale checks — potential liability or fraud
- Wire transfers to unfamiliar beneficiaries or personal accounts
- Round number transactions (exactly MXN 100,000 or USD 10,000) — structuring indicator
- Multiple payments to same vendor in same month to stay below authorization threshold
- Cash withdrawals: flag any significant cash transactions; verify vs. petty cash records

---

## Customs Pedimentos

Look for:
- Pedimento number, date, and regime code (A4 = temporary IMMEX import; V1 = export)
- Material description and quantity: reconcile to Annex 24 system
- Declared value: compare to supplier invoice (CFDI or commercial invoice)
- Customs broker (agente aduanal) RFC: confirm licensed
- Pedimento seal (modulación): signed by SAT customs officer
- For exports: confirm material quantity ≤ accumulated Annex 24 balance

---

## Environmental Permits (LAU / COA)

Look for:
- LAU issue date and validity period: is it current?
- Permitted activities listed: do they match actual operations? (Any new process = amendment needed)
- Emission limits stated in LAU: compare to actual COA reported emissions
- COA filing date: confirm filed by March 31 deadline for prior year
- Hazardous waste quantities in COA: compare to waste manifests and disposal receipts

---

## IMSS Risk Premium Letter (Prima de Riesgo)

Look for:
- Document title: "Determinación de la Prima en el Seguro de Riesgos de Trabajo"
- Filing date: must be filed in February for prior year accident data
- Accident statistics: number of accidents, days lost, permanent disabilities
- Resulting premium rate: compare to rate being used in SUA payments
- Any discrepancy between DCSST-filed rate and SUA-applied rate = either over or underpayment
