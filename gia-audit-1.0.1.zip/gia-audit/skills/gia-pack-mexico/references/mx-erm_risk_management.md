> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-mexico.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules; the [INS]/[CON]/[ANA] tags are source-type labels, not evidence ranks.
## Contents
- Regulatory & Standards Basis
- COSO ERM 2017 — Five Components Audit Checklist
- Manufacturing-Specific Risk Register — Minimum Expected Risks
- IIA 2024 — Audit Planning Alignment (Standard 9.2)
- KRI Examples for Manufacturing ERM Dashboard
- Whistleblower Channel (Línea de Denuncia)


# Enterprise Risk Management (ERM) — Mexican Manufacturing Audit Reference

## Regulatory & Standards Basis
- **IIA 2024 Global Internal Audit Standards** (effective January 9, 2025):
  - Standard 9.2: Internal audit strategy must be risk-based; scope aligned to risk register
  - Standard 11.1: Building relationships with stakeholders, including audit committee/board
  - Standard 12.2: Performance measurement for internal audit function
- **COSO ERM 2017 Framework** — *Integrating with Strategy and Performance*:
  Five components, 20 principles
- **Comité de Auditoría (Audit Committee)** per Ley del Mercado de Valores (if publicly traded)
  or per corporate governance best practice (Código de Mejores Prácticas Corporativas — CMPC)

---

## COSO ERM 2017 — Five Components Audit Checklist

### Component 1: Governance & Culture
| Audit Question | Red Flag If… |
|---------------|-------------|
| Is there a risk oversight body (audit committee, risk committee)? | No formal body — 🔴 |
| Does the board/audit committee set risk appetite? | Risk appetite undocumented — 🟠 |
| Is there a Chief Risk Officer (CRO) or risk owner? | No risk ownership defined — 🟠 |
| Is risk culture assessed and communicated? | No risk training for staff — 🟡 |
| Is the internal audit function independent of management? | CAE reports to CFO only, not audit committee — 🟠 |

### Component 2: Strategy & Objective-Setting
| Audit Question | Red Flag If… |
|---------------|-------------|
| Are strategic risks identified (customer concentration, tariff exposure, FX risk)? | No strategic risk register — 🟠 |
| Is risk appetite aligned to business strategy? | Strategy document never references risk tolerance — 🟡 |
| Are emerging risks (nearshoring demand surge, supply chain disruption) assessed? | No horizon-scanning process — 🟡 |

### Component 3: Performance (Risk Assessment & Response)
| Audit Question | Red Flag If… |
|---------------|-------------|
| Is a risk register maintained and reviewed at least annually? | No risk register exists — 🔴 |
| Does each risk have an owner, likelihood rating, impact rating, and control? | Risks listed without owners or ratings — 🟠 |
| Is a heat map (likelihood × impact matrix) produced? | Heat map not updated in 12+ months — 🟠 |
| Are operational risks covered (equipment failure, scrap, supplier default)? | Operational risks absent from register — 🟠 |
| Are compliance risks covered (SAT, IMSS, REPSE, environmental)? | Regulatory risks absent — 🔴 |
| Are KRIs (Key Risk Indicators) defined and monitored? | No KRIs defined — 🟡 |

### Component 4: Review & Revision
| Audit Question | Red Flag If… |
|---------------|-------------|
| Is the risk register reviewed after significant events (audits, incidents, new contracts)? | Register static for >12 months — 🟠 |
| Are controls tested for effectiveness, not just existence? | Controls documented but never tested — 🟠 |
| Are lessons learned from past incidents incorporated? | No post-incident risk update process — 🟡 |

### Component 5: Information, Communication & Reporting
| Audit Question | Red Flag If… |
|---------------|-------------|
| Is a risk report produced for the audit committee at least quarterly? | No reporting cadence — 🔴 |
| Are employees informed of relevant risks and their role in controls? | No risk communication plan — 🟡 |
| Are whistleblower channels in place and results reported to audit committee? | No channel or results never reported up — 🟠 |

---

## Manufacturing-Specific Risk Register — Minimum Expected Risks

A metal stamping / manufacturing plant risk register should include at minimum:

| Risk Category | Example Risk | Typical Likelihood | Typical Impact |
|--------------|-------------|-------------------|---------------|
| **Operational** | Press breakdown / unplanned downtime | High | High |
| **Operational** | Key supplier failure (steel, tooling) | Medium | High |
| **Operational** | Scrap rate above standard (material yield loss) | Medium | Medium |
| **Regulatory — Fiscal** | SAT CFDI audit / EFOS supplier exposure | Medium | High |
| **Regulatory — Labor** | IMSS SBC underreporting discovery | Medium | High |
| **Regulatory — Customs** | IMMEX Annex 24 inventory discrepancy | Low | Critical |
| **Regulatory — REPSE** | Subcontractor REPSE non-compliance (2025 protocol) | Medium | High |
| **Environmental** | Hazardous waste non-compliance (SEMARNAT) | Low | High |
| **Financial** | FX exposure (USD costs vs. MXN revenue) | High | High |
| **Customer** | Customer concentration > 40% revenue in one customer | Medium | Critical |
| **Fraud** | Scrap diversion / phantom vendor | Low-Medium | High |
| **Cyber/IT** | ERP or CFDI system breach | Low | High |

---

## IIA 2024 — Audit Planning Alignment (Standard 9.2)

Per IIA Standard 9.2, the internal audit plan must:
1. Be based on the risk register — highest risks get more audit coverage
2. Be approved by the audit committee (or equivalent governance body)
3. Be updated when significant new risks emerge
4. Include follow-up on prior audit findings

**Audit finding if:** Internal audit plan exists but is not risk-based (e.g., based on rotation
schedule only, or based on management request without risk prioritization).

---

## KRI Examples for Manufacturing ERM Dashboard

| KRI | Warning Threshold | Critical Threshold |
|-----|-------------------|-------------------|
| OEE (Overall Equipment Effectiveness) | <75% | <65% |
| Scrap rate vs. standard | >110% of standard | >125% of standard |
| SAT CFDI rejection rate | >2% | >5% |
| IMSS SBC gap (registered vs. actual) | >5% | >10% |
| REPSE contractor compliance rate | <95% | <85% |
| Number of open critical audit findings | >3 past due | >5 past due |
| Days Sales Outstanding (DSO) | >60 days | >90 days |
| Customer concentration (top customer % revenue) | >35% | >50% |

---

## Whistleblower Channel (Línea de Denuncia)

Per IIA standards and anti-fraud best practice:
- Must be independently operated (not by HR or management)
- Must be anonymous
- Reports must go to audit committee, not just management
- Results must be tracked and remediated
- Existence must be communicated to all employees and contractors

**Red flag:** Channel exists but is managed by the same management accused in complaints,
or results are never shared with the audit committee.
