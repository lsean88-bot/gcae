> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-mexico.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules; the [INS]/[CON]/[ANA] tags are source-type labels, not evidence ranks.
## Contents
- Key Laws & Agencies
- Operating Permits
- Hazardous Waste (Residuos Peligrosos)
- Wastewater Discharge
- Atmospheric Emissions
- PROFEPA Audit Process


# Environmental Compliance Reference — SEMARNAT / Mexican Manufacturing

## Key Laws & Agencies
- **LGEEPA** — Ley General del Equilibrio Ecológico y la Protección al Ambiente
- **SEMARNAT** — Secretaría de Medio Ambiente y Recursos Naturales
- **PROFEPA** — Procuraduría Federal de Protección al Ambiente (enforcement arm)
- **CNA / CONAGUA** — Water rights and wastewater discharge

---

## Operating Permits

### LAU — Licencia Ambiental Única
Required for: facilities with atmospheric emissions, hazardous waste generation, or
significant environmental impact.
Metal stamping plants typically require LAU due to: stamping press noise, metalworking fluid
mist, paint/coating operations (if present), solvent use, and hazardous waste generation.

**Renewal:** Periodic; changes in operations require amendment.
**Shutdown risk:** Operating without valid LAU = PROFEPA closure authority.

### COA — Cédula de Operación Anual
**Annual environmental self-report** filed with SEMARNAT.
Reports: atmospheric emissions (tons/year), water consumption (m³), wastewater discharge,
hazardous waste generated and disposed.
**Deadline:** Typically March 31 for prior year data.
**Failure to file:** Administrative fine + increased audit probability.

---

## Hazardous Waste (Residuos Peligrosos)

**Governing NOM:** NOM-052-SEMARNAT-2005 (classification of hazardous wastes)

**Typical hazardous wastes in metal stamping:**
| Waste Type | Classification |
|-----------|---------------|
| Spent metalworking fluids (coolants, cutting oils) | Corrosive + Toxic |
| Contaminated rags / absorbents | Toxic |
| Empty solvent containers | Flammable |
| Used lubricating oils | Toxic |
| Metal sludge from wastewater treatment | Toxic |
| Spent batteries, fluorescent lamps | Special handling |

**Note:** Metal scrap (clean steel/aluminum offcuts) is NOT hazardous waste — it is a
recoverable material and handled separately (sold to scrap buyers with CFDI).

**Required documentation:**
1. Hazardous waste manifest (bitácora) for each generator site
2. Authorized carrier contract (carrier must have SEMARNAT authorization)
3. Authorized final treatment/disposal facility contract
4. Annual report of quantities generated and disposed
5. Insurance coverage for hazardous material transport

---

## Wastewater Discharge

**Governing NOMs:**
- **NOM-001-SEMARNAT-1996:** Discharge to national waters (rivers, lakes)
- **NOM-002-SEMARNAT-1996:** Discharge to municipal sewer systems
- **NOM-003-SEMARNAT-1997:** Treated wastewater for reuse

**Parameters monitored for metalworking wastewater:**
- Total suspended solids (SST)
- Oil and grease (grasas y aceites)
- Heavy metals: chromium, nickel, zinc, copper (if present in stamping operations)
- pH (must be 6–9 for sewer discharge)
- BOD/COD (biochemical/chemical oxygen demand)

**Discharge permit (permiso de descarga):** Required from CONAGUA for any discharge above
thresholds. Annual monitoring and reporting required.

---

## Atmospheric Emissions

If the plant has: spray painting, powder coating, solvent cleaning, or industrial boilers →
atmospheric emission permit required.

**Key NOM:** NOM-040-SEMARNAT-2002 (particulate matter from industrial sources)

Metal stamping without painting/coating: typically low atmospheric emission risk, but verify:
- Stamping press mist extraction systems (metalworking fluid mist)
- Any heat treatment operations (annealing, stress relief)
- Fork lift exhaust (propane vs. electric)

---

## PROFEPA Audit Process

PROFEPA conducts both scheduled and surprise inspections. Response protocol:
1. Request inspector identification and legal authorization (orden de visita)
2. Allow inspection with company representative present at all times
3. Review and sign acta de inspección — note any discrepancies before signing
4. Respond to any observations within deadline stated in acta
5. Unresolved observations escalate to fines and potential closure

**Voluntary audit program (Auditoría Ambiental):** PROFEPA offers a certification that
demonstrates environmental compliance — reduces inspection frequency and provides favorable
treatment in enforcement proceedings.
