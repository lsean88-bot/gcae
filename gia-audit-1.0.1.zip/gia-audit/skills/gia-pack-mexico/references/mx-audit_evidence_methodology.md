> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-mexico.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules; the [INS]/[CON]/[ANA] tags are source-type labels, not evidence ranks.
## Contents
- Aligned to: ISA 500 / IIA 2024 Global Internal Audit Standards / ISSAI 300
- Foundational Principle
- Seven Evidence Types — Mandatory Tags
- Assertion Framework — Every Test Must Name Its Assertion
- Evidence Reliability Hierarchy
- Professional Skepticism — Operating Rules
- Documentation Standard — Finding Worksheet
- Sampling vs. Full Population — Decision Rule
- Anti-Assumption Rules — What Is PROHIBITED
- Evidence-First Workflow for Each Audit Test
- Technology-Enabled Full-Population Testing


# Audit Evidence Methodology — No Assumption, No Fuzzy Logic
## Aligned to: ISA 500 / IIA 2024 Global Internal Audit Standards / ISSAI 300

---

## Foundational Principle

**Every finding in this skill must be grounded exclusively in sufficient appropriate audit
evidence. No finding may be based on assumption, inference, hearsay, or unverified assertion.**

IIA Standard 12.4 (Evidence): "Internal auditors must identify sufficient, reliable, relevant,
and useful information to achieve the engagement objectives."

ISA 500: "Sufficient" = quantity. "Appropriate" = quality (relevance + reliability). Both
must be met simultaneously before a finding is stated.

---

## Seven Evidence Types — Mandatory Tags

Every audit test must be tagged with its evidence type. Use these shortcodes in all references:

| Tag | Evidence Type | Definition | Reliability |
|-----|--------------|------------|------------|
| `[INS]` | **Inspection of records** | Examining invoices, CFDIs, contracts, ledgers, payroll registers, bank statements, weigh-gate logs | HIGH (original docs); MEDIUM (copies/scans — may be manipulated) |
| `[PHY]` | **Physical inspection** | Directly observing assets in existence: coil inventory, die count, cash count, machinery | HIGH — auditor observes directly; cannot be fabricated in real time |
| `[CON]` | **External confirmation** | Evidence obtained directly from independent third party: bank confirmation, IMSS SUA portal extract, SAT EFOS query, INM portal, CFCRL registry, customer confirmation | HIGHEST — independent of client; cannot be altered by management |
| `[REP]` | **Reperformance** | Auditor independently executes a control: re-running a bank reconciliation, re-performing a CFDI match, recomputing payroll, re-tracing a coil from GRN to production order | HIGH — auditor-generated |
| `[REC]` | **Recalculation** | Independently recalculating a figure: ISR provisional payment, BOM theoretical scrap, IVA retention amount, LVC wage average, thin cap ratio | HIGH — mathematical verification; error-free if inputs are confirmed |
| `[OBS]` | **Observation** | Watching a process as it happens: press operation, physical inventory count, receiving inspection, weigh-gate procedure | MEDIUM-HIGH — limited to moment of observation; no guarantee of normal behavior |
| `[ANA]` | **Analytical procedures** | Comparing data across sources: Benford's Law, trend analysis, ratio analysis, year-over-year scrap rates, BOM vs. actual variance, forecast accuracy MAPE | MEDIUM — corroborative; must be supported by `[INS]` or `[CON]` for findings |

**`[INQ]`** — Inquiry (management representations, interviews) is **NOT** listed above because:
- Inquiry **alone** is never sufficient audit evidence (ISA 500 para. A22)
- Inquiry must always be corroborated by at least one of the seven types above
- When inquiry is used, always document: who was asked, what was said, what corroborating evidence was obtained

---

## Assertion Framework — Every Test Must Name Its Assertion

Each audit test targets one or more financial statement or compliance assertions:

| Assertion Code | Assertion | Meaning in Manufacturing Context |
|---------------|-----------|----------------------------------|
| `EX` | **Existence** | Assets, liabilities, and transactions actually exist at the balance sheet date. (Do these coils physically exist?) |
| `CO` | **Completeness** | All transactions and balances that should be recorded are recorded. (Are all scrap sales recorded? All workers in IMSS?) |
| `AC` | **Accuracy** | Transactions recorded at correct amounts. (Is SBC calculated correctly? Is IVA at the right rate?) |
| `VA` | **Valuation** | Assets and liabilities are at appropriate carrying values. (Is inventory at lower of cost or NRV? Are dies properly depreciated?) |
| `CU` | **Cut-off** | Transactions recorded in the correct period. (Is CFDI issued after shipment, not before?) |
| `RO` | **Rights & Obligations** | Entity has rights to assets, obligations for liabilities. (Are customer-owned dies excluded from balance sheet?) |
| `CL` | **Classification** | Items are classified correctly. (Is reverse factoring classified as trade payable, not debt?) |
| `PR` | **Presentation** | Disclosures are complete and understandable. (Are related-party transactions disclosed in NIF notes?) |
| `CP` | **Compliance** | Activity conforms to applicable law, regulation, or policy. (Is REPSE contractor registered? Is CCT filed at CFCRL?) |

---

## Evidence Reliability Hierarchy

```
HIGHEST ──────────────────────────────────────────────────────── LOWEST

[CON] External    [PHY] Physical    [REP] Reperform    [INS] Original    [INS] Copies    [ANA] Analytics    [INQ] Inquiry
Confirmation      Inspection        / Recalculation     Documents         / Scans          (corroborative)    (alone: ❌)
    ↑                  ↑                  ↑                  ↑                ↑                  ↑                ↑
Independence      Auditor-direct     Auditor-generated    Client-internal   Risk of            Pattern          Subject to
from client       observation        — no client input     w/ good controls  manipulation       detection        bias
```

**Practical rule:** For any 🔴 Critical finding, evidence must include at least one `[CON]` or
`[PHY]` item. `[INS]` of internal documents alone is insufficient to sustain a critical finding
without corroboration.

---

## Professional Skepticism — Operating Rules

Per IIA Standard 12.3 and ISA 200 para. 15:

1. **Questioning mind:** Do not accept management explanations at face value. Ask: "What would
   this look like if it were false?" Treat unusual items as suspicious until evidence proves otherwise.

2. **Critical assessment:** Evaluate the relevance and reliability of evidence obtained. An
   internally-generated document with no independent verification is lower-reliability than an
   external confirmation — even if it looks convincing.

3. **No management confirmation is audit evidence.** Management representations (ISA 580) are
   required but are the LOWEST quality evidence. They do not substitute for external confirmation
   or physical inspection.

4. **Challenge round numbers.** Scrap weights, production counts, or payments that consistently
   end in .000 or .500 warrant Benford's Law test `[ANA]` and physical verification `[PHY]`.

5. **Corroborate oral representations immediately.** If management says "the Annex 24 balances,"
   obtain the Annex 24 system export and reconcile it yourself `[REP]`. Document the outcome.

6. **Treat related parties as high-risk by default.** Transactions with parent companies, expat
   handlers, scrap buyers, or union-connected vendors require `[CON]` corroboration.

---

## Documentation Standard — Finding Worksheet

Every finding must be documented in a working paper with the following fields.
In reports, condense to the Finding Template below, but the working paper must exist.

### Working Paper Fields
```
Finding Reference:     [e.g., D16-001]
Domain:                [e.g., Domain 16 — Material Balance]
Assertion(s) Tested:   [e.g., CO, AC]
Population:            [e.g., All coil issuance transactions Jan–Mar 2026, N=847 records]
Sample Method:         [e.g., Full population via ERP extract / Risk-based sample n=25]
Evidence Obtained:
  1. [Type] [Source] [Date obtained] [Reliability rating]
  2. ...
Procedure Performed:   [Step-by-step description of what auditor did]
Expected Result:       [What the correct/compliant outcome should be]
Actual Result:         [What was found — quantified]
Variance / Deviation:  [Difference between expected and actual — in MXN or kg or %]
Root Cause:            [Probable cause based on evidence, not assumption]
Regulatory Basis:      [Specific law / article / IIA Standard]
Risk Rating:           [🔴 / 🟠 / 🟡 / 🟢]
Auditor:               [Name + date]
Management Response:   [Management's reply — note this is INQ and requires corroboration]
```

### Finding Template for Reports
```
**Finding [N]: [Title]** | Priority: 🔴/🟠/🟡/🟢
**Assertion(s):** [CO / AC / EX / etc.]
**Evidence Basis:** [e.g., [REC] BOM recalculation; [INS] weigh-gate log extract; [CON] SAT CFDI descarga masiva]
**Condition:** [Precisely what was observed — quantified]
**Criteria:** [Specific law, article, standard — no vague references]
**Cause:** [Root cause based on evidence, not speculation]
**Effect:** [Financial or legal exposure — quantified in MXN / kg / % where possible]
**Recommendation:** [Specific, actionable — with responsible party and deadline]
```

---

## Sampling vs. Full Population — Decision Rule

| Scenario | Approach | Rationale |
|----------|---------|-----------|
| ERP/system data available (CFDI universe, payroll extract, weigh-gate log) | **Full population** `[ANA]` + `[REC]` | Technology enables 100% testing; no sampling risk |
| Large paper-based populations | **Risk-based sample** minimum n=25 for populations >500; n=15 for <500 | Statistical confidence; document sampling method |
| High-risk items (related parties, large transactions, round numbers) | **100% of identified items** | No sampling for individually significant items |
| Controls testing (reconciliation procedure, CFDI matching process) | **Reperformance** `[REP]` on all instances in period | Controls are binary: either performed or not |

**When using sampling:** Document the sampling frame, method (random/systematic/judgmental),
selection basis, and extrapolation logic. A finding from a sample must state: "Based on sample
of N items from population of X, [Y]% error rate extrapolates to [MXN Z] estimated total
exposure, to a confidence level of 95%."

---

## Anti-Assumption Rules — What Is PROHIBITED

The following are explicitly prohibited in all findings and reports:

| Prohibited | Reason | Replace With |
|-----------|--------|-------------|
| "It is likely that..." | Speculation | State only what evidence shows |
| "Management appears to..." | Unverified | Obtain `[CON]` or `[PHY]` evidence |
| "Based on industry norms..." | Assumption | Cite specific regulatory benchmark |
| "The company probably..." | Inference | Test and document the actual fact |
| "It is assumed that..." | Assumption | If unknown, state "could not be verified — see recommendation" |
| "The risk is high because typically..." | Generalization | Cite specific evidence for this entity |
| Findings without a MXN/kg/unit quantification | Imprecision | Quantify or state that quantification was not possible due to [specific reason] |

---

## Evidence-First Workflow for Each Audit Test

```
Step 1: State the assertion(s) being tested
Step 2: Identify the evidence type(s) that will prove/disprove the assertion
Step 3: Obtain the evidence (from highest-reliability source available)
Step 4: Perform the procedure (inspect, recalculate, confirm, observe)
Step 5: Document: expected result vs. actual result, with exact figures
Step 6: If a finding: quantify the exposure, cite the regulatory basis
Step 7: Corroborate any management explanation with at least one additional evidence type
Step 8: Only then: state the condition, criteria, cause, effect, and recommendation
```

**You must not reach Step 8 without completing Steps 1–7.**

---

## Technology-Enabled Full-Population Testing

Modern analytics (ERP exports, SAT CFDI portal, IMSS SUA, BANXICO FIX rates) enable
100% population testing that eliminates sampling risk entirely:

| Data Source | What to Pull | Test Enabled |
|------------|-------------|-------------|
| SAT descarga masiva (CFDI portal) | All CFDIs issued and received | Full-population Benford, duplicate detection, EFOS match |
| IMSS SUA export | All registered workers, SBC, contributions | Full-population headcount vs. payroll |
| ERP material issuance register | All coil issuances to production orders | Full-population BOM yield variance |
| ERP weigh-gate module | All scrap weights by date and category | Full-population Benford + buyer analysis |
| BANXICO DIOT (CFDI complement) | All IVA transactions | Full-population IVA rate compliance |
| CFCRL public registry | CCT registration status | Direct external confirmation |
| SAT EFOS portal | Vendor blacklist status | Direct external confirmation |

Preferred audit stance: **obtain full-population data first; apply risk-based deep-dive
procedures to flagged items.** This converts subjective sampling into objective analysis.
