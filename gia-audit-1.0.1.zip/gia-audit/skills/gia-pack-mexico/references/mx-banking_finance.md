> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-mexico.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules; the [INS]/[CON]/[ANA] tags are source-type labels, not evidence ranks.
## Contents
- Regulatory Framework
- Bancarization Requirements — CFF Art. 31-A
- LFPIORPI — Anti-Money Laundering for Vulnerable Activities
- FX Controls & BANXICO Reporting
- Treasury Controls — Internal Audit Checklist
- Letter of Credit & Supply Chain Finance
- Foreign Currency — NIF B-15 Audit Controls
- Cash Flow Forecasting Controls
- Evidence-Annotated Test Programme — Banking & Finance


# Banking, Finance & Treasury Controls Reference — Mexican Manufacturing

## Regulatory Framework

| Authority | Law / Regulation | Scope |
|-----------|-----------------|-------|
| **BANXICO** | Ley del Banco de México; Circular 3/2012 | FX operations, payment systems, interbank clearing |
| **CNBV** | Ley de Instituciones de Crédito (LIC); CUOEF | Banking supervision, credit line compliance |
| **SHCP** | CFF Art. 31-A; LFPIORPI | Cash controls, AML reporting for vulnerable activities |
| **SAT** | CFF Art. 28; RMF | Electronic accounting, bancarization of payments |
| **CONDUSEF** | Ley para la Protección y Defensa al Usuario de Servicios Financieros | Consumer financial protection (if applicable) |

---

## Bancarization Requirements — CFF Art. 31-A

All business payments must use the banking system to be **ISR-deductible and IVA-acreditable**:

| Threshold | Requirement |
|-----------|------------|
| Cash payments per transaction at or above the [MX-039] threshold | **Non-deductible for ISR; non-acreditable IVA** |
| Payments in cash to related parties ≥ any amount | High audit risk — treat as non-deductible unless cash nature justified |
| Accepted instruments | Bank transfer (transferencia bancaria), check (cheque nominativo), payroll card, credit/debit card |

**Audit test:** Sample 25% of payment transactions by value; verify each ≥ MXN threshold has bank remittance advice (comprobante de transferencia) matched to CFDI. Any cash payment above threshold = automatic finding.

**Red flags:**
- Vendor paid in multiple cash installments to stay below USD 2,000 threshold (split transactions): 🔴 (CFF evasion indicator)
- Petty cash (fondo fijo) used for recurring operational costs instead of one-time miscellaneous: 🟠
- Cash payments to REPSE contractors: 🔴 (non-deductible and potential AML violation)

---

## LFPIORPI — Anti-Money Laundering for Vulnerable Activities

**Ley Federal para la Prevención e Identificación de Operaciones con Recursos de Procedencia Ilícita**

Manufacturing plants must assess if any of their activities qualify as "actividades vulnerables":

| Activity | Threshold for Reporting | Applies to Manufacturing? |
|----------|------------------------|--------------------------|
| Sale of real estate | >USD 100,000 | If plant sells property |
| Leasing of real estate | >USD 3,210/month per contract | If subleasing plant space |
| Sale of vehicles | >USD 3,000 | If fleet disposal |
| Precious metals / gems trading | >USD 805 | If jewelry/parts with precious metals |
| Accounting, auditing, legal services (notary) | >USD 3,210 | If paid to external advisors |
| Construction of real estate | >USD 8,025 | If CAPEX >threshold |
| **Cash receipt of any kind >USD 7,500** | Mandatory report to UIF | Always applicable |

**UIF Reporting:** Reports to Unidad de Inteligencia Financiera (UIF-SHCP) via portal within 30 calendar days of the suspicious/threshold transaction.

**Audit test:** Review all cash receipts >MXN 130,000 (~USD 7,500); verify UIF reports were filed. Review customer advance payments in cash; verify no LFPIORPI threshold was breached without report.

---

## FX Controls & BANXICO Reporting

Mexico does not have formal FX controls, but BANXICO requires reporting of:

| Transaction | Reporting Threshold | Form |
|------------|--------------------|----|
| Receipt of foreign currency (wire or cash) | >USD 10,000 per operation | BANXICO Formulario CE (through authorized bank) |
| Payments abroad (servicios técnicos, royalties, dividends) | Any amount | Bank executes withholding ISR before transfer |
| Import payments (raw material from foreign parent) | Cross-reference with IMMEX pedimento | No separate BANXICO form; use CFDI + pedimento |

**Intercompany wire transfers — Audit alert:** BANXICO Circular 3/2012 requires that wire transfers >USD 1,000 include complete originator and beneficiary information. Banks must validate. Audit test: Pull a sample of intercompany wire advice vs. pedimento to verify consistency.

---

## Treasury Controls — Internal Audit Checklist

### Bank Account Controls
| Control | Requirement | Audit Test |
|---------|------------|-----------|
| Bank account authorization | All accounts in company name; no personal accounts used for company transactions | List all bank accounts from SAT records; compare to finance-approved list |
| Signatory controls | Dual signature for payments above threshold (typically MXN 50,000+) | Review bank signature cards; test payments against authorization matrix |
| Bank reconciliation | Monthly; prepared by accounting, reviewed by controller independent of cashier | Pull last 6 months reconciliations; verify timely preparation and sign-off |
| Dormant accounts | Any account with no activity >90 days reviewed and closed if unnecessary | Request bank statement for all accounts; flag dormant with unexplained balance |
| Petty cash fund | Maximum balance and replenishment policy; surprise counts quarterly | Perform surprise cash count; reconcile to float approved |

**Red flags:**
- Bank accounts not disclosed in electronic accounting (Contabilidad Electrónica): 🔴
- Company officer personal account used for business payments: 🔴
- Bank reconciliation aged >60 days: 🟠
- Single signatory authority for payments of any amount: 🟠

### Intercompany Loans & Related-Party Financing
| Area | Requirement | Audit Test |
|------|------------|-----------|
| **Loan agreement** | Written agreement with arm's-length interest rate; supported by TP study | Request all intercompany loan agreements; verify interest rate vs. TIIE or LIBOR equivalent |
| **Thin cap compliance** | Related-party debt ≤ 3× fiscal equity (LISR Art. 28 XXVII) | Calculate ratio; if >3:1, excess interest is non-deductible |
| **Transfer pricing on loans** | Interest rate must be arm's length; DIOR disclosure | Verify TP study covers financing transactions |
| **CFDI for interest** | Interest payments to foreign parent require CFDI and ISR withholding | Verify withholding certificates (constancias de retención) on file |
| **CFF formalities** | Contracts must be formalized; avoid disguised capital contributions classified as loans | If parent capitalizes subsidiary via loan that is never repaid, SAT may reclassify as equity |

---

## Letter of Credit & Supply Chain Finance

For IMMEX plants with significant import volumes, letter of credit (LC) and supply chain finance are common:

| Instrument | Audit Area |
|-----------|-----------|
| **Standby LC** | Verify LC is in company name; confirm no unauthorized third-party pledging of assets |
| **Factoring of customer invoices** | Ensure factoring is disclosed in notes to financial statements (NIF C-3); true sale vs. recourse factoring classification |
| **Supplier reverse factoring (Supply Chain Finance)** | Verify correctly classified as trade payable, not financial debt (NIF C-19) — misclassification inflates EBITDA |
| **NAFIN programs** | Cadenas Productivas (government reverse factoring); verify enrollment and discount rate |

---

## Foreign Currency — NIF B-15 Audit Controls

Manufacturing plants with intercompany transactions must comply with NIF B-15 (Conversión de Monedas Extranjeras):

- **Functional currency determination:** If >50% of revenues and costs are USD-denominated (common for maquiladora/IMMEX), functional currency may be USD, not MXN
- **Transaction date FX rate:** Use BANXICO FIX rate on transaction date (or monthly average if policy approved)
- **Year-end restatement:** USD monetary assets/liabilities restated at closing BANXICO FIX rate; exchange differences to P&L (NIF B-15)
- **CFC risks:** Controlled Foreign Corporation rules under LISR Art. 4-A — if Mexican entity owns foreign entity holding passive income, LISR anti-deferral applies

**Audit test:** Pull USD bank account balances; verify FX restatement calculation uses closing BANXICO FIX rate; agree P&L FX gain/loss to bank statements.

---

## Cash Flow Forecasting Controls

| Control | Best Practice |
|---------|--------------|
| 13-week cash flow forecast | Prepared weekly by Finance; reviewed by CFO/GM |
| IVA cash flow | Separate line for monthly IVA payment/refund due to manufacturing export volatility |
| IMSS/ISN/INFONAVIT due dates | Built into treasury calendar; auto-reminder 5 days before 17th deadline |
| Payroll funding | Bank account funded 2 business days before payroll date; dual authorization |
| Foreign parent funding (capital injection) | Track separately from operating cash; verify SAT FX reporting |

**Red flag:** Treasury forecast not prepared or not shared with plant management — treasury flying blind: 🟠

---

## Evidence-Annotated Test Programme — Banking & Finance

### TEST BF-01: Bank Account Completeness
- **Assertion:** EX (Existence), CO (Completeness)
- **Evidence:** `[CON]` bank confirmation letters (request directly from bank — NOT via management); cross to `[INS]` SAT catálogo de cuentas (electronic accounting)
- **Procedure:** Request standard bank confirmation for each known account. Also request from SAT electronic accounting filing the complete chart of accounts — identify all bank accounts coded. Any account in SAT not confirmed by bank, or bank account not in SAT chart = gap.
- **Finding trigger:** Any undisclosed account → 🔴 (off-book account risk)
- **Prohibited:** Do not rely on management's list of bank accounts as complete — this is `[INQ]` only

### TEST BF-02: Cash Payment CFF Art. 31-A Compliance
- **Assertion:** AC (Accuracy), CP (Compliance)
- **Evidence:** `[INS]` ERP payment journal filtered for Forma de Pago = "01" (efectivo) in CFDI; `[ANA]` Benford on payment amounts
- **Population:** 100% of payments in period via ERP extract
- **Procedure:** Filter all payments where CFDI Forma de Pago code = "01" (cash). Flag any payment above the [MX-039] threshold (convert at DOF FIX rate on payment date). `[REC]` recalculate ISR deductibility lost = disallowed payment × ISR rate ([MX-008]; [MX-009] border zone).
- **Finding trigger:** Any cash payment above the [MX-039] threshold → 🟠. Systematic pattern → 🔴. Quantify: sum of all disallowed payments × ISR rate = tax exposure

### TEST BF-03: LFPIORPI UIF Reporting
- **Assertion:** CO (Completeness), CP (Compliance)
- **Evidence:** `[INS]` cash receipt log (100% population) + `[INS]` UIF filing acknowledgments (acuses)
- **Procedure:** Pull all cash receipts from ERP/bank statements. Flag any single cash receipt ≥ MXN 130,000 (~USD 7,500). Cross-match to UIF filings. Any threshold breach without UIF report = violation.
- **Finding trigger:** Any unreported threshold transaction → 🔴 (LFPIORPI Art. 32 + Art. 55 sanction)

### TEST BF-04: Thin Capitalization (LISR Art. 28 XXVII)
- **Assertion:** AC (Accuracy), CP (Compliance)
- **Evidence:** `[INS]` all intercompany loan agreements + `[REC]` fiscal equity from tax return + balance sheet `[INS]`
- **Procedure:** Sum all related-party debt (intercompany loans + related-party payables with interest). Divide by fiscal equity (capital contable fiscal per ISR return). If ratio exceeds the [MX-014] limit: `[REC]` calculate non-deductible interest = excess debt × interest rate = disallowed deduction × 30% ISR = tax exposure.
- **Finding trigger:** Ratio >3:1 with no exception → 🔴. Quantify MXN exposure.

### TEST BF-05: Intercompany Wire Transfer ISR Withholding
- **Assertion:** CO (Completeness), AC (Accuracy)
- **Evidence:** `[CON]` bank SPEI/SWIFT records for all foreign wires + `[INS]` constancias de retención + `[REC]` withholding rate per LISR Art. 167 / applicable tax treaty
- **Procedure:** Pull all foreign wires classified as royalties, technical fees, interest, or dividends. Verify ISR was withheld at correct rate before wire. Cross to constancias filed with SAT.
- **Finding trigger:** Wire sent without prior withholding → 🔴 (SAT liability falls on Mexican payor)
