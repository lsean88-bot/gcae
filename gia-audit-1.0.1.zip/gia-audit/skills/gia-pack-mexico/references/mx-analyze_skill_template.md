> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-mexico.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules; the [INS]/[CON]/[ANA] tags are source-type labels, not evidence ranks.
## Contents
- Template Structure


# data:analyze Skill Customization Template

Use this template to produce the `[COMPANY]_analyze_skill_customization.md` output file
when the user requests customization of the data:analyze skill alongside the audit.

---

## Template Structure

The output file must cover all of these sections, populated with company-specific information
gathered from Steps 1–4 of the audit:

### Section 1 — Company Context
- Company name, plant type, state, ERP system (if known)
- Accounting standards (NIF), fiscal year, currency (MXN), exchange rate source (SAT DOF daily)

### Section 2 — Operational KPIs (Metal Stamping)
Define each metric with: name, formula, units, warning threshold

**Production KPIs to include:**
- OEE (Overall Equipment Effectiveness) = Availability × Performance × Quality; warning: <70%
- Scrap Rate = (Defective or scrap parts / Total produced) × 100; warning: >3%
- Material Yield = (Good parts × part weight) / Total material consumed; warning: <85%
- PPM = Defective parts per million (customer metric)
- Press Uptime = Actual press hours / Scheduled hours; warning: <80%
- Die Change Time (SMED) in minutes; benchmark: <30 min
- Tons/Shift: metric tons processed; compare to standard
- Coils Consumed: reconcile to AP purchases

**Material KPIs:**
- Steel Price/Ton vs. TERNIUM/AHMSA published benchmark
- Aluminum Price/Ton vs. LME spot
- Material Cost as % of Net Sales (benchmark: 40–60% for stamping)
- Scrap Revenue: must have corresponding CFDI — flag if missing
- Scrap Weight Reconciliation: BOM theoretical vs. actual

### Section 3 — Financial Metrics (NIF Terminology)
Map standard financial metrics to Mexican accounting terms:
- Net Sales = Ventas Netas
- COGS = Costo de Ventas
- Gross Profit = Utilidad Bruta
- EBITDA (not a NIF term but used in practice)
- EBIT = Utilidad de Operación
- RIF = Resultado Integral de Financiamiento
- Net Income = Utilidad Neta
- ISR Causado = Current tax expense
- ISR Diferido = Deferred tax (asset or liability)
- PTU = Participación de los Trabajadores en las Utilidades

### Section 4 — Tax & Labor Compliance Metrics
- Effective ISR Rate = ISR paid / Pre-tax income; flag if materially below the [MX-008] rate
- IVA Acreditable % = IVA credited / IVA paid on purchases; flag if >100%
- PTU Liability = taxable profit × rate per [MX-033]; flag if not accrued
- Payroll Deductibility = Nómina with CFDI / Total payroll; flag if <100%
- ISN Effective Rate = ISN paid / Gross payroll; compare to state rate
- SBC/Base Salary Ratio; flag if <1.10 for manufacturing
- IMSS Headcount vs. Payroll Headcount; flag any gap
- Overtime Ratio = Overtime hours / Regular hours; flag if >10% sustained

### Section 5 — Auto-Flag Logic
Define specific conditions that Claude should always flag automatically:

**SAT Flags:**
```
IF any supplier RFC on EFOS list → FLAG CRITICAL
IF CFDI universe < total invoices processed → FLAG HIGH
IF IVA saldo a favor above the [MX-052] threshold → FLAG HIGH
IF cash payments per vendor > USD 2,000 → FLAG HIGH
IF contabilidad upload date > 25th of month → FLAG MEDIUM
```

**Labor Flags:**
```
IF IMSS registered workers < payroll headcount → FLAG CRITICAL
IF SBC < (base salary × 1.10) → FLAG CRITICAL
IF PTU not accrued → FLAG HIGH
IF payroll CFDIs < 100% of pay periods → FLAG CRITICAL
```

**Operational Flags:**
```
IF scrap revenue has no CFDI → FLAG CRITICAL
IF (scrap sold kg) vs (BOM theoretical scrap) gap > 10% → FLAG HIGH
IF steel purchase price > LME equivalent + 15% → FLAG HIGH
IF material yield < 80% → FLAG HIGH
IF OEE < 65% → FLAG MEDIUM
```

### Section 6 — Data Sources
List the company's actual systems and data sources:
- ERP system (SAP / Oracle / Aspel / CONTPAQi): GL, inventory, cost centers
- PAC (CFDI provider): CFDI XML universe
- SAT portal: tax declarations, balanza uploads
- IMSS SUA: contribution payments, worker registry
- MES / production system: press output, OEE, downtime
- Manual Excel: scrap tracking, die log (flag as risk — recommend systemizing)

### Section 7 — Standard Analysis Templates
Four ready-to-use templates:

1. **Monthly Tax Dashboard:** IVA balance, ISR provisional vs. coefficient, IMSS/INFONAVIT
   payments vs. payroll, CFDI count vs. sales invoices, any missed SAT deadlines

2. **Production Cost Analysis:** Material cost per ton (vs. standard), direct labor cost per
   press hour, overhead absorption rate vs. budget, scrap impact, variance analysis

3. **Compliance Health Check:** CFDI universe completeness, IMSS headcount reconciliation,
   environmental permit expiry dates, STPS NOMs status, IMMEX export ratio

4. **Scrap Revenue Reconciliation:** BOM theoretical scrap vs. actual scrap recorded vs.
   scrap sold (with CFDI); flag any gap >5%

### Section 8 — Output Format Standards
- Currency: MXN; if USD, note DOF daily rate used
- Regulatory citations: always cite specific law/article
- Confidence flags: mark estimated figures as "[Estimated — validate against source]"
- IIA structure for findings: Condition → Criteria → Cause → Effect → Recommendation
- Priority: 🔴 Critical | 🟠 High | 🟡 Medium | 🟢 Low

### Section 9 — Regulatory Calendar
Always include the next 3 relevant filing deadlines given the analysis period.
