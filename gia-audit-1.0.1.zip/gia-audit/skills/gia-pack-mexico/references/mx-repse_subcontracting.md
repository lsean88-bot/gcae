> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-mexico.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules; the [INS]/[CON]/[ANA] tags are source-type labels, not evidence ranks.
## Contents
- Legal Basis
- The 2021 Subcontracting Reform — Core Rules
- REPSE Registration Requirements
- STPS 2025 New Inspection Protocol (Published November 24, 2025)
- Audit Red Flags — REPSE Compliance
- Sanctions for Non-Compliance
- Audit Procedure — REPSE Compliance Checklist
- REPSE Compliance — Filing Calendar


# REPSE / Subcontracting Compliance — Mexican Manufacturing Audit Reference

## Legal Basis
- **Ley Federal del Trabajo (LFT)** — Art. 13, 15-A through 15-D (as amended April 23, 2021)
- **Ley del Seguro Social (LSS)** — Art. 15-A (IMSS subcontracting obligations)
- **LISR** — Art. 27 (deductibility conditions for subcontracting payments)
- **LIVA** — Art. 32 Frac. VIII (IVA retention obligation)
- **CFF** — Art. 69-B (simulated operations / criminal liability)
- **STPS New Inspection Protocol** — published November 24, 2025

---

## The 2021 Subcontracting Reform — Core Rules

The April 2021 reform **prohibits general outsourcing** of personnel. Only two structures are permitted:

1. **Specialized services or works (servicios u obras especializadas)** that are:
   - NOT part of the beneficiary company's corporate purpose (objeto social)
   - NOT part of the beneficiary's predominant economic activity (actividad económica preponderante)
   - Performed by a provider **registered in REPSE**

2. **In-house employment** — all other workers must be on the beneficiary's own payroll

---

## REPSE Registration Requirements

### For Service Providers (Prestadores)
| Requirement | Details |
|-------------|---------|
| **Register with STPS** | Online via REPSE portal — must describe specialized service |
| **Renewal** | Every 3 years (verify current status) |
| **RFC required** | Active, non-blacklisted RFC on SAT |
| **Social security current** | IMSS compliance certification at registration |
| **Tax compliance** | SAT opinion of compliance (Opinión de Cumplimiento) |

### For Beneficiary Companies (Receptores)
| Obligation | Frequency | Risk if Missing |
|-----------|-----------|-----------------|
| Verify REPSE certificate of provider | Before every contract | 🔴 — payments non-deductible |
| Withhold ISR per [MX-041] from provider invoice | Per invoice | 🔴 — ISR liability |
| Withhold IVA per [MX-041] from provider invoice | Per invoice (unless provider is IVA certified) | 🔴 — IVA liability |
| File SISUB (SAT) quarterly | Within 17 days of quarter-end | 🔴 — fines + criminal risk |
| Obtain IMSS compliance report from provider | Monthly | 🟠 — joint IMSS liability |
| Obtain INFONAVIT compliance report from provider | Monthly | 🟠 — joint liability |

---

## STPS 2025 New Inspection Protocol (Published November 24, 2025)

The STPS published a new, more rigorous inspection protocol for subcontracting compliance.
Key changes vs. prior practice:

1. **Evidence-based inspections** — not just document review; inspectors verify actual work
   performed matches REPSE registration description
2. **Cross-agency data matching** — STPS now shares data with SAT, IMSS, and INFONAVIT
   to detect payroll, contribution, and contract inconsistencies in real-time
3. **Documents inspectors may request:**
   - Service agreements (contratos de servicios especializados)
   - REPSE certificates (valid at time of service)
   - Personnel lists and roles for subcontracted workers
   - Social security and tax compliance evidence (monthly IMSS/INFONAVIT reports from provider)
   - SISUB filings (SAT quarterly report)
   - Training and supervision records for subcontracted workers
4. **Joint liability:** If provider fails IMSS/SAT compliance, beneficiary may be held jointly liable

---

## Audit Red Flags — REPSE Compliance

| Condition | Priority | Legal Basis |
|-----------|----------|-------------|
| Service provider not registered in REPSE | 🔴 | LFT Art. 15-C; LISR Art. 27 — non-deductible |
| REPSE certificate expired at time of service | 🔴 | LFT Art. 15-C — same as unregistered |
| Services provided are NOT specialized (e.g., general cleaning, security by non-specialist) | 🔴 | LFT Art. 13 — must convert to direct employment |
| ISR retention ([MX-041]) not applied on provider invoices | 🔴 | LISR Art. 27 — ISR exposure + fines |
| IVA retention ([MX-041]) not applied (when required) | 🔴 | LIVA Art. 32 Frac. VIII |
| SISUB not filed quarterly | 🔴 | CFF — fines; SAT may treat as simulated ops |
| No written service contract on file | 🟠 | LFT Art. 15-B — required by law |
| IMSS/INFONAVIT monthly compliance not obtained from provider | 🟠 | LSS Art. 15-A — joint liability |
| Service agreement scope matches beneficiary's core business | 🟠 | LFT Art. 13 — non-permitted structure |
| Subcontracted workers on beneficiary's premises without supervision | 🟡 | STPS 2025 Protocol |

---

## Sanctions for Non-Compliance

| Violation | Sanction |
|-----------|---------|
| General subcontracting (prohibited) | Fine per worker affected [MX-038] |
| Simulated subcontracting (tax fraud) | Criminal: 3–9 years imprisonment (CFF Art. 69-B) |
| SISUB not filed | Fines per quarter |
| ISR/IVA retention not applied | Tax assessment + actualization + surcharges |
| IMSS contributions unpaid for subcontracted workers | Joint IMSS liability on beneficiary |

**Current UMA value:** Verify current value at INEGI before calculating fine exposure.
Fine exposure is expressed in UMA multiples [MX-038]; convert to MXN with the UMA in force for the period under review [MX-019].

---

## Audit Procedure — REPSE Compliance Checklist

1. **Obtain list of all service providers** — from AP vendor master (filter service vendors)
2. **Verify REPSE registration** — check REPSE portal (repse.stps.gob.mx) for each provider
3. **Review service contracts** — confirm scope is specialized and not core business
4. **Test SISUB filings** — request SAT acknowledgment of quarterly SISUB submissions
5. **Test invoice retention** — sample AP invoices; verify retention per [MX-041], [MX-004] and [MX-005] applied
6. **Request provider IMSS/INFONAVIT compliance** — monthly reports for audit period
7. **Cross-match** — subcontracted worker list vs. IMSS beneficiary payroll to detect
   ghost workers or misclassified employees
8. **Interview** — ask how subcontractor workers are supervised and by whom

---

## REPSE Compliance — Filing Calendar

| Filing | Deadline | Platform |
|--------|----------|---------|
| SISUB Q1 (Jan–Mar) | April 17 | SAT portal |
| SISUB Q2 (Apr–Jun) | July 17 | SAT portal |
| SISUB Q3 (Jul–Sep) | October 17 | SAT portal |
| SISUB Q4 (Oct–Dec) | January 17 | SAT portal |
| REPSE renewal | Every 3 years from registration date | STPS portal |
| Provider IMSS compliance | Monthly | Provider obligation; beneficiary must archive |
