> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-mexico.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules; the [INS]/[CON]/[ANA] tags are source-type labels, not evidence ranks.
## Contents
- Regulatory & Standards Framework
- ACFE — Association of Certified Fraud Examiners (CFE) Framework
- Ethics Program — Governance Audit Checklist
- Ethics & ABAC Red Flags — Priority Matrix
- CFE Behavioral Red Flags — Employee Screening
- Data Analytics — Anti-Fraud & ABAC Tests


# Ethics, Anti-Bribery & Anti-Corruption (ABAC) — Mexican Manufacturing Audit

## Regulatory & Standards Framework

### Mexican Law (Primary Jurisdiction)

| Instrument | Scope | Key Provisions |
|-----------|-------|---------------|
| **Ley General del Sistema Nacional Anticorrupción (LGSNA, 2016)** | Public & private sector | Establishes SNA; private companies liable for corruption acts involving public officials |
| **Ley General de Responsabilidades Administrativas (LGRA, 2016)** — "Ley 3de3" | Private entities engaging public sector | Art. 21: private party liability for bribery, influence peddling, use of illegal influence; Art. 25: corporate compliance program as mitigating factor |
| **Código Penal Federal (CPF)** | Criminal | Arts. 222–224: bribery (cohecho), extortion, influence peddling (tráfico de influencias) — corporate criminal liability under CPF Art. 11 Bis |
| **Ley Federal Anticorrupción en Contrataciones Públicas (LFACP)** | Government contracting | Sanctions companies for corrupt acts in public procurement — fines up to 2× the value of the contract + blacklisting |
| **NOM/SAT KYC requirements** | Anti-money laundering (AML) | LFPIORPI — cash transaction reporting; company as "actividad vulnerable" if meeting thresholds |

### International Instruments (Apply Where Connected)

| Instrument | When Applicable | Key Risk |
|-----------|----------------|---------|
| **US Foreign Corrupt Practices Act (FCPA, 1977)** | Any company listed on US markets, or with US parent/partner | Bribery of "foreign official" = criminal; jurisdiction attaches even outside US; 2023 DOJ Corporate Enforcement Policy requires voluntary disclosure + full cooperation |
| **UK Bribery Act 2010 (UKBA)** | Any company with UK parent, UK business, or UK-listed | Strict liability offense (Section 7): failure to prevent bribery; defense requires "adequate procedures" — equivalent to an ISO 37001 program |
| **OECD Anti-Bribery Convention** | Mexico is a signatory | Criminalizes bribery of foreign public officials; requires mutual legal assistance |
| **UN Convention Against Corruption (UNCAC)** | Broad international reach | Articles 12 & 21 cover private sector bribery |

### Management System Standards

| Standard | Application |
|---------|------------|
| **ISO 37001 (current edition [MX-037])** Anti-Bribery Management Systems | Gold standard for ABAC programs; covers risk assessment, due diligence, training, controls, reporting — audit against this if company claims ISO 37001 certification or as gap assessment framework |
| **ISO 37002:2021** Whistleblowing Management Systems | Framework for effective, safe reporting channels |
| **COSO ERM 2017** | Ethics embedded in Component 1 (Governance & Culture — Principle 3: Define desired behaviors) |
| **IIA 2024 Global Internal Audit Standards** | Standard 8.2: Internal audit must assess the organization's ethical culture; Standard 9.2: Fraud and corruption risk must be assessed in audit planning |

---

## ACFE — Association of Certified Fraud Examiners (CFE) Framework

### ACFE Fraud Tree — Full Taxonomy Applied to Manufacturing

The ACFE Fraud Tree classifies occupational fraud into three branches. Apply all three in every engagement:

#### Branch 1: Asset Misappropriation (Most Common — ~89% of cases, ACFE RTTN 2024)

**Cash schemes:**
- Skimming: Cash removed before recorded in books (scrap cash payments, customer advance payments)
- Larceny: Theft of recorded cash (petty cash, bank deposits diverted)
- Fraudulent disbursements:
  - Billing schemes: phantom/inflated vendor invoices
  - Payroll schemes: ghost employees, falsified time records, unauthorized raises
  - Expense reimbursement: fictitious or inflated expense claims
  - Check/wire tampering: unauthorized payments

**Non-cash asset schemes (highest risk in metal stamping):**
- Inventory theft: steel coils, finished parts, tooling consumables
- Scrap diversion: scrap metal removed before weighing or CFDI issuance
- Die/tooling misappropriation: plant-owned tooling converted to personal use or sold
- Misuse of company equipment: presses, vehicles, computers
- Intellectual property theft: die designs, customer drawings, process specifications

**Red flag thresholds (ACFE benchmarks):**
- Median fraud loss in manufacturing: USD 200,000 (RTTN 2024)
- Median duration before detection: 12 months
- Internal controls failure = most common enabler (32% of cases: no controls existed)
- Tip-off = most common detection method (43%): whistleblower channel is the highest-ROI anti-fraud control

#### Branch 2: Corruption (Second most common — ~38% of cases)

**Bribery:**
- Commercial bribery: payments to customers' purchasing agents to win/retain business
- Government bribery (cohecho): payments to SAT inspectors, IMSS auditors, STPS inspectors, customs agents (aduana), municipal inspectors (uso de suelo, permisos), police
- Facilitation payments: "speed money" to expedite routine government actions — illegal under LGRA and UKBA (no facilitation exception in Mexican or UK law)
- Bid rigging: coordinating with competitors or collusion with procurement staff

**Conflicts of interest:**
- Employee-vendor relationship: employee has undisclosed ownership, family member, or financial interest in vendor
- Employee-competitor relationship: employee secretly works for or consults a competitor
- Employee-customer relationship: employee receives personal benefits from customer contacts

**Economic extortion:**
- "Pay to play" demands from public officials or customer gatekeepers
- Reverse bribery: company official demands payment from a vendor for business

#### Branch 3: Financial Statement Fraud (Least frequent — ~9% of cases, but highest loss)

**Revenue overstatement:**
- Premature revenue recognition (booking before delivery / customer acceptance)
- Channel stuffing: shipping unsolicited inventory to distributors
- Round-tripping: revenue recorded with offsetting intercompany transactions

**Expense understatement / liability concealment:**
- Understating warranty reserves
- Failing to accrue IMSS back-contributions or SAT contingencies
- Capitalizing expenses to avoid income statement impact

**Asset overstatement:**
- Inflated inventory (scrap not written off, obsolete stock not reserved)
- Fictitious assets on balance sheet
- Deferred cost improper capitalization

---

### CFE Investigation Standards & Protocols

When a fraud suspicion or allegation arises, apply these CFE-aligned procedures:

#### Phase 1: Allegation Assessment & Scoping

1. **Document the allegation:** Source (whistleblower tip, anonymous, management referral, audit test), date received, description verbatim
2. **Conflict check:** Confirm no audit team member has a conflict with the subject
3. **Escalation determination:** Does severity warrant notifying audit committee immediately? (IIA 2024 Standard 11.1 — bypass management if management is implicated)
4. **Preserve evidence immediately:** Freeze IT access logs, email archives, ERP audit trails before any notification. Coordinate with IT and legal counsel
5. **Engage legal counsel:** Fraud investigation requires attorney-client privilege protection; involve Mexican abogado experienced in corporate fraud / CPR (delito corporativo)
6. **Determine if external specialists needed:** Forensic accountants, CFEs, digital forensics

#### Phase 2: Evidence Collection (Chain of Custody)

**Chain of custody requirements:**
- Every piece of evidence is logged with: date collected, collector name, location collected from, condition at collection
- Physical evidence bagged, sealed, labeled with sequential control number
- Digital evidence: hash value (MD5/SHA-256) recorded at time of collection; never work on original — always copy
- Maintain custody log: every person who handled evidence must sign log (fecha, hora, motivo)
- Store evidence in locked, access-controlled location

**Types of evidence to collect in manufacturing fraud:**
- ERP transaction records (AP, inventory, GL, payroll — full audit trail with user IDs and timestamps)
- Email and communications (coordinate with IT and legal for e-discovery)
- Physical documents: purchase orders, invoices, weight tickets, delivery notes, payroll records
- Bank statements (company and, where legally possible, individual)
- Surveillance / CCTV footage (retain before overwrite cycle)
- Vendor and employee files from HR and AP
- Scale calibration records and scrap removal logs
- CFDI XML files from SAT portal (authoritative record)

#### Phase 3: Interviews

**CFE interview sequence:**
1. **Corroborating witnesses first** — gather facts from neutral parties before alerting subject
2. **Co-conspirators** — if any, consider interview order carefully with legal counsel
3. **Subject last** — subject is interviewed only after sufficient evidence is gathered

**Interview principles (ACFE / CFE best practices):**
- Conduct in a neutral private location, never the subject's office
- Two investigators present: one leads, one observes and takes notes
- Begin with rapport-building, non-threatening open questions
- Establish baseline behavior before introducing sensitive topics
- Do NOT use coercive, threatening, or deceptive tactics (violates LGRA and professional standards)
- In Mexico: employee has right to union representative if unionized (LFT Art. 782 — right to due process)
- Record only with explicit consent or as permitted by Mexican law (LFPDPPP for privacy considerations)
- Document immediately after: interview memo signed by both investigators; subject given opportunity to review and sign

#### Phase 4: Reporting

**Investigation report structure (CFE standard):**
1. Executive summary — allegation, scope, conclusion
2. Methodology — procedures performed, evidence reviewed
3. Findings — what was found, who was involved, how, for how long, estimated loss
4. Supporting evidence — referenced exhibits, never originals
5. Recommendations — control remediation, disciplinary action, legal referral
6. Limitations — what was not examined, why

**Reporting to governance (IIA 2024 Standard 11.1):**
- Significant fraud involving senior management or implicating governance: report directly to audit committee, bypassing CFO/CEO
- If audit committee is implicated: report to board chair or independent legal counsel
- Document the escalation and rationale

---

## Ethics Program — Governance Audit Checklist

### Code of Ethics / Code of Conduct

| Element | Audit Test | Red Flag |
|---------|-----------|---------|
| Written Code of Ethics exists | Request document; verify board approval | None exists: 🔴 |
| Covers bribery, gifts, conflicts of interest, confidentiality | Review scope of code | Missing bribery/gift section: 🟠 |
| Translated into Spanish for Mexican operations | Review Spanish version | English only in Mexican plant: 🟠 |
| Signed acknowledgment by all employees annually | Review acknowledgment log vs. headcount | <90% signature rate: 🟠 |
| Updated within past 3 years | Review revision date and change log | Not updated since 2020 or earlier: 🟡 |

### Anti-Bribery & Anti-Corruption (ABAC) Policy

| Element | Requirement | Audit Test |
|---------|------------|-----------|
| **Zero tolerance statement** | Explicit prohibition on bribes in any form | Policy must use plain language; not just "we comply with laws" |
| **Gift & hospitality limits** | Defined monetary thresholds (e.g., max MXN 500 per gift; max MXN 1,500 per business meal) | No monetary limit = policy gap: 🟠 |
| **Gift & hospitality register** | Central log of all gifts/hospitality given and received, reviewed quarterly by Compliance/CAE | No register exists: 🟠; register not reviewed in 12+ months: 🟡 |
| **Government official interactions** | Heightened controls: all meetings with government officials documented; no gifts of any value to government officials (zero-tolerance) | No government official controls: 🔴 |
| **Political contributions** | Company funds prohibited for political campaigns; personal contributions are individual right but must not be tied to company benefit | Company money used for political campaigns: 🔴 |
| **Facilitation payments** | Explicitly prohibited; procedure for reporting demands | Not mentioned in policy: 🟠 |
| **ABAC training** | All employees, annual; enhanced for high-risk roles (procurement, customs, logistics, government relations) | No training records: 🔴; procurement staff not trained: 🟠 |

### Third-Party Due Diligence (TPDD)

Third parties (agents, distributors, customs brokers, subcontractors, government-relations consultants) are the #1 FCPA/UKBA risk vector. Audit requires:

| Due Diligence Element | Minimum Standard | Red Flag |
|----------------------|-----------------|---------|
| **Identity verification** | Legal name, RFC/tax ID, ownership structure, UBO (Ultimate Beneficial Owner) | No UBO identification: 🟠 |
| **Sanctions screening** | Screen against: OFAC SDN list, UN sanctions, Mexico's SHCP LISTAS NEGRAS, EFOS (SAT blacklist) | No screening performed: 🔴 |
| **PEP check (Politically Exposed Person)** | Check if third party, its principals, or UBO is a current/former government official | PEP detected but not escalated: 🔴 |
| **Reputational due diligence** | Media search, court records, public registry check for adverse history | Not performed for high-risk third parties: 🟠 |
| **Contract ABAC clauses** | All third-party contracts must include: right to audit, ABAC representations, termination for cause on ABAC violation, no sub-delegation without consent | Missing ABAC clause in contracts: 🟠 |
| **Periodic re-screening** | High-risk third parties: annual; standard: every 3 years | Never re-screened after onboarding: 🟠 |

### Conflicts of Interest

| Control | Audit Procedure | Red Flag |
|---------|----------------|---------|
| **Annual COI declaration** | All employees with procurement, financial, or management authority complete signed declaration | No COI program: 🔴 |
| **Recusal procedure** | Documented process for employee to recuse from decision where conflict exists | No recusal mechanism: 🟠 |
| **Review of undisclosed conflicts** | Cross-reference AP vendor master against employee RFC and family member names | Match found not disclosed: 🔴 |
| **Outside employment** | Policy prohibits working for competitor or customer without prior approval | No outside employment policy: 🟡 |

### Whistleblower (Línea de Denuncia) Program

Per ACFE RTTN 2024, organizations with active hotlines detect fraud in half the time and suffer losses 50% smaller than those without.

| Element | Requirement | Red Flag |
|---------|------------|---------|
| **Channel exists** | Telephone hotline, web portal, or both; anonymous option available | No channel: 🔴 |
| **Independence** | Managed by third party or internal audit, NOT by HR or management | Managed by CFO/HR: 🟠 |
| **Multilingual** | Spanish-language option minimum for Mexican operations | English only: 🟠 |
| **Non-retaliation policy** | Written prohibition on retaliation; LFT provides some worker protection — but private sector policy must reinforce | No non-retaliation language: 🟠 |
| **Reports investigated** | All reports logged, triaged, and investigated; results communicated to audit committee | No tracking of reports: 🔴 |
| **Zero reports in >12 months** | Investigate channel effectiveness — is it accessible, known, trusted? | 🟠 (may indicate suppression or unawareness, not necessarily clean operations) |
| **Awareness** | Hotline number prominently displayed in plant (posters, pay stubs, intranet) | Not communicated: 🟠 |

---

## Ethics & ABAC Red Flags — Priority Matrix

| Condition | Priority | Basis |
|-----------|----------|-------|
| No Code of Ethics or ABAC Policy | 🔴 | LGRA Art. 25 — no mitigating compliance program; FCPA/UKBA exposure |
| Government official on vendor list or receiving payments | 🔴 | CPF Arts. 222–224; FCPA; LGRA Art. 21 — criminal bribery |
| Gift & hospitality register not maintained | 🟠 | ISO 37001 gift and hospitality control clause [MX-037]; FCPA adequate procedures |
| Third-party agents not screened before engagement | 🔴 | FCPA — company liable for agent's bribery; UKBA Section 7 |
| PEP identified in vendor chain, not escalated | 🔴 | FCPA; LGSNA; money laundering risk |
| COI declarations not completed annually | 🟠 | IIA 2024 Standard 8.2; ISO 37001 conflict-of-interest clause [MX-037] |
| Employee lifestyle clearly inconsistent with salary (car, home, travel) | 🟠 | CFE behavioral red flag — kickback, embezzlement indicator |
| Procurement employee never takes vacation (>2 years) | 🟠 | ACFE — fraud perpetrators often fear detection during absence |
| Single approver for vendor add + PO + payment | 🔴 | Segregation of duties — direct fraud enabler |
| ABAC training not conducted for high-risk roles | 🟠 | ISO 37001 training clause [MX-037]; FCPA adequate procedures |
| Whistleblower channel inactive or unknown to employees | 🟠 | ACFE RTTN 2024 — highest ROI anti-fraud control |
| No investigation protocol documented | 🟠 | IIA 2024; CFE standards — risk of mishandled allegations |
| Facilitation payments made (even small amounts) | 🔴 | LGRA Art. 21; UKBA absolute prohibition; FCPA |
| Political contributions from company funds | 🔴 | LFACP; LGSNA; reputational and legal risk |
| Intercompany transactions with no arm's-length documentation | 🟠 | LISR Art. 76 — transfer pricing; LGRA — possible disguised benefit |
| No ABAC clause in third-party contracts | 🟠 | FCPA; UKBA "adequate procedures" defense requirement |
| Company in government-tendered supply chain with no ABAC program | 🔴 | LFACP — disqualification and blacklisting risk |

---

## CFE Behavioral Red Flags — Employee Screening

Apply during interviews, observation, and document review. These do not constitute proof of fraud — they are indicators requiring follow-up.

### Financial Behavioral Indicators
- Lives conspicuously beyond known salary (luxury vehicle, expensive home, travel, jewelry)
- Refuses to take vacation or delegate work (fears audit of their area during absence)
- Works unusual hours (early/late) without clear business reason — possible opportunity window
- Insists on personally handling specific transactions (sole authority, refuses sharing)
- Becomes defensive or agitated when controls are applied to their area
- Has financial difficulties (garnishments, bankruptcy notices in court records, known debts)

### Workplace Behavioral Indicators
- Close personal relationships with specific vendors (gifts, meals, personal contact)
- Consistently overrides established procedures "for efficiency" with management tolerance
- Poor work quality documentation — verbal agreements, no paper trail
- Unexplained frequent contact with competitors
- Has copy of sensitive documents (pricing, customer lists) not required for their role
- Grudge-holder: expresses persistent resentment about compensation, recognition, or treatment

### Organizational Red Flags
- One person controls an entire process end-to-end (a single point of control = a single point of failure)
- Management dismisses audit concerns about a specific employee ("we trust him completely")
- Rapid employee departures in a specific department (possible hostile culture or exposure of misconduct)
- Vendor relationship managed exclusively by one employee with no backup or review

---

## Data Analytics — Anti-Fraud & ABAC Tests

These can be run on ERP/accounting data exports without specialized software (Excel-capable):

| Test | Data Needed | What It Detects |
|------|------------|----------------|
| **Benford's Law** on AP invoice amounts | All vendor invoices for period | Non-Benford distribution of leading digits = possible fabricated invoices |
| **Duplicate payment test** | AP payment file: amount, vendor, date, invoice number | Same invoice paid twice; or two invoices with same amount to same vendor ±30 days |
| **Vendor-employee match** | AP master RFC vs. payroll RFC | Related-party vendors not disclosed |
| **Round-number test** on expense claims | Employee expense reports | Excessive round-number amounts = likely fabricated |
| **Split transaction test** | PO and invoice data | Multiple invoices just below competitive bid threshold from same vendor on same day |
| **Weekend/holiday payment test** | AP payment dates | Payments on Saturdays, Sundays, or Mexican public holidays — possible unauthorized |
| **New vendor + immediate payment** | Vendor creation date vs. first payment date | Vendor paid within 30 days of being added without competitive bidding |
| **Ghost employee test** | Payroll vs. IMSS SUA vs. access control | Workers on payroll not in IMSS, not badged in to plant |
| **Excessive scrap delta** | BOM theoretical scrap vs. actual scrap sold by SKU/press | Diversion of scrap before weighing |
| **Gift register vs. vendor award** | Gift/hospitality register vs. contract awards | Gifts received from vendors who subsequently won contracts |
