> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-mexico.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules; the [INS]/[CON]/[ANA] tags are source-type labels, not evidence ranks.
## Contents
- Key Laws
- CFDI Electronic Invoicing
- ISR — Impuesto Sobre la Renta
- IVA — Impuesto al Valor Agregado
- Electronic Accounting (Contabilidad Electrónica)
- Cash Payment Restrictions
- SAT Filing Calendar Summary
- Evidence-Annotated Test Programme — SAT / Fiscal


# SAT / Fiscal Compliance Reference — Mexican Manufacturing

## Key Laws
- **CFF** — Código Fiscal de la Federación (procedural tax law; fines, electronic accounting)
- **LISR** — Ley del Impuesto Sobre la Renta (corporate income tax)
- **LIVA** — Ley del Impuesto al Valor Agregado (VAT)
- **RMF** — Resolución Miscelánea Fiscal (annual SAT operational rules)

---

## CFDI Electronic Invoicing

**Version:** 4.0 (mandatory since April 2023; 3.3 is fully invalid)
**Required fields in v4.0:** RFC emisor, RFC receptor, Nombre, Código Postal, Régimen Fiscal
**Stamp window:** Must be sealed (sellado) within 72 hours of transaction

**2026 Reform — Critical:**
- CFDIs must represent real, truthful transactions
- False or simulated CFDIs lose all tax effects
- Criminal liability for issuers, recipients, AND intermediaries
- SAT has expedited powers to suspend digital certificates
- Validate all supplier CFDIs at: `efos.sat.gob.mx`

**CFDI Usage Codes (Uso CFDI) — Common for Manufacturing:**
- G01 — Adquisición de mercancias (raw material, inventory)
- G03 — Gastos en general (services, overhead)
- I01 — Construcciones (building improvements)
- I04 — Equipo de cómputo y accesorios (computers)
- I06 — Comunicaciones telefónicas (telecom)

**Payroll CFDI (Nómina):** Complement 1.2 effective 2026
- Required for every pay period without exception
- Missing nómina CFDIs = payroll non-deductible ([MX-040])

---

## ISR — Impuesto Sobre la Renta

**Corporate Rate:** [MX-008] on net taxable income
**Provisional Payments:** By the 17th of each month; calculated using:
  - Prior year coefficient of utility × current month accumulated income
  - Adjusted for known allowable deductions
**Annual Return Deadline:** March 31 of following fiscal year

**Fiscal Depreciation Rates (LISR Art. 34):**
| Asset Type | Annual Rate |
|-----------|------------|
| Industrial machinery (stamping presses) | 10% |
| Dies and tooling | 25% |
| Computers / ERP systems | 30% |
| Transportation vehicles | 25% |
| Buildings | 5% |
| Office furniture | 10% |
| Molds | 35% |

**Tax Losses (Pérdidas Fiscales):**
- Can be amortized against future profits for up to 10 fiscal years
- Updated for inflation each year
- Not transferable to related parties

**Transfer Pricing:**
- Required when transactions with related parties (foreign or domestic) exceed thresholds
- Annual informative return: DIOR (Declaración Informativa de Operaciones con Partes Relacionadas)
- Contemporaneous study must be prepared in the same tax year
- Arm's length methods: CUP, Resale Price, Cost Plus, TNMM, Profit Split

---

## IVA — Impuesto al Valor Agregado

**General Rate:** [MX-001]
**Export Rate:** [MX-002] (acto gravado a tasa 0%)
**Monthly Filing:** By the 17th of following month

**Acreditable IVA:** Only VAT on expenses backed by valid v4.0 CFDI
**Export documentation:** Pedimento + CFDI + proof of delivery to foreign territory

**VAT Refund (Saldo a Favor):**
- Refunds >MXN 1,000,000 trigger SAT's automated audit review
- Exporters can request monthly refund; requires IVA/IEPS certification (IMMEX companies)
- Processing time: 40 business days (standard) or 20 days (certified taxpayer)

---

## Electronic Accounting (Contabilidad Electrónica)

**Legal Basis:** CFF Art. 28, Annex 24 of RMF

**Monthly uploads (by 25th of following month):**
1. Catálogo de Cuentas (Chart of Accounts) — mapped to SAT grouping codes
2. Balanza de Comprobación (Trial Balance)

**On-demand (SAT request within 3 business days):**
3. Pólizas (Journal Entries) with CFDI UUID references
4. Auxiliares (Sub-ledger detail)

**Red Flags:**
- Chart of accounts not mapped to SAT's standard grouping
- Discrepancy between Balanza and CFDI universe
- Pólizas without CFDI reference for deductible expenses

---

## Cash Payment Restrictions

**CFF Art. 31-A:** Payments in cash (efectivo) exceeding the threshold in [MX-039] (or MXN equivalent at
DOF rate on payment date) per transaction per vendor lose ISR deductibility.

This applies to: raw material purchases, tooling payments, any business expense.
Exception: payments through financial system (check, wire, bank transfer, credit/debit card).

---

## SAT Filing Calendar Summary

| Obligation | Deadline | Frequency |
|-----------|---------|-----------|
| IVA declaration | 17th of following month | Monthly |
| ISR provisional payment | 17th of following month | Monthly |
| Contabilidad electrónica | 25th of following month | Monthly |
| Annual ISR return | March 31 | Annual |
| DIOR (transfer pricing) | March 31 (with annual return) | Annual |
| Informativa de operaciones relevantes | Within 30 days of operation | As needed |

---

## Evidence-Annotated Test Programme — SAT / Fiscal

### TEST SAT-01: CFDI Universe Completeness & Validity
- **Assertion:** CO (Completeness), AC (Accuracy), CP (Compliance)
- **Evidence:** `[CON]` SAT descarga masiva — pull 100% of CFDIs issued AND received for the period directly from SAT portal (not from ERP — ERP data is `[INS]` and may omit cancelled or altered CFDIs)
- **Population:** 100% of CFDI transactions in period
- **Procedure:** Download complete XML universe from SAT portal. Cross-match to ERP revenue and purchase ledger. Any CFDI in SAT not in ERP, or in ERP not in SAT = 🔴. Check each CFDI status = "vigente" (not cancelled). Verify v4.0 format (reject any 3.3 — invalid since April 2023).
- **Finding trigger:** Any CFDI with status "cancelado" that was previously booked = 🔴 (potential false transaction). Any v3.3 CFDI after April 2023 deadline = 🔴.

### TEST SAT-02: IVA Rate Compliance
- **Assertion:** AC (Accuracy), CP (Compliance)
- **Evidence:** `[CON]` SAT descarga masiva (full population) + `[CON]` border padrón status from SAT portal
- **Population:** 100% of outgoing sales CFDIs
- **Procedure:** For each CFDI: extract TasaOCuota field from XML. Classify: 0.16 (domestic general), 0.08 (border zone), 0.00 (export/exempt). For 0.08 invoices: verify company is registered in border padrón on the CFDI date. For 0.00 invoices: verify corresponding export pedimento exists.
- **Finding trigger:** 0.08 rate on CFDI dated after padrón lapse → 🔴 (IVA undercharge = SAT liability). Missing pedimento for 0.00 invoice → 🔴. Quantify: affected revenue × (correct rate − applied rate) = IVA exposure.

### TEST SAT-03: EFOS / EDOS Vendor Screen
- **Assertion:** CP (Compliance), VA (Valuation)
- **Evidence:** `[CON]` query each vendor RFC at `efos.sat.gob.mx` — screenshot with timestamp per vendor
- **Population:** 100% of vendors with invoices in period
- **Procedure:** Extract unique vendor RFCs from purchase CFDI universe. Query each RFC at SAT EFOS portal. Classify result: (a) not listed (clean); (b) listed presumed (EDOS — deductibility at risk); (c) listed definitive (EFOS — 100% disallowed; potential criminal liability).
- **Finding trigger:** Any EFOS definitive vendor → 🔴. Quantify: sum of all CFDIs from that vendor = non-deductible ISR exposure + non-acreditable IVA exposure.

### TEST SAT-04: Electronic Accounting (Contabilidad Electrónica) — CFF Art. 28
- **Assertion:** CO (Completeness), CP (Compliance)
- **Evidence:** `[CON]` SAT acknowledgment receipts (acuses) for catálogo + balanza uploads; `[REC]` compare upload dates to 25th-of-month deadline
- **Procedure:** Pull SAT upload acknowledgments for each month in scope. Verify: (a) catálogo de cuentas uploaded; (b) balanza de comprobación uploaded by 25th. Late upload = regulatory violation regardless of content. Compare balanza totals to financial statement trial balance — any discrepancy.
- **Finding trigger:** Late upload >25th → 🟠. Missing upload → 🔴. Balanza total ≠ financial statement trial balance → 🔴.

### TEST SAT-05: REPSE IVA Retention — LIVA Art. 1-A
- **Assertion:** AC (Accuracy), CO (Completeness), CP (Compliance)
- **Evidence:** `[CON]` SAT descarga masiva for all REPSE contractor CFDIs received; `[REC]` recalculate correct retention per invoice
- **Population:** 100% of REPSE contractor invoices in period
- **Procedure:** For each REPSE invoice: identify contractor type (persona moral = [MX-004]; persona física = [MX-005] per LIVA Art. 1-A). `[REC]` calculate required retention. Compare to retention shown on CFDI. Any shortfall = under-retained IVA.
- **Finding trigger:** Any under-retention → 🟠 (minimum). Systematic → 🔴. Quantify: sum of under-retained IVA = SAT liability of Mexican company as retaining agent.
