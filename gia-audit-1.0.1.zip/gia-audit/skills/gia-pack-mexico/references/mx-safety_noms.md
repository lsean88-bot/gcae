> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-mexico.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules; the [INS]/[CON]/[ANA] tags are source-type labels, not evidence ranks.
## Contents
- Key Agency
- Critical NOMs for Metal Stamping
- Accident Reporting
- STPS Inspection Readiness Checklist


# Workplace Safety Reference — STPS NOMs for Metal Stamping

## Key Agency
**STPS** — Secretaría del Trabajo y Previsión Social
**Enforcement:** STPS inspectors issue actas de verificación; unresolved findings escalate to
fines (CFF-equivalent labor fines) and in extreme cases, plant suspension.

---

## Critical NOMs for Metal Stamping

### NOM-004-STPS-1999 — Safety Guards on Machinery
**Most important NOM for stamping plants.**
Every stamping press, shear, and bending machine must have:
- Physical guards preventing access to danger zone during operation
- **Two-hand control** (mando de dos manos) on manually-fed presses — operator cannot
  trigger the stroke with one hand in the die zone
- Emergency stop accessible from operator position
- Clear danger zone markings (yellow/black)

**Documentation required:**
- Machine safety analysis for each press (análisis de riesgo)
- Guard inspection records (monthly)
- Operator training records for each machine

**Red flag:** Any press without documented guards and two-hand controls is an immediate
🔴 CRITICAL finding — it is both a STPS violation and an IMSS workplace accident liability.

---

### NOM-011-STPS-2001 — Noise and Vibration
Metal stamping is a high-noise environment (presses typically 85–105 dB).
**Requirements:**
- Noise level measurement study (estudio de ruido) by certified professional
- If >80 dB: post warning signs and require hearing protection
- If >85 dB: mandatory audiometric testing (audiometría) for all exposed workers at hire and
  annually thereafter
- Engineering controls preferred over PPE (enclosures, dampers, acoustic barriers)
- Results filed with STPS and kept in worker medical record (expediente médico)

---

### NOM-017-STPS-2008 — Personal Protective Equipment (PPE)
**Requirements:**
- Hazard analysis identifies required PPE by work area
- PPE provided free of charge to workers (LFT requirement — employer pays)
- Training on correct use, maintenance, and replacement
- PPE delivery records signed by each worker

**Metal stamping typical PPE:**
- Safety glasses/goggles (flying metal chips)
- Cut-resistant gloves (sharp edges, metal coils)
- Safety boots with steel toe
- Hearing protection in press areas
- Face shields for die setting/grinding operations

---

### NOM-001-STPS-2008 — Electrical Installations
**Requirements:**
- All electrical panels labeled with voltage, capacity, circuit identification
- Panels accessible only to authorized personnel (lockout available)
- Ground fault protection on press control circuits
- Electrical inspection by certified professional (perito en instalaciones eléctricas)
- Lockout/Tagout (LOTO) procedure for press maintenance

---

### NOM-009-STPS-2011 — Work at Heights
Applies if: die maintenance on elevated press beds, overhead crane maintenance, mezzanine
work platforms, or roof maintenance.
- Fall protection systems (harness + anchor) for work >1.8 meters
- Rescue plan for workers working at heights
- Inspection of fall protection equipment before each use

---

### NOM-025-STPS-2008 — Lighting
**Minimum lux levels by task:**
| Area | Minimum Lux |
|------|------------|
| General press area | 300 lux |
| Fine detail/inspection | 500–750 lux |
| Die setting / quality control | 500 lux |
| Warehouses / raw material storage | 100–200 lux |
| Corridors / walkways | 100 lux |

**Requirement:** Annual lighting measurement study (estudio de iluminación).

---

### NOM-019-STPS-2011 — Joint Health & Safety Commission (CSST)
**Comisión de Seguridad e Higiene:**
- Mandatory for ALL workplaces with ≥1 worker
- Must meet at minimum monthly
- Minutes (actas) must be recorded and available for STPS inspection
- CSST is responsible for workplace hazard inspections and accident investigation

---

## Accident Reporting

**IMSS RT-01 form:** Must be filed with IMSS within **24 hours** of any workplace accident or
occupational illness. Failure = IMSS administrative fine and potential liability reclassification.

**Internal investigation:** All accidents and near-misses must be investigated. Root cause +
corrective action documented in CSST minutes.

**STPS notification:** Serious accidents (involving death, permanent disability, or affecting
multiple workers) must be reported to STPS within 72 hours.

---

## STPS Inspection Readiness Checklist

Documents STPS inspector will request on arrival:
- [ ] Reglamento Interior de Trabajo (registered with STPS)
- [ ] Organigrama (org chart)
- [ ] List of all workers with position and salary
- [ ] CSST formation records and last 12 months of meeting minutes
- [ ] Noise, lighting, and hazardous substance studies
- [ ] PPE delivery records
- [ ] Worker training records (capacitación) — minimum 8 topics required annually
- [ ] Emergency response plan (plan de emergencia)
- [ ] Last STPS inspection acta and status of any open findings
- [ ] Machine safety analysis for each press
