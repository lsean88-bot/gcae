> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-mexico.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules; the [INS]/[CON]/[ANA] tags are source-type labels, not evidence ranks.
## Contents
- Regulatory & Standards Framework
- Warehouse Layout & Physical Controls
- Inventory Receiving Controls
- FIFO Discipline — Coil & Steel Inventory
- Cycle Count & Physical Inventory Program
- ABC Classification & Inventory Optimization
- Outbound Shipping Controls
- Dangerous Goods & Chemical Storage
- Evidence-Annotated Test Programme — Warehouse & Inventory


# Warehouse Operations & Inventory Controls Reference — Mexican Manufacturing

## Regulatory & Standards Framework

| Standard / Law | Application |
|---------------|------------|
| **NIF C-4** — Inventarios | Inventory valuation, write-offs, LCNRV (lower of cost or NRV) |
| **IMMEX Annex 24** | Virtual inventory of imported raw materials and in-process goods; SAT/ANAM reconciliation |
| **ISO 9001:2015 cl. 7.1.5, 8.5.2** | Measurement control, traceability, first-in-first-out discipline |
| **IATF 16949:2016 cl. 8.5.4** | Preservation of product: packaging, labeling, storage segregation |
| **NOM-004-STPS-1999** | Press operation safety — relevant for material handling equipment in warehouse |
| **NOM-006-STPS-2014** | Manejo manual de cargas (manual lifting safety) |
| **NOM-009-STPS-2011** | Montacargas (forklift) — operator certification, inspection |

---

## Warehouse Layout & Physical Controls

### Zoning Requirements
| Zone | Purpose | Audit Test |
|------|---------|-----------|
| **Receiving dock (Área de recibo)** | Incoming raw material; quality inspection before release | Verify dock has space for queue; inspect incoming before releasing to main stores |
| **Quality inspection / hold area** | Non-conforming or suspect material; physically segregated | Check for locked cage or red-tagged area; verify QC sign-off required for release |
| **Raw material stores (Almacén de materia prima)** | Coil racks, steel inventory; FIFO-controlled by heat number | Verify FIFO visual system (date tags, magnetic flags); no mixed heats on same coil rack |
| **WIP staging area** | Blanks, in-process parts between operations | WIP >5 days in staging without forward movement = production bottleneck; investigate |
| **Finished goods / outbound staging** | Packed, labeled, ready for shipment | Verify quantity vs. shipping order; no unauthorized removal without remisión |
| **Scrap yard (Patio de chatarra)** | Skeleton scrap, turnings, rejected parts by category | Weighed at entry; locked; access limited to authorized personnel |
| **Customer-owned tooling area** | Dies and tooling owned by customers; must be physically separated and labeled | Compare physical inventory to die master register; confirm ownership tags |
| **Hazardous materials store** | Lubricants, solvents, cleaning chemicals | CRETIB classification; manifests on file; NOM-052-SEMARNAT compliance |

---

## Inventory Receiving Controls

| Step | Control | Audit Test |
|------|---------|-----------|
| 1. **Physical count at dock** | Receiving team counts and weighs each coil/skid against purchase order | Select 10 GRN (Nota de Entrada) entries; verify counted quantity vs. PO vs. GRN |
| 2. **MTC verification** | Mill Test Certificate (Certificado de calidad del material) verified against drawing requirements (grade, thickness, yield/tensile) | Pull 5 recent coils; verify MTC on file and grade/spec matches engineering drawing |
| 3. **CFDI matching** | Supplier CFDI must match GRN quantity and price | Verify 3-way match: PO → GRN → CFDI; any variance >0.5% requires investigation |
| 4. **IMMEX virtual import** | IMMEX companies: create virtual import pedimento (Pedimento virtual) in Annex 24 within 72 hours of physical entry | Pull Annex 24 entries; match to GRNs by date; gaps = customs compliance risk |
| 5. **Quarantine for non-conforming** | Any material failing MTC or dimensional check placed in hold zone | Request Q1 (non-conforming receiving) log for last 3 months; verify disposition decisions |

**Red flags:**
- Coils received without MTC verification: 🟠 (IATF 16949 cl. 8.4.3 violation)
- GRN created before physical count (pre-receipt): 🔴 (inventory and payment fraud risk)
- IMMEX import not virtualized within 72 hours: 🟠 (customs penalty + Annex 24 reconciliation failure)
- Receiving dock without CCTV coverage: 🟡 (loss prevention)

---

## FIFO Discipline — Coil & Steel Inventory

For metal stamping, FIFO (First-In-First-Out) is not just a financial standard (NIF C-4) — it is an automotive quality requirement (IATF 16949 and most OEM CSRs).

### Coil FIFO Control System

| Element | Requirement | Visual Indicator |
|---------|------------|----------------|
| **Lot tagging** | Each coil tagged with: heat number, grade, thickness, width, weight, receipt date | Color-coded magnetic tags or rack labels |
| **Rack sequencing** | Coils loaded from rear, consumed from front (flow-through rack) or tracked by computer in single-entry racking | Rack diagram posted; first coil in = first coil out |
| **Consumption recording** | Every coil issued to production recorded in ERP (material issuance / salida de almacén) with heat number | Request ERP material issuance report; spot-check 10 issues vs. physical rack position |
| **Remnant tracking** | Partial coils (tailings) tagged with original heat number and remaining weight; stored separately; returned to FIFO queue | Inspect remnant area; verify each remnant has heat tag |

**Audit test:** Select 5 active production orders; trace raw material issuance record back to coil heat number; verify heat number appears on MTC on file; verify FIFO sequence (receipt date of consumed coil is older than or equal to remaining coils in same grade/spec).

---

## Cycle Count & Physical Inventory Program

| Control | Frequency | Coverage |
|---------|-----------|---------|
| **Cycle count — Raw material (A items)** | Weekly | 100% A-class coils by weight |
| **Cycle count — WIP** | Monthly | 100% WIP by cost value |
| **Cycle count — Finished goods** | Weekly | 100% open sales orders + safety stock |
| **Full physical inventory** | Annual | Full count; production shutdown required (Planta para) |
| **Die physical count** | Semi-annual | 100% die master register; tied to insurance policy |
| **Scrap yard count** | Monthly | Weigh all scrap by category; reconcile to theoretical BOM scrap |

**Audit test:** Request cycle count records for last 3 months; verify variances investigated and adjusted; review adjustment authorization (who can post inventory adjustments — must not be same person who counted); verify counts performed by person independent of warehouse keeper (segregation of duties).

**Red flags:**
- No cycle count program: 🟠 (NIF C-4 — inventory must be verified periodically)
- Inventory adjustments posted by warehouse staff with no second approval: 🔴 (segregation of duties violation)
- Physical inventory not performed in >18 months: 🟠
- Scrap yard not counted monthly — scrap theft risk: 🔴

---

## ABC Classification & Inventory Optimization

| Class | Criteria | % of Items | % of Value | Management |
|-------|---------|-----------|-----------|-----------|
| **A** | Top 80% of total inventory value | ~20% | 80% | Tight control; cycle count weekly; management review |
| **B** | Next 15% of value | ~30% | 15% | Monthly cycle count; standard controls |
| **C** | Bottom 5% of value | ~50% | 5% | Quarterly count; periodic review for obsolescence |

**Slow-moving and obsolete inventory (SLOB):**
- Definition: Raw material or finished goods with no consumption or sales movement in >90 days
- NIF C-4 requires write-down to net realizable value (NRV) — even if physically saleable, if price has fallen
- **Audit test:** Pull ERP aging report; identify all items with zero movement >90 days; verify each item has disposition plan (use, sell, scrap, return to supplier)
- IMMEX risk: Imported materials unused >18 months must be exported, destroyed, or duty paid — verify against Annex 24 aging

---

## Outbound Shipping Controls

| Control | Requirement | Audit Test |
|---------|------------|-----------|
| **Shipping order authorization** | No parts leave warehouse without authorized shipping order (Orden de Embarque) | Request shipping log; verify each entry has approved order reference |
| **Packing verification** | Packed quantity vs. shipping order vs. CFDI | Select 10 outbound CFDIs; trace to packing list; verify quantities agree |
| **CFDI issuance** | CFDI must be issued before or at moment of departure (SAT — stamp within 72 hours) | Verify CFDI timestamps vs. departure time from WMS/ERP |
| **Customer label compliance** | Labels per customer specification (GM, Ford, Stellantis barcode requirements) | Pull last customer complaint log; verify labeling issues; check corrective action |
| **Export documentation** | IMMEX: pedimento de exportación created; commercial invoice in USD; packing list signed | Pull 5 recent export pedimentos; verify completeness and timing |
| **Vehicle weight ticket (Carta Porte CFDI)** | CFDI Complemento Carta Porte mandatory since January 2022 for domestic transport | Verify all domestic shipments have Carta Porte; non-compliance = NMF (non-deductible freight) |

**Red flags:**
- Shipments made without Carta Porte CFDI: 🟠 (SAT compliance; transport CFDI deductibility risk)
- Customer labeling non-compliance generating charge-backs: 🟠
- Export pedimento created >72 hours after physical export: 🟠 (ANAM customs violation)

---

## Dangerous Goods & Chemical Storage

Under NOM-052-SEMARNAT-2005 and NOM-018-STPS-2015 (SDS/HazCom):

- All chemicals must have current Safety Data Sheet (SDS / Ficha de Datos de Seguridad) in Spanish
- CRETIB classification (Corrosivo, Reactivo, Explosivo, Tóxico, Inflamable, Biológico) required
- Chemical inventory must match hazardous materials manifest (Manifiesto de materiales peligrosos)
- Incompatible chemicals stored separately (flammables away from oxidizers)

**Audit test:** Cross-check chemical inventory list against SDS register; verify all chemicals with ≥CRETIB classification have SDS; verify SEMARNAT hazardous waste generation report (COA) includes all waste streams.

---

## Evidence-Annotated Test Programme — Warehouse & Inventory

### TEST WH-01: Physical Coil Inventory Count
- **Assertion:** EX (Existence), AC (Accuracy/Valuation)
- **Evidence:** `[PHY]` auditor physical count + `[REC]` compare to ERP book balance + `[CON]` supplier MTC on file
- **Population:** 100% of A-class coils (top 80% of inventory value); 20% sample of B/C class
- **Procedure:** At period-end or surprise count date: (1) Freeze ERP inventory (request cutoff); (2) Physically count and weigh each coil; (3) Record heat number, grade, width, actual weight; (4) Compare to ERP record. Any coil in ERP not found physically = 🔴 (existence failure). Any coil found physically not in ERP = 🔴 (unrecorded inventory).
- **Finding trigger:** Variance >0.5% by value → investigate before stating. >2% → 🔴. Quantify: kg × cost per kg = MXN exposure.

### TEST WH-02: FIFO Compliance — Coil Issuance Sequence
- **Assertion:** AC (Accuracy), CP (Compliance — IATF 16949)
- **Evidence:** `[INS]` ERP material issuance records (100% population) + `[PHY]` physical rack inspection
- **Procedure:** Extract all coil issuances from ERP: sort by part/grade/spec. For each issuance: compare consumption date to receipt date of coil consumed. Any instance where a coil with a later receipt date was consumed before an earlier-received coil of the same spec = FIFO violation. `[PHY]` inspect active racks: verify oldest coil is physically at front/accessible position.
- **Finding trigger:** Any FIFO violation in automotive traceability context → 🟠 (IATF 16949 cl. 8.5.4 + OEM CSR violation). >5% of issuances = 🔴.

### TEST WH-03: 3-Way Match — Receiving Controls
- **Assertion:** AC (Accuracy), CO (Completeness), CP (Compliance)
- **Evidence:** `[INS]` Purchase Orders + `[INS]` GRNs + `[CON]` SAT CFDI from supplier (descarga masiva received)
- **Population:** Risk-based sample: 25 GRNs stratified by value + 100% of GRNs for top 3 suppliers
- **Procedure:** For each sampled GRN: (1) Verify GRN quantity ≤ PO quantity (no over-receipt without amended PO); (2) Verify GRN date ≥ actual physical receipt (no pre-receipt); (3) Verify supplier CFDI matches GRN quantity and price within 0.5%. Any variance: document exact amount.
- **Finding trigger:** GRN created before physical receipt → 🔴 (prepayment fraud / phantom receipt). Price variance >0.5% without credit note → 🟠. Quantify: sum of overpayments.

### TEST WH-04: Carta Porte CFDI — Domestic Freight Compliance
- **Assertion:** CO (Completeness), CP (Compliance)
- **Evidence:** `[CON]` SAT descarga masiva (100% of transport CFDIs received and issued) + `[INS]` outbound shipment log
- **Population:** 100% of domestic freight movements in period
- **Procedure:** Pull all freight-related CFDIs (ClaveProdServ = transport services) from SAT descarga masiva. Verify each has Complemento Carta Porte v2.0 or later (mandatory since Jan 2022). Any domestic shipment without Carta Porte = non-deductible freight cost.
- **Finding trigger:** Any transport CFDI without Carta Porte complement → 🟠. Systematic absence → 🔴. Quantify: affected freight cost × ISR rate ([MX-008]) = non-deductible tax exposure.

### TEST WH-05: SLOB — Slow-Moving & Obsolete Inventory Write-Down
- **Assertion:** VA (Valuation), CP (Compliance — NIF C-4)
- **Evidence:** `[INS]` ERP aging report (last movement date per item) + `[REC]` NRV calculation + `[INS]` current purchase price or scrap market price
- **Population:** 100% of inventory items with zero movement >90 days (ERP extract)
- **Procedure:** Export ERP inventory aging report. Flag all items with zero movement >90 days. For each: (1) Determine NRV (current scrap price for raw material; current customer price less cost to complete for WIP/FG); (2) `[REC]` Compare NRV to book cost; (3) If NRV < book cost: write-down required = book cost − NRV. Sum all required write-downs.
- **Finding trigger:** Identified write-down not booked → 🟠 (NIF C-4 para. 42 — immediate write-down mandatory). Quantify total required provision in MXN.
