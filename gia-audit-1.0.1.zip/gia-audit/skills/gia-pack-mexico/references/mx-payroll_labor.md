> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-mexico.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules; the [INS]/[CON]/[ANA] tags are source-type labels, not evidence ranks.
## Contents
- Key Laws
- IMSS (Instituto Mexicano del Seguro Social)
- INFONAVIT (Housing Fund)
- Payroll CFDI (Nómina)
- PTU — Participación de los Trabajadores en las Utilidades
- LFT — Ley Federal del Trabajo Key Rights
- ISN — Impuesto Sobre Nómina (State Payroll Tax)
- Union / Sindicato Compliance — Quick Reference
- Expatriate Payroll — Quick Reference
- Evidence-Annotated Test Programme — Payroll & Labor


# Payroll & Labor Compliance Reference — Mexican Manufacturing

## Key Laws
- **LSS** — Ley del Seguro Social (IMSS contributions)
- **LFT** — Ley Federal del Trabajo (labor rights, minimum wage, overtime, PTU)
- **LINFONAVIT** — Housing fund contributions
- **RMF / SAT** — Payroll CFDI nómina requirements

---

## IMSS (Instituto Mexicano del Seguro Social)

### SBC — Salario Base de Cotización (Integrated Salary)
The SBC is the base for ALL IMSS contributions. It is NOT just the base salary.

**SBC must include:**
- Base salary (salario base)
- Food allowances above the limit in [MX-050] (if lower, exempt)
- Savings fund contributions above 13% of salary (excess is SBC)
- Holiday bonus (aguinaldo) pro-rated: divide annual days by 365
- Vacation premium pro-rated
- Any other regular monetary benefit

**SBC underreporting is the #1 IMSS audit trigger in manufacturing.**
Red flag: SBC/Base Salary ratio <1.10 for manufacturing workers.

### IMSS Risk Premium (Prima de Riesgo)
Metal stamping = **Clase III or IV** (high-risk metalworking).
The premium is recalculated annually based on actual accident history.
Filing: DCSST (Determinación de la Prima en el Seguro de Riesgos de Trabajo) — February each year.

### IMSS Contribution Rates (2025 — validate current UMA at IMSS portal)
| Concept | Employer % | Worker % |
|---------|-----------|---------|
| Enfermedad y Maternidad (EM) | ~1.05% – 7.03% | 0.375% |
| Invalidez y Vida (IV) | 1.75% | 0.625% |
| Retiro (SAR) | [MX-026] | — |
| INFONAVIT | [MX-029] | — |
| Riesgo de Trabajo | Variable (risk class) | — |
| Guardería y Prestaciones Sociales | 1.00% | — |

### IMSS Reporting Deadlines
- **Alta (new hire):** Within **5 business days** of start date
- **Baja (termination):** Within **5 business days** of last day
- **Modificación salarial:** Within **5 business days** of change
- **Monthly SUA payment:** By the **17th** of following month

---

## INFONAVIT (Housing Fund)

- Employer contribution: **5% of SBC**
- If worker has an active INFONAVIT credit, employer must discount the credit payment from
  net salary and remit to INFONAVIT (in addition to the employer contribution [MX-029])
- Non-remittance of worker credit discounts = INFONAVIT enforcement action

---

## Payroll CFDI (Nómina)

**Version:** Complement 1.2 (updated 2026)
- Must be issued for **every pay period** (weekly, biweekly, monthly — whatever the agreement)
- Stamp deadline: before the SUA payment for that period
- Missing nómina CFDIs: payroll non-deductible for ISR purposes ([MX-040])

**Required concepts in Complement 1.2:**
- All percepciones (earnings): base salary, bonuses, overtime premium, vacation premium, etc.
- All deducciones (deductions): IMSS worker portion, ISR withheld, INFONAVIT credit
- Correct SAT catalog codes for each concept

---

## PTU — Participación de los Trabajadores en las Utilidades

**Rate:** per [MX-033], on annual taxable profit (same base as ISR annual return)
**Payment Deadline:** Within 60 calendar days after ISR annual return filing date
  - For corporations: by May 30 (60 days after March 31 filing deadline)
**Eligible Workers:** All workers employed during the fiscal year, proportional to days worked
  and salary level
**Exempt Workers:** Directors, general managers, administrative partners
**Accounting Treatment:** Must be accrued as a liability on the balance sheet (NIF D-3)

---

## LFT — Ley Federal del Trabajo Key Rights

| Benefit | Amount / Rule |
|---------|--------------|
| Aguinaldo (holiday bonus) | Minimum 15 days salary, paid before December 20 |
| Vacation days | Year 1: 12 days; increases per LFT 2023 reform (now minimum 12 days, scaling) |
| Vacation premium | 25% of vacation salary |
| Sunday premium | 25% above regular pay for Sunday worked |
| Overtime | Overtime pay per [MX-049] |
| Overtime limit | Max 3 hours/day, max 3 days/week (LFT Art. 68) |
| Seniority premium | 12 days salary per year of service (after 15 years or on death/disability) |
| Minimum wage | Set annually by CONASAMI (validate current CONASAMI rate) |

---

## ISN — Impuesto Sobre Nómina (State Payroll Tax)

Each state sets its own rate. Typical range per [MX-034] of gross payroll.

| State | Approximate Rate (validate current) |
|-------|-------------------------------------|
| Nuevo León | 3.0% |
| Chihuahua | 2.0% |
| Coahuila | 2.5% |
| Sonora | 2.0% |
| Tamaulipas | 2.0% |
| Baja California | 2.5% |
| Estado de México | 3.0% |
| Jalisco | 3.0% |
| CDMX | 3.0% |

**Filing:** Monthly to the state's Secretaría de Finanzas
**Red flag:** If plant operates workers across multiple states, ISN must be apportioned by
actual work location — not just by corporate domicile.

---

## Union / Sindicato Compliance — Quick Reference

See full guidance in `references/mx-expat_union_hr.md` (Part B: Union Law).

**Critical LFT milestones audit must verify:**
- CCT registered at CFCRL (mandatory since May 2023): if not registered, CCT is legally void
- CCT ratification by free and secret worker vote (2019 reform): documented tally (escrutinio) on file
- Wages per CCT tabulator: actual pay ≥ CCT minimum by category
- Comisión Mixta de Capacitación registered with STPS: annual training plan filed

**T-MEC Chapter 23 — Labor Value Content (LVC):**
- For automotive export to US/Canada: plant workers must average ≥ USD 16/hour
- Calculate: (SBC ÷ contracted hours per week) × (1 ÷ BANXICO FIX) ≥ USD 16
- Annual certification required per Annex 23-A
- See `references/mx-tax_rates_vat.md` for LVC audit test steps

---

## Expatriate Payroll — Quick Reference

See full guidance in `references/mx-expat_union_hr.md` (Part A: Expatriate Workforce).

**Key payroll compliance points:**
- Expat working >183 days in Mexico = tax resident; shadow payroll required
- Shadow payroll must produce nómina CFDI for expat compensation
- Housing, school fees, car allowances assessed for SBC and ISR inclusion
- ISN: Expat salary included in state payroll tax base if work performed in Mexico

---

## Evidence-Annotated Test Programme — Payroll & Labor

### TEST PAY-01: SBC Integrity — Integrated Salary Completeness
- **Assertion:** CO (Completeness), AC (Accuracy), CP (Compliance)
- **Evidence:** `[INS]` payroll CFDI nómina XML (descarga masiva from SAT) + `[REC]` SBC recalculation for sample
- **Population:** Risk-based sample: 25 workers minimum, stratified by salary band; 100% for workers with highest SBC underreporting risk (kitchen sink benefits, commission-based)
- **Procedure:** For each sampled worker: extract all percepciones from nómina CFDI (base salary + bonus + food allowance + vacation premium pro-rate + aguinaldo pro-rate + savings fund excess). `[REC]` calculate correct SBC per LSS Art. 5-A. Compare to SBC registered in IMSS SUA `[CON]`. Any gap = underreported SBC.
- **Finding trigger:** SBC/Base Salary ratio <1.10 for any manufacturing worker → immediate investigation. Quantify: (Correct SBC − Reported SBC) × IMSS employer % × months = IMSS exposure (plus surcharges per [MX-048] per LSS Art. 304-B).

### TEST PAY-02: Ghost Employee Detection — Dual CLABE
- **Assertion:** EX (Existence), CO (Completeness)
- **Evidence:** `[ANA]` full-population CLABE analysis from nómina CFDI XML + corroboration `[PHY]` badge access for flagged workers
- **Population:** 100% of workers in nómina CFDI
- **Procedure:** Extract worker RFC + CLABE bancaria from every nómina CFDI XML in period. Group by CLABE. Any CLABE appearing for ≥2 different RFCs = 🔴 (ghost employee or direct family account scheme). For each flag: verify with `[PHY]` badge access log and `[CON]` IMSS SUA registration date.
- **Finding trigger:** Any shared CLABE → 🔴. Quantify: sum of salary payments to suspected ghost worker(s) in period.

### TEST PAY-03: PTU Calculation Accuracy
- **Assertion:** AC (Accuracy), VA (Valuation)
- **Evidence:** `[INS]` ISR annual return (Declaración Anual) as base + `[REC]` PTU recalculation + `[INS]` PTU payment CFDI/bank wire
- **Procedure:** `[REC]` PTU = Taxable Fiscal Profit (from ISR return) × rate [MX-033]. Compare to PTU provision on balance sheet. Verify PTU was paid within 60 days of March 31 ISR filing (i.e., by May 30). `[INS]` payment receipt.
- **Finding trigger:** PTU underprovided vs. recalculation → 🟠 (NIF D-3 misstatement). PTU paid late → 🟠 (LFT Art. 122 surcharge risk). Quantify: shortfall × [MX-033] rate on the ISR base.

### TEST PAY-04: CONASAMI Minimum Wage Compliance
- **Assertion:** AC (Accuracy), CP (Compliance)
- **Evidence:** `[CON]` current CONASAMI minimum wage from `conasami.gob.mx` + `[INS]` payroll CFDI lowest salary worker
- **Procedure:** Pull current CONASAMI daily minimum wage. Extract lowest daily effective salary from payroll CFDI nómina (calculate: monthly salary ÷ 30.4 days). Any worker below minimum = LFT Art. 90 violation.
- **Finding trigger:** Any worker below CONASAMI rate → 🔴. Quantify: (Minimum − Actual) × days worked × workers affected = retroactive liability.
- **Note:** General minimum wage applies nationwide. Free trade zone (zona libre) may have a higher rate — verify for border plants.
