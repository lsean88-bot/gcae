---
name: gia-pack-mexico
description: "Mexico audit, SAT, CFDI, IMMEX, REPSE, IMSS, INFONAVIT, UMA, ISN, border-zone IVA, MKSDL, scrap. Use when auditing a Mexico plant or entity (16 domains); holds the dated Mexico register. Do NOT use for India (use gia-audit:gia-pack-india), Malaysia (use gia-audit:gia-pack-malaysia), RACM (use gia-audit:gia-racm-icfr-testing) or fraud (use gia-fraud:gia-fraud-investigation)."
---

# Mexico pack

Entity code is MKSDL (MKSLD is an older alias; confirm which the engagement files use). Statutory values are held only in `references/statutory-register-mexico.md`; year-sensitive values in `references/year-check-uma-isn.md`. Rows marked `[UNVERIFIED]` or `CONFLICT` cannot support a finding.

## Before any test
1. Context. Confirm plant type (stamping, injection, die casting), state of operation, border-zone status, headcount, audit period. Anything not supplied is an open dependency in the working paper; do not default to "metal stamping" or any other assumption.
2. Evidence. `references/mx-audit_evidence_methodology.md` defines the source-type tags `[INS]` `[PHY]` `[CON]` `[REP]` `[REC]` `[OBS]` `[ANA]` and assertion codes. The tags describe the source of an item; the evidence grade R1 to R5 and the strict R3 test come from `gia-core:iron-rules`. Inquiry alone never suffices; every critical finding needs at least one confirmed (portal-obtained) or physically observed item; "cannot be verified" is a valid finding with what was requested and why the absence is a risk.
3. Year-check before any payroll or tax recompute: complete `references/year-check-uma-isn.md` for each year in scope (UMA is not the same as the general minimum wage and changes on a different date).
4. Web-validate regulations through agent `statutory-validator`; workflow Step 3 in `mx-workflow.md` lists the portals.

## Domain index
| Domain | File |
|---|---|
| 1 SAT and fiscal | `mx-sat_fiscal.md`, `mx-tax_rates_vat.md` |
| 2 Payroll and labour | `mx-payroll_labor.md` |
| 3 Customs and IMMEX | `mx-immex_customs.md` |
| 4 Financial reporting (NIF) | `mx-nif_accounting.md` |
| 5 Environmental | `mx-environmental.md` |
| 6 Workplace safety | `mx-safety_noms.md` |
| 7 Internal controls and anti-fraud | `mx-internal_controls.md`, `mx-red_flags.md` |
| 8 ERM | `mx-erm_risk_management.md` |
| 9 REPSE and subcontracting | `mx-repse_subcontracting.md` |
| 10 Operational and quality | `mx-operational_quality.md` |
| 11 Anti-bribery and ethics | `mx-ethics_antibribery.md` |
| 12 Banking and treasury | `mx-banking_finance.md` |
| 13 Expatriate, union, manpower | `mx-expat_union_hr.md` |
| 14 S&OP and planning | `mx-sales_sop_planning.md` |
| 15 Warehouse and inventory | `mx-warehouse_operations.md` |
| 16 Material balance and scrap | `mx-material_balance_scrap.md` |
Full test tables, step order and portal list: `mx-workflow.md`. Document scanning: `mx-document_scan_guide.md`.

## Rules specific to Mexico
- Quantify in MXN, kg or percent, or state why it cannot be quantified.
- Digit tests (weigh-gate, payments, invoices) go through `gia-fraud:gia-fraud-analytics`; a deviation is an indicator that needs physical or documentary corroboration, never a conclusion.
- Border-zone IVA and ISR stimuli depend on registration status and domicile history; test eligibility, not only the rate applied.
- Transfer-pricing, thin capitalisation and CFDI reform points are criteria questions: take values from the register and flag for counsel or the tax adviser where interpretation is needed.
- Include the next filing deadlines in the working paper; take dates from the register.
- Report format: `gia-report-qa:gia-ia-report`. This pack emits a findings register.

## Open items
No Mexico healthcare pack exists. Plant state, border status and the UMA and ISN values for each audit year are open dependencies until supplied.
