#!/usr/bin/env python3
"""
check_rates.py - freshness gate for the three gia-audit statutory registers (India, Malaysia, Mexico).

Ported from gia-governance-suite:gia-statutory-freshness (check_rates.py v1.0.0) and adapted: it no longer reads a
rate table and data/register.json; it reads the register rows (`| IN-001 | ... |`, `MY-`, `MX-`) directly.

Run it BEFORE any statutory recompute and before quoting a statutory value in a finding.

A register row is flagged when
  NOT_VERIFIED   status is anything other than VERIFIED ([UNVERIFIED], SECONDARY-ONLY, CONFLICT, CORRECTED, NOT FOUND ...)
  STALE          verified-on is more than --max-age-days (default 180) before --asof
  NO_DATE        status is VERIFIED but verified-on is empty
  BAD_DATE       verified-on cannot be parsed (use DD-Mon-YYYY, e.g. 29-Oct-2026) or lies after --asof
  UNKNOWN_ID     (with --used-in) a pointer cites an id that is not in any register

A clean result means every checked row is VERIFIED and recent. It does not prove the value is right: the register is
a dated tripwire, not a legal authority.

  check_rates.py [--registers FILE ...] [--pack india|malaysia|mexico] [--ids IN-001,MY-003]
                 [--used-in FILE_OR_DIR ...] [--asof 2026-10-30] [--max-age-days 180] [--format md|json]

Exit code: 0 no findings, 1 findings, 2 usage or parse error. Standard library only.
"""
import argparse
import json
import re
import sys
from datetime import date, datetime
from pathlib import Path

__version__ = "1.0.1"

PACKS = {"india": "IN", "malaysia": "MY", "mexico": "MX"}
ROW_RE = re.compile(r"^\|\s*((?:IN|MY|MX)-\d{3,})\s*\|")
POINTER_RE = re.compile(r"\[((?:IN|MY|MX)-\d{3,})\]")
MONTHS = {m: i for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass


def default_registers():
    skills = Path(__file__).resolve().parent.parent.parent
    return sorted(skills.glob("gia-pack-*/references/statutory-register-*.md"))


def parse_date(text):
    """Return a date, None when empty, or False when unparseable."""
    t = re.sub(r"\(.*", "", (text or "")).strip()
    if t in ("", "-", "n/a", "N/A"):
        return None
    m = re.fullmatch(r"(\d{1,2})[- ]([A-Za-z]{3})[a-z]*[- ](\d{4})", t)
    if m and m.group(2).lower() in MONTHS:
        try:
            return date(int(m.group(3)), MONTHS[m.group(2).lower()], int(m.group(1)))
        except ValueError:
            return False
    try:
        return datetime.strptime(t, "%Y-%m-%d").date()
    except ValueError:
        return False


def norm_status(text):
    s = (text or "").strip()
    s = re.sub(r"\(.*", "", s).strip().strip("[]").strip()
    return s.upper() or "EMPTY"


def split_row(line):
    cells = [c.strip() for c in line.strip().strip("|").split("|")]
    return cells


def load_rows(paths):
    rows, errors = [], []
    for p in paths:
        p = Path(p)
        try:
            text = p.read_text(encoding="utf-8")
        except OSError as e:
            errors.append(f"cannot read {p}: {e.strerror}")
            continue
        n = 0
        for lineno, line in enumerate(text.splitlines(), 1):
            if not ROW_RE.match(line):
                continue
            c = split_row(line)
            if len(c) < 8:
                errors.append(f"{p.name}:{lineno}: expected 8 cells, found {len(c)}")
                continue
            rows.append({"id": c[0], "item": c[1], "verified_on": c[-2], "status": c[-1], "file": p.name, "line": lineno})
            n += 1
        if n == 0:
            errors.append(f"{p.name}: no register rows found")
    return rows, errors


def check_rows(rows, asof, max_age):
    findings = []

    def add(row, cat, detail, sev):
        findings.append({"id": row["id"], "item": row["item"], "category": cat, "severity": sev, "detail": detail,
                         "where": f"{row['file']}:{row['line']}"})

    for r in rows:
        status = norm_status(r["status"])
        d = parse_date(r["verified_on"])
        if status != "VERIFIED":
            add(r, "NOT_VERIFIED", f"status is {status}; do not cite in a finding until the validator sets VERIFIED", "HIGH")
        if d is False:
            add(r, "BAD_DATE", f"verified-on '{r['verified_on']}' is not a valid date (DD-Mon-YYYY)", "MED")
        elif d is None:
            if status == "VERIFIED":
                add(r, "NO_DATE", "status is VERIFIED but verified-on is empty", "HIGH")
        elif d > asof:
            add(r, "BAD_DATE", f"verified-on {d} is after the as-of date {asof}", "MED")
        elif (asof - d).days > max_age:
            add(r, "STALE", f"verified {d}, {(asof - d).days} days before {asof} (limit {max_age}); re-verify", "MED")
    return findings


def collect_pointers(targets):
    used, files = {}, []
    for t in targets:
        t = Path(t)
        files += sorted(t.rglob("*.md")) if t.is_dir() else [t]
    for f in files:
        try:
            text = f.read_text(encoding="utf-8")
        except OSError:
            continue
        if f.name.startswith("statutory-register-"):
            continue
        for rid in POINTER_RE.findall(text):
            used.setdefault(rid, set()).add(f.name)
    return used


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--registers", nargs="+", help="register files (default: the three registers beside this script)")
    ap.add_argument("--pack", choices=sorted(PACKS), help="check only one pack's rows")
    ap.add_argument("--ids", help="comma-separated row ids to check, e.g. IN-001,MY-003")
    ap.add_argument("--used-in", nargs="+", help="check only rows cited by [ID] pointers in these files or folders")
    ap.add_argument("--asof", help="as-of date, YYYY-MM-DD (default: today)")
    ap.add_argument("--max-age-days", type=int, default=180)
    ap.add_argument("--format", choices=["md", "json"], default="md")
    ap.add_argument("--version", action="version", version=__version__)
    a = ap.parse_args(argv)

    asof = parse_date(a.asof) if a.asof else date.today()
    if asof is False or asof is None:
        print(f"Invalid --asof: {a.asof}", file=sys.stderr)
        return 2
    paths = a.registers or default_registers()
    if not paths:
        print("No register files found.", file=sys.stderr)
        return 2
    rows, errors = load_rows(paths)
    if errors:
        for e in errors:
            print(f"ERROR: {e}", file=sys.stderr)
        return 2

    total = len(rows)
    if a.pack:
        rows = [r for r in rows if r["id"].startswith(PACKS[a.pack] + "-")]
    findings = []
    known = {r["id"] for r in rows}
    if a.ids:
        wanted = [x.strip() for x in a.ids.split(",") if x.strip()]
        for w in wanted:
            if w not in known:
                findings.append({"id": w, "item": "", "category": "UNKNOWN_ID", "severity": "HIGH",
                                 "detail": "id is not in the register", "where": "--ids"})
        rows = [r for r in rows if r["id"] in wanted]
    if a.used_in:
        used = collect_pointers(a.used_in)
        for rid in sorted(set(used) - {r["id"] for r in load_rows(paths)[0]}):
            findings.append({"id": rid, "item": "", "category": "UNKNOWN_ID", "severity": "HIGH",
                             "detail": "pointer cites an id that is not in any register (" + ", ".join(sorted(used[rid])[:3]) + ")",
                             "where": "--used-in"})
        rows = [r for r in rows if r["id"] in used]
    findings += check_rows(rows, asof, a.max_age_days)

    flagged = sorted({f["id"] for f in findings})
    summary = {"asof": str(asof), "max_age_days": a.max_age_days, "rows_in_registers": total,
               "rows_checked": len(rows), "rows_flagged": len(flagged)}
    if a.format == "json":
        print(json.dumps({**summary, "findings": findings}, indent=2, ensure_ascii=False))
    else:
        out = [f"# Statutory register freshness (as of {asof}; limit {a.max_age_days} days)", "",
               f"{summary['rows_checked']} of {total} register rows checked; {summary['rows_flagged']} flagged.", ""]
        if not findings:
            out.append("No findings. Every checked row is VERIFIED and within the age limit. This is not legal verification: "
                       "confirm each parameter against the official notification.")
        for sev in ("HIGH", "MED"):
            items = [f for f in findings if f["severity"] == sev]
            if items:
                out.append(f"## {sev} ({len(items)})")
                out += [f"- [{f['category']}] {f['id']} {f['item'][:60]} ({f['where']}): {f['detail']}" for f in items]
                out.append("")
        out.append("The register is a dated tripwire, not a legal authority.")
        print("\n".join(out))
    return 1 if findings else 0


if __name__ == "__main__":
    sys.exit(main())
