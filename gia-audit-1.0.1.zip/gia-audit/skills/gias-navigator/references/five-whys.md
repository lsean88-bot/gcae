# 5 Whys — Layered onto the Governance/Process/People/Technology/Culture Root Cause Method

MKTron GIA's existing root cause discipline (the root-cause dimensions in `gia-fieldwork-workpapers`) requires classifying a control failure
into one or more of five dimensions: Governance, Process, People, Technology, Culture. That
classification answers *which kind* of cause it is. It does not always force the analysis deep
enough to answer *why that dimension failed in this specific case* — which is where a
five-times-iterated "why" chain adds value, and why IIA Standard 14.3 (Evaluation of Findings)
calls for evaluating significance through causal analysis rather than accepting the first
plausible explanation.

Use both together: classify the dimension first, then drill the chosen dimension with 5 Whys
until you hit a cause that is (a) verifiable with evidence and (b) would actually prevent
recurrence if fixed. Stop before or after five iterations — five is a typical depth, not a fixed
rule; some chains resolve in three, some need seven.

## The technique

1. State the observed failure in one sentence — the Condition, exactly as it will appear in the
   finding.
2. Ask "why did this happen?" and write the first-level answer.
3. Ask "why" again of that answer. Repeat.
4. At each step, note:
   - **Evidence available** to confirm or refute this level of cause (don't advance on an
     unverified assumption — this is where the zero-assumption rules in `gia-core:iron-rules` apply
     directly to root cause work).
   - **Dimension** this level sits in (Governance / Process / People / Technology / Culture) —
     the dimension can shift as you go deeper (e.g. a People-looking failure often resolves to a
     Process or Governance cause underneath).
5. Stop when the next "why" would answer a question outside the organization's control (e.g.
   "because the regulator changed the threshold") or when you reach a cause that, if remediated,
   would plausibly prevent recurrence — that is the root cause to carry into the Recommendation.
6. Before finalizing, ask the two validation questions from Standard 14.3: does the causal chain
   hold together without gaps, and would addressing this cause — and not a shallower one — prevent
   recurrence? If either answer is no, the chain isn't finished.

## Worked example (illustrative, not a real MKTron finding)

Condition: 3 of 25 sampled purchase orders lacked required supervisor approval before processing.

| # | Why | Evidence to confirm/refute | Dimension |
|---|---|---|---|
| 1 | Why did POs process without approval? | SAP workflow log shows approval step skipped | Technology |
| 2 | Why could the workflow be skipped? | SAP config shows the approval step is a soft-stop, not a hard-block | Technology → Process |
| 3 | Why is it a soft-stop rather than a hard-block? | Change request history: hard-block was relaxed 14 months ago | Process |
| 4 | Why was it relaxed? | Change ticket cites a one-time year-end volume spike as justification | Governance |
| 5 | Why was a "temporary" change never reverted? | No control owner assigned to review temporary configuration changes for expiry | Governance |

Root cause: absence of a control-owner review cycle for temporary system configuration changes
(Governance), not "staff forgot to approve" (People) — the shallow, symptom-level explanation the
chain started with. The recommendation should target the governance gap (mandatory expiry/review
on all temporary control overrides), not retraining, because retraining would not prevent
recurrence if the soft-stop remains permanently configured.

## Where this fits in the report

Slot the completed chain into the workpaper as supporting evidence for the Cause element; the
finding narrative itself should state only the resolved root cause in one or two sentences, per
existing 5C/9-element formatting — the full Why-chain belongs in the workpaper appendix, not the
finding text seen by the Audit Committee.

## Common failure modes to avoid

- **Stopping at the first People-shaped answer.** "Staff error" is almost never the root cause;
  it is usually a symptom of a Process or Governance gap that made the error possible or likely.
- **Advancing on assertion rather than evidence.** Each "why" needs something that could
  independently confirm it — an interview alone is a lead, not evidence, until corroborated.
- **Conflating multiple causal chains.** If two people independently cite different first-level
  "whys" for the same condition, run both chains separately rather than merging them; note in the
  finding if root cause is genuinely multi-causal.
