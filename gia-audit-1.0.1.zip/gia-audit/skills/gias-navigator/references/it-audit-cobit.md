# IT Audit — COBIT 2019 & ISACA Reference

## ITGC Testing Programme (4 Domains)

### 1. Access Management (COBIT DSS05, APO13)
| Control | Test Procedure | Evidence Required |
|---|---|---|
| User access provisioning | Sample new joiners; verify approval before access granted | Access request forms; HR joiners list |
| User access de-provisioning | Sample leavers; verify access removed within policy SLA | HR leavers list; access revocation log |
| Privileged access management | List all super-user / admin accounts; verify business justification | Admin account inventory; approval evidence |
| Segregation of duties | Run SoD conflict matrix; verify conflicting roles not assigned | SoD report; exceptions log with approvals |
| Periodic access reviews | Inspect access certification evidence for in-scope systems | Certification completion log; manager sign-offs |
| Password controls | Inspect system configuration for complexity, age, lockout | System screenshots; security policy |

### 2. Change Management (COBIT BAI06, BAI07)
| Control | Test Procedure | Evidence Required |
|---|---|---|
| Change request authorisation | Sample changes; verify approval before implementation | Change tickets with approvals |
| Development-to-production migration | Verify changes moved only through approved process | Migration log; deployment approvals |
| Emergency change controls | Sample emergency changes; post-implementation review | Emergency change log; retroactive approvals |
| Segregation of duties (Dev vs Prod) | Verify developers cannot migrate to production | Access matrix; system configuration |
| Change testing documentation | Inspect test evidence for sampled changes | Test plans; test results; UAT sign-offs |

### 3. Computer Operations (COBIT DSS01, DSS04)
| Control | Test Procedure | Evidence Required |
|---|---|---|
| Backup and recovery | Test restore procedures; verify backup completion reports | Backup completion logs; restore test results |
| Batch job monitoring | Inspect job scheduling tool; sample failed jobs and resolution | Job logs; incident tickets |
| Problem and incident management | Review P1/P2 incident register; verify RCA for major incidents | Incident register; RCA documents |
| Business continuity / DR | Inspect BCP/DRP documentation; evidence of annual test | BCP document; DR test report |
| Capacity and performance monitoring | Review performance dashboards; threshold alerting | Monitoring tool evidence |

### 4. Program Development (COBIT BAI02, BAI03)
| Control | Test Procedure | Evidence Required |
|---|---|---|
| SDLC governance | Review SDLC policy; verify adherence for significant projects | SDLC documentation; project charters |
| Requirements documentation | Sample projects; inspect approved requirements and traceability | Requirements specifications; approval records |
| Security by design | Verify security testing (SAST/DAST) in development lifecycle | Security test results; remediation evidence |

---

## COBIT 2019 — Maturity Assessment Scale

| Level | Description |
|---|---|
| 0 — Incomplete | Process not implemented; objectives not achieved |
| 1 — Initial | Ad hoc; depends on individual knowledge |
| 2 — Managed | Planned and monitored; basic controls exist |
| 3 — Defined | Tailored standard process; documented and consistently applied |
| 4 — Quantitatively Managed | Measured; statistical controls applied |
| 5 — Optimising | Continuous improvement; benchmarked against best practice |

**Target State**: Core financial/operational systems: Level 3. Public company IT environment (SOX): Level 3–4.

---

## Cybersecurity Audit (IIA Topical Requirements + NIST CSF)

### NIST CSF 2.0 Core Functions
1. **Govern** (NEW in CSF 2.0): Cybersecurity risk strategy; roles and responsibilities; policy
2. **Identify**: Asset management; risk assessment; data classification
3. **Protect**: Access control; data security; training; secure configuration; SDLC
4. **Detect**: Anomaly detection; continuous monitoring; log management
5. **Respond**: Incident response plan; communications; analysis; mitigation
6. **Recover**: Recovery planning; business continuity integration; post-incident review

### IIA Cybersecurity Topical Requirements (effective Feb 5, 2026)
- Assess cybersecurity governance and accountability at board level
- Evaluate cybersecurity risk assessment processes and integration into ERM
- Test key cybersecurity controls across the NIST CSF functions
- Verify cybersecurity incident response plan currency and test completion
- Assess third-party cybersecurity risk management programme

---

## Application Controls Testing
| Control Type | Examples | Test Approach |
|---|---|---|
| Input Controls | Mandatory field validation; range checks; format checks | Inspect system configuration; attempt invalid inputs |
| Processing Controls | Calculation logic; duplicate prevention; matching logic | Reperformance; exception report review |
| Output Controls | Report distribution controls; output reconciliation | Verify authorised recipients; reconcile output to input |
| Interface Controls | File transfer integrity checks; error handling; completeness | Review interface logs; test error handling |

---

## GRC / Audit Technology Tools

| Tool Category | Products | Use in Audit |
|---|---|---|
| Data Analytics | ACL (Galvanize), IDEA, Python, R | Benford, duplicates, outliers, stratification |
| Continuous Monitoring | SAP GRC, Oracle GRC, MetricStream | Real-time control monitoring |
| Audit Management | AuditBoard, TeamMate+, Diligent | Workpaper management, findings tracker |
| IT Risk Assessment | ServiceNow GRC, RSA Archer | IT risk register; COBIT mapping |
| SIEM / Security Analytics | Splunk, Microsoft Sentinel, IBM QRadar | Log analysis; anomaly detection |
| Identity Governance | SailPoint, Saviynt, CyberArk | Access reviews; PAM testing |
| Vulnerability Management | Qualys, Tenable, Rapid7 | IT security control testing |
