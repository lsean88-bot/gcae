# Frameworks reference (COSO ERM, COBIT, governance, accounting standards)

Companion to the standards map. COSO Internal Control 2013 is in `gia-racm-icfr-testing/references/coso-ic-map.md`. Fraud methodology is in `gia-fraud:gia-fraud-investigation`. SOX-specific material is applied only where US-style ICFR reporting is in scope (see `gia-racm-icfr-testing`). Framework editions below are as stated in the retired source and are [UNVERIFIED] against the publisher.

## Contents
- COSO ERM 2017
- ISACA COBIT 2019
- Corporate governance and the Three Lines Model
- Accounting standards relevant to audit
- Quantitative risk tools

##  C — COSO ERM 2017

### Five Components and 20 Principles

| Component | Key Principles |
|---|---|
| 1. Governance & Culture | Board oversight (P2), Operating structures (P3), Culture (P4), Commitment to core values (P5) |
| 2. Strategy & Objective Setting | Risk appetite (P6-P7), Strategy analysis (P8), Business objectives (P9) |
| 3. Performance | Risk identification (P10), Risk assessment (P11-P12), Risk prioritization (P13), Risk response (P14) |
| 4. Review & Revision | Substantial change (P15), Risk & performance (P16), ERM improvement (P17) |
| 5. Information, Communication & Reporting | Data analytics (P18), Risk information systems (P19), Reporting (P20) |

### ERM Audit Techniques
- Assess risk appetite statement completeness and board approval
- Validate risk register currency: inherent risk → control assessment → residual risk
- Test risk tolerance thresholds and escalation triggers
- Evaluate KRI (Key Risk Indicator) relevance and threshold calibration
- Review linkage between ERM risk map and audit universe prioritization
- Test ERM integration with strategy-setting (board strategy workshops, risk-adjusted business plans)

> For GARP FRM quantitative risk tools integration → **read `references/garp-risk-tools.md`**

---


##  D — ISACA / COBIT 2019

### COBIT 2019 Core Model: 40 Governance & Management Objectives

**5 Governance Objectives (EDM domain)**
EDM01 Governance Framework, EDM02 Benefits Delivery, EDM03 Risk Optimization, EDM04 Resource Optimization, EDM05 Stakeholder Engagement

**35 Management Objectives (APO, BAI, DSS, MEA domains)**
- APO (Align, Plan, Organise): Strategy, Enterprise Architecture, Innovation, Portfolio, Budget, HR, Relationships, Service Agreements, Suppliers, Quality, Risk, Data, Security, Managed IT
- BAI (Build, Acquire, Implement): Programs, Requirements, Solutions, Availability, Organisational Change, IT Changes, IT Change Acceptance, Knowledge, Asset Management, Configuration
- DSS (Deliver, Service, Support): Operations, Service Requests, Problems, Continuity, Security, Business Process Controls
- MEA (Monitor, Evaluate, Assess): Performance, System of Internal Control, Compliance, Assurance

### IT Audit Techniques (COBIT 2019 + ISACA ITAF)
- **ITGC Testing**: Access management, Change management, Computer operations, Program development
- **Application Controls**: Input controls, processing controls, output controls, interface controls
- **IT Risk Assessment**: Align COBIT management objectives to IT risk universe; rate maturity (0–5 scale)
- **Cybersecurity Audit**: Map to NIST CSF; test IAM, patch management, incident response, DLP
- **Cloud Audit**: Shared responsibility model testing; SSAE 18 / SOC 1 / SOC 2 reliance assessment
- **Data Analytics Tools**: ACL/ARBUTUS, IDEA, PowerBI, Python/Pandas for Benford's Law, duplicate detection, outlier analysis

> For full IT audit program templates → **read `references/it-audit-cobit.md`**

---

##  H — CORPORATE GOVERNANCE FRAMEWORK

### G20/OECD Principles of Corporate Governance 2023 (Revised)

| Chapter | Key Audit Focus |
|---|---|
| I. Effective CG Framework | Legal/regulatory basis for IA independence; audit charter legality |
| II. Shareholder Rights & Equitable Treatment | Related-party transaction controls; conflicts of interest |
| III. Institutional Investors & Markets | Activist investor disclosures; voting rights governance |
| IV. Disclosure & Transparency | Financial reporting quality; audit committee oversight of disclosure |
| V. Board Responsibilities | Board composition, IA access to board, risk oversight, sustainability |

**Key 2023 Updates**:
- Sustainability / ESG: Board responsibilities for sustainability disclosure; internal audit role in ESG assurance
- Tax risk: Board risk frameworks must include tax compliance and planning risk
- Data privacy and cybersecurity: Explicit mention as governance-level risk categories
- Internal audit reporting: IA should functionally report to board or AC; direct access to non-executive directors endorsed

### Board / Audit Committee — IA Governance Requirements

| Requirement | Standard |
|---|---|
| Functional reporting to Board/AC | GIAS 2024 Dom III; G20/OECD Principle V |
| Board oversight of QAIP | GIAS 2024 Standard 15 |
| Board approval of IA charter | GIAS 2024 Standard 6.1 |
| Board approval of IA budget and plan | GIAS 2024 Standard 9 |
| CAE access to board without management | IIA Core Principle; G20/OECD Principle V |
| Disclosure of IA-identified MW/SD | SOX §302/§404; SEC reporting |

### IIA Three Lines Model 2020

| Line | Role | Examples |
|---|---|---|
| First Line | Owns and manages risk/control | Business units, process owners, front-line management |
| Second Line | Oversees risk/control, provides expertise | Risk management, compliance, legal, finance, QHSE |
| Third Line | Independent assurance to board and senior management | Internal Audit (CAE) |

---

##  I — INTERNATIONAL ACCOUNTING STANDARDS (IAS/IFRS)

### Key Standards Relevant to Internal Audit

| Standard | Subject | IA Relevance |
|---|---|---|
| IAS 1 / IFRS (Presentation) | Financial statement presentation | Assess classification, reclassification, disclosure |
| IAS 2 | Inventories | Inventory valuation, NRV, FIFO/WAC; costing audit |
| IAS 7 | Statement of Cash Flows | Cash flow manipulation; fraud risk in classification |
| IAS 8 | Accounting Policies, Estimates, Errors | Prior period errors; policy change disclosures |
| IAS 10 | Events after Reporting Period | Completeness of post-balance sheet disclosures |
| IAS 16 | PPE | CAPEX/OPEX misclassification; depreciation rates |
| IAS 19 | Employee Benefits | Actuarial assumptions; post-employment obligations |
| IAS 24 | Related Party Disclosures | RPT completeness; conflicts of interest |
| IAS 36 | Impairment of Assets | CGU definition; impairment trigger indicators |
| IAS 37 | Provisions, Contingent Liabilities | Adequacy and completeness of provisions |
| IAS 38 | Intangible Assets | Capitalisation criteria; amortization |
| IAS 40 | Investment Property | Fair value model; auditor's property valuation review |
| IFRS 9 | Financial Instruments | ECL models; classification and measurement |
| IFRS 15 | Revenue Recognition | 5-step model; percentage completion; variable consideration |
| IFRS 16 | Leases | Right-of-use assets; lease liability completeness |
| IFRS 17 | Insurance Contracts | Actuarial models; CSM calculation |

### Key Audit Assertions Mapped to Standards
**Completeness** · **Existence/Occurrence** · **Valuation/Accuracy** · **Rights & Obligations** · **Presentation & Disclosure** · **Cut-off**

---


##  G — GARP FRM RISK TOOLS FOR AUDIT

### Quantitative Risk Tools Applicable to Internal Audit

| Tool | Application |
|---|---|
| Value at Risk (VaR) | Quantify tail risk exposure in financial audits; validate treasury risk models |
| Expected Shortfall (CVaR) | Audit stress-testing; evaluate adequacy of risk buffers |
| Key Risk Indicators (KRIs) | Calibrate ERM monitoring thresholds; validate escalation triggers |
| Scenario Analysis / Stress Testing | Assess adequacy of contingency planning; BCM audit |
| Monte Carlo Simulation | Model-based audit of complex financial instruments or inventory valuations |
| Risk-Adjusted Return (RAROC) | Evaluate performance management systems; audit incentive alignment |
| Operational Risk Capital | Basel III op-risk framework; validate LDA (Loss Distribution Approach) |
| Counterparty Credit Risk | Review credit exposure controls, collateral management, netting agreements |
| Correlation / Concentration Risk | Audit portfolio/vendor/customer concentration; validate diversification policy |

### GARP FRM Integration in ERM Audit
- Validate risk quantification models used in risk appetite statements
- Review adequacy of economic capital models for business lines
- Assess model risk governance: model validation, independent review, model inventory
- Benchmark KRI thresholds against industry peers and GARP/Basel standards

---
