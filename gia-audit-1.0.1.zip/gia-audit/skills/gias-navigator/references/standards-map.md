# IIA Global Internal Audit Standards (2024) — Full Citation Map


## Contents
- Domain I — Purpose of Internal Auditing
- Domain II — Ethics and Professionalism
- Domain III — Governing the Internal Audit Function
- Domain IV — Managing the Internal Audit Function
- Domain V — Performing Internal Audit Services
- Quick lookup by audit phase
- Citing standards in a finding or board paper

Source of truth: The IIA, *Global Internal Audit Standards*, published 9 January 2024, effective
9 January 2025 (theiia.org/globalassets/site/standards/globalinternalauditstandards_2024january9.pdf).
Structure verified against the official table of contents. Titles below are the Standards' own
titles (factual labels, not creative text); the one-line "Apply it" notes are original guidance
written for MKTron GIA use, not reproductions of the IIA's Requirements text. Do not paste IIA
Requirements/Considerations/Evidence paragraphs verbatim into any deliverable — cite the number
and title, then write the application in your own words, exactly as this file does.

52 Standards. 15 Principles. 5 Domains.

---

## Domain I — Purpose of Internal Auditing
No principles/standards — a purpose statement only. Cite as "Domain I" when a paper needs to
ground *why* GIA exists (e.g. opening lines of an annual plan or charter renewal).

---

## Domain II — Ethics and Professionalism
*Applies to every internal auditor personally, not just the CAE. This is the domain to cite when
a finding, investigation, or board paper touches integrity, bias, competency, care, skepticism, or
confidentiality.*

| Principle | Standard | Title | Apply it |
|---|---|---|---|
| P1 Demonstrate Integrity | 1.1 | Honesty and Professional Courage | Cite when a finding required pushing back on management pressure to soften a rating. |
| | 1.2 | Organization's Ethical Expectations | Cite when GIA is escalating a code-of-conduct breach found incidentally during fieldwork. |
| | 1.3 | Legal and Ethical Behavior | Cite alongside MACC s.17A / FCPA / UKBA references in ABAC and fraud work. |
| P2 Maintain Objectivity | 2.1 | Individual Objectivity | Cite in the engagement independence declaration. |
| | 2.2 | Safeguarding Objectivity | Cite when an auditor is rotated off an engagement to avoid a self-review conflict. |
| | 2.3 | Disclosing Impairments to Objectivity | Cite when disclosing a prior-year advisory role before an assurance engagement in the same area. |
| P3 Demonstrate Competency | 3.1 | Competency | Cite when justifying use of an external specialist (e.g. die-casting metallurgist, forensic IT). |
| | 3.2 | Continuing Professional Development | Cite in CPE tracking and the annual training plan. |
| P4 Exercise Due Professional Care | 4.1 | Conformance with the Global Internal Audit Standards | Cite in the engagement's methodology statement; also the standard to cite for any **documented deviation** from GIAS (e.g. reduced sample size due to resource constraints). |
| | 4.2 | Due Professional Care | Cite when justifying scope/depth decisions against cost-benefit (e.g. why MKSDL tooling advances got 100% population testing vs sampling elsewhere). |
| | 4.3 | Professional Skepticism | **The fraud/investigation anchor citation.** Cite whenever a finding narrative documents that management's explanation was independently verified rather than accepted at face value — this is the standard MKTron's fraud investigation reports should be citing next to ACFE Fraud Triangle analysis, not a generic "GIAS 2024" reference. |
| P5 Maintain Confidentiality | 5.1 | Use of Information | Cite in investigation chain-of-custody sections. |
| | 5.2 | Protection of Information | Cite in data-handling clauses of board-restricted reports (e.g. MKPC-GIA-2026-01 distribution restriction to Chairman/AC only). |

---

## Domain III — Governing the Internal Audit Function
*CAE-level. Cite in charter renewals, AC papers about GIA's own positioning, and annual
independence declarations — not in individual findings.*

| Principle | Standard | Title |
|---|---|---|
| P6 Authorized by the Board | 6.1 | Internal Audit Mandate |
| | 6.2 | Internal Audit Charter |
| | 6.3 | Board and Senior Management Support |
| P7 Positioned Independently | 7.1 | Organizational Independence |
| | 7.2 | Chief Audit Executive Qualifications |
| P8 Overseen by the Board | 8.1 | Board Interaction |
| | 8.2 | Resources |
| | 8.3 | Quality |
| | 8.4 | External Quality Assessment |

Apply it: 8.4 is the standard to cite when scoping MKTron GIA's next External Quality Assessment —
worth flagging to the AC given the function has never formally cited an EQA cadence in memory.

---

## Domain IV — Managing the Internal Audit Function
*CAE-level. Cite in the annual audit plan, resourcing papers, and GIA's own quality program.*

| Principle | Standard | Title |
|---|---|---|
| P9 Plan Strategically | 9.1 | Understanding Governance, Risk Management, and Control Processes |
| | 9.2 | Internal Audit Strategy |
| | 9.3 | Methodologies |
| | 9.4 | Internal Audit Plan |
| | 9.5 | Coordination and Reliance |
| P10 Manage Resources | 10.1 | Financial Resource Management |
| | 10.2 | Human Resources Management |
| | 10.3 | Technological Resources |
| P11 Communicate Effectively | 11.1 | Building Relationships and Communicating with Stakeholders |
| | 11.2 | Effective Communication |
| | 11.3 | Communicating Results |
| | 11.4 | Errors and Omissions |
| | 11.5 | Communicating the Acceptance of Risks |
| P12 Enhance Quality | 12.1 | Internal Quality Assessment |
| | 12.2 | Performance Measurement |
| | 12.3 | Oversee and Improve Engagement Performance |

Apply it: 11.5 is the standard to cite when management formally accepts a residual risk GIA
flagged (e.g. a disputed finding closed at management's own risk) — useful precision for the
Appendix F–style exception logs already in use on MKPC-GIA-2026-01.

---

## Domain V — Performing Internal Audit Services
*The engagement-level domain — this is where almost all fieldwork, findings, and reporting
citations should point instead of a bare "Standard 14" or "GIAS 2024."*

### Principle 13 — Plan Engagements Effectively
| Standard | Title | Apply it |
|---|---|---|
| 13.1 | Engagement Communication | Cite for the engagement notification / opening letter to the process owner. |
| 13.2 | Engagement Risk Assessment | Cite in the engagement-level risk assessment that sets scope (distinct from 9.1, which is function-wide). |
| 13.3 | Engagement Objectives and Scope | Cite when defining SMART engagement objectives in the audit program. |
| 13.4 | Evaluation Criteria | Cite when stating the "Criteria" element of a 5C/9-element finding — this is the precise clause for the criteria leg, not 14.3. |
| 13.5 | Engagement Resources | Cite when justifying use of a specialist or co-source resource on an engagement. |
| 13.6 | Work Program | Cite for the approved audit program / test-of-design-and-effectiveness plan. |

### Principle 14 — Conduct Engagement Work
| Standard | Title | Apply it |
|---|---|---|
| 14.1 | Gathering Information for Analyses and Evaluation | Cite for evidence-sufficiency statements — the standard behind the zero-assumption rules in `gia-core:iron-rules`. |
| 14.2 | Analyses and Potential Engagement Findings | Cite when documenting how raw exceptions became potential findings (the analytics-to-finding bridge — Benford, duplicate, JE testing outputs land here). |
| 14.3 | Evaluation of Findings | **The precise citation for root cause and significance analysis** — cite this, not a generic Standard 14, whenever writing the "Cause" element of a finding or running 5 Whys (see `five-whys-root-cause.md`). |
| 14.4 | Recommendations and Action Plans | Cite for the "Recommendation" element and SMART action-plan formulation. |
| 14.5 | Engagement Conclusions | Cite for the overall engagement opinion (Adverse / Limited / Reasonable Assurance) — the precise clause behind MKSLD's "Adverse opinion" and MKAPL's "Limited Assurance" conclusions already on file. |
| 14.6 | Engagement Documentation | Cite in workpaper retention/quality-gate sections. |

### Principle 15 — Communicate Engagement Results and Monitor Action Plans
| Standard | Title | Apply it |
|---|---|---|
| 15.1 | Final Engagement Communication | Cite for the report/board paper itself — the precise clause behind every "Standard 15" reference already used across the skill stack. |
| 15.2 | Confirming the Implementation of Recommendations or Action Plans | Cite for follow-up audits and the Management Response Tracker — the precise clause behind "Standard 15.2 compliance" already referenced in `cae-command-centre` and `cae-cowork-ai-plugin`. |

---

## Quick lookup by audit phase

| Phase | Primary Domain V standards | Supporting Domain II standards |
|---|---|---|
| Planning | 13.1, 13.2, 13.3, 13.4, 13.5, 13.6 | 4.1, 4.2 |
| Fieldwork | 14.1, 14.2 | 4.3 (Professional Skepticism), 3.1 |
| Root cause / significance | 14.3 | 4.3 |
| Reporting | 14.4, 14.5, 14.6, 15.1 | 1.1, 11.3 (Domain IV) |
| Follow-up | 15.2 | 11.5 (Domain IV, for accepted-risk closures) |
| Fraud / investigation | 4.3, 1.3, 5.1, 5.2 | — |

## Citing standards in a finding or board paper

Prefer the precise sub-clause over the domain/principle when writing for an audit-literate
reader (Audit Committee, external QA reviewer). Reserve the principle-level citation for
non-technical audiences (management narrative, executive summary).

**Precise (workpapers, Appendix, technical annex):**
"Root cause was evaluated per Standard 14.3 (Evaluation of Findings), applying the 5 Whys
technique against the Governance/Process/People/Technology/Culture dimensions in the root-cause dimensions in `gia-fieldwork-workpapers`."

**Accessible (executive summary, board narrative):**
"In line with IIA Standard 14 on Conducting Engagement Work, we traced this finding to its
underlying cause rather than stopping at the symptom."
