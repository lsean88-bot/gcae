# GARP FRM Risk Tools — Internal Audit Integration Reference


## Contents
- Quantitative Risk Tools and Audit Application
- ERM Maturity Assessment (COSO ERM 2017 / ISO 31000)
- ISO 31000:2018 Audit Assessment

## Quantitative Risk Tools and Audit Application

### 1. Value at Risk (VaR)
**Definition**: Maximum expected loss over a given time horizon at a specified confidence level (e.g., 99% VaR over 1-day)
**Audit Application**:
- Validate Treasury / risk management VaR models
- Assess whether VaR limits align with Board-approved risk appetite
- Test back-testing methodology: compare actual losses to VaR predictions
- Review VaR model assumptions: normality, historical lookback period, correlation inputs
- Audit Model Risk Management (MRM): independent validation, model inventory, governance

### 2. Expected Shortfall (CVaR / ES)
**Definition**: Average loss beyond the VaR threshold (tail risk measure; preferred under Basel III)
**Audit Application**:
- Assess stress scenario adequacy: are tail events covered?
- Validate that regulatory capital aligns with ES-based requirements (Basel III FRTB)
- Review liquidity stress tests: buffer adequacy against severe but plausible scenarios

### 3. Key Risk Indicators (KRIs)
**Audit Application**:
- Review KRI definitions: are they leading, lagging, or concurrent indicators?
- Test threshold calibration: how were amber/red thresholds set? Are they reviewed?
- Validate escalation protocols: are breached KRIs escalated to appropriate governance levels?
- Assess KRI coverage: do KRIs cover all material risk categories in the ERM framework?
- Common audit KRIs: staff turnover rate, control exceptions count, customer complaint rate, near-miss incidents, system downtime

### 4. Scenario Analysis and Stress Testing
**Audit Application**:
- Review scenario design: are scenarios severe but plausible?
- Assess reverse stress testing: what scenario would cause business failure?
- Validate assumption documentation and expert opinion inputs
- Test that results are used in capital planning and strategic decision-making
- BCM/DRP: audit whether stress scenarios are integrated into recovery plans

### 5. Monte Carlo Simulation
**Audit Application**:
- Review simulation models used for inventory valuation, option pricing, pension liability estimates
- Validate random number generator quality and convergence (number of iterations ≥ 10,000)
- Audit inputs: correlation matrices, volatility assumptions, distribution choices
- Assess sensitivity analysis: how do outputs change when key assumptions vary?

### 6. Operational Risk Frameworks (Basel III / BIS)
**Fundamental Review**: Operational risk = risk of loss resulting from inadequate/failed internal processes, people, systems, or external events
**7 Basel Event Categories**:
1. Internal fraud
2. External fraud
3. Employment practices and workplace safety
4. Clients, products, and business practices
5. Damage to physical assets
6. Business disruption and system failures
7. Execution, delivery, and process management

**Audit Application**:
- Review operational loss database: completeness, timely recording, root cause classification
- Assess RCSA (Risk and Control Self-Assessment) quality and challenge process
- Validate scenario analysis inputs for low-frequency, high-severity events
- Test Key Risk Indicators against each Basel event category

### 7. Credit Risk Tools
**Audit Application**:
- Review credit exposure methodology: EAD, PD, LGD model validation
- Audit counterparty credit risk: netting agreements, collateral management, margin calls
- Assess IFRS 9 ECL model: staging criteria (Stage 1/2/3); forward-looking macroeconomic adjustments; management overlays
- Review concentration risk: single-name, sector, geographic exposures vs. limits

### 8. RAROC (Risk-Adjusted Return on Capital)
**Audit Application**:
- Verify that business unit performance is measured on a risk-adjusted basis
- Assess whether incentive compensation is aligned with RAROC (not just revenue)
- Review hurdle rate adequacy vs. cost of equity
- Audit capital allocation methodology across business lines

---

## ERM Maturity Assessment (COSO ERM 2017 / ISO 31000)

| Maturity Level | Description | Key Indicators |
|---|---|---|
| 1 — Initial | Ad hoc risk identification; no formal framework | Risk register absent or informal; no risk appetite statement |
| 2 — Developing | Basic risk register; fragmented risk ownership | Risk register exists but not current; appetite statement high-level only |
| 3 — Defined | Documented ERM framework; risk owners assigned; integrated with annual planning | Full risk register with owners; risk-informed audit plan; KRI programme |
| 4 — Managed | Risk-adjusted decision-making; KRIs monitored; ERM linked to strategy | Risk appetite quantified; KRI dashboards operational; risk culture assessed |
| 5 — Optimising | Dynamic ERM; predictive analytics; continuous improvement embedded | Scenario-based planning; ML-based risk monitoring; board engagement high |

**Target for MKTron Group / multi-entity manufacturing**: Level 3–4, with Level 5 elements in financial risk.

---

## ISO 31000:2018 Audit Assessment

### 8 Principles of Risk Management
1. Integrated (embedded in processes, not standalone)
2. Structured and comprehensive
3. Customized
4. Inclusive (stakeholder engagement)
5. Dynamic (responsive to change)
6. Best available information
7. Human and cultural factors considered
8. Continual improvement

### Risk Management Process (ISO 31000)
Communication & Consultation → Scope/Context/Criteria → Risk Assessment (Identification + Analysis + Evaluation) → Risk Treatment → Monitoring & Review → Recording & Reporting

**Audit Assessment**: Map entity's ERM process against ISO 31000 process steps; identify gaps in each step.
