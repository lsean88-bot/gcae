---
name: gias-navigator
description: "GIAS, IIA standard citation (14.3, 14.4, 15.2), topical requirement, five whys, root cause chain, EQA readiness. Use when a finding or paper needs the exact GIAS 2024 sub-clause; holds the dated topical-requirement register. Do NOT use for finding format (use gia-audit:gia-fieldwork-workpapers) or statutory citations (use the pack statutory registers)."
---

# GIAS navigator

## How to use
1. Identify the deliverable type (finding, workpaper, board paper, engagement letter, follow-up). Domain V covers engagement work; Domains III and IV cover CAE-level governance.
2. Open `references/standards-map.md` and take only the rows you need. Cite the sub-clause, not "Standard 14".
   - 14.3 evaluation of findings, 14.4 recommendations and action plans, 14.5 engagement conclusions.
   - 15.1 final engagement communication, 15.2 confirming implementation of recommendations. These are commonly confused.
3. Match the citation register to the audience: precise sub-clause in workpapers, technical annexes and EQA-facing documents; principle-level wording in executive summaries and Board text.
4. For root cause, run `references/five-whys.md` inside the chosen dimension (governance, process, people, technology, culture). Cite 14.3 as the standards basis for the causal chain.
5. For topical requirements, read `references/topical-requirements.yaml`. Its dates are [UNVERIFIED] (secondary sources; the field may mean issue or effective date). Confirm on theiia.org and decide applicability per engagement and period before citing.
6. Frameworks: `references/frameworks.md` (COSO ERM, COBIT, governance and Three Lines, accounting standards), `references/garp-risk-tools.md`, `references/it-audit-cobit.md`.

## Rules
- Do not paste IIA requirement text verbatim; cite number and title and write the application in your own words.
- The sub-clause map has not been independently verified against the published standards; record that when the citation is for an external quality assessment.
- Before finalising, check each cited standard matches the claim made.

## Quick answer format
Standard number and title; one-line application to this context; register note if relevant. Pull only the relevant rows.
