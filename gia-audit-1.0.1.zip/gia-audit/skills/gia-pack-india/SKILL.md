---
name: gia-pack-india
description: "India audit, Chennai, Tamil Nadu, Pune, Maharashtra, Puducherry, MKAPL: TDS, GST ITC, EPF, ESIC, labour codes, CLRA, POSH, FEMA, scrap. Use when auditing an India plant or office; holds the dated India register. Do NOT use for Mexico (use gia-audit:gia-pack-mexico), Malaysia (use gia-audit:gia-pack-malaysia) or RACM (use gia-audit:gia-racm-icfr-testing)."
---

# India pack

Statutory values are **not** in this skill or its domain files. Take every rate, threshold, due date and applicability test from `references/statutory-register-india.md` (item, Act and section, value, effective date, source, verified-on, status). A row marked `[UNVERIFIED]` or `CONFLICT` cannot support a finding; send it to agent `statutory-validator`.

## Before any procedure
1. Entity facts. Confirm entity name and code, entity type, industry (factory or establishment), state and site, headcount, audit period. Anything not supplied goes to the open-dependency table below. Never assume the state or plant type.
2. Choose the state module. A site in a state with no module here is an open dependency, not a reason to apply Tamil Nadu or Maharashtra rules by analogy.
3. Load only the domain files needed. Grade evidence R1 to R5 per `gia-core:iron-rules`. Declare scope limitations immediately.
4. Run the cross-domain reconciliation tests (RT-01 to RT-12) in `gia-audit:gia-fieldwork-workpapers` when several domains are in scope.
5. Cite Act, section, notification and year from the register on every finding. Report format is owned by `gia-report-qa:gia-ia-report`; this pack emits a findings register.

## Open-dependency table (copy into the working paper)
| Fact | Why it matters | Supplied? | Owner (role) | Needed by |
|---|---|---|---|---|
| State and site per entity | Selects module and statutory rows | | | |
| Factory licence or S&E registration | Applicability of labour Acts | | | |
| Headcount (regular, contract) by month | Coverage tests | | | |
| Audit period and pay periods that straddle a rate change | Period-wise recompute | | | |
| Customer certification requirement in writing (new plant) | Readiness gate | | | |

## Domain index (state modules)
| Domain | Tamil Nadu file | Maharashtra file |
|---|---|---|
| D1 Direct tax and TDS | `tn-R01_direct_tax.md` | `mh-R01_direct_tax.md` |
| D2 GST | `tn-R02_gst_indirect_tax.md` | `mh-R02_gst_indirect_tax.md` |
| D3 EPF and ESIC | `tn-R03_epf_esic.md` | `mh-R03_epf_esic.md` |
| D4 HR and payroll | `tn-R04_hr_payroll.md` | `mh-R04_hr_payroll.md` |
| D5 Labour laws | `tn-R05_labour_laws_tn.md` | `mh-R05_labour_laws_mh.md` |
| D6 Wages and welfare | `tn-R06_wages_welfare.md` | `mh-R06_wages_welfare_mh.md` |
| D7 Company law | `tn-R07_company_law.md` | `mh-R07_company_law.md` |
| D8 FEMA and RBI | `tn-R08_fema_rbi.md` | `mh-R08_fema_rbi.md` |
| D9 Vendors and contractors | `tn-R09_vendor_contractor.md` | `mh-R09_vendor_contractor.md` |
| D10 Financial operations | `tn-R10_financial_ops.md` | `mh-R10_financial_ops.md` |
| D11 Fraud indicators | `tn-R11_fraud_detection.md` | `mh-R11_fraud_detection.md` |
| D12 Environment and safety | `tn-R12_environment_safety.md` | `mh-R12_environment_safety_mh.md` |
| D13 POSH and governance | `tn-R13_posh_governance.md` | `mh-R13_posh_governance.md` |
| D14 Compliance calendar | `tn-R14_compliance_calendar.md` | `mh-R14_compliance_calendar_mh.md` |
Workflow, document inventory and web-validation query lists: `tn-workflow.md`, `mh-workflow.md`.

## State delta (what differs, no values)
| Topic | Tamil Nadu | Maharashtra | Puducherry (UT) |
|---|---|---|---|
| Shops and establishments law | TN S&E Act (amended 2025) | MH S&E Act 2017 (amended Oct 2025) | Puducherry S&E Act and OSH Code order |
| Professional tax | TN levy | PTRC and PTEC regimes | Local-body levy, not a state Act |
| Labour welfare fund | TN LWF Board | MH LWF Board | Status unverified |
| Pollution authority | TNPCB | MPCB | UT committee (name to confirm) |
| Minimum wage notification | TN Labour Dept | MH Labour Dept (bi-annual) | Puducherry Labour Dept |
| GSTIN state code | in register | in register | in register |
Values for every row above: `statutory-register-india.md`. Puducherry is a map and a method, not an authority: `puducherry.md` with confidence labels and `puducherry-verification-register.md`.

## Modules
| Need | File |
|---|---|
| General manufacturing (scrap and material balance, BOM yield, subcontracting, OEM requirements, S&OP, warehouse) | `general-mfg.md` |
| Payroll structure and EPF base | `hr-payroll-salary-structure.md` |
| Payroll fraud indicators and analytics checklist | `hr-payroll-fraud-detection.md` |
| Contract labour (TN, MH) | `hr-contract-labour-clra.md`, `hr-mh-contract-labour-clra.md` |
| Maharashtra professional tax | `hr-mh-professional-tax.md` |
Digit tests: `gia-fraud:gia-fraud-analytics`. Payroll recompute and expiry checks: `gia-analytics:gia-payroll-analytics`; rate-freshness check: `python3 -I ${CLAUDE_PLUGIN_ROOT}/skills/gias-navigator/scripts/check_rates.py`.

## Plant statutory-readiness
For a new plant, takeover or customer programme cutover, statutory licences and customer or quality certifications (VDA 6.3, IATF 16949, ISO) are two separate workstreams with separate gates; one never substitutes for the other. Use command `/gia-plant-readiness-tracker`, the workflow and tab pattern in `references/plant-readiness-tracker.md`, and the Maharashtra R12 file for the jurisdiction table (PMC, PCMC, MIDC, outside limits) and tracker skeleton.

## Labour Codes
Treat the four Labour Codes as in force from the date in register row IN-018, with the transition position (old Acts and rules continuing until corresponding rules exist) assessed per audit period. The retired HR skills that said otherwise are superseded.

## Open items
State packs for other states, an India dialysis pack and a site-to-state mapping for each group India entity do not exist; record them as open dependencies when in scope.
