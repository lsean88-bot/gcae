> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- Critical Update — Labour Codes [IN-018]
- EPF Contribution Rates (Current — May 2026)
- ESIC Contribution Rates (Current)
- Remittance Deadlines
- Pune-Specific EPF/ESIC Issues
- Audit Procedures — EPF/ESIC (Pune)
- Red Flags — EPF/ESIC (Pune)


# R03 — EPF, ESIC & Labour Codes Social Security (Pune/Maharashtra)

## Critical Update — Labour Codes [IN-018]

Four Labour Codes notified in Official Gazette: **21 November 2025**.
ESIC implementing notifications: **10-11 December 2025**.
**First affected payroll cycle: December 2025.**

All payroll from December 2025 must comply with the new uniform wages definition.

### New Wages Definition (Code on Social Security 2020)

**Key change:** If a worker's total allowances exceed [IN-017] of total remuneration, the excess is added back to wages for EPF and ESI contribution base.

```
Total remuneration = Basic + DA + All allowances (excluding statutory exclusions)
Permitted allowances cap = [IN-017] of total remuneration
If actual allowances > [IN-017] → Excess = actual allowances - [IN-017] of total remuneration
Revised EPF/ESI wage base = Basic + DA + Excess
```

**Pune impact:** IT companies in Hinjewadi, Baner, Kharadi typically structure salaries with high HRA, Special Allowance, and low Basic to minimize EPF. These structures now face significantly higher contribution bases from Dec 2025.

---

## EPF Contribution Rates (Current — May 2026)

| Component | Rate | Base | Cap | Remitting Party |
|-----------|------|------|-----|----------------|
| Employee EPF | [IN-001] | Basic + DA | No cap | Employee (via employer) |
| Employer EPS | [IN-002] | Basic + DA | Max [IN-002]/mo (wage ceil [IN-006]) | Employer |
| Employer EPF (differential) | [IN-003] | Basic + DA | No cap | Employer |
| EPFO Admin | [IN-004] | Basic + DA | Min [IN-122]/mo per establishment | Employer |
| EDLI | [IN-005] | Basic + DA | Capped at [IN-006] wage | Employer |
| **Total employer cost** | **~[IN-121] + [IN-121]** | | | |

**EPF Interest Rate:** [IN-014] p.a. for FY 2024-25 and FY 2025-26 (CBT Feb 2025).

**Applicability threshold:** ≥20 employees (some notified sectors ≥10).

**Pune MIDC / manufacturing:** Most factories exceed 20-employee threshold — verify establishment-level EPF code.

---

## ESIC Contribution Rates (Current)

| Component | Rate | Base | Ceiling |
|-----------|------|------|---------|
| Employee | [IN-009] | Gross wages | ≤[IN-010]/mo gross |
| Employer | [IN-008] | Gross wages | ≤[IN-010]/mo gross |
| Total | [IN-124] | | |

**Wage ceiling:** >[IN-010]/mo gross = exempt from ESIC.
**Applicability:** Factories and establishments ≥10 employees.
**ESIC hospital network in Pune:** ESIC Pimpri Chinchwad, ESIC Yerawada — employees must be registered at nearest dispensary.

---

## Remittance Deadlines

| Statutory | Due Date | Portal |
|-----------|---------|--------|
| EPF ECR filing + challan | 15th of following month | epfindia.gov.in |
| ESIC ECR filing + challan | 15th of following month | esic.gov.in |

**Penalties:**
- EPF late: Sec 7Q — [IN-123] p.a. interest; Sec 14B — damages up to [IN-007] (wilful default)
- ESIC late: Sec 85B — [IN-125] p.a. interest; Sec 85 — prosecution

---

## Pune-Specific EPF/ESIC Issues

### IT Sector (Hinjewadi, Baner, Kharadi)
- High base salary with large HRA/Special Allowance components — post-Labour Codes, new wages definition recalculates base
- Moonlighting / dual employment risk: EPFO Unified Portal now shows multi-employer UAN linkages — audit check
- Variable pay (quarterly/annual bonuses): Not included in EPF base unless paid monthly and regularly

### Auto Ancillary / Manufacturing (Pimpri-Chinchwad, MIDC)
- Contract workers on CLRA basis: Contractor must have separate EPFO code; principal employer must verify [superseded 21-Nov-2025 — re-map to Code]
- Seasonal workers: EPF applicability — if establishment has 20+ across season = EPF applies
- International workers on deputation: Separate International Worker ECR; verify passport + visa

### Pharma / Engineering (Chakan, Ranjangaon MIDC)
- Shift workers: OT/shift allowance included in ESIC base (gross wages definition)
- Canteen/transport allowances: Post-Labour Codes, if total allowances >[IN-017] gross, excess included in EPF/ESIC base

---

## Audit Procedures — EPF/ESIC (Pune)

1. Download 100% ECR from EPFO and ESIC portals for all months (Rank 1)
2. Cross-match ECR headcount to HRMS payroll headcount — gaps = ghost employee or exclusion risk
3. Recompute EPF: Employee [IN-001] + Employer [IN-120] ([IN-002] EPS + [IN-003] EPF) + [IN-004] admin + [IN-005] EDLI — 100% population
4. **Post-Nov 2025 periods:** Apply Labour Codes wages test — for each employee, check if allowances > [IN-017] of gross → recalculate contribution base
5. Verify Form 11 for all employees with wages >[IN-016]/mo — opt-in or exemption documented
6. ESIC: Identify all employees with gross ≤[IN-010]/mo → verify registered as Insured Persons
7. Test for mid-year wage crossers ([IN-010] ESIC threshold) — ESIC contribution stops at end of contribution period, not immediately
8. Verify challan deposit by 15th of month
9. For contractors: Obtain EPFO/ESIC acknowledgement receipts — Rank 1 that contributions actually remitted
10. Dual employment (moonlighting) check: Download UAN-linked employer list for sample employees — multiple active employers flagged

---

## Red Flags — EPF/ESIC (Pune)

- Post-Dec 2025 payroll still using pre-Labour Codes salary structure without updating EPF/ESIC base
- Pune IT company: Allowances consistently >[IN-017] gross across all employees (most likely Labour Codes issue)
- ESIC contributions continuing after employee crossed [IN-010] gross
- No Form 11 for high-wage employees (>[IN-016] Basic+DA)
- Contractor billing EPF/ESIC reimbursement without EPFO/ESIC challan copies (collecting but not remitting)
- ECR headcount > actual headcount (ghost employees on contractor roll)
- Pimpri-Chinchwad/MIDC factory: Contract labour EPFO code missing or no sub-code for contractor
- UAN seeding mismatch — EPFO database Aadhaar vs HR records Aadhaar
