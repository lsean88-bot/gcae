> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- Overview — Pune's Cross-Border Profile
- FDI — Foreign Direct Investment (Pune Entities)
- ECB — External Commercial Borrowings (Pune Manufacturers)
- Software / Service Exports (Pune IT Sector)
- Import Compliance (Pune Manufacturing)
- Expat / NRI Employees in Pune
- Sec 269ST — Cash Receipt Prohibition (Pune)
- FEMA / RBI Audit Procedures (Pune)
- Red Flags — FEMA / RBI (Pune)


# R08 — FEMA 1999, RBI & Cross-Border Transactions (Pune)

## Overview — Pune's Cross-Border Profile

Pune has significant cross-border exposure across multiple sectors:
- **IT/ITeS (Hinjewadi, Baner, Kharadi):** Software/service exports; STPI/SEZ units; foreign parent companies
- **Auto OEM/Ancillary (Pimpri-Chinchwad, Chakan, Talegaon):** Import of components; export of parts; Japanese/German OEM royalties
- **Pharma/Biotech:** API export; technology transfer fees; CRO payments
- **FDI recipients:** Many Pune companies have foreign investors — FC-GPR compliance critical
- **GCCs (Global Capability Centers):** Increasing presence in Pune — cross-border intra-group transactions

**Regulator:** RBI via Authorized Dealer (AD) Category I banks (Axis/HDFC/ICICI/SBI branches in Pune).

---

## FDI — Foreign Direct Investment (Pune Entities)

### Automatic Route (Most common for Pune IT/manufacturing)
- IT, software, manufacturing, auto, pharma — automatic up to specified caps
- **Reporting mandatory — no excuses:**

| Event | Form | Due Date | Portal |
|-------|------|---------|--------|
| FDI received (equity allotment) | FC-GPR | Within 30 days of allotment | FIRMS (RBI — firms.rbi.org.in) |
| Transfer of shares (FDI) | FC-TRS | Within 60 days of transaction | FIRMS |
| Annual FDI/ODI stock | FLA Return | **15 July** every year | FIRMS (FLAIR module) |
| ODI (investment abroad) | Form ODI | Before/within 60 days (auto route) | FIRMS |

### Common Pune Scenario: GCC Setup
- Foreign company sets up a wholly-owned subsidiary in Pune as GCC (100% FDI, automatic)
- FC-GPR required within 30 days of each equity allotment
- If Pune GCC receives loans from foreign parent → ECB route (Form ECB required)
- FLA Return: Due every 15 July even if no new FDI in the year (annual stock reporting)

---

## ECB — External Commercial Borrowings (Pune Manufacturers)

Common for Pune auto ancillary / manufacturing capex funding:

### Track I (Minimum 3-year average maturity)
- Manufacturing, infrastructure — most common Pune use case
- All-in cost ceiling: Per RBI Master Direction (changes — web-verify before use)
- End-use: Capex allowed; NOT for real estate, equity investment, working capital beyond limits

### Key ECB Compliance
| Obligation | Due Date | Portal |
|-----------|---------|--------|
| Form ECB (loan agreement registration) | Before drawdown | FIRMS via AD bank |
| Form ECB-2 (monthly reporting) | Last business day of following month | FIRMS via AD bank |
| ECB-2 with nil reporting | Mandatory even if no transactions | FIRMS |

---

## Software / Service Exports (Pune IT Sector)

### FEMA Repatriation
- All export proceeds: Repatriated within **9 months** of export date
- AD bank monitoring: Bank will track repatriation; delays trigger RBI query
- FIRC (Foreign Inward Remittance Certificate): Obtain from AD bank for each inward remittance → match to debtors ledger

### SOFTEX Form (STPI / SEZ Units in Hinjewadi/Pune)
- Mandatory for software exports (all forms — on-site, off-site, electronic)
- Single transaction > USD 25,000: Separate SOFTEX filed with STPI Pune / SEZ authority
- Aggregate ≤USD 25,000/transaction: Monthly aggregation permitted
- STPI Pune address: Software Technology Parks of India, EON IT Park, Pune

### Export Benefits (Pune IT Exporters)
| Benefit | Eligibility | Governing Body |
|---------|-----------|----------------|
| IGST exemption (zero-rated exports) | All exporters; LUT/Bond (Form RFD-11) required | GST Dept |
| SEIS (Services Export from India Scheme) | Verify current DGFT notification; SEIS status post-FTP 2023 | DGFT Pune |
| STPI Unit benefits | STPI-registered units: Duty-free hardware import | STPI Pune |
| SEZ benefits | SEZ-registered units: Duty-free procurement; IT Act exemption | SEZ Pune |
| IT Act 2025 export exemption | Verify Sec 10AA equivalent in IT Act 2025 for SEZ units | incometax.gov.in |

---

## Import Compliance (Pune Manufacturing)

- AD bank authorization for import payments above thresholds
- Import documentation: Commercial invoice, packing list, BL/AWB, Bill of Entry (BE)
- **Advance payment for imports:** Up to USD 2,50,000 without additional documentation; above = CA certificate or AD bank-specific condition
- **Buyer's credit / Letter of Credit:** FEMA Sec 10 — permitted per RBI norms
- **Royalty payments:** Technology transfer fee / royalty to foreign parent — RBI Master Direction on overseas investments (verify current circular)

### Pune Auto Ancillary — Royalty/Tech Fees to Japan/Germany
- Common: Pune auto parts manufacturer paying royalties to Japanese/German OEM licensor
- FEMA: Automatic route up to limits under RBI Master Direction on tech transfers
- TDS: Sec 195 IT Act 1961 (equiv IT Act 2025) — [IN-072] (or DTAA rate with Japan/Germany, whichever lower; DTAA certificate required)
- GST: Import of service → IGST under RCM ([IN-098] — recipient pays)

---

## Expat / NRI Employees in Pune

| Aspect | Requirement |
|--------|-------------|
| Work visa | Employment Visa — Ministry of Home Affairs |
| Tax residency | Number of days in India — IT Act 2025 test |
| TDS on salary | Sec 192 IT Act 2025 — employer deducts; DTAA relief only with Form 10F + TRC |
| FEMA — expat remittances | Current account transaction — permitted via AD bank |
| ESIC | International workers at standard rates if within ESIC-notified region |
| EPF | International Worker ECR required at EPFO; benefits available |
| Shadow payroll | If dual employment (home country + India) — Indian payroll required |

---

## Sec 269ST — Cash Receipt Prohibition (Pune)

- No person shall receive ≥[IN-087] in cash from any single person in a day, in a single transaction, or multiple transactions relating to one event/occasion
- **Penalty:** 100% of amount received
- Common risk: Pune real estate, retail, wedding venues, event management companies

---

## FEMA / RBI Audit Procedures (Pune)

1. **For IT/service companies:** Verify FIRC for each foreign receipt → match to debtors ledger → test repatriation within 9 months
2. **SOFTEX submissions:** Verify monthly STPI Pune filing; match to HRMS billing records
3. **FLA Return:** Verify filed by 15 July; cross-check with audited FY financials
4. **FDI-received companies:** Verify FC-GPR within 30 days of each equity allotment
5. **ECB:** Verify Form ECB-2 filed monthly; verify end-use compliance (capex vs. working capital)
6. **Royalty/tech fees:** Verify FEMA compliance + Sec 195 TDS + DTAA documentation (Form 10F + TRC)
7. **Expat employees:** Verify Employment Visa; DTAA relief; shadow payroll if applicable
8. **Sec 269ST:** Review cash receipts register — any single-day receipt ≥[IN-087] from one person

---

## Red Flags — FEMA / RBI (Pune)

- Foreign remittances from Pune IT clients not matched to FIRC (possible unrecorded income)
- SOFTEX not filed or filed late for STPI Pune-registered unit
- FLA Return not filed (compounding required; common for Pune GCCs and startups)
- ECB proceeds deployed in working capital beyond permitted limits (common in cash-tight Pune manufacturing)
- Royalty paid to foreign parent without RBI compliance / Section 195 TDS
- Round-tripping: FDI origin traceable to Indian resident (FEMA Sec 3 violation)
- Import advance payment >USD 2,50,000 without CA certificate
- Cash receipts from Pune customers ≥[IN-087] (Sec 269ST — 100% penalty risk)
- Expired/lapsed STPI registration with continued benefits claim
