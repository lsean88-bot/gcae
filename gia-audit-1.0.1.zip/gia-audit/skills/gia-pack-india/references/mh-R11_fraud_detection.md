> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- ACFE Fraud Tree — Pune Business Context
- Benford's Law Application (Pune)
- Ghost Employee Detection — Pune
- Pune-Specific Fraud Scenarios (High Incidence)
- Fraud Risk Assessment Matrix
- PMLA 2002 / AML (Pune)
- Audit Procedures — Fraud Detection (Pune)
- Red Flags — Consolidated (Pune)


# R11 — Fraud Detection, ACFE & Analytics (Pune)

## ACFE Fraud Tree — Pune Business Context

### Asset Misappropriation ([see ACFE benchmark in gia-fraud] of cases globally; highest frequency in Pune)

#### Cash Schemes
| Scheme | Pune-Specific Red Flags | Test |
|--------|------------------------|------|
| Skimming (cash before recording) | Pune retail/event companies; AR > Collections | Sec 269ST cash test; GSTR-1 vs. actual cash |
| Larceny (cash after recording) | Petty cash shortages at MIDC site offices | Surprise count; bank statement vs. books |
| Ghost employees — payroll | EPFO ECR headcount < payroll headcount | Cross-match payroll to EPFO member portal |
| Ghost employees — contract workers | Contractor bills for workers not deployed | Biometric/gate access vs. contractor muster roll |
| Payroll rate inflation | Salary increase without approved letter | Authorized salary master vs. payroll run |
| Expense reimbursement fraud | Inflated travel/entertainment claims (Pune-Mumbai route) | Receipt quality; duplicate claim test |
| Cheque/RTGS tampering | Beneficiary changed; vendor master altered | Vendor master change log; bank debit vs. invoice |

#### Non-Cash Schemes
| Scheme | Pune-Specific Red Flags | Test |
|--------|------------------------|------|
| Inventory theft | High scrap variance at MIDC factories; BOM yield gaps | Cycle count; scrap register vs. GST invoices |
| MIDC raw material diversion | RM received but not entered in ERP; BOM understated | GRN vs. purchase order vs. production records |
| IP/data theft | Hinjewadi IT employees downloading code/data before exit | IT access logs; DLP alerts; exit checklist |
| Company vehicle misuse | Fleet vehicles used for personal trips at Chakan/Talegaon factories | GPS log vs. logbook; fuel card analysis |

---

### Corruption (Most Damaging — Pune Industry Context)

| Scheme | Pune-Specific Red Flags | Test |
|--------|------------------------|------|
| Vendor kickbacks — procurement | MIDC raw material single-source; price above market | Tendering records; price benchmark vs. market |
| Bid rigging — MIDC construction | Identical losing bids; contractor known before tender | Tender timeline; bid submission IP addresses |
| MPCB/PMC facilitation payments | Cash withdrawals before MPCB/PMC inspection | Expense report + cash withdrawal patterns |
| Related party vendor | Procurement employee owns/is related to vendor | Vendor ownership vs. employee/director database |
| Conflicts of interest — Pune IT | Employee moonlighting for competitor; undisclosed | COI declaration register; LinkedIn audit |
| Mathadi Board levy diversion | Levy deducted but not remitted to Mathadi Board | Mathadi challan vs. payroll deduction |

---

### Financial Statement Fraud (Pune Industries)

| Scheme | Pune-Specific Flags | Test |
|--------|-------------------|------|
| Revenue inflation | Fictitious IT export invoices; round-trip billing via GCC | Customer confirmation; FIRC vs. debtors ledger |
| Expense suppression | Accruals not made at month-end to show profit | Completeness test; post-period vendor invoices |
| Inventory overstatement | MIDC finished goods overstated; scrap understated | Physical verification; BOM yield analysis |
| Related party concealment | Pune group company transactions not disclosed | Sec 188 register; Ind AS 24 notes; auditor RPT inquiry |
| MIDC scrap income suppression | Scrap sold for cash without GST invoice | Scrap weight records vs. GST scrap invoices |

---

## Benford's Law Application (Pune)

### When to Apply
- All vendor invoice amounts (100% population preferred)
- Expense reimbursements (common in IT/consulting Pune)
- Payroll amounts per employee
- JE posting amounts
- Cash transaction amounts

### Method
Benford and digit tests: run through `gia-fraud:gia-fraud-analytics` (Nigrini MAD primary with per-digit z-scores; chi-square supplementary for small populations). Confirm the preconditions, segment fixed-amount populations first, and record the MAD table version in the workpaper. A deviation is an indicator, never a conclusion. Inline thresholds from the retired source were removed.

### Pune-Specific Threshold Clustering Tests
| Threshold | Risk | Pune Context |
|-----------|------|-------------|
| Just below [IN-024] | Sec 194C TDS threshold avoidance | MIDC contractor invoices |
| Just below [IN-024] | Annual TDS aggregate threshold | Annual maintenance contracts |
| Just below [IN-028] | Cash payment limit | Petty cash vouchers |
| Just below [IN-087] | Sec 269ST cash receipt limit | Pune events/retail |
| Just below [IN-105] | eWay bill threshold | MIDC goods movement |

---

## Ghost Employee Detection — Pune

1. **Payroll vs. EPF ECR:** Every employee in payroll must appear in EPFO ECR. Exceptions documented (Form 11, ceiling opt-out).
2. **Unique identifiers:** Every employee: unique valid PAN (incometax.gov.in), Aadhaar-seeded UAN (EPFO member portal), unique bank account.
3. **Biometric/access match:** Payroll list vs. biometric attendance. Pune IT companies typically have Aadhaar-linked biometrics — cross-check.
4. **Ghost contractor workers:** Contractor bill worker count vs. site biometric/gate entry register. Factory sites in Pimpri-Chinchwad/Chakan often have electronic gate systems.
5. **Duplicate detection:** Same PAN / same bank account / same mobile / same Aadhaar for two employee IDs.
6. **Post-exit test:** All terminated employees — verify no salary credit after exit date. Pune IT: High attrition — common risk.
7. **Moonlighting detection (Pune IT):** Check EPFO UAN-linked employer list for multiple active employers. Multiple EPF ECR contributions from different employers to same UAN = dual employment.

---

## Pune-Specific Fraud Scenarios (High Incidence)

### MIDC Factory Scrap Diversion
- **Scheme:** Scrap metal (steel, aluminum, copper) sold for cash at Pimpri-Chinchwad / Talegaon MIDC without GST invoice
- **Impact:** Income suppression; GST default; raw material cost inflation (BOM variance)
- **Test:** Scrap weight register (Form 26 Factories Act) vs. scrap GST invoices vs. scrap purchaser's GSTR-2B (they should show purchase from factory) [superseded 21-Nov-2025 — re-map to Code]

### Pune IT Moonlighting / Dual Employment
- **Scheme:** IT employee working for second employer during notice period or simultaneously
- **Impact:** IP theft; conflict of interest; payroll fraud
- **Test:** EPFO UAN multiple-employer check; ESIC registration cross-check; laptop usage logs

### MPCB/PMC Grease Payments
- **Scheme:** Cash paid to MPCB inspectors or PMC officials for consents/NOCs without actual compliance
- **Impact:** Bribery under Prevention of Corruption Act 1988; FCPA risk for foreign-owned entities
- **Test:** Cash withdrawals before/after regulatory visits; expense report "miscellaneous" items

### Mathadi Levy Non-Remittance
- **Scheme:** Employer deducts Mathadi levy from applicable workers/contractors but does not remit to Maharashtra Mathadi Board
- **Impact:** Trust receipt fraud; Mathadi Board penalty
- **Test:** Mathadi Board challan vs. deduction register

---

## Fraud Risk Assessment Matrix

| Risk Factor | Weight | Score (1–5) | Weighted Score |
|-------------|--------|-------------|---------------|
| Cash handling volume | [set in engagement risk model] | — | — |
| Related party complexity (Pune group) | [set in engagement risk model] | — | — |
| Management override opportunity | [set in engagement risk model] | — | — |
| Incentive/pressure (revenue targets, bonus) | [set in engagement risk model] | — | — |
| Control environment maturity | [set in engagement risk model] | — | — |
| Prior fraud incidents | [set in engagement risk model] | — | — |
| **Total** | **100%** | | |

Score >3.5 = High fraud risk → expand testing scope; consider forensic specialist (CFE).

---

## PMLA 2002 / AML (Pune)

- Banks file CTR (Cash Transaction Report) for >[IN-090]/day per account
- STR (Suspicious Transaction Report) for unusual patterns — multiple round amounts, structuring
- **Pune real estate:** High cash transaction risk — PMLA-designated sector
- **Structuring risk:** Multiple cash deposits just below [IN-090] threshold from same source
- Round-trip: Pune entity pays foreign subsidiary → foreign subsidiary pays back as export proceeds (layer)

---

## Audit Procedures — Fraud Detection (Pune)

1. Benford's Law on all vendor invoices + payroll + cash vouchers + JEs
2. Threshold clustering: Count transactions ±[band set in engagement plan] of [IN-028] / [IN-024] / [IN-024] / [IN-087] / [IN-105]
3. Ghost employee: Cross-match payroll vs. EPFO ECR + biometric + PAN validation
4. Moonlighting (IT): EPFO UAN multiple-employer check for all IT employees
5. Vendor conflict of interest: Cross-match vendor ownership/director against HR employee database + director register
6. Scrap diversion (manufacturing): Scrap weight register vs. GST scrap invoices vs. bank receipts from scrap dealers
7. Surprise petty cash count (unannounced)
8. Cash receipt test: Sec 269ST — any cash receipt ≥[IN-087] from any single person
9. JE fraud analysis: Round number, unusual accounts, weekend/holiday, description "correction/adjustment", same ID preparer and approver
10. Mathadi levy: Deduction register vs. Mathadi Board challan copies
11. MPCB/PMC payment review: All payments to government agencies → legitimate challan receipts only

---

## Red Flags — Consolidated (Pune)

- Employee lifestyle inconsistent with salary (common in Pune IT bonus culture)
- Procurement manager at MIDC factory repeatedly awarding to same vendor without tender
- Scrap income consistently low relative to production volume / scrap rate benchmarks
- IT employee's EPFO UAN shows contribution from multiple employers simultaneously
- Cash withdrawals from company account just before MPCB/PMC inspection dates
- Vendor director/owner name matching an employee's family member (Pune startup ecosystem risk)
- Round-trip IT billing: Pune company invoices foreign parent → same amount received back as "loan"
- Mathadi Board not registered despite employing construction/headload workers in Pune
- Ghost contract workers — contractor bills for 50 workers but gate entry shows only 30
- Manager approving and paying own expense reimbursements without second-level review
