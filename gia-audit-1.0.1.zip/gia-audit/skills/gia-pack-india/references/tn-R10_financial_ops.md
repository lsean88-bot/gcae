> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- Accounts Payable (AP) Controls
- Accounts Receivable (AR) Controls
- Bank & Treasury Controls
- Journal Entry Controls (IFC-Critical)
- Financial Close & Reporting Controls
- Expense Controls — Key Policy Areas
- Audit Procedures — Financial Operations
- Red Flags — Financial Operations


# R10 — Financial Operations & Internal Controls

## Accounts Payable (AP) Controls

### Procure-to-Pay Process Controls

| Stage | Control | Test |
|-------|---------|------|
| Purchase Requisition | Authorised by budget owner; within budget | Sample PRs — verify approvals |
| Purchase Order | Raised only post-PR approval; price in vendor master | PO vs. PR match; price test |
| Goods/Service Receipt | GRN signed by receiver; quantity/quality verified | GRN vs. PO match |
| Invoice Receipt | Logged same day received; stamp with receipt date | Invoice log completeness |
| Three-way Match | PO + GRN + Invoice before payment approval | System auto-match or manual checklist |
| Payment Approval | Dual authorization: Finance Manager + CFO/Director (above threshold) | Verify payment approval matrix |
| Payment Execution | RTGS/NEFT only; no cash >[IN-028]/day per person (IT Act 2025) | Bank statement — cash payments |
| Vendor Reconciliation | Statement reconciled quarterly | Reconciliation file vs. vendor statement |

### Critical IT Act 2025 Cash Payment Restriction
- Cash payment to a single person in a single day: Maximum [IN-028] (IT Act 2025 equivalent of Sec 40A(3) IT Act 1961)
- Violation: Entire cash payment DISALLOWED as business expense
- Exception: Payments to banks, government, certain categories
- Test: Review all cash vouchers >[IN-028] — any single-day, single-payee payments

---

## Accounts Receivable (AR) Controls

| Control | Detail | Test |
|---------|--------|------|
| Credit limit approval | New customer: credit limit authorized by CFO | Sample new customers vs. approval |
| Invoice generation | Only on service delivery / shipment; not pre-invoiced | Invoice date vs. delivery date |
| Ageing review | Monthly — AR ageing reviewed by Finance + Sales | Review minutes/email trail |
| Collection follow-up | Escalation at 30/60/90 days | Dunning letters / call logs |
| Disputed invoices | Separately tracked; not written off without approval | Check for disputed items in ageing |
| Write-off authorization | Bad debt write-off: CFO + MD/Board approval; IT Act compliance for deduction | Write-off register |
| Export AR (FEMA) | Repatriation within 9 months of export — see R08 | FIRC matching |
| GST credit note | Issued correctly on returns; reflected in GSTR-1 | GSTR-1 vs. books credit notes |

---

## Bank & Treasury Controls

### Bank Reconciliation
- Prepared monthly for every bank account
- Prepared by accounts team; reviewed and approved by Finance Manager
- Outstanding items >30 days must be explained individually
- Reconciling items: Unpresented cheques, deposits in transit, bank charges, bank errors

### Bank Authorization Matrix (Minimum best practice)

| Amount | Approver 1 | Approver 2 | Channel |
|--------|-----------|-----------|---------|
| Up to [entity DoA tier] | Accounts Manager | — | NEFT (single) |
| [entity DoA tier] – [entity DoA tier] | Finance Manager | — | NEFT/RTGS |
| [entity DoA tier] – [entity DoA tier] | Finance Manager | CFO | RTGS |
| Above [entity DoA tier] | CFO | MD/Director | RTGS + Board note |

### Cash Controls
- Petty cash: Maximum float [entity policy]–[entity policy] depending on establishment
- Imprest system: Replenished on vouchers; counted weekly; surprise counts quarterly
- No salary or vendor payment in cash (legal restriction + control risk)
- Daily cash closing: Physical count vs. book balance; signed by custodian + supervisor

---

## Journal Entry Controls (IFC-Critical)

| Control | Detail |
|---------|--------|
| Authorization | All manual JEs: Preparer + Approver — no self-approval |
| Supporting documentation | Every JE must have a business reason + supporting document |
| Period-end JEs | All JEs after period close: Finance Head approval; audited list maintained |
| Reversals | Auto-reversing entries for accruals; manual reversals need special approval |
| Access control | Only authorized personnel can post JEs in ERP (IT General Control) |
| High-risk JE testing | Round numbers, unusual accounts (personal a/c, suspense), non-business-hours postings |

---

## Financial Close & Reporting Controls

### Month-End Close Checklist
- [ ] All bank accounts reconciled
- [ ] All vendor invoices for the month received, matched, and accrued
- [ ] Payroll correctly posted; EPF/ESIC/TDS payables created
- [ ] GST ITC reconciled against GSTR-2B
- [ ] Depreciation computed per Schedule II Companies Act 2013
- [ ] Provisions reviewed: Gratuity (Ind AS 19 actuarial), bonus, leave encashment
- [ ] Intercompany balances confirmed and reconciled
- [ ] Deferred tax computed (Ind AS 12)
- [ ] Revenue recognized per Ind AS 115 (percentage completion / milestone / point of transfer)

### Ind AS Key Standards (Chennai Corporate Entities)

| Standard | Area | Key Consideration |
|---------|------|-----------------|
| Ind AS 115 | Revenue | Right to invoice; variable consideration; performance obligations |
| Ind AS 116 | Leases | Operating leases now on-balance-sheet; ROU asset + lease liability |
| Ind AS 19 | Employee benefits | Actuarial valuation for gratuity and leave encashment; annual |
| Ind AS 12 | Deferred Tax | DTL/DTA on all timing differences |
| Ind AS 36 | Impairment | Annual test for goodwill, fixed assets; indicators-based test for others |
| Ind AS 2 | Inventories | Lower of cost or NRV; FIFO/WA (not LIFO) |
| Ind AS 103 | Business combinations | M&A — purchase price allocation |

---

## Expense Controls — Key Policy Areas

| Area | Control | IT Act / Companies Act Reference |
|------|---------|--------------------------------|
| Entertainment | CEO/MD approval for client entertainment; reasonable amount per person | IT Act 2025 — business expenditure test |
| Travel | Pre-approval; actuals + receipts; no cash advance >[IN-028] | IT Act cash limit |
| Director remuneration | Board + shareholder approval; Sec 197 Companies Act 2013 — max [IN-118] net profit | Companies Act 2013 Sec 197 |
| CSR expenditure | CSR committee approval; Schedule VII projects; not treated as business expense | Companies Act 2013 Sec 135 |
| Related party | Arm's length test; Sec 188 approval | Companies Act 2013 |
| Capital vs. revenue | Capitalize per Ind AS 16 (useful life >1 year, cost reliably measurable, future benefit) | Ind AS 16; IT Act depreciation |

---

## Audit Procedures — Financial Operations

1. Test bank reconciliations: 100% of accounts × all months — unreconciled items >30 days = finding
2. Cash payments test: Extract all cash vouchers; flag any single-day/single-payee payment >[IN-028]
3. Journal entry analysis: Extract all JEs; test for: (a) high-value round numbers, (b) unusual accounts, (c) weekend/holiday postings, (d) same preparer and approver
4. Three-way match test: Sample 25 invoices per AP category → verify PO + GRN + Invoice
5. Vendor payment test: Verify dual-authorization on all payments above threshold
6. GRN date vs. invoice date vs. payment date: Test for pre-payment (payment before receipt) and late accrual
7. Bank authorization: Verify payment amounts match authorization levels; no bypassed approvals
8. Petty cash count: Surprise count + reconciliation to imprest book
9. Credit note/write-off: Verify all write-offs have CFO/Board approval + IT Act bad debt deduction compliance
10. Month-end accruals: Test completeness — are all known liabilities (vendor invoices, salary, statutory dues) accrued at month end?

---

## Red Flags — Financial Operations

- Bank reconciliation not prepared or stale (>30 days outstanding items)
- Large JE postings on last day of month or first day of next (period-cut manipulation)
- Round-number JEs with no supporting document in unusual accounts
- Vendor payments without three-way match documentation
- Cash payments to vendors or employees >[IN-028]/day
- Same person as preparer and approver of JEs or payments
- Negative vendor balance in AP (advance without PO or over-payment not recovered)
- Multiple invoices from same vendor on same day (split billing)
- Credit to "Other Income" or "Miscellaneous" without clear business rationale
- Intercompany balances unreconciled for >3 months (related party manipulation risk)
