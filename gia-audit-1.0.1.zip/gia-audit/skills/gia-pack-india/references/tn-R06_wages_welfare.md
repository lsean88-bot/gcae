> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- TN Minimum Wages (Current — April 2026)
- Tamil Nadu Professional Tax Act 1992
- Tamil Nadu Labour Welfare Fund (LWF) Act 1972
- Payment of Bonus Act 1965 [superseded 21-Nov-2025 — re-map to Code]
- Payment of Gratuity Act 1972 [superseded 21-Nov-2025 — re-map to Code]
- Payment of Wages Act 1936 (as applicable) [superseded 21-Nov-2025 — re-map to Code]
- Audit Procedures — Wages & Welfare
- Red Flags — Wages & Welfare


# R06 — Wages, Welfare & Statutory Benefits: TN

## TN Minimum Wages (Current — April 2026)

**Notification:** TN Labour Dept Gazette, Notification No. Z3/3459/2026 — [IN-037].
**DA Base:** 183 points above CPI index 161 (base year 2001=100) × [IN-037]/point = [IN-037] DA/month.

### Zone Classification (Chennai)
| Zone | Areas Included |
|------|---------------|
| Zone A | All Corporations + Special Grade Municipalities — **Chennai falls here** |
| Zone B | Municipalities (other than special grade) |
| Zone C | Town Panchayats |
| Zone D | All other areas (rural) |

### TN Min Wages — Shops & Commercial Establishments (Zone A, Apr 2026)
| Category | Approx Monthly (Basic + DA) |
|----------|---------------------------|
| Unskilled | ~[IN-037]+ (web-verify from gazette) |
| Semi-skilled | Higher — verify gazette |
| Skilled | Higher — verify gazette |
| Highly skilled | ~[IN-037]+ (web-verify from gazette) |

**DA revision:** Every April 1, based on average CPI Jan-Dec of prior year. Next revision: April 2027.

> **Audit rule:** Always download the official TN Labour Dept gazette notification for the specific industry and zone. Min wages vary by: (a) industry/scheduled employment category, (b) skill level, (c) zone. Never use generic estimates in findings.

---

## Tamil Nadu Professional Tax Act 1992

### Employer Obligations
| Obligation | Rate/Detail | Due Date | Form |
|-----------|-------------|---------|------|
| PT Registration (Employer) | Mandatory for all employers in TN | Before first salary | Online — TN CT portal |
| PT on employees (deduction + remittance) | Per slab (see below) | Monthly or half-yearly (depending on category) | PT challan |
| Employer PT | [IN-137] p.a. flat | Half-yearly (Sep + Mar) | — |

### PT Slab — Individuals (Effective Apr 2024 — Chennai Municipal Corporation)
| Monthly Gross Salary | PT per Half-Year |
|---------------------|-----------------|
| Up to [IN-136] | Nil |
| [IN-136] to [IN-136] | [IN-136] |
| [IN-136] to [IN-136] | [IN-136] |
| [IN-136] to [IN-136] | [IN-136] |
| [IN-136] to [IN-136] | [IN-136] |
| Above [IN-136] | [IN-136] |

> **Max per year:** [IN-038] ([IN-136] × 2 half-years).
> **Note:** PT slab was revised effective April 2024 (Chennai Corporation). Verify for applicable assessment year.

### PT Audit Procedures
1. Extract payroll register — compute expected PT per employee per half-year based on monthly gross
2. Reconcile against PT deducted in payroll register
3. Verify PT challans deposited — cross-check TN CT portal
4. Confirm employer PT ([IN-137] p.a.) paid separately
5. Ensure PT deducted even from exempted employees who had PT deducted incorrectly — verify refund process

---

## Tamil Nadu Labour Welfare Fund (LWF) Act 1972

| Component | Rate | Payable By | Due Date |
|-----------|------|-----------|---------|
| Employee contribution | [IN-039] per half-year | Employee (employer deducts) | Jan 31 and Jul 31 |
| Employer contribution | [IN-040] per half-year | Employer | Jan 31 and Jul 31 |
| Total per employee | [IN-039, IN-040] per half-year | — | — |

**Applicability:** Establishments with ≥ 5 employees in Tamil Nadu.
**Exemption:** Employees earning >[IN-138]/month are excluded — verify latest TN LWF notification.
**Remittance:** Tamil Nadu Labour Welfare Board, Chennai.
**Return:** Annual Form A — by April 30.
**Penalty:** Sec 15 — fine up to [IN-139] per default.

---

## Payment of Bonus Act 1965

### Eligibility
- Employees with salary ≤ [IN-057]/month
- Completed 30 working days in the accounting year
- Applicable to: Factories + establishments ≥ 20 employees (or >10 in some notified states)

### Calculation
| Component | Details |
|-----------|---------|
| Minimum bonus | [IN-055] of annual earnings (or [IN-055] whichever is higher) |
| Maximum bonus | [IN-056] of annual earnings |
| Computation salary ceiling | [IN-055]/month or minimum wage (whichever is higher) |
| Allocable surplus | [IN-126] of available surplus (companies); [IN-126] (banking) |
| Set-on / Set-off | Carried over up to 4 years |

### Key Forms & Deadlines
| Form | Purpose | Due Date |
|------|---------|---------|
| Form A | Computation of allocable surplus | Annual — by Nov 30 (8 months from FY end) |
| Form B | Set-on and set-off | Annual |
| Form C | Bonus paid | Annual |
| Form D | Annual return | By Nov 30 |

**Payment deadline:** Within 8 months of FY close (by November 30 for March year-end).
**Penalty:** Sec 28 — imprisonment up to 6 months + fine [IN-127].

---

## Payment of Gratuity Act 1972

### Eligibility
- Minimum 5 years continuous service (4 years + 240 days in 5th year accepted by courts)
- Payable on: Superannuation, resignation, retirement, death, disablement

### Formula
```
Gratuity = (Last drawn salary × 15) / 26 × Number of completed years of service
```
- "Last drawn salary" = Basic + DA
- 15 days per completed year (26 working days/month basis)
- Each period of 6 months or more = 1 year for rounding
- **Ceiling: [IN-058]** (verify latest amendment — may have been revised)

### Nomination
- Employee must file nomination (Form F) within 30 days of joining
- Update on change of family status

### Payment Timeline
- Employer must pay within 30 days of becoming payable
- Interest @ [IN-128] p.a. beyond 30 days (unless delay due to employee's fault)

### Gratuity Fund / Insurance
- Approved gratuity trust: Investments per IRDA norms
- LIC group gratuity scheme: Common for SMEs
- AS 15 / Ind AS 19: Actuarial valuation required in financial statements

### Gratuity Audit Procedures
1. Extract full employee register with date of joining and date of exit for all exits in period
2. Compute expected gratuity per Formula above — 100% of exits with ≥5 years service
3. Reconcile to gratuity paid / liability booked
4. Verify payment within 30 days — late payment = interest payable
5. Verify Gratuity Act Trust registration (if applicable) — valid trust deed
6. Verify Ind AS 19 actuarial valuation used for financial statement provisioning

---

## Payment of Wages Act 1936 (as applicable)

| Provision | Requirement |
|-----------|------------|
| Wage period | Monthly (employees earning <[IN-129]/mo, unless higher by agreement) |
| Payment deadline | By 7th of following month (≤1,000 employees); 10th (>1,000) |
| Deductions allowed | PF, ESI, PT, Income Tax, advance recovery, fine (limited), union dues |
| Unauthorised deductions | Prohibited — cannot deduct for uniform, tools, damage without inquiry |
| Pay slip | Mandatory |

---

## Audit Procedures — Wages & Welfare

1. **TN Min Wages:** Extract per-worker wage from each contractor bill / payroll → compare to applicable TN notification (industry + zone + skill) — shortfall = statutory violation
2. **PT:** Recompute expected PT on 100% payroll using TN slab → reconcile to payroll deduction and challan
3. **LWF:** Verify [IN-039] deducted from eligible employees × 2 (half-years); [IN-040] employer contribution × 2; remittance Jan 31 + Jul 31; annual Form A by Apr 30
4. **Bonus:** Verify allocable surplus computation (P&L); minimum [IN-055] paid by Nov 30; Forms A/B/C/D filed; employees ≤[IN-057] included
5. **Gratuity:** 100% computation of all exits ≥5 years; 30-day payment test; Ind AS 19 provision review

---

## Red Flags — Wages & Welfare

- Contractor bills show per-worker wage below TN min wage gazette rate for the applicable category and zone
- PT deducted but TN CT portal shows no remittance (trust receipt fraud)
- LWF not deducted for employees clearly within applicability range
- Bonus not paid for eligible employees (most common for contract workers via contractor)
- Gratuity not paid or under-calculated (using 30-day month instead of 26-day formula)
- Gratuity forfeiture claimed without DLC order / proper misconduct inquiry
- Bonus computation using flat salary instead of minimum wage where minimum wage is higher than [IN-055]
