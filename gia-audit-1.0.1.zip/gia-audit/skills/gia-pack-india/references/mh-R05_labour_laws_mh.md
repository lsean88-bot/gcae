> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- Critical Update — Maharashtra S&E Act Amendment Ordinance 2025
- Applicable Acts — Priority Hierarchy (Pune/Maharashtra)
- MH S&E Act 2017 (Post-Oct 2025 Amendment)
- Factories Act 1948 — Maharashtra Factories Rules 1963 (Pune) [superseded 21-Nov-2025 — re-map to Code]
- CLRA 1970 — Contract Labour (Maharashtra) (Pune) [superseded 21-Nov-2025 — re-map to Code]
- Maternity Benefit Act 1961 (Amendment 2017) [superseded 21-Nov-2025 — re-map to Code]
- Standing Orders (Pune Manufacturing)
- Audit Procedures — Labour Laws (Pune)
- Red Flags — Labour Laws (Pune)


# R05 — Labour Laws: Maharashtra & Central (2026)

## Critical Update — Maharashtra S&E Act Amendment Ordinance 2025

**Governor's assent and promulgation: 1 October 2025**
**Effective: 1 October 2025**
*(Will remain in force until Maharashtra Legislature passes a permanent amendment)*

### Key Changes Under MH S&E (Amendment) Ordinance 2025

| Provision | Before (MH S&E Act 2017) | After (Amendment Oct 2025) |
|-----------|--------------------------|---------------------------|
| Registration threshold | ≥10 employees | **≥20 employees** — establishments with <20 need only file INTIMATION |
| Daily working hours | 9 hours/day | **10 hours/day** (inclusive of rest interval) |
| Weekly hours | 48 hours | Unchanged — 48 hours/week |
| Spread-over | 10.5 hours | **12 hours/day** |
| Continuous work before rest | 5 hours | **6 hours** |
| Rest interval | 30 minutes (after 5 hrs) | 30 minutes (after 6 hrs) |
| Quarterly OT limit | 125 hours | **144 hours/quarter** |
| OT rate | 2× ordinary rate | Unchanged — 2× ordinary rate |
| 24×7 operations | Not permitted | **Permitted** (except establishments selling alcohol) with prior approval |

> **Audit implication (Pune):** Establishments with 10–19 employees previously required to register now need only file INTIMATION. Audit must verify which category the entity falls under. Entities with ≥20 employees must have full registration. Non-registration for ≥20 employees = MH S&E Act 2017 violation.

---

## Applicable Acts — Priority Hierarchy (Pune/Maharashtra)

| Statute | Jurisdiction | Establishment | Key Authority |
|---------|-------------|---------------|--------------|
| Maharashtra Shops & Establishments (RE&CS) Act 2017 (Amdt Oct 2025) | Maharashtra | All commercial establishments | Pune Labour Commissioner / Inspector |
| Factories Act 1948 + MH Factories Rules 1963 | Central + MH | Manufacturing (≥10 workers+power OR ≥20 without power) | Maharashtra Chief Inspector of Factories (Pune division) | [superseded 21-Nov-2025 — re-map to Code]
| Contract Labour (Regulation & Abolition) Act 1970 + MH Rules 1971 | Central + MH | PE (≥20 contract workers) + Contractor (≥20 workers) | Asst Commissioner of Labour (ACL) Pune | [superseded 21-Nov-2025 — re-map to Code]
| Industrial Employment (Standing Orders) Act 1946 | Central | Industrial establishments ≥100 employees | ACL Pune | [superseded 21-Nov-2025 — re-map to Code]
| Industrial Disputes Act 1947 | Central | Disputes, retrenchment, closure | Pune Labour Court / Industrial Tribunal | [superseded 21-Nov-2025 — re-map to Code]
| Maternity Benefit Act 1961 (Amdt 2017) | Central | All establishments (TN: ≥10) | Inspector under Act | [superseded 21-Nov-2025 — re-map to Code]
| Four Labour Codes (2019-2020) | Central | In force Nov 2025 | Multiple — verify per code |
| Mathadi & Unprotected Workers Act 1969 (Maharashtra) | Maharashtra | Specific industries — construction, loading/unloading in Pune | Mathadi Board |

---

## MH S&E Act 2017 (Post-Oct 2025 Amendment)

### Registration vs. Intimation
| Scenario | Requirement | Authority |
|----------|-------------|-----------|
| ≥20 employees | Full registration — Form A | Pune Labour Commissioner portal (mahakamgar.gov.in) |
| <20 employees | INTIMATION only (simplified) | Online intimation via portal |
| Change in category | Update within 30 days | Portal |

### Leave Entitlements (MH S&E Act 2017)
| Leave type | Entitlement | Carry forward | Cap |
|-----------|-------------|---------------|-----|
| Earned leave (EL) | 1 day per 12 days worked; min 21 days/year | Yes | Up to 42 days |
| Sick leave | 12 days/year | No carry forward | — |
| Casual leave | 12 days/year (typically; verify rules) | No carry forward | — |
| Public holidays | As per MH government notification (2026 list) | — | — |
| National holidays | 3 mandatory (26 Jan, 15 Aug, 2 Oct) | — | — |

### Salary Payment
- Salary must be paid by **7th of following month** (≤1,000 employees)
- **10th of following month** (>1,000 employees)
- Pay slips: Mandatory on each payment
- Service certificate: Mandatory on separation (Sec 22)

### Women's Safety in Workplace (Post-Oct 2025)
- Night shift (post-10 PM): Employer must provide safe transport, adequate lighting, rest facilities
- No woman employee to be required to work against her will after 9.30 PM without consent

---

## Factories Act 1948 — Maharashtra Factories Rules 1963 (Pune)

### Applicability
- Manufacturing process + ≥10 workers with power, OR ≥20 workers without power
- Common in Pune: Pimpri-Chinchwad, Chakan, Ranjangaon, Talegaon MIDC

### Key Compliance Points
| Provision | Requirement |
|-----------|------------|
| Annual licence (Form 2 MH) | Renewed before 31 December for following year |
| Occupier + Manager notification | Form 7 (Occupier) + Form 7A (Manager) — within 15 days of appointment |
| Working hours | Max 9 hrs/day; 48 hrs/week (MH Factories still follows Factories Act — not S&E Act amendment) | [superseded 21-Nov-2025 — re-map to Code]
| OT | 2× regular rate; max 50 hrs OT/quarter (Factories Act — compare to 144 hrs S&E Act for commercial establishments) | [superseded 21-Nov-2025 — re-map to Code]
| Annual leave with wages | 1 day per 20 days worked; carry forward up to 30 days |
| Annual return | Form 21 — by 31 January |
| Half-yearly return | Form 22 — by 31 July |
| Accident reporting | Fatal: Immediately (Form 18A); Major: within 24 hours (Form 18) |
| Safety committee | ≥250 workers — mandatory; meets quarterly |
| Canteen | ≥250 workers — mandatory |
| Creche | ≥30 women workers — mandatory |
| First aid | Per Sec 45 — mandatory; one first-aider per shift |

---

## CLRA 1970 — Contract Labour (Maharashtra) (Pune)

### Threshold & Registration
| Party | Threshold | Required | Form |
|-------|-----------|---------|------|
| Principal employer (Pune factory/office) | Uses ≥20 contract workers on any day | Register — ACL Pune | Form I (Application) + Form II (Certificate) |
| Contractor | Deploys ≥20 workers in MH | Licence — ACL Pune | Form IV (Application) + Form V (Licence) |

### Key Principal Employer Obligations (Pune)
- Form II registration before engaging contractor
- Maintain Form XIII (Register of Contractors) at premises
- Ensure contractor pays wages, EPF, ESIC, min wages to workers
- **Sec 21(4):** If contractor fails to pay wages → principal employer must pay and recover from contractor
- Annual return: Form XXV — by **15 February** (DLC Pune / ACL Pune)

### Mathadi Board (Pune-Specific)
- Maharashtra Mathadi, Unprotected Manual and Other Workers Act 1969
- Applicable to: Construction workers, loading/unloading, headload workers in certain industries in Pune
- Welfare fund levy (Mathadi levy) applicable — verify if entity uses such labour
- Registration with Maharashtra Mathadi Board mandatory if applicable

---

## Maternity Benefit Act 1961 (Amendment 2017)

| Provision | Details |
|-----------|---------|
| Paid maternity leave | 26 weeks (first 2 children); 12 weeks (3rd child+) |
| Adoption / commissioning | 12 weeks — child <3 months at adoption |
| Work from home option | Employer with ≥50 employees may offer post-maternity leave if nature of work permits |
| Creche | ≥50 employees — within 500m or at workplace; creche info given to all employees |
| Medical bonus | [IN-133] if no pre/post-natal care by employer |
| No dismissal | Cannot dismiss/discharge during maternity leave |

---

## Standing Orders (Pune Manufacturing)

- Applies to factories + industrial establishments ≥100 employees
- Standing Orders certified by Certifying Officer (ACL Pune) within 6 months of reaching threshold
- Must cover: Classification (permanent/temporary/probationer), attendance, leave, misconduct, suspension, termination, grievance
- Display: At workplace — Marathi + English (Maharashtra requirement)
- IT companies in Pune: If ≥100 employees — verify certified Standing Orders exist

---

## Audit Procedures — Labour Laws (Pune)

1. MH S&E Registration: Verify certificate for ≥20 employees; confirm intimation filed for <20 employees; check headcount against registration category
2. Post-Oct 2025 amendment: Verify HR policies updated — daily hours, OT quarterly limit (144 hrs), 24×7 approval (if applicable)
3. Leave ledger: EL = 1 day per 12 days worked; max carry forward 42 days; SL/CL per year
4. Salary payment dates: Verified credited by 7th or 10th per MH S&E Act
5. OT records: Hours × 2× rate; quarterly limit — S&E establishments 144 hrs; Factories 50 hrs
6. Factory: Form 2 (annual licence), Form 21/22 (annual/half-yearly returns), accident register
7. CLRA: Form V licence from ACL Pune (not from vendor); Form XIII at site; Form XXV filed by Feb 15 [superseded 21-Nov-2025 — re-map to Code]
8. Mathadi: If construction/loading/unloading workers — verify Mathadi Board registration and levy payment
9. Maternity register: ≥26 weeks paid leave granted; WFH option documented if ≥50 employees
10. Standing Orders: Certified (if ≥100 employees); displayed in Marathi + English

---

## Red Flags — Labour Laws (Pune)

- Establishment with 20+ employees but no MH S&E registration (post-Oct 2025 threshold) — ongoing violation
- OT exceeding 144 hrs/quarter for commercial establishments (post-Oct 2025 limit)
- Factory with OT exceeding 50 hrs/quarter for workers (Factories Act limit — separate from S&E Act) [superseded 21-Nov-2025 — re-map to Code]
- No CLRA Form V from ACL Pune — relying on vendor-submitted copy only [superseded 21-Nov-2025 — re-map to Code]
- Maternity leave granted for only 12 weeks for first child (must be 26 weeks)
- No creche facility for establishment with ≥50 employees (Maternity Benefit Act) [superseded 21-Nov-2025 — re-map to Code]
- Termination of permanent employee without inquiry under Standing Orders
- Night shift for women without safety provisions (MH S&E Act post-Oct 2025)
- Mathadi Board levy not paid for applicable establishments in Pune
