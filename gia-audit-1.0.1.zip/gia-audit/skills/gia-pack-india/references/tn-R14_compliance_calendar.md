> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- Monthly Recurring Obligations
- Quarterly Obligations
- Annual / Periodic Compliance Calendar (FY 2025-26 / FY 2026-27)
- Penalty Quick Reference


# R14 — Chennai / Tamil Nadu / India Compliance Calendar (FY 2025-26 & 2026-27)

> **Audit use:** For each engagement, extract the relevant period's due dates and test whether each obligation was met on time. Late compliance = finding; non-compliance = finding + quantified penalty.

---

## Monthly Recurring Obligations

| Due Date | Obligation | Statute | Portal / Authority |
|---------|-----------|---------|-------------------|
| 7th | TDS challan deposit (Apr–Feb payments) | IT Act 1961/2025, Sec 200, Rule 30 | TRACES (challan 281) |
| 10th | GSTR-7 (TDS deductors u/s 51) | CGST Act 2017 | gst.gov.in |
| 10th | GSTR-8 (TCS e-commerce operators) | CGST Act 2017 | gst.gov.in |
| 11th | GSTR-1 (monthly — outward supply) | CGST Act Rule 59 | gst.gov.in |
| 13th | IFF (QRMP — optional invoice filing) | CGST Act | gst.gov.in |
| 15th | EPF ECR + challan | EPF Act 1952, Para 38 | epfindia.gov.in |
| 15th | ESIC ECR + challan | ESI Act 1948, Sec 40 | esic.gov.in | [superseded 21-Nov-2025 — re-map to Code]
| 20th | GSTR-3B (monthly taxpayers >[IN-099]) | CGST Act Rule 61 | gst.gov.in |
| 22nd/24th | GSTR-3B (QRMP scheme) | CGST Act | gst.gov.in |
| Last working day | ECB-2 (if ECB outstanding) | FEMA 1999 / RBI Master Direction | FIRMS (RBI) |

---

## Quarterly Obligations

| Quarter | Due Date | Obligation | Statute | Portal |
|---------|---------|-----------|---------|--------|
| Q1 (Apr–Jun) | 31 Jul | Form 24Q (TDS salary) + Form 26Q (TDS non-salary) + Form 27Q (NR) + Form 27EQ (TCS) | IT Act 1961/2025 Rule 31A | TRACES |
| Q2 (Jul–Sep) | 31 Oct | Same TDS/TCS returns | IT Act | TRACES |
| Q3 (Oct–Dec) | 31 Jan | Same TDS/TCS returns | IT Act | TRACES |
| Q4 (Jan–Mar) | **31 May** | Same TDS/TCS returns | IT Act | TRACES |
| Q4 March only | **30 Apr** | TDS challan for March payments | IT Act Rule 30 | TRACES |

---

## Annual / Periodic Compliance Calendar (FY 2025-26 / FY 2026-27)

### Direct Tax

| Due Date | Obligation | Applicable To | Statute |
|---------|-----------|-------------|---------|
| 15 Jun | 1st advance tax instalment ([IN-075]) | Companies + individuals | IT Act |
| 15 Jul | Income Tax Return — companies (tentative) | Companies (no TP) | IT Act |
| 31 Jul | ITR — individuals (not audit required) | Individuals | IT Act |
| 15 Sep | 2nd advance tax instalment ([IN-075] cumulative) | All | IT Act |
| 30 Sep | Tax audit report (Form 3CA/3CB + 3CD) | Businesses above turnover threshold | IT Act |
| 15 Oct | ITR — companies (with audit, no TP) | Companies | IT Act |
| 31 Oct | ITR — businesses requiring audit | Firms, LLPs, businesses | IT Act |
| 30 Nov | ITR — companies / persons with TP | With international TP | IT Act |
| 15 Dec | 3rd advance tax instalment ([IN-075] cumulative) | All | IT Act |
| 31 Dec | Belated ITR / Revised ITR | All | IT Act |
| 15 Mar | 4th advance tax instalment (100%) | All | IT Act |
| Jun 15 | Form 16 (TDS certificate) to employees | Employers | IT Act Rule 31 |
| Jun 15 | Form 16A (TDS certificate) to vendors | Deductors | IT Act Rule 31A |

**Note: Dates above follow IT Act 1961 practice. IT Act 2025 effective Tax Year 2026-27 — verify CBDT notification for any changes to due dates under new Act.**

---

### GST

| Due Date | Obligation | Applicable To |
|---------|-----------|-------------|
| 11th monthly | GSTR-1 | Monthly filers |
| 20th monthly | GSTR-3B | Monthly filers (>[IN-099]) |
| 31 Dec (next FY) | GSTR-9 (Annual Return) | All registered taxpayers |
| 31 Dec (next FY) | GSTR-9C (Reconciliation) | Taxpayers with turnover >[IN-100] |
| Within 3 months | Rectification under Sec 161 TNGST (Circular 4/2025) | If error in assessment orders |

---

### HR / Payroll / Labour

| Due Date | Obligation | Statute | Authority |
|---------|-----------|---------|---------|
| 7 Feb, 7 Mar, 7 Apr… | TDS challan (salary month) | IT Act | TRACES |
| 15th monthly | EPF + ESIC ECR + challan | EPF Act, ESI Act | EPFO, ESIC | [superseded 21-Nov-2025 — re-map to Code]
| 31 Jan | Form 26Q Q3 TDS return | IT Act | TRACES |
| 31 Jan | TN LWF — half-year deduction + remittance (Oct–Mar) | TN LWF Act 1972 | TN LWF Board |
| 31 Jan | POSH ICC Annual Report to District Officer | POSH Act 2013, Sec 21 | District Officer |
| 15 Feb | CLRA Annual Return (Form XXV) | CLRA 1970, Rule 82 | DLC Chennai | [superseded 21-Nov-2025 — re-map to Code]
| 28 Feb | PT half-year 2 (Oct–Mar) — verify exact date TN CT portal | TN PT Act 1992 | TN CT portal |
| 31 Mar | TN Factories — Annual Return Form 21 (by 31 Jan — verify) | Factories Act 1948 | Inspector of Factories | [superseded 21-Nov-2025 — re-map to Code]
| 30 Apr | TDS challan for March salary payments | IT Act | TRACES |
| 30 Apr | TN LWF Annual Return Form A | TN LWF Act | TN LWF Board |
| 30 Apr | MSME Form I (Oct–Mar outstanding dues) | MSMED Act 2006 | MCA21 |
| 30 Apr | PT half-year 1 (Apr–Sep) | TN PT Act 1992 | TN CT portal |
| 31 May | Form 24Q + 26Q Q4 (Jan–Mar) TDS returns | IT Act | TRACES |
| 30 Jun | EPF Annual Return (if not on ECR system — verify) | EPF Act | EPFO |
| 31 Jul | TN LWF — half-year 1 (Apr–Sep) remittance | TN LWF Act | TN LWF Board |
| 31 Jul | Factories Half-Yearly Return Form 22 (by 31 Jul) | Factories Act | Inspector | [superseded 21-Nov-2025 — re-map to Code]
| 15 Jun | Form 16 + Form 16A issued to employees/vendors | IT Act | Internal |
| 30 Sep | DIR-3 KYC (Director KYC update) | Companies Act 2013, Rule 12A | MCA21 |
| 30 Nov | Bonus payment (FY April–March companies) | Payment of Bonus Act 1965, Sec 19 | Internal | [superseded 21-Nov-2025 — re-map to Code]
| 31 Oct | MSME Form I (Apr–Sep outstanding dues) | MSMED Act 2006 | MCA21 |

---

### Company Law — Key Annual Dates

| Due Date | Obligation | Form | Portal |
|---------|-----------|-----|--------|
| 30 days from AGM | Financial Statements | AOC-4 / AOC-4 CFS | MCA21 |
| 60 days from AGM | Annual Return | MGT-7 / MGT-7A | MCA21 |
| AGM by 30 Sep | Annual General Meeting | — | Company records |
| 30 Sep | Director KYC | DIR-3 KYC | MCA21 |
| 30 Oct | MSME Form I (half-yearly) | MSME Form I | MCA21 |
| 30 Apr | MSME Form I (half-yearly) | MSME Form I | MCA21 |
| Within 30 days of charge | Charge registration | CHG-1 | MCA21 |
| Within 15 days of AGM | Auditor appointment | ADT-1 | MCA21 |
| With AOC-4 | CSR-2 (if CSR applicable) | CSR-2 | MCA21 |

---

### FEMA / RBI

| Due Date | Obligation | Form | Portal |
|---------|-----------|-----|--------|
| Within 30 days of FDI allotment | FDI receipt reporting | FC-GPR | FIRMS (RBI) |
| Within 60 days of share transfer | FDI transfer reporting | FC-TRS | FIRMS |
| 15 Jul each year | FLA Annual Return (if FDI/ODI) | FLA | FIRMS / RBI |
| Last working day (monthly) | ECB repayment reporting | ECB-2 | FIRMS (via AD bank) |
| Within 9 months | Foreign export proceeds repatriation | — | AD bank / FEMA |

---

### Environment / Local Body

| Due Date | Obligation | Authority |
|---------|-----------|---------|
| Before expiry | TNPCB CTO renewal | TNPCB |
| Before expiry | Fire NOC renewal | TNFRS |
| Annual | GCC Trade Licence renewal | Greater Chennai Corporation |
| Annual | Factory Licence (Form 2) renewal | Inspector of Factories |
| Annual | Legal Metrology instrument verification | Dept of Legal Metrology |
| Half-yearly | Hazardous waste manifest (Form 3) | TNPCB |

---

## Penalty Quick Reference

| Violation | Penalty |
|-----------|---------|
| Late TDS challan deposit | Sec 234E — [IN-073]/day; Sec 271H — [IN-073]–[IN-073] |
| TDS not deducted | Sec 40(a)(ia) — [IN-074] expense disallowance; Sec 276B — prosecution |
| Late GST GSTR-3B | [IN-101]/day ([IN-101] for nil); [IN-102] p.a. interest on tax |
| Late EPF remittance | Sec 7Q — [IN-123] p.a.; Sec 14B — damages up to [IN-007] |
| Late ESIC remittance | Sec 85B — [IN-125] p.a. interest |
| Minimum wages not paid | Min Wages Act — fine up to [IN-130]; repeat [IN-130] + imprisonment |
| CLRA non-compliance | Fine up to [IN-131]; repeat [IN-131] + imprisonment | [superseded 21-Nov-2025 — re-map to Code]
| Bonus not paid on time | Sec 28 — fine [IN-127] + imprisonment 6 months |
| POSH ICC not constituted | Sec 26 — [IN-134] first offence; doubled for repeat |
| ROC annual return late | MGT-7: [IN-110] + [IN-110]/day |
| MCA AOC-4 late | [IN-109]/day |
| MSME Form I not filed | Fine [IN-112] |
| TNPCB CTO expired | Closure order + prosecution under EP Act |
| GCC Trade Licence expired | Sealing / fine |
