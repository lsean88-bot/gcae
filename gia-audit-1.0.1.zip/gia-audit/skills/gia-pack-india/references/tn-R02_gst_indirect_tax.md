> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- Jurisdiction Note — Chennai
- Key GST Rate Reference (Services — Current as at Sep 2025 notification)
- Reverse Charge Mechanism (RCM) — Critical for Chennai Businesses
- GST Compliance Calendar (Monthly/Quarterly)
- ITC Eligibility — Critical Rules (Sec 16 CGST Act)
- e-Invoicing Requirements (2026)
- e-Way Bill Requirements
- GST Audit Procedures
- Red Flags — GST


# R02 — GST: CGST / TNGST / IGST (2017)

## Jurisdiction Note — Chennai
Chennai transactions are INTRA-STATE → CGST [IN-091] + SGST (TNGST) [IN-091] = [IN-091] (for most services).
Interstate transactions → IGST at full rate (no split).
Always confirm bill has correct CGST+SGST split for Chennai-based supplies.

---

## Key GST Rate Reference (Services — Current as at Sep 2025 notification)

| Service | SAC | GST Rate | Notes |
|---------|-----|----------|-------|
| Manpower supply / labour / staffing | 9985 / 998513 / 998519 | [IN-031] | CGST [IN-091] + SGST [IN-091] |
| Contract staffing (temp) | 998513 | [IN-031] | Same |
| Security services | 998523 | [IN-092] | RCM applies if supplier is sole proprietor/individual |
| Housekeeping / facility management | 998532 | [IN-092] | — |
| Professional services (CA, legal, consulting) | 9983 / 998211 | [IN-092] | — |
| Works contract — commercial buildings | 9954 | [IN-032] | — |
| Works contract — government infra | 9954 | [IN-033] | Specific notified projects only |
| IT services / software | 9983 / 998314 | [IN-092] | — |
| Transportation (GTA) | 9965 | [IN-093] (no ITC) or [IN-093] (with ITC) | GTA elects forward or RCM |
| Rent — commercial | 9972 | [IN-092] | — |
| Rent — residential (if registered) | 9972 | [IN-094] (post Jul 2022 for registered persons) | RCM on registered lessee |
| Training / coaching | 9992 | [IN-092] | — |

---

## Reverse Charge Mechanism (RCM) — Critical for Chennai Businesses

RCM applies — RECIPIENT pays GST (not supplier):

| Supply | RCM rate | Action required |
|--------|---------|-----------------|
| GTA (Goods Transport Agency) services | [IN-093] or [IN-093] | Recipient pays GST; supplier issues consignment note |
| Legal services by advocate | [IN-097] | Recipient pays |
| Security services by individual/sole prop | [IN-097] | Recipient (corporate) pays |
| Sponsorship services | [IN-097] | Recipient pays |
| Imports of services | IGST at applicable rate | Recipient pays (Schedule I) |
| Director's remuneration | [IN-097] | Company pays (post AAR rulings — verify specific facts) |

> **Audit risk:** RCM GST not paid by recipient = GST demand + interest + penalty (Sec 73/74 CGST)

---

## GST Compliance Calendar (Monthly/Quarterly)

| Return | Who files | Monthly due | Quarterly (QRMP) |
|--------|-----------|-------------|------------------|
| GSTR-1 | All registered outward supply | 11th of next month | 13th of month after quarter |
| IFF (Invoice Filing Facility) | QRMP taxpayers only | 13th of month | n/a |
| GSTR-3B | All registered (net liability) | 20th of next month (>[IN-099]) | 22nd/24th for QRMP |
| GSTR-9 | Annual — all registered | 31 December of next FY | — |
| GSTR-9C | Reconciliation statement (turnover >[IN-100]) | 31 December of next FY | — |
| GSTR-7 | TDS deductors u/s 51 | 10th of next month | — |
| GSTR-8 | e-commerce TCS operators | 10th of next month | — |

**Late fee:** GSTR-3B — [IN-101]/day ([IN-101]/day for nil return); GSTR-1 — [IN-101]/day.
**Interest on late tax payment:** [IN-102] p.a. on net tax payable.

---

## ITC Eligibility — Critical Rules (Sec 16 CGST Act)

ITC is available ONLY if ALL of these conditions are met:
1. Tax invoice or debit note from registered supplier is in possession
2. Goods/services received
3. Tax actually paid by supplier to government
4. GSTR-3B return filed by recipient
5. **Sec 16(2)(aa) — CRITICAL:** Invoice must appear in GSTR-2B of recipient (supplier must have filed GSTR-1/IFF); ITC is BLOCKED if supplier hasn't filed

**ITC BLOCKED (Sec 17(5)):**
- Motor vehicles (except specific business use)
- Food and beverages, outdoor catering
- Health club, fitness centre membership
- Works contract services for immovable property (except for further supply)
- Goods/services for personal use
- CSR expenditure

---

## e-Invoicing Requirements (2026)

| Aggregate turnover (previous FY) | Mandatory e-invoice? |
|----------------------------------|---------------------|
| > [IN-103] | YES — since Aug 2023 |
| [IN-103] and below | No (as at May 2026 — verify latest notification) |

e-Invoice must be generated on IRP (Invoice Registration Portal) → IRN + QR code mandatory on invoice.
**Audit test:** Verify IRN on all invoices from vendors with turnover >[IN-103]. Invalid IRN = invalid tax invoice = ITC blocked.

---

## e-Way Bill Requirements

- Required for movement of goods > [IN-105] in value
- Intra-state and inter-state (IGST)
- Generated on ewaybillgst.gov.in
- Validity: 1 day per 100 km (extendable in specific cases)

---

## GST Audit Procedures

1. **GSTR-2B Reconciliation:** Download GSTR-2B for all months → compare to ITC claimed in GSTR-3B. Any ITC claimed not in GSTR-2B = recoverable with [IN-102] interest.
2. **Outward supply reconciliation:** GSTR-1 vs. books of account vs. GSTR-3B — three-way match.
3. **Rate verification:** For all vendor invoices — verify SAC code, rate applied, CGST+SGST or IGST as applicable.
4. **RCM compliance:** Identify all RCM-applicable supplies (GTA, legal, security, imports) — verify RCM GST paid in GSTR-3B Table 3.1(d).
5. **e-Invoice verification:** For vendors with turnover >[IN-103] — verify IRN on invoice against IRP portal.
6. **Annual return (GSTR-9) filing:** Verify filed by 31 Dec; GSTR-9C if turnover >[IN-100].
7. **TNGST Circular 4/2025:** If any rectification was filed/required under Sec 161 TNGST — verify compliance with 6-month order deadline.

---

## Red Flags — GST

- Vendor GSTIN cancelled or suspended (verify gst.gov.in taxpayer search) → ITC ineligible
- GST rate on invoice different from SAC mapping (under-charge = revenue risk; overcharge = supplier's liability)
- ITC claimed on blocked items (Sec 17(5)) — especially food, employee welfare, motor vehicles
- No e-Invoice IRN on bills from vendors above [IN-103] threshold
- GSTR-2B mismatch with ITC claimed — most common GST audit demand trigger
- RCM obligations unrecognized (especially security services from individual contractors)
- Intra-state supply billed as IGST or vice versa (place of supply error)
- Split invoices to stay below e-invoicing threshold or annual return scrutiny
