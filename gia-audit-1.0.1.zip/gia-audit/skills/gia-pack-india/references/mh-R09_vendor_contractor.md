> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- Vendor Onboarding KYC — Mandatory Controls
- Invoice Completeness — CGST Rule 46 (Mandatory Fields)
- Invoice Validation Checklist (per bill) — Pune
- Bill Population Analytics (Multi-Vendor)
- CLRA Validation Matrix (Pune) [superseded 21-Nov-2025 — re-map to Code]
- Approved Vendor Master Controls (Pune)
- Red Flags — Vendor / Contractor (Pune)


# R09 — Vendor & Contractor Bill Validation (Pune / Maharashtra)

## Vendor Onboarding KYC — Mandatory Controls

| Document | Purpose | Verification Source |
|----------|---------|-------------------|
| GSTIN (must start with 27) | GST compliance + intra-MH confirmation | gst.gov.in — taxpayer search |
| PAN | TDS rate determination; entity type | incometax.gov.in — PAN verification |
| Bank account details | Payment accuracy | Cancelled cheque + Bank letter; penny drop |
| CLRA Form V Licence | Contract labour compliance | ACL Pune office records (NOT from vendor) | [superseded 21-Nov-2025 — re-map to Code]
| Company incorporation | Entity type | MCA21 — CIN search under ROC Pune |
| MSME Registration | Payment terms (45-day MSMED Act) | udyamregistration.gov.in |
| GST state code confirmation | First 2 digits of GSTIN = 27 (Maharashtra) | gst.gov.in |

> **Pune-specific rule:** A Pune-based vendor's GSTIN must start with 27 (Maharashtra). If a vendor claims to be in Pune but has GSTIN starting with a different state code, verify their registration state — they may be registered elsewhere, making the supply inter-state (IGST, not CGST+MGST).

---

## Invoice Completeness — CGST Rule 46 (Mandatory Fields)

Every valid GST tax invoice MUST contain:
1. Supplier name, address, **GSTIN (first 2 digits = 27 for Pune)**
2. Serial number (unique, within FY)
3. Date of issue
4. Recipient name, address, GSTIN
5. **Place of supply = Maharashtra (27)** for intra-Pune supplies
6. HSN / SAC code
7. Description of goods/services
8. Quantity / units (man-days, hours, head count for services)
9. Taxable value
10. Tax rate: **CGST [IN-091] + MGST [IN-091]** for intra-MH
11. Tax amount: CGST amount + MGST amount
12. Total amount payable
13. Whether RCM applicable (Yes/No)
14. Signature of supplier
15. **IRN + QR Code** if vendor turnover >[IN-103] (e-invoice)

**Incomplete invoice = invalid tax document = ITC ineligible.**

---

## Invoice Validation Checklist (per bill) — Pune

### Identity Checks
- [ ] Vendor GSTIN starts with **27** — verify on gst.gov.in — active, not cancelled/suspended
- [ ] Place of supply on invoice = Maharashtra (27) for Pune-to-Pune supply → CGST+MGST (not IGST)
- [ ] PAN on invoice matches incometax.gov.in — entity type from 4th PAN letter (P=individual, C=company, F=firm, H=HUF, A=AOP)
- [ ] Invoice entity name EXACTLY matches GSTIN registration name on GST portal

### Tax Computation Checks
- [ ] GST rate correct for SAC/HSN (SAC 998513 manpower = [IN-031]; SAC 9965 GTA = [IN-093] or [IN-093])
- [ ] CGST = [IN-091] × taxable value (for intra-MH)
- [ ] MGST = [IN-091] × taxable value (for intra-MH)
- [ ] CGST + MGST + taxable value = Invoice total (arithmetic check)
- [ ] TDS NOT deducted on GST portion (base only per CBDT Circular 23/2017)
- [ ] e-Invoice IRN present and valid (vendors with turnover >[IN-103] — most large Pune vendors)

### Service/Labour Description Checks
- [ ] Period of service stated (month/dates)
- [ ] Number of workers / man-days — sufficient to compute per-worker unit rate
- [ ] Implied per-worker rate ≥ applicable MH min wage (Zone I Pune, Jan/Jul notification, applicable skill)
- [ ] SAC code matches actual service (not a generic catch-all code)

### EPF/ESIC Component Checks (if billed separately)
- [ ] EPF employee = [IN-001] of (Basic+DA per worker)
- [ ] EPF employer = [IN-120] of (Basic+DA per worker) [[IN-002] EPS + [IN-003] EPF]
- [ ] EPFO admin = [IN-004]; EDLI = [IN-005] (capped at [IN-006])
- [ ] ESIC employer = [IN-008] of gross wages (for workers ≤[IN-010] gross)
- [ ] ESIC employee = [IN-009] of gross wages
- [ ] **Post-Nov 2025 Labour Codes check:** New wages definition applied — allowances >[IN-017] gross re-enter base
- [ ] EPFO/ESIC challan copies provided — Rank 1 evidence contributions actually remitted

### TDS Application Checks
- [ ] TDS on TAXABLE VALUE only (not on CGST + MGST)
- [ ] Rate: Individual/HUF = [IN-023]; Company/Firm = [IN-023]; No PAN = [IN-026] (Sec 206AA)
- [ ] Aggregate vendor billing in FY tested: >[IN-024] → TDS on all invoices
- [ ] Multiple invoices just below [IN-024] from same vendor in same month = splitting red flag
- [ ] Challan deposited by 7th of following month (30 April for March)

### CLRA Checks
- [ ] CLRA Form V Licence number verified from ACL Pune records (not vendor copy) [superseded 21-Nov-2025 — re-map to Code]
- [ ] Worker count on bill ≤ Form V headcount limit
- [ ] Workers are within the licensed category/type of work
- [ ] MH min wage (Zone I) implied per-worker rate check

---

## Bill Population Analytics (Multi-Vendor)

### Completeness Test
```
Expected bills = Vendors × Months in period
Actual bills received = Count
Gaps = Missing vendor × month combinations → Obtain immediately; explain
Duplicates = Same vendor + same month + same amount → Double payment risk
```

### Amount Trend Analysis
- Month-on-month change per vendor >[threshold set in engagement plan] without explanation = investigate
- Identical total invoice amounts across different vendors = collusion flag
- Round-number totals ([just-below-threshold value]; [just-below-threshold value]) = threshold manipulation

### Benford's Law Application
- Leading digit distribution from all bill amounts (taxable values)
- Benford and digit tests: run through `gia-fraud:gia-fraud-analytics` (Nigrini MAD primary with per-digit z-scores; chi-square supplementary for small populations). Confirm the preconditions, segment fixed-amount populations first, and record the MAD table version in the workpaper. A deviation is an indicator, never a conclusion. Inline thresholds from the retired source were removed.
- Focus on digit clustering near [IN-024] (Sec 194C threshold) = invoice splitting signal
- Focus on excess of leading 1s/2s near [IN-028] = cash limit avoidance

### Cross-Vendor Duplicate Tests (Pune MIDC / IT Parks)
- Same GST number across two vendors = same entity billing twice
- Same PAN across two vendors = same beneficial owner; related party risk
- Same bank account across two vendors = payment diversion risk
- Same MIDC address for two vendors = potential shell entities

---

## CLRA Validation Matrix (Pune)

| Test | Source | Finding if Failed |
|------|--------|-----------------|
| Form V licence verified from ACL Pune | ACL Pune office (Rank 1) | Unlicensed contractor; CLRA Sec 7 violation; PE liability Sec 21(4) | [superseded 21-Nov-2025 — re-map to Code]
| Worker count on bill ≤ Form V headcount | Bill vs. Form V | Excess workers = licence violation |
| Licensed work category matches bill description | Form V scope vs. bill | Licence scope mismatch |
| Form XIII at Pune principal employer's premises | Internal register | Unregistered contractor |
| Implied per-worker wage ≥ MH Zone I min wage | Bill calculation vs. gazette | Min Wages Act 1948 violation |
| Form XXV Annual Return filed by 15 Feb | ACL Pune records | Annual return default |

---

## Approved Vendor Master Controls (Pune)

| Control | Description |
|---------|-------------|
| Dual authorization | New vendor: requested by dept + Finance approval + IA verification |
| GSTIN (27) + PAN portal validation | Not from vendor copy — portal verification |
| Bank account penny-drop | [nominal amount] test transfer + signed bank letter |
| Periodic revalidation | Annual — GSTIN active, no cancellation, MCA21 active |
| Related party check | Vendor director/owner = company employee/director/relative → RPT |
| MSME check | Udyamregistration.gov.in — verify MSME category for payment terms |
| Price benchmarking | Rates vs. market and other vendors for same service/commodity |
| MIDC-specific | For MIDC Pune vendors — verify MIDC allotment/letter |

---

## Red Flags — Vendor / Contractor (Pune)

- Vendor GSTIN not starting with 27 but claims Pune location (wrong state registration or inter-state supply billed as intra-state)
- GSTIN cancelled or suspended on gst.gov.in portal
- No CLRA Form V from ACL Pune — only vendor-submitted copy available [superseded 21-Nov-2025 — re-map to Code]
- Per-worker implied wage below MH Zone I minimum wage notification
- EPF/ESIC billed without challan copies (collecting but not remitting to EPFO/ESIC)
- Invoice serial numbers non-sequential (bills issued selectively)
- No e-Invoice IRN on invoices from large Pune vendors (likely >[IN-103] turnover)
- Multiple vendors with same Pune MIDC address or pin code (shell entity pattern)
- Bill amounts consistently just below [IN-024] from same vendor (TDS avoidance)
- New vendor onboarded without background check — vendor director cross-check against Pune employee database not done
