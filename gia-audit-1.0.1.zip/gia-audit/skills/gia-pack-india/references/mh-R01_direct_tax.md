> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- Critical Transition — IT Act 2025 ([IN-022])
- Key TDS Sections (IT Act 1961 — applicable up to 31 Mar 2026)
- TDS Deposit & Return Deadlines
- TDS Sec 194C — Contractor Payments (Pune Context)
- Advance Tax (Corporate) — IT Act 1961
- Pune-Specific Tax Audit Applicability
- Audit Procedures — Direct Tax (Pune)
- Red Flags — Direct Tax (Pune Manufacturing / IT/ITeS)


# R01 — Direct Tax (Income Tax Act 2025 / IT Act 1961 Transition)

## Critical Transition — IT Act 2025 ([IN-022])

| Aspect | IT Act 1961 | IT Act 2025 |
|--------|------------|------------|
| Applies to | Up to 31 Mar 2026 (FY 2025-26 and earlier) | [IN-022] (Tax Year 2026-27 onwards) |
| Sections | 819 sections + provisos | 536 sections, 23 chapters, 16 schedules |
| Key terminology | Previous Year / Assessment Year | "Tax Year" (single unified concept = FY) |
| Tax rates | Unchanged | Unchanged — structural reform only |
| TDS sections | Sec 192, 194C, 194J, 194H etc. | Re-numbered — verify CBDT notification for new section refs |
| FY 2025-26 returns (Pune entities) | Filed under IT Act 1961 | n/a |
| FY 2026-27 returns (Pune entities) | n/a | Filed under IT Act 2025 |

> **Audit implication (Pune):** For Jan–Mar 2026 transactions → IT Act 1961 governs. For Apr 2026 onwards → IT Act 2025 governs. Always state which Act applies. Pune-based companies file returns at Pune Jurisdiction (incometax.gov.in — know your AO based on PAN).

---

## Key TDS Sections (IT Act 1961 — applicable up to 31 Mar 2026)

| Section | Nature of Payment | Rate | Threshold | Notes |
|---------|------------------|------|-----------|-------|
| 192 | Salary | Slab rate | Any salary above basic exemption | New regime default from FY 2024-25 |
| 194C | Contractor / sub-contractor | [IN-023] (individual/HUF); [IN-023] (company/firm) | [IN-024] single / [IN-024] annual | MOST COMMON for Pune manufacturing/IT contractor bills |
| 194J | Professional / technical fees | [IN-025] professional; [IN-025] technical | [IN-069] | IT/ITeS Pune sector — frequent application |
| 194H | Commission / brokerage | [IN-066] | [IN-066] | |
| 194I(b) | Rent — land/building | [IN-067] | [IN-067] p.a. | Pune office/warehouse rent |
| 194I(a) | Rent — plant/machinery | [IN-068] | [IN-068] p.a. | MIDC Pune equipment lease |
| 194Q | Purchase of goods | [IN-070] | Buyer turnover >[IN-070]; transaction >[IN-070] | Auto ancillary Pune — high value purchases |
| 206AA | No PAN | [IN-026] | — | Mandatory; no exceptions |
| 206AB | Specified person (non-filer) | [IN-071] or 2× rate, whichever higher | Specified condition | |

**TDS on GST:** TDS is on base value ONLY — NOT on GST component (CBDT Circular 23/2017; IT Act 2025 equivalent confirmed).

---

## TDS Deposit & Return Deadlines

| Month of deduction | Deposit due (Challan 281) |
|-------------------|--------------------------|
| April to February | 7th of following month |
| March | 30th April (extended for March only) |

| Return | Nature | Quarterly due dates |
|--------|--------|-------------------|
| Form 24Q | TDS on salary | Q1: 31 Jul | Q2: 31 Oct | Q3: 31 Jan | Q4: **31 May** |
| Form 26Q | TDS other than salary | Same as 24Q |
| Form 27Q | TDS on NR payments | Same as 24Q |
| Form 27EQ | TCS | Same as 24Q |

**Late filing:** Sec 234E — [IN-073]/day (max up to TDS amount). Sec 271H — [IN-073] to [IN-073].
**Non-deduction:** Sec 40(a)(ia) — [IN-074] of entire payment disallowed as business expense.

---

## TDS Sec 194C — Contractor Payments (Pune Context)

Pune manufacturing (auto ancillary, pharma, engineering) and IT/ITeS companies heavily use contract labour and service vendors. Key rules:

1. **Threshold test:** Single payment >[IN-024] OR aggregate FY >[IN-024] → TDS mandatory
2. **Entity rate:** Individual/HUF = [IN-023]; Company/Firm/LLP/AOP = [IN-023]
3. **Invoice split check:** Multiple invoices from same contractor just below [IN-024] in same month = splitting red flag
4. **GST exclusion:** TDS on taxable base; not on CGST+MGST (CBDT Circular 23/2017)
5. **Transport exemption:** Sec 194C(6) — transporter with ≤10 vehicles, PAN furnished = nil TDS
6. **Sec 40(a)(ia) exposure:** If TDS not deducted → [IN-074] of total payment disallowed
7. **Prosecution:** Sec 276B — non-deposit of TDS after deduction = imprisonment 3 months to 7 years

---

## Advance Tax (Corporate) — IT Act 1961

| Instalment | Due Date | % of Annual Liability |
|-----------|---------|----------------------|
| 1st | 15 June | [IN-075] |
| 2nd | 15 September | [IN-075] (cumulative) |
| 3rd | 15 December | [IN-075] (cumulative) |
| 4th | 15 March | 100% |

**Interest on shortfall:** Sec 234B and Sec 234C — [IN-076] per month simple interest.

---

## Pune-Specific Tax Audit Applicability

| Entity Type | Tax Audit Threshold | Form |
|-------------|--------------------|----|
| Business (non-presumptive) | Turnover >[IN-077] (or >[IN-077] if >[IN-077] digital) | Form 3CA + 3CD |
| Profession (CA, legal, consulting) | Gross receipts >[IN-077] | Form 3CB + 3CD |
| Presumptive (Sec 44AD/44ADA) | If income declared < presumptive income | Form 3CB + 3CD |
| Company | Always (Sec 44AB — companies must get audit) | Form 3CA + 3CD |

---

## Audit Procedures — Direct Tax (Pune)

1. Obtain Form 26AS, AIS, TIS for all Tax Years from portal — Rank 1 evidence
2. Reconcile 26AS TDS credits to books — unexplained third-party TDS = unreported income
3. Test 100% TDS on vendor invoices — recompute per Sec 194C/194J/194H/194I category
4. Test for invoice splitting: Identify vendors with multiple invoices just below [IN-024] in a single month
5. Verify TDS challan deposit dates — late = Sec 234E interest + Sec 271H penalty
6. Verify Form 26Q (Q4 Jan-Mar) filed by 31 May — critical deadline
7. Test Sec 206AA compliance — PAN on every vendor invoice; [IN-026] TDS if absent
8. Test Sec 206AB — verify key vendors/deductees are not "specified persons" (non-filers)
9. Reconcile TDS returns to books — gap = under-deduction exposure
10. Advance tax: Recompute expected on latest P&L; test for Sec 234B/234C interest
11. **IT Act 2025 transition (Apr 2026+):** Verify new section references used; verify "Tax Year" terminology; verify CBDT notification for renumbered TDS sections

---

## Red Flags — Direct Tax (Pune Manufacturing / IT/ITeS)

- High-value MIDC supplier invoices without TDS deduction (often seen in industrial procurement)
- IT/ITeS companies in Hinjewadi/Baner engaging freelance professionals without 194J TDS
- Auto ancillary vendors with high-value contracts but PAN missing ([IN-026] exposure)
- Multiple invoices from same vendor in same month all just below [IN-024]
- TDS deducted but challan not deposited (Sec 276B prosecution risk)
- 26AS credits not matching books (income suppression or TDS default by customer)
- Round-trip intercompany transactions with Pune group companies without proper TDS treatment
