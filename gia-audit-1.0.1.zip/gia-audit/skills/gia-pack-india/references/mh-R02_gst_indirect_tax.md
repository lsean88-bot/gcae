> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- Maharashtra GST — Key Jurisdiction Facts for Pune
- Key GST Rate Reference (Services — Sep 2025 Notification)
- Reverse Charge Mechanism (RCM) — Pune Businesses
- GST Compliance Calendar (Monthly/Quarterly)
- ITC Eligibility — Critical Rules (Sec 16 CGST Act)
- e-Invoicing (Pune Context)
- e-Way Bill (Pune Manufacturing Context)
- GST Audit Procedures (Pune)
- Red Flags — GST (Pune)


# R02 — GST: CGST / MGST (Maharashtra GST) / IGST (2017)

## Maharashtra GST — Key Jurisdiction Facts for Pune

- **Maharashtra GST State Code: 27**
- All Pune-based vendor GSTINs must begin with **27** for intra-state supplies
- Intra-Pune supply: CGST [IN-091] + MGST [IN-091] = [IN-091] (for most services)
- Inter-state supply (supplier in Pune, recipient outside MH): IGST at full rate
- Maharashtra GST authority: Maharashtra GST Department (mahagst.gov.in) for state jurisdiction
- CBIC Central Jurisdiction: Based on GSTIN assignment at registration — verify under "know your jurisdiction" on cbic.gov.in

**Audit check:** For all Pune vendor invoices, verify GSTIN starts with 27. Any GSTIN starting with a different state code for a Pune entity = possible wrong state registration or registration in another state with no MH presence.

---

## Key GST Rate Reference (Services — Sep 2025 Notification)

| Service | SAC | GST Rate | Notes |
|---------|-----|----------|-------|
| Manpower supply / labour / staffing | 9985 / 998513 / 998519 | [IN-031] | CGST [IN-091] + MGST [IN-091] (intra-MH) |
| Security services | 998523 | [IN-092] | RCM applies if supplier is sole prop/individual |
| Housekeeping / facility management | 998532 | [IN-092] | — |
| Professional services (CA, legal, consulting) | 9983 | [IN-092] | Common in Pune IT/fin sector |
| IT services / software development | 998314 | [IN-092] | Hinjewadi IT Park — primary sector |
| Works contract — commercial buildings | 9954 | [IN-032] | Pune construction/real estate |
| Works contract — government infrastructure | 9954 | [IN-033] | Specific notified projects only — verify |
| Transportation (GTA) | 9965 | [IN-093] (no ITC) or [IN-093] (with ITC) | MIDC Pune logistics — frequent |
| Rent — commercial premises | 9972 | [IN-092] | Office/warehouse in Pune |
| Training / coaching | 9992 | [IN-092] | Pune IT training firms |
| Auto parts — manufacturing supply | 8700-series HSN | [IN-095]/[IN-095] | Pune auto ancillary — goods, not services |

---

## Reverse Charge Mechanism (RCM) — Pune Businesses

RCM — RECIPIENT (Pune company) pays GST:

| Supply | RCM Rate | Action |
|--------|---------|--------|
| GTA (road transport) | [IN-093] or [IN-093] | Very common in MIDC Pune logistics; recipient pays |
| Legal services by advocate | [IN-097] | Recipient pays; common for Pune corporate legal |
| Security guard services by individual/sole prop | [IN-097] | Recipient (corporate) pays; common in Pune |
| Sponsorship services | [IN-097] | Recipient pays |
| Imports of services | IGST at applicable rate | Common for Pune IT/software companies with foreign clients/vendors |
| Director's remuneration (per GST AAR) | [IN-097] | Company pays (verify specific facts + latest AAR) |

> **MPCB / MIDC context:** If Pune manufacturing company engages a waste disposal contractor who is unregistered — RCM on such supplies (Notification 13/2017-CT Rate) may apply. Verify.

---

## GST Compliance Calendar (Monthly/Quarterly)

| Return | Who files | Monthly due | QRMP scheme |
|--------|-----------|-------------|-------------|
| GSTR-1 | All registered — outward supply | 11th of next month | 13th of month after quarter |
| GSTR-3B | All registered — net liability | 20th of next month (>[IN-099]) | 22nd/24th for QRMP |
| GSTR-9 | Annual — all registered | 31 December of next FY | — |
| GSTR-9C | Reconciliation (turnover >[IN-100]) | 31 December of next FY | — |
| GSTR-7 | TDS deductors u/s 51 CGST | 10th of next month | — |

**Late fee:** GSTR-3B — [IN-101]/day ([IN-101] for nil return); GSTR-1 — [IN-101]/day.
**Interest on late tax payment:** [IN-102] p.a. on net tax payable.

---

## ITC Eligibility — Critical Rules (Sec 16 CGST Act)

ITC available ONLY if ALL conditions met:
1. Tax invoice or debit note from registered supplier in possession
2. Goods/services received
3. **Sec 16(2)(aa) — MOST CRITICAL:** Invoice must appear in GSTR-2B (supplier filed GSTR-1). ITC BLOCKED if supplier hasn't filed.
4. Tax actually paid by supplier to government
5. GSTR-3B return filed by recipient

**ITC BLOCKED (Sec 17(5)):** Motor vehicles, food/beverages, health club memberships, works contract for immovable property, personal use items, CSR expenditure.

---

## e-Invoicing (Pune Context)

| Supplier turnover threshold | Mandatory e-invoice? |
|-----------------------------|---------------------|
| >[IN-103] (any FY since FY 2021-22) | YES — mandatory |
| ≤[IN-103] | No (as at May 2026 — verify latest CBIC notification) |

e-Invoice: Generated on IRP (Invoice Registration Portal) → IRN + QR code mandatory.
**Pune IT/manufacturing suppliers with large turnovers are almost always above [IN-103] threshold.** Verify IRN on their invoices.

**Penalty for non-generation of e-invoice:** Sec 122 CGST — [IN-104] per invoice; ITC denial to buyer.

---

## e-Way Bill (Pune Manufacturing Context)

- Required for goods movement >[IN-105] in value (intra- or inter-state)
- Generated on ewaybillgst.gov.in
- Critical for MIDC Pune factories moving goods to/from customers
- Validity: 200 km per day (revised from 1 day per 100 km — verify latest CGST rule amendment)
- **Pune MIDC:** Goods moving between MIDC units and customers — eWay bill must accompany
- Penalty for movement without eWay bill: Sec 129 CGST — [IN-106] of tax; vehicle detention

---

## GST Audit Procedures (Pune)

1. **GSTR-2B reconciliation (primary test):** Download GSTR-2B for all months → compare ITC claimed in GSTR-3B. Any ITC not in GSTR-2B = Sec 16(2)(aa) — recoverable with [IN-102] interest
2. **Outward supply reconciliation:** GSTR-1 vs. books vs. GSTR-3B — three-way match
3. **Rate verification:** For all vendor invoices — verify SAC/HSN, rate, CGST+MGST split (27-prefix GSTIN = MH)
4. **RCM compliance:** Identify GTA, legal, security, import of service — verify RCM GST paid in GSTR-3B Table 3.1(d)
5. **e-Invoice verification:** For large Pune vendors (likely >[IN-103]) — verify IRN on each invoice against IRP portal
6. **Annual GSTR-9 filing:** Filed by 31 Dec; GSTR-9C if turnover >[IN-100]
7. **IGST vs. CGST+MGST:** Verify place of supply on all invoices — inter-state suppliers must charge IGST (not CGST+MGST)
8. **eWay bill test (manufacturing):** For goods deliveries >[IN-105] — verify eWay bill number on delivery challan

---

## Red Flags — GST (Pune)

- Vendor GSTIN doesn't start with 27 but vendor claims to be Pune-based (possible wrong registration; verify)
- Pune-based vendor charging IGST on an intra-Pune supply (place of supply error — ITC at risk)
- ITC claimed on Sec 17(5) blocked items — especially for Pune IT companies (food, canteen, cabs)
- Large supplier invoice without IRN (e-invoice non-compliance for vendors >[IN-103])
- GSTR-2B mismatch — vendor filed late or not at all (most common GST audit trigger in Pune IT/manufacturing)
- RCM on GTA not paid despite MIDC logistics vendors being GTAs
- Fake GSTIN: Vendor GSTIN cancelled on GST portal but still invoicing (verify every quarter)
- Invoice amounts split across multiple dates to stay below e-invoice threshold
