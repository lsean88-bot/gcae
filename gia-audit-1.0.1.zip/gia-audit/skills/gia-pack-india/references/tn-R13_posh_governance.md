> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- POSH Act 2013 — Sexual Harassment of Women at Workplace
- Whistleblower Mechanism
- Code of Conduct & Ethics
- Related Party Transaction Governance (Recap)
- Data Protection & Privacy (IT/ITES Chennai Context)
- Governance Audit Procedures
- Red Flags — POSH & Governance


# R13 — POSH, Whistleblower & Corporate Governance

## POSH Act 2013 — Sexual Harassment of Women at Workplace

### Applicability
Every employer with ≥ 10 employees — POSH Act applies.
Workplace = any place where work is done, including client sites, travel, and virtual/online.

### Internal Complaints Committee (ICC) — Mandatory for ≥10 employees

| Requirement | Detail |
|-------------|--------|
| Composition | Minimum 4 members: Presiding Officer (senior woman), ≥2 employees, 1 external member (NGO/social worker) |
| Presiding Officer | Senior woman employee — not below managerial level |
| External member | From a list of NGOs/social workers committed to cause of women OR a person familiar with issues relating to sexual harassment |
| Term | 3 years (not exceeding 3 consecutive terms) |
| Quorum | 3 members (including Presiding Officer and external member) for each inquiry |

### Annual Report (Mandatory — Sec 21)
- ICC must submit annual report to employer AND District Officer by **January 31** of each year
- Report must contain: Number of complaints filed, disposed, pending, workshops conducted
- Employer must include summary in Board's Report (if company under Companies Act)

### Employer Obligations — Sec 19
| Obligation | Details |
|-----------|---------|
| Anti-sexual harassment policy | Written policy; circulated to all employees; displayed at workplace |
| ICC constitution | Notified by employer; names displayed |
| Awareness | Workshops/training — at least once a year for all employees |
| Safe environment | Zero tolerance culture; no retaliation against complainant |
| Complaint register | Maintained by ICC; confidential |
| Annual disclosure | In Director's Report (Companies Act 2013 Rule 8(5)(x)) |

### Complaint & Inquiry Process
| Stage | Timeline |
|-------|---------|
| Complaint filing | Within 3 months of incident (extendable by 3 more months by ICC with reasons) |
| Inquiry completion | Within 60 days of receiving complaint |
| Report to employer | Within 10 days of inquiry completion |
| Employer action | Within 60 days of receiving ICC report |
| Interim relief | ICC may recommend interim measures during inquiry (transfer, paid leave) |

### Penalties for Non-Compliance
- Sec 26: Fine up to [IN-134] for first offence; doubled for repeat
- Higher penalties under IPC / BNS (if criminal in nature)
- Labour Court / District Officer inspections

---

## Whistleblower Mechanism

### Companies Act 2013 — Vigil Mechanism (Sec 177(9))
**Mandatory for:**
- Listed companies
- Companies accepting deposits from public
- Companies with Audit Committee

| Requirement | Detail |
|-------------|--------|
| Vigil mechanism / whistleblower policy | Written policy; communicated to all employees and directors |
| Channel | Direct access to Audit Committee Chairperson for genuine concerns |
| Protection | Protection from victimization for good-faith disclosures |
| Policy upload | Disclosed on company website |

### Whistleblower Protection Act 2014 (Public Sector)
Applies to public sector employees and government contractors — not directly to private companies, but Best Practice to align.

### Whistleblower Audit Procedures
1. Verify written vigil mechanism policy exists — check website + internal communication
2. Verify reporting channel accessible to all employees (email, portal, hotline)
3. Review complaints register for last 3 years — any complaints received, investigated, resolved
4. Verify no retaliation cases: Any employee who raised concern — subsequently terminated/demoted? = Red flag
5. Test AC chairperson access: Is channel genuinely independent or routed through management?

---

## Code of Conduct & Ethics

### SEBI LODR (Listed Companies)
- Code of Conduct for Directors and Senior Management: Mandatory; annual compliance declaration
- Insider Trading Policy: SEBI (Prohibition of Insider Trading) Regulations 2015 — trading window closure, structured digital database

### Best Practice for All Companies (Chennai)
| Control | Detail |
|---------|--------|
| Code of Conduct | Written; covers gifts, bribery, conflicts of interest, data protection |
| Gift policy | Maximum gift value (typically [per entity gift policy]–[per entity gift policy]); prohibition on cash gifts |
| Conflict of interest | Annual declaration by all employees; vendor-ownership cross-check |
| ABAC (Anti-Bribery and Anti-Corruption) | Policy aligned to Prevention of Corruption Act 1988 + Companies Act 2013 |
| Third-party due diligence | Vendors, agents, channel partners — ABAC questionnaire |

---

## Related Party Transaction Governance (Recap)

| Requirement | Sec 188 Companies Act 2013 | Board/AC Role |
|-------------|---------------------------|--------------|
| Arm's length test | All RPTs at arm's length | Finance + legal confirms |
| Board approval | Ordinary transactions — Board resolution | AC recommendation first |
| Shareholder approval | Specified threshold exceeded — Ordinary Resolution | AGM/EGM |
| Register MBP-4 | Maintained for all RPTs | Company Secretary |
| Disclosure in financial statements | Ind AS 24 — related party disclosure | Statutory auditor verifies |

---

## Data Protection & Privacy (IT/ITES Chennai Context)

**India's Personal Data Protection Act (DPDPA) 2023:**
- Enacted; rules being finalized as of May 2026 — verify gazette notification for latest implementation timeline
- Applies to: Processing of digital personal data of Indian residents
- Key obligations: Consent, purpose limitation, data minimisation, data localization (for some categories), breach notification (60 days)
- DPA (Data Protection Board) — adjudication of complaints

**Audit implications for HR/Payroll data:**
- Employee personal data processed must have consent or legal basis
- Employee data transferred outside India — verify adequacy/sufficiency rules under DPDPA
- Data retention policy: How long are employee records kept post-separation?

---

## Governance Audit Procedures

1. POSH ICC: Verify constitution notification — names, designation, external member; term not expired
2. POSH policy: Obtain current version — verify displayed at all office locations
3. POSH annual report: Verify submitted to District Officer by Jan 31 each year
4. POSH training: Obtain attendance records for last 3 years — verify all employees covered
5. Complaints register: Verify ICC has independently maintained register (not through HR)
6. Vigil mechanism policy: Verify on company website; obtain complaints log
7. COI declarations: Verify all employees signed annually — cross-check vendor database against HR
8. Board minutes: Verify RPT approvals, POSH report acknowledgement, IC audit committee oversight
9. Director's Report: Verify POSH statement, IFC statement, CSR report, related party disclosures included

---

## Red Flags — POSH & Governance

- ICC not constituted or constitution not notified despite having ≥10 employees
- External member absent or expired term
- POSH annual report never submitted to District Officer
- No POSH training conducted in 2+ years
- Complaint received but no inquiry conducted (liability on employer)
- Vigil mechanism policy not on website or not accessible
- Code of Conduct annual declarations not collected
- Conflict of interest declared but no follow-up action taken
- Board minutes show RPT approvals without Audit Committee prior recommendation
- Related party transactions not at arm's length and not disclosed in financials (Ind AS 24 violation)
