> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- Vendor Onboarding KYC — Mandatory Controls
- Invoice Completeness — CGST Rule 46 Mandatory Fields
- Invoice Validation Checklist (per bill)
- Bill Population Analytics (Multi-Vendor)
- CLRA Contractor Bill Validation Matrix [superseded 21-Nov-2025 — re-map to Code]
- Approved Vendor Master Controls
- Red Flags — Vendor / Contractor


# R09 — Vendor & Contractor Bill Validation

## Vendor Onboarding KYC — Mandatory Controls

| Document | Purpose | Verification Source |
|----------|---------|-------------------|
| GSTIN | GST compliance | gst.gov.in — taxpayer search (not vendor's copy) |
| PAN | TDS rate determination | incometax.gov.in — PAN verification |
| Bank account details | Payment accuracy | Cancelled cheque + Bank letter; penny drop verification |
| CLRA Form V Licence | Contract labour compliance | DLC Chennai register — not from vendor | [superseded 21-Nov-2025 — re-map to Code]
| Company incorporation | Entity type confirmation | MCA21 — CIN search |
| MSME Registration | MSME Act compliance / payment terms | Udyam portal (udyamregistration.gov.in) |
| GST registration state | Intra vs. inter-state | Verify GSTIN state code (33 = Tamil Nadu) |

> **Iron rule:** Verify all vendor credentials from GOVERNMENT PORTALS, not from vendor-provided copies.

---

## Invoice Completeness — CGST Rule 46 Mandatory Fields

Every GST tax invoice MUST contain:

1. Supplier name, address, GSTIN
2. Serial number (unique, within FY, one or multiple series)
3. Date of issue
4. Recipient name, address, GSTIN (for B2B)
5. Place of supply (State name + code) — confirms intra/inter-state
6. HSN / SAC code
7. Description of goods/services
8. Quantity (goods) or units (services — days/hours/head count)
9. Taxable value (after any discount)
10. Tax rate (CGST% + SGST% or IGST%)
11. Tax amount (CGST + SGST or IGST)
12. Total amount payable
13. Whether tax payable on reverse charge (Yes/No)
14. Signature (digital or physical) of supplier or authorized representative
15. **For e-invoice eligible suppliers (turnover >[IN-103]):** IRN + QR Code mandatory

**Incomplete invoice = invalid tax document = ITC ineligible.**

---

## Invoice Validation Checklist (per bill)

### Identity Checks
- [ ] Vendor GSTIN on invoice matches gst.gov.in — ACTIVE registration, not cancelled/suspended
- [ ] GSTIN State code = 33 (Tamil Nadu) for Chennai-based vendor (intra-state supply)
- [ ] PAN on invoice matches incometax.gov.in PAN verification
- [ ] Entity type from PAN (1st 4 letters: XXXP = individual, XXXC = company, XXXF = firm, XXXH = HUF)
- [ ] Invoice is from the same entity as vendor master (no name variation — "SKL" vs "SKL Enterprises" must match GSTIN exactly)

### Tax Computation Checks
- [ ] Taxable value = Gross service value (before tax)
- [ ] GST rate correct for the SAC code stated (SAC 998513 → [IN-031]; verify others via CBIC notification)
- [ ] CGST = [IN-091] × taxable value (intra-state Chennai supply)
- [ ] SGST = [IN-091] × taxable value (intra-state Chennai supply)
- [ ] CGST + SGST + taxable value = Invoice total
- [ ] TDS not deducted on GST portion (CBDT Circular 23/2017; IT Act 2025 equivalent)
- [ ] e-Invoice IRN present and valid (if vendor turnover >[IN-103])

### Service Description Checks
- [ ] Period of service stated (month/dates covered)
- [ ] Number of workers / man-days / hours — sufficient to compute unit rate
- [ ] Implied per-worker rate ≥ applicable TN min wage (Zone A, applicable skill category)
- [ ] SAC code on invoice matches actual service provided (not a generic or incorrect code) [superseded 21-Nov-2025 — re-map to Code]

### EPF/ESIC Component Checks (if billed separately)
- [ ] EPF employee component = [IN-001] of (Basic+DA per worker)
- [ ] EPF employer component = [IN-120] of (Basic+DA per worker) [of which [IN-002] EPS + [IN-003] EPF]
- [ ] EPFO admin = [IN-004]; EDLI = [IN-005] (both capped at [IN-006] wage per worker)
- [ ] ESIC employer = [IN-008] of gross wages (for workers ≤[IN-010] gross)
- [ ] ESIC employee = [IN-009] of gross wages
- [ ] **Post-Nov 2025:** New wages definition applied — allowances >[IN-017] of gross added back to EPF/ESIC base
- [ ] ECR/challan copies provided for the billing period — Rank 1 evidence that contributions remitted

### TDS Application Checks
- [ ] TDS computed on TAXABLE VALUE only (not on GST)
- [ ] Rate applied: Individual/HUF = [IN-023] (Sec 194C); Company = [IN-023]; No PAN = [IN-026]
- [ ] Aggregate billings from vendor in FY: If >[IN-024] — TDS must be deducted even on earlier invoices
- [ ] TDS deduction register entry matched to invoice number and date
- [ ] Challan deposited by 7th of following month (30 April for March)

---

## Bill Population Analytics (Multi-Vendor)

### Completeness Test
```
Expected bills = Vendors × Months in period
Actual bills received = Count from evidence
Gap analysis: Missing = which vendor + which month + reason obtained?
Duplicate alert: Same vendor + same month + same/different amount = explain
```

### Amount Trend Analysis
- Month-on-month change per vendor: >[threshold set in engagement plan] unexplained change = investigate
- Same total across vendors in same month = collusion red flag
- Round-number total invoices (e.g. exact [just-below-threshold value] or [just-below-threshold value]) = threshold manipulation

### Benford's Law Application
- Extract all bill amounts (both taxable and total)
- Benford and digit tests: run through `gia-fraud:gia-fraud-analytics` (Nigrini MAD primary with per-digit z-scores; chi-square supplementary for small populations). Confirm the preconditions (population size, range across orders of magnitude, no assigned or bounded numbers), segment fixed-amount populations first, and record the MAD table version in the workpaper. A deviation is an indicator, never a conclusion. Inline thresholds from the retired source were removed.

- Focus: Excess of digits 1-3 near [IN-024] (194C threshold) = invoice splitting
- Focus: Excess of digits near round numbers = manually keyed (not system-generated) amounts

### Cross-Vendor Duplicate Tests
- Same GST number across two vendors = same entity, multiple billing
- Same PAN across two vendors = same beneficial owner
- Same bank account across two vendors = payment diversion risk
- Same address across two vendors = shell entity pattern

---

## CLRA Contractor Bill Validation Matrix

| Test | Source | Finding if failed |
|------|--------|-----------------|
| Verify Form V licence — valid for period | DLC Chennai (Rank 1) | Unlicensed contractor — CLRA Sec 7 violation; principal employer CLRA Sec 21(4) liability | [superseded 21-Nov-2025 — re-map to Code]
| Worker count on bill ≤ Form V licence headcount | Bill vs. Form V | Excess workers = licence violation |
| Form V licence covers the type of work billed | Form V description vs. bill | Licence scope mismatch |
| CLRA Form XIII (register of contractors) — vendor listed | Internal register | Unregistered contractor | [superseded 21-Nov-2025 — re-map to Code]
| Minimum wage per worker implied by bill ≥ TN gazette rate | Bill calculation | Minimum Wages Act 1948 violation | [superseded 21-Nov-2025 — re-map to Code]

---

## Approved Vendor Master Controls

| Control | Description |
|---------|-------------|
| Dual authorization | New vendor setup: proposed by requesting dept + approved by Finance/Procurement + verified by internal audit |
| GSTIN + PAN validation | Portal-verified before onboarding |
| Bank account verification | Penny drop ([nominal amount] test transfer) + signed bank letter |
| Periodic review | Annual revalidation of all active vendors — GSTIN active, no bankruptcy/deregistration |
| Related party check | Vendor owner / director = company employee / director / relative → flag as RPT |
| Price benchmarking | Rates compared to market and other vendors for same services |
| Concentration risk | Any one vendor >[threshold set in engagement plan] of category spend → single-source risk |

---

## Red Flags — Vendor / Contractor

- GSTIN cancelled or not found on portal
- Entity name on invoice different from vendor master
- PAN type implies individual but invoices are very large (e.g. [materiality threshold set in engagement plan]+) with no incorporation details
- Invoice serial numbers non-sequential across months (indicates invoices issued selectively, not from running series)
- Service description generic: "Services rendered" or "Labour charges" without worker count, period, or rate
- No CLRA Form V available from DLC — contractor submits self-prepared copy [superseded 21-Nov-2025 — re-map to Code]
- EPF/ESIC billed but no challan copies provided
- Invoice date and service period inconsistent (e.g. Jan bill raised in March)
- Multiple vendors sharing similar registered address (search on gst.gov.in taxpayer search by address)
- Bill amounts consistently just below [IN-024] (Sec 194C threshold avoidance)
- Total vendor spend increasing without corresponding increase in output/headcount
