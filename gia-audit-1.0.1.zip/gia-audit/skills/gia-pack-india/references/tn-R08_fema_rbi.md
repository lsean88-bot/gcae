> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- Overview — Applicability to Chennai Businesses
- FDI — Foreign Direct Investment
- ECB — External Commercial Borrowings
- Export of Services (IT/ITES — Chennai's Primary Sector)
- Import Compliance
- Expat / NRI Employees in Chennai
- RBI — Domestic Banking Compliance
- FEMA / RBI Audit Procedures
- Red Flags — FEMA / RBI


# R08 — FEMA 1999, RBI & Cross-Border Transactions

## Overview — Applicability to Chennai Businesses

FEMA 1999 governs ALL cross-border transactions for Indian residents/entities. Most relevant for:
- IT/ITES companies in Chennai (service exports, software exports, BPO/KPO)
- Manufacturing companies with export/import operations
- Companies with FDI (foreign investment) or foreign investors
- Companies with ECB (External Commercial Borrowing)
- Companies with ODI (Overseas Direct Investment)
- NRI/expat employees

**Regulator:** Reserve Bank of India (RBI) via Authorized Dealer (AD) banks.
**Penalty for violation:** FEMA Sec 13 — up to 3× amount involved; compounding available for most violations.

---

## FDI — Foreign Direct Investment

### Automatic Route (No RBI/FIPB approval needed)
- Most sectors: IT, manufacturing, services, trading — automatic up to specified caps
- Reporting mandatory: FC-GPR (within 30 days of receiving FDI); FC-TRS (on transfer of shares)
- Annual filing: FLA (Foreign Liabilities & Assets) Return — by July 15 via RBI portal (FLAIR)

### Prohibited Sectors (No FDI)
- Lottery, gambling, chit funds, Nidhi company, real estate business (not construction), tobacco manufacturing, atomic energy

### Key RBI Filing Requirements
| Event | Form / Report | Due Date | Portal |
|-------|--------------|---------|--------|
| Receipt of FDI | FC-GPR | Within 30 days of allotment | FIRMS (RBI portal) |
| Transfer of shares (FDI) | FC-TRS | Within 60 days of transaction | FIRMS |
| Annual FDI stock | FLA Return | July 15 every year | RBI FLAIR portal |
| ODI (overseas investment) | Form ODI | Before investment (if approval route) or within 60 days (auto) | FIRMS |
| ECB — borrowing | Form ECB | Before drawdown | FIRMS (via AD bank) |
| ECB — repayment | Form ECB 2 | Monthly | FIRMS |

---

## ECB — External Commercial Borrowings

### Track I — Medium-Term (3-year minimum average maturity)
- Manufacturing, infrastructure sectors
- Maximum amount: As per RBI Master Direction

### Track III — Indian Rupee-denominated bonds
- FEMA notification compliance required

### Key Compliance
- End-use restrictions: Cannot use for real estate, capital market, equity investment, general working capital beyond specified limits
- All-in cost ceiling: As per RBI Master Direction (verify current — changes frequently)
- Hedging: Mandatory for ECB in certain categories
- Form ECB-2: Monthly reporting through AD bank (last business day of following month)

---

## Export of Services (IT/ITES — Chennai's Primary Sector)

### FEMA Compliance for Software/Service Exports
- Proceeds must be repatriated to India within specified time:
  - Software exports: 9 months from date of export
  - Other services: 9 months
- FIRC (Foreign Inward Remittance Certificate) must be obtained from AD bank for each receipt
- SOFTEX Form: Mandatory for software exports >US$25,000 (single export or aggregated monthly)
  - Filed electronically with STPI or SEZ authority as applicable
  - Monthly aggregation permitted for exports ≤US$25,000/per transaction
- DGFT: RCMC (Registration Cum Membership Certificate) for export benefit schemes

### Export Benefits Available (Chennai exporters)
- SEIS (Services Export from India Scheme) — verify current DGFT notification
- IGST exemption on exports (zero-rated supply) — bond/LUT required; file Form RFD-11
- SEZ units: Duty-free procurement; IT Act exemption (verify IT Act 2025 provisions)

---

## Import Compliance

- AD Category I bank authorization for import payments
- Import documentation: Invoice, packing list, bill of lading/airway bill, customs assessed BE
- Advance payment: Allowed up to USD 2,50,000 without documents; above — CA certificate or AD bank verification
- Interest on import payments: FEMA Sec 10 — buyer credit permitted up to RBI norms

---

## Expat / NRI Employees in Chennai

| Aspect | Requirement |
|--------|-------------|
| Work visa | Employment Visa (E-Visa) — Ministry of Home Affairs |
| Tax residency | Number of days in India — IT Act 2025 test |
| TDS on salary | Sec 192 (IT Act 2025) — employer deducts; DTAA benefits only if Form 10F + Tax Residency Certificate submitted |
| FEMA — expat remittances | Permitted through AD bank; FEMA Sec 6(4) — current account transaction |
| ESIC | International workers: Contribution at standard rates; benefits available; social security agreements with some countries |
| EPF | International Workers (IW) ECR required; separate schedule |
| Shadow payroll | If dual employment (home country + India) — Indian payroll must be structured |

---

## RBI — Domestic Banking Compliance

| Requirement | Detail | Regulator |
|-------------|--------|---------|
| KYC / AML | PMLA 2002 + RBI KYC Master Direction | Financial Intelligence Unit (FIU-IND) |
| Cash transactions >[IN-088] | PAN mandatory | IT Act 2025 / Rule 114B |
| Cash deposit >[IN-089] | SFT (Statement of Financial Transaction) reporting by bank | CBDT |
| Cash receipt >[IN-087] | Sec 269ST IT Act 1961 (equivalent in IT Act 2025) — prohibition | IT Department |
| Loan from directors / shareholders | FEMA / Companies Act — foreign = ECB; Indian = Sec 185 restriction | RBI / MCA |
| Bank charges & forex rates | Compare to interbank benchmark; overcharging = basis risk | Negotiate with bank |

---

## FEMA / RBI Audit Procedures

1. For IT/service companies: Verify FIRC for each foreign receipt — cross-match to debtors ledger; test repatriation within 9 months
2. Verify SOFTEX submissions — monthly aggregate verified with AD bank / STPI certificate
3. FLA Return: Verify filed by July 15; cross-check with audited FY financials
4. For FDI-received companies: Verify FC-GPR within 30 days of all equity allotments
5. For ECB: Verify Form ECB-2 filed monthly; verify end-use compliance (no capital market / real estate deployment)
6. Expat employees: Verify Employment Visa; verify DTAA relief documentation (Form 10F + TRC); verify shadow payroll if applicable
7. Test Sec 269ST compliance: No single receipt of >[IN-087] in cash from any person in any mode — review cash receipts register

---

## Red Flags — FEMA / RBI

- Foreign remittances not matched to FIRC (possible unrecorded foreign income)
- SOFTEX not filed or filed late (STPI/SEZ penalty risk)
- FLA Return not filed (compounding required; common missed compliance for startups)
- ECB proceeds deployed in working capital beyond permitted limits or in prohibited sectors
- Round-tripping: FDI origin traceable back to Indian resident (FEMA Sec 3 — prohibited)
- Cash receipts from customers >[IN-087] (Sec 269ST IT Act violation + 100% penalty)
- Director loans to company without proper RBI/Companies Act compliance
- Export invoices raised but remittance not received within 9 months (FEMA notice risk)
