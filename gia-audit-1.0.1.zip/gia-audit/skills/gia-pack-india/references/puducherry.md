> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.

# Puducherry (UT) operations audit

## Status and how to use this skill

This skill was built on 2026-10-10 from web research. The Puducherry Labour Department site blocks automated access, so most items are rated from secondary sources (compliance vendors, practitioner guides) and official-site search snippets. It is a **map and a method, not an authority**. Rules:

1. Run `python3 -I ${CLAUDE_PLUGIN_ROOT}/skills/gias-navigator/scripts/check_rates.py` before any statutory recompute, and treat every value here as a lead until the CAE or counsel has verified it against the official notification, Gazette or department order.
2. Never state a Puducherry rate, slab or threshold from this skill in a workpaper without a verified source and date. Where it says "verify", the answer is not known.
3. Puducherry is a Union Territory with its own rules and its own labour department. Do not apply Tamil Nadu or Maharashtra state rules by analogy. Central laws apply, UT rules differ, and some Acts have been replaced by the four Labour Codes.
4. Confidence labels: V = several independent professional sources agree; S = one or two secondary sources or an official page seen only as a snippet; U = unverified or conflicting.

## What applies (and how sure we are)

| Area | What is reported | Conf. | Verify with |
|---|---|---|---|
| Labour Codes | Four Codes reported in force [IN-018]; central and UT rules and transitional provisions determine which old Acts and rules still operate. Draft Puducherry Code on Wages Rules circulated in 2026 | V (Codes), S (UT rules) | Gazette of India; Puducherry Gazette; Labour Department |
| EPF/EPS/EDLI | Central scheme. Wage ceiling revised by S.O. 5109(E) (old and new ceiling and effective date: [IN-006]); contribution rates unchanged; a pay period that straddles the effective date needs a split calculation | V | Gazette notification; EPFO FAQs |
| ESIC | Central scheme. Wage ceiling reported 21,000 (unchanged) | S | ESIC circulars |
| Minimum wages | Puducherry Labour Department final notification (shops and establishments) dated 09-09-2024 is listed on the department site; factories and other scheduled employments carry separate rates and zones. Values not recorded here | S | The notification applying to the unit's scheduled employment, effective date, VDA/DA components |
| Shops and Establishments Act, 1964 | The department lists an order exempting establishments registered under the OSH&WC Code from registration and renewal under the 1964 Act, and a 15/03/2026 notification on 24x7 operation and women in night shifts. Conditions not read | S | The orders themselves |
| Profession tax | Reported as a local-body levy under the Puducherry Municipalities Act, 1973 and Village and Commune Panchayats Act, 1973 (1976 Rules), not a state-wide professional tax Act; slabs differ between sources | S | The municipality or commune panchayat that covers the unit |
| Labour welfare fund | One 2026 table says none applies | U | Department; payroll registrations |
| Contract labour | Central framework (CLRA, now the OSH Code) with threshold and licensing rules; UT specifics not verified | U | OSH Code and Puducherry rules; licence copies | [superseded 21-Nov-2025 — re-map to Code]
| Bonus, gratuity, payment of wages | Central; moving under the Code on Wages and Code on Social Security | V (central) | Current Code provisions and rules |
| POSH | Central Act; Internal Committee required where 10 or more employees | V (central) | Constitution orders, annual report to the District Officer |
| Factories and OSH | Factory licence and registration with the UT authority under the Factories Act or OSH Code; safety officer, medical, canteen thresholds apply as per the applicable law | U (UT specifics) | Licence, rules in force, inspection reports | [superseded 21-Nov-2025 — re-map to Code]
| Pollution | Consent to establish and operate from the UT pollution control committee (name and consent categories to confirm); hazardous and e-waste authorisations where relevant | U | Consent orders; validity dates |
| GST | State code 34 (GSTINs begin 34) | V | GSTIN records |
| Company law | A Registrar of Companies for Puducherry is described by several sources; one mentions a 2026 redrawing of Registrar jurisdictions | S | MCA site for the filing concerned |

## Audit approach

Follow the standard lifecycle under `gcgo-orchestrator` and `gia-evidence-discipline` (scope lock, criteria register, evidence register, approved procedures). Specific to Puducherry:

1. **Criteria register first.** For each row above that matters to the scope, obtain the primary notification or order, record the CRIT ID, clause, effective dates and who confirmed applicability. Mark anything not obtained as an evidence gap; do not fill it from this table.
2. **Payroll and statutory deductions.** Build an effective-dated rate table (with source and verified-on date), run `check_rates.py`, then `audit_analytics.py payroll-recompute --period-start ...`. Pay periods that straddle a change (September 2026 for EPF) are reported as gaps or range tests: confirm the period-wise method required by the notification.
3. **Minimum wages.** Compare actual wages by grade and zone with the notified schedule for the unit's scheduled employment, including components that count towards the wage. Apprentices, trainees and contract workers need separate treatment.
4. **Contract labour.** Principal employer and contractor licences, wage register and payment evidence, EPF/ESIC coverage of contract workers, and who actually pays. Check licence validity dates with `audit_analytics.py expiry`.
5. **Registrations and licences calendar.** Factory licence, pollution consent, fire safety, GST, profession tax registrations, trade licence: record validity dates and feed them to the monitoring watchlist.
6. **Fraud and conflict indicators.** Master-data overlaps between employees and vendors, payroll without attendance, round-sum contractor invoices and split purchases: use the analytics procedures as leads, and follow the confidentiality rules (need-to-know, no lookups on named individuals without approval).
7. **Reporting.** Cite only verified criteria. Separate "policy departure" from "statutory non-compliance": the latter needs the legal requirement and its applicability confirmed. Legal interpretation goes to counsel.

## Evidence to request

Latest notifications relied on (minimum wage schedule, any UT Code rules), licence and registration copies with validity, EPF/ESIC returns and challans with ECR, wage and attendance registers, contractor agreements and licences, profession tax receipts, POSH committee orders and report, pollution consents, GST returns, board and ROC filings as scoped.

## Known gaps in this skill

- No primary UT notification was opened by Claude; minimum wage values, profession tax slabs, LWF status, contract-labour thresholds and factory-law specifics are unverified.
- The UT Code rules were in draft in the sources seen; their final status at the audit date is unknown.
- Entity assignment: no group entity is mapped to Puducherry in the registry. Confirm which entity and licences are in scope.

See `references/puducherry-verification-register.md` for each claim, its source and how to verify it.
