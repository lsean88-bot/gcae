> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.

# Payroll & Salary Structure — Chennai HR Audit Reference

## CTC Architecture — Typical Indian Manufacturing/IT (Chennai)

| Component | Tax Treatment | Audit Test |
|-----------|--------------|------------|
| Basic Salary | Fully taxable | Foundation for EPF, Gratuity, HRA calc |
| HRA | Sec 10(13A) partial exemption | Actual receipts + Chennai metro = [IN-082] Basic |
| Special Allowance | Fully taxable | Most common "filler" component — test for suppression |
| Conveyance | Fully taxable post-2018 (standard deduction replaces) | Verify no double benefit |
| LTA | Sec 10(5) — biennial, actual travel | Travel bills, rail/air tickets |
| Medical Reimbursement | Fully taxable post-2018 | Absorbed into standard deduction [IN-080] |
| Company Car | Perquisite — Rule 3 | Compute taxable value; verify Form 16 Part B |
| ESOP/RSU | Sec 17(2)(vi) — taxable on exercise | Verify employer TDS on exercise date |
| NPS Contribution (Employer) | Sec 80CCD(2) — up to [IN-081] of Basic | Verify NPS account, CRA portal |
| Gratuity (Employer provision) | Not taxable during service; taxable on exit above ceiling | Verify actuarial provision |
| PF (Employer) | Not taxable | Verify on Form 16 Part B |

## Tax Regime Election (FY 2024-25 onwards)
- New regime is DEFAULT from AY 2024-25 (FY 2023-24)
- Employee must file Form 10-IEA to opt old regime
- Employer must honour election — verify Form 10-IEA in HR file for all claiming old regime
- New regime: no exemptions (HRA, LTA, 80C/D inoperative); lower slab rates
- Old regime: all deductions/exemptions available

## Slab Rates FY 2025-26 (New Regime — web-validate)
| Income Slab (₹) | Rate |
|----------------|------|
| Up to 4,00,000 | Nil |
| 4,00,001 – 8,00,000 | [IN-078] |
| 8,00,001 – 12,00,000 | [IN-078] |
| 12,00,001 – 16,00,000 | [IN-078] |
| 16,00,001 – 20,00,000 | [IN-078] |
| 20,00,001 – 24,00,000 | [IN-078] |
| Above 24,00,000 | [IN-078] |
*Rebate u/s 87A: up to [IN-079] taxable income in new regime — verify current notification*

## Section 43B(h) — Salary/Wages Payment Timing
- Wages/salary disallowed as deduction unless paid within due date (EPF/ESI) or before ITR filing
- Test: are statutory wages paid to employees/contractors on time?

## Common Salary Structuring Red Flags
1. Basic < [IN-017] of CTC (suppresses EPF, Gratuity, Bonus base)
2. HRA paid to employees living in company-owned/leased accommodation
3. Multiple allowances created to fragment salary below audit thresholds
4. Salary components changed post-increment without HR approval trail
5. Consultants paid on payroll (no appointment letter → tax and EPF evasion)
6. Directors' remuneration not approved by Board/shareholders (Companies Act 2013 Sec 197)
