> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.

# Puducherry verification register (2026-10-10)

Every statement in SKILL.md that is not marked V needs verification. This register lists the source behind each claim so the checker can see how strong it is. Source types: **official snippet** = seen only as text in a search result (the department site blocks automated fetching); **vendor** = compliance or payroll vendor; **firm** = audit or advisory firm alert; **forum** = practitioner forum.

| # | Claim | Source (type) | Retrieved | Confidence | How to verify |
|---|---|---|---|---|---|
| 1 | EPF/EPS wage ceiling revision [IN-006] (S.O. 5109(E)) | BDO alert (firm); EPFO FAQ reproduced by SGCMS (regulator FAQ via vendor); Upstox (news); CiteHR (forum) | 2026-10-10 | V | Gazette of India notification; EPFO FAQ on epfindia.gov.in |
| 2 | Rates unchanged; September 2026 ECR due 15 Oct; first full month October | SGCMS FAQ reproduction; HRMantra (vendor) | 2026-10-10 | S | EPFO circular on implementation |
| 3 | Labour Codes in force [IN-018] | HRTailor guide (vendor) and others | 2026-10-10 | V | Ministry of Labour notification |
| 4 | Draft Puducherry Code on Wages Rules circulated | Lexplosion PDF (vendor) | 2026-10-10 | S | Puducherry Gazette |
| 5 | Minimum wage final notification for shops and establishments dated 09-09-2024 | Labour Dept page title (official snippet); Simpliance (vendor) | 2026-10-10 | S | Department notification; schedule and zones |
| 6 | Registration under OSH&WC Code exempts from S&E Act registration/renewal; 24x7 notification dated 15/03/2026 | Labour Dept What's New (official snippet) | 2026-10-10 | S | Read the orders and their conditions |
| 7 | Profession tax is a local-body levy under 1973 Acts and 1976 Rules; slabs differ by source | Simpliance; Kanoon Mitra (vendors) | 2026-10-10 | S | Municipality or commune panchayat |
| 8 | LWF not applicable | Kanoon Mitra table (vendor) | 2026-10-10 | U | Labour Department; payroll registrations |
| 9 | GST state code 34 | GSTIN records; several vendors | 2026-10-10 | V | GST portal |
| 10 | RoC Puducherry exists; 2026 jurisdiction notification mentioned | Taxaj; QwikFilings (vendors) | 2026-10-10 | S | MCA site |
| 11 | ESIC ceiling 21,000 unchanged | HRMantra (vendor) | 2026-10-10 | S | ESIC circulars |

Machine-readable gate: `skills/gias-navigator/scripts/check_rates.py` reads the statutory register rows.
