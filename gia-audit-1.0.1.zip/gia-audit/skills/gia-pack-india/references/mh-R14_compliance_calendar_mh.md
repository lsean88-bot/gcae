> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- Monthly Recurring Obligations
- Quarterly Obligations
- Annual / Periodic Compliance Calendar — Maharashtra / Pune
- Penalty Quick Reference — Maharashtra / India


# R14 — Pune / Maharashtra / India Compliance Calendar (FY 2025-26 & 2026-27)

> **Audit use:** Extract the relevant period's due dates. Test whether each obligation was met on time.
> Late compliance = finding. Non-compliance = finding + quantified penalty.
> **Maharashtra-specific:** Always verify bi-annual min wage and PT notices on mahakamgar.gov.in and mahagst.gov.in before each engagement.

---

## Monthly Recurring Obligations

| Due Date | Obligation | Statute | Portal / Authority |
|---------|-----------|---------|-------------------|
| 7th | TDS challan deposit (Apr–Feb payments) | IT Act 1961/2025, Rule 30 | TRACES (Challan 281) |
| 10th | GSTR-7 (TDS deductors u/s 51 CGST) | CGST Act 2017 | gst.gov.in |
| 10th | GSTR-8 (TCS e-commerce operators) | CGST Act 2017 | gst.gov.in |
| 11th | GSTR-1 (monthly — outward supply) | CGST Act Rule 59 | gst.gov.in |
| 13th | IFF (QRMP optional invoice filing) | CGST Act | gst.gov.in |
| 15th | EPF ECR + challan | EPF Act 1952, Para 38 | epfindia.gov.in |
| 15th | ESIC ECR + challan | ESI Act 1948, Sec 40 | esic.gov.in | [superseded 21-Nov-2025 — re-map to Code]
| 20th | GSTR-3B (monthly — >[IN-099] turnover) | CGST Act Rule 61 | gst.gov.in |
| 22nd/24th | GSTR-3B (QRMP scheme) | CGST Act | gst.gov.in |
| Last business day | ECB-2 (if ECB outstanding) | FEMA 1999 / RBI | FIRMS via AD bank |
| Last day (large PT payers) | PTRC monthly return (Form III-B) — if annual PT >[IN-142] | MH PT Act 1975 | mahagst.gov.in |

---

## Quarterly Obligations

| Quarter | Due Date | Obligation | Statute | Portal |
|---------|---------|-----------|---------|--------|
| Q1 (Apr–Jun) | **31 Jul** | Form 24Q + 26Q + 27Q + 27EQ | IT Act, Rule 31A | TRACES |
| Q2 (Jul–Sep) | **31 Oct** | Form 24Q + 26Q + 27Q + 27EQ | IT Act, Rule 31A | TRACES |
| Q3 (Oct–Dec) | **31 Jan** | Form 24Q + 26Q + 27Q + 27EQ | IT Act, Rule 31A | TRACES |
| Q4 (Jan–Mar) | **31 May** | Form 24Q + 26Q + 27Q + 27EQ | IT Act, Rule 31A | TRACES |
| March payments | **30 Apr** | TDS challan for March | IT Act Rule 30 | TRACES |

---

## Annual / Periodic Compliance Calendar — Maharashtra / Pune

### Direct Tax

| Due Date | Obligation | Applicable To | Statute |
|---------|-----------|-------------|---------|
| 15 Jun | 1st advance tax instalment ([IN-075]) | Companies + individuals | IT Act |
| 31 Jul | ITR — individuals (not audit required) | Individuals | IT Act |
| 15 Sep | 2nd advance tax instalment ([IN-075]) | All | IT Act |
| 30 Sep | Tax audit report (Form 3CA + 3CD) | Business turnover above threshold | IT Act |
| 15 Oct | ITR — companies (with audit, no TP) | Companies | IT Act |
| 31 Oct | ITR — businesses requiring audit | Firms, LLPs | IT Act |
| 30 Nov | ITR — TP cases | International related-party transactions | IT Act |
| 15 Dec | 3rd advance tax instalment ([IN-075]) | All | IT Act |
| 31 Dec | Belated / revised ITR | All | IT Act |
| 15 Mar | 4th advance tax instalment (100%) | All | IT Act |
| 15 Jun | Form 16 to employees | All employers | IT Act Rule 31 |
| 15 Jun | Form 16A to vendors | All deductors | IT Act Rule 31A |

---

### GST

| Due Date | Obligation | Applicable To |
|---------|-----------|-------------|
| 11th monthly | GSTR-1 | Monthly filers |
| 20th monthly | GSTR-3B | Monthly >[IN-099] |
| 31 Dec (next FY) | GSTR-9 (Annual) | All registered |
| 31 Dec (next FY) | GSTR-9C (Reconciliation) | Turnover >[IN-100] |
| Within 3 months | ITC reversal (if GSTR-2B mismatch not resolved) | All ITC claimants — CGST Rule 37A |

---

### HR / Payroll / Labour — Maharashtra

| Due Date | Obligation | Statute | Authority |
|---------|-----------|---------|---------|
| 7th of following month | TDS challan (salary + contractor deductions) | IT Act | TRACES |
| 15th of following month | EPF ECR + challan | EPF Act 1952 | epfindia.gov.in |
| 15th of following month | ESIC ECR + challan | ESI Act 1948 | esic.gov.in | [superseded 21-Nov-2025 — re-map to Code]
| Last day of month | PTRC monthly return (Form III-B) — large PT payers | MH PT Act 1975 | mahagst.gov.in |
| **31 January** | Form 26Q Q3 TDS return | IT Act | TRACES |
| **31 January** | POSH ICC Annual Report to District Officer, Pune | POSH Act 2013, Sec 21 | District Officer Pune |
| **31 January** | MH Factories — Annual Return Form 21 (for prior calendar year) | Factories Act 1948 | Inspector of Factories Pune | [superseded 21-Nov-2025 — re-map to Code]
| **15 February** | CLRA Annual Return (Form XXV) — to ACL Pune | CLRA 1970, Rule 82 | ACL Pune | [superseded 21-Nov-2025 — re-map to Code]
| **15 February** | MLWB Annual Return | MH LWF Act 1953 | mlwb.in |
| **28/29 February** | Mathadi Board half-year return (Oct–Mar period) — verify MLWB notification | Mathadi Act 1969 | Mathadi Board Pune |
| **30 April** | TDS challan for March payments | IT Act Rule 30 | TRACES |
| **30 April** | PTEC Annual Payment — professional tax on entity | MH PT Act 1975 | mahagst.gov.in |
| **30 April** | MSME Form I — outstanding dues Apr–Sep | MSMED Act 2006 | MCA21 |
| **31 May** | Form 24Q + 26Q Q4 TDS return | IT Act Rule 31A | TRACES |
| **30 June** | MH LWF — half-year 1 (Jan–Jun) remittance | MH LWF Act 1953 (revised Mar 2024) | mlwb.in |
| **30 June** | PTEC — professional tax payment (if enrolled before 31 May) | MH PT Act 1975 | mahagst.gov.in |
| **31 July** | MH Factories — Half-Yearly Return Form 22 (Jan–Jun) | Factories Act 1948 | Inspector of Factories Pune | [superseded 21-Nov-2025 — re-map to Code]
| **1 July** | MH Min Wages — mid-year VDA revision effective | Min Wages Act 1948 (MH notification) | mahakamgar.gov.in |
| **31 July** | GSTR-9 / GSTR-9C annual return due (for some extensions — verify) | CGST Act | gst.gov.in |
| **30 September** | MPCB Environmental Statement (Form V) — for prior year | Water Act 1974 + Air Act 1981 | ecmpcb.in |
| **30 September** | DIR-3 KYC (Director KYC update) | Companies Act 2013, Rule 12A | MCA21 |
| **30 October** | MSME Form I — outstanding dues Oct–Mar | MSMED Act 2006 | MCA21 |
| **30 November** | Bonus payment deadline (Apr–Mar FY) | Payment of Bonus Act 1965, Sec 19 | Internal + Labour Dept | [superseded 21-Nov-2025 — re-map to Code]
| **31 December** | MH Factories — annual licence (Form 2) renewal | Factories Act 1948 + MH Factories Rules 1963 | Inspector of Factories Pune | [superseded 21-Nov-2025 — re-map to Code]
| **31 December** | MH LWF — half-year 2 (Jul–Dec) remittance | MH LWF Act 1953 | mlwb.in |
| **31 December** | GSTR-9 / GSTR-9C | CGST Act | gst.gov.in |
| **1 January** | MH Min Wages — annual VDA revision effective | Min Wages Act 1948 (MH notification) | mahakamgar.gov.in |

---

### Company Law — Key Annual Dates (Pune / ROC Pune)

| Due Date | Obligation | Form | Portal |
|---------|-----------|-----|--------|
| AGM by 30 Sep | Annual General Meeting | — | Company records |
| 30 days from AGM | Financial Statements | AOC-4 / AOC-4 CFS | MCA21 (ROC Pune) |
| 60 days from AGM | Annual Return | MGT-7 / MGT-7A | MCA21 (ROC Pune) |
| 15 days from AGM | Auditor appointment | ADT-1 | MCA21 |
| 30 Sep | Director KYC | DIR-3 KYC | MCA21 |
| 31 Oct | MSME Form I (half-yearly) | MSME Form I | MCA21 |
| 30 Apr | MSME Form I (half-yearly) | MSME Form I | MCA21 |
| 30 days of charge creation | Charge registration | CHG-1 | MCA21 (ROC Pune) |
| With AOC-4 | CSR-2 (if CSR applicable) | CSR-2 | MCA21 |

> **ROC Pune note:** All MCA21 filings for Maharashtra (non-Mumbai) companies must show ROC Pune jurisdiction. Post-16 Feb 2026 realignment — verify correct ROC on MCA21 for every entity.

---

### FEMA / RBI

| Due Date | Obligation | Form | Portal |
|---------|-----------|-----|--------|
| Within 30 days of FDI allotment | FDI receipt | FC-GPR | FIRMS (RBI) |
| Within 60 days of share transfer | FDI transfer | FC-TRS | FIRMS |
| **15 July** each year | FLA Annual Return | FLA | FIRMS / RBI |
| Last business day monthly | ECB repayment | ECB-2 | FIRMS via AD bank |
| Within 9 months | Export proceeds repatriation | — | AD bank |
| Monthly (STPI Pune units) | SOFTEX submission | SOFTEX | STPI Pune |

---

### Environment / Local Body — Pune

| Due Date | Obligation | Authority |
|---------|-----------|---------|
| Before expiry | MPCB CTO renewal | ecmpcb.in |
| **30 Sep** | MPCB Environmental Statement (Form V) | ecmpcb.in |
| **31 May** | Hazardous waste annual return | ecmpcb.in |
| Before expiry | PMC / PCMC Trade Licence renewal | PMC / PCMC |
| Before expiry | Pune Fire Brigade Fire NOC renewal | PMC Fire Dept |
| **31 Dec** | Factory licence (Form 2 MH) renewal | Inspector of Factories Pune |
| Annual | Legal Metrology instrument calibration | Dept of Legal Metrology Pune |
| Half-yearly | Hazardous waste Form 3 manifest | MPCB |

---

## Penalty Quick Reference — Maharashtra / India

| Violation | Penalty |
|-----------|---------|
| Late TDS challan | Sec 234E — [IN-073]/day; Sec 271H — [IN-073]–[IN-073] |
| TDS not deducted | Sec 40(a)(ia) — [IN-074] expense disallowance; Sec 276B — prosecution |
| Late GSTR-3B | [IN-101]/day ([IN-101] nil return); [IN-102] p.a. interest |
| Late GSTR-1 | [IN-101]/day |
| Late EPF remittance | Sec 7Q — [IN-123] p.a.; Sec 14B — damages up to [IN-007] |
| Late ESIC remittance | Sec 85B — [IN-125] p.a. |
| MH min wages violation | Min Wages Act — fine + imprisonment; back-wages to workers |
| MH S&E Act non-registration (≥20 empl.) | MH S&E Act 2017 — [IN-146]–[IN-146] (post-Oct 2025 amendment) |
| CLRA non-compliance | Fine [IN-131]; repeat + imprisonment | [superseded 21-Nov-2025 — re-map to Code]
| Bonus not paid (by Nov 30) | Bonus Act Sec 28 — [IN-127] + imprisonment 6 months |
| MH LWF not remitted | MH LWF Act Sec 10 — recoverable + fine |
| PT non-registration | MH PT Act — [IN-143]/day |
| PT late payment | [IN-143] of tax due + [IN-143]/month interest |
| POSH ICC not constituted | POSH Act Sec 26 — [IN-134] first; doubled for repeat |
| ROC annual return late | MGT-7: [IN-110] + [IN-110]/day |
| AOC-4 late | [IN-109]/day |
| MSME Form I not filed | [IN-112] |
| MPCB CTO expired | Closure order + prosecution; fine [IN-135]+ |
| Hazardous waste violation | EPA 1986 — fine [IN-135] + 5 years imprisonment |
| PMC Trade Licence expired | Sealing + fine |
| Factory Licence expired | Factories Act — factory operations illegal | [superseded 21-Nov-2025 — re-map to Code]
| Cash payment >[IN-028]/day | IT Act — 100% disallowance of expense |
| Cash receipt ≥[IN-087] | Sec 269ST — 100% penalty on amount |
| Sec 269ST violation | Penalty equal to amount received in cash |
| FLA Return not filed | FEMA Sec 13 — 3× amount involved; compounding available |
| SOFTEX not filed (STPI Pune) | FEMA + STPI penalty |
