> Ported workflow from the retired ops-audit skill. Statutory values are in `statutory-register-india.md` only. Domain files are named `mh-R01...R14` in this folder. Safeguards and evidence rules are in `gia-core:iron-rules`. Standard numbers cited below are as stated in the source; confirm via `gias-navigator`.
## Contents
- SKILL ARCHITECTURE
- Step 0 — Pre-Engagement Mandatory Checks
- Step 1 — Entity & Engagement Context (Evidence-Based)
- Step 2 — Document Inventory
- Step 3 — Mandatory Web-Validation Searches
- Step 4 — Domain Testing Matrix
- Step 5 — Finding Format (Mandatory)
- Step 6 — IIA & ICAI Standards Overlay
- Statutory rates and thresholds
- Step 7 — Risk Rating
- Report structure
- Step 9 — Pune/Maharashtra-Specific Cross-Domain Interlinkage Tests
- Non-Negotiable Evidence Rules


# Pune & Maharashtra — Full-Spectrum Business & Financial Operations Audit Skill

**Jurisdiction:** Pune, Maharashtra, India
**Standard:** IIA GIAS 2024 | ICAI SA/SIA Series | COSO ERM 2017 | ACFE Fraud Tree
**Evidence Standard:** Real, Proven, Actual Facts — No assumption, no fabrication, no drift
**Effective Date:** All rates/thresholds MUST be web-validated before any finding
**Version:** 1.1 — Aug 2026 (IT Act 2025 eff. 01 Apr 2026; Labour Codes Nov 2025; MH S&E Amdt Oct 2025; MH Min Wages Jan 2026; MH LWF revised Mar 2024; ROC realignment Feb 2026; v1.1 adds Statutory-vs-Certification distinction, PMC/PCMC/MIDC jurisdiction table, and pre-production Go/No-Go readiness tracker workbook pattern to R12)

> **MAHARASHTRA-SPECIFIC:** GST state code = 27. All intra-Pune supply = CGST [IN-091] + MGST [IN-091]. ROC Pune jurisdiction covers Maharashtra excluding Mumbai district (ROC realignment [IN-107] — verify MCA21).

---

## SKILL ARCHITECTURE

```
pune-india-ops-audit/
├── SKILL.md                            ← This file (workflow, domain index, quick-ref)
└── references/
    ├── R01_direct_tax.md               ← IT Act 2025, TDS, advance tax, transition
    ├── R02_gst_indirect_tax.md         ← CGST/MGST, ITC, e-invoice, GSTR, state code 27
    ├── R03_epf_esic.md                 ← EPF/EPS/ESIC, Labour Codes wages def (Nov 2025)
    ├── R04_hr_payroll.md               ← Payroll structure, TDS Sec 192, FnF, MH-specific
    ├── R05_labour_laws_mh.md           ← MH S&E Act 2017 (Amdt Oct 2025), Factories Act, CLRA [superseded 21-Nov-2025 — re-map to Code]
    ├── R06_wages_welfare_mh.md         ← MH Min Wages (Zone I Pune), PTRC/PTEC, MH LWF, Bonus, Gratuity
    ├── R07_company_law.md              ← Companies Act 2013, ROC Pune (post-Feb 2026), IFC
    ├── R08_fema_rbi.md                 ← FEMA 1999, FDI, ECB, SOFTEX, forex, expat
    ├── R09_vendor_contractor.md        ← Vendor KYC, MH GSTIN (27), CLRA, bill validation [superseded 21-Nov-2025 — re-map to Code]
    ├── R10_financial_ops.md            ← AP/AR, cash controls, JE, Ind AS, COSO
    ├── R11_fraud_detection.md          ← ACFE tree, Benford, ghost employee, PMLA
    ├── R12_environment_safety_mh.md    ← MPCB, Factories Act MH, Fire NOC, MIDC, PMC/PCMC jurisdiction, Statutory-vs-Certification distinction (VDA 6.3/IATF/ISO), pre-production Go/No-Go tracker pattern [superseded 21-Nov-2025 — re-map to Code]
    ├── R13_posh_governance.md          ← POSH 2013 ICC, vigil mechanism, DPDPA 2023
    └── R14_compliance_calendar_mh.md   ← Full MH/Pune/India compliance calendar + penalties
```

**Loading rule:** Read only reference files needed for the specific engagement.
For multi-domain engagements, load all applicable R-files before raising findings.

---

## Step 0 — Pre-Engagement Mandatory Checks

Before ANY procedure, finding, or recommendation:

1. **Web-validate all MH-specific rates** — minimum wages, PT slabs, LWF — change bi-annually
2. **Establish evidence baseline** — classify all evidence on the 5-rank hierarchy (see below)
3. **Declare scope limitations immediately** — if documents/portals inaccessible, state it
4. **Identify entity type** — Pvt Ltd / LLP / OPC / Proprietorship / Partnership / Section 8 — determines applicable Acts
5. **Identify industry** — Factory (MH Factories Act), IT/ITES (MH S&E Act), MIDC industrial area, Services, Retail, Auto Ancillary, Pharma — determines specific regulations [superseded 21-Nov-2025 — re-map to Code]
6. **Identify headcount** — applicability triggers:
   - Applicability thresholds (EPF, ESIC, CLRA, MH S&E, POSH, MH LWF, maternity): see `statutory-register-india.md` (IN-012, IN-013, IN-060, IN-061, IN-050, IN-049, IN-063) [superseded 21-Nov-2025 — re-map to Code]
7. **Confirm Pune zone classification** — Pune falls within Pune Metropolitan Region (PMR) = Zone I / Group A for minimum wages and PT
8. **If the engagement involves a new plant, plant takeover, or customer-programme cutover** — separate statutory legal compliance from customer/quality certification (VDA 6.3, IATF 16949, ISO) as two parallel workstreams from Day 1; never let one substitute for the other in scoping, findings, or a readiness tracker (see R12 § Statutory Licence vs. Customer/Quality Certification)
9. **Confirm exact site jurisdiction** — PMC / PCMC / MIDC estate / outside municipal limits — before relying on any Fire NOC, building permission, or trade-licence status (see R12 § Jurisdiction confirmation table)

### Evidence reliability

Grade every item R1 to R5 using the scale and strict R3 test in `gia-core:iron-rules`. R5 (verbal) evidence never supports a finding.

---

## Step 1 — Entity & Engagement Context (Evidence-Based)

| Field | Verified Source |
|-------|----------------|
| Entity type | MCA21 — CIN, incorporation certificate (ROC Pune for non-Mumbai MH entities) |
| Industry | Factory licence (Form 2 MH Factories Rules) OR MH S&E Registration |
| Registered address | GST registration certificate — state code 27 confirms Maharashtra jurisdiction |
| GSTIN | gst.gov.in — taxpayer search; first 2 digits must be 27 for Pune entity |
| Headcount (regular) | EPFO ECR portal — month-wise headcount (Rank 1) |
| Contract workforce | CLRA Form V / Form VI / Form XIII | [superseded 21-Nov-2025 — re-map to Code]
| PAN / TAN | incometax.gov.in — verification portal |
| EPFO code | epfindia.gov.in — unified portal |
| ESIC code | esic.gov.in — employer module |
| PTRC / PTEC number | mahagst.gov.in — Maharashtra PT portal |
| MLWB registration | mlwb.in — Maharashtra Labour Welfare Board |
| MIDC membership | If operating in MIDC Pune area — MIDC NOC / Allotment letter |
| Prior audit findings | Prior IA/EA reports; CAE file |

---

## Step 2 — Document Inventory

**Mark:** ✅ Obtained | ⚠️ Partial | ❌ Not Provided

### Tier 1 — Core Financial & Tax (Mandatory)
- [ ] Income Tax returns (ITR) — last 3 assessment years
- [ ] Form 26AS / AIS / TIS — all Tax Years (from Income Tax portal)
- [ ] TDS returns: 24Q (salary), 26Q (non-salary), 27Q (NR), 27EQ (TCS) — last 4 quarters
- [ ] GSTR-1, GSTR-3B, GSTR-9/9C — last 3 financial years
- [ ] Audited financial statements (P&L, Balance Sheet, Notes) — last 3 years
- [ ] Bank statements — all accounts, last 12 months

### Tier 2 — HR & Payroll
- [ ] HRMS payroll register — full population, all months
- [ ] EPFO ECR — portal download, all months
- [ ] ESIC ECR — portal download, all months
- [ ] PTRC challans — monthly PT return (Form III-B) or annual (Form IIIy)
- [ ] MLWB LWF challans — June and December half-years
- [ ] Form 24Q (TDS on salary) + Form 16 issued
- [ ] Appointment letters — sample ≥30
- [ ] Full-and-final settlement register — last 12 months

### Tier 3 — Corporate & Statutory
- [ ] MCA21 annual returns (MGT-7/7A) and financials (AOC-4) — last 3 years
- [ ] Board meeting minutes — last 12 months
- [ ] MH S&E Registration certificate (or intimation receipt, per the applicability row in the register)
- [ ] Factory licence (Form 2 MH Factories Rules) — if applicable
- [ ] CLRA Form V (contractor licences), Form XIII (register of contractors) [superseded 21-Nov-2025 — re-map to Code]
- [ ] POSH ICC constitution + annual report + complaints register
- [ ] Bonus computation — allocable surplus, Forms A/B/C/D
- [ ] Gratuity computation + trust deed (if approved trust)
- [ ] MPCB Consent to Operate (CTO) — if manufacturing/industrial
- [ ] PMC Trade Licence — annual renewal

### Tier 4 — Vendor / Contractor Specific
- [ ] Vendor master — approved list with GSTIN (27-prefix), PAN, bank details
- [ ] Purchase orders / work orders — all active contractors
- [ ] Vendor invoices — all months under review (100% population)
- [ ] TDS deduction register — Sec 194C/194J/194H etc.
- [ ] GSTR-2B — to verify ITC eligibility for all vendor GST claims
- [ ] Payment register — date, amount, mode, TDS deducted

---

## Step 3 — Mandatory Web-Validation Searches

Run BEFORE any finding is raised. Never cite from memory.

```
Maharashtra minimum wages Zone I Pune PMR January 2026 notification
Maharashtra minimum wages July 2026 notification VDA update
Maharashtra Professional Tax slab PTRC 2025 2026 male female
Maharashtra LWF contribution rate 2024 2025 2026 employer employee
Maharashtra Shops Establishments Act 2017 Amendment October 2025 key changes
Maharashtra S&E Act amendment rules 2025 working hours overtime quarterly limit
MH S&E Act 2025 registration threshold 20 employees
Income Tax Act 2025 TDS sections renumbered effective April 2026
TDS Section 194C rate FY 2026-27 India contractor
GST rate manpower supply SAC 9985 India 2026
EPF ESIC contribution rate 2026 India Labour Codes wages definition
Labour Codes 2020 wages definition 50 percent allowances EPF ESIC base
ROC Pune jurisdiction realignment February 2026 MCA notification
MPCB Pune consent to operate CTO renewal 2025 2026
Maharashtra Factories Act annual return Form 21 due date 2026 [superseded 21-Nov-2025 — re-map to Code]
Pune PMC trade licence renewal 2026
Maharashtra CLRA threshold 2025 2026 [superseded 21-Nov-2025 — re-map to Code]
```

---

## Step 4 — Domain Testing Matrix

Read the corresponding reference file before testing each domain.

| Domain | Reference File | Key Statutes | Trigger Condition |
|--------|---------------|-------------|-------------------|
| D1 — Direct Tax | R01_direct_tax.md | IT Act 2025 ([IN-022]); IT Act 1961 (up to 31 Mar 2026) | Any income tax, TDS, advance tax, filing query |
| D2 — GST | R02_gst_indirect_tax.md | CGST Act 2017; Maharashtra GST Act 2017 (MGST); IGST Act 2017; State code 27 | Any GST, ITC, invoice, e-way bill, GSTR query |
| D3 — EPF/ESIC | R03_epf_esic.md | EPF Act 1952; ESI Act 1948; Code on Social Security 2020 (eff. Nov 2025) | Any EPF, ESIC, PF, social security query | [superseded 21-Nov-2025 — re-map to Code]
| D4 — HR/Payroll | R04_hr_payroll.md | IT Act 2025 Sec 192 equiv; EPF; ESIC; MH PT; MH S&E Act | Any payroll, salary structure, deduction query |
| D5 — Labour Laws MH | R05_labour_laws_mh.md | MH S&E Act 2017 (Amdt Ordinance Oct 2025); MH Factories Rules 1963; CLRA 1970; Maternity Benefit Act 1961 (Amdt 2017); Labour Codes 2019-20 | Any labour law, leave, hours, termination query | [superseded 21-Nov-2025 — re-map to Code]
| D6 — Wages & Welfare MH | R06_wages_welfare_mh.md | MH Min Wages notification (Zone I — bi-annual: Jan + Jul); MH Prof Tax Act 1975 (PTRC/PTEC); MH LWF Act 1953 (revised Mar 2024); Bonus Act 1965; Gratuity Act 1972 | Min wages, PT, LWF, bonus, gratuity query |
| D7 — Company Law | R07_company_law.md | Companies Act 2013; LLP Act 2008; ROC Pune (post-Feb 2026 realignment) | Any company law, ROC, MCA filing query |
| D8 — FEMA/RBI | R08_fema_rbi.md | FEMA 1999; RBI Master Directions; SEBI (FPI/FDI) | Any forex, ECB, ODI, FDI, NRI, cross-border query |
| D9 — Vendor/Contractor | R09_vendor_contractor.md | CLRA 1970; IT Act 2025 TDS equivalent; CGST Act (GSTIN 27 prefix); Min Wages MH | Any vendor bill, contractor invoice, supply chain query | [superseded 21-Nov-2025 — re-map to Code]
| D10 — Financial Ops | R10_financial_ops.md | COSO Internal Control; IT Act 2025 Sec cash limit; Companies Act 2013 | Any AP/AR, cash management, bank reconciliation query |
| D11 — Fraud Detection | R11_fraud_detection.md | ACFE Fraud Tree; Prevention of Corruption Act 1988; IPC/BNS; PMLA 2002 | Any fraud risk, red flag, Benford, ghost worker query |
| D12 — Env/Safety MH | R12_environment_safety_mh.md | MPCB (Water Act 1974 + Air Act 1981 MH); MH Factories Rules 1963; MIDC; PMC; Fire NOC | Any MPCB, factory safety, NOC, MIDC query |
| D13 — POSH/Governance | R13_posh_governance.md | POSH Act 2013; Companies Act 2013 (Audit Committee); Vigil Mechanism; DPDPA 2023 | Any POSH, ICC, harassment, governance, ethics query |
| D14 — Calendar MH | R14_compliance_calendar_mh.md | All of the above — MH-specific filing/remittance deadlines | Any "when is X due?" or compliance schedule query |

---

## Step 5 — Finding Format (Mandatory)

Every finding must follow this structure:

```
Finding ID:     [Domain prefix]-[NNN]  e.g. D1-001, D6-003
Title:          [Clear, specific — WHAT the issue IS; WHO is affected; WHICH law breached]
                MUST explicitly state the non-compliance, deficiency, or risk.
                BAD:  "PT compliance review"
                GOOD: "Maharashtra PTRC — Professional Tax not deposited for 3 months: 
                       Vendor ABC Pvt Ltd — PTRC violation under MH PT Act 1975"

Risk Rating:    🔴 Critical | 🟠 High | 🟡 Medium | 🟢 Low
Condition:      [Fact found — not inference. Source stated. "The PTRC challan portal shows..."]
Criteria:       [Exact Act / Section / Notification / Year — e.g. "MH State Tax on Professions, 
                Trades, Callings & Employments Act 1975, Sec 6 + PTRC notification FY 2025-26"]
Evidence:       [Source + Rank from hierarchy above]
Cause:          [Root cause — process gap, control failure, deliberate act, knowledge gap]
Effect:         [₹ exposure with formula AND source data; or "Unquantified — insufficient evidence"]
Recommendation: [SMART — Specific, Measurable, Achievable, Relevant, Time-bound]
Owner:          [Named function/role]
Target Date:    [Specific date — not "ASAP"]
Mgmt Response:  [Agree / Partially Agree / Disagree + rationale]
```

---

## Step 6 — IIA & ICAI Standards Overlay

| Standard | Application |
|----------|-------------|
| IIA GIAS 2024 Std 9.2 | Evidence sufficiency — portal > system > document > management |
| IIA GIAS 2024 Std 11.1 | Communicating results — factual, objective, constructive |
| IIA GIAS 2024 Std 13.1 | Scope limitations — declare immediately, never suppress |
| ICAI SA 200 | Professional scepticism — never accept at face value |
| ICAI SA 240 | Fraud risk — always apply fraud risk assessment |
| ICAI SA 500 | Evidence sufficiency and reliability |
| ICAI SA 505 | External confirmations — EPFO/ESIC/TRACES/GST portal |
| ICAI SA 530 | Sampling — only when 100% analytics not feasible |
| ICAI SIA 1 | Planning the internal audit |
| ICAI SIA 3 | Documentation standards |
| ICAI SIA 4 | Risk assessment |
| ICAI SIA 10 | Internal audit evidence |
| ICAI SIA 11 | Consideration of fraud |

---

## Statutory rates and thresholds

No rate, threshold or date is held in this file. Take every value from `statutory-register-india.md` (item, Act and section, value, effective date, source, verified-on, status). A register row marked `[UNVERIFIED]` or `CONFLICT` cannot support a finding.

---

## Step 7 — Risk Rating

| Rating | Colour | Likelihood × Impact | Action |
|--------|--------|---------------------|--------|
| Critical | 🔴 | Almost certain / catastrophic | Immediate escalation to AC/Board |
| High | 🟠 | Likely / major | Priority remediation < 30 days |
| Medium | 🟡 | Possible / moderate | Remediation < 90 days |
| Low | 🟢 | Unlikely / minor | Monitor; next audit cycle |

---

## Report structure

Owned by `gia-report-qa:gia-ia-report` (standard concise report plus Excel working paper). This pack emits a findings register only. The 13-section structure is a legacy conversion reference and is not used.

---

## Step 9 — Pune/Maharashtra-Specific Cross-Domain Interlinkage Tests

| Test | Link | Red Flag |
|------|------|----------|
| Payroll headcount vs. EPF ECR | D4 ↔ D3 | Gap = ghost employee or EPF exclusion |
| GSTIN (27-prefix) on all vendor bills | D9 ↔ D2 | Non-MH GSTIN on Pune vendor = place-of-supply error; wrong tax type |
| GST charged on vendor bill vs. GSTR-2B | D9 ↔ D2 | ITC claimed but vendor not filed GSTR-1 = Sec 16(2)(aa) CGST risk |
| TDS deducted vs. TRACES challan | D1 ↔ D9 | TDS not deposited = Sec 40(a)(ia) [IN-074] expense disallowance |
| Vendor bill EPF/ESIC vs. contractor ECR | D9 ↔ D3 | Billed but not remitted = CLRA Sec 21(4) liability | [superseded 21-Nov-2025 — re-map to Code]
| Per-worker wage on bill vs. MH Zone I min wage | D9 ↔ D6 | Below minimum wage (Zone I Pune) = Minimum Wages Act 1948 violation | [superseded 21-Nov-2025 — re-map to Code]
| PTRC monthly deposit vs. payroll deduction | D6 ↔ D10 | Deducted from employee but PTRC not remitted = trust receipt fraud |
| MLWB LWF deduction vs. June/Dec remittance | D6 ↔ D10 | Same trust receipt fraud risk |
| Contractor headcount vs. CLRA Form V limit | D9 ↔ D5 | Exceeds licence headcount = CLRA violation | [superseded 21-Nov-2025 — re-map to Code]
| Salary paid vs. bank debit | D4 ↔ D10 | Variance = unaccounted payment or ghost payroll |
| MH S&E registration vs. actual headcount | D5 ↔ D4 | >20 employees but no S&E registration = MH S&E Act 2017 violation |
| Bonus computation vs. P&L allocable surplus | D6 ↔ D7 | Overpaid = misappropriation; underpaid = Bonus Act violation |
| Labour Codes wages definition — Dec 2025+ | D3 ↔ D4 | Pre-Nov 2025 salary structure still in use = under-contribution |
| ROC Pune filing vs. MCA21 SRN | D7 ↔ D10 | Annual return / AOC-4 not filed = ROC Pune penalty |

---

## Non-Negotiable Evidence Rules

1. No finding on assumption — document, portal, reperformance, or observation only
2. No estimate without formula and source — every ₹ figure shows derivation
3. No management representation alone — initiates inquiry; never closes finding
4. No verbal confirmation — always in writing (ICAI SA 505)
5. Contradict, don't defer — where evidence contradicts management, evidence governs
6. Cite Act/Section/Notification/Year — e.g. "MH LWF Act 1953 (revised Mar 2024) (value per the register row IN-047 / IN-048)"
7. Cite IIA GIAS 2024 Standard for process/reporting observations
8. Cite ICAI SA/SIA number for every procedure
9. Prefer 100% population over sampling wherever data extract is available
10. Disclaimer on every report: Professional internal audit — not a statutory, legal, or CA opinion

---

*All regulatory rates and thresholds must be web-validated before use. This skill is a professional audit framework; it is not legal advice, statutory audit, or a Chartered Accountant's certificate. Maharashtra-specific law applies; where silent, central legislation governs.*
