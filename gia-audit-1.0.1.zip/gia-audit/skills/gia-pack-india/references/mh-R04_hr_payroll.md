> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- Salary Structure Framework (Pune / Maharashtra)
- Payroll Processing Controls
- TDS on Salary (Sec 192 IT Act 1961 / IT Act 2025 equivalent)
- Termination & Full-and-Final (FnF) Settlement (Maharashtra)
- Statutory Forms — Payroll (Maharashtra)
- Audit Procedures — HR & Payroll (Pune)
- Red Flags — Payroll (Pune)


# R04 — HR & Payroll Operations (Pune / Maharashtra)

## Salary Structure Framework (Pune / Maharashtra)

### Compliant Salary Components

| Component | Nature | EPF Base? | ESIC Base? | PT Base? | TDS Basis |
|-----------|--------|-----------|-----------|---------|-----------|
| Basic Salary | Fixed | Yes | Yes | Yes | Yes |
| Dearness Allowance (DA) | Fixed/variable | Yes | Yes | Yes | Yes |
| House Rent Allowance (HRA) | Fixed | No | Yes | Yes | Partly exempt: actual/[IN-082]basic/rent-[IN-082] basic (min of 3) |
| Special Allowance | Fixed | No (if ≤[IN-017] gross pre-Labour Codes) | Yes | Yes | Fully taxable |
| Conveyance Allowance | Fixed | No | Yes | Yes | Up to [IN-084]/mo (IT Act 1961); verify IT Act 2025 equivalent |
| Medical Allowance | Fixed | No | Yes | Yes | Up to [IN-085] p.a. (IT Act 1961); verify IT Act 2025 |
| Overtime (OT) | Variable | Yes | Yes | Yes | Fully taxable |
| Bonus / Ex-gratia | Variable | No (if not monthly regular) | No (if irregular) | Yes | Fully taxable |
| Shift Allowance | Fixed/variable | No | Yes | Yes | Taxable — common in Pune manufacturing |
| LTA | Periodic | No | No | No | Exempt 2× in 4-year block |
| Gratuity | On separation | No | No | No | Exempt up to ceiling |
| PF employer contribution | Statutory | N/A | No | No | Exempt up to [IN-086] |

> **Post–Labour Codes (Nov 21 2025):** If allowances > [IN-017] of total remuneration → excess re-enters EPF and ESIC base. This disproportionately affects Pune IT companies with high HRA + Special Allowance structures. Reassess all salary structures from Dec 2025.

### Maharashtra PT-Specific Note
- Males earning ≤[IN-045]/mo: PT = Nil
- Males earning >[IN-045]/mo: PT applies per slab (max [IN-044] p.a.)
- **Females earning ≤[IN-045]/mo: PT = Nil** (Maharashtra-specific gender exemption)
- Females earning >[IN-045]/mo: PT applies at same rate as males

---

## Payroll Processing Controls

### Pre-Payroll Controls
- [ ] Attendance/leave data frozen — signed off by HR by payroll cutoff date
- [ ] New joiners: Appointment letter + bank details + PAN + Aadhaar completed before first salary
- [ ] Exits: FnF computation approved by HR and Finance; no salary post-exit date
- [ ] Increment letters: Authorised before payroll run; no retrospective changes without documented approval
- [ ] Variable pay: Supported by performance records or management approval

### Payroll Run Controls
- [ ] Payroll processed only in HRMS — manual overrides require dual-level approval
- [ ] MH PT: Correctly applied — Nil for females ≤[IN-045]; correct slab for males
- [ ] TDS: New regime vs. old regime election confirmed from each employee (Form 10IEA / Sec 115BAC declaration)
- [ ] EPF/ESIC: Auto-computed; reconciled to ECR before challan generation
- [ ] Labour Codes check: If allowances >[IN-017] gross → EPF/ESIC base corrected from Dec 2025

### Post-Payroll Controls
- [ ] Payroll register: Signed by Payroll Manager + Finance Head
- [ ] Bank transfer file: Dual authorization (maker + checker); no manual NEFT/RTGS
- [ ] Salary credit: By 7th of following month (MH S&E Act 2017) or 10th (>1,000 employees)
- [ ] Pay slips: Issued to all employees — mandatory under MH S&E Act 2017
- [ ] Reconciliation: Total payroll cost per P&L vs. sum of all pay slips

---

## TDS on Salary (Sec 192 IT Act 1961 / IT Act 2025 equivalent)

- TDS on salary = Estimated annual tax liability / 12 months
- Must be deducted monthly from April
- **New vs. Old Tax Regime:** From FY 2024-25, new regime is DEFAULT. Employee must explicitly opt for old regime in writing (Form 10IEA). Verify election at start of year.
- Investment declarations: April (provisional) + January update (with proofs)
- HRA exemption: Rent receipts + PAN of landlord if annual rent >[IN-083]
- Form 12BB: Employee's investment declaration (Rule 26C)
- Form 16: Issued to all employees by June 15 of following year
- Form 24Q Q4: Due May 31

---

## Termination & Full-and-Final (FnF) Settlement (Maharashtra)

| Component | Legal Basis | Timeline | Pune-Specific Note |
|-----------|------------|---------|---------------------|
| Salary up to LWD | Contract / MH S&E Act 2017 | With FnF | Mandatory; salary credited same day as FnF |
| Earned leave encashment | MH S&E Act 2017 / Contract | With FnF | Up to 42 days can be carried; remainder encashed |
| Gratuity (≥5 years) | Payment of Gratuity Act 1972 | Within 30 days | 15/26 × last salary × years | [superseded 21-Nov-2025 — re-map to Code]
| Bonus (if year completed) | Payment of Bonus Act 1965 | Within 8 months of FY end | By Nov 30 for Mar year-end | [superseded 21-Nov-2025 — re-map to Code]
| PF settlement / transfer | EPF Act — Form 10C/19 | Within 60 days of claim | UAN-linked; online claim |
| ESIC Form 31 | ESI Act | Employer provides within 3 months | ESIC Pimpri Chinchwad / Yerawada | [superseded 21-Nov-2025 — re-map to Code]
| Service certificate | MH S&E Act 2017, Sec 22 | At time of separation | Mandatory for all employees |
| Relieving letter | Good practice; MH S&E Act | At time of separation | Required for IT companies |

---

## Statutory Forms — Payroll (Maharashtra)

| Form | Purpose | Frequency | Portal |
|------|---------|-----------|--------|
| Form 24Q | TDS on salary | Quarterly | TRACES |
| Form 16 (Part A + B) | TDS certificate to employee | Annual by Jun 15 | TRACES (Part A from portal) |
| PTRC Form III-B | Professional Tax — employer monthly return | Monthly (>[IN-142] annual PT) | mahagst.gov.in |
| PTRC Form IIIy | Professional Tax — employer annual return | Annual | mahagst.gov.in |
| PTEC | PT for self-employed / company entity | Annual | mahagst.gov.in |
| ECR (EPFO) | EPF/EPS contribution challan | Monthly | epfindia.gov.in |
| ECR (ESIC) | ESIC contribution challan | Monthly | esic.gov.in |
| MLWB LWF remittance | Maharashtra LWF half-year | June 30 + Dec 31 | mlwb.in |
| Form 11 (EPF) | Employee declaration on joining | On joining | HRMS/EPFO |
| Form 12BB | Investment declaration | April (provisional) + Jan (revised) | Internal |

---

## Audit Procedures — HR & Payroll (Pune)

1. Extract 100% payroll register for all months from HRMS (Rank 2)
2. Reconcile total gross payroll per month to:
   - General ledger / P&L salary expense
   - Bank statement — salary disbursement
   - EPF ECR — contribution base
   - PTRC — PT deduction
3. Ghost employee test: Cross-check payroll list against:
   - Active HR file (digital/physical)
   - Biometric attendance (mandatory for Pune IT SEZ/STPI companies)
   - EPFO member seeding data
   - Bank account (flag if two employees share same bank account)
4. New joiner test: Appointment letter date vs. first payroll date
5. Exit test: Last working day vs. last salary month
6. PT test: Verify male/female split; nil PT for females ≤[IN-045]; correct slab for males; PTRC remittance on mahagst.gov.in
7. LWF test: [IN-047]/employee deducted June and December; [IN-048]/employee employer contribution remitted by June 30 and Dec 31; annual return filed
8. Labour Codes test (Dec 2025+): For each employee — compute allowances as % of gross; if >[IN-017] → verify revised EPF/ESIC base applied
9. TDS: Verify new vs. old regime election from all employees; compute expected TDS per month; Form 24Q Q4 filed by May 31
10. Salary payment date: Verify credited by 7th (≤1,000 employees) or 10th (>1,000 employees) per MH S&E Act 2017

---

## Red Flags — Payroll (Pune)

- Female employees with salary >[IN-045] having nil PT (eligible for PT; verify MH slab)
- Male employees with salary ≤[IN-045] having PT deducted (incorrect; below threshold)
- Post-Dec 2025: EPF/ESIC base unchanged despite salary structures with allowances >[IN-017] gross
- PTRC not filed or challan missing — PT deducted from employees but not remitted to mahagst.gov.in
- LWF deducted monthly instead of half-yearly (over-deduction; MH LWF Act violation)
- LWF still at old rates ([IN-144] employee/[IN-144] employer) instead of current [IN-047]/[IN-048] (revised Mar 2024)
- Salary paid in cash >[IN-028]/day (IT Act cash limit + MH S&E Act)
- No pay slips issued (MH S&E Act 2017 violation)
- Salary credited after 7th/10th of following month (MH S&E Act delay)
