> Ported workflow from the retired ops-audit skill. Statutory values are in `statutory-register-india.md` only. Domain files are named `tn-R01...R14` in this folder. Safeguards and evidence rules are in `gia-core:iron-rules`. Standard numbers cited below are as stated in the source; confirm via `gias-navigator`.
## Contents
- SKILL ARCHITECTURE
- Step 0 — Pre-Engagement Mandatory Checks
- Step 1 — Entity & Engagement Context (Evidence-Based)
- Step 2 — Document Inventory
- Step 3 — Mandatory Web-Validation Searches
- Step 4 — Domain Testing Matrix
- Step 5 — Finding Format (Mandatory)
- Step 6 — ICAI & IIA Standards Overlay
- Step 7 — Risk Rating Quick Reference
- Statutory rates and thresholds
- Report structure
- Step 9 — Cross-Domain Interlinkage Tests
- Non-Negotiable Evidence Rules


# Chennai & Tamil Nadu — Full-Spectrum Business & Financial Operations Audit Skill

**Jurisdiction:** Chennai, Tamil Nadu, India
**Standard:** IIA GIAS 2024 | ICAI SA/SIA Series | COSO ERM 2017 | ACFE Fraud Tree
**Evidence Standard:** Real, Proven, Actual Facts — No assumption, no fabrication, no drift
**Effective Date of Regulations:** All rates and thresholds MUST be web-validated before any finding
**Version:** 2.0 — May 2026 (reflects Income Tax Act 2025 [IN-022]; Labour Codes effective Nov 21 2025; TN Min Wages Apr 2026)


---

## SKILL ARCHITECTURE

```
chennai-india-ops-audit/
├── SKILL.md                          ← This file (workflow, domain index, quick-ref)
└── references/
    ├── R01_direct_tax.md             ← Domain 1: Income Tax Act 2025, TDS, TCS, advance tax
    ├── R02_gst_indirect_tax.md       ← Domain 2: CGST/TNGST, ITC, e-invoicing, GSTR filing
    ├── R03_epf_esic.md               ← Domain 3: EPF, EPS, ESIC, Labour Codes wage def
    ├── R04_hr_payroll.md             ← Domain 4: Payroll structure, salary, deductions, Forms
    ├── R05_labour_laws_tn.md         ← Domain 5: TN S&E Act, Factories Act, CLRA, Maternity [superseded 21-Nov-2025 — re-map to Code]
    ├── R06_wages_welfare.md          ← Domain 6: Min wages TN, PT, LWF, Bonus, Gratuity
    ├── R07_company_law.md            ← Domain 7: Companies Act 2013, MCA21, ROC filings
    ├── R08_fema_rbi.md               ← Domain 8: FEMA 1999, RBI, forex, ECB, FDI/FPI
    ├── R09_vendor_contractor.md      ← Domain 9: Vendor onboarding, bill validation, CLRA [superseded 21-Nov-2025 — re-map to Code]
    ├── R10_financial_ops.md          ← Domain 10: AP/AR, cash, bank recs, internal controls
    ├── R11_fraud_detection.md        ← Domain 11: ACFE tree, Benford, ghost workers, IFC
    ├── R12_environment_safety.md     ← Domain 12: TNPCB, factories safety, fire NOC, MSME
    ├── R13_posh_governance.md        ← Domain 13: POSH 2013, ICC, whistleblower, governance
    └── R14_compliance_calendar.md    ← Domain 14: Full Chennai/TN/India compliance calendar
```

**Loading rule:** Read only the reference files needed for the specific engagement.
For multi-domain engagements, load all applicable R-files before raising findings.

---

## Step 0 — Pre-Engagement Mandatory Checks

Before ANY procedure, finding, or recommendation:

1. **Web-validate all rates** via Step 3 searches below — never cite from memory
2. **Establish evidence baseline** — classify all evidence on the 5-rank hierarchy (see below)
3. **Declare scope limitations immediately** — if documents/portals inaccessible, state it
4. **Identify the entity type** — Pvt Ltd, LLP, Proprietorship, Partnership, Public Ltd, Section 8 — determines applicable Acts
5. **Identify the industry** — Factory (Factories Act), IT/ITES (TN S&E Act), Manufacturing, Services, Retail — determines specific regulations [superseded 21-Nov-2025 — re-map to Code]
6. **Identify headcount** — applicability triggers for EPF, ESIC, CLRA, POSH and maternity benefits are in `statutory-register-india.md` (IN-012, IN-013, IN-060, IN-061, IN-063) [superseded 21-Nov-2025 — re-map to Code]

### Evidence reliability

Grade every item R1 to R5 using the scale and strict R3 test in `gia-core:iron-rules`. R5 (verbal) evidence never supports a finding.

---

## Step 1 — Entity & Engagement Context (Evidence-Based)

| Field | Verified Source |
|-------|----------------|
| Entity type | MCA21 ROC (mca.gov.in) — CIN, incorporation certificate |
| Industry | Factory licence (Form 2) OR TN S&E Registration Certificate |
| Registered address | GST registration certificate — confirms Chennai jurisdiction |
| Headcount (regular) | EPFO ECR portal — month-wise count (Rank 1) |
| Contract workforce | CLRA Form V/VI/XIII register | [superseded 21-Nov-2025 — re-map to Code]
| PAN / TAN | incometax.gov.in — PAN/TAN verification portal |
| GSTIN | gst.gov.in — taxpayer search |
| EPFO code | epfindia.gov.in — unified portal |
| ESIC code | esic.gov.in — employer module |
| PT number | TN Commercial Taxes portal |
| Prior audit findings | Prior IA/EA reports; CAE file |

---

## Step 2 — Document Inventory

**Mark:** ✅ Obtained | ⚠️ Partial | ❌ Not Provided

### Tier 1 — Core Financial & Tax (mandatory)
- [ ] Income Tax returns (ITR) — last 3 assessment years
- [ ] Form 26AS / AIS / TIS — all 3 TY (from Income Tax portal)
- [ ] TDS returns: 24Q (salary), 26Q (non-salary), 27Q (NR), 27EQ (TCS) — last 4 quarters
- [ ] GSTR-1, GSTR-3B, GSTR-9/9C — last 3 financial years
- [ ] Audited financial statements (P&L, Balance Sheet, Notes) — last 3 years
- [ ] Bank statements — all accounts, last 12 months
- [ ] Cash book / petty cash register

### Tier 2 — HR & Payroll
- [ ] HRMS payroll register — full population, all months
- [ ] EPFO ECR — portal download, all months
- [ ] ESIC ECR — portal download, all months
- [ ] Form 24Q (TDS on salary) + Form 16 issued
- [ ] Appointment letters — sample ≥30
- [ ] Full-and-final settlement register — last 12 months
- [ ] Leave ledger — all leave types

### Tier 3 — Corporate & Statutory
- [ ] MCA21 annual returns (MGT-7/7A) and financial statements (AOC-4) — last 3 years
- [ ] Board meeting minutes — last 12 months
- [ ] Statutory registers: Members, Directors, Charges (Form CHG-1/7)
- [ ] CLRA Form V (contractor licences), Form XIII (register of contractors) [superseded 21-Nov-2025 — re-map to Code]
- [ ] TN S&E registration certificate
- [ ] Factory licence (if applicable — Form 2 under Factories Act) [superseded 21-Nov-2025 — re-map to Code]
- [ ] PT challans (Form PT-1) — half-yearly
- [ ] LWF remittance challans — half-yearly (Jan and Jul)
- [ ] POSH ICC constitution + annual report + complaints register (last 3 years)
- [ ] Bonus computation — allocable surplus, Form D (set-on/set-off)
- [ ] Gratuity computation + trust deed (if approved trust)

### Tier 4 — Vendor / Contractor Specific
- [ ] Vendor master — approved list with GSTIN, PAN, bank details
- [ ] Purchase orders / work orders — all active contractors
- [ ] Vendor invoices — all months under review (100% population)
- [ ] TDS deduction register — Sec 194C/194J/194H etc.
- [ ] GSTR-2B — to verify ITC eligibility for all vendor GST claims
- [ ] Payment register — date, amount, mode, TDS deducted

---

## Step 3 — Mandatory Web-Validation Searches

Run before ANY finding. Never cite from memory.

```
Income Tax Act 2025 sections TDS rates FY 2026-27
Income Tax Act 2025 vs 1961 section mapping TDS
TDS Section 194C rate 2026 contractor India
TDS Section 194J rate 2026 professional fees India
GST rate manpower supply SAC 9985 India 2026
CGST SGST TNGST rate notification 2025 2026
EPF contribution rate 2026 India EPFO
ESIC contribution rate 2026 India
Labour Codes 2020 implementation India wages definition
Tamil Nadu minimum wages notification April 2026
Tamil Nadu Professional Tax slab 2026
TN Labour Welfare Fund rate 2025 2026
Tamil Nadu Shops Establishments Act amendment 2025
CLRA threshold Tamil Nadu 2026 [superseded 21-Nov-2025 — re-map to Code]
Payment of Gratuity Act ceiling 2024 2025 [superseded 21-Nov-2025 — re-map to Code]
Payment of Bonus Act salary threshold 2025 2026 [superseded 21-Nov-2025 — re-map to Code]
Companies Act 2013 ROC annual return due date 2025 2026
FEMA RBI ECB FDI regulations 2025 2026
POSH annual report 31 January 2026
```

---

## Step 4 — Domain Testing Matrix

Read the corresponding reference file before testing each domain.

| Domain | Reference File | Key Statutes | Trigger Condition |
|--------|---------------|-------------|-------------------|
| D1 — Direct Tax | R01_direct_tax.md | IT Act 2025 ([IN-022]); IT Act 1961 (up to 31 Mar 2026) | Any income tax, TDS, advance tax, filing query |
| D2 — GST | R02_gst_indirect_tax.md | CGST Act 2017; TNGST Act 2017; IGST Act 2017 | Any GST, ITC, invoice, e-way bill query |
| D3 — EPF/ESIC | R03_epf_esic.md | EPF Act 1952; ESI Act 1948; Code on Social Security 2020 | Any EPF, ESIC, PF, social security query | [superseded 21-Nov-2025 — re-map to Code]
| D4 — HR/Payroll | R04_hr_payroll.md | IT Act 2025 Sec 192 (salary TDS); EPF; ESIC; PT | Any payroll, salary structure, deduction query |
| D5 — Labour Laws | R05_labour_laws_tn.md | TN S&E Act 1947 (Amdt 2025); Factories Act 1948; CLRA 1970; Maternity Benefit Act 1961 (Amdt 2017); Labour Codes 2019-20 | Any labour law, leave, working hours, termination query | [superseded 21-Nov-2025 — re-map to Code]
| D6 — Wages & Welfare | R06_wages_welfare.md | Min Wages Act 1948 (TN notification Apr 2026); TN PT Act 1992; TN LWF Act 1972; Bonus Act 1965; Gratuity Act 1972 | Min wages, PT, LWF, bonus, gratuity query |
| D7 — Company Law | R07_company_law.md | Companies Act 2013; LLP Act 2008; SEBI (if listed) | Any company law, ROC, MCA filing query |
| D8 — FEMA/RBI | R08_fema_rbi.md | FEMA 1999; RBI Master Directions; SEBI (FPI/FDI) | Any forex, ECB, ODI, FDI, NRI, cross-border query |
| D9 — Vendor/Contractor | R09_vendor_contractor.md | CLRA 1970; IT Act 2025 (TDS Sec 193/194); GST Act; Min Wages | Any vendor bill, contractor invoice, supply chain query | [superseded 21-Nov-2025 — re-map to Code]
| D10 — Financial Ops | R10_financial_ops.md | COSO Internal Control; IT Act 2025 Sec 40A(3) cash; Companies Act 2013 | Any AP/AR, cash management, bank reconciliation query |
| D11 — Fraud Detection | R11_fraud_detection.md | ACFE Fraud Tree; Prevention of Corruption Act 1988; IPC; PMLA 2002 | Any fraud risk, red flag, Benford, ghost worker query |
| D12 — Env/Safety | R12_environment_safety.md | TNPCB; Environment Protection Act 1986; Factories Act 1948; Fire Services Act | Any environment, safety, NOC, factory compliance query | [superseded 21-Nov-2025 — re-map to Code]
| D13 — POSH/Governance | R13_posh_governance.md | POSH Act 2013; Companies Act 2013 (Audit Committee); Whistleblower | Any POSH, ICC, harassment, governance, ethics query |
| D14 — Calendar | R14_compliance_calendar.md | All of the above — filing and remittance deadlines | Any "when is X due?" or compliance schedule query |

---

## Step 5 — Finding Format (Mandatory)

Every finding must follow this structure:

```
Finding ID:     [Domain prefix]-[NNN]  e.g. D1-001, D6-003
Title:          [Clear, specific description — what the issue IS, not what was tested]
                Must name the non-compliance, deficiency, or risk explicitly.
                BAD:  "TDS compliance review"
                GOOD: "TDS under Sec 194C not deducted on [vendor name] — 3 months"

Risk Rating:    🔴 Critical | 🟠 High | 🟡 Medium | 🟢 Low
Condition:      [Fact found — not inference. "The payroll register shows..."; "The ECR for Jan shows..."]
Criteria:       [Exact Act / Section / Notification / Year]
Evidence:       [Source + Rank]
Cause:          [Root cause — process gap, control failure, deliberate act, knowledge gap]
Effect:         [₹ exposure with formula AND source data; or "Unquantified — insufficient evidence"]
Recommendation: [SMART — Specific, Measurable, Achievable, Relevant, Time-bound]
Owner:          [Named function/role]
Target Date:    [Specific date — not "ASAP"]
Mgmt Response:  [Agree / Partially Agree / Disagree + rationale]
```

**Title and Observation quality gate:** The finding title must, on its own, tell a reader:
- WHO is affected (entity/vendor/department)
- WHAT the non-compliance or deficiency is
- WHAT regulation is breached (if applicable)

---

## Step 6 — ICAI & IIA Standards Overlay

| Standard | Application |
|----------|-------------|
| IIA GIAS 2024 Std 9.2 | Evidence sufficiency — portal > system > document > management |
| IIA GIAS 2024 Std 11.1 | Communicating results — factual, objective, constructive |
| IIA GIAS 2024 Std 13.1 | Scope limitations — declare immediately, never suppress |
| ICAI SA 200 | Professional scepticism — never accept at face value |
| ICAI SA 240 | Fraud risk — always apply fraud risk assessment |
| ICAI SA 500 | Evidence sufficiency and reliability |
| ICAI SA 505 | External confirmations — for EPF/ESIC/TRACES/GST portal |
| ICAI SA 530 | Sampling — only when 100% analytics not feasible |
| ICAI SIA 1 | Planning the internal audit |
| ICAI SIA 3 | Documentation standards |
| ICAI SIA 4 | Risk assessment |
| ICAI SIA 10 | Internal audit evidence |
| ICAI SIA 11 | Consideration of fraud |

---

## Step 7 — Risk Rating Quick Reference

| Rating | Colour | Likelihood × Impact | Action Required |
|--------|--------|---------------------|-----------------|
| Critical | 🔴 | Almost certain / catastrophic | Immediate escalation to AC/Board |
| High | 🟠 | Likely / major | Priority remediation < 30 days |
| Medium | 🟡 | Possible / moderate | Remediation < 90 days |
| Low | 🟢 | Unlikely / minor | Monitor; next audit cycle |

---

## Statutory rates and thresholds

No rate, threshold or date is held in this file. Take every value from `statutory-register-india.md` (item, Act and section, value, effective date, source, verified-on, status). A register row marked `[UNVERIFIED]` or `CONFLICT` cannot support a finding.

---

## Report structure

Owned by `gia-report-qa:gia-ia-report` (standard concise report plus Excel working paper). This pack emits a findings register only. The 13-section structure is a legacy conversion reference and is not used.

---

## Step 9 — Cross-Domain Interlinkage Tests

Always test these linkages when multiple domains are in scope:

| Test | Link | Red Flag |
|------|------|----------|
| Payroll headcount vs. EPF ECR headcount | D4 ↔ D3 | Gap = ghost employee or EPF exclusion |
| GST charged on vendor bill vs. GSTR-2B | D9 ↔ D2 | ITC claimed but vendor not filed = Sec 16(2)(aa) risk |
| TDS deducted vs. TRACES | D1 ↔ D9 | TDS not deposited = Sec 40(a)(ia) [IN-074] disallowance |
| Vendor bill EPF/ESIC vs. contractor ECR | D9 ↔ D3 | Billed but not remitted = CLRA Sec 21(4) liability | [superseded 21-Nov-2025 — re-map to Code]
| Worker wage on bill vs. TN min wage | D9 ↔ D6 | Below min wage = Minimum Wages Act violation | [superseded 21-Nov-2025 — re-map to Code]
| Contractor headcount vs. CLRA licence limit | D9 ↔ D5 | Exceeds licence = unlicensed contractor | [superseded 21-Nov-2025 — re-map to Code]
| Salary paid vs. bank debit | D4 ↔ D10 | Variance = unaccounted payment or ghost payroll |
| Bonus computation vs. P&L allocable surplus | D6 ↔ D7 | Overpaid = misappropriation; underpaid = statutory violation |
| PT deducted vs. PT challan | D6 ↔ D10 | Deducted not remitted = trust receipt fraud |
| LWF deducted vs. LWF remittance | D6 ↔ D10 | Same trust receipt fraud risk |

---

## Non-Negotiable Evidence Rules

1. No finding on assumption — document, portal confirmation, reperformance, or observation only
2. No estimate without formula and source — every ₹ figure shows derivation
3. No management representation alone — initiates inquiry; never closes finding
4. No verbal confirmation — always in writing (SA 505)
5. Contradict, don't defer — where evidence contradicts management, evidence governs
6. Cite Act/Section/Notification/Year — never generic (e.g. "EPF Act" alone is insufficient; cite "EPF Act 1952, Sec 6 read with Para 29 EPF Scheme 1952")
7. Cite IIA 2024 Standard for process/reporting observations
8. Cite ICAI SA/SIA number for every procedure
9. Prefer 100% population over sampling wherever data extract is available
10. Disclaimer on every report: Professional internal audit — not a statutory, legal, or CA opinion

---

*All regulatory rates and thresholds must be web-validated before use. This skill is a professional framework; it is not legal advice, statutory audit, or a Chartered Accountant's certificate.*
