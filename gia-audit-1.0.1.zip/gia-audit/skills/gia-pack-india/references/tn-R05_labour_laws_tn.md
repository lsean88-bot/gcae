> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- Applicable Acts — Priority Hierarchy
- TN Shops & Establishments Act 1947 (Amendment 2025)
- Factories Act 1948 (TN) [superseded 21-Nov-2025 — re-map to Code]
- CLRA 1970 — Contract Labour (Critical for Chennai Industry) [superseded 21-Nov-2025 — re-map to Code]
- Maternity Benefit Act 1961 (Amendment 2017) [superseded 21-Nov-2025 — re-map to Code]
- Industrial Employment (Standing Orders) Act 1946 [superseded 21-Nov-2025 — re-map to Code]
- Audit Procedures — Labour Laws
- Red Flags — Labour Laws


# R05 — Labour Laws: Tamil Nadu & Central (2026)

## Applicable Acts — Priority Hierarchy

| Statute | Jurisdiction | Establishment | Key Authority |
|---------|-------------|---------------|--------------|
| TN Shops & Establishments Act 1947 (Amdt 2025) | Tamil Nadu | All commercial establishments | TN Labour Dept / Inspector of Shops |
| Factories Act 1948 + TN Factories Rules 1950 | Central + TN | Manufacturing (≥10 workers+power OR ≥20 without power) | TN Chief Inspector of Factories | [superseded 21-Nov-2025 — re-map to Code]
| Contract Labour (Regulation & Abolition) Act 1970 + TN Rules 1975 | Central + TN | Principal employers (≥20 contract workers) + Contractors (≥20 workers) | DLC Chennai | [superseded 21-Nov-2025 — re-map to Code]
| Industrial Employment (Standing Orders) Act 1946 | Central | Industrial establishments ≥ 100 employees | DLC Chennai | [superseded 21-Nov-2025 — re-map to Code]
| Industrial Disputes Act 1947 | Central | Disputes, retrenchment, closure | Labour Court, Industrial Tribunal | [superseded 21-Nov-2025 — re-map to Code]
| Maternity Benefit Act 1961 (Amdt 2017) | Central | All establishments (≥10 employees in some states) | Inspector under Act | [superseded 21-Nov-2025 — re-map to Code]
| Child Labour (Prohibition & Regulation) Act 1986 (Amdt 2016) | Central | All | District Collector |
| Four Labour Codes (2019-2020) | Central | Phased implementation | Multiple — verify per code |

> **Labour Codes Implementation (Nov 21, 2025):** The four codes are now in force. However, Tamil Nadu continues to rely heavily on legacy rules for local enforcement. Both the new Codes and existing TN rules apply — verify specific compliance requirement against both.

---

## TN Shops & Establishments Act 1947 (Amendment 2025)

**Governor's assent: June 6, 2025** — New Chapter IX on Penalties and Adjudicating Mechanism.

### Registration & Display
- Registration mandatory before commencement of business
- Registration certificate must be displayed prominently at workplace
- Renewal: Annual (verify TN portal for online renewal status)
- Changes (address, category, employee count): Must be intimated within 30 days

### Working Hours
| Category | Max hours/day | Max hours/week | Max OT/quarter |
|----------|-------------|----------------|---------------|
| Adult employee | 9 hours | 48 hours | 50 hours |
| Spread over | Not exceed 12 hours | — | — |
| Young person (<18) | 6 hours | 36 hours | No OT |

- OT must be paid at 2× ordinary rate
- Rest interval: 30 mins after 5 hours of continuous work

### Leave Entitlements (TN Shops & Establishments)
| Leave type | Entitlement | Carry forward |
|-----------|-------------|---------------|
| Earned leave | 1 day per 20 days worked (min 12 days/year) | Up to 45 days |
| Sick leave | 12 days per year | No carry forward |
| Casual leave | 12 days per year | No carry forward |
| National holidays | All 3 national holidays — mandatory (26 Jan, 15 Aug, 2 Oct) | — |
| Festival holidays | As per TN government notification (2025: published) | — |

### Other Key Provisions
- Salary must be paid by 7th of following month (≤1000 employees) or 10th (>1000)
- Dismissal/discharge: One month's notice or pay in lieu (Sec 25)
- Service certificate: Mandatory on separation (Sec 26)

---

## Factories Act 1948 (TN)

### Applicability
- Manufacturing process with ≥10 workers + power (or ≥20 workers without power)
- Annual licence renewal (Form 2) — must display
- Notice of change (Occupier, Manager, activity) — Form 5 within 15 days

### Key Compliance Points
- Max working hours: 9/day, 48/week, 60/week (with prior permission)
- OT: 2× regular rate; max 50 hours OT per quarter
- Annual leave with wages: 1 day per 20 days worked; carry forward up to 30 days
- Health, Safety, Welfare: Provisions on cleanliness, lighting, ventilation, first aid, canteen (≥250 workers), creche (≥30 women workers), rest rooms
- Annual returns: Form 21 (by 31 January); Half-yearly: Form 22 (by 31 July)
- Accident reporting: Fatal — immediately; Major — within 24 hours (Form 18)

---

## CLRA 1970 — Contract Labour (Critical for Chennai Industry)

### Threshold & Registration
| Party | Threshold | Required | Form |
|-------|-----------|---------|------|
| Principal employer | Uses ≥ 20 contract workers on any day | Register with DLC | Form I (Registration) — Form II (Certificate) |
| Contractor | Deploys ≥ 20 workers | Obtain licence from DLC | Form IV (Application) — Form V (Licence) |

### Key Obligations — Principal Employer
- Form II registration certificate before engaging contractor
- Maintain Form XIII (Register of Contractors)
- Ensure contractor provides: wages, EPF, ESIC, safety to workers
- **Liability (Sec 21(4)):** If contractor fails to pay wages — principal employer must pay and recover from contractor
- Annual return: Form XXV — by **February 15**

### Key Obligations — Contractor
- Form V licence (5-year renewal; annual return on change)
- Maintain: Muster roll (Form XVI), Wage register (Form XVII), Deduction register (Form XX), OT register (Form XXIII)
- Issue wage slips to contract workers
- Provide EPF/ESIC to all eligible workers
- Wages: Equivalent to regular employees in same establishment (CLRA amendment enforced) [superseded 21-Nov-2025 — re-map to Code]

### Audit Test — CLRA
1. Verify Form V licence number on vendor bill / contract — check DLC Chennai register (not from vendor copy)
2. Count workers on each bill — verify headcount doesn't exceed Form V licence limit
3. Verify principal employer Form I/II registration — confirm current
4. Obtain Form XIII — all contractors listed
5. Verify Form XXV Annual Return filed by Feb 15
6. For each contractor: cross-check EPF/ESIC challan copies with billing period

---

## Maternity Benefit Act 1961 (Amendment 2017)

| Provision | Details |
|-----------|---------|
| Paid maternity leave | 26 weeks (for first 2 children); 12 weeks (3rd child onwards) |
| Adoption / surrogate | 12 weeks — child under 3 months at adoption |
| Commissioning mother | 12 weeks |
| Work from home option | Employer with ≥50 employees may offer, post-maternity leave — if nature of work permits |
| Crèche facility | Mandatory for ≥50 employees — within 500m or at workplace |
| Medical bonus | [IN-133] if no pre/post-natal care provided by employer |
| Notice before dismissal | Cannot dismiss or discharge during maternity leave |

---

## Industrial Employment (Standing Orders) Act 1946

- Applies to factories + industrial establishments ≥ 100 employees
- Standing Orders must be certified by Certifying Officer (DLC Chennai) within 6 months of reaching threshold
- Must cover: Classification of workers, attendance, leave, misconduct, suspension, termination
- Displayed at workplace (Tamil + English in TN)

---

## Audit Procedures — Labour Laws

1. Obtain TN S&E Registration Certificate — verify validity, category, registered employee count
2. Verify actual employee count vs. registered count — underdeclaration = registration non-compliance
3. Test leave ledger: Confirm leave types credited and debited per Act entitlements
4. Test salary payment dates against registers — late payment = TN S&E Act violation
5. Verify OT records: Hours × 2× rate; verify quarterly OT does not exceed 50 hours/employee
6. For factories: Verify Form 2 (Factory Licence), Form 21/22 annual returns filed
7. Maternity register: Verify ≥26 weeks paid leave granted; WFH option documented (if ≥50 employees)
8. Standing Orders: Verify certified and displayed (if ≥100 employees)
9. CLRA: All procedures per CLRA section above [superseded 21-Nov-2025 — re-map to Code]

---

## Red Flags — Labour Laws

- OT paid at regular rate instead of 2× (Factories Act / TN S&E Act violation) [superseded 21-Nov-2025 — re-map to Code]
- Contract workers on site without CLRA Form V licence [superseded 21-Nov-2025 — re-map to Code]
- Maternity leave denied or truncated (Sec 21A — compoundable offence)
- No TN S&E registration / expired registration — serious risk if labour inspection
- Employment of persons under 18 in hazardous categories (Child Labour Act)
- Termination without notice / hearing for permanent employees (Industrial Disputes Act) [superseded 21-Nov-2025 — re-map to Code]
- Standing Orders not certified for factories/large establishments
- Service certificate not issued on separation (TN S&E Act Sec 26)
- Working hours exceeding 9hr/day or 48hr/week without Form 3A permission (Factories Act) [superseded 21-Nov-2025 — re-map to Code]
