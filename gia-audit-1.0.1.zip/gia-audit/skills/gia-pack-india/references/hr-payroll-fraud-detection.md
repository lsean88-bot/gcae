> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.

# Payroll Fraud Detection — Chennai HR Audit Reference
# ACFE Fraud Tree | Benford's Law | Data Analytics

## ACFE Payroll Fraud Schemes (Manufacturing/Service Context)

### Scheme 1: Ghost Employees
**Definition:** Fictitious employees on payroll — salary paid to non-existent persons
**Detection tests:**
- Match HRMS employee master to physical access control records (biometric/card)
- Match payroll register to EPFO ECR (UAN-level) — employees on payroll not on ECR = ghost risk
- Identify employees with no attendance record for >30 consecutive days but salary paid
- Verify joining documents for all employees (offer letter, appointment letter, Aadhaar-PAN-bank KYC)
- Flag employees with: PO Box bank addresses, no nominees, no emergency contact
- Identify terminated employees still receiving salary post-last working day + 15 days

### Scheme 2: Falsified Hours/Overtime
**Detection tests:**
- Cross-match OT hours claimed in payroll to production shift reports (OT should occur only when production ran)
- Verify OT on Sundays/National Holidays → require prior sanction + production records
- Flag employees claiming OT in excess of Factories Act limit (Sec 64 — max 50 OT hours per quarter without exemption) [superseded 21-Nov-2025 — re-map to Code]
- Apply time-series analysis on OT hours — sudden spikes without production justification

### Scheme 3: Salary Manipulation / Unauthorized Increments
**Detection tests:**
- Pull salary history from HRMS → verify every salary change has HR approval document
- Flag backdated increments (increment date < HR approval date)
- Identify increments processed by payroll staff for themselves or relatives
- Verify access controls: HR admin who processes payroll cannot approve increments

### Scheme 4: Fictitious Deductions / Manipulation
**Detection tests:**
- Recompute all statutory deductions (EPF, ESIC, PT, LWF) from first principles
- Verify deductions collected from employees are actually remitted to authorities
  - PT: payroll deduction sum ≠ PT challan = employer fraud
  - EPF: payroll deduction sum ≠ EPFO remittance = misappropriation (Sec 406 IPC)
- Test for manipulated net pay (negative deductions, zero deductions without valid reason)

### Scheme 5: Payroll Diversion
**Detection tests:**
- Verify all bank accounts in payroll master against original documents (cancelled cheque + Aadhaar)
- Flag bank account changes: identify changes in last 6 months → verify employee consent form + dual approval
- Test for accounts changed after employee resignation
- Verify payroll bank file (NEFT batch) generated from HRMS system, not manual upload

### Scheme 6: Benefits Fraud
**Detection tests:**
- Test reimbursement claims (medical, LTA, conveyance) — verify original bills, not photocopy bundles
- LTA: verify transport proof (boarding pass / train ticket) with journey dates matching leave records
- Verify no duplicate reimbursement claims (same bill submitted twice or to different entities)

---

## Benford's Law Application

### Where to apply:
1. **Net pay amounts** — 1st digit distribution should follow Benford; deviation in [band set in engagement plan]–[band set in engagement plan] range signals threshold manipulation
2. **OT amounts** — 2nd digit; round numbers ([round values set in engagement plan] [round values set in engagement plan]) cluster = manual entry
3. **Reimbursement claims** — look for clustering just below approval thresholds (e.g., bulk claims of [value just below the approval limit] if approval required above [approval limit per entity policy])
4. **Salary amounts** — 1st/2nd digit test on entire population

Benford and digit tests: run through `gia-fraud:gia-fraud-analytics` (Nigrini MAD primary with per-digit z-scores; chi-square supplementary for small populations). Confirm the preconditions (population size, range across orders of magnitude, no assigned or bounded numbers), segment fixed-amount populations first, and record the MAD table version in the workpaper. A deviation is an indicator, never a conclusion. Inline thresholds from the retired source were removed.

---

## Data Analytics Checklist (100% Population)

| Test | Data Required | Red Flag |
|------|--------------|----------|
| Duplicate PAN | Payroll master PAN field | Same PAN, different employee ID |
| Duplicate bank account | Payroll master account no. | Same account for ≥2 employees |
| Payroll vs. EPFO ECR count | HRMS headcount vs. ECR | Variance > 0 requires explanation |
| Active employee, no attendance | HRMS + attendance system | >15 days absent, full salary paid |
| Salary paid post-resignation | Exit register + payroll dates | Salary after LWD + 15 days |
| EPF deduction < statutory | Payroll EPF column vs. [IN-001] calculation | Underpayment ≥ [any amount] |
| PT deduction vs. slab | Net pay × TN PT slab | Over/under deduction |
| OT on no-production days | OT payroll vs. production register | OT paid, no production record |
| Reimbursement threshold clustering | Claim amounts histogram | >[share set in engagement plan] of claims just below limit |
| Digit-distribution test | Net pay, OT, reimbursements | Per the Benford note above |

---

## Escalation Protocol
- Ghost employee confirmed → escalate to GCAE + Legal immediately (potential IPC Sec 406/420)
- EPF/ESIC deduction not remitted → report to EPFO/ESIC Regional Office; quantify with penalty
- Payroll diversion → freeze payments to affected accounts; HR + Finance + Legal joint investigation
- All fraud investigations: document per IIA Standard 13.2 (Investigation Conduct) and ICAI SIA 11
