> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- Maharashtra Pollution Control Board (MPCB) — Pune Region
- Hazardous / Scheduled Waste (Pune MIDC Manufacturing)
- MIDC (Maharashtra Industrial Development Corporation) — Pune
- Factories Act 1948 — Maharashtra Factories Rules 1963 (Pune) [superseded 21-Nov-2025 — re-map to Code]
- Fire Safety — Pune
- PMC (Pune Municipal Corporation) — Local Body
- MSME Registration (Pune Context)
- Legal Metrology (Maharashtra / Pune)
- Environment & Safety Audit Procedures (Pune)
- Statutory Licence vs. Customer/Quality Certification — Critical Distinction
- Red Flags — Environment & Safety (Pune)


# R12 — Environment, Safety & Local Regulations (Pune / Maharashtra)

## Maharashtra Pollution Control Board (MPCB) — Pune Region

**MPCB Pune Office:** mpcbpune@mpcb.gov.in | mpcb.gov.in
**Online portal:** Ec-MPCB Web Portal (ecmpcb.in) — all consents, authorizations, returns
**MPCB Helpdesk:** 7045113344 / 7045113322

### Applicability — Industry Categories

| Category | Pollution Potential | Pune Examples | Consent Period |
|----------|-------------------|---------------|---------------|
| Red | High | Electroplating, chemicals, foundries, forging, tanneries | CTO — 5 years |
| Orange | Moderate | Auto ancillary (machining), food processing, pharma API, printing | CTO — 5 years |
| Green | Low | Assembly, electronic goods, packaging, textiles | CTO — 10 years |
| White | Negligible / Zero | IT/software, educational institutions, hospitals (small), clinics | **Exempted from CTO** |

> **Pune MIDC (Pimpri-Chinchwad, Chakan, Ranjangaon, Talegaon):** Most manufacturing units = Orange or Red category. IT companies in Hinjewadi/Baner = White (exempt from CTO).

### Consents Required (MPCB)
1. **Consent to Establish (CTE):** Before construction/setting up plant; based on investment and pollution category
2. **Consent to Operate (CTO):** Before commencement of operations; renewed before expiry
3. **Hazardous Waste Authorization:** If generating scheduled/hazardous waste

### MPCB Online Returns / Compliance (Ec-MPCB Portal)
| Return/Compliance | Frequency | Portal |
|------------------|-----------|--------|
| Environmental Statement (Form V) | Annual — by 30 September | ecmpcb.in |
| CEMS (Continuous Emission Monitoring) | If notified — real-time online | ecmpcb.in |
| Water consumption report | As per CTO condition | ecmpcb.in |
| Hazardous waste annual return | By 31 May (for previous year) | ecmpcb.in |
| MPCB CTO renewal | Before expiry date | ecmpcb.in |

---

## Hazardous / Scheduled Waste (Pune MIDC Manufacturing)

**Governed by:** Hazardous and Other Wastes (Management and Transboundary Movement) Rules 2016

| Waste Type | Pune Industry | Disposal Rule |
|-----------|--------------|---------------|
| Spent solvents, paint sludge | Auto ancillary painting | MPCB-authorized TSDF only |
| ETP sludge | Pharma/chemical Pune | MPCB-authorized disposal |
| Metal grinding sludge | Pimpri-Chinchwad machining units | MPCB-authorized recycler |
| E-waste | All Pune industries | E-Waste (Management) Rules 2022 — CPCB-registered recycler |
| Battery waste | Auto OEM/ancillary | Battery Waste Management Rules 2022 |
| Used oil / lubricants | MIDC factories | MPCB-authorized re-refiner |

**Form 3 Manifest:** Mandatory for every hazardous waste movement — accompanies consignment from factory to disposal site. Annual return by 31 May.

---

## MIDC (Maharashtra Industrial Development Corporation) — Pune

**MIDC Pune Areas:** Pimpri-Chinchwad, Chakan, Ranjangaon, Talegaon, Bhosari, Hadapsar

| Compliance | Requirement | Authority |
|-----------|------------|---------|
| MIDC plot allotment letter | Proof of industrial plot; maintained at factory | MIDC Pune |
| MIDC NOC for construction | Before any construction/expansion | MIDC Pune |
| MIDC water connection | Separate from PMC supply; monthly usage bill | MIDC |
| MIDC industrial effluent | Connection to MIDC CETP (Common Effluent Treatment Plant) if available | MIDC + MPCB |
| MIDC road use | Heavy vehicle access; road damage clearance | MIDC |
| MIDC lease renewal | Typically 95-year lease; mid-term renewals and premiums | MIDC |

---

## Factories Act 1948 — Maharashtra Factories Rules 1963 (Pune)

### Key Compliance

| Provision | Requirement | Authority |
|-----------|------------|---------|
| Annual licence (Form 2 MH) | Renewed by 31 December for the following calendar year | Inspector of Factories (Pune division) |
| Occupier notification (Form 7) | Within 15 days of appointment | Inspector of Factories |
| Manager notification (Form 7A) | Within 15 days of appointment | Inspector of Factories |
| Accident reporting — Fatal | Immediately (Form 18A) | Inspector + Police + DIC |
| Accident reporting — Major | Within 24 hours (Form 18) | Inspector of Factories |
| Annual return (Form 21) | By **31 January** | Inspector of Factories |
| Half-yearly return (Form 22) | By **31 July** | Inspector of Factories |
| Safety committee | ≥250 workers — mandatory; meets quarterly | Internal |
| Canteen | ≥250 workers — mandatory | Inspector of Factories |
| Creche | ≥30 women workers — mandatory | Inspector of Factories |
| First aid | 1 first-aider per shift; box at each work area | Inspector of Factories |
| Fire extinguisher | Certified annually by approved agency | Inspector + Fire Brigade |
| Mock drill | At least annually | Factory records |
| Accident register (Form 26) | Maintained continuously | Internal + Inspector |

---

## Fire Safety — Pune

| Requirement | Authority | Applicability |
|-------------|-----------|--------------|
| Fire NOC (No Objection Certificate) | Pune Fire Brigade (part of PMC) | Buildings >15m height; industrial; assembly occupancy; hotels; hospitals |
| Annual renewal | Pune Fire Brigade | Annual — before expiry |
| Fire Safety Audit | Pune Fire Brigade / certified auditor | Large buildings, factories |
| Mock drill | Factories Act Rule + Fire Brigade | Annually; attendance record kept | [superseded 21-Nov-2025 — re-map to Code]
| Fire extinguisher certification | Certified fire safety agency | Annually |

**Pune Fire Brigade contact:** Pune Municipal Corporation (PMC) — Fire Headquarters, Pune.

---

## PMC (Pune Municipal Corporation) — Local Body

| Licence/Compliance | Requirement | Due Date | Authority |
|-------------------|------------|---------|---------|
| PMC Trade Licence | Mandatory for all businesses within PMC limits | Annual renewal | PMC (mahaonline.gov.in) |
| PMC Building Plan approval | Before any construction | Before commencement | PMC / PMRDA |
| PMC Completion Certificate | Before occupancy | After construction | PMC |
| PMC Signage / Advertisement | Annual licence fee for any display | Annual | PMC |
| PMC Food Safety (FSSAI) | If food business — FSSAI registration/licence | Annual | FSSAI + TN Food Safety Dept |
| PMC Water Connection | Municipal water supply | Monthly bills paid | PMC |

### PCMC (Pimpri-Chinchwad Municipal Corporation)
- Separate authority for Pimpri-Chinchwad (major industrial area)
- Trade licence from PCMC (not PMC) for businesses in PC area
- PCMC building permissions for MIDC-adjacent industrial buildings

---

## MSME Registration (Pune Context)

**Udyam Registration Portal:** udyamregistration.gov.in

| Category | Investment (Plant & Machinery) | Annual Turnover |
|----------|-------------------------------|-----------------|
| Micro | ≤[IN-119] | ≤[IN-119] |
| Small | ≤[IN-119] | ≤[IN-119] |
| Medium | ≤[IN-119] | ≤[IN-119] |

> **Pune MSME ecosystem:** One of India's largest — Pimpri-Chinchwad region has received [statistic removed: unverified] of MH MSME investment. Most Pune auto ancillary vendors and IT services SMEs qualify as MSME. Verify on portal before classifying for payment terms.

---

## Legal Metrology (Maharashtra / Pune)

- Legal Metrology Act 2009: All traders/manufacturers using weights and measures must be registered
- Controller of Legal Metrology, Maharashtra — Pune district office
- Annual verification of weighing scales, measuring instruments (critical for MIDC factories — raw material/scrap weighment)
- **Audit risk:** Uncertified weighbridge at factory = measurement disputes + penalty

---

## Environment & Safety Audit Procedures (Pune)

1. Verify MPCB CTO validity from ecmpcb.in — expiry date, category (Red/Orange/Green)
2. Verify MPCB Environmental Statement (Form V) filed by 30 September
3. Hazardous waste: Obtain Form 3 manifests — verify MPCB-authorized TSDF/recycler only
4. E-waste / battery waste: CPCB portal — registered recycler certificates
5. Fire NOC (Pune Fire Brigade): Verify validity; annual renewal
6. PMC / PCMC Trade Licence: Annual renewal confirmed
7. MIDC: Verify allotment letter; MIDC NOC for any construction/expansion; MIDC water bills paid
8. Factory Licence (Form 2 MH): Valid for current year; renewed by 31 Dec
9. Accident register: Review Form 26 for last 3 years — any major/fatal incidents not reported to Inspector?
10. Mock drill records: At least annual; signed attendance
11. Safety committee minutes: Quarterly meetings (factories ≥250 workers)
12. Legal Metrology: Weighbridge certification — verify annual calibration certificate
13. MSME registration: Udyamregistration.gov.in for all vendors claiming MSME status

---

## Statutory Licence vs. Customer/Quality Certification — Critical Distinction

**IRON RULE:** A quality-management or process-audit certification (VDA 6.3, IATF 16949, ISO 9001, ISO 14001, ISO 45001) is a **customer/commercial requirement assessed by an accredited or customer-approved body**. It is **NOT** a statutory operating licence and must never be treated as, or reported as, a substitute for factory licence, MPCB CTE/CTO, Fire NOC, labour registrations, or GST registration. Track the two as **separate gates** in every audit and every readiness tracker.

| Item | Purpose | Issuing/Assessing Body | Mandatory by Law? |
|------|---------|------------------------|---------------------|
| Factory licence, MPCB CTE/CTO, Fire NOC, GST, EPF/ESIC | Legal authorisation to operate | Government authority (DISH, MPCB, PMC/PCMC Fire, GST, EPFO/ESIC) | Yes, where applicable |
| VDA 6.3 | Automotive process-audit assessment | VDA-QMC-licensed training/examination ecosystem, or customer-approved auditor | No — customer/commercial requirement |
| IATF 16949 | Automotive QMS certification | Accredited certification body | No — customer/supply-chain requirement |
| ISO 9001 / 14001 / 45001 | QMS/EMS/OHSMS certification | Accredited certification body | No — commercial requirement (occasionally tender-mandated) |

**Auditor vs. plant certification:** VDA 6.3 auditor qualification (VDA-QMC qualification, ISO 19011-based training, Automotive Core Tools knowledge, relevant industry/QMS experience) attaches to the **individual auditor**, not the plant. Before reporting a "VDA 6.3 certification" finding, obtain the customer's written requirement and clarify whether it means: (a) a customer VDA 6.3 process audit, (b) a VDA-QMC-certified process auditor, (c) a customer-approved supplier audit, (d) IATF 16949 certification, (e) ISO 9001 certification, or (f) an internal/corporate VDA compliance self-assessment. These six are not interchangeable and must not be conflated in a finding or a readiness tracker.

**Audit procedure:** When scoping any Pune manufacturing engagement (new plant, new customer programme, plant takeover/cutover, or acquisition), build **two parallel workstreams** from Day 1:
1. Statutory legal compliance for operating the facility (factory licence → MPCB CTE/CTO → Fire NOC → building/occupancy → labour registrations → GST).
2. Customer/OEM quality-readiness (VDA 6.3 / IATF 16949 / ISO, as specified in the customer contract).

Never let progress or completion on workstream 2 be cited as evidence of compliance on workstream 1, or vice versa — this is a recurring conflation risk in plant-readiness reporting and must be flagged as a finding if observed in management's own status reporting.

### Jurisdiction confirmation is a prerequisite, not an assumption

Before relying on any Fire NOC, building permission, or trade-licence status, confirm the **exact competent local authority** for the site address — do not assume PMC coverage by default:

| Site Location | Likely Authority | Note |
|---|---|---|
| Pune city limits | Pune Municipal Corporation (PMC) — Fire, Building, Trade Licence | |
| Pimpri-Chinchwad | PCMC — separate Fire, Building, Trade Licence (not PMC) | |
| MIDC estate (Chakan, Ranjangaon, Talegaon, Bhosari, Hadapsar) | MIDC (plot/lease/NOC) **plus** local fire and planning authority | An MIDC location changes the competent authority for building/fire matters — it does **not** remove the requirement for factory licence, MPCB consent, or labour registrations |
| Outside municipal limits | District/local planning body | Confirm building, occupancy, fire and industrial-use approvals separately |

### Pre-production Go/No-Go readiness tracker — reusable workbook pattern

For any new Pune plant, plant takeover, or major process/customer-programme cutover, build a multi-tab Excel tracker (not a narrative memo) with this structure — proven on GIA-2026-MKAPL-PUN-VDA-COMPLIANCE-001:

1. **Cover_Index** — entity, engagement type, statutory-vs-certification distinction stated up front, status-code legend, verification caveat.
2. **Dashboard** — live `COUNTA`/`COUNTIF`-driven completion % by category (never hardcoded), plus an explicit **Go/No-Go gate formula** (`IF(AND(...)=0,...)`) counting Open/To Confirm items among **High-priority statutory items only**. Certification-workstream items (VDA/IATF/ISO) are tracked on the dashboard but **excluded from the statutory Go/No-Go formula** — state this exclusion explicitly as a dashboard note so the reader cannot mistake a certification gate for a legal one.
3. **Priority_Permits** — every statutory permit/registration ranked by priority number, with authority, applicability trigger, "when required," current status, and required action.
4. **Factory_Licence_File** — DISH Maharashtra document checklist (registration, approved plans, occupier/manager nomination, stability certificate, annual/half-yearly returns, accident register).
5. **MPCB_Applicability** — process-by-process screen (presses, oil, scrap, degreasing, painting, heat treatment, welding, DG set, compressed air, gas storage) — a bare stamping/machining operation is not automatically low-risk; each ancillary process re-triggers CTE/CTO/hazardous-waste applicability.
6. **Fire_Building_Jurisdiction** — the PMC/PCMC/MIDC table above, as a standing worksheet, not a one-off note.
7. **Labour_Direct_Employees** and **Contractor_Compliance** — apply the existing R03/R05/R09 thresholds and CLRA controls from this skill. [superseded 21-Nov-2025 — re-map to Code]
8. **[Certification]_Readiness** (e.g. VDA6.3_Readiness) — quality-system elements (PFMEA, control plan, MSA, traceability, internal audits, auditor qualification) kept on its own tab, explicitly labelled as customer/commercial, not statutory.
9. **Action_Tracker** — immediate actions with owner, priority, and dependency, feeding the Dashboard gate.

Status values are dropdown-validated (`Open / In Progress / To Confirm / Conditional / Closed / Not Applicable`); conditional formatting colours Closed green, Open red, and To Confirm/Conditional amber. This same skeleton reapplies directly to MKAPL Jacks, MKAPL Diecasting (Chennai — swap MPCB→TNPCB/Ec-MPCB→OCMMS per the CAE's 18-Aug-2026 confirmed entity structure), and Erawan/MKPC plant-cutover or new-customer-programme engagements — only the authority names, portals, and process-applicability table change.

---

## Red Flags — Environment & Safety (Pune)

- MPCB CTO expired — operations technically illegal; risk of closure order
- Hazardous waste disposal records missing — unauthorized dumping risk (EPA 1986: [IN-135] fine + 5+ years imprisonment)
- Hazardous waste disposed of with non-MPCB-authorized vendor (common cost-cutting in Pune MIDC)
- Fire NOC expired in commercial/industrial building
- Factory licence (Form 2 MH) not renewed by 31 December
- MIDC building constructed without MIDC NOC — demolition risk
- Scrap sold to unregistered scrap dealer without GST invoice + no Form 3 manifest (hazardous scrap)
- No weighbridge calibration certificate — input/output measurement fraud risk
- Vendor claiming MSME status but not found on udyamregistration.gov.in (false MSME claim)
- Factory with >250 workers but no Safety Committee or quarterly meetings not held
