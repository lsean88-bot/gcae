> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- Critical Update — Labour Codes Effective Nov 21, 2025
- EPF Contribution Rates (Current — May 2026)
- ESIC Contribution Rates (Current)
- Remittance Deadlines
- Audit Procedures — EPF/ESIC
- Red Flags — EPF/ESIC


# R03 — EPF, ESIC & Labour Codes Social Security

## Critical Update — Labour Codes Effective Nov 21, 2025

The four Labour Codes were officially notified in the Official Gazette on **November 21, 2025**.
ESIC implementing notifications were issued **December 10-11, 2025**.
**First affected payroll cycle: December 2025.**

All payroll periods from December 2025 onwards must comply with the new uniform wages definition.

### New "Wages" Definition (Code on Social Security 2020)

**Key change:** If a worker's allowances (HRA, conveyance, special allowance, etc.) exceed [IN-017] of total remuneration, the EXCESS is added back to wages for EPF and ESI contribution purposes.

**Formula:**
```
Total remuneration = Basic + DA + All allowances (excluding statutory exclusions)
Permitted allowances = [IN-017] of total remuneration
If actual allowances > [IN-017] → Excess = actual allowances - [IN-017] of total
Revised wage base = Basic + DA + Excess allowances
EPF/ESI contributions computed on Revised wage base
```

**Impact:** Companies that structured salaries with high allowances and low Basic+DA to minimize EPF/ESI will now have a HIGHER contribution base. Bills/payroll from Dec 2025 onwards must reflect this.

---

## EPF Contribution Rates (Current — May 2026)

| Component | Rate | Base | Cap | Remitting Party |
|-----------|------|------|-----|----------------|
| Employee EPF | [IN-001] | Basic + DA | No cap for employee | Employee (via employer) |
| Employer EPS | [IN-002] | Basic + DA | Capped at [IN-002]/mo (wage ceiling [IN-006]) | Employer |
| Employer EPF (differential) | [IN-003] | Basic + DA | No cap | Employer |
| EPFO Admin | [IN-004] | Basic + DA | Min [IN-122]/mo per establishment | Employer |
| EDLI | [IN-005] | Basic + DA | Capped at [IN-006] wage | Employer |
| **Total employer cost** | **[IN-121] + [IN-121]** | | | |

**EPF Interest Rate:** [IN-014] p.a. for FY 2024-25 and FY 2025-26 (CBT Feb 2025).

**Applicability threshold:** Establishments with ≥ 20 employees (some categories ≥ 10).

**Voluntary coverage:** Employees with wages >[IN-016]/mo who join after 01 Sep 2014 are exempt from mandatory coverage BUT may opt in voluntarily (Form 11).

**International Workers:** Separate ECR; higher contribution — verify passport/visa for all expats.

---

## ESIC Contribution Rates (Current)

| Component | Rate | Base | Ceiling |
|-----------|------|------|---------|
| Employee | [IN-009] | Gross wages | ≤ [IN-010]/mo gross |
| Employer | [IN-008] | Gross wages | ≤ [IN-010]/mo gross |
| Total | [IN-124] | | |

**Wage ceiling:** Employees earning > [IN-010]/mo gross are EXEMPT from ESIC.
**Daily wage exemption:** Employees with daily average wage ≤ [IN-015] — employer still contributes; employee exempt.
**Applicability:** Factories and establishments with ≥ 10 employees (some states: ≥ 20).
**Contribution periods:** Apr-Sep (IP Oct-Mar benefit) | Oct-Mar (IP Apr-Sep benefit).

---

## Remittance Deadlines

| Statutory | Due Date | Portal |
|-----------|---------|--------|
| EPF ECR filing + challan | 15th of following month | epfindia.gov.in |
| ESIC ECR filing + challan | 15th of following month | esic.gov.in |

**Penalties:**
- EPF: Sec 7Q — [IN-123] p.a. interest on delayed payments; Sec 14B — damages up to [IN-007] of arrears (for wilful defaults)
- ESIC: Sec 85 — prosecution; Sec 85B — [IN-125] interest on delayed contributions

---

## Audit Procedures — EPF/ESIC

1. Download 100% ECR from EPFO and ESIC portals for all months under review (Rank 1 evidence)
2. Cross-match ECR headcount to HRMS payroll register headcount — unexplained gaps = ghost employee or exclusion risk
3. Recompute EPF contribution: Employee [IN-001] + Employer [IN-120] (split [IN-002] EPS + [IN-003] EPF) + [IN-004] admin + [IN-005] EDLI on 100% population
4. **Post–Nov 2025 periods:** Apply new wages definition test — for each employee, check if allowances > [IN-017] of gross → recalculate contribution base
5. Verify Form 11 for all employees with wages >[IN-016]/mo — either opt-in or exemption documented
6. Verify EDLI exemption certificate if company has its own group insurance scheme
7. ESIC: Identify all employees with gross ≤[IN-010]/mo → verify registered as Insured Persons → verify [IN-124] remitted
8. Test for mid-year wage crossers ([IN-010] threshold) — ESIC contribution stops prospectively at the end of that contribution period, not immediately
9. Cross-check challan deposit dates against 15th of month deadline
10. Obtain EPFO/ESIC acknowledgement receipts for all periods — Rank 1 evidence that contributions actually remitted (not just billed to principal employer)

---

## Red Flags — EPF/ESIC

- Payroll headcount > ECR headcount → excluded employees or EPFO exclusion violations
- EPF ECR headcount > actual workforce → ghost employees
- Contribution base appears same every month for all employees (likely static, ignoring overtime/bonus)
- ESIC contributions continuing after employee crossed [IN-010] threshold
- No Form 11 on file for high-wage employees (>[IN-016] Basic+DA)
- Contractor billing EPF/ESIC reimbursement without providing EPFO/ESIC challan copies (collecting but not remitting)
- Post-Dec 2025 bills showing same EPF/ESIC base as pre-Dec 2025 (not reflecting Labour Codes change)
- EDLI rate applied on wages >[IN-005] (incorrect — EDLI capped at [IN-005] wage)
