# Statutory register - India

Single dated source for every statutory rate, threshold and date used by the India pack. Skill and reference text must point here and must not restate values.

Owner: statutory-validator agent (fills `source URL`, `verified-on`, `status`); freshness gate: `python3 -I ${CLAUDE_PLUGIN_ROOT}/skills/gias-navigator/scripts/check_rates.py` (rows older than 180 days or not VERIFIED are flagged).
Seeded 2026-10-29 from the retired source skills; rows marked VERIFIED or SECONDARY-ONLY were updated from the validated-facts run of 29-Oct-2026. Every other row is `[UNVERIFIED]` until the validator replaces the status with `VERIFIED`, `CORRECTED` or `CONFLICT` and fills `verified-on`.

Column notes:
- `id` is the stable row identifier cited by every `[IN-nnn]` pointer in the pack. Never renumber or reuse an id; append new rows with the next number.
- `value` is copied as stated in the source skill, including its own caveats.
- `source URL` holds the portal named in the source skill; the validator replaces it with the primary-source deep link (gazette, notification, circular).
- Rows with a conflict note are listed in the conflict table at the end. A finding must not cite a row whose status is `[UNVERIFIED]` or `CONFLICT` (see `gia-core:iron-rules`, evidence rules).

## Contents
- Social security
- Direct tax and TDS
- GST
- Tamil Nadu
- Maharashtra
- Puducherry
- Wages, bonus, gratuity, contract labour, POSH
- Direct tax and TDS (additions)
- Cash, banking and reporting limits
- GST rates, returns and thresholds
- Company law and MCA
- Social security (additions)
- Wages, bonus, penalties and state rows (additions)
- Conflicts to resolve
- Open dependencies

## Social security
| id | item | Act/section | value | effective date | source URL | verified-on | status |
|---|---|---|---|---|---|---|---|
| IN-001 | EPF employee contribution | EPF & MP Act 1952; EPF Scheme 1952 Para 29 [superseded 21-Nov-2025 — re-map to Code] | 12% of Basic + DA | Current | epfindia.gov.in | | [UNVERIFIED] |
| IN-002 | employer share to EPS | EPF Scheme 1952 [superseded 21-Nov-2025 — re-map to Code] | 8.33%, capped at Rs 1,250/month (wage ceiling applies) | Current | epfindia.gov.in | | [UNVERIFIED] |
| IN-003 | employer EPF share | EPF Scheme 1952 [superseded 21-Nov-2025 — re-map to Code] | 3.67% of Basic + DA | Current | epfindia.gov.in | | [UNVERIFIED] |
| IN-004 | EPFO administrative charge | EPF Scheme 1952 [superseded 21-Nov-2025 — re-map to Code] | 0.50% of Basic + DA | Current | epfindia.gov.in | | [UNVERIFIED] |
| IN-005 | EDLI contribution | EDLI Scheme (as cited in source) | 0.50% (wages up to the ceiling) | Current | epfindia.gov.in | | [UNVERIFIED] |
| IN-006 | EPF/EPS statutory wage ceiling | Code on Social Security 2020 s.2(89) (wage ceiling for Chapter III); MoLE notification S.O. 5109(E) | Rs 25,000/month (supersedes Rs 15,000, which applied from 29-May-2026 to 16-Sep-2026 per secondary source) | 17-Sep-2026 | https://www.pib.gov.in/PressReleasePage.aspx?PRID=2313790 ; https://www.labour.gov.in/static/uploads/2026/09/4f607a88c5342aeb980c6b999997caab.pdf | 29-Oct-2026 | VERIFIED (ceiling and date); SECONDARY-ONLY (S.O. number, supersession) |
| IN-007 | damages for late EPF payment | EPF & MP Act 1952 (section not stated in source) [superseded 21-Nov-2025 — re-map to Code] | 1% per month simple (not a 5-25% tier), per validator trap list | Current | epfindia.gov.in | | [UNVERIFIED] |
| IN-008 | ESIC employer contribution | ESI Act 1948 [superseded 21-Nov-2025 — re-map to Code] | 3.25% of gross wages | 01-Jul-2019 (unchanged per source) | esic.gov.in | | [UNVERIFIED] |
| IN-009 | ESIC employee contribution | ESI Act 1948 [superseded 21-Nov-2025 — re-map to Code] | 0.75% of gross wages | 01-Jul-2019 (unchanged per source) | esic.gov.in | | [UNVERIFIED] |
| IN-010 | ESIC coverage wage ceiling | ESI Act 1948 s.2(9) read with Rule 50 ESI (Central) Rules 1950 (not s.2(22)) [superseded 21-Nov-2025 — re-map to Code] | Rs 21,000/month (Rs 25,000 for persons with disabilities) | 01-Jan-2017 (per ESIC page) | https://esic.gov.in/coverage | 29-Oct-2026 | VERIFIED (amount). Legal basis s.2(9)/Rule 50 not re-verified; whether the ESI Act still governs after 21-Nov-2025 is OPEN |
| IN-011 | ESIC Amnesty Scheme 2025 | ESIC scheme 2025 | Settlement scheme for criminal, s.75 and s.82 cases filed by 31-Mar-2025; not a general late-registration penalty waiver | 2025 | esic.gov.in | | [UNVERIFIED] |
| IN-012 | EPF applicability (headcount) | EPF & MP Act 1952 [superseded 21-Nov-2025 — re-map to Code] | 20 or more employees | Current | epfindia.gov.in | | [UNVERIFIED] |
| IN-013 | ESIC applicability (headcount) | ESI Act 1948 [superseded 21-Nov-2025 — re-map to Code] | 10 or more employees | Current | esic.gov.in | | [UNVERIFIED] |
| IN-014 | EPF interest rate | EPF Scheme 1952 para 60 | not re-verified (pre-Code text said 8.25% for FY 2024-25 and FY 2025-26) | n/a | n/a | n/a | [UNVERIFIED] |
| IN-015 | ESIC daily-wage exemption | ESI Act 1948 [superseded 21-Nov-2025 — re-map to Code] | not re-verified | n/a | n/a | n/a | [UNVERIFIED] |
| IN-016 | voluntary coverage above ceiling | EPF Scheme 1952 [superseded 21-Nov-2025 — re-map to Code] | not re-verified | n/a | n/a | n/a | [UNVERIFIED] |
| IN-017 | allowance add-back (50% test) | Code on Wages 2019 s.2(y) | not re-verified | n/a | n/a | n/a | [UNVERIFIED] |
| IN-018 | four Labour Codes status | Code on Wages 2019; Code on Social Security 2020; IR Code 2020; OSH Code 2020 | All four in force; subsume 29 central labour laws; old Acts, rules and schemes continue until corresponding rules are framed | 21-Nov-2025 | https://www.pib.gov.in/PressReleseDetailm.aspx?PRID=2192463 | 29-Oct-2026 | VERIFIED |
| IN-019 | Code wage definition 50% rule | Code on Wages 2019 s.2(y); Code on Social Security 2020 | Allowances above 50% of gross: excess re-enters the EPF/ESIC wage base | 21-Nov-2025 | labour.gov.in | | [UNVERIFIED] |
| IN-020 | Code on Social Security commencement | Code on Social Security 2020; S.O. 5319(E) of 21-Nov-2025 (corrigendum 19-Dec-2025) | In force from 21-Nov-2025: ss.1-14, 15(1)-(2), 16(1)(c), 17-141, 143 (except provisions in S.O. 2060(E)), 144-163 and listed parts of s.164; EPS-related provisions from 03-May-2023 (S.O. 2060(E)). Repeal is by s.164; a secondary source says ESI Act repealed with rules and schemes saved to 20-Nov-2026 | 21-Nov-2025 | https://labour.gov.in/sites/default/files/e-_noti-ss_0.pdf | 29-Oct-2026 | VERIFIED (S.O. 5319(E)); corrigendum and ESI repeal SECONDARY-ONLY |
| IN-021 | final rules under the four Codes | All four Codes | Final rules status not confirmed | n/a | https://www.labour.gov.in (additional FAQs 16-Mar-2026, not read) | 29-Oct-2026 | NOT FOUND ([UNVERIFIED]) |

## Direct tax and TDS
| id | item | Act/section | value | effective date | source URL | verified-on | status |
|---|---|---|---|---|---|---|---|
| IN-022 | Income-tax Act 2025 | Income-tax Act 2025 | Replaces ITA 1961; s.392(1) salary TDS from TY 2026-27; ITA 1961 governs FY 2025-26 payroll | 01-Apr-2026 | incometax.gov.in / tdscpc.gov.in | | [UNVERIFIED] |
| IN-023 | TDS on contractor payments | ITA 1961 s.194C / ITA 2025 s.393 (as cited in source) | 1% individual/HUF; 2% company/firm | Unchanged per source; ITA 2025 from 01-Apr-2026 | incometax.gov.in / tdscpc.gov.in | | [UNVERIFIED] |
| IN-024 | s.194C thresholds | ITA 1961 s.194C | Rs 30,000 single payment or Rs 1,00,000 aggregate in the year (from test T-003) | Current | incometax.gov.in / tdscpc.gov.in | | [UNVERIFIED] |
| IN-025 | TDS on professional / technical fees | ITA 1961 s.194J / ITA 2025 equivalent | 10% professional; 2% technical | Unchanged per source | incometax.gov.in / tdscpc.gov.in | | [UNVERIFIED] |
| IN-026 | TDS where no valid PAN | ITA 1961 s.206AA | 20% | Current | incometax.gov.in / tdscpc.gov.in | | [UNVERIFIED] |
| IN-027 | TDS challan due date | Income-tax Rules | 7th of the following month (test T-003) | Current | incometax.gov.in / tdscpc.gov.in | | [UNVERIFIED] |
| IN-028 | cash payment limit | ITA 1961 s.40A(3) / ITA 2025 equivalent | Rs 10,000 per person per day | ITA 1961 to 31-Mar-2026; ITA 2025 from 01-Apr-2026 | incometax.gov.in / tdscpc.gov.in | | [UNVERIFIED] |
| IN-029 | domestic company tax | ITA 2025 (section not stated in source) | 22% base; 25.17% effective with surcharge and cess | Current | incometax.gov.in / tdscpc.gov.in | | [UNVERIFIED] |
| IN-030 | new manufacturing company tax | ITA 2025 (section equivalent to s.115BAB, as cited in source) | 15% base plus surcharge and cess | Current | incometax.gov.in / tdscpc.gov.in | | [UNVERIFIED] |

## GST
| id | item | Act/section | value | effective date | source URL | verified-on | status |
|---|---|---|---|---|---|---|---|
| IN-031 | manpower / labour supply | CGST/SGST Acts 2017; SAC 9985, 998513, 998519 | 18% (9% + 9%) | Notification of 22-Sep-2025 (per TN source); 'Sep 2025' (MH source) | gst.gov.in | | [UNVERIFIED] |
| IN-032 | works contract, commercial | CGST Act 2017; SAC 9954 | 18% | Current | gst.gov.in | | [UNVERIFIED] |
| IN-033 | works contract, government infrastructure | Specific notification | 12% (verify per project) | Verify | gst.gov.in | | [UNVERIFIED] |
| IN-034 | ITC only if reflected in GSTR-2B | CGST Act 2017 s.16(2)(aa) | ITC eligible only where the invoice appears in GSTR-2B | 01-Jan-2022 | gst.gov.in | | [UNVERIFIED] |
| IN-035 | GSTIN state code Maharashtra | GST registration | 27 | Current | gst.gov.in | | [UNVERIFIED] |
| IN-036 | GSTIN state code Puducherry | GST registration | 34 | Current | gst.gov.in | | [UNVERIFIED] |

## Tamil Nadu
| id | item | Act/section | value | effective date | source URL | verified-on | status |
|---|---|---|---|---|---|---|---|
| IN-037 | minimum wage, Shops Zone A, unskilled | Minimum Wages Act 1948; TN Labour Dept notification [superseded 21-Nov-2025 — re-map to Code] | About Rs 13,783 per month (CPI-linked DA); factory unskilled Rs 13,783 to Rs 14,703 | 01-Apr-2026 (verify) | TN Labour Dept gazette | | [UNVERIFIED] |
| IN-038 | TN professional tax maximum | TN Professional Tax Act 1992 | Rs 2,500 per half-year | Apr-2024 revision | TN Commercial Taxes portal | | [UNVERIFIED] |
| IN-039 | TN labour welfare fund, employee | TN Labour Welfare Fund Act 1972 [superseded 21-Nov-2025 — re-map to Code] | Rs 20 per half-year | Current | TN LWF Board | | [UNVERIFIED] |
| IN-040 | TN labour welfare fund, employer | TN Labour Welfare Fund Act 1972 [superseded 21-Nov-2025 — re-map to Code] | Rs 40 per half-year | Current | TN LWF Board | | [UNVERIFIED] |
| IN-041 | TN Shops and Establishments Act amendment | TN S&E Act 1947 (Amdt 2025) [superseded 21-Nov-2025 — re-map to Code] | Applicability and conditions to be read from the amendment | 2025 | TN Labour Dept | | [UNVERIFIED] |

## Maharashtra
| id | item | Act/section | value | effective date | source URL | verified-on | status |
|---|---|---|---|---|---|---|---|
| IN-042 | minimum wage Zone I (PMR Pune), shops, unskilled | Minimum Wages Act 1948; MH Labour Dept notification [superseded 21-Nov-2025 — re-map to Code] | Rs 12,442 to Rs 14,638 plus (Basic + VDA); revised each Jan and Jul | Jan-2026 revision | mahakamgar.gov.in | | [UNVERIFIED] |
| IN-043 | additional HRA component | MH minimum wage notification | 5% of Basic + special allowance if establishment has more than 50 workers | Current | MH notification | | [UNVERIFIED] |
| IN-044 | MH professional tax, male maximum | MH PT Act 1975 | Rs 2,500 per year (Rs 200 x 11 months + Rs 300 in Feb) | Current | mahagst.gov.in | | [UNVERIFIED] |
| IN-045 | MH PT exemption thresholds | MH PT Act 1975 | Male: nil below Rs 7,500/month. Female: nil up to Rs 25,000/month | Current | mahagst.gov.in | | [UNVERIFIED] |
| IN-046 | employer PT enrolment certificate | MH PT Act 1975 | Rs 2,500 per year | Current | mahagst.gov.in | | [UNVERIFIED] |
| IN-047 | MH LWF employee | MH Labour Welfare Fund Act 1953 [superseded 21-Nov-2025 — re-map to Code] | Rs 25 per half-year (Jun and Dec) | Mar-2024 revision | mlwb.in | | [UNVERIFIED] |
| IN-048 | MH LWF employer | MH Labour Welfare Fund Act 1953 [superseded 21-Nov-2025 — re-map to Code] | Rs 75 per half-year (Jun and Dec) | Mar-2024 revision | mlwb.in | | [UNVERIFIED] |
| IN-049 | MH LWF applicability and due dates | MH LWF Act 1953 | 5 or more employees; due 30 June and 31 December | Current | mlwb.in | | [UNVERIFIED] |
| IN-050 | MH Shops and Establishments Act 2017 | MH S&E (Regulation of Employment and Conditions of Service) Act 2017 (Amdt Oct 2025) [superseded 21-Nov-2025 — re-map to Code] | Verify amendment content | Oct-2025 | MH Labour Dept | | [UNVERIFIED] |

## Puducherry
| id | item | Act/section | value | effective date | source URL | verified-on | status |
|---|---|---|---|---|---|---|---|
| IN-051 | minimum wage final notification, shops and establishments | Minimum Wages Act 1948; Puducherry Labour Dept [superseded 21-Nov-2025 — re-map to Code] | Values not recorded in source | 09-Sep-2024 (notification date per source) | Puducherry Labour Dept | | [UNVERIFIED] |
| IN-052 | profession tax | Puducherry Municipalities Act 1973; Village and Commune Panchayats Act 1973; 1976 Rules | Local-body levy; slabs differ between sources | Verify | Municipality / commune panchayat | | [UNVERIFIED] |
| IN-053 | labour welfare fund | Not established | One source says none applies (confidence U) | Verify | Puducherry Labour Dept | | [UNVERIFIED] |
| IN-054 | S&E Act registration exemption for OSH Code registrants | Puducherry S&E Act 1964; OSH&WC Code [superseded 21-Nov-2025 — re-map to Code] | Order exempts OSH Code registrants from S&E registration and renewal; separate notification on 24x7 operation and women in night shifts | 15-Mar-2026 (24x7 notification) | Puducherry Labour Dept | | [UNVERIFIED] |

## Wages, bonus, gratuity, contract labour, POSH
| id | item | Act/section | value | effective date | source URL | verified-on | status |
|---|---|---|---|---|---|---|---|
| IN-055 | minimum bonus | Payment of Bonus Act 1965 [superseded 21-Nov-2025 — re-map to Code] | 8.33% of annual salary (computed on at least Rs 7,000 or the minimum wage, whichever is higher) | Current | Company books / Act | | [UNVERIFIED] |
| IN-056 | maximum bonus | Payment of Bonus Act 1965 [superseded 21-Nov-2025 — re-map to Code] | 20% of annual salary | Current | Act | | [UNVERIFIED] |
| IN-057 | bonus eligibility salary threshold | Payment of Bonus Act 1965 [superseded 21-Nov-2025 — re-map to Code] | Rs 21,000/month (verify latest amendment) | Verify | Act | | [UNVERIFIED] |
| IN-058 | gratuity ceiling | Payment of Gratuity Act 1972 [superseded 21-Nov-2025 — re-map to Code] | Rs 20 lakh | Verify latest | Act | | [UNVERIFIED] |
| IN-059 | gratuity formula | Payment of Gratuity Act 1972 [superseded 21-Nov-2025 — re-map to Code] | 15/26 x last drawn wage x years; round up each completed 6 months | Current | Act | | [UNVERIFIED] |
| IN-060 | CLRA applicability | CLRA 1970 [superseded 21-Nov-2025 — re-map to Code] | 20 or more contract workers; s.21(4) is the joint-liability basis for a minimum-wage shortfall | Current | Act | | [UNVERIFIED] |
| IN-061 | POSH Internal Committee | POSH Act 2013 s.4 | Required where 10 or more employees; at least 50% women members; external member | Current | Act | | [UNVERIFIED] |
| IN-062 | POSH annual report | POSH Act 2013 s.21 | Filed with District Officer by 31 January for the prior year | Annual | Act | | [UNVERIFIED] |
| IN-063 | creche / WFH option headcount | Maternity Benefit Act 1961 (Amdt 2017) [superseded 21-Nov-2025 — re-map to Code] | 50 or more employees | Current | Act | | [UNVERIFIED] |

## Direct tax and TDS (additions)
| id | item | Act/section | value | effective date | source URL | verified-on | status |
|---|---|---|---|---|---|---|---|
| IN-064 | TDS on interest on securities | ITA 1961 s.193 / ITA 2025 equivalent | 10%; threshold Rs 5,000 (as stated in TN pack source) | Current | incometax.gov.in | | [UNVERIFIED] |
| IN-065 | TDS on interest other than securities | ITA 1961 s.194A / ITA 2025 equivalent | 10%; threshold Rs 40,000 (bank) and Rs 5,000 (others), as stated in TN pack source | Current | incometax.gov.in | | [UNVERIFIED] |
| IN-066 | TDS on commission / brokerage | ITA 1961 s.194H / ITA 2025 equivalent | 5%; threshold Rs 15,000 | Current | incometax.gov.in | | [UNVERIFIED] |
| IN-067 | TDS on rent, land and building | ITA 1961 s.194I(b) / ITA 2025 equivalent | 10%; threshold Rs 2,40,000 per year | Current | incometax.gov.in | | [UNVERIFIED] |
| IN-068 | TDS on rent, plant and machinery | ITA 1961 s.194I(a) / ITA 2025 equivalent | 2%; threshold Rs 2,40,000 per year | Current | incometax.gov.in | | [UNVERIFIED] |
| IN-069 | s.194J annual threshold | ITA 1961 s.194J | Rs 30,000 per year | Current | incometax.gov.in | | [UNVERIFIED] |
| IN-070 | TDS on purchase of goods | ITA 1961 s.194Q / ITA 2025 equivalent | 0.10%; buyer turnover above Rs 10 crore; purchases above Rs 50 lakh | Current | incometax.gov.in | | [UNVERIFIED] |
| IN-071 | TDS on non-filers (specified persons) | ITA 1961 s.206AB | 5% or twice the normal rate, whichever is higher | Current | incometax.gov.in | | [UNVERIFIED] |
| IN-072 | TDS on payments to non-residents | ITA 1961 s.195 / ITA 2025 equivalent | 20% (or the DTAA rate if lower, with tax residency certificate), as stated in MH pack source | Current | incometax.gov.in | | [UNVERIFIED] |
| IN-073 | Late TDS statement fee and penalty | ITA 1961 s.234E, s.271H | s.234E Rs 200 per day (capped at the TDS amount); s.271H Rs 10,000 to Rs 1,00,000 | Current | incometax.gov.in | | [UNVERIFIED] |
| IN-074 | Disallowance for non-deduction of TDS | ITA 1961 s.40(a)(ia) / ITA 2025 equivalent | 30% of the payment disallowed as business expense | Current | incometax.gov.in | | [UNVERIFIED] |
| IN-075 | Advance tax instalment schedule (corporate) | ITA 1961 s.208-211 | 15 Jun 15%; 15 Sep 45% cumulative; 15 Dec 75% cumulative (as stated in pack sources) | Current | incometax.gov.in | | [UNVERIFIED] |
| IN-076 | Interest on advance tax default or deferment | ITA 1961 s.234B, s.234C | 1% per month simple interest | Current | incometax.gov.in | | [UNVERIFIED] |
| IN-077 | Tax audit thresholds | ITA 1961 s.44AB / ITA 2025 equivalent | Business (non-presumptive): turnover above Rs 1 crore, or above Rs 10 crore where cash receipts and payments are within the digital limit (95% digital per MH source); profession: gross receipts above Rs 50 lakh | Current | incometax.gov.in | | [UNVERIFIED] |
| IN-078 | Individual income tax slabs, new regime | Finance Act (FY 2025-26 slabs as stated in pack source) | Nil up to Rs 4,00,000; 5% (Rs 4,00,001 to 8,00,000); 10% (to 12,00,000); 15% (to 16,00,000); 20% (to 20,00,000); 25% (to 24,00,000); 30% above (as stated in pack source, web-validate) | FY 2025-26 | incometax.gov.in | | [UNVERIFIED] |
| IN-079 | Rebate under s.87A, new regime | ITA 1961 s.87A | Rebate for taxable income up to Rs 12,00,000 (as stated in pack source; verify current notification) | FY 2025-26 | incometax.gov.in | | [UNVERIFIED] |
| IN-080 | Standard deduction from salary | ITA 1961 s.16(ia) / ITA 2025 equivalent | Rs 50,000 (as stated in pack source; later-year amounts to be verified) | FY 2025-26 | incometax.gov.in | | [UNVERIFIED] |
| IN-081 | Employer NPS contribution deduction | ITA 1961 s.80CCD(2) | Up to 10% of Basic (as stated in pack source) | Current | incometax.gov.in | | [UNVERIFIED] |
| IN-082 | HRA exemption formula | ITA 1961 s.10(13A); Rule 2A | Least of: actual HRA; 50% of Basic for Chennai metro (TN source) or 40% (MH source); rent paid less 10% of Basic | Current (old regime) | incometax.gov.in | | [UNVERIFIED] |
| IN-083 | Landlord PAN requirement for HRA exemption | ITA Rules (HRA claim documentation) | Annual rent above Rs 1,00,000: landlord PAN required | Current | incometax.gov.in | | [UNVERIFIED] |
| IN-084 | Conveyance allowance exemption (pre-April 2026) | ITA 1961 (old regime exemption) | Rs 1,600 per month; ITA 2025 equivalent to be verified | To 31-Mar-2026 | incometax.gov.in | | [UNVERIFIED] |
| IN-085 | Medical reimbursement exemption (pre-April 2026) | ITA 1961 (old regime exemption) | Rs 15,000 per year; ITA 2025 equivalent to be verified | To 31-Mar-2026 | incometax.gov.in | | [UNVERIFIED] |
| IN-086 | Tax-exempt limit on employer PF contribution | ITA 1961 Rule 6, Part A, Fourth Schedule | 12% of salary (as stated in pack source) | Current | incometax.gov.in | | [UNVERIFIED] |

## Cash, banking and reporting limits
| id | item | Act/section | value | effective date | source URL | verified-on | status |
|---|---|---|---|---|---|---|---|
| IN-087 | Cash receipt prohibition | ITA 1961 s.269ST / ITA 2025 equivalent | Rs 2 lakh from one person in a day, a single transaction or one event; penalty equal to the amount received | Current | incometax.gov.in | | [UNVERIFIED] |
| IN-088 | PAN on cash transactions | Income-tax Rules, Rule 114B | Rs 50,000 (as stated in TN pack source) | Current | incometax.gov.in | | [UNVERIFIED] |
| IN-089 | Bank reporting of cash deposits (SFT) | Income-tax Rules, Rule 114E | Rs 10 lakh in a year (as stated in TN pack source) | Current | incometax.gov.in | | [UNVERIFIED] |
| IN-090 | Cash Transaction Report by banks | PMLA Rules 2005 | Cash transactions above Rs 10 lakh in a day per account (as stated in pack sources) | Current | fiuindia.gov.in | | [UNVERIFIED] |

## GST rates, returns and thresholds
| id | item | Act/section | value | effective date | source URL | verified-on | status |
|---|---|---|---|---|---|---|---|
| IN-091 | Intra-state GST split | CGST/SGST (UTGST) Acts 2017 | CGST 9% plus SGST/MGST 9% = 18% for most services | Current | gst.gov.in | | [UNVERIFIED] |
| IN-092 | GST rate by service type (SAC table) | CGST Act 2017; rate notifications | 18% for security, housekeeping and facility management, professional, IT and software, commercial rent and training services (as stated in pack sources) | Current | gst.gov.in | | [UNVERIFIED] |
| IN-093 | Goods transport agency (GTA) rate | CGST Act 2017; SAC 9965 | 5% (no ITC) or 12% (with ITC); recipient pays under RCM unless GTA opts for forward charge | Current | gst.gov.in | | [UNVERIFIED] |
| IN-094 | Residential rent to registered lessee | CGST Act 2017; SAC 9972 | 18% under RCM (from July 2022 for registered persons) | Jul-2022 | gst.gov.in | | [UNVERIFIED] |
| IN-095 | GST rate on auto parts | CGST Act 2017; HSN 87 series | 18% or 28% by HSN (as stated in MH pack source) | Current | gst.gov.in | | [UNVERIFIED] |
| IN-096 | GST rate on scrap | CGST Act 2017 | Rate by scrap HSN as stated in the general manufacturing source (not recorded in pack text) | Verify | gst.gov.in | | [UNVERIFIED] |
| IN-097 | Notified services under reverse charge | CGST Act 2017 s.9(3) | 18% payable by the recipient: legal services by an advocate; security services by an individual or sole proprietor; sponsorship; director remuneration (per AAR rulings, verify facts) | Current | gst.gov.in | | [UNVERIFIED] |
| IN-098 | IGST on import of services | IGST Act 2017 s.5(3) | 18% under RCM; recipient pays | Current | gst.gov.in | | [UNVERIFIED] |
| IN-099 | GSTR-3B due date and filer category | CGST Rules 2017, Rule 61 | 20th of the following month for taxpayers above Rs 5 crore turnover; 22nd/24th for QRMP filers | Current | gst.gov.in | | [UNVERIFIED] |
| IN-100 | GSTR-9C reconciliation threshold and due date | CGST Act 2017 s.44 | Turnover above Rs 5 crore; due 31 December of the next financial year | Current | gst.gov.in | | [UNVERIFIED] |
| IN-101 | Late fee for GSTR-3B and GSTR-1 | CGST Act 2017 s.47 | GSTR-3B Rs 50 per day (Rs 20 for nil return); GSTR-1 Rs 50 per day | Current | gst.gov.in | | [UNVERIFIED] |
| IN-102 | Interest on late or wrongly claimed GST | CGST Act 2017 s.50 | 18% per annum | Current | gst.gov.in | | [UNVERIFIED] |
| IN-103 | e-Invoice (IRN) turnover threshold | CGST Rules 2017, Rule 48(4) | Aggregate turnover above Rs 5 crore in any year since FY 2021-22 | Aug-2023 (per TN source) | gst.gov.in | | [UNVERIFIED] |
| IN-104 | Penalty for no e-invoice | CGST Act 2017 s.122 | Rs 10,000 per invoice; ITC denied to the buyer | Current | gst.gov.in | | [UNVERIFIED] |
| IN-105 | e-Way bill value threshold | CGST Rules 2017, Rule 138 | Goods consignment above Rs 50,000 | Current | gst.gov.in | | [UNVERIFIED] |
| IN-106 | Penalty for movement without e-way bill | CGST Act 2017 s.129 | 200% of tax (as stated in MH pack source); vehicle detention | Current | gst.gov.in | | [UNVERIFIED] |

## Company law and MCA
| id | item | Act/section | value | effective date | source URL | verified-on | status |
|---|---|---|---|---|---|---|---|
| IN-107 | ROC jurisdiction realignment effective date | MCA S.O. 4850(E) of 23-Oct-2025; notification of 30-Dec-2025 | Effective 16-Feb-2026 after postponement from 1-Jan-2026 (as stated in MH pack source) | 16-Feb-2026 | mca.gov.in | | [UNVERIFIED] |
| IN-108 | LLP statutory audit thresholds | LLP Act 2008 s.34 | Turnover above Rs 40 lakh or contribution above Rs 25 lakh | Current | mca.gov.in | | [UNVERIFIED] |
| IN-109 | AOC-4 late filing fee | Companies Act 2013 s.137 | Rs 1,000 per day of delay (as stated in TN and MH pack sources) | Current | mca.gov.in | | [UNVERIFIED] |
| IN-110 | MGT-7 annual return late filing | Companies Act 2013 s.92, s.403 | Rs 50,000 penalty plus Rs 100 per day (as stated in pack sources) | Current | mca.gov.in | | [UNVERIFIED] |
| IN-111 | ADT-1 auditor appointment default fine | Companies Act 2013 s.139, s.140 | Fine Rs 25,000 to Rs 5 lakh | Current | mca.gov.in | | [UNVERIFIED] |
| IN-112 | MSME Form I filing, dues over 45 days | MSMED Act 2006 s.15; MCA order | Half-yearly filing (31 Oct and 30 Apr) for MSME dues outstanding beyond 45 days; fine Rs 25,000 | Current | mca.gov.in | | [UNVERIFIED] |
| IN-113 | CSR-2 filing default fine | Companies Act 2013 s.135; CSR Rules | Fine Rs 50,000 to Rs 25 lakh | Current | mca.gov.in | | [UNVERIFIED] |
| IN-114 | CSR applicability and spend | Companies Act 2013 s.135 | Net worth Rs 500 crore or turnover Rs 1,000 crore or net profit Rs 5 crore; spend 2% of average net profit | Current | mca.gov.in | | [UNVERIFIED] |
| IN-115 | Audit Committee mandatory thresholds | Companies Act 2013 s.177; Rule 6 Companies (Meetings of Board) Rules | Paid-up capital Rs 10 crore or turnover Rs 100 crore or outstanding borrowings, debentures and deposits above Rs 50 crore | Current | mca.gov.in | | [UNVERIFIED] |
| IN-116 | Related-party transaction thresholds | Companies Act 2013 s.188; Rule 15 | Sale or purchase of goods, property or services, and leasing: 10% of turnover or net worth, or Rs 100 crore (Rs 50 crore for services), per pack source | Current | mca.gov.in | | [UNVERIFIED] |
| IN-117 | Related-party office or place of profit | Companies Act 2013 s.188; Rule 15 | Monthly remuneration above Rs 2.5 lakh | Current | mca.gov.in | | [UNVERIFIED] |
| IN-118 | Managerial remuneration ceiling | Companies Act 2013 s.197 | 11% of net profit | Current | mca.gov.in | | [UNVERIFIED] |
| IN-119 | MSME classification | MSMED Act 2006 s.7, as amended | Micro: investment up to Rs 1 crore and turnover up to Rs 5 crore; Small: Rs 10 crore and Rs 50 crore; Medium: Rs 50 crore and Rs 250 crore | Current | udyamregistration.gov.in | | [UNVERIFIED] |

## Social security (additions)
| id | item | Act/section | value | effective date | source URL | verified-on | status |
|---|---|---|---|---|---|---|---|
| IN-120 | Employer EPF contribution split | EPF Scheme 1952 Para 29 | 12% of Basic + DA: 8.33% to EPS and 3.67% to EPF | Current | epfindia.gov.in | | [UNVERIFIED] |
| IN-121 | Total employer EPF cost | EPF Scheme 1952 and EDLI Scheme | About 13% plus 1% (as stated in pack sources) | Current | epfindia.gov.in | | [UNVERIFIED] |
| IN-122 | Minimum EPFO administrative charge | EPF Scheme 1952 | Rs 75 per month per establishment | Current | epfindia.gov.in | | [UNVERIFIED] |
| IN-123 | Interest on delayed EPF payment | EPF & MP Act 1952 s.7Q | 12% per annum | Current | epfindia.gov.in | | [UNVERIFIED] |
| IN-124 | Total ESIC contribution | ESI Act 1948 | 4% of gross wages (3.25% employer plus 0.75% employee) | 01-Jul-2019 | esic.gov.in | | [UNVERIFIED] |
| IN-125 | Interest on delayed ESIC contribution | ESI Act 1948 s.85B | 12% per annum | Current | esic.gov.in | | [UNVERIFIED] |

## Wages, bonus, penalties and state rows (additions)
| id | item | Act/section | value | effective date | source URL | verified-on | status |
|---|---|---|---|---|---|---|---|
| IN-126 | Bonus allocable surplus share | Payment of Bonus Act 1965 s.2(4) | 67% of available surplus (companies); 60% (banking), per pack sources | Current | Act | | [UNVERIFIED] |
| IN-127 | Penalty for bonus default | Payment of Bonus Act 1965 s.28 | Fine Rs 1,000 plus imprisonment up to 6 months | Current | Act | | [UNVERIFIED] |
| IN-128 | Interest on delayed gratuity | Payment of Gratuity Act 1972 s.7(3A) | 10% per annum beyond 30 days | Current | Act | | [UNVERIFIED] |
| IN-129 | Payment of Wages Act wage ceiling | Payment of Wages Act 1936 | Monthly wage period for employees earning below Rs 24,000 per month | Current | Act | | [UNVERIFIED] |
| IN-130 | Penalty for non-payment of minimum wages | Minimum Wages Act 1948 | Fine up to Rs 500; repeat offence Rs 1,000 plus imprisonment (as stated in TN pack source) | Current | Act | | [UNVERIFIED] |
| IN-131 | Penalty for CLRA non-compliance | CLRA 1970 s.23-25 | Fine Rs 1,000; repeat offence plus imprisonment (as stated in pack sources) | Current | Act | | [UNVERIFIED] |
| IN-132 | BOCW cess on construction cost | BOCW Cess Act 1996 | Rate not recorded in pack text (pack states cess is payable on construction cost); validator to fill | Current | Act | | [UNVERIFIED] |
| IN-133 | Maternity medical bonus | Maternity Benefit Act 1961 s.8 | Rs 3,500 if no pre-natal or post-natal care is provided by the employer | Current | Act | | [UNVERIFIED] |
| IN-134 | POSH non-compliance fine | POSH Act 2013 s.26 | Fine up to Rs 50,000; doubled for repeat; licence cancellation possible | Current | Act | | [UNVERIFIED] |
| IN-135 | Environment penalties | Environment (Protection) Act 1986; Air and Water Acts (consent to operate) | Hazardous waste violation: fine up to Rs 1 lakh plus up to 5 years imprisonment; expired consent: closure order, prosecution and fine (as stated in pack sources) | Current | mpcb.gov.in / tnpcb.gov.in | | [UNVERIFIED] |
| IN-136 | TN professional tax slabs per half-year (Chennai) | TN Professional Tax Act 1992 | Nil up to Rs 21,000 monthly salary; intermediate half-yearly slabs per TN pack source; Rs 1,250 per half-year above Rs 75,000 (revised Apr-2024) | Apr-2024 | TN Commercial Taxes portal | | [UNVERIFIED] |
| IN-137 | TN employer professional tax | TN Professional Tax Act 1992 | Rs 2,500 per year flat, paid half-yearly (Sep and Mar) | Current | TN Commercial Taxes portal | | [UNVERIFIED] |
| IN-138 | TN LWF salary ceiling | TN Labour Welfare Fund Act 1972 | Employees earning above Rs 3,500 per month excluded (verify latest notification) | Verify | TN LWF Board | | [UNVERIFIED] |
| IN-139 | TN LWF default fine | TN Labour Welfare Fund Act 1972 s.15 | Fine up to Rs 1,000 per default | Current | TN LWF Board | | [UNVERIFIED] |
| IN-140 | MH professional tax monthly slabs (male) | MH PT Act 1975 | Nil up to Rs 7,500; Rs 175 per month for Rs 7,501 to Rs 10,000; Rs 200 per month above Rs 10,000 (FY 2024-25 as stated in pack sources, web-validate) | FY 2024-25 | mahagst.gov.in | | [UNVERIFIED] |
| IN-141 | MH professional tax February instalment | MH PT Act 1975 | Rs 300 in February instead of Rs 200, for employees earning above Rs 10,000 | Current | mahagst.gov.in | | [UNVERIFIED] |
| IN-142 | MH PT monthly return threshold | MH PT Act 1975 | Monthly PTRC return (Form III-B) where annual PT exceeds Rs 1 lakh | Current | mahagst.gov.in | | [UNVERIFIED] |
| IN-143 | MH PT late payment and non-registration | MH PT Act 1975 | Late payment: 10% of tax plus 1.25% per month interest; late filing Rs 1,000 per month; non-registration Rs 5 per day (as stated in pack sources) | Current | mahagst.gov.in | | [UNVERIFIED] |
| IN-144 | MH LWF superseded rates (before Mar-2024) | MH Labour Welfare Fund Act 1953 | Employee Rs 12; employer Rs 36 per half-year (old rates; do not use) | Before Mar-2024 | mlwb.in | | [UNVERIFIED] |
| IN-145 | MH LWF salary ceiling | MH Labour Welfare Fund Act 1953 | Employees earning above Rs 3,500 per month covered (verify latest threshold) | Verify | mlwb.in | | [UNVERIFIED] |
| IN-146 | MH S&E Act non-registration fine | MH S&E Act 2017 (Amdt Oct 2025) | Fine Rs 2,000 to Rs 1,00,000 (post-Oct 2025 amendment, as stated in MH pack source) | Oct-2025 | MH Labour Dept | | [UNVERIFIED] |

## Conflicts to resolve
| id | topic | values in source skills | action for validator |
|---|---|---|---|
| IN-C9 | EPF/EPS wage ceiling (RESOLVED: Rs 25,000 from 17-Sep-2026; Rs 15,000 is stale for later periods) | Rs 15,000 'Current' (TN and MH packs) versus Rs 25,000 from 17-Sep-2026 (Puducherry pack) | Confirm against the Gazette notification and EPFO circular; state which pay periods straddle the change |
| IN-C10 | Labour Codes status | In force 21-Nov-2025 (TN, MH, Puducherry packs) versus 'enacted but not yet implemented in TN' (retired chennai-hr-audit) | Confirm commencement notifications and which old Acts survive; retired HR source text is superseded |
| IN-C11 | ITA 1961 versus ITA 2025 section mapping | TN source cites s.194C and s.393; validator trap list cites s.392(1) for salary TDS from TY 2026-27 | Confirm section numbers in the new Act and the commencement date |
| IN-C12 | GST manpower notification date | 22-Sep-2025 (TN) versus 'Sep 2025' (MH) | Confirm notification number and effective date |
| IN-C13 | Bonus eligibility threshold | Rs 21,000 flagged 'verify' in both packs | Confirm current amendment status |
| IN-C14 | TN professional tax maximum | Row IN-038 states Rs 2,500 per half-year; the TN pack text states Rs 1,250 per half-year, Rs 2,500 per year | Confirm against the TN Commercial Taxes notification and correct IN-038 or the pack text |
| IN-C15 | MH PT exemption for female employees | Row IN-045 states nil up to Rs 25,000 per month; the professional-tax HR reference states nil up to Rs 10,000 (slab table pays female employees above Rs 10,000) | Confirm against the MH PT Act schedule and mahagst.gov.in |
| IN-C16 | EPF s.14B damages | Row IN-007 states 1% per month simple (validator trap list); the TN and MH pack text states damages up to 25% of arrears for wilful default | Confirm against the EPFO damages table and correct the row or the pack text |

## Open dependencies
- Entity-to-state mapping for each MKTron India site (MKAPL Stamping, Die Casting, Jacks, BCP, Gencor, Sekhar India) is not supplied in the source skills; the pack must not assume one. Supply the factory licence state per site.
- No state packs exist for states other than Tamil Nadu, Maharashtra and Puducherry; a site in another state is an open scope dependency.
- State minimum wage values change every Jan/Apr/Jul/Oct cycle; obtain the notification in force for the audit period rather than relying on this register date.
- Payment-approval (delegation of authority) tiers, petty-cash float, gift-policy limits, fraud risk-model weights and threshold-clustering bands appear in the pack text as `[entity DoA tier]`, `[entity policy]`, `[per entity gift policy]` and `[set in engagement risk model]`. They are entity or engagement parameters, not statutory values; obtain them from the client policy set or the engagement plan and carry them as open dependencies.
