> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- Maharashtra Minimum Wages (Pune — Zone I / Group A)
- Maharashtra Professional Tax (PTRC / PTEC)
- Maharashtra Labour Welfare Fund (MLWF)
- Payment of Bonus Act 1965 (Maharashtra) [superseded 21-Nov-2025 — re-map to Code]
- Payment of Gratuity Act 1972 (Maharashtra) [superseded 21-Nov-2025 — re-map to Code]
- Audit Procedures — Wages & Welfare (Maharashtra)
- Red Flags — Wages & Welfare (Maharashtra)


# R06 — Wages, Welfare & Statutory Benefits: Maharashtra / Pune

## Maharashtra Minimum Wages (Pune — Zone I / Group A)

### Zone Classification — Pune
| Zone | Definition | Pune Classification |
|------|-----------|---------------------|
| Zone I (Group A) | Municipal Corporation limits + Cantonment areas + Industrial areas within 20 km of Municipal Corporation | **Pune falls here — PMR (Pune Metropolitan Region)** |
| Zone II (Group B) | Areas under 'A' and 'B' class Municipal Councils | Outside PMC limits |
| Zone III (Group C) | All other areas not in Zone I or II | Rural Maharashtra |

> **Critical for Pune:** Pune city + PCMC (Pimpri-Chinchwad Municipal Corporation) + MIDC areas within 20 km of PMC = **Zone I**. This is the highest wage zone in Maharashtra.

### MH Minimum Wages — Bi-Annual Revision Cycle
- **January 1 revision:** Based on previous year's CPI average (VDA update)
- **July 1 revision:** Mid-year CPI update
- Current January 2026 rates apply until June 30, 2026
- Next revision: July 1, 2026 — verify MH Labour Dept gazette (mahakamgar.gov.in)

### MH Min Wages — Shops & Commercial Establishments (Zone I, Jan 2026)
| Category | Basic (₹/mo) | VDA (₹/mo) | Total (₹/mo) | ₹/day (26 days) |
|----------|-------------|-----------|-------------|----------------|
| Unskilled | ~10,021 | ~3,614 | ~13,635 | ~524 |
| Semi-skilled | ~10,856 | ~3,614 | ~14,470 | ~557 |
| Skilled | ~11,632 | ~3,614 | ~15,246 | ~587 |
| Highly Skilled | — | — | ~16,592+ | ~639+ |

> **Mandatory:** Always download the official MH Labour Dept notification from mahakamgar.gov.in for the exact current rates. Rates above are indicative; the official gazette governs.

### Additional HRA Requirement (MH Shops — ≥50 Workers)
If establishment employs >50 workers:
- **Additional [IN-043] HRA** calculated on (Basic Pay + Special Allowance) — mandatory
- This is ON TOP of any HRA already paid under employment contract
- Failure to pay = Minimum Wages Act violation [superseded 21-Nov-2025 — re-map to Code]

### Min Wages Audit Procedure
1. Download applicable MH Minimum Wages notification from mahakamgar.gov.in for the exact period under review
2. Identify skill category and zone for each worker/group
3. Compute implied per-worker wage from vendor bills or payroll
4. Compare to gazette rate — any shortfall = violation
5. For establishments >50 workers: Verify additional [IN-043] HRA component is included

---

## Maharashtra Professional Tax (PTRC / PTEC)

**Statute:** The Maharashtra State Tax on Professions, Trades, Callings and Employments Act 1975
**Authority:** Maharashtra GST Department (mahagst.gov.in)

### PT Slabs (Current — FY 2025-26 and FY 2026-27)

**Male Employees:**
| Monthly Gross Salary | Annual PT | Monthly Deduction |
|---------------------|-----------|------------------|
| ≤[IN-140] | Nil | Nil |
| [IN-140] – [IN-140] | [IN-140] | ~[IN-140]-15/mo |
| [IN-140] – [IN-140] | [IN-140] | [IN-140] × 11 + [IN-141] in Feb |
| [IN-140] – [IN-140] | [IN-140] | [IN-140] × 11 + [IN-141] in Feb |
| [IN-140] – [IN-140] | [IN-140] | [IN-140] × 11 + [IN-141] in Feb |
| Above [IN-140] | [IN-140] | [IN-140] × 11 + [IN-141] in Feb |

**Female Employees:**
| Monthly Gross Salary | Annual PT |
|---------------------|-----------|
| ≤[IN-045] | **Nil** (complete exemption — Maharashtra-specific) |
| >[IN-045] | Same slab as males ([IN-044] p.a. max) |

> **Maharashtra is unique in having gender-specific PT slabs.** Most payroll systems in Pune must be configured to respect this.

### PTRC — Employer Obligations
| Obligation | Details | Due Date |
|-----------|---------|---------|
| PTRC Registration | Mandatory for all employers in MH | Before first salary payment |
| Monthly PT return (PTRC Form III-B) | Required if annual PT >[IN-142] | By last day of following month |
| Annual PT return (Form IIIy) | For all others | Annual |
| PTEC | PT on company/entity itself | [IN-046] p.a. by June 30 |
| Late payment penalty | [IN-143] of tax due | — |
| Interest | [IN-143] per month | — |
| Fine for non-registration | [IN-143]/day | mahagst.gov.in |

---

## Maharashtra Labour Welfare Fund (MLWF)

**Statute:** Maharashtra Labour Welfare Fund Act 1953
**Authority:** Maharashtra Labour Welfare Board (mlwb.in)
**Current Rates (Revised March 2024):**

| Component | Rate | Frequency | Old Rate (pre-Mar 2024) |
|-----------|------|-----------|------------------------|
| Employee contribution | **[IN-047] per half-year** | June 30 + Dec 31 | [IN-144] (OLD — do not use) |
| Employer contribution | **[IN-048] per half-year** | June 30 + Dec 31 | [IN-144] (OLD — do not use) |
| Total per employee per year | [IN-047, IN-048] | — | [IN-144] (OLD) |

> **CRITICAL:** Many Pune payroll teams still use old rates [IN-144]/[IN-144]. The revised rates ([IN-047]/[IN-048]) are effective from March 2024. Using old rates = underpayment + penalty risk.

### MLWF Compliance Requirements
| Requirement | Detail |
|-------------|--------|
| Applicability | ≥5 employees in Maharashtra |
| Deduction frequency | Only June and December (half-yearly) — NOT monthly |
| Remittance | By June 30 (for Apr-Sep) and December 31 (for Oct-Mar) |
| Annual return | Form A — by 15 February (verify MLWB portal) |
| Penalty | Late payment: MLWF Act Sec 10 — recoverable + fine |
| Exemption | Employees earning >[IN-145]/mo are covered; verify latest threshold |

> **Common error in Pune:** LWF deducted every month from employee salary (over-deduction). MH LWF is HALF-YEARLY only.

---

## Payment of Bonus Act 1965 (Maharashtra)

### Eligibility
- Employees with salary ≤[IN-057]/month
- Completed 30 working days in the accounting year
- Applicable: Factories + establishments ≥20 employees

### Calculation
| Component | Details |
|-----------|---------|
| Minimum bonus | [IN-055] of annual earnings or [IN-055] whichever higher |
| Maximum bonus | [IN-056] of annual earnings |
| Computation salary ceiling | [IN-055]/month or applicable MH minimum wage (Zone I, relevant category), whichever HIGHER |
| Allocable surplus | [IN-126] of available surplus (companies) |
| Set-on / Set-off | Carried over up to 4 years |

> **Maharashtra Minimum Wage ceiling rule:** If applicable MH min wage (Zone I) for the category is >[IN-055]/month, the higher MH min wage is used as the computation ceiling. For Pune Zone I, minimum wages already exceed [IN-055] — so MH min wage governs.

### Bonus Filing Deadlines
| Form | Purpose | Due Date |
|------|---------|---------|
| Form A | Allocable surplus computation | Within 8 months of FY end (by Nov 30 for March FY) |
| Form B | Set-on / set-off | Annual — same as Form A |
| Form C | Bonus paid | Annual |
| Form D | Annual return | Nov 30 |

---

## Payment of Gratuity Act 1972 (Maharashtra)

### Eligibility
- Minimum 5 years continuous service (4 years + 240 days accepted by courts for 5th year)
- Payable on: Superannuation, resignation, retirement, death, disablement

### Formula
```
Gratuity = (Last drawn salary × 15) / 26 × Number of completed years of service
```
- "Last drawn salary" = Basic + DA (only)
- Each period ≥6 months = rounded up to 1 year
- **Ceiling: [IN-058]** (verify latest amendment — may have been revised)

### Gratuity — Maharashtra Context
- SEBI-regulated listed Pune companies: Ind AS 19 actuarial valuation mandatory
- LIC Group Gratuity Scheme: Common for Pune mid-size companies
- Approved Gratuity Trust: Larger Pune corporates — must follow IRDA investment norms

### Payment Timeline
- Employer must pay within 30 days of becoming payable
- Interest @ [IN-128] p.a. beyond 30 days (unless delay due to employee)

---

## Audit Procedures — Wages & Welfare (Maharashtra)

1. **MH Min Wages:** Per-worker implied wage from vendor bills / payroll → compare to MH Zone I notification (mahakamgar.gov.in) for applicable industry + skill + period. Shortfall = violation.
2. **Additional HRA:** If >50 workers, verify [IN-043] HRA component on top of contractual HRA
3. **PT:** Recompute expected PT per MH slab — apply gender-specific rule (females ≤[IN-045] = nil); verify PTRC remittance on mahagst.gov.in; verify February deduction = [IN-141] for applicable male employees
4. **LWF:** Verify [IN-047] deducted from eligible employees in June and December only (not monthly); [IN-048] employer contribution remitted by June 30 and Dec 31; verify NEW rates ([IN-047]/[IN-048]) used, not old rates ([IN-144]/[IN-144])
5. **Bonus:** Verify allocable surplus computation (P&L); MH min wage ceiling applied for computation; minimum [IN-055] paid by Nov 30; Forms A/B/C/D filed; employees ≤[IN-057] included
6. **Gratuity:** 100% FnF exits with ≥5 years — compute per formula; verify payment within 30 days; Ind AS 19 provision reviewed

---

## Red Flags — Wages & Welfare (Maharashtra)

- Per-worker wage below MH Zone I minimum wage notification rate
- Establishment with >50 workers not paying additional [IN-043] HRA
- Female employees earning >[IN-045] with nil PT (should be paying same as males)
- Male employees earning [IN-045]–[IN-140] with nil PT (slab shows [IN-140] p.a. due)
- LWF deducted monthly (violation — must be half-yearly June and December only)
- LWF at old rates [IN-144]/[IN-144] instead of revised [IN-047]/[IN-048] (revised March 2024)
- PTRC not remitted to mahagst.gov.in despite deduction from employees
- Bonus computation ceiling using [IN-055]/mo flat instead of higher MH min wage
- Gratuity not paid or paid after 30-day limit (interest liability)
- FnF settlement not including leave encashment (MH S&E Act — up to 42 days carry-forward)
