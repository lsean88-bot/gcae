> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- Entity Types & Key Compliance Matrix
- Key Annual Compliance — Private Limited Company
- Internal Financial Controls (IFC) — Companies Act 2013 Sec 143(3)(i)
- Audit Committee Requirements (if applicable)
- Related Party Transactions (RPT) — Sec 188 & SEBI LODR
- MSME Payment Compliance (Sec 15 MSMED Act 2006)
- Statutory Registers (Physical / Digital)
- Company Law Audit Procedures
- Red Flags — Company Law


# R07 — Companies Act 2013 & Corporate Governance

## Entity Types & Key Compliance Matrix

| Entity Type | Governing Law | ROC Filing | Audit Requirement |
|-------------|--------------|-----------|------------------|
| Private Limited | Companies Act 2013 | MCA21 — ROC Chennai (TN & Puducherry) | Statutory audit — all companies |
| Public Limited | Companies Act 2013 | MCA21 | Statutory + SEBI (if listed) |
| OPC (One Person Company) | Companies Act 2013 | MCA21 | Statutory audit |
| LLP | LLP Act 2008 | MCA21 | Statutory audit if turnover >[IN-108] or contribution >[IN-108] |
| Section 8 (NGO/Foundation) | Companies Act 2013 | MCA21 | Statutory audit |
| Partnership Firm | Indian Partnership Act 1932 | Income Tax filing | Tax audit if turnover threshold met |
| Proprietorship | No separate registration | Income Tax / GST | Tax audit if turnover threshold met |

**ROC jurisdiction for Chennai:** Registrar of Companies, Tamil Nadu — ROC Chennai (also covers Puducherry).

---

## Key Annual Compliance — Private Limited Company

| Compliance | Form | Portal | Due Date | Penalty |
|-----------|------|--------|---------|---------|
| Annual Return | MGT-7 / MGT-7A (small company) | MCA21 | 60 days from AGM (AGM must be by Sep 30) | [IN-110] + [IN-110]/day delay |
| Financial Statements | AOC-4 / AOC-4 CFS | MCA21 | 30 days from AGM | [IN-109]/day delay |
| Auditor Appointment | ADT-1 (new) or ratification | MCA21 | 15 days from AGM | Fine [IN-111]–[IN-111] |
| Director KYC | DIR-3 KYC | MCA21 | Sep 30 of each year | DIN deactivation |
| Board Meetings | Minutes + Attendance | Company records | Min 4/year (≤120 days between) | Fine on every officer |
| AGM | Notice + Minutes | Company records | Within 6 months of FY end (by Sep 30) | Penalty on officers |
| Charge Registration | CHG-1 (creation) | MCA21 | Within 30 days of charge | Condonation required; additional fees |
| MSME payment disclosure | MSME Form I | MCA21 | Half-yearly (Oct 31 and Apr 30) | Fine [IN-112] |
| CSR Report (if applicable) | CSR-2 | MCA21 | With AOC-4 | Fine [IN-113]–[IN-113] |
| Beneficial Ownership (SBO) | BEN-2 | MCA21 | Within 90 days of triggering | Penalty |

---

## Internal Financial Controls (IFC) — Companies Act 2013 Sec 143(3)(i)

**Applicable to:** All companies (reporting on IFC mandatory for auditors of all companies; management responsibility to design and maintain IFC).

### IFC Framework Requirements
- Board (Directors' Responsibility Statement) must confirm: adequate IFC in place and operating effectively
- Statutory auditor must report on IFC adequacy and operating effectiveness
- Internal auditor: IFC testing and reporting to Audit Committee

### Key IFC Domains to Test
1. Revenue recognition controls
2. Procure-to-pay process (authorization, segregation, three-way match)
3. Payroll process (authorization, HRMS integrity, bank transfer controls)
4. Financial close process (journal entry controls, period-end cut-off)
5. Treasury controls (bank authorization matrix, investment approvals)
6. IT general controls (access management, change management, backup)

---

## Audit Committee Requirements (if applicable)

**Mandatory for:** Companies with paid-up capital ≥[IN-115] OR turnover ≥[IN-115] OR aggregate outstanding loans/borrowings/debentures/deposits ≥[IN-115].

| Requirement | Detail |
|-------------|--------|
| Composition | Minimum 3 directors; majority independent; chairperson = independent director |
| Terms of Reference | As per Sec 177(4) — oversight of financial reporting, audit, IFC, related party transactions |
| Meetings | Min 4 per year |
| Whistleblower mechanism | Mandatory for listed + companies with public deposits + Audit Committee companies |
| Internal auditor reports to | Audit Committee |

---

## Related Party Transactions (RPT) — Sec 188 & SEBI LODR

| Transaction type | Threshold requiring ordinary resolution | Threshold requiring special resolution |
|-----------------|---------------------------------------|--------------------------------------|
| Sale/purchase of goods | [IN-116] of turnover or [IN-116] | None specified (ordinary sufficient) |
| Sale/purchase of property | [IN-116] of net worth or [IN-116] | — |
| Leasing of property | [IN-116] of net worth or [IN-116] | — |
| Availing/rendering services | [IN-116] of turnover or [IN-116] | — |
| Appointment of related party to an office of profit | [IN-117] p.m. | — |

**Arm's length test:** All RPTs must be on arm's length terms; any transaction not at arm's length must go through special resolution regardless of value.

**Register of contracts:** Statutory register to be maintained (Form MBP-4).

---

## MSME Payment Compliance (Sec 15 MSMED Act 2006)

**Critical for Chennai businesses — most vendor contracts involve MSMEs:**
- Payment to MSME suppliers: Within 45 days of acceptance / agreed terms (maximum 45 days if agreed in writing)
- Overdue interest: 3× Bank Rate (compound, monthly) on delayed payments to MSMEs
- **MSME Form I:** Half-yearly disclosure of outstanding MSME dues > 45 days — due October 31 and April 30

**Audit risk:** If MSME Form I not filed → ROC penalty; if dues outstanding beyond 45 days → interest liability; MSME facilitation council complaint risk.

---

## Statutory Registers (Physical / Digital)

| Register | Sec | Content |
|---------|-----|---------|
| Register of Members | Sec 88 | Shareholder names, address, shares held |
| Register of Directors & KMPs | Sec 170 | Director details, DIN, appointments |
| Register of Charges | Sec 85 | All mortgages, pledges, charges |
| Register of Contracts (RPT) | Sec 189 | All related party transactions |
| Minutes Book — Board | Sec 118 | All board and committee resolutions |
| Minutes Book — General Meeting | Sec 118 | All AGM/EGM resolutions |
| Register of Loans & Investments | Sec 186 | All inter-company loans/investments/guarantees |

---

## Company Law Audit Procedures

1. Verify CIN on MCA21 — confirm active status, no pending disqualification
2. Confirm AOC-4 and MGT-7/7A filed within due dates — check for SRN on MCA21
3. Test all 4 Board meetings held — verify quorum, proper resolutions, signature
4. Verify Director KYC (DIR-3) filed by Sep 30 — DIN deactivation = company governance risk
5. Verify Auditor appointment/reappointment in ADT-1 — within 15 days of AGM
6. Test RPT transactions against Board/Shareholder approvals — Form MBP-4 register maintained
7. Verify MSME Form I filed (Oct 31 and Apr 30) — cross-check with outstanding AP register for MSME vendors
8. If IFC applicable: Review internal audit reports and AC minutes — were material weaknesses reported?
9. Verify CSR compliance (if net profit ≥[IN-114] or turnover ≥[IN-114] or net worth ≥[IN-114]) — [IN-114] net profit spend; CSR-2 filed

---

## Red Flags — Company Law

- Annual returns or financial statements filed late or not filed (MCA21 status = struck off risk)
- Director KYC not completed — DIN deactivated directors cannot sign documents validly
- Board meeting quorum not met (minutes may be invalid)
- Related party transactions not disclosed or approved — Sec 188 violation + potential Sec 447 (fraud)
- MSME dues outstanding >45 days without MSME Form I disclosure
- Charges not filed within 30 days — unregistered charge unenforceable in insolvency
- Statutory registers not maintained / not available for inspection
- Auditor not reappointed for consecutive term without reason (ADT-3 not filed on resignation)
- Shell company features: No real office, no employees, no transactions except inter-company → heightened fraud scrutiny
