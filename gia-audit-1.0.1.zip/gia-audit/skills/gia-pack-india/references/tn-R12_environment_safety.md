> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- Tamil Nadu Pollution Control Board (TNPCB)
- Fire Safety — Chennai
- Factories Act 1948 — Safety & Health (TN) [superseded 21-Nov-2025 — re-map to Code]
- MSME (Micro, Small & Medium Enterprises) Registration
- Legal Metrology (TN)
- Chennai Local Body / CMDA Regulations
- Environment & Safety Audit Procedures
- Red Flags — Environment & Safety


# R12 — Environment, Safety & Local Regulations (Chennai/TN)

## Tamil Nadu Pollution Control Board (TNPCB)

### Applicability
All industrial and commercial establishments — based on pollution potential (Red/Orange/Green/White category).

| Category | Pollution Potential | Examples | Consent Frequency |
|----------|-------------------|---------|-----------------|
| Red | High | Electroplating, tanneries, chemicals, foundries | Consent to Operate (CTO) — 5 years |
| Orange | Moderate | Light engineering, food processing, printing | CTO — 5 years |
| Green | Low | Handloom, paper product, leather goods (not processing) | CTO — 10 years |
| White | Negligible / Zero | IT/software, educational institutions, clinics | Exempted from consent |

### Key Consents Required
1. **Consent to Establish (CTE):** Before setting up plant/factory
2. **Consent to Operate (CTO):** Before commencing operations; renewal before expiry
3. **Hazardous Waste Authorization:** If generating hazardous waste (Batteries, E-waste, paint waste, solvents, etc.)

### Scheduled Waste / Hazardous Waste (Chennai context)
- Governed by: Hazardous and Other Wastes (Management and Transboundary Movement) Rules 2016
- E-Waste: E-Waste (Management) Rules 2022 — manufacturers/dealers must register with CPCB
- Battery Waste: Battery Waste Management Rules 2022
- Disposal: Only through TNPCB-authorized recyclers; maintain Form 3 manifest

---

## Fire Safety — Chennai

| Requirement | Authority | Applicability |
|-------------|-----------|--------------|
| Fire NOC | Tamil Nadu Fire and Rescue Services | Buildings >15m height; industrial buildings; assembly occupancy; educational; healthcare |
| Annual renewal | TNFRS | Annual — before expiry |
| Fire Safety Audit | TNFRS / certified auditor | Buildings ≥3 floors or occupancy >50 persons |
| Mock drill | TN Factories Act Rule 68-J | Factories — minimum annually | [superseded 21-Nov-2025 — re-map to Code]
| Fire extinguisher certification | Factory Inspector / certified agency | Annually |

**Key compliance:** Fire NOC must be obtained before commencement. Expired NOC = insurance claim risk + regulatory action.

---

## Factories Act 1948 — Safety & Health (TN)

| Provision | Requirement |
|-----------|------------|
| Annual licence (Form 2) | Renewed before expiry; displayed at factory |
| Occupier & Manager notification | Form 7A — within 7 days of appointment |
| Accident reporting | Fatal: Immediately; Major: Form 18 within 24 hours |
| Dangerous occurrence | Immediately — DIC (Department of Industries and Commerce) + Inspector |
| Medical examination | Scheduled occupational diseases → Form 21A |
| Safety committee | Factories with ≥250 workers — mandatory; meets quarterly |
| Works committee | Factories with ≥100 workers (Industrial Disputes Act) | [superseded 21-Nov-2025 — re-map to Code]

---

## MSME (Micro, Small & Medium Enterprises) Registration

### Udyam Registration (post-July 2020)
- Replaced Udyog Aadhaar — all old registrations migrated or to be registered on udyamregistration.gov.in
- Based on: Investment in plant & machinery + Annual turnover (latest amendment effective Jan 2022)

| Category | Investment (P&M) | Turnover |
|----------|-----------------|---------|
| Micro | ≤[IN-119] | ≤[IN-119] |
| Small | ≤[IN-119] | ≤[IN-119] |
| Medium | ≤[IN-119] | ≤[IN-119] |

**Benefits:** Easier bank credit; payment protection (45-day MSMED Act); priority sector lending; various TN state incentives.

---

## Legal Metrology (TN)

- Legal Metrology Act 2009: All traders/manufacturers using weights and measures must be registered
- Inspector of Legal Metrology (Chennai — District): Annual verification of weighing scales, measuring instruments
- Packaged Commodities Rules: Mandatory declaration on all pre-packaged goods

---

## Chennai Local Body / CMDA Regulations

| Requirement | Authority |
|-------------|-----------|
| Trade licence | Greater Chennai Corporation (GCC) — Annual renewal |
| Building plan approval | CMDA (Chennai Metropolitan Development Authority) — before construction |
| Completion certificate | CMDA — before occupancy |
| Signage / advertisement | GCC — annual licence fee |
| Food safety (if applicable) | FSSAI — annual licence/registration; TN Food Safety Dept |

**Trade licence (GCC):** Must be displayed at premises. Failure to renew = GCC sealing notice.

---

## Environment & Safety Audit Procedures

1. Verify TNPCB CTO validity — expiry date; confirm correct category for current activity
2. Verify Fire NOC validity — expiry date and authority issuing
3. Verify GCC Trade licence — annual renewal done
4. Hazardous waste: Obtain Form 3 manifests — verify disposal through TNPCB-authorized vendor only
5. E-waste / battery waste: CPCB registration status; authorized recycler certificates
6. Factory licence (Form 2): Verify validity; verify occupier/manager notifications are current
7. Accident register: Review Form 20 for last 3 years — any near-misses or reportable incidents unreported
8. Mock drill records: At least annual; attendance signed
9. Safety committee minutes: Verify quarterly meetings held (factories ≥250 workers)
10. MSME registration: Verify udyamregistration.gov.in — current status for any vendors claiming MSME status (for payment term and Form I purposes)

---

## Red Flags — Environment & Safety

- TNPCB CTO expired or no consent obtained (significant risk — operations may be ordered to stop)
- Hazardous waste disposal records missing (unauthorized dumping risk — criminal liability under EPA 1986)
- Fire NOC expired in a commercial building with >50 occupants
- No annual factory licence renewal (operations technically illegal under Factories Act) [superseded 21-Nov-2025 — re-map to Code]
- Accident records not maintained or reportable accidents not reported to Inspector
- E-waste accumulating on premises without registered recycler documentation
- MSME vendor claiming status but not found on udyamregistration.gov.in (false MSME claim — preferential treatment fraud)
