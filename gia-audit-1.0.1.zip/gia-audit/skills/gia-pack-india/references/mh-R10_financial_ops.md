> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- Accounts Payable (AP) Controls — Procure-to-Pay
- Accounts Receivable (AR) Controls
- Bank & Treasury Controls
- Journal Entry Controls (IFC-Critical for Pune)
- Financial Close & Reporting Controls
- Expense Controls — Pune Context
- Audit Procedures — Financial Operations (Pune)
- Red Flags — Financial Operations (Pune)


# R10 — Financial Operations & Internal Controls (Pune)

## Accounts Payable (AP) Controls — Procure-to-Pay

| Stage | Control | Pune-Specific Test |
|-------|---------|-------------------|
| Purchase Requisition | Authorised by budget owner; within approved budget | Sample PRs — verify approvals vs. budget |
| Purchase Order | Raised post-PR approval; price matched to vendor master | PO vs. PR match; price benchmarking |
| Goods/Service Receipt | GRN signed by receiver; quantity/quality verified | GRN vs. PO; MIDC goods inward register |
| Invoice Receipt | Logged same day; stamped with receipt date | Invoice log completeness |
| Three-Way Match | PO + GRN + Invoice before payment | System auto-match or manual checklist |
| Payment Approval | Dual authorization per authorization matrix | Review payment approval records |
| Payment Execution | RTGS/NEFT only; no cash >[IN-028]/day per person | Bank statement — flag cash payments |
| Vendor Reconciliation | Statement reconciled quarterly | Reconciliation file vs. vendor statement |

### Cash Payment Restriction — IT Act 2025 (Critical)
- Max cash payment to a single person in a single day: **[IN-028]**
- Violation: Entire cash payment **disallowed as business expense** (IT Act 2025 equivalent of Sec 40A(3) IT Act 1961)
- Exception: Payments to banks, government, certain statutory bodies
- Test: Review all cash vouchers — flag any single-day, single-payee payment >[IN-028]

---

## Accounts Receivable (AR) Controls

| Control | Detail | Pune-Specific Risk |
|---------|--------|-------------------|
| Credit limit approval | New customer: CFO authorized | Pune startups/SMEs — credit risk |
| Invoice generation | Only on service delivery / shipment | IT: milestone billing risk (Ind AS 115) |
| Ageing review | Monthly AR ageing — Finance + Sales | IT/auto receivables — long credit terms |
| Disputed invoices | Separately tracked; not written off without approval | Auto OEM deductions — common in Pune |
| Write-off authorization | Bad debt: CFO + MD/Board + IT Act compliance | Audit trail mandatory |
| Export AR (FEMA) | Repatriation within 9 months — see R08 | STPI Pune IT companies |
| GST credit note | Issued correctly on sales returns; reflected in GSTR-1 | Pune manufacturing sales returns |
| Sec 269ST | No cash receipt ≥[IN-087] from any single person | Pune retail/events businesses |

---

## Bank & Treasury Controls

### Bank Reconciliation Standards
- Prepared monthly for EVERY bank account
- Prepared by accounts team; reviewed and signed by Finance Manager
- Outstanding items >30 days: Each item individually explained
- Reconciling items: Unpresented cheques, deposits in transit, bank charges, bank errors
- **Pune multi-bank scenario:** Large manufacturers often have 5–10 bank accounts (working capital, LC, BG, export) — ALL must be reconciled

### Bank Authorization Matrix (Minimum Best Practice)

| Amount | Approver 1 | Approver 2 | Channel |
|--------|-----------|-----------|---------|
| Up to [entity DoA tier] | Accounts Manager | — | NEFT |
| [entity DoA tier] – [entity DoA tier] | Finance Manager | — | NEFT/RTGS |
| [entity DoA tier] – [entity DoA tier] | Finance Manager | CFO | RTGS |
| Above [entity DoA tier] | CFO | MD/Director | RTGS + Board note |

### Cash Controls (Pune)
- Petty cash float: [entity policy]–[entity policy] (depending on establishment)
- Imprest system: Replenished on vouchers only; counted weekly; surprise quarterly count
- No vendor payment in cash
- No salary in cash (MH S&E Act — salary by bank transfer)
- Daily closing: Physical count vs. book balance; signed by custodian + supervisor

---

## Journal Entry Controls (IFC-Critical for Pune)

| Control | Detail |
|---------|--------|
| Authorization | All manual JEs: Preparer ≠ Approver; no self-approval |
| Documentation | Every JE: Business reason + supporting document attached |
| Period-end JEs | All JEs after period close: Finance Head approval; log maintained |
| Reversals | Auto-reversing for accruals; manual reversals need special approval |
| ERP access control | Only authorized personnel can post JEs (IT General Control) |
| High-risk JE flags | Round numbers; unusual accounts (suspense, personal a/c); non-business-hours; "adjustment"/"correction" |

### Pune Manufacturing / IT Specific JE Risks
- Year-end revenue recognition JEs (Ind AS 115 — milestone/% completion)
- MIDC scrap sales recorded as "miscellaneous income" without GST invoice
- Inter-company recharges between Pune parent and subsidiary — no supporting basis
- Tax provision reversal entries post-audit without documentation
- OT/shift allowance adjustments — manually added in payroll month-end JE

---

## Financial Close & Reporting Controls

### Month-End Close Checklist (Pune)
- [ ] All bank accounts reconciled (all accounts — current, OD, LC, export)
- [ ] All vendor invoices for the month received, matched, and accrued
- [ ] Payroll correctly posted; EPF/ESIC/PT/LWF/TDS payables created
- [ ] GST ITC reconciled against GSTR-2B
- [ ] MGST (MH GST) output tax reconciled against sales register
- [ ] Depreciation: Schedule II Companies Act 2013 rates applied; or Ind AS 16 useful life
- [ ] Provisions reviewed: Gratuity (Ind AS 19 actuarial), bonus, leave encashment, warranty (if product company)
- [ ] Intercompany balances: Confirmed and reconciled (common in Pune auto/pharma groups)
- [ ] Deferred tax computed (Ind AS 12)
- [ ] Revenue recognized per Ind AS 115 (correct performance obligation and timing)

### Key Ind AS Standards for Pune Companies

| Standard | Area | Pune Industry Relevance |
|---------|------|------------------------|
| Ind AS 115 | Revenue | IT: milestone; Auto: delivery; Pharma: out-licensing |
| Ind AS 116 | Leases | MIDC lease, office space, equipment lease — all on-balance-sheet |
| Ind AS 19 | Employee benefits | Gratuity + leave encashment — actuarial (ICAI 2024 guidance) |
| Ind AS 12 | Deferred tax | On all timing differences; MAT credit entitlement |
| Ind AS 36 | Impairment | Annual test for goodwill; indicators-based for assets |
| Ind AS 2 | Inventories | Auto ancillary: FIFO/WA; raw material, WIP, FG; no LIFO |
| Ind AS 21 | Foreign currency | IT/pharma: USD/EUR receivables; translation at closing rate |

---

## Expense Controls — Pune Context

| Area | Control | Regulatory Basis |
|------|---------|----------------|
| Entertainment | MD/CEO approval; reasonable per-person amount | IT Act 2025 business expenditure test |
| Travel | Pre-approval; actuals + receipts; no cash advance >[IN-028] | Cash limit IT Act 2025 |
| Director remuneration | Board + shareholder approval; Sec 197 max [IN-118] net profit | Companies Act 2013 Sec 197 |
| CSR expenditure | CSR committee approval; Schedule VII activities | Companies Act 2013 Sec 135 |
| Related party service fees | Arm's length; Sec 188 Board approval; Ind AS 24 | Companies Act 2013; Ind AS 24 |
| Capital vs. revenue | Capitalize per Ind AS 16 (useful life >1 year, reliable cost, future benefit) | Ind AS 16; IT Act 2025 depreciation |
| MIDC land/building | MIDC lease payment treated as operating lease (Ind AS 116) | Ind AS 116 |
| Scrap sales | GST invoice mandatory; income accounted; not netted | CGST Act; IT Act |

---

## Audit Procedures — Financial Operations (Pune)

1. **Bank reconciliation test:** 100% of all bank accounts × all months under review — outstanding items >30 days = finding
2. **Cash payment test:** Extract all cash vouchers; flag any single-day/single-payee payment >[IN-028]
3. **Journal entry analysis:** Extract all JEs; test for: round numbers, unusual GL accounts, weekend/holiday postings, same preparer and approver
4. **Three-way match test:** Sample ≥25 invoices per AP category → verify PO + GRN + Invoice
5. **Dual authorization:** Verify payment amounts match authorization levels; no bypassed approvals
6. **Petty cash count:** Surprise count + reconciliation to imprest book
7. **Credit note/write-off:** All write-offs have CFO/Board approval + IT Act bad debt deduction compliance
8. **Month-end accruals completeness:** Are all known liabilities (vendor invoices, salary, statutory dues, warranty) accrued?
9. **Intercompany reconciliation:** Pune parent vs. subsidiary — all balances confirmed and zero differences
10. **MIDC lease (Ind AS 116):** Verify ROU asset and lease liability correctly computed and on balance sheet
11. **Scrap sales (MIDC factories):** Verify each scrap sale has GST invoice; income not netted against costs

---

## Red Flags — Financial Operations (Pune)

- Bank reconciliation stale (>30 days outstanding items across multiple accounts)
- Large round-number JEs posted on last working day of month (period-cut manipulation)
- Cash payments to vendors or employees >[IN-028]/day (IT Act cash limit violation)
- Same person as preparer and approver of JEs or payments (segregation failure)
- MIDC scrap sales not invoiced under GST (unreported income + GST default)
- Intercompany balances unreconciled for >3 months (related party manipulation)
- Vendor advance paid without PO — balance outstanding >90 days with no delivery (advance misappropriation)
- Negative AP balance for a vendor (over-payment or double-payment not recovered)
- Warranty provision not made for product companies (Ind AS 37 violation)
- MIDC lease not on balance sheet post-Ind AS 116 (Ind AS 116 non-compliance)
