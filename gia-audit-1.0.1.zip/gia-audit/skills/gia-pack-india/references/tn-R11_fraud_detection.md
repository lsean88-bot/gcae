> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- ACFE Fraud Tree — Chennai Business Context
- Benford's Law Application
- Ghost Employee Detection Tests
- PMLA 2002 — Money Laundering & AML (India)
- Fraud Risk Assessment — Per ICAI SIA 11 & IIA GIAS
- Audit Procedures — Fraud Detection
- Red Flags — Consolidated Fraud Indicators


# R11 — Fraud Detection, ACFE & Analytics

## ACFE Fraud Tree — Chennai Business Context

### Asset Misappropriation (Most Common — [see ACFE benchmark in gia-fraud] of cases)

#### Cash Schemes
| Scheme | Red Flags | Test |
|--------|----------|------|
| Skimming (cash before recording) | AR > Collections; unaccounted cash receipts | Sec 269ST test; GST vs. income comparison |
| Larceny (cash after recording) | Cash shortage on count; unexplained reconciling items | Surprise petty cash count; bank statement vs. books |
| Payroll fraud: Ghost employees | Payroll headcount > EPF ECR headcount | Cross-match payroll list to EPFO member list |
| Payroll fraud: Rate inflation | Salary increase without approval | Authorized salary master vs. payroll run |
| Payroll fraud: Commission fraud | Inflated commissions to specific sales persons | Commission register vs. approval + customer confirmation |
| Expense reimbursement fraud | Inflated/duplicate claims; personal expenses | Receipt quality test; vendor internet search |
| Cheque/RTGS tampering | Payee altered; unauthorized beneficiary | Vendor master vs. payment file vs. bank debit |

#### Non-Cash Schemes
| Scheme | Red Flags | Test |
|--------|----------|------|
| Inventory theft | Physical count variance; high scrap % | Cycle count + Benford on adjustment vouchers |
| Data/IP theft | Unusual data access after hours | IT access logs; DLP alerts |
| Asset misuse | Company vehicle/equipment for personal use | Fuel log vs. GPS; vehicle log |

---

### Corruption (Most Damaging in India context)

| Scheme | Red Flags | Test |
|--------|----------|------|
| Bribery — vendor selection | Single-source procurement; price above market | Tendering records; price benchmarking |
| Kickbacks from contractors | Employee owns/connected to vendor | Vendor ownership cross-check against employee/director database |
| Bid rigging | Identical losing bids; winner known before tender | Tender documentation review; bid timing analysis |
| Conflicts of interest — undisclosed | Employee vendor relationship not declared | COI declaration register; vendor KYC vs. HR database |
| Grease payments / facilitation | Expenses to government officials | Expense report review; cash withdrawal patterns |

**Prevention of Corruption Act 1988 (India):** Bribery of public servant — criminal; MACC equivalent in India context.

---

### Financial Statement Fraud

| Scheme | Red Flags | Test |
|--------|----------|------|
| Revenue inflation | Fictitious invoices; round-trip revenue; early recognition | Customer confirmation; cut-off test; Ind AS 115 compliance |
| Expense suppression | Accruals not made; payables understated | Completeness test; post-period vendor invoices |
| Asset overstatement | Fixed assets not physically verified; phantom assets | Physical verification; Ind AS 36 impairment test |
| Liability understatement | Contingent liabilities not disclosed | Legal confirmations; minutes review for claims |
| Related party concealment | RPT not disclosed; off-balance-sheet entities | Sec 188 register; auditor related-party inquiries |

---

## Benford's Law Application

### What It Tests
First-digit (or first-two-digit) frequency distribution of naturally occurring numbers.
Benford and digit tests: run through `gia-fraud:gia-fraud-analytics` (Nigrini MAD primary with per-digit z-scores; chi-square supplementary for small populations). Confirm the preconditions (population size, range across orders of magnitude, no assigned or bounded numbers), segment fixed-amount populations first, and record the MAD table version in the workpaper. A deviation is an indicator, never a conclusion. Inline thresholds from the retired source were removed.

### When to Apply
- Vendor invoice amounts (full population preferred)
- Expense reimbursements
- Payroll amounts
- Journal entry postings
- Cash transaction amounts

### What It Cannot Test
- Assigned numbers (PAN, invoice serials, bank account numbers)
- Numbers with psychological anchors (below-threshold amounts like [IN-024])
- Small populations (use the small-N method in the analytics skill)

### Threshold Clustering Test (Complements Benford)
- Extract all transactions and plot near common thresholds:
  - Near [IN-028] (cash limit IT Act)
  - Near [IN-024] (TDS 194C single transaction)
  - Near [IN-024] (TDS 194C annual threshold)
  - Near [IN-087] (cash receipt limit, Sec 269ST)
- Statistical spike just below threshold = strong indicator of deliberate splitting

---

## Ghost Employee Detection Tests

1. **Payroll vs. EPF ECR match:** Every employee in payroll register must appear in EPFO ECR. Exceptions require documented reason (PF-exempted, new joiner, PF ceiling opt-out with Form 11).

2. **Unique identifier test:** Every payroll employee must have: (a) valid PAN (verify incometax.gov.in), (b) valid Aadhaar-seeded UAN (verify EPFO member portal), (c) unique bank account not shared with another employee.

3. **Biometric/access record match:** Payroll list vs. attendance system (biometric, HRMS, gate entry). No attendance for multiple months but salary paid = ghost.

4. **Email domain test:** All employees must have company email. Missing/personal email only = potential ghost or irregular engagement.

5. **Duplicate detection:** Same PAN across multiple employee IDs; same bank account for two employees; same mobile number for multiple employees.

6. **Post-exit payments:** Extract all employees with exit date in the period → verify no salary post-exit date.

7. **Round-trip test:** Ghost salary paid out, then returned as loan repayment by the same employee (bank statement analysis).

---

## PMLA 2002 — Money Laundering & AML (India)

**Applicable to:** Financial institutions, designated non-financial businesses, and professionals (DNFBPs including CA firms, real estate, jewellers).

**For corporate entities in Chennai:**
- Banks will flag unusual cash transactions (CTR: Cash Transaction Report for >[IN-090]/day)
- STR (Suspicious Transaction Report) filed by bank for unusual patterns
- Related party transactions with shell companies: scrutinize for layering
- Round-tripping via foreign subsidiaries/LLPs

---

## Fraud Risk Assessment — Per ICAI SIA 11 & IIA GIAS

### Fraud Risk Scoring Matrix

| Risk Factor | Weight | Score (1-5) | Weighted Score |
|-------------|--------|-------------|---------------|
| Cash handling volume | [set in engagement risk model] | — | — |
| Related party complexity | [set in engagement risk model] | — | — |
| Management override opportunity | [set in engagement risk model] | — | — |
| Incentive/pressure (revenue targets, bonus) | [set in engagement risk model] | — | — |
| Control environment maturity | [set in engagement risk model] | — | — |
| Prior fraud incidents | [set in engagement risk model] | — | — |
| **Total** | **100%** | | |

Score > 3.5 = High fraud risk → expand testing scope; involve forensic specialist.

---

## Audit Procedures — Fraud Detection

1. Apply Benford's Law to all vendor invoices, payroll amounts, expense claims — use statistical test
2. Threshold clustering test: Count transactions within ±[band set in engagement plan] of key thresholds ([IN-028]; [IN-024]; [IN-024])
3. Ghost employee: Full cross-match payroll vs. EPF ECR + biometric + PAN validation
4. Vendor conflict of interest: Cross-match vendor director/owner list against HR employee database + director register
5. Surprise petty cash count (unannounced)
6. Cash receipt test: Sec 269ST — verify no cash receipt >[IN-087] from any single person in a single transaction or related transactions
7. Post-exit salary: Extract all terminated employees; verify no payments after exit date
8. Journal entry fraud analysis: Filter JEs by: amount >[materiality threshold set in engagement plan], round number, weekend posting, description "adjustment"/"correction"/"reversal", user ID (test for inappropriate access)
9. Bank statement analysis: Any payment to personal accounts (non-vendor, non-employee) — flag and investigate
10. Management override test: Transactions approved by the same person who initiated them (segregation failure)

---

## Red Flags — Consolidated Fraud Indicators

- Employee lifestyle inconsistent with salary (luxury car, foreign travel, property)
- Employee responsible for AP and also signs off on vendor payments
- Vendor name/address similar to employee address
- Vendor registered after employee joined (possible employee-created vendor)
- Procurement function awarding contracts to same vendor repeatedly without tendering
- No physical verification of assets despite large capital expenditure
- Management resistant to audit access to specific systems or periods
- Accounting entries reversing just after audit period (window dressing)
- Loans to directors not disclosed or approved (Sec 185 Companies Act 2013)
- Round-trip transactions: money out as loan, money back as payment for services
