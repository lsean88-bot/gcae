# Plant readiness tracker: workflow and workbook pattern

Method for a plant statutory and customer-certification readiness tracker (new plant, takeover, new customer or OEM programme, cutover). Ported from the retired Pune VDA tracker command. The jurisdiction table (PMC, PCMC, MIDC, outside limits) and the Statutory-versus-Certification distinction are in `mh-R12_environment_safety_mh.md`. The command `/gia-plant-readiness-tracker` runs this file.

## Contents
- When to use
- Framing to state in the workbook and the reply
- Workflow
- Workbook tabs
- Reuse for other entities

## When to use
Requests such as VDA 6.3 readiness, plant Go/No-Go, statutory permits, factory licence tracker, MPCB consent tracker, plant cutover checklist, or any request naming the Pune facility of MKAPL Stamping for a new plant, takeover or customer programme.

## Framing to state in the workbook and the reply
- A customer or quality-management certification (VDA 6.3, IATF 16949, ISO 9001, 14001, 45001) is not a statutory operating licence.
- The two are separate parallel workstreams with separate gates.
- The Go/No-Go dashboard formula counts only high-priority statutory items. Certification items stay visible but are excluded from that formula, and the dashboard says so in a note.

## Workflow
1. Confirm or request: exact site jurisdiction (PMC, PCMC, MIDC estate, outside municipal limits); whether it is a new plant, takeover or new customer programme; the customer's certification requirement in writing (customer VDA 6.3 process audit, VDA-QMC-certified auditor, customer-approved supplier audit, IATF 16949, ISO 9001, or internal self-assessment: not interchangeable, see R12). Where not supplied, carry as an open dependency; if a default is used, state the assumption and its impact if wrong.
2. Build the workbook (tabs below) using the skeleton in R12, section "Pre-production Go/No-Go readiness tracker".
3. Status columns use dropdown validation: Open, In Progress, To Confirm, Conditional, Closed, Not Applicable. Conditional formatting: green Closed, red Open, amber To Confirm, Conditional and In Progress.
4. Recalculate and verify zero formula errors before delivery.
5. Name the file `GIA-2026-MKAPL-PUN-VDA-COMPLIANCE-{seq}.xlsx` unless told otherwise (ASSUMED naming convention from the source) and save to disk.
6. State plainly in the reply that every To Confirm or Open status is an unverified planning position, not a completed audit; the tracker is not a compliance opinion until each line is verified against the factories inspectorate (DISH Maharashtra), the state pollution control board portal, the competent fire and building authority, EPFO, ESIC and GST. Statutory values and dates come from `statutory-register-india.md` by row id; do not type them into the tracker.

## Workbook tabs
| Tab | Content |
|---|---|
| Cover_Index | Framing statements above; scope; open dependencies |
| Dashboard | Live COUNTA/COUNTIF completion percentage per category (never hardcoded); AND()-based Go/No-Go gate on high-priority statutory items only |
| Priority_Permits | High-priority statutory permits and consents |
| Factory_Licence_File | Factory licence, plans, stability and layout approvals |
| MPCB_Applicability | Environmental-authority applicability screen (consent to establish and operate) |
| Fire_Building_Jurisdiction | Fire NOC, building completion, jurisdiction |
| Labour_Direct_Employees | Registrations and compliances for direct employees |
| Contractor_Compliance | Contract labour licence and contractor compliance |
| [Certification]_Readiness | For example VDA6.3_Readiness; excluded from the Go/No-Go formula |
| Action_Tracker | Owner (role), due date, status |

## Reuse for other entities
The same skeleton applies to MKAPL Jacks, MKAPL Die Casting Chennai (swap the Maharashtra authority and portal for the Tamil Nadu equivalents, using the `tn-` files) and to Erawan or MKPC plant cutovers (swap in the Malaysian authorities, using `gia-pack-malaysia`). Only authority names, portals and the process-applicability table change; do not rebuild the skeleton.
