> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.

# Professional Tax — Maharashtra (Pune) HR Audit Reference
# Maharashtra State Tax on Professions, Trades, Callings and Employments Act 1975

## Registration Requirements
- **PTRC** (Professional Tax Registration Certificate): Employer registration for deducting and remitting employee PT
- **PTEC** (Professional Tax Enrolment Certificate): Employer's own PT liability (flat [IN-046] p.a.)
- Portal: mahagst.gov.in → PT module
- New employer: register within 30 days of commencement of business

## Maharashtra PT Slabs — FY 2024-25
*(Always web-validate at mahagst.gov.in before citing in any finding)*

| Monthly Gross Salary (₹) | Male Employees | Female Employees |
|--------------------------|----------------|-----------------|
| Up to [IN-140] | Nil | Nil |
| [IN-140] – [IN-140] | [IN-140]/month | **Nil** |
| Above [IN-140] | [IN-140]/month (Jan–Dec) | [IN-140]/month (Jan–Dec) |
| **February only** | **[IN-141]** (for >[IN-140] earners) | **[IN-141]** (for >[IN-140] earners) |

**Maximum annual PT per employee = [IN-044]** (11 months × [IN-140] + February [IN-141])

### Critical MH-specific rules:
1. **Female employees ≤ [IN-045]/month: completely exempt** from employee PT
2. **February = [IN-141]** (not [IN-140]) for all employees earning > [IN-140] — HRIS must auto-apply
3. Employer PT (PTEC): [IN-046] flat per year, payable by **30 June**

## Remittance Due Dates
| Filing | Due Date |
|--------|----------|
| Monthly employee PT (PTRC) | 31st of following month |
| Annual employer PT (PTEC) | 30 June each year |
| Annual return (if applicable) | 31 March |

## Filing — Form III-B
- Form III-B: Monthly PT return cum challan — filed online at mahagst.gov.in
- Verify challan serial number and BSR code (Rank 1 evidence)
- Cross-reference: payroll PT deduction register vs. Form III-B totals vs. bank debit

## Audit Test Matrix

| Test | Procedure | Risk |
|------|-----------|------|
| Gender exemption | Filter female employees ≤ [IN-045] → PT deducted should be zero | PT deducted, not refunded — misappropriation |
| February [IN-141] | Filter all employees > [IN-140] in February → verify [IN-141] deducted | [IN-140] used throughout — underpayment to authority |
| New employees | Verify PT deduction starts from month of joining | Deduction missed in first month |
| Contract labour | Verify contractor deducts PT for contract workers | Principal employer's exposure if contractor defaults |
| PTEC payment | Verify [IN-046] paid by 30 June | Late payment — interest + penalty |
| Remittance reconciliation | PTRC deduction register = Form III-B challan | Deduction collected, remittance short — trust fraud |

## Penalties under MH PT Act 1975
- Late filing: [IN-143]/month
- Non-registration: [IN-143]/day until registered
- Non-payment: simple interest + penalty up to 2× tax
- False returns: prosecution under Sec 9

## Pune PT Authority
- PT administered by Maharashtra State (not municipal) → mahagst.gov.in
- Jurisdiction: Maharashtra Sales Tax Department (now GST + PT combined portal)
- Queries / objections: Joint Commissioner of State Tax, Pune Division
