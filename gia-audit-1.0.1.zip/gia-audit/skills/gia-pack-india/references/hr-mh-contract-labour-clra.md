> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.

# Contract Labour (CLRA 1970 / MH Rules 1971) — Pune HR Audit Reference

## Contract Labour (Regulation and Abolition) Act 1970

### Coverage Thresholds
- Principal employer with ≥20 contract workers → Registration mandatory
- Contractor deploying ≥20 workers → Licence mandatory
- Once registered, coverage continues even if count drops below 20

### Maharashtra-Specific Rules
- **Maharashtra Contract Labour (Regulation and Abolition) Rules 1971** govern procedure
- Administering authorities in Pune:
  - **DLC Pune City** — PMC limits
  - **DLC PCMC** — Pimpri-Chinchwad, MIDC Bhosari, Chakan
  - **DLC Pune Rural** — Talegaon, Ranjangaon, Rajgurunagar
- Annual returns: **Form XXV** — due **15 February** for previous calendar year

### Forms Reference (MH CLRA)

| Form | Purpose | Maintained by |
|------|---------|--------------|
| Form I | Application for registration | Principal employer |
| Form II | Certificate of registration | DLC (Rank 1) |
| Form IV | Application for contractor licence | Contractor |
| Form V | Contractor licence | DLC (Rank 1) |
| Form VI | Notice of commencement/completion of contract work | Contractor |
| Form XII | Register of contractors | Principal employer |
| Form XIII | Register of workers employed | Contractor (at worksite) |
| Form XIV | Register of wages | Contractor |
| Form XV | Wage slip | Per worker per pay period |
| Form XVI | Register of deductions | Contractor |
| Form XVII | Register of overtime | Contractor |
| Form XVIII | Register of fines | Contractor |
| Form XIX | Register of advance wages | Contractor |
| Form XX | Register of leave | Contractor |
| Form XXI | Register of accidents | Contractor |
| Form XXII | Notice board at worksite | Contractor |
| Form XXV | Annual return | Principal employer → DLC |

### Principal Employer Liability — Sec 21
- Primary obligation: Contractor pays wages
- Contingent: Principal employer pays within 48 hours if contractor defaults; recovers from contractor
- **Audit test:** Verify contract agreement has recovery clause; verify contractor's payroll matches CLRA Form XIV [superseded 21-Nov-2025 — re-map to Code]

### MIDC Pune — Contract Labour Additional Compliance
- MIDC plots: verify MIDC tenancy agreement allows sub-contracting
- Security contractors: registered under Private Security Agencies (Regulation) Act 2005 additionally
- Housekeeping / canteen contractors in Hinjewadi / Kharadi IT parks: verify CLRA + MH Shops Act 2017 compliance [superseded 21-Nov-2025 — re-map to Code]
- Construction activity (new plant/expansion): separate CLRA licence required per project; verify BOCW (Building & Other Construction Workers) Act 1996 cess payment ([IN-132] of construction cost) [superseded 21-Nov-2025 — re-map to Code]

### Deemed Employment Risk
Red flags indicating sham contracting:
- Contract workers using principal employer's tools/machinery/raw materials
- Workers taking instructions from principal employer's supervisors
- Same workers deployed for >3 years exclusively to one principal employer
- Core/perennial manufacturing activity performed by contract workers

**Maharashtra Government notifications under Sec 10:** Several occupations in MH have been notified as prohibited for contract labour. Audit test: map contract worker job descriptions to MH Sec 10 notification — prohibited categories = immediate finding.

### TDS on Contractor Payments
- Sec 194C: [IN-023] (individual/HUF), [IN-023] (company/firm)
- Threshold: single payment > [IN-024] OR aggregate > [IN-024] p.a.
- Verify via TRACES Form 26AS of contractor (Rank 1)
- Common Pune finding: IT infrastructure maintenance contractors paid without TDS Sec 194C

### EPF/ESIC for Contract Workers
- Contractor's ECR — obtain and cross-check against worker list in Form XIII
- Workers on site > workers on contractor ECR = coverage gap → principal employer's contingent liability
- Verify ESIC dispensary coverage for contract workers in MIDC area
