> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- Critical Transition Note — IT Act 2025 ([IN-022])
- Key TDS Sections (IT Act 1961 — applicable up to 31 Mar 2026)
- TDS Deposit & Return Deadlines
- TDS Sec 194C — Contractor Payments (Key Rules)
- Advance Tax (Corporate) — IT Act 1961
- Audit Procedures — Direct Tax
- Red Flags — Direct Tax


# R01 — Direct Tax (Income Tax Act 2025 / IT Act 1961 Transition)

## Critical Transition Note — IT Act 2025 ([IN-022])

| Aspect | IT Act 1961 | IT Act 2025 |
|--------|------------|------------|
| Applies to | Up to 31 Mar 2026 (Tax Year / FY 2025-26 and earlier) | [IN-022] (Tax Year 2026-27 onwards) |
| Sections | 819 sections + numerous provisos | 536 sections, 23 chapters, 16 schedules |
| Key terminology | Previous Year / Assessment Year | "Tax Year" (single unified concept = FY) |
| Tax rates | Unchanged | Unchanged — structural reform only |
| TDS sections | Sec 192, 194C, 194J, 194H etc. | Re-numbered (e.g. 194C → Sec 393 in IT Act 2025) |
| Forms | Form 24Q, 26Q, 27Q, Form 16/16A | Forms renamed/renumbered — verify CBDT notification |
| FY 2025-26 returns | Filed under IT Act 1961 | n/a |
| FY 2026-27 returns | n/a | Filed under IT Act 2025 |

> **Audit implication:** For Jan–Mar 2026 transactions → IT Act 1961 governs.
> For Apr 2026 onwards → IT Act 2025 governs. Always state which Act applies.

---

## Key TDS Sections (IT Act 1961 — applicable up to 31 Mar 2026)

| Section | Nature of Payment | Rate | Threshold | Deductor |
|---------|------------------|------|-----------|---------|
| 192 | Salary | Slab rate | Any salary above basic exemption | Employer |
| 193 | Interest on securities | [IN-064] | [IN-064] | Specified |
| 194A | Interest other than securities | [IN-065] | [IN-065] (bank); [IN-065] others | Specified |
| 194C | Contractor / sub-contractor | [IN-023] (individual/HUF); [IN-023] (others) | [IN-024] single / [IN-024] annual | Specified |
| 194H | Commission / brokerage | [IN-066] | [IN-066] | Specified |
| 194I | Rent — land/building | [IN-067] | [IN-067] p.a. | Specified |
| 194I(a) | Rent — plant/machinery | [IN-068] | [IN-068] p.a. | Specified |
| 194J | Professional/technical fees | [IN-025] professional; [IN-025] technical | [IN-069] | Specified |
| 194Q | Purchase of goods | [IN-070] | Buyer turnover >[IN-070]; transaction >[IN-070] | Specified buyer |
| 206AA | No PAN furnished | [IN-026] (or applicable rate, whichever higher) | — | Mandatory |
| 206AB | Non-filer of returns (specified persons) | [IN-071] or twice normal rate, whichever higher | Specified condition | Mandatory |

**Critical:** TDS must be deducted at time of credit or payment, whichever is EARLIER.

---

## TDS Deposit & Return Deadlines

| Month of deduction | Deposit due (Challan) | Exceptions |
|-------------------|----------------------|------------|
| April to February | 7th of following month | — |
| March | 30th April | Extended for March only |

| Return | Nature | Quarterly due dates |
|--------|--------|-------------------|
| Form 24Q | TDS on salary | Q1: 31 Jul | Q2: 31 Oct | Q3: 31 Jan | Q4: 31 May |
| Form 26Q | TDS other than salary | Same as 24Q |
| Form 27Q | TDS on NR payments | Same as 24Q |
| Form 27EQ | TCS | Same as 24Q |

**Late filing penalty:** Sec 234E — [IN-073]/day (max up to TDS amount). Sec 271H — [IN-073] to [IN-073].
**Non-deduction consequence:** Sec 40(a)(ia) — [IN-074] of the entire payment disallowed as expense.

---

## TDS Sec 194C — Contractor Payments (Key Rules)

1. **Threshold:** Single payment > [IN-024] OR aggregate in FY > [IN-024] → TDS applies
2. **Rate:** [IN-023] for Individual/HUF; [IN-023] for Company, Firm, LLP, AOP, BOI
3. **GST exclusion:** TDS is on base value ONLY — not on GST (CBDT Circular 23/2017)
4. **Material contracts:** TDS on gross if material ownership does not pass to contractor; on labour only if material separately identified
5. **Transport exemption:** No TDS if transporter declares ≤10 vehicles owned (Sec 194C(6)) — obtain declaration in writing
6. **No PAN:** [IN-026] TDS mandatory (Sec 206AA)
7. **Disallowance risk:** If TDS not deducted → Sec 40(a)(ia) disallows [IN-074] of payment

---

## Advance Tax (Corporate) — IT Act 1961

| Instalment | Due Date | % of Annual Liability |
|-----------|---------|----------------------|
| 1st | 15 June | [IN-075] |
| 2nd | 15 September | [IN-075] (cumulative) |
| 3rd | 15 December | [IN-075] (cumulative) |
| 4th | 15 March | 100% |

**Interest on default:** Sec 234B (non-payment) and Sec 234C (deferment) — [IN-076] per month.

---

## Audit Procedures — Direct Tax

1. Obtain Form 26AS, AIS, and TIS for all Tax Years under review from portal (Rank 1)
2. Reconcile 26AS TDS credits to books — any unexplained TDS deducted by third parties = income not recorded
3. Test 100% TDS deductions: recompute TDS on each vendor category (194C/194J/194H/194I) for all months
4. Verify TDS challan deposit dates against due dates — late payment = Sec 234E interest
5. Verify Form 26Q/24Q filed on time via TRACES — late = Sec 271H penalty
6. Test for Sec 206AA compliance — verify PAN on every vendor in register
7. Test for Sec 206AB — check if any key vendor/deductee is a "specified person" (non-filer)
8. Reconcile TDS returns to books of account — any gap = under-deduction risk
9. Verify advance tax instalments — recompute on latest estimated income
10. Verify corporate tax provision — match to ITR filed; test for under-provision
11. **IT Act 2025 transition (if period includes Apr 2026+):** Verify new section references used in returns; verify new form numbers; verify "Tax Year" terminology in records

---

## Red Flags — Direct Tax

- Vendors with no PAN on file (blanket [IN-026] TDS risk)
- Multiple invoices just below [IN-024] from same vendor (invoice splitting to avoid 194C)
- TDS deducted but not deposited (trust receipt fraud + Sec 276B prosecution risk)
- 26AS mismatch with books (income suppression or TDS default by payer)
- Unexplained year-end entries reducing TDS liability
- Directors' remuneration not covered by TDS Sec 192
- Professional fees paid to related parties without TDS 194J
