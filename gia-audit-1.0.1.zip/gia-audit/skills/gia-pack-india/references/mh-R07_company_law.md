> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- ROC Jurisdiction — Pune (Critical Update: Feb 2026)
- Entity Types & Key Compliance Matrix
- Key Annual Compliance — Private Limited Company (Pune / ROC Pune)
- Internal Financial Controls (IFC) — Companies Act 2013 Sec 143(3)(i)
- Audit Committee Requirements
- Related Party Transactions (RPT) — Pune Context
- MSME Payment Compliance (Pune — High Risk)
- Statutory Registers (Pune Companies)
- Company Law Audit Procedures (Pune)
- Red Flags — Company Law (Pune)


# R07 — Companies Act 2013 & Corporate Governance (Pune / ROC Pune)

## ROC Jurisdiction — Pune (Critical Update: Feb 2026)

**MCA Notification:** S.O. 4850(E) dated **23 October 2025** — ROC jurisdiction realignment.
**Effective:** **16 February 2026** (postponed [IN-107] via MCA notification 30 Dec 2025).

### Post-Feb 2026 ROC Jurisdiction

| ROC Office | Covers | Jurisdiction |
|-----------|--------|-------------|
| **ROC Pune** | Maharashtra (excluding Mumbai district) | All companies with registered office in Pune, Nashik, Aurangabad, Nagpur (verify MCA notification for exact district mapping) |
| ROC Mumbai | Mumbai district only | Mumbai-registered companies |

> **Audit check:** Verify every Pune-entity filing uses **ROC Pune** as the jurisdiction on MCA21. Companies that were previously under ROC Mumbai (if any MH company outside Mumbai) must verify their new correct ROC. Incorrect ROC filings post-Feb 2026 = misfiling risk.

**ROC Pune address:** PMT Building, Pune Stock Exchange, 3rd Floor, Deccan Gymkhana, Pune – 411004.

---

## Entity Types & Key Compliance Matrix

| Entity Type | Governing Law | ROC | Audit Requirement |
|-------------|--------------|-----|------------------|
| Private Limited | Companies Act 2013 | **ROC Pune** | Statutory audit — mandatory |
| Public Limited | Companies Act 2013 | ROC Pune / Mumbai | Statutory + SEBI (if listed) |
| OPC | Companies Act 2013 | ROC Pune | Statutory audit |
| LLP | LLP Act 2008 | ROC Pune | Statutory if turnover >[IN-108] or contribution >[IN-108] |
| Section 8 | Companies Act 2013 | ROC Pune | Statutory audit |
| Partnership Firm | Indian Partnership Act 1932 | Tax filing only | Tax audit if turnover threshold |
| Proprietorship | No entity registration | Income Tax / GST | Tax audit if threshold |

---

## Key Annual Compliance — Private Limited Company (Pune / ROC Pune)

| Compliance | Form | Portal | Due Date | Penalty |
|-----------|------|--------|---------|---------|
| Financial Statements | AOC-4 / AOC-4 CFS | MCA21 | 30 days from AGM (AGM by 30 Sep) | [IN-109]/day |
| Annual Return | MGT-7 / MGT-7A (small co.) | MCA21 | 60 days from AGM | [IN-110] + [IN-110]/day |
| Auditor Appointment | ADT-1 (new) or ratification | MCA21 | 15 days from AGM | [IN-111]–[IN-111] |
| Director KYC | DIR-3 KYC | MCA21 | 30 September each year | DIN deactivation |
| Board Meetings | Minutes + Attendance | Company records | Min 4/year (≤120 days between) | Fine on officers |
| AGM | Notice + Minutes | Company records | Within 6 months of FY end (by 30 Sep) | Penalty on officers |
| Charge Registration | CHG-1 (creation) | MCA21 | Within 30 days | Condonation + extra fees |
| MSME Form I | Outstanding MSME dues >45 days | MCA21 | **Oct 31 + Apr 30** (half-yearly) | [IN-112] |
| CSR Report (if applicable) | CSR-2 | MCA21 | With AOC-4 | [IN-113]–[IN-113] |
| SBO Declaration | BEN-2 | MCA21 | Within 90 days of trigger | Penalty |

---

## Internal Financial Controls (IFC) — Companies Act 2013 Sec 143(3)(i)

**Applicable:** All companies. Board must confirm IFC in place and operating effectively (Directors' Responsibility Statement in Annual Report). Statutory auditor must report on IFC.

### Key IFC Domains for Pune Companies

| IFC Domain | Pune-Specific Risk |
|-----------|-------------------|
| Revenue recognition | IT companies: % completion method (Ind AS 115); milestone billing |
| Procure-to-pay | Manufacturing: MIDC vendor payments; raw material procurement |
| Payroll | IT sector: Variable pay, ESOPs, flexi-benefit plans |
| Treasury | Large Pune groups: Inter-company loans, bank guarantees |
| IT General Controls | Hinjewadi IT companies: ERP access management, SOC 2 equivalents |
| Inventory | Auto ancillary: BOM accuracy, scrap reconciliation, cycle counts |

---

## Audit Committee Requirements

**Mandatory for:** Companies with paid-up capital ≥[IN-115] OR turnover ≥[IN-115] OR outstanding borrowings/debentures/deposits ≥[IN-115].

| Requirement | Detail |
|-------------|--------|
| Composition | Min 3 directors; majority independent; chairperson = independent director |
| Terms of Reference | Oversight of financial reporting, audit, IFC, RPT (Sec 177) |
| Meetings | Min 4 per year |
| Vigil mechanism | Mandatory for Audit Committee companies |
| Internal auditor reports to | Audit Committee |

---

## Related Party Transactions (RPT) — Pune Context

Pune has significant intra-group transactions (auto OEM–ancillary, pharma–CRO, IT–offshore captive) — RPT governance is high-risk.

| Transaction type | Threshold (ordinary resolution) |
|-----------------|-------------------------------|
| Sale/purchase of goods | [IN-116] of turnover or [IN-116] |
| Property transactions | [IN-116] of net worth or [IN-116] |
| Leasing of property | [IN-116] of net worth or [IN-116] |
| Services | [IN-116] of turnover or [IN-116] |
| Office of profit to related party | [IN-117] p.m. |

**Register:** Form MBP-4 — all RPTs recorded.
**Arm's length test:** All RPTs at arm's length. Non-arm's length = special resolution required regardless of value.

---

## MSME Payment Compliance (Pune — High Risk)

**Pune MSME ecosystem is one of India's largest.**
- Payment to MSME suppliers: Within 45 days of acceptance (max if written agreement)
- Overdue interest: 3× Bank Rate (compound, monthly) on delayed MSME payments
- **MSME Form I:** Half-yearly disclosure — due **October 31** (Apr-Sep period) and **April 30** (Oct-Mar period)

**Audit test:** Extract Pune vendor list → identify MSME-registered vendors (verify on udyamregistration.gov.in) → cross-check payment dates vs. invoice dates → any >45 days = interest liability and MSME Form I disclosure risk.

---

## Statutory Registers (Pune Companies)

| Register | Sec | Content |
|---------|-----|---------|
| Register of Members | Sec 88 | Shareholder names, address, shares |
| Register of Directors & KMPs | Sec 170 | Director details, DIN |
| Register of Charges | Sec 85 | All mortgages, pledges, charges |
| Register of Contracts (RPT) | Sec 189 | All related party transactions |
| Minutes Book — Board | Sec 118 | All board and committee resolutions |
| Minutes Book — General Meeting | Sec 118 | AGM/EGM resolutions |
| Register of Loans & Investments | Sec 186 | Inter-company loans/investments |

---

## Company Law Audit Procedures (Pune)

1. Verify CIN on MCA21 — confirm active status under **ROC Pune** jurisdiction (post-Feb 2026)
2. Confirm AOC-4 and MGT-7/7A filed on time — check SRN on MCA21
3. Test all 4 board meetings — verify quorum, resolutions, signatures
4. Verify Director KYC (DIR-3) filed by 30 Sep — DIN deactivation = governance risk
5. Verify Auditor appointment (ADT-1) — within 15 days of AGM
6. Test RPT transactions (especially Pune group companies) — MBP-4 maintained; AC recommendation; shareholder approval if threshold crossed
7. MSME Form I: Extract AP ageing for MSME vendors — any balance >45 days outstanding? Filed by Oct 31/Apr 30?
8. Verify CSR compliance (if applicable) — [IN-114] net profit; CSR-2 filed with AOC-4
9. Verify IFC reporting in Board's Report (Directors' Responsibility Statement)
10. Verify charge registration (CHG-1) within 30 days of any new bank borrowing

---

## Red Flags — Company Law (Pune)

- Annual returns / financial statements filed late or not filed — ROC Pune may initiate strike-off
- Post-Feb 2026: Filing under ROC Mumbai for a non-Mumbai MH entity (jurisdictional error)
- Board meeting minutes not signed or quorum not met
- RPT with group companies not disclosed in MBP-4 register or Ind AS 24 notes
- MSME Form I not filed despite Pune MSME vendors with outstanding balances >45 days
- Charges not registered with ROC Pune within 30 days
- DIN deactivated directors executing company documents (legally invalid)
- IT companies in Hinjewadi/Baner: ESOPs not reported in annual return correctly
- Large intra-group service contracts between Pune parent and subsidiary without arm's-length pricing documentation
