> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.

# Contract Labour (CLRA 1970) — Chennai HR Audit Reference

## Contract Labour (Regulation and Abolition) Act, 1970

### Coverage
- Principal employer: establishment employing ≥20 contract workers on any day in preceding 12 months
- Contractor: employing ≥20 workers for any work
- Registration: Principal employer — Form I → Certificate of Registration (Form II)
- Licence: Contractor — Form IV application → Form V licence (per worksite, per year)

### Tamil Nadu CLRA Rules 1975
- Administering authority: Commissioner of Labour / Deputy Labour Commissioner, Chennai
- Annual returns: Form XXV — due by 15 February for previous calendar year

### Forms Reference

| Form | Purpose | Maintained by |
|------|---------|--------------|
| Form I | Application for registration | Principal employer |
| Form II | Certificate of registration | Issuing authority |
| Form IV | Application for contractor licence | Contractor |
| Form V | Contractor licence | Issuing authority |
| Form VI | Notice of commencement/completion | Contractor to principal employer |
| Form XII | Register of contractors | Principal employer |
| Form XIII | Register of persons employed | Contractor (at worksite) |
| Form XIV | Register of wages | Contractor |
| Form XV | Wage slip | Contractor (per employee per pay period) |
| Form XVI | Register of deductions | Contractor |
| Form XVII | Register of overtime | Contractor |
| Form XVIII | Register of fines | Contractor |
| Form XIX | Register of advance wages | Contractor |
| Form XX | Register of leave | Contractor |
| Form XXI | Register of accidents | Contractor |
| Form XXII | Notice board at worksite | Contractor |
| Form XXV | Annual return | Principal employer |

### Wage Payment Compliance (Sec 21)
- Primary obligation: Contractor must pay wages
- Contingent obligation: If contractor fails, principal employer MUST pay within 48 hours
- Principal employer can recover amount paid from contractor
- Audit test: Verify contractor's Form XIV for all contract workers — confirm wages ≥ TN minimum wage for relevant category

### EPF/ESIC for Contract Workers
- Contractor bears primary responsibility
- If contractor's workers are deployed at principal employer's premises, principal employer must ensure coverage
- Verify contractor's ECR (EPFO/ESIC) — obtain from contractor; cross-check worker list vs. contract deployment records
- Test: contract workers on site > workers on contractor's ECR = undercoverage finding

### Prohibited Work Activities (Sec 10 Notification Risk)
TN Government has notified certain core/perennial activities where contract labour is prohibited:
- Canteen, sweeping/cleaning in certain industries
- Core production activities generally not permitted under contract in manufacturing
- Audit test: map job descriptions of contract workers to notified prohibited categories

### Deemed Employment Risk
If contractor is a "sham" (worker integrated into principal employer's operations, principal employer controls hours/tools/methods), courts may declare workers as "deemed employees" → backlog of EPF/ESIC/Gratuity/Bonus becomes principal employer's liability
- Red flags: contractor workers using principal employer's tools/equipment, following principal employer's supervisors, working exclusively for one principal employer for >3 years

### Principal Employer Obligations Checklist
✅ Certificate of registration (Form II) obtained
✅ Form XII — contractor register updated
✅ Contractor holds valid Form V licence (not expired)
✅ Contractor's Form XIII/XIV/XV displayed at worksite
✅ Minimum wages compliance verified for all contract workers
✅ EPF/ESIC contributions verified via contractor's ECR
✅ Annual return Form XXV filed by 15 February
✅ Canteen, rest rooms, first aid (Sec 16/17/18/19) — verify if contractor workforce > 100
