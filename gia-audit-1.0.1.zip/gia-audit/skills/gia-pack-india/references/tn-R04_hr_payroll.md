> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- Salary Structure Framework (Chennai / Tamil Nadu)
- Payroll Processing Controls
- TDS on Salary (Sec 192 IT Act 1961 / IT Act 2025 equivalent)
- Termination & Full-and-Final (FnF) Settlement
- Statutory Forms — Payroll Domain
- Payroll Audit Procedures
- Red Flags — Payroll


# R04 — HR & Payroll Operations

## Salary Structure Framework (Chennai / Tamil Nadu)

### Compliant Salary Components

| Component | Nature | EPF Base? | ESIC Base? | PT Base? | TDS Basis |
|-----------|--------|-----------|-----------|---------|-----------|
| Basic Salary | Fixed | Yes | Yes | Yes | Yes |
| Dearness Allowance (DA) | Fixed/variable | Yes | Yes | Yes | Yes |
| House Rent Allowance (HRA) | Fixed | No | Yes | Yes | Yes (partial exemption IT Act 2025 Sec 10(13A)/equivalent) |
| Conveyance Allowance | Fixed | No | Yes | Yes | Up to [IN-084]/mo exempt (pre-Apr 2026); verify IT Act 2025 equivalent |
| Medical Allowance | Fixed | No | Yes | Yes | Up to [IN-085] p.a. exempt (pre-Apr 2026); verify IT Act 2025 |
| Special Allowance | Fixed | No (if ≤[IN-017] gross pre-Labour Codes) | Yes | Yes | Fully taxable |
| Overtime | Variable | Yes | Yes | Yes | Fully taxable |
| Bonus / Ex-gratia | Variable | No (if not regular) | No (if not regular) | Yes | Fully taxable |
| Leave Travel Allowance (LTA) | Periodic | No | No | No | Exempt 2x in 4-year block (IT Act) |
| Gratuity | On separation | No | No | No | Exempt up to ceiling (IT Act) |
| PF employer contribution | Statutory | N/A | No | No | Exempt up to [IN-086] |

> **Post–Labour Codes (Nov 21 2025):** If allowances collectively exceed [IN-017] of total remuneration, the excess is re-included in the EPF and ESIC wage base. Reassess all salary structures from Dec 2025.

---

## Payroll Processing Controls

### Pre-Payroll Controls
- [ ] Attendance/leave data frozen and signed off by HR by cutoff date
- [ ] New joiners: Appointment letter + bank details + KYC (PAN, Aadhaar) completed before first salary
- [ ] Exits: Full-and-final computation approved by HR and Finance; no salary processed after exit date
- [ ] Increment/promotion letters: Authorised before payroll run — no retrospective changes without documented approval
- [ ] Variable pay: Supported by performance records or management approval

### Payroll Run Controls
- [ ] Payroll processed only in HRMS — no manual overrides without dual-level approval
- [ ] Changes from prior month reconciled and documented
- [ ] TDS computation: Tax slab applied; Investment proof declarations obtained (April, January update)
- [ ] EPF/ESIC: Automatically computed from HRMS; reconciled to ECR before challan generation

### Post-Payroll Controls
- [ ] Payroll register: Signed by Payroll Manager + Finance Head
- [ ] Bank transfer file: Dual authorization (maker + checker); no manual NEFT/RTGS entries
- [ ] Disbursement date: Salary must be credited by 7th of following month (TN S&E Act; verify specific establishment type)
- [ ] Pay slips: Issued to all employees — mandatory under Payment of Wages Act 1936 / TN S&E Act [superseded 21-Nov-2025 — re-map to Code]
- [ ] Reconciliation: Total payroll cost per P&L vs. sum of individual pay slips

---

## TDS on Salary (Sec 192 IT Act 1961 / IT Act 2025 equivalent)

- TDS on salary = Estimated annual tax liability / 12 months
- Must be deducted every month from April
- Investment declarations: April (provisional) + January (revised with proofs)
- HRA exemption: Verify rent receipts + PAN of landlord (if annual rent >[IN-083])
- Form 12BB: Employee's investment declaration — mandatory per Rule 26C
- Form 16: Must be issued to all employees by June 15 of following year
- Form 24Q: Quarterly TDS return (Q4 due May 31)

**Common error:** Lump-sum TDS deduction in March instead of equal monthly deduction → Sec 234E interest risk.

---

## Termination & Full-and-Final (FnF) Settlement

| Component | Legal Basis | Timeline |
|-----------|------------|---------|
| Salary up to last working day | Contract / TN S&E Act | With FnF |
| Leave encashment (earned leave) | TN S&E Act / Contract | With FnF |
| Gratuity (≥5 years service) | Payment of Gratuity Act 1972 | Within 30 days of eligibility | [superseded 21-Nov-2025 — re-map to Code]
| Bonus (if year completed) | Payment of Bonus Act 1965 | Within 8 months of FY end | [superseded 21-Nov-2025 — re-map to Code]
| PF settlement / transfer | EPF Act — Form 10C/19 | Within 60 days of claim |
| ESIC claim documents | ESI Act | Employer provides Form 31 within 3 months | [superseded 21-Nov-2025 — re-map to Code]
| Experience letter | Good practice; TN S&E Act Sec 26 — service certificate mandatory | At time of separation |
| Relieving letter | Good practice; TN S&E Act | At time of separation |

**Gratuity disqualification:** Misconduct involving damage/loss to employer property — only the excess over the calculated amount may be forfeited; basic gratuity cannot be forfeited for other misconduct.

**TDS on FnF:** Leave encashment on retirement — exempt u/s 10(10AA); Gratuity — exempt u/s 10(10); Ex-gratia fully taxable. Verify IT Act 2025 equivalents.

---

## Statutory Forms — Payroll Domain

| Form | Purpose | Frequency | Portal |
|------|---------|-----------|--------|
| Form 24Q | TDS on salary return | Quarterly | TRACES (traces.gov.in) |
| Form 16 (Part A + B) | TDS certificate to employee | Annual (by Jun 15) | TRACES (Part A from portal) |
| Form 12BA | Statement of perquisites | Annual (with Form 16) | Internal |
| ECR (EPFO) | EPF/EPS contribution challan | Monthly | epfindia.gov.in |
| ECR (ESIC) | ESIC contribution challan | Monthly | esic.gov.in |
| Form 11 (New) | EPF — employee declaration | On joining | HRMS/EPFO |
| Form 19 | EPF — final withdrawal claim | On separation | EPFO |
| Form 10C | EPS — withdrawal/scheme certificate | On separation | EPFO |
| UAN Activation | EPF — mandatory for all members | On joining | EPFO |

---

## Payroll Audit Procedures

1. Extract 100% payroll register for all months under review from HRMS (Rank 2)
2. Reconcile total gross payroll per month to:
   - General ledger / P&L — salary expense line
   - Bank statement — salary disbursement debit
   - EPF ECR — contribution base consistency
3. Test for ghost employees: Cross-check payroll employee list against:
   - Active HR file (physical/digital)
   - Biometric/access card attendance
   - EPFO member seeding data
   - Bank account details (flag if two employees share bank account)
4. Verify new joiners: Appointment letter date vs. first payroll date — no salary before appointment date
5. Verify exits: Last working day vs. last payroll month — no salary after exit
6. Test salary increases: Authorisation letter/email vs. effective date in payroll
7. Verify TDS: Recompute for sample ≥30 employees across salary bands — test Form 12BB investment declarations
8. Verify HRA exemption: Rent receipts + Aadhaar/PAN of landlord if rent >[IN-083]/year
9. Verify OT computation: Overtime rate per Factories Act (2× for OT above 9hr/day) or TN S&E Act [superseded 21-Nov-2025 — re-map to Code]
10. Verify pay slips issued to all employees

---

## Red Flags — Payroll

- Employee bank account changed frequently or shared with another employee
- New joiners in payroll before appointment letter date
- Exits continue to receive salary after relieving date
- PAN missing or duplicate PAN across multiple employees
- TDS not deducted despite salary above exemption threshold
- Round-number salaries for all employees in a department (indicator of fabricated roster)
- Large unexplained variance in payroll between months (ghost additions or deletions)
- Employee's EPFO-linked mobile number / Aadhaar different from HR records
- Advance salary repaid in cash (Sec 40A(3) cash limit violation)
- Loan deductions matching round numbers with no supporting loan register
