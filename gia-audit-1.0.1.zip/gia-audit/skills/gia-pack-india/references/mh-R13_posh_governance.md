> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- POSH Act 2013 — Sexual Harassment of Women at Workplace
- Whistleblower / Vigil Mechanism (Pune Companies)
- Code of Conduct & Ethics (Pune)
- Related Party Transaction Governance (Pune)
- Data Protection — DPDPA 2023 (Pune IT Context)
- Governance Audit Procedures (Pune)
- Red Flags — POSH & Governance (Pune)


# R13 — POSH, Whistleblower & Corporate Governance (Pune)

## POSH Act 2013 — Sexual Harassment of Women at Workplace

### Applicability
Every employer with ≥10 employees — POSH Act applies.
Workplace = any place where work is done, including client sites, Pune–Mumbai travel, factory floors, and virtual/online.

> **Post-Oct 2025 MH S&E Amendment:** MH S&E registration threshold changed to ≥20 employees. However, POSH Act threshold remains ≥10 employees (Central Act — not affected by MH S&E amendment). Establishments with 10–19 employees: POSH ICC still mandatory even though they now only file S&E intimation (not full registration).

### Internal Complaints Committee (ICC) — Mandatory for ≥10 Employees

| Requirement | Detail |
|-------------|--------|
| Composition | Min 4 members: Presiding Officer (senior woman employee), ≥2 employees, 1 external member |
| Presiding Officer | Senior woman employee — not below managerial level |
| External member | NGO / social worker / person familiar with harassment issues |
| Term | 3 years (not exceeding 3 consecutive terms for each member) |
| Quorum | 3 members (including PO and external member) for each inquiry |

### Annual Report — Mandatory (Sec 21)
- ICC must submit annual report to employer AND **District Officer (Pune)** by **31 January** each year
- Report must contain: Number of complaints filed, disposed, pending, trainings conducted
- Employer must include summary in Board's Report under Companies Act 2013 Rule 8(5)(x)

### Employer Obligations (Sec 19)
| Obligation | Detail |
|-----------|--------|
| Anti-harassment policy | Written; circulated to all employees; displayed at all Pune office/factory locations |
| ICC constitution | Notified by employer; names displayed at all locations |
| Awareness training | Minimum annually; attendance records maintained |
| Safe environment | Zero tolerance; no retaliation against complainant |
| Complaints register | Maintained by ICC; confidential; not merged with HR records |
| Board report disclosure | Mandatory per Companies Act 2013 |

### Complaint & Inquiry Process
| Stage | Timeline |
|-------|---------|
| Complaint filing | Within 3 months of incident (extendable by 3 months by ICC with reasons) |
| Inquiry completion | Within 60 days of receiving complaint |
| Report to employer | Within 10 days of inquiry completion |
| Employer action | Within 60 days of receiving ICC report |
| Interim relief | ICC may recommend transfer/paid leave during inquiry |

### Penalties for Non-Compliance
- Sec 26: Fine up to [IN-134] (first offence); doubled for repeat; cancellation of business licence possible
- Criminal liability under BNS (Bharatiya Nyaya Sanhita) 2023 if conduct is criminal in nature
- Pune Labour Commissioner may conduct inspections under POSH Act

---

## Whistleblower / Vigil Mechanism (Pune Companies)

### Companies Act 2013 Sec 177(9) — Mandatory For:
- Listed companies
- Companies accepting public deposits
- Companies with Audit Committee (paid-up capital ≥[IN-115] or turnover ≥[IN-115] or borrowings ≥[IN-115])

| Requirement | Detail |
|-------------|--------|
| Vigil mechanism / whistleblower policy | Written policy; communicated to all employees |
| Direct access | To Audit Committee Chairperson for genuine concerns; no management filter |
| Protection | Protection from victimization for good-faith disclosures |
| Website disclosure | Policy must be disclosed on company website |

### Whistleblower Audit Procedures
1. Verify written vigil mechanism policy exists — check company website and intranet
2. Verify reporting channel independently accessible (email, secure portal, hotline)
3. Review complaints log maintained by AC Chairperson — any received, investigated, resolved
4. Test for retaliation: Any employee who raised concern — subsequently demoted/terminated?
5. Verify AC chairperson access is genuinely independent (not routed through HR or management)

---

## Code of Conduct & Ethics (Pune)

### SEBI LODR (Listed Pune Companies — NSE/BSE)
- Code of Conduct for Directors and Senior Management: Annual compliance declaration mandatory
- Insider Trading Policy: SEBI (PIT) Regulations 2015 — trading window closure; structured digital database (SDD) maintained
- Related party disclosures: Quarterly RPT disclosure to stock exchange

### Best Practice for All Pune Companies
| Control | Detail |
|---------|--------|
| Code of Conduct | Written; covers gifts, bribery, conflicts of interest, moonlighting, data protection |
| Gift policy | Max value ([per entity gift policy]–[per entity gift policy]); no cash gifts to/from vendors or government |
| Conflict of interest | Annual declaration all employees; vendor-ownership cross-check |
| Moonlighting policy | Explicit policy — critical for Pune IT sector (dual employment) |
| ABAC policy | Aligned to Prevention of Corruption Act 1988; for foreign-owned entities also FCPA/UK Bribery Act |
| Third-party due diligence | Vendors, agents, MIDC contractors — ABAC questionnaire before onboarding |

---

## Related Party Transaction Governance (Pune)

### Common RPT Patterns in Pune
- Auto OEM–ancillary group: Pune parent supplies to its own subsidiary or JV OEM customer
- IT GCC: Pune subsidiary provides services exclusively to foreign parent (intra-group billing)
- Pharma: Pune research entity charges IP/royalty to overseas parent or group entity
- Real estate: Pune company takes premises on lease from director's family trust

| Requirement | Sec 188 Companies Act 2013 |
|-------------|--------------------------|
| Arm's length test | All RPTs must be at arm's length |
| Board approval | Via AC recommendation first |
| Shareholder approval | If specified threshold crossed — Ordinary Resolution |
| Register MBP-4 | All RPTs recorded |
| Ind AS 24 | Related party disclosures in financial statements |

---

## Data Protection — DPDPA 2023 (Pune IT Context)

**India's Digital Personal Data Protection Act 2023:**
- Enacted; rules being finalized as of May 2026 — verify latest gazette notification
- Applies to: Processing of digital personal data of Indian residents
- **Key obligations:** Consent; purpose limitation; data minimisation; breach notification (60 days); data localization for sensitive categories
- Data Protection Board (DPB): Adjudication

**Pune IT/GCC companies — high DPDPA exposure:**
- Processing large volumes of customer and employee personal data
- Cross-border data transfer to foreign parent: Verify adequacy/sufficiency rules under DPDPA
- Employee data: Payroll, biometric, health — all require consent or legal basis
- Retention policy: How long employee records kept post-separation?

---

## Governance Audit Procedures (Pune)

1. POSH ICC: Verify constitution notification — names displayed; external member named; term not expired
2. POSH policy: Obtain current version — verify displayed at all Pune locations (office + factory)
3. POSH annual report: Verify submitted to District Officer, Pune by 31 January each year
4. POSH training: Attendance records — verify all employees covered in last 12 months
5. POSH complaints register: Maintained by ICC independently; test for any open complaints without inquiry
6. Vigil mechanism policy: On company website; complaints log with AC Chairperson
7. COI declarations: Verify all employees signed annually — cross-check against vendor ownership database
8. Moonlighting policy: Verify EPFO UAN check done for IT employees; policy signed by all employees
9. Board minutes: RPT approvals, POSH report acknowledgement, AC oversight
10. Director's Report: POSH statement, IFC statement, CSR disclosures, RPT disclosures — all included

---

## Red Flags — POSH & Governance (Pune)

- POSH ICC not constituted despite having ≥10 employees (post-Oct 2025 S&E threshold change does not affect POSH)
- External member term expired or same person on ICC for >9 years (max 3 terms × 3 years)
- POSH annual report not submitted to District Officer Pune by 31 January
- No POSH training conducted in the past 12 months
- Complaint received but no inquiry conducted within 60 days
- Vigil mechanism policy not on company website
- COI declarations not obtained annually (especially critical in Pune IT and procurement)
- Moonlighting policy absent in Pune IT company despite high dual-employment risk
- Board minutes show RPT approvals without prior AC recommendation
- Ind AS 24 disclosures absent for material related party transactions
- DPDPA 2023: No data protection officer appointed; no consent mechanism for employee data processing; no breach response plan
