> Statutory values here are pointers to statutory-register-india.md; pre-Labour-Code Act citations are flagged for re-mapping.

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-india.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules.
## Contents
- Step 0 — Evidence Baseline (Mandatory Before Any Testing)
- Step 1 — Establish Company Context (Evidence-Based)
- Step 2 — Document Inventory and Evidence Collection
- Step 3 — Web-Validate Current Regulations
- Step 4 — Execute Testing Across All Sixteen Domains
- Step 5 — Structure the Report
- Executive Summary
- Priority Matrix
- Findings by Domain [D1–D16 as applicable]
- Scope Limitations
- Regulatory & Compliance Calendar
- Next Steps [prioritized 🔴→🟢, named owner, target date]
- Sources & Regulatory Basis
- Step 6 — ICAI Standards Overlay
- Step 7 — Optional: KPI Analytics
- Non-Negotiable Evidence Rules


# /in-manufacturing-audit — Indian Manufacturing Internal Audit (v3)

**Evidence Standard:** Every finding is grounded in real, proven, actual facts obtained through
inspection of records, physical observation, external confirmation, reperformance/recalculation,
or direct observation of processes — per IIA 2024 Standard 11.1, SA 500, and SIA 10.
No finding may rest on assumption, management assertion alone, or unverified estimate.
Read the retired `audit_evidence_framework` module (not a separate file in this suite) before any fieldwork begins.

Findings structured as: **Condition → Criteria → Cause → Effect (₹ exposure, sourced) → Recommendation**.

---

## Step 0 — Evidence Baseline (Mandatory Before Any Testing)

Read: the retired `audit_evidence_framework` module (not a separate file in this suite)

Before raising any finding:
1. **Identify the assertion** being tested (existence, completeness, accuracy, valuation, cut-off, rights/obligations)
2. **Classify evidence obtained** on the reliability hierarchy (Rank 1 = external/portal; Rank 5 = management assertion only)
3. **Require corroboration** for any Rank 4–5 evidence before concluding
4. **Document the working paper** — objective, evidence source, reliability rank, procedure, result, conclusion
5. **Flag scope limitations immediately** — if evidence cannot be obtained, classify as "Evidence Not Obtained" and escalate to CAE; never substitute an assumption
6. **Prefer 100% population testing** via ERP/WMS data extract over sampling wherever data is available

If documents are not provided: produce a framework checklist only — label the output
**"FRAMEWORK ONLY — No Evidence Obtained — No Audit Opinion Expressed"**.

---

## Step 1 — Establish Company Context (Evidence-Based)

Obtain the following from verifiable sources (company registration documents, licenses, portals).
Do not accept oral-only representations for any mandatory compliance field.

| Field | Verified Source |
|-------|----------------|
| **Process type** | Factory license (Form 2) / product drawings / IATF 16949 scope certificate |
| **Alloy / material** | Material Test Certificates (MTC), BOM, supplier CoA |
| **State of operation** | Registered office address on PAN card / GST registration certificate |
| **Subcontractors** | ITC-04 portal returns / challan register / AVL register |
| **Export / EXIM regime** | EPCG / AA authorization letter / SEZ approval / ICEGATE portal |
| **Fiscal year under review** | Audited financial statements / ITR acknowledgement |
| **Listed entity?** | BSE / NSE listing status — public record |
| **Foreign parent?** | MCA21 shareholding data / FEMA FDI filing / Form FC-GPR |
| **Contract workers >20?** | CLRA registration certificate / contractor register / ECR headcount | [superseded 21-Nov-2025 — re-map to Code]
| **ERP / WMS system** | IT system inventory / network diagram (obtain from IT, not HR) |
| **IATF 16949 certified?** | IAQG OASIS database — https://iaqg.org/oasis (Rank 1 confirmation) |
| **OEM customers** | Customer-issued POs / annual purchase agreements / portal records |
| **Prior incidents** | Legal register / compliance tracker / board minutes / CARO 2020 auditor notes |

**If any field cannot be verified from documentary or portal evidence within 5 working days,
document as "Context Not Confirmed" and note the specific gap in the engagement opening memo.**

---

## Step 2 — Document Inventory and Evidence Collection

Read: the retired `document_scan_guide` module (not a separate file in this suite)

Request the following and verify each document against its source system or portal.
Mark each document received as: ✅ Obtained | ⚠️ Partial | ❌ Not Provided.

**Tier 1 — Mandatory (engagement cannot proceed without these):**
GST portal data (GSTR-1/3B/9/9C downloaded from GSTIN portal), TRACES 26AS/AIS (TDS),
EPFO ECR portal records (EPF/ESIC), audited financial statements (signed by statutory auditor),
Factories Act license (Form 2), IATF 16949 certificate (OASIS database), ERP/WMS GRN and [superseded 21-Nov-2025 — re-map to Code]
inventory reports (system-generated, not Excel re-keys).

**Tier 2 — Domain-specific:**
3CA/3CB/3CD tax audit report, Form 3CEB (transfer pricing), CPCB/SPCB CTO/CTE certificate,
CLRA registration (Form I) and contractor licenses (Form V), import BOEs / shipping bills, [superseded 21-Nov-2025 — re-map to Code]
EPCG / AA authorizations, ITC-04 returns, die/tooling register, weigh-gate scrap records,
production schedules, customer demand releases, subcontractor challan register, BOM / routing
sheets, MRP run history, APA / customer price agreements.

**Document authenticity:** Verify at least 5 documents per domain against their originating
portal or system. Do not rely solely on client-provided copies of regulatory filings.

---

## Step 3 — Web-Validate Current Regulations

Run targeted web searches before writing any finding. Cite only confirmed current-year sources.
Never cite a rate, threshold, or deadline from memory — validate every figure.

Mandatory validations:
- GST e-invoicing threshold and IRN/QR requirements → cbic.gov.in
- IGST/CGST/SGST rates by HSN → cbic-gst.gov.in/gst-goods-services-rates.html
- EPF/ESIC rates and wage ceiling → epfindia.gov.in, esic.in
- State minimum wage → relevant State Labour Department notification
- CBDT TDS rate chart, Section 43B timing → incometax.gov.in
- ICAI: current SAs, SIAs, Guidance Notes → icai.org/post/standards
- IIA 2024 GIAS update → theiia.org
- NADCA standards → diecasting.org/standards (die casting engagements)
- SAIL / JSW HRC published price → sailsteel.net / jswsteel.in (surcharge recalculation)
- LME Al / Zn / Cu prices → lme.com (die casting metal yield valuation)

Search queries (use current year):
```
GST e-invoicing threshold CBIC notification [year]
IGST rate HSN 8708 auto parts India [year]
GST scrap iron steel HSN 7204 rate RCM [year]
EPF ESIC contribution wage ceiling [year]
[State] minimum wage metal stamping [year]
CBDT TDS rate chart 194C 194Q [year]
ICAI Standards on Internal Audit SIA [year]
SAIL HRC hot rolled coil price [year]
LME aluminium price [year]
```

---

## Step 4 — Execute Testing Across All Sixteen Domains

**Evidence gate:** For each domain, apply the retired `audit_evidence_framework` module (not a separate file in this suite) before
recording any finding. Apply the retired `red_flags` module (not a separate file in this suite) to identify risk indicators.
Produce findings only for domains with sufficient evidence.

### Domain 1 — Income Tax & GST Compliance
Read: the retired `income_tax_gst` module (not a separate file in this suite) AND the retired `gst_tax_rates` module (not a separate file in this suite)

**Evidence procedures (not representations):**
- **TDS:** Export all payments from ERP → recompute TDS by section and rate → cross-check
  against TRACES 26AS (Rank 1 portal confirmation) → variance = confirmed finding with ₹ amount
- **GST ITC:** Download GSTR-2B from portal → reconcile to ITC in GSTR-3B and books →
  every excess claim quantified in ₹ with invoice-level detail
- **E-invoicing:** Spot-check minimum 30 B2B invoices → verify each IRN on IRP portal
  (https://einvoice1.gst.gov.in) — portal response is the evidence, not client's Excel
- **E-way bills:** Cross-reference GRN/dispatch register → EWB portal for each delivery note
- **Interstate vs. intrastate classification:** Verify supplier GSTIN state vs. own GSTIN state
  for each tested invoice → wrong tax type = confirmed finding (portal-verified)
- **Scrap GST:** Verify HSN on scrap invoices; recompute tax at [IN-096]; verify GSTR-1 declaration
- **RCM:** Identify GTA/advocate/overseas payments → verify RCM declared in GSTR-3B Table 3.1(d)
- **Job work ITC-04:** Download filed ITC-04 from portal → reconcile to challan register

### Domain 2 — Payroll & Labour Compliance
Read: the retired `payroll_labor` module (not a separate file in this suite)

**Evidence procedures:**
- **EPF/ESIC:** Download ECR from EPFO portal (Rank 1) → recompute [IN-001]+[IN-120] on eligible wages
  → compare headcount ECR vs. payroll register → variance = confirmed finding
- **Minimum wage:** Obtain current state notification → recompute for applicable wage category
  → compare to actual wages paid (payroll extract) — every shortfall identified by employee
- **Factories Act OT:** Extract payroll overtime log → verify OT rate = 2× normal rate; [superseded 21-Nov-2025 — re-map to Code]
  OT hours ≤50/quarter per employee — flag individual violations

### Domain 3 — Customs, EXIM & FEMA
Read: the retired `customs_exim` module (not a separate file in this suite)

**Evidence procedures:**
- **EPCG:** Download EPCG license from DGFT portal; obtain shipping bills from ICEGATE → recompute
  export obligation fulfilled (6× CIF) and balance outstanding — reperformance, not estimate
- **AA SION:** Obtain SION from DGFT notification → compare to actual import quantities (BOE
  from ICEGATE) → over-import = finding with ₹ customs duty exposure computed
- **FEMA:** Obtain RBI/AD bank filings (ECB-2, FC-GPR, FLA return) → verify filing dates vs.
  prescribed deadlines → each late filing = confirmed finding with penalty exposure per FEMA

### Domain 4 — Financial Reporting (Ind AS / ICAI)
Read: the retired `ind_as_accounting` module (not a separate file in this suite) AND the retired `icai_standards` module (not a separate file in this suite)

**Evidence procedures:**
- **Inventory valuation (Ind AS 2):** Attend physical count (SA 501) → test-count independently
  → verify NRV = LME/market price (obtained from portal/published index) > cost
- **PPE / tooling (Ind AS 16):** Physically verify sample of assets → verify remaining useful life
  vs. Schedule II → recompute depreciation → impairment test (Ind AS 36) for dormant dies
- **Gratuity (Ind AS 19):** Obtain actuarial valuation report → verify actuary is ICAI-recognised
  → verify assumptions (mortality, discount rate) against INDA published yield curves
- **Revenue (Ind AS 115):** Obtain delivery terms from APA/supply agreement → verify GRN/POD
  dates vs. invoice dates → any invoice raised before delivery = early recognition finding

### Domain 5 — Environmental Compliance
Read: the retired `environmental` module (not a separate file in this suite)

**Evidence procedures:**
- Obtain CTO/CTE from SPCB (or verify on state SPCB portal where available)
- Verify hazardous waste manifests for dross/flux — each dispatch must have Form 10
- Verify authorized recycler's SPCB licence number — cross-check licence currency on SPCB portal
- Verify Form V (annual environmental statement) filed date vs. prescribed date

### Domain 6 — Workplace Safety
Read: the retired `safety_factories_act` module (not a separate file in this suite)

**Evidence procedures:**
- Verify Factories Act licence (Form 2) — physical original + expiry date [superseded 21-Nov-2025 — re-map to Code]
- Verify statutory Form 21 annual return — acknowledge receipt from Inspector of Factories
- Witness / inspect PPE stock vs. headcount → shortfall = finding with headcount × PPE unit cost
- Verify IS 7084 press safety compliance (die casting: splash shields, PPE aluminized aprons)
  through physical inspection, not management assurance

### Domain 7 — Internal Controls & Anti-Fraud
Read: the retired `internal_controls` module (not a separate file in this suite)

**Evidence procedures — 100% population analytics (no sampling):**
- Extract all cash payments from ERP → pivot by payee + date → flag Section 40A(3) violations
- Extract all general ledger journal entries → filter: management-posted, off-cycle, round-number
  → verify each against source documents — no explanation from management accepted without paper
- Extract all scrap sale invoices → digit-distribution test via `gia-fraud:gia-fraud-analytics` → compare price per kg vs.
  LME/published rate → uninvoiced weigh-gate dispatches = confirmed fraud risk indicator
- Vendor-employee PAN match: extract vendor master PANs → match against employee PAN list
  → any match = Rank 1 confirmation of COI → escalate immediately

### Domain 8 — Enterprise Risk Management
Read: the retired `erm_risk_management` module (not a separate file in this suite)

**Evidence procedures:**
- Obtain risk register → verify each risk has named owner, rating date, and KRI metric
- Obtain board/audit committee minutes → verify risk register tabled and discussed
- Verify KRI data is system-generated (not management-prepared Excel) where possible

### Domain 9 — Contract Labour (CLRA)
Read: the retired `contract_labour` module (not a separate file in this suite)

**Evidence procedures:**
- Verify CLRA Form I registration certificate — physical document; check validity period [superseded 21-Nov-2025 — re-map to Code]
- Download contractor EPF ECR from EPFO portal (Rank 1) — do not rely on contractor's statement
- Verify welfare facilities (canteen, first aid) through physical inspection during site visit

### Domain 10 — Operational Quality (IATF 16949)
Read: the retired `operational_quality` module (not a separate file in this suite)

**Evidence procedures:**
- Verify IATF 16949 certificate on IAQG OASIS database (https://iaqg.org/oasis) — Rank 1
- Verify PPAP approval from customer portal (e.g., MSIL SWAS) — not internal copy only
- Witness SPC chart update at production cell — verify real-time data, not retroactive
- Verify OEE from machine controller data — not manually entered spreadsheet

### Domain 11 — Ethics, ABAC & Anti-Corruption
Read: the retired `ethics_antibribery` module (not a separate file in this suite)

**Always assess — not optional. Evidence procedures:**
- Obtain gift register → verify signatories and thresholds match ABAC policy
- Verify vigil mechanism hotline is operational — test by calling the number
- Obtain COI declaration register → verify all procurement-facing employees signed
- For government official interactions: obtain register + verify approvals per policy
- Any investigation: obtain full evidence chain — no conclusions from verbal briefings

### Domain 12 — Die Casting Process
Read: the retired `diecast_audit` module (not a separate file in this suite)

**Evidence procedures:**
- Obtain heat-by-heat spectrometer log → verify against ASTM/IS spec for every heat in period
- Witness furnace temperature check or review calibrated thermocouple log — not verbal assertion
- Read shot counter from machine controller directly (photo evidence) vs. die master register
- Recompute metal yield: (accepted parts × drawing weight + authorized scrap weight) / ingot in
  → verify ingot in from delivery records and GRNs (Rank 3) — not from production estimate
- Verify dross manifests (Form 10) → match to each dross dispatch on weigh-gate log

### Domain 13 — Subcontractor Management
Read: the retired `subcontractor_audit` module (not a separate file in this suite)

**Evidence procedures:**
- Download ITC-04 from GST portal (Rank 1) → reconcile to challan register
- Obtain confirmation of material balance from job worker in writing (SA 505 format)
- Verify AVL re-qualification record → physical supplier audit report signed by quality head
- Verify TDS Section 194C via TRACES 26AS (Rank 1) — recompute on payment extract

### Domain 14 — Sales, Production Forecast & Planning
Read: the retired `sales_production_planning` module (not a separate file in this suite)

**Evidence procedures:**
- Download customer demand releases from OEM portal directly (Rank 1) → reconcile to ERP
- Recompute steel surcharge entitlement: SAIL/JSW published HRC index × APA formula → compare
  to invoiced amounts → revenue leakage = (entitlement – invoiced) × volume, ₹ quantified
- Obtain OEM OTIF scorecard from customer portal → do not use client's self-prepared scorecard
- Verify Ind AS 115 cut-off: delivery confirmation (POD/E-way bill portal) vs. invoice date

### Domain 15 — Warehouse Operations
Read: the retired `warehouse_operations` module (not a separate file in this suite)

**Evidence procedures:**
- Attend physical inventory count (SA 501) → perform blind test counts → document on count
  sheet co-signed by auditor and store manager
- Obtain WMS system access control report from IT department (Rank 2) → verify SoD
- Pull ERP GRN exception report: GRNs without PO, GRNs before IQC date, backdated GRNs →
  each exception is a confirmed finding — no management explanation accepted without paper
- Verify e-way bill for a sample of FG dispatches via e-way bill portal (Rank 1)

### Domain 16 — Material Balance & Scrap Reconciliation
Read: the retired `material_balance_scrap` module (not a separate file in this suite)

**Evidence procedures — all from source documents, no estimates:**
- **Opening stock:** Confirmed prior-period closing physical count or audited trial balance
- **Receipts:** GRN register (Tier 1) × verified weights from weigh-bridge slips (witnessed)
- **Good output:** Accepted finished goods QC pass records × drawing weight per part (BOM)
- **Authorized scrap:** Category-wise scrap register co-signed by production supervisor
- **Weigh-gate dispatches:** Weigh-gate log (signed, timestamped) — every line
- **Scrap invoices:** Tax invoices with IRN from IRP portal → match to weigh-gate log 1:1
- **Closing stock:** Physical count (SA 501) or perpetual inventory confirmed by cycle count
- **Compute MTC** from these verified inputs — any shortfall below benchmark = confirmed finding
  with ₹ exposure = unexplained loss (kg) × LME/market rate (portal-sourced)
- **Digit-distribution test** on 100% of scrap weight data via `gia-fraud:gia-fraud-analytics` (preconditions apply: weights recorded by a scale are often not suitable); an indicator is referred to Domain 7/11

---

## Step 5 — Structure the Report

```
# [COMPANY] — Internal Audit Report
### [Stamping / Die Casting / Both] | Period: [dates] | Prepared: [date]
### IIA 2024 GIAS | ICAI SA/SIA | Evidence-Based: Real, Proven, Actual Facts Only
### All findings supported by working papers — no assumptions, no estimates without source

> [IF DOCUMENTS NOT PROVIDED: "FRAMEWORK ONLY — No Evidence Obtained — No Audit Opinion Expressed"]

## Executive Summary
[3–5 sentences: overall risk rating, top 3 findings with ₹ exposure, immediate actions,
evidence base (list key Rank 1 confirmations obtained)]

## Priority Matrix
[🔴 Critical | 🟠 High | 🟡 Medium | 🟢 Low]
[Domain | Finding | Assertion Tested | Evidence Type | ₹ Exposure]

## Findings by Domain [D1–D16 as applicable]
Each finding must contain:
  Condition:       [What was found — state the fact, not an inference]
  Criteria:        [Act / Section / Standard / year — exact citation]
  Evidence:        [How confirmed — document type, portal verified, reperformance, observation]
  Reliability:     [Evidence Rank 1–5 per audit_evidence_framework.md]
  Cause:           [Root cause — substantiated by evidence]
  Effect:          [₹ exposure — computed from verified data with formula shown; or
                   "Unquantified — evidence insufficient to compute exposure" if data unavailable]
  Recommendation: [Specific, actionable, time-bound]
  Owner:           [Named individual]
  Target Date:     [Specific date]

## Scope Limitations
[Any domain where "Evidence Not Obtained" — what was requested, what was received, impact]

## Regulatory & Compliance Calendar
[Upcoming filing deadlines: ITR, GSTR-9/9C, ITC-04, EPF/ESIC, EPCG, Factory return, IATF]

## Next Steps [prioritized 🔴→🟢, named owner, target date]

## Sources & Regulatory Basis
[All Acts, Sections, Ind AS, ICAI SAs, SIAs, Guidance Notes, IIA Standards, BIS/IATF,
NADCA standards cited with section and year; all portal URLs used for verification]
```

---

## Step 6 — ICAI Standards Overlay

Read: the retired `icai_standards` module (not a separate file in this suite)

Apply per procedure: SA 200 (professional skepticism), SA 240 (fraud — always), SA 500
(evidence sufficiency), SA 501 (inventory observation), SA 505 (external confirmations),
SA 530 (sampling — only when analytics impossible), SA 540 (estimates — actuarial, impairment),
SIA 1/3/4/7/10/11 (always applicable), ICAI GNs on Inventories / Manufacturing / GST Audit.

---

## Step 7 — Optional: KPI Analytics

Read: the retired `analyze_skill_template` module (not a separate file in this suite)

KPIs sourced from verified system data only: OEE (machine controller), scrap rate by cell
(production log), MTC % (weigh-gate + GRN), GST ITC utilization (portal), EPF/ESIC ratio
(EPFO portal), TDS default rate (TRACES), OTIF (OEM portal), Cpk (SPC system), BOM yield
variance ₹ (ERP), SLOB % (WMS age report), cycle count accuracy (WMS), demand MAPE (ERP).

---

## Non-Negotiable Evidence Rules

1. **No finding on assumption.** If the fact cannot be verified from a document, portal,
   reperformance, physical observation, or external confirmation — it is not a finding.
   It is a "Scope Limitation: Evidence Not Obtained."

2. **No estimate without source.** Every ₹ figure in a finding must show its formula and
   the source data used (ERP line, portal reference, published index). If the source data
   is unavailable, state "Unquantified — [state reason]."

3. **No management representation alone.** Management statements may initiate an enquiry
   but cannot close a finding. A finding is confirmed or cleared by Rank 1–3 evidence.

4. **No verbal confirmation.** Every confirmation must be in writing — email, portal screenshot,
   signed document, or SA 505 written confirmation. Verbal confirmations are noted and then
   verified by independent means before reliance.

5. **Contradict, don't assume.** Where evidence contradicts management representation,
   the evidence is correct. State the contradiction explicitly in the finding.

6. **Cite Act/Section/year** for every compliance finding — no generic citations.

7. **Cite ICAI SA or SIA number** for every audit procedure performed.

8. **Cite IIA 2024 Standard** for all audit process and reporting observations.

9. **100% population preferred.** Apply data analytics to the full population wherever
   ERP/WMS data is extractable. Document sampling basis only when analytics unavailable.

10. **Disclaimer:** This is a professional internal audit report, not a statutory or legal opinion.
    Findings must be reviewed by a licensed CA, CS, or advocate before regulatory action.
    ICAI SA citations are for best-practice guidance — statutory audit mandates are separate.
