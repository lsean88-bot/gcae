---
name: gia-pack-malaysia
description: "Malaysia audit, MKPC, Erawan, Nephrocare: die casting, LMW gas cylinders, dialysis clinics, Employment Act, EPF, SOCSO, EIS, minimum wage, SST, e-invoice, MACC s.17A. Use when auditing a Malaysian entity; holds the dated Malaysia register. Do NOT use for India (use gia-audit:gia-pack-india), Mexico (use gia-audit:gia-pack-mexico) or RACM (use gia-audit:gia-racm-icfr-testing)."
---

# Malaysia pack

Statutory values are held only in `references/statutory-register-malaysia.md`. A row marked `[UNVERIFIED]` or `CONFLICT` cannot support a finding. The minimum-wage effective date and the privacy statute name are known conflicts (rows MY-C7 and MY-C8); resolve them through agent `statutory-validator` before use.

## Before any procedure
1. Entity and site. Confirm the entity (MKPC, Erawan, Nephrocare, other), state, sector, headcount, audit period. Unsupplied facts become open dependencies; do not assume them. If a site is in Sabah or Sarawak, the Employment Act does not apply as written; record a scope limitation.
2. Pick the module(s). A combined request (for example dialysis plus HR) loads both references together.
3. Grade evidence R1 to R5 per `gia-core:iron-rules`. The bracket tags in the module files are source-type labels.
4. Digit tests go through `gia-fraud:gia-fraud-analytics` (MAD primary); bounded or fixed-amount populations are not suitable for a first-digit test.
5. Report format: `gia-report-qa:gia-ia-report`. Modules emit a findings register; their long-form report layouts are not used.

## Module router
| Entity or topic | File |
|---|---|
| Die casting and stamping, general | `mfg-diecast-stamping.md`, `mfg-R15-compliance-calendar.md` |
| MKPC overlay (OEM customers, IATF, SST, metal yield, OEM billing) | `mkpc-overlay.md`, `mkpc-iatf_quality.md`, `mkpc-metal_yield_scrap.md`, `mkpc-oem_billing_collection.md`, `mkpc-sst_compliance.md`, `mkpc-employment_payroll.md`, `mkpc-benchmarks.md` |
| Gas cylinder under LMW | `lmw-gas-cylinder.md`, `lmw-lmw_customs.md`, `lmw-dosh_gas_cylinder.md`, `lmw-gas_customer_billing.md`, `lmw-cylinder_inventory_cogs.md`, `lmw-employment_payroll.md`, `lmw-benchmarks.md` |
| Dialysis (canonical) | `healthcare-dialysis.md` and `dialysis-*.md` (licensing, PPT agreement, expansion governance, revenue cycle, inventory, payroll, fraud, tax, KPIs, compliance calendar) |
| Dialysis clinical overlap | `healthcare-dialysis-clinical-overlap.md` (nurse ratio, water standards, combined clinic and dialysis) |
| Nephrocare finance and risk | `nmsb-finance.md` |
| Nephrocare operations and consumables | `nmsb-ops.md` |
| Private clinic | `healthcare-clinic.md` and `clinic-*.md` (A to M) |
| HR and payroll law | `hr.md`, `hr-law-register.md`, `hr-rcm.md`, `hr-pbc-template.md`, `hr-fraud-schemes.md`, `hr-entities.md` |

## Rules specific to Malaysia
- The law register inside `hr-law-register.md` is a source table; the authoritative dated values are in the statutory register.
- Do not impose a single fixed minimum wage figure as an instruction; take the minimum wage value and effective date by employer size from the register after validation.
- Healthcare clinical benchmarks (for example Kt/V, reuse ratio, nurse ratio) are practice benchmarks, not statutes; label them as benchmarks.
- Variance value in a stock take is unit price times the difference, never unit price times the physical count (finance module).
- The clinic reference files still hold figures from one prior engagement (flagged at the top of each); do not carry them forward.

## Open items
Entity-to-state mapping, an India-equivalent dialysis mapping and the generalisation of the clinic files are open. Which Malaysian entity each engagement covers must be supplied.
