> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- Step 0 — Evidence Standard (Read First — Non-Negotiable)
- Step 1 — Establish Company Context
- Step 2 — Document Scan (if files provided)
- Step 3 — Web-Validate Current Regulations
- Step 4 — Execute Audit Tests Across All Seventeen Domains
- Step 5 — Report structure
- Validation Standards — Non-Negotiable


# /my-hc-dialysis-audit — Malaysian Healthcare & Kidney Dialysis Internal Audit

Conduct a rigorous, evidence-based internal audit of a Malaysian private kidney dialysis operating
company with multiple haemodialysis centres and active annual expansion. Output follows
**2024 IIA Global Internal Audit Standards (GIAS)** (effective 9 January 2025).

**Zero assumptions. Zero unverified claims. All findings require sufficient appropriate audit evidence.**

Finding structure: **Condition → Criteria → Cause → Effect → Recommendation**
Each finding additionally states: **Evidence Basis** and **Assertion(s) Tested**

---

## Step 0 — Evidence Standard (Read First — Non-Negotiable)

Evidence type tags used throughout this skill:

| Tag | Type | Reliability |
|-----|------|------------|
| `[CON]` | Confirmations / independent portal extracts | Highest |
| `[PHY]` | Physical observation / count | High |
| `[INS]` | Inspection of documents | Medium-High |
| `[REC]` | Recalculation / reperformance | High (mathematical) |
| `[ANA]` | Analytical procedures / Benford | Medium |
| `[REP]` | Management reports | Medium |
| `[OBS]` | Observation of process | Medium |
| `[INQ]` | Inquiry | Lowest — never stand-alone |

**Operational rules — apply to every test:**
1. `[INQ]` alone is never sufficient — always corroborate with a second evidence type
2. Every 🔴 Critical finding requires at least one `[CON]` or `[PHY]` evidence item
3. All monetary findings must be quantified in MYR (Ringgit Malaysia)
4. "Cannot be verified" is a valid finding — document what was requested and unavailable
5. Treatment-count findings must be reconciled: machine log → purchase orders → invoices → collections

---

## Step 1 — Establish Company Context

Collect or confirm before auditing:

| Field | Why It Matters |
|-------|---------------|
| **Total centres operating** | Scope of licence, CKAPS, PERKESO contracts |
| **Centres under expansion (current year)** | CKAPS pre-approval, capex commitment, MFRS 16 |
| **PPT agreement(s) in force** | FMC contract number, machine count, PPT rate, commitment |
| **PERKESO-contracted centres vs private** | Billing model, tariff cap, collection risk |
| **Patient census per centre** | Chair utilisation, revenue per chair, clinical risk |
| **Nephrologist staffing model** | Employed vs sessional, ratio to chairs/patients |
| **Cash vs cashless payment split** | Cash-diversion risk, reconciliation controls |
| **ERP / billing system used** | Evidence availability — ClinicMaster, HIS, custom |
| **Ownership and guarantor structure** | MACC s.17A exposure, related-party transactions |
| **Financial year under review** | MFRS version, SST, Minimum Wages Order effective date |
| **Prior MOH or CKAPS inspection findings** | Elevates clinical governance domains |
| **Lease structure for all premises** | MFRS 16 right-of-use, CKAPS building compliance |

---

## Step 2 — Document Scan (if files provided)

Read the retired `document_scan_guide` module (not a separate file in this suite). Key documents and evidence tags:

| Document | Evidence Tag | Notes |
|----------|-------------|-------|
| CKAPS operating licences — all centres | `[CON]` verify on MOH eSPKKS portal | Licence per centre, per specialist |
| PPT Agreement (FMC) | `[INS]` contract + `[REC]` commitment reconciliation | Both PPT 2025/112 and PPT 2026/114 |
| Monthly purchase orders — consumables | `[INS]` PO + GRN + invoice + payment | 3-way match for all consumable purchases |
| Treatment count logs (machine-level) | `[INS]` machine session logs vs PO quantity | Core anti-fraud test |
| PERKESO billing submissions and claim receipts | `[CON]` PERKESO portal extract vs billing records | Full population preferred |
| Patient billing ledger — private / others | `[INS]` billing system export | Trace to collections |
| Bank statements — all accounts | `[CON]` bank confirmation or portal extract | Reconcile to cash receipts |
| EPF / SOCSO / EIS contribution schedules | `[CON]` portal extract — KWSP i-Akaun / PERKESO portal | Full population |
| PCB / MTD returns | `[CON]` LHDN e-PCB system extract | Per payroll period |
| SST returns | `[CON]` MySST portal extract | Note: healthcare services SST-exempt per First Schedule |
| Tenancy / lease agreements — all premises | `[INS]` signed agreements | MFRS 16 lease term and rent |
| CKAPS expansion pre-approval letters | `[INS]` MOH correspondence | Tied to capex and MFRS 16 |
| Dialyser reuse records | `[INS]` machine log / reuse tags | Validate 9-reuse + 1 first-use cap |
| Actuarial report — employee benefits | `[INS]` actuarial report | MFRS 119 compliance |

If no documents: label report **"FRAMEWORK ONLY — No Documents Reviewed — No Line-Item Findings."**

---

## Step 3 — Web-Validate Current Regulations

Always search before writing. Use `[CON]` — obtained from independent regulatory portals:

- **MOH CKAPS / eSPKKS:** `sppkk.moh.gov.my` — operating licences, specialist registration, building approvals
- **Companies Commission (SSM):** `mycoid.ssm.com.my` — company search, director/shareholder verification
- **Inland Revenue Board (LHDN):** `mytax.hasil.gov.my` — tax status, PCB, e-BE, RPGT
- **EPF (KWSP):** `kwsp.gov.my` — contribution rates (employer [MY-005]; employee [MY-004])
- **SOCSO (PERKESO):** `perkeso.gov.my` — contribution ceiling, injury fund, invalidity scheme
- **EIS (SIP):** `eismy.perkeso.gov.my` — Employment Insurance System contribution table
- **Minimum Wages Order 2024:** `jtksm.mohr.gov.my` — national minimum wage [MY-003]; verify all staff at or above the threshold
- **MACC:** `macc.gov.my` — s.17A guidelines, adequate procedures 6 pillars
- **PDPA / JPDP:** `pdp.gov.my` — breach notification ≤ 72 hours; DPO appointment thresholds
- **PERKESO dialysis tariff:** `perkeso.gov.my` — current approved dialysis rate per session
- **MOH ESRD statistics:** `crc.gov.my` / `msds.moh.gov.my` — national benchmark, centre-level data
- **Bank Negara Malaysia (BNM):** `bnm.gov.my` — AML/CFT guidelines, wire transfer reporting
- **SST MySST:** `mysst.customs.gov.my` — healthcare exemption status under Service Tax (Note: private healthcare services are SST-exempt; verify consumable imports SST)
- **BURSA / SC (if listed parent):** `bursamalaysia.com` — related-party transaction rules

---

## Step 4 — Execute Audit Tests Across All Seventeen Domains

For every test: state the assertion → obtain evidence → quantify finding → write condition.

### Domain 1 — MOH / CKAPS Regulatory Compliance

**Read: `references/dialysis-ckaps_licensing.md`**

| Test | Evidence | Assertion |
|------|---------|-----------|
| Operating licence current for each centre | `[CON]` eSPKKS portal — licence number, expiry, centre address match | EX, CP |
| Specialist (nephrologist) registration on licence | `[CON]` MMC registration number + CKAPS specialist approval | CP |
| Nurse-to-machine / nurse-to-patient ratio compliance | `[INS]` staff rota + `[OBS]` site visit; MOH guideline: 1 trained nurse per 4 machines | CP |
| Nephrologist-to-chair ratio (minimum 1 per 20 chairs) | `[REC]` total chairs ÷ registered nephrologists per centre; cross-reference CKAPS licence | AC, CP |
| Annual licence renewal submitted timely | `[INS]` renewal acknowledgement letter vs licence expiry date | CP |
| CKAPS pre-approval obtained before each new centre opening | `[INS]` approval letters vs actual centre opening date | CP |
| Building / premise compliance for each dialysis centre | `[INS]` CKAPS approval letter specifying floor area, chair count, isolation room, water treatment room | CP |
| RO water quality test certificates (every 6 months) | `[INS]` test certificates; cross-reference AAMI/ISO 23500 standards referenced in MOH guidelines | CO, CP |
| Medical waste management licence (Kualiti Alam / DOE) | `[CON]` DOE permit + scheduled waste manifest | CP |
| Adverse event / near-miss reporting to MOH | `[INS]` adverse event register vs MOH notification acknowledgements | CO, CP |

**Key criteria:** Private Healthcare Facilities and Services Act 1998 (PHFSA); Private Healthcare Facilities and Services (Private Hospitals and Other Private Healthcare Facilities) Regulations 2006; MOH Haemodialysis Centre Guidelines (current edition); Medical Act 1971 (specialist registration)

---

### Domain 2 — PPT Agreement Compliance & Treatment Commitment Tracking

**Read: `references/dialysis-ppt_agreement_audit.md`**

Context: Nephrocare operates two PPT agreements with FMC:
- **PPT 2025/112** (84 machines, 7 existing PERKESO centres, PPT rate RM 56.00/treatment, Total Contract Commitment: 411,264 treatments, machine commitment 4,896/machine, Final Installation Date: 31 Dec 2026)
- **PPT 2026/114** (34 machines, 12 existing centres, PPT rate RM 42.75/treatment, Total Contract Commitment: 411,264 treatments, machine commitment 12,096/machine, 7-year commitment)
- Combined obligation: 250 machines within 2.5 years of PPT 2025/112 signing date

| Test | Evidence | Assertion |
|------|---------|-----------|
| Monthly treatment count vs Monthly Treatment Commitment per machine | `[REC]` actual PO treatments ÷ 84 machines (PPT 112) and 34 machines (PPT 114) vs schedule | AC, CO |
| Annual treatment count vs Annual Treatment Commitment | `[REC]` cumulative PO per contract year vs Schedule IV target | AC, CP |
| Total machine count vs 250-machine commitment (deadline 30 Jun 2028 approx.) | `[INS]` PPT 112 + PPT 114 machine counts + any direct-purchase records | CO, CP |
| PPT rate applied in invoices — RM 56.00 (PPT 112) and RM 42.75 (PPT 114) | `[INS]` FMC invoices vs Schedule IV PPT rate | AC, VA |
| FX adjustment assessed at 6-month intervals (baseline EUR/MYR 4.98; 6.5% threshold) | `[REC]` Fxtop.com 6-month average vs 4.98 baseline; confirm amendment signed if >6.5% | AC, CP |
| Payment within 60 days of invoice | `[INS]` invoice date vs payment date from bank statement | CP |
| Late payment interest calculated at 1%/month on overdue balances | `[REC]` overdue days × outstanding balance × 1%/month | VA, AC |
| Machine installation timeline compliance (60-day first unit; Final Installation Date) | `[INS]` Schedule III installation dates vs agreement signing date | CP |
| Personal guarantee executed by the director guarantors | `[INS]` signed guarantee documents | CO, CP |
| Contract Residual Value (CRV) exposure calculated if termination scenario arises | `[REC]` CRV = PPT rate × remaining treatments × 1.25 | VA |
| Purchase orders specify correct PPT contract number | `[INS]` PO documents vs Clause 6.3 requirement | CP |
| Quarterly treatment reports submitted to FMC | `[INS]` submission records + GRNs | CP |
| Dialyser reuse rate: 9 reuses + 1 first use (consumption rate validation) | `[REC]` dialysers consumed ÷ treatments; theoretical 1 dialyser per 10 treatments | AC, CO |
| Citrosteril usage rate: 1 canister / 150 treatments | `[REC]` Citrosteril units consumed vs treatments performed | AC |
| Diasafe filter: 1 per 100 treatments | `[REC]` Diasafe units consumed vs treatments performed | AC |
| Concentrate Part A: 1 canister / 3 treatments | `[REC]` concentrates consumed vs treatments performed | AC |
| Bibag: 1 per treatment | `[REC]` bibag units consumed vs treatments performed | AC |
| Bloodline: 1 per treatment | `[REC]` bloodline units consumed vs treatments performed | AC |
| AVF needles: 2 per treatment | `[REC]` AVF units consumed vs (treatments × 2) | AC |
| Dressing set: 1 per treatment | `[REC]` dressing set units consumed vs treatments | AC |
| Equipment not relocated without FMC written approval | `[INS]` machine asset register vs premises; `[OBS]` site verification | CP |
| Consumables not destroyed without FMC written authorisation | `[INS]` destruction records vs FMC approval | CP |
| Adverse event / product complaint forms filed within 5 Working Days | `[INS]` complaint register vs date logged | CP |

**Key criteria:** PPT 2025/112 Clauses 2.4–2.8, 4.1–4.9, 6.3, 12.8; PPT 2026/114 same; Schedule IV consumption ratios

---

### Domain 3 — Revenue Cycle: Billing, Collection & Cash Controls

**Read: `references/dialysis-revenue_cycle.md`**

| Test | Evidence | Assertion |
|------|---------|-----------|
| PERKESO panel billing — all claims submitted vs eligible treatments | `[CON]` PERKESO portal claim extract vs billing system | EX, CO |
| PERKESO claim approval rate and rejection analysis | `[CON]` PERKESO portal — approved, rejected, pending | AC |
| PERKESO tariff applied correctly per approved rate | `[REC]` billing rate per session vs current PERKESO approved tariff | AC, VA |
| Private-pay billing completeness — all treatments billed | `[REC]` machine treatment log vs billing records | EX, CO |
| Cash receipts reconciled to billing ledger daily | `[INS]` daily cash book vs billing system | AC, CP |
| Official receipt issued for every cash payment | `[INS]` official receipt sequence — no gaps | CO, CP |
| Bank deposit matches daily cash collected | `[INS]` daily cash collection report vs bank credit | AC, CO |
| Debtor aging — PERKESO receivables vs non-PERKESO | `[INS]` AR aging report by payer class | VA, CP |
| Bad debt provision methodology — MFRS 9 expected credit loss | `[REC]` ECL calculation; `[INS]` provision schedule | VA, AC |
| Third-party insurance / TPA billing — tariff vs contracted rate | `[INS]` TPA panel agreements vs billing records | AC, VA |
| Revenue per chair per month by centre — benchmark vs industry | `[ANA]` revenue ÷ installed chairs; benchmark RM 6,000–RM 12,000/chair/month (MSDS-based) | AC |
| Refund / credit notes — approval authority and supporting documentation | `[INS]` credit note log vs approval sign-off | CP, EX |
| Segregation of duties: billing ≠ collection ≠ posting | `[INS]` access rights report + `[OBS]` workflow | CP |

---

### Domain 4 — PERKESO Contract Centres: Specific Audit Requirements

**Read: the retired `perkeso_centres` module (not a separate file in this suite)**

| Test | Evidence | Assertion |
|------|---------|-----------|
| PERKESO panel agreement current and covers all sessions billed | `[INS]` panel agreement + `[CON]` PERKESO portal status | CO, CP |
| Patient eligibility verified before treatment (PERKESO active member) | `[INS]` PERKESO eligibility check log per patient | CP |
| Treatment frequency per patient within PERKESO approved sessions | `[REC]` patient session log vs PERKESO approved frequency (3×/week) | AC, CP |
| PERKESO billing submitted within stipulated timeframe | `[INS]` submission date vs PERKESO deadline | CP |
| No dual-billing (PERKESO + private) for same session | `[ANA]` cross-match patient ID on PERKESO claims vs private billing | EX, CP |
| PERKESO capitation or fee-for-service — verify payment reconciliation | `[CON]` PERKESO remittance vs AR ledger | AC, CO |
| Ancillary charges billed to PERKESO within approved scope | `[INS]` PERKESO approved service list vs line items billed | CP, AC |
| Patient medical records support each billed treatment | `[INS]` sample of 25 patient records vs billing | CO, CP |
| PERKESO audit response — prior queries resolved | `[INS]` PERKESO audit correspondence + management responses | CP |

---

### Domain 5 — Consumable Inventory, COGS & Treatment Cost Reconciliation

**Read: `references/dialysis-inventory_cogs.md`**

| Test | Evidence | Assertion |
|------|---------|-----------|
| Opening stock + purchases − COGS = closing stock (per consumable line) | `[REC]` monthly inventory reconciliation — full population | EX, CO, AC |
| COGS per treatment by consumable — actual vs theoretical (Schedule IV ratios) | `[REC]` consumables used ÷ actual treatments performed | AC |
| Dialyser reuse register — per machine, per patient | `[INS]` reuse tags / machine log; max 9 reuses | CO, CP |
| Consumables not purchased from non-FMC sources without approval | `[INS]` supplier list vs FMC authorisation | CP |
| Physical count of consumables at each centre | `[PHY]` count at ≥3 centres; agree to system | EX, AC |
| FIFO applied for consumable issuance (expiry date management) | `[INS]` GRN date vs issuance date by batch | CP, AC |
| Near-expiry and expired stock written off with proper approval | `[INS]` write-off records vs approval | VA, CP |
| Consumable diversion risk: actual usage vs theoretical | `[REC]` if actual < theoretical — investigate; if actual > theoretical — overstatement risk | AC, EX |
| GRN signed by authorised receiver on delivery | `[INS]` GRN documents vs Clause 6.4 FMC reconciliation | CO, CP |
| FMC monthly delivery reconciliation performed | `[INS]` FMC reconciliation report vs CUSTOMER GRNs | CO, AC |
| COGS to revenue ratio by centre — trend analysis | `[ANA]` COGS ÷ revenue per centre per month; flag >35% variance | AC |
| Inventory valuation method — weighted average or FIFO — MFRS 102 | `[INS]` accounting policy + `[REC]` valuation consistency | VA, CP |

---

### Domain 6 — Clinical Governance & Patient Safety

**Read: the retired `clinical_governance` module (not a separate file in this suite)**

| Test | Evidence | Assertion |
|------|---------|-----------|
| Kt/V (dialysis adequacy) ≥ 1.2 — per patient per quarter | `[INS]` patient lab results vs MOH / KDOQI benchmark | CO, AC |
| Haemoglobin (Hb) target 10–12 g/dL — % patients achieving | `[ANA]` patient registry extract vs CMS ESRD QIP benchmark | AC |
| Calcium × Phosphate product ≤ 55 mg²/dL² | `[INS]` patient biochemistry records | AC |
| Hepatitis B vaccination record for all patients | `[INS]` vaccination register vs patient list | CO, CP |
| Hepatitis B/C screening frequency (every 6 months) | `[INS]` lab results vs MOH screening guideline | CP |
| Vascular access audit — AVF preferred (≥65% per KDOQI) | `[ANA]` patient vascular access type from registry | AC |
| Machine disinfection log — Citrosteril per schedule | `[INS]` machine maintenance log per IFU/FMC requirement | CO, CP |
| Diasafe filter replacement per machine notification | `[INS]` filter replacement record vs machine alert log | CP |
| Incident and adverse event register — complete and reported | `[INS]` incident register vs MOH reporting requirements | CO, CP |
| Patient informed consent on file | `[INS]` sample of 20 patient files — consent form present | CO, CP |
| Doctor's prescription / standing order for each patient | `[INS]` sample of 20 patient files | CO, CP |
| Nurse qualification register — dialysis-trained | `[INS]` nurse qualification certificates vs MOH requirement | CP |

---

### Domain 7 — Expansion Governance & CKAPS Pre-Approval

**Read: `references/dialysis-expansion_governance.md`**

Context: 6 new centres per year; each requires CKAPS building approval, premises tenancy, RO water system, machine installation, licence application, and nephrologist engagement.

| Test | Evidence | Assertion |
|------|---------|-----------|
| CKAPS pre-approval obtained before lease signed / capex committed | `[INS]` approval letter date vs lease date vs capex PO date | CP |
| Operating licence application submitted ≥ 3 months before planned opening | `[INS]` submission records vs planned opening date | CP |
| Capital expenditure approval per limits of authority | `[INS]` capex approval documentation vs LOA schedule | CP |
| MFRS 16 lease — right-of-use asset and lease liability properly recognised for each new centre | `[REC]` ROU = PV of lease payments; `[INS]` lease commencement date = date of access | VA, AC |
| Lease term used in MFRS 16 calculation reflects CKAPS licence period alignment | `[REC]` lease term vs CKAPS licence renewal cycle | VA, CP |
| Machine installation timeline meets PPT agreement Final Installation Date | `[INS]` Schedule III vs PPT agreement Clause 2.2 | CP |
| New centre budget vs actual — post-opening variance | `[INS]` approved budget vs actual capex spend | AC |
| Nephrologist contracted before opening (CKAPS requirement) | `[INS]` nephrologist engagement letter date vs opening date | CP |
| Renovation / fit-out costs capitalised vs expensed per MFRS 116 | `[INS]` project cost schedule — distinguish between MFRS 116 assets vs repairs expense | VA, AC |
| Tenancy agreement registered / stamped (LHDN stamp duty) | `[INS]` stamped agreement | CP |
| Related-party premises — arm's length test | `[INS]` lease vs market rate; `[INS]` Companies Act 2016 s.228 disclosure | CP, AC |

---

### Domain 8 — Payroll, HR & Malaysian Employment Compliance

**Read: `references/dialysis-payroll_hr.md`**

| Test | Evidence | Assertion |
|------|---------|-----------|
| All employees paid at or above the national minimum wage [MY-003] (Minimum Wages Order 2024) | `[REC]` payroll records vs MWO 2024 threshold | AC, CP |
| EPF employer rate [MY-005] and employee rate [MY-004] by salary band | `[REC]` EPF schedule vs payroll; `[CON]` KWSP portal | AC, CP |
| SOCSO contribution — Employment Injury and Invalidity Scheme insurable wage ceiling [MY-007] | `[REC]` SOCSO table vs payroll; `[CON]` PERKESO portal | AC, CP |
| EIS contribution rate [MY-009] and insurable wage ceiling [MY-007] | `[REC]` EIS schedule vs payroll | AC, CP |
| PCB / MTD deduction and remittance — e-PCB | `[CON]` LHDN e-PCB extract; compare to payroll PCB | AC, CP |
| Headcount reconciliation — 4-way: payroll vs HR records vs SOCSO vs EPF | `[CON]` portal extracts + `[INS]` HR list; flag discrepancies | EX, CO |
| Ghost employee test — shared bank account number | `[ANA]` full population: flag ≥2 employees with same bank account | EX |
| Annual leave encashment and overtime — EA 1955 (2022 amendments) compliance | `[REC]` overtime rate: 1.5× for >8 hours/day; `[INS]` time records | AC, CP |
| Anti-Sexual Harassment Act 2022 — policy in employee handbook | `[INS]` HR manual + complaint mechanism | CP |
| Employment contracts — probation, confirmation, termination provisions per EA 1955 | `[INS]` sample of 10 contracts | CP |
| Foreign workers — PLKS pass (Pas Lawatan Kerja Sementara) current | `[CON]` Immigration portal; `[INS]` pass copies | CO, CP |
| Clinical staff credentialing — MMC, MQA, nursing board registration | `[CON]` MMC online verification; `[INS]` registration certificates | CO, CP |

---

### Domain 9 — Malaysian Tax: Income Tax, SST, Transfer Pricing

**Read: `references/dialysis-malaysia_tax.md`**

| Test | Evidence | Assertion |
|------|---------|-----------|
| Corporate Income Tax — rate per [MY-037] (ITA 1967 s.2) | `[INS]` tax computation + `[CON]` LHDN e-Filing submission | AC, CP |
| Estimated Tax (CP204) filed and paid — monthly instalments | `[CON]` LHDN MyTax portal — CP204 submissions | CO, CP |
| SST — healthcare services SST-exempt (Service Tax (Exemption) Order); consumable imports SST applicable | `[INS]` SST return; verify no SST charged on dialysis services | AC, CP |
| Capital Allowance on medical equipment — IA 20%, AA 20% per ITA s.34 Schedule 3 | `[REC]` CA computation vs PP&E schedule | AC, VA |
| Transfer pricing — related-party transactions (management fees, shared services, lease) at arm's length | `[INS]` TP documentation; `[REC]` benchmark | AC, CP |
| Withholding tax on foreign services / interest (rates per [MY-040]) | `[INS]` WHT returns vs FMC fees; `[CON]` LHDN e-Filing | CO, CP |
| Real Property Gains Tax (RPGT) — applicable on disposal of leasehold premises | `[INS]` disposal records | CP |
| Tax-exempt income sources (MOH-sponsored / charity) — separately tracked | `[INS]` income schedule vs tax computation | AC |

---

### Domain 10 — Financial Reporting: MFRS / IFRS

**Read: `references/clinic-D_financial_reporting.md`**

| Test | Evidence | Assertion |
|------|---------|-----------|
| MFRS 16 — Right-of-Use assets and lease liabilities for ALL dialysis centre premises | `[REC]` PV calculation for each lease; `[INS]` lease registry | VA, AC |
| MFRS 16 — Short-term lease exception applied correctly (≤12 months) | `[INS]` lease terms — flag any short-term election on multi-year leases | VA, CP |
| MFRS 15 — Revenue recognised when treatment delivered (point-in-time) | `[INS]` revenue recognition policy; `[REC]` trace PO → treatment → invoice → revenue | VA, CO |
| MFRS 15 — Deferred revenue for treatments purchased but not yet delivered | `[REP]` deferred revenue schedule | VA, AC |
| MFRS 9 — ECL on trade receivables (PERKESO and private debtors) | `[REC]` ECL calculation; `[INS]` provision schedule vs aging | VA, AC |
| MFRS 102 — Inventory: consumables valued at lower of cost and NRV | `[INS]` inventory write-down policy + supporting calculations | VA, AC |
| MFRS 119 — Employee benefit obligations (annual leave, long-service gratuity) | `[INS]` actuarial report; `[REC]` liability vs balance sheet | VA |
| MFRS 116 — Medical equipment capitalisation threshold and useful life policy | `[INS]` capex policy; `[REC]` depreciation calculation | VA, AC |
| Goodwill / intangibles from centre acquisitions — MFRS 3 purchase price allocation | `[INS]` acquisition agreements vs accounting entries | VA, AC |
| Segment reporting — centre-by-centre management accounts | `[INS]` management accounts by centre | CO, AC |
| Related-party disclosures — Companies Act 2016 s.228 + MFRS 124 | `[INS]` notes to accounts; `[INS]` RPT register | CO, CP |

---

### Domain 11 — Healthcare Fraud Risk & Anti-Fraud Controls

**Read: `references/dialysis-healthcare_fraud.md`**

Apply ACFE Fraud Tree. High-risk schemes specific to dialysis:

| Fraud Scheme | Audit Test | Evidence | Signal |
|-------------|-----------|---------|--------|
| **Phantom treatments** — billed but not performed | Match treatment machine log vs billing vs FMC PO vs patient attendance register | `[INS]` + `[REC]` + `[ANA]` | Billing > machine log |
| **Treatment count inflation** — machine log tampered | Independent patient attendance vs machine session counter vs nursing notes | `[PHY]` + `[INS]` | Discrepancy across sources |
| **Dialyser reuse falsification** — fewer reuses recorded to inflate consumption | Reuse tag count per patient per month vs dialysers purchased | `[REC]` + `[INS]` | Theoretical consumption < actual purchase |
| **Consumable diversion** — items removed from clinic for resale | Physical count variance; delivery quantity vs theoretical usage | `[PHY]` + `[REC]` | Positive variance (more received than theoretically needed) |
| **Cash diversion** — patient cash payment not deposited | Official receipt number sequence; bank deposit vs daily collection sheet | `[INS]` + `[CON]` | Receipt gaps; deposit shortfall |
| **PERKESO dual-billing** — same session billed to PERKESO and patient | Cross-match patient ID: PERKESO claims vs private billing | `[ANA]` | Same patient, same date on both |
| **Referral kickbacks** — nephrologist / GP patient funnelling | Review unusual payments to doctors; `[INS]` consultancy/referral fee agreements | `[INS]` + `[ANA]` | MACC s.17A exposure |
| **Ghost staff** — fictitious employees on payroll | 4-way reconciliation; bank account duplication; physical headcount | `[ANA]` + `[PHY]` | Payroll > portal headcounts |
| **Inflated consumable purchase price** — related supplier | Compare FMC invoice price vs Schedule IV PPT rate; `[INS]` any side purchases | `[INS]` + `[REC]` | Price > contracted rate |
| **Related-party lease at above-market rent** | Benchmark rent per sqft against market comparable; `[INS]` lease agreements | `[ANA]` + `[INS]` | Rent > market; payee = related party |

**Digit-distribution tests (full population):**
- Cash receipts per day per centre (first digit)
- PERKESO billing amount per claim (first digit)
- Consumable purchase invoice amounts (first digit)
- Benford and digit tests: run through `gia-fraud:gia-fraud-analytics` (Nigrini MAD primary with per-digit z-scores; chi-square supplementary for small populations). Confirm the preconditions (population size, range across orders of magnitude, no assigned or bounded numbers), segment fixed-amount populations first, and record the MAD table version in the workpaper. A deviation is an indicator, never a conclusion. Inline thresholds from the retired source were removed.
- Treatment count per machine per month is a bounded count and is not suitable for a first-digit test.

---

### Domain 12 — Anti-Bribery, Anti-Corruption & MACC s.17A

**Read: the retired `abac_macc` module (not a separate file in this suite)**

| Test | Evidence | Assertion |
|------|---------|-----------|
| MACC Act 2009 s.17A corporate liability — adequate procedures in place | `[INS]` ABAC policy, training records, gifts register, due diligence | CP |
| Gifts and entertainment register maintained | `[INS]` register completeness vs policy threshold | CO, CP |
| Referral arrangements with nephrologists / GPs — no fee-for-referral | `[INS]` consultancy agreements; `[ANA]` payment pattern to referring doctors | CP |
| Procurement — competitive quotation for ≥RM 10,000 purchases | `[INS]` 3-quotation records vs LOA | CP |
| Related-party vendor approval — independent board approval | `[INS]` board minutes vs RPT register | CP |
| Guarantors (director guarantors) — conflict of interest declarations | `[INS]` COI declarations vs contracts awarded | CP |
| FMC Code of Conduct for Business Partners — signed compliance | `[INS]` signed FMC CoC BP vs PPT Clause 17 | CP |
| Whistleblower channel exists and is communicated | `[INS]` policy + `[OBS]` signage in centres | CP |

---

### Domain 13 — AML/CFT & Cash Controls

| Test | Evidence | Assertion |
|------|---------|-----------|
| Cash payment policy — limit per transaction | `[INS]` policy + `[CON]` BNM AML/CFT guidelines | CP |
| Large cash transactions flagged and reported | `[ANA]` cash receipts > RM 25,000 threshold — BNM reporting | CP |
| Patient identity verification on registration | `[INS]` registration form — MyKad / passport captured | CP |
| Source of funds for self-pay high-value patients (medical tourism) | `[INS]` patient intake form vs billing | CP |

---

### Domain 14 — Data Protection: PDPA 2010 (Amendment 2024)

| Test | Evidence | Assertion |
|------|---------|-----------|
| Personal Data Protection Officer (DPO) appointed (if threshold met) | `[INS]` DPO appointment letter; `[CON]` JPDP register | CP |
| Patient data breach — 72-hour notification procedure in place | `[INS]` incident response policy (effective 1 June 2025) | CP |
| Patient consent for data processing obtained | `[INS]` sample of 20 consent forms | CO, CP |
| Cross-border data transfer (FMC Germany/HQ) — consent or JPDP approval | `[INS]` TDMS data transfer agreement + FMC privacy addendum | CP |
| Data retention and disposal policy — medical records (minimum 7 years per MOH) | `[INS]` records retention policy | CP |

---

### Domain 15 — Comparative Benchmarking & KPI Analysis

**Read: `references/dialysis-benchmarking_kpis.md`**

| KPI | Benchmark | Source | Calculation |
|-----|----------|--------|-------------|
| Treatments per machine per month | 130–156 (PERKESO); up to 180 (optimised private) | MOH ESRD stats, MSDS | Total treatments ÷ installed machines |
| Chair utilisation | ≥ 85% | ANRS, global dialysis benchmarks | Actual patient-sessions ÷ (chairs × shifts × days) |
| Revenue per chair per month | RM 6,000–RM 12,000 | MSDS-based estimate | Revenue ÷ installed chairs |
| COGS as % of revenue | 25%–35% | FMC global PPT economics | Consumable COGS ÷ revenue |
| PPT cost per treatment (PPT 112) | RM 56.00 | PPT 2025/112 Schedule IV | FMC invoice ÷ treatments |
| PPT cost per treatment (PPT 114) | RM 42.75 | PPT 2026/114 Schedule IV | FMC invoice ÷ treatments |
| Dialyser reuse ratio | 10 (1 first + 9 reuses) | PPT Sched IV; AAMI | Treatments ÷ dialysers consumed |
| Hepatitis B seroconversion rate | < 1% | CMS ESRD QIP | New Hep B positives ÷ susceptible patients |
| Kt/V adequacy (≥ 1.2) | ≥ 80% of patients | KDOQI / MOH | Patients achieving Kt/V ≥ 1.2 ÷ total patients |
| Nurse-to-machine ratio | 1:4 (MOH) | PHFSA Regulations | Nurses on shift ÷ machines operating |
| Debtor days — PERKESO | < 60 days | Best practice | PERKESO AR balance ÷ (PERKESO revenue ÷ 365) |
| Debtor days — Private | < 30 days | Best practice | Private AR ÷ (private revenue ÷ 365) |
| Treatment shortfall vs commitment | 0% | PPT Clauses 2.4–2.7 | Actual treatments ÷ commitment |

---

### Domain 16 — Ownership, Governance & Corporate Structure

| Test | Evidence | Assertion |
|------|---------|-----------|
| SSM company search — directors, shareholders match Schedule VIII | `[CON]` SSM MyCoID extract vs PPT Schedule VIII | EX, CO |
| Ocean Eagle (70%) and Nephro Management (30%) shareholder structure verified | `[CON]` SSM extract + `[INS]` shareholder register | EX, CO |
| Guarantors (director guarantors) — personal guarantee status | `[INS]` signed guarantee documents per PPT Clause 4.9 | CO, CP |
| Board minutes for major decisions (lease, capex, expansion, RPT) | `[INS]` board minutes last 12 months | CP |
| Related-party register — Companies Act 2016 s.228 | `[INS]` RPT register vs transactions | CP |
| Change of control notification to FMC — 21 days advance notice | `[INS]` correspondence per PPT Clause 9.2(vi) | CP |
| Annual financial statements filed with SSM — within 6 months of FYE | `[CON]` SSM filing portal | CO, CP |
| Auditor independence — no prohibited services | `[INS]` engagement letter + MIA independence declaration | CP |

---

### Domain 17 — IT / Systems Controls

| Test | Evidence | Assertion |
|------|---------|-----------|
| Billing system access controls — role-based; no shared logins | `[INS]` user access matrix | CP |
| TDMS (Therapy Data Management System) — FMC access rights | `[INS]` TDMS user list per centre | CP |
| Backup and recovery — patient data and financial records | `[OBS]` + `[INS]` backup policy and restoration test | CP |
| Audit trail in billing system — cannot be overridden without log | `[INS]` system audit log configuration | CP |
| Patient data encrypted at rest and in transit (PDPA compliance) | `[INS]` IT security policy + `[CON]` vendor certification | CP |

---

## Step 5 — Report structure

Owned by `gia-report-qa:gia-ia-report` (standard concise report plus Excel working paper). This pack emits a findings register and its supporting tables only; the long-form overall-opinion layout in the retired source is a legacy conversion reference and is not used. Dashboards named in the retired layout (yield, labour compliance, OEM scorecard, benchmarks) are working-paper sheets.

## Validation Standards — Non-Negotiable

| Standard | Rule |
|----------|------|
| **Evidence first** | No finding stated before evidence obtained and documented |
| **Quantify always** | Every finding states MYR exposure, treatment count, or % gap — or explains why not |
| **Cite specifically** | Law + section/clause + year; IIA GIAS Standard number; no vague references |
| **Tag evidence** | Every test tagged: `[INS]` `[PHY]` `[CON]` `[REP]` `[REC]` `[OBS]` `[ANA]` |
| **Challenge always** | Professional skepticism; corroborate all management explanations |
| **No inference as finding** | "Appears to" / "likely" / "probably" prohibited in findings |
| **Regulatory calendar** | Always include next 5 filing/compliance deadlines |
| **IIA 2024 alignment** | Reference specific IIA GIAS Standards |
| **Disclaimer** | Every report includes the professional advisory disclaimer |
| **PPT tracking** | Every report includes PPT commitment dashboard |
| **Digit tests** | Run per the Benford note under the fraud section |
