> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- IATF 16949 Current Status (2025)
- AIAG Core Tools (5 Tools) — Mandatory for OEM Supply
- OEM Customer-Specific Requirements (CSRs)
- OEM Quality Scorecards — Evidence Hierarchy
- Quality KPIs — Benchmarks
- IATF Finding — Potential Audit Conclusions


# IATF 16949 & OEM Quality Management Reference — MKPC

## IATF 16949 Current Status (2025)

### Standard Version
- **IATF 16949:2016** remains the certifiable standard
- **IATF Rules 6th Edition** published 31 March 2024; **effective 1 January 2025**
- Replaces 5th Edition and all associated Sanctioned Interpretations (SIs) and FAQs
- Transition: All certified organisations are subject to 6th Edition Rules from 1 Jan 2025

### 6th Edition Key Changes (Rules-Level — Not Standard-Level)
| Change | Old Requirement | New Requirement |
|--------|---------------|----------------|
| Surveillance interval | Some flexibility allowed | **Exactly 12 months** — no flexibility |
| NC corrective action | 20 days to submit | **15 days** to submit |
| Late surveillance audit | Grace period possible | **Immediate certificate removal** |
| Remote audits | Various options | **Limited to support functions only** — cannot replace on-site manufacturing audit |
| Cybersecurity | Emerging topic | Now explicitly referenced as new focus area |
| Certificate scope | Site-specific | Confirmed: must include manufacturing site; remote support functions audited but cannot certify independently |

### Certificate Verification (Rank 1 Evidence)
- **IAQG OASIS database:** `https://iaqg.org/oasis`
- Search by company name, site address, or certificate number
- Verify: Certificate number, expiry date, CB (Certification Body) name, scope, surveillance dates
- **Do NOT rely on client-provided copy of certificate** — always cross-check OASIS

### Malaysia-Approved Certification Bodies for IATF 16949
- SIRIM QAS International Sdn Bhd
- TÜV SÜD PSB Malaysia
- SGS (Malaysia) Sdn Bhd
- Bureau Veritas Certification Malaysia
- DNV Malaysia

## AIAG Core Tools (5 Tools) — Mandatory for OEM Supply

### 1. APQP (Advanced Product Quality Planning)
- Required before start of production (SOP) for all new parts
- Phase-gate reviews at design freeze, prototype, pre-launch, SOP
- **Audit test:** `[INS]` APQP plan + gate review minutes for all parts launched in period

### 2. PPAP (Production Part Approval Process)
- **Level 3** most common for Perodua/Denso (full submission with sample parts)
- Required for: new parts, design changes, engineering changes, process changes, tooling changes
- Customer PPAP approval = "Warrant" signed by customer SQA engineer
- **Audit test:** `[INS]` PPAP file per part number; `[INS]` customer-signed warrant; flag any part in production without approved PPAP

### 3. PFMEA (Process Failure Mode & Effects Analysis)
- Linked to Control Plan
- All high RPN (Risk Priority Number) items must have closed action items
- **IATF 6th Ed / AIAG-VDA FMEA (2019):** AP (Action Priority — H/M/L) replaces RPN threshold
- **Audit test:** `[INS]` PFMEA for each production process; `[INS]` action tracker for H-priority items; verify all H-priority actions closed

### 4. MSA (Measurement System Analysis)
- Gage R&R study required for all measurement systems used on critical characteristics
- Acceptance criteria: %R&R <10% (excellent), 10–30% (marginal-acceptable with approval), >30% (unacceptable)
- **Audit test:** `[INS]` MSA study reports for all gauges used at critical characteristics; flag %R&R >30%

### 5. SPC (Statistical Process Control)
- Applied on all special/critical characteristics (SC/CC as designated in Control Plan)
- **Cpk ≥1.33** (minimum capability index for production characteristics)
- **Cpk ≥1.67** for safety-critical characteristics (some OEMs)
- **Audit test:** `[INS]` SPC charts; `[REC]` recalculate Cpk for sample of 5 critical characteristics; flag Cpk <1.33

## OEM Customer-Specific Requirements (CSRs)

### Perodua (P2) CSRs — Based on Daihatsu/Toyota Framework
- Perodua does not publish a standalone CSR document publicly; requirements communicated via:
  - Annual Supplier Quality Day briefings (P2SA)
  - P2SA Technical Committee guidelines
  - Individual PO terms and conditions
- Key Perodua quality requirements:
  - PPM target: typically <50 ppm customer-end (some parts <10 ppm)
  - Supplier must be IATF 16949 certified (mandatory for Tier 1)
  - 8D response within 24–48 hours for quality incidents
  - Annual Supplier Quality Rating (SQR) affects future sourcing decisions
- **Audit test:** `[CON]` Perodua SQR scorecard from Perodua portal/SQA letter; `[INS]` any quality warning letters received

### Denso CSRs — Denso SQA Manual
- Denso operates a formal Supplier Quality Assurance (SQA) system
- Denso issues formal **Supplier Evaluation Results** — cover: Quality, Delivery, Cost, Management (QDCM)
- Quality failures trigger: SQA Notification → 8D response → on-site audit by Denso SQA team
- **Audit test:** `[CON]` Denso SQA notification log (from Denso's system, not MKPC's self-report); `[INS]` all 8D reports issued in period

### Daihatsu CSRs (if applicable)
- Daihatsu is the technical partner in Perodua; some MKPC parts may be designed to Daihatsu engineering standards
- Daihatsu CSRs include: DS-G series design standards; DPS (Daihatsu Production System) alignment
- **Audit test:** `[INS]` engineering drawings — verify Daihatsu standard notation compliance

## OEM Quality Scorecards — Evidence Hierarchy

| Scorecard Source | Reliability | Acceptable? |
|----------------|-----------|------------|
| OEM portal / OEM-issued letter | `[CON]` — Rank 1 | ✅ Yes — primary evidence |
| MKPC's own quality register (self-reported) | `[REP]` — Rank 5 | ❌ No — only initiate inquiry |
| Mixed (OEM data re-keyed into MKPC system) | `[INS]` | ⚠️ Verify source vs. OEM portal |

**NEVER cite MKPC's internally compiled customer scorecard as the basis for a finding without cross-referencing the OEM-issued source.**

## Quality KPIs — Benchmarks

| KPI | World-Class | Malaysia Tier 1 Typical | MKPC Target |
|----|------------|------------------------|------------|
| Customer DPPM | <10 ppm | 20–100 ppm | Verify per OEM APA |
| Internal reject rate | <1% | 1–3% | |
| Supplier DPPM | <100 ppm | 200–500 ppm | |
| OTIF | ≥99.5% | 95–99% | ≥98% (Perodua/Denso) |
| 8D on-time response | 100% | 80–95% | 100% mandatory |
| Cpk (production critical chars) | ≥1.67 | ≥1.33 | ≥1.33 minimum |
| MSA %R&R | <10% | <30% | <10% preferred |

## IATF Finding — Potential Audit Conclusions

| Condition | Finding Level | IIA Impact |
|----------|-------------|-----------|
| Certificate expired / lapsed | 🔴 Critical | Customer supply qualification at risk; revenue continuity risk |
| Surveillance overdue >1 month | 🔴 Critical | Certificate suspension risk; OEM may be notified |
| Open IATF NC >15 days | 🟠 High | Certificate suspension risk |
| PPAP not approved for active part | 🔴 Critical | Non-compliant supply; OEM quality stop risk |
| Cpk <1.33 on critical characteristic | 🟠 High | OEM claim/warranty risk |
| PFMEA H-priority action open >3 months | 🟠 High | Quality system non-compliance |
| Customer DPPM trending up (3 consecutive months) | 🟠 High | SQA incident risk |
| MSA %R&R >30% on critical gauge | 🟠 High | Measurement system invalid; quality data unreliable |
