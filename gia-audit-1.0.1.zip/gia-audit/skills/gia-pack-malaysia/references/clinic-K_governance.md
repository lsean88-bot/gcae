> Case figures from a prior clinic engagement were moved to example-2026-Q1.md (illustrative, dated).
## Contents
[case figure moved to example-2026-Q1.md]
- J2 — PDPA 2024: Personal Data Protection Act
[case figure moved to example-2026-Q1.md]
- K1 — Companies Act 2016 Director Duties
- K2 — MACC Act 2009: Adequate Procedures (s.17A)
- K3 — Board Governance Minimum Requirements


> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.

# Reference J — IT Systems, PDPA & Digital Controls

[case figure moved to example-2026-Q1.md]

| Entity | Accounting | POS / Clinic | Payroll / HR |
|--------|-----------|-------------|-------------|
| Perfect Healthcare Sdn Bhd | SQL Accounting | **Klinify** | **Worksy** |
| Perfect Dental Sdn Bhd | SQL Accounting | **Doctor Partner** | **Payroll Panda** |
| Perfect Physio Sdn Bhd | SQL Accounting | **Doctor Partner** | **Payroll Panda** |

[case figure moved to example-2026-Q1.md]

---

## J2 — PDPA 2024: Personal Data Protection Act

**Law:** Personal Data Protection Act 2010 (PDPA) — substantive amendments effective 2024; Personal Data Protection (Amendment) Act 2023 gazetted

### Key 2024 Amendments
| Provision | Requirement |
|-----------|-------------|
| Data Breach Notification | Must notify PDPA Commissioner **within 72 hours** of becoming aware of a data breach |
| Data Protection Officer (DPO) | Mandatory for data processors meeting prescribed threshold (TBC by Commissioner — expected: organisations processing sensitive personal data of >500 individuals) |
| Patient data = Sensitive Personal Data | Health, medical, genetic data explicitly classified as sensitive — heightened protection |
| Cross-border transfer | Only to countries with adequate protection or with data subject consent |
| Data subject rights | Right to access, correction, erasure, portability (2024 amendment adds portability and erasure rights) |

[case figure moved to example-2026-Q1.md]
[case figure moved to example-2026-Q1.md]
- **Separate PDPA assessment required per entity per POS platform**
- Patient registration forms must include PDPA consent (collection notice)
- Data retention policy: how long is patient data retained in Klinify / Doctor Partner?
- Backup security: patient data in backup must be encrypted at rest
- Access log: who accessed patient records — audit trail in Klinify / Doctor Partner

### Audit Tests — PDPA
| Test | Evidence | Assertion |
|------|---------|-----------|
| Patient registration form includes PDPA collection notice | `[INS]` sample registration form | CP |
| DPO appointed (if threshold met) | `[INS]` appointment letter or assessment | CP |
| Data breach response procedure documented | `[INS]` incident response policy | CP |
| Role-based access in POS — clinical staff cannot access billing; billing cannot access clinical notes | `[INS]` Klinify user access matrix | AU |
| Patient data not shared with third parties without consent | `[INQ]` + `[INS]` data sharing agreements | CO, CP |

---

[case figure moved to example-2026-Q1.md]

| Control | Requirement | Test |
|---------|-------------|------|
| Encounter cannot be deleted without audit log entry | Klinify system setting | `[OBS]` attempt to delete test record |
| POS discounts require manager approval | Role-based approval | `[INS]` discount authorisation log |
| Daily Z-report — end-of-day reconciliation | Run daily | `[INS]` Z-report archive |
| SST module — configured for non-citizen surcharge | Post-01 Sep 2025 | `[OBS]` test transaction with non-citizen patient |
| Patient nationality captured at registration | IC vs passport field | `[INS]` registration records |
| Backup — patient data backed up daily | Klinify cloud backup | `[CON]` Klinify backup confirmation |

---

# Reference K — Corporate Governance, MACC & Board

## K1 — Companies Act 2016 Director Duties

[case figure moved to example-2026-Q1.md]
|---------|------|---------------|
| s.213 | Duty to act in good faith in best interests of company | Director cannot approve interco loan without documented commercial basis |
| s.214 | Duty to exercise reasonable care, skill and diligence | Board must review management accounts; failing to notice RM 2.47M unrecovered interco = potential breach |
| s.217 | Disclosure of interest | Director with interest in any counterparty must disclose |
| s.223 | Loans to directors prohibited without shareholder approval | Director A/C movements must be properly authorised |
| s.228 | Related-party transactions require disclosure | All transactions with Physio, Dental, Cuisine entities |
| s.245 | Proper books of accounts | Static inventory, unreconciled POS-GL gap |
| s.258 | Directors' report — going concern assessment | If ECL provision reduces equity significantly |
| s.259 | Annual financial statements — 6 months after FYE | Confirm SSM filing date for FY2025 |

## K2 — MACC Act 2009: Adequate Procedures (s.17A)

A commercial organisation can be convicted of bribery committed by an **associated person** unless it can prove it had **adequate procedures** in place.

### The 6 Pillars of Adequate Procedures (MACC Guidelines 2020)
1. **T.R.U.S.T** framework: Top-level commitment; Risk assessment; Undertake control measures; Systematic review; Training and communication
2. **Anti-bribery policy** — written, endorsed by CEO/Board, publicly displayed
3. **Third-party due diligence** — vendor registration, referral agent screening
4. **Gifts, hospitality & entertainment register** — threshold-based approval
5. **Whistleblower mechanism** — protected reporting channel
6. **Training** — annual MACC training for all staff

[case figure moved to example-2026-Q1.md]
- Cell therapy sourcing (NEUROPRO PTE LTD, SCI Laboratories, Regen Cell Technology) — supplier due diligence required
[case figure moved to example-2026-Q1.md]
- VIP patients ([named VIP patient], [named VIP patient]) — document that no improper benefits are given in exchange for clinic patronage

## K3 — Board Governance Minimum Requirements

| Requirement | Frequency | Evidence |
|-------------|-----------|---------|
| Board meeting | Quarterly minimum (annual for Sdn Bhd) | `[INS]` board minutes |
| Management accounts review | Monthly (best practice) | `[INS]` board approval on management accounts |
| Related-party transaction approval | Per transaction | `[INS]` board minutes |
| Capital expenditure approval | Per policy threshold | `[INS]` capex approval |
| Annual budget approval | Before financial year start | `[INS]` approved budget |
| External auditor appointment | Annual | `[INS]` AGM resolution |
| SSM annual return (Section 68) | 30 days after AGM | `[CON]` SSM portal |
