> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- Primary Benchmark Sources
- Operational KPIs
- Centre-Level Performance Matrix Template


# Benchmarking & KPI Reference — Malaysian Dialysis Operations

## Primary Benchmark Sources

| Source | Description | Access |
|--------|-------------|--------|
| **MSDS** — Malaysian Society of Dialysis and Transplantation | Annual dialysis report — treatment statistics, patient outcomes, centre data | `msds.org.my` |
| **MOH CRC** — Clinical Research Centre | National Renal Registry (NRR); ESRD incidence, prevalence, modality | `crc.gov.my` |
| **ANRS** — Annual Nephrology Report (Malaysia) | Facility-level data, survival analysis | MOH publication |
| **CMS ESRD QIP** — US Centers for Medicare & Medicaid | Quality Incentive Program benchmarks (internationally referenced) | `cms.gov` |
| **KDOQI** — Kidney Disease Outcomes Quality Initiative | Clinical practice guidelines: Kt/V, Hb, vascular access | `kdoqi.org` |
| **ERA-EDTA** — European Renal Association | European dialysis registry — outcome benchmarks | `era-online.org` |
| **Fresenius Medical Care Annual Report** | Global NephroCare operational KPIs | `freseniusmedicalcare.com` |

---

## Operational KPIs

### Treatment Volume & Machine Utilisation

| KPI | Formula | Target/Benchmark | Source |
|-----|---------|-----------------|--------|
| Treatments per machine per month | Total treatments ÷ installed machines | 130–180 treatments | MOH NRR; FMC operational norms |
| Treatments per chair per month | Total treatments ÷ chairs (≈ machines) | 130–180 | Derived |
| Machine utilisation rate | (Actual treatments ÷ theoretical max) × 100% | ≥ 80% | Industry norm |
| Theoretical maximum | Chairs × 3 shifts/day × 26 days/month × 1 treatment/shift | Centre-specific | |
| Sessions per patient per week | Patient record count | 3.0 sessions (standard) | KDOQI; MOH |
| Patient census per centre | Active patients on census | 80–100% of chair capacity | Operational norm |
| New patient intake per month | New registrations vs churn (mortality + transplant + transfer) | Expansion-dependent | |

### Revenue KPIs

| KPI | Formula | Target/Benchmark | Notes |
|-----|---------|-----------------|-------|
| Revenue per chair per month | Revenue ÷ installed chairs | RM 7,000–RM 12,000 | Varies: PERKESO centres lower; private higher |
| Revenue per treatment | Total revenue ÷ treatments | PERKESO: ~RM 60–90; Private: RM 150–250+ | PERKESO tariff varies by contract; verify current rate |
| PERKESO revenue as % of total | PERKESO collections ÷ total revenue | 60–80% for PERKESO centres | Higher = more government-dependency risk |
| Billing completion rate | Treatments billed ÷ treatments performed | 100% | Zero unbilled = control objective |
| Collection rate — PERKESO | Collections ÷ PERKESO billings | 95–100% | Government payer — low credit risk |
| Collection rate — Private | Collections ÷ private billings | 85–95% | Credit risk varies |
| Debtor days — PERKESO | (PERKESO AR ÷ PERKESO revenue) × 365 | < 60 days | MOH: PERKESO typically 45–90 days |
| Debtor days — Private | (Private AR ÷ private revenue) × 365 | < 30 days | Higher risk if extended |

### Cost KPIs

| KPI | Formula | Target/Benchmark | Notes |
|-----|---------|-----------------|-------|
| PPT consumable cost per treatment | FMC invoice ÷ treatments | RM 42.75 (PPT 114); RM 56.00 (PPT 112) | Per Schedule IV |
| COGS as % revenue | Consumable COGS ÷ revenue | 25%–35% | Varies by payer mix |
| Staff cost as % revenue | Total payroll ÷ revenue | 35%–45% | Healthcare labour-intensive |
| Rent as % revenue | Total lease payments ÷ revenue | 8%–15% | Higher in new centres (lower utilisation) |
| EBITDA margin per centre | EBITDA ÷ revenue | 15%–25% | Mature centre; new centres typically < 10% Year 1 |

### Clinical Quality KPIs (KDOQI / MOH / CMS ESRD QIP)

| KPI | Formula | Benchmark | Action if Below |
|-----|---------|----------|----------------|
| Kt/V adequacy | Single-pool Kt/V per machine measurement | ≥ 1.2 (minimum); target 1.4 | Review prescription; machine parameters |
| % patients achieving Kt/V ≥ 1.2 | Patients with Kt/V ≥ 1.2 ÷ total patients | ≥ 80% (CMS QIP) | Investigate causes; audit prescriptions |
| Haemoglobin 10–12 g/dL | % patients in target range | ≥ 70% | Review EPO dosing; iron status |
| Phosphate control (< 1.78 mmol/L) | % patients in range | ≥ 55% | Dietary compliance; binder therapy |
| Calcium × Phosphate product | Ca × P (mg²/dL²) | < 55 mg²/dL² | Cardiovascular risk indicator |
| AVF usage rate | AVF patients ÷ total HD patients | ≥ 65% (KDOQI) | AVF preferred over catheter |
| Catheter infection rate | CRBSI per 1,000 catheter days | < 2.0 (CMS benchmark) | Infection control review |
| Hepatitis B seroconversion | New HBsAg positive ÷ previously negative patients | < 1% annually | Isolation protocol breach |
| Hepatitis C transmission | New anti-HCV positive | 0% (target) | Universal precautions review |
| Hospitalisation rate | Unplanned hospitalisations per patient per year | < 1.5 (ESRD QIP) | Clinical quality indicator |
| Mortality rate | Patient deaths per 1,000 patient-years | Country-specific (Malaysia NRR: ~120–150) | Compare to NRR data |

### Expansion KPIs

| KPI | Formula | Target | Notes |
|-----|---------|--------|-------|
| Centre break-even timeline | Fixed costs ÷ contribution per treatment | 12–18 months | Subject to ramp-up |
| Ramp-up rate — treatments per month growth | Month-on-month treatment growth % | +10–15%/month (Year 1) | Patient recruitment pace |
| CKAPS approval lead time | Date applied → date approved | < 90 days | Subject to MOH processing |
| Capex per centre | Fit-out + RO + TDMS + furniture | RM 200,000–RM 500,000 | Excludes FMC machines (PPT lease) |
| Machine deployment lead time | PPT signing → installation | ≤ 60 days per Clause 2.2 | FMC contractual |
| New centre revenue at 6 months | Treatments × PPT billing rate | Centre-specific | vs budget |

---

## Centre-Level Performance Matrix Template

```
Centre: _________________ | Month: ________ | Year: ________
═══════════════════════════════════════════════════════════════════
VOLUME
  Installed machines:                        ___
  Active patients on census:                 ___
  Total treatments performed:                ___
  Treatments per machine/month:              ___  [Benchmark: 130–180]
  Machine utilisation rate:                  ___%  [Target: ≥80%]
  PPT 112 commitment (if applicable):        ___  [Required: per Schedule IV]
  PPT 114 commitment (if applicable):        ___  [Required: per Schedule IV]
  PPT shortfall / surplus:                   ___

REVENUE
  PERKESO billings:                     RM ___
  Private / self-pay billings:          RM ___
  Other (insurance, TPA):               RM ___
  Total revenue:                        RM ___
  Revenue per chair/month:              RM ___  [Benchmark: RM 7,000–12,000]

COLLECTIONS
  PERKESO collections:                  RM ___
  Private collections:                  RM ___
  PERKESO debtor days:                  ___  [Target: <60 days]
  Private debtor days:                  ___  [Target: <30 days]

COST
  PPT consumable cost (FMC):            RM ___
  COGS per treatment:                   RM ___  [Expected: RM 42.75 or RM 56.00]
  Total payroll:                        RM ___
  Lease / rent:                         RM ___
  Other overheads:                      RM ___

CLINICAL QUALITY
  % patients Kt/V ≥ 1.2:               ___%  [Target: ≥80%]
  % patients Hb 10–12 g/dL:            ___%  [Target: ≥70%]
  AVF usage rate:                       ___%  [Target: ≥65%]
  New Hep B cases:                      ___   [Target: 0]

STAFFING
  Registered nurses on duty (peak shift): ___
  Machines in operation (peak shift):    ___
  Nurse:machine ratio:                   1:___  [Required: ≤1:4]
  Nephrologist sessions/week:            ___
═══════════════════════════════════════════════════════════════════
```
