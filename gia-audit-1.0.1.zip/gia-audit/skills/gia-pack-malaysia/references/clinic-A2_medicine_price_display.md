> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.

# Reference A2 — Medicine Price Display Order 2025 (NEW REGULATORY DOMAIN)
*Research-verified as at May 2026 — active High Court judicial review, enforcement stayed*

---

## A2.1 — Legal Framework

**Primary Law:** Price Control and Anti-Profiteering Act 2011 (Act 723)
**Gazette Order:** Price Control and Anti-Profiteering (Price Marking for Drug) Order 2025, P.U.(A) 141/2025
**Joint Enforcement:** Ministry of Health (MOH) + Ministry of Domestic Trade and Cost of Living (KPDN)

---

## A2.2 — Timeline of Events (Critical for Audit Context)

| Date | Event | Status |
|------|-------|--------|
| 01 May 2025 | P.U.(A) 141/2025 came into force — mandatory price display | Effective |
| May–Jul 2025 | 3-month educational enforcement phase | Completed |
| Aug 2025 | MOH inspected 842 facilities — 57% satisfactory compliance | Benchmark |
| 01 Oct 2025 | Compounds for repeat offences announced | Was planned |
| 01 Jan 2026 | Full enforcement originally planned | Was planned |
| 24 Dec 2025 | High Court granted temporary stay pending JR hearing | Stay in force |
| 21 May 2026 | High Court Justice Alice Loke granted STAY of enforcement pending full JR disposal | **CURRENT STATUS: ENFORCEMENT STAYED** |

[case figure moved to example-2026-Q1.md]

---

## A2.3 — Scope of the Price Display Requirement

When enforcement resumes, the following applies:

**Affected facilities:** All private healthcare facilities governed under PHFSA 1998 that sell, supply, or administer medicines, plus community pharmacies.

**Medicines covered:**
- All prescription and non-prescription medicines
- Over-the-counter medications
- Traditional medicines and health supplements
- Extemporaneously prepared products (compounded medications)

**Display method required:**
- Price list prominently displayed, OR
- Individual price tags on medicine packaging accessible to consumers
- Must show: medicine name, quantity, retail price

---

## A2.4 — Penalties

| Offender | Maximum Fine |
|----------|-------------|
| Individual healthcare provider | RM 50,000 |
| Corporate body (e.g. Sdn Bhd) | RM 100,000 |

Basis: Price Control and Anti-Profiteering Act 2011 (Act 723) s.14

---

## A2.5 — Audit Tests (Apply When Enforcement Resumes)

| Test | Evidence | Assertion |
|------|----------|-----------|
| Price list for all medicines displayed at reception/dispensary | `[PHY]` site inspection — photograph price list | CP |
| Individual price tags on accessible OTC medicines | `[PHY]` inspection of dispensary shelves | CP |
| Price list includes: medicine name, quantity, retail price | `[INS]` review of price list contents | CP |
| Traditional medicines and health supplements included | `[PHY]` + `[INS]` | CP |
| Staff trained on price display requirements | `[INS]` training records | CP |

[case figure moved to example-2026-Q1.md]

---

[case figure moved to example-2026-Q1.md]

[case figure moved to example-2026-Q1.md]
1. Prepare a compliant medicine price list covering ALL dispensed medicines (including aesthetics, cell therapy preparations if continuing, TCM products)
2. Do NOT display until court status confirmed (to avoid inadvertently appearing to concede legal compliance with an order being challenged)
3. Monitor: www.codeblue.galencentre.org / Malaysia Judiciary website for JR outcome
4. Engage legal counsel who can advise on timing of voluntary compliance

---

## A2.7 — Broader Price Transparency Context

[case figure moved to example-2026-Q1.md]
