# Statutory register - Malaysia

Single dated source for every statutory rate, threshold and date used by the Malaysia pack. Skill and reference text must point here and must not restate values.

Owner: statutory-validator agent (fills `source URL`, `verified-on`, `status`); freshness gate: `python3 -I ${CLAUDE_PLUGIN_ROOT}/skills/gias-navigator/scripts/check_rates.py` (rows older than 180 days or not VERIFIED are flagged).
Seeded: 2026-10-29 from the retired source skills, **not web-checked**. Every row is `[UNVERIFIED]` until the validator replaces the status with `VERIFIED`, `CORRECTED` or `CONFLICT` and fills `verified-on`.

Column notes:
- `id` is the stable row identifier cited by pointers in the pack (`[MY-nnn]`). Never renumber or reuse an id; append new rows with the next number.
- `value` is copied as stated in the source skill, including its own caveats.
- `source URL` holds the portal named in the source skill; the validator replaces it with the primary-source deep link (gazette, notification, circular).
- Rows with a conflict note are listed in the conflict table at the end. A finding must not cite a row whose status is `[UNVERIFIED]` or `CONFLICT` (see `gia-core:iron-rules`, evidence rules).

## Contents
- Employment, social security and tax withholding
- Indirect tax and e-invoicing
- Sector and entity-specific
- Sector and entity-specific
- Conflicts to resolve
- Open dependencies

## Employment, social security and tax withholding
| id | item | Act/section | value | effective date | source URL | verified-on | status |
|---|---|---|---|---|---|---|---|
| MY-001 | Employment Act 1955 as amended by Act A1651 | Employment Act 1955 (Act 265); Act A1651 | All employees covered; 45 hours/week cap; 98-day maternity; 7-day paternity; flexible work provisions; Peninsular Malaysia and Federal Territories only | 01-Jan-2023 | mohr.gov.my / jtksm.mohr.gov.my | | [UNVERIFIED] |
| MY-002 | overtime multipliers | Employment Act 1955 | 1.5x normal day; 2x rest day; 3x public holiday | Current | jtksm.mohr.gov.my | | [UNVERIFIED] |
| MY-003 | national minimum wage | Minimum Wages Order 2024, P.U.(A) 376/2024 (gazetted 04-Dec-2024) | RM1,700/month; hourly RM8.72 (source skills said RM8.17: conflict) | 01-Feb-2025 (5 or more employees, and MASCO professional employers of any size); 01-Aug-2025 (other employers). 01-Feb-2024 is not an RM1,700 date | https://gajiminimum.mohr.gov.my/wp-content/uploads/PUA%20376.pdf (not read); content via https://www.skrine.com/insights/alerts/december-2024/minimum-wages-order-2024-gazetted | 29-Oct-2026 | SECONDARY-ONLY (re-read the gazette PDF before final use) |
| MY-004 | EPF employee | EPF Act 1991, Third Schedule | 11% (age 60 or below); 5.5% (age above 60) | Current | kwsp.gov.my | | [UNVERIFIED] |
| MY-005 | EPF employer | EPF Act 1991, Third Schedule | 13% where wages are RM5,000 or less, 12% above (per MIDA, secondary); no statutory wage ceiling found; RM5,000 and RM20,000 are rate or calculation thresholds | Current | https://www.kwsp.gov.my/en/employer/responsibilities/mandatory-contribution | 29-Oct-2026 | SECONDARY-ONLY (Third Schedule not retrievable; document dated Oct-2025 exists, unread) |
| MY-006 | EPF foreign workers | EPF Act 1991 | Voluntary; employer minimum RM5/month if opted in | Current | kwsp.gov.my | | [UNVERIFIED] |
| MY-007 | SOCSO and EIS insurable wage ceiling | Employees' Social Security Act 1969; EIS Act 2017 | RM6,000/month (up from RM5,000), for SOCSO and EIS | 01-Oct-2024 | https://www.perkeso.gov.my/en/contribution-rate/ | 29-Oct-2026 | VERIFIED (a MIDA page still showing RM4,000 is stale) |
| MY-008 | SOCSO contribution | Employees' Social Security Act 1969 | Employer about 1.75%; employee about 0.5% (band-based) | Current | perkeso.gov.my | | [UNVERIFIED] |
| MY-009 | EIS contribution | Employment Insurance System Act 2017 | 0.4% employer + 0.4% employee | Current | perkeso.gov.my | | [UNVERIFIED] |
| MY-010 | remittance date for EPF, SOCSO, EIS, PCB | Respective Acts | 15th of the following month | Current | kwsp.gov.my / perkeso.gov.my / hasil.gov.my | | [UNVERIFIED] |
| MY-011 | monthly tax deduction | Income Tax Act 1967 s.107 and PCB schedule | Per LHDN schedule for the tax year | Annual | hasil.gov.my | | [UNVERIFIED] |
| MY-012 | employer accommodation standards and deduction cap | Accommodation and Amenities Act 1990 (Act 446) | Federal order 01-Sep-2020; deduction cap commonly cited RM150/month, state gazette governs | 01-Sep-2020; state-specific | mohr.gov.my / state gazette | | [UNVERIFIED] |
| MY-013 | Employment Pass salary categories | Immigration / ESD policy | Cat I at least RM10,000; Cat II RM5,000-9,999; Cat III RM3,000-4,999 | 01-Jun-2026 | esd.imi.gov.my | | [UNVERIFIED] |
| MY-014 | corporate liability | MACC Act 2009 s.17A | Corporate liability for corrupt acts by associated persons; adequate-procedures defence | 01-Jun-2020 | sprm.gov.my | | [UNVERIFIED] |
| MY-015 | Personal Data Protection Act 2010 as amended 2024 | PDPA 2010 (Amendment Act 2024) | 72-hour breach notification; DPO appointment where threshold met | 01-Jun-2025 (breach notification and DPO per sources) | pdp.gov.my | | [UNVERIFIED] |
| MY-016 | OSHA 1994 as amended 2022 | OSHA 1994 (Act A1648) | Penalty up to RM500,000; OSH coordinator for 5 or more employees | 2022 amendment | dosh.gov.my | | [UNVERIFIED] |

## Indirect tax and e-invoicing
| id | item | Act/section | value | effective date | source URL | verified-on | status |
|---|---|---|---|---|---|---|---|
| MY-017 | sales tax | Sales Tax Act 2018 | 5% or 10% (as of 2025, per source) | 2025 | customs.gov.my | | [UNVERIFIED] |
| MY-018 | service tax | Service Tax Act 2018 | 8% general; 6% for F&B, logistics, telecom, parking (source). Another source quotes 6% for manufacturing: confirm | 2025 | customs.gov.my | | [UNVERIFIED] |
| MY-019 | service tax on imported services | Service Tax Act 2018 | 8% self-accounted (reverse charge), per MKPC source | Current | customs.gov.my | | [UNVERIFIED] |
| MY-020 | e-Invoice phase 3 | LHDN e-Invoice guideline | Annual turnover RM5 million to RM25 million; mandatory from 01-Jul-2025 | 01-Jul-2025 | myinvois.hasil.gov.my | | [UNVERIFIED] |
| MY-021 | e-Invoice and expense deductibility | Finance Act 2024 | Deductibility rule linked to validated e-invoice | 2025 | hasil.gov.my | | [UNVERIFIED] |

## Sector and entity-specific
| id | item | Act/section | value | effective date | source URL | verified-on | status |
|---|---|---|---|---|---|---|---|
| MY-022 | LMW export / local ratio | Customs Act 1967 s.65/65A; LMW conditions | Export at least 80% of finished goods value; local sales up to 20% (MIDA approval above) | Current | customs.gov.my / mida.gov.my | | [UNVERIFIED] |
| MY-023 | RMCD returns | Customs Act 1967 | M1, M2, M4 returns as per LMW licence | Current | customs.gov.my | | [UNVERIFIED] |
| MY-024 | gas cylinder hydrostatic test cycle | DOSH requirement (instrument not stated in source) | 5-year cycle for all cylinders | Current | dosh.gov.my | | [UNVERIFIED] |
| MY-025 | large cash transaction reporting | BNM AML reporting (instrument not stated in source) | Cash above RM25,000 reportable (per dialysis source) | Current | bnm.gov.my | | [UNVERIFIED] |
| MY-026 | dialysis centre licensing | PHFSA 1998; CKAPS / MOH licensing | Pre-approval and licence for each centre; building compliance | Current | moh.gov.my | | [UNVERIFIED] |
| MY-027 | nurse to machine ratio | Clinical standard cited in source (instrument not stated) | 1:4 (per clinical-overlap source) | Current | moh.gov.my | | [UNVERIFIED] |
| MY-028 | IATF 16949 rules edition | IATF 16949:2016, 6th Edition Rules | Applies to MKPC OEM supply chain (certification scheme, not statute) | 2025 (per source) | iatfglobaloversight.org | | [UNVERIFIED] |

## Sector and entity-specific
| id | item | Act/section | value | effective date | source URL | verified-on | status |
|---|---|---|---|---|---|---|---|
| MY-029 | Penalty for minimum wage breach | National Wages Consultative Council Act 2011 (Act 732) s.43 | Fine RM10,000 to RM20,000 per employee; imprisonment up to 5 years (as stated in MKPC and dialysis sources) | Current | mohr.gov.my | | [UNVERIFIED] |
| MY-030 | Penalty for late SOCSO contribution | Employees' Social Security Act 1969 | Fine up to RM10,000 per offence; imprisonment up to 2 years (as stated in MKPC and dialysis sources) | Current | perkeso.gov.my | | [UNVERIFIED] |
| MY-031 | SST registration threshold | Sales Tax Act 2018; Service Tax Act 2018 | Manufacturers: annual sales above RM500,000 (diecast source). Private healthcare to non-citizens: taxable turnover above RM500,000 per year (clinical-overlap source) versus RM1,500,000 taxable services over 12 months (clinic source); see MY-C14 | Current | mysst.customs.gov.my | | [UNVERIFIED] |
| MY-032 | service tax on private healthcare to non-citizens | Service Tax Act 2018 | 6% on private healthcare services to non-Malaysian patients (hospitals, clinics, dental, aesthetic, allied health, dialysis, traditional and complementary medicine); Malaysian patients exempt; payment basis. Tax code E for exempt, S for standard on invoices | 01-Jul-2025 | mysst.customs.gov.my | | [UNVERIFIED] |
| MY-033 | SST late payment and non-compliance penalties | Sales Tax Act 2018; Service Tax Act 2018 | Late payment: 10% surcharge per month on unpaid tax, up to 20 times unpaid tax; under-declaration or evasion: 10% to 20% penalty plus tax and interest (one source states 10 to 20 times unpaid tax: confirm); non-registration: fine up to RM50,000 and/or 3 years; non-filing of SST-02: fine RM10,000 to RM50,000; non-compliant invoice: fine up to RM10,000 per invoice; records not kept 7 years: fine up to RM10,000 | Current | mysst.customs.gov.my | | [UNVERIFIED] |
| MY-034 | e-Invoice phases | LHDN e-Invoice guideline | Phase 1: turnover RM100 million or more from 01-Aug-2024; Phase 2: RM25 million to RM100 million from 01-Jan-2025; Phase 3: see MY-020; Phase 4: below RM5 million from 01-Jan-2026 (verify). Clinic source: revenue above RM25 million Aug 2024, above RM500,000 Jul 2025, all Jul 2026 | As stated | myinvois.hasil.gov.my | | [UNVERIFIED] |
| MY-035 | e-Invoice expense deductibility threshold | Finance Act 2024; LHDN guideline | Expenses above RM150 per transaction must be supported by a validated e-invoice to be deductible (exact threshold to verify) | 01-Jan-2025 | myinvois.hasil.gov.my | | [UNVERIFIED] |
| MY-036 | e-Invoice non-compliance penalty | LHDN e-Invoice guideline (as stated in clinic sources) | RM200 per non-compliant or unsubmitted invoice | Current | myinvois.hasil.gov.my | | [UNVERIFIED] |
| MY-037 | corporate income tax rates | Income Tax Act 1967 s.2; Schedule 1 | Standard 24%. SME rate: 17% on first RM600,000 then 24% (paid-up capital RM2.5 million or less, not controlled by a larger company: MKPC source); 15% on first RM150,000 (diecast and dialysis overlap sources); 17% on first RM150,000 then 24% (dialysis tax source): see MY-C15 | Current | hasil.gov.my | | [UNVERIFIED] |
| MY-038 | tax incentives | ITA 1967; Promotion of Investments Act (MIDA) | Pioneer status: 70% or 100% of statutory income exempt for 5 years (extendable; 5 to 10 years in the diecast source). Investment tax allowance: 60% to 100% of qualifying capex for 5 years, offset against 70% of statutory income. Reinvestment allowance: 60% of qualifying capex, offset against 70% of statutory income | Current | mida.gov.my | | [UNVERIFIED] |
| MY-039 | global minimum tax and transfer pricing thresholds | OECD Pillar Two (QDMTT); ITA 1967 s.140A; Transfer Pricing Rules 2012 | Global minimum tax 15% where consolidated group revenue exceeds EUR750 million. Transfer pricing documentation mandatory where related-party transactions exceed RM15 million per year. TP adjustment penalty: 5% surcharge on additional tax. Non-compliance with documentation: RM20,000 to RM100,000 plus 5% surcharge (dialysis source) | Current | hasil.gov.my | | [UNVERIFIED] |
| MY-040 | withholding tax on payments to non-residents | ITA 1967 s.109, s.109B; DTA may reduce | Royalties 10%; technical service fees 10%; contract payments (services) 10%; interest 15% (dialysis overlap source: 15% to 25% on foreign services and interest); non-resident employees flat 30% on employment income | Current | hasil.gov.my | | [UNVERIFIED] |
| MY-041 | income tax filing penalties | ITA 1967 | CP204 estimate and return late: RM200 per day plus 10% penalty on tax, estimated tax raised; CP204 shortfall: 10% penalty where estimate understated by more than 30%; late return: minimum RM200, maximum RM20,000 plus 300% surcharge on unpaid tax | Current | hasil.gov.my | | [UNVERIFIED] |
| MY-042 | SOCSO contribution by employee category | Employees' Social Security Act 1969 | Malaysian or PR, under 60 (employment injury plus invalidity): employer about 1.75%, employee about 0.5%; Malaysian or PR, 60 or over (employment injury only): employer about 1.25%, employee 0%; foreign workers (employment injury only): employer about 1.25%, employee 0.5%. Ceiling per MY-007 | Current | perkeso.gov.my | | [UNVERIFIED] |
| MY-043 | EPF foreign workers (mandatory) | EPF Act 1991 (as stated in seven pack sources) | 2% employer plus 2% employee, mandatory for non-citizen workers with a valid work pass (domestic workers excluded) from October 2025 wages (November 2025 contribution); previously optional at RM5 per month. Conflicts with MY-006: see MY-C12 | 01-Oct-2025 | kwsp.gov.my | | [UNVERIFIED] |
| MY-044 | EPF, SOCSO and PCB late payment penalties | EPF Act 1991 s.43, s.47, s.48; ESSA 1969; ITA 1967 | EPF: 10% of overdue contribution, or 6% per annum dividend foregone, plus criminal penalty (RM20,000 or 6 years per s.47/48; imprisonment up to 3 years per s.43: sources differ); SOCSO: 6% per annum on outstanding amount (see MY-030 for fines); PCB late remittance: 10% of amount due. Remittance date per MY-010 | Current | kwsp.gov.my; perkeso.gov.my; hasil.gov.my | | [UNVERIFIED] |
| MY-045 | HRD Corp levy | Pembangunan Sumber Manusia Berhad Act 2001 | 1% of monthly wages of Malaysian employees where the employer has 10 or more Malaysian employees (manufacturing and healthcare); 0.5% where fewer than 10 but registered | Current | hrdcorp.gov.my | | [UNVERIFIED] |
| MY-046 | foreign worker levy, manufacturing | Immigration Department levy schedule (as stated in diecast source) | 2025: unskilled RM1,850 per year; semi-skilled RM1,250 per year; skilled RM750 per year | 2025 | jtksm.mohr.gov.my | | [UNVERIFIED] |
| MY-047 | Employment Act penalties | Employment Act 1955 s.102 | RM10,000 per offence (first offence); RM20,000 (repeat offence); employer non-compliance generally fine up to RM10,000 per offence | Current | mohr.gov.my | | [UNVERIFIED] |
| MY-048 | OSHA penalties | OSHA 1994 as amended by Act A1648 (2022) | Individual: up to RM500,000 and/or 15 years (diecast and calendar sources; LMW and MKPC sources state 5 years: see MY-C16); body corporate: up to RM1,000,000; accident not reported to DOSH: fine up to RM10,000 | Current | dosh.gov.my | | [UNVERIFIED] |
| MY-049 | Environmental Quality Act penalties | Environmental Quality Act 1974 | Scheduled waste and unlicensed medical waste disposal: fine up to RM500,000 and/or 5 years | Current | doe.gov.my | | [UNVERIFIED] |
| MY-050 | private healthcare licensing and registration penalties | Private Healthcare Facilities and Services Act 1998 (Act 586) s.6, s.13; clinic registration s.4, s.26; Poisons Act; CDCR 1984 s.12 | Operating without licence: fine up to RM300,000 and/or 6 years (calendar source) or 10 years (licensing source): see MY-C17; failure to comply with licence conditions: up to RM50,000; false information to CKAPS: up to RM100,000; clinic operating without registration: up to RM300,000 and 3 years; breach of registration conditions or hours: up to RM50,000 and 2 years; unregistered product dispensed: up to RM50,000 per product per offence; Medicine Price Display Order P.U.(A) 141/2025: up to RM100,000 corporate (enforcement stayed per clinic source) | Current | moh.gov.my | | [UNVERIFIED] |
| MY-051 | PDPA penalties | PDPA 2010 as amended 2024 | Maximum fine RM1,000,000 (2025 amendment, per clinic sources); failure to notify a breach within 72 hours: up to RM500,000; processing without consent: up to RM300,000 and/or 2 years | 2025 | pdp.gov.my | | [UNVERIFIED] |
| MY-052 | Companies Act filing penalties | Companies Act 2016 s.259 and annual return | Audited accounts filing: fine up to RM50,000 (calendar source) or RM500,000 (s.259, clinic source); annual return: RM50,000 | Current | ssm.com.my | | [UNVERIFIED] |
| MY-053 | MACC s.17A penalty | MACC Act 2009 s.17A | Commercial organisation: fine not less than 10 times the gratification or RM1 million, whichever is higher; officer: imprisonment up to 20 years | Current | sprm.gov.my | | [UNVERIFIED] |
| MY-054 | immigration and passport penalties | Immigration Act 1959/63 s.55E; Passports Act 1966 s.12A | Employing a worker with an expired visit pass (temporary employment): fine up to RM10,000 per worker and up to 12 months; employer retaining a passport: fine up to RM5,000 and/or 2 years | Current | imi.gov.my | | [UNVERIFIED] |
| MY-055 | Singapore GST rate (benchmark only) | Singapore GST Act (as stated in clinic benchmarking source) | 9% on private healthcare | Current | iras.gov.sg | | [UNVERIFIED] |

## Conflicts to resolve
| id | topic | values in source skills | action for validator |
|---|---|---|---|
| MY-C7 | Minimum wage RM1,700 effective date (RESOLVED in part: 01-Feb-2025 and 01-Aug-2025 apply to different employer classes; 01-Feb-2024 is not valid) | 01-Feb-2024 (healthcare-dialysis source); 01-Feb-2025 for 5 or more employees and 01-Aug-2025 for fewer than 5 (MKPC source); 01-Aug-2025 (HR and clinical-dialysis sources) | Confirm Minimum Wages Order 2024 gazette and its commencement by employer size |
| MY-C8 | Privacy statute name | 'PDPA 2024' versus 'PDPA 2010 (Amendment 2024)' | Use PDPA 2010 as amended 2024 once confirmed |
| MY-C9 | Service tax rate for manufacturers | 6% in the fieldwork quick reference versus 8% general in the LMW source | Confirm which rate applies to the entity's taxable services |
| MY-C10 | Sabah and Sarawak | Employment Act applies to Peninsular Malaysia and Federal Territories only | Confirm whether any group site is in Sabah or Sarawak (labour ordinances apply instead) |
| MY-C11 | EIS contribution rate | MY-009 states 0.4% employer plus 0.4% employee (HR source); seven other pack sources state 0.2% plus 0.2% | Confirm the rate on perkeso.gov.my and correct MY-009 or the pack text |
| MY-C12 | EPF for foreign workers | MY-006 states voluntary (HR source); MKPC, LMW, clinic and dialysis sources state mandatory 2% plus 2% from Oct 2025 | Confirm against KWSP notices of Oct 2025 and correct MY-006 |
| MY-C13 | Employment Pass Category III salary band | MY-013 states Cat III RM3,000 to RM4,999; the diecast-stamping reference states Cat III minimum RM5,000 from Jun 2026 | Confirm against ESD notices |
| MY-C14 | SST registration threshold | MY-031: RM500,000 (manufacturers; healthcare overlap) versus RM1,500,000 (clinic source) | Confirm on mysst.customs.gov.my for the entity's taxable activity |
| MY-C15 | SME corporate tax rate | MY-037: 17% on first RM600,000 (MKPC), 15% on first RM150,000 (diecast, dialysis overlap), 17% on first RM150,000 (dialysis tax) | Confirm against Schedule 1 ITA and the Finance Act for the year of assessment |
| MY-C16 | OSHA individual penalty term | MY-048: 15 years (diecast, calendar) versus 5 years (LMW, MKPC, dialysis sources) | Confirm against OSHA 1994 as amended by Act A1648 |
| MY-C17 | PHFSA unlicensed operation term | MY-050: 6 years (calendar) versus 10 years (licensing reference) | Confirm against Act 586 s.6 |

## Open dependencies
- Which Malaysian entity (MKPC, Erawan LMW, Nephrocare, other) and state each engagement covers is not supplied in the source skills; the pack must not assume it.
- Act 446 deduction cap is state-specific; obtain the gazette for the entity's state.
- Clinical benchmarks (for example Kt/V) are not statutory and are kept in the sector reference files, not in this register.
