> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- Consumable Supply Chain
- Inventory Accounting — MFRS 102
- Full Inventory Reconciliation Template
- Dialyser Reuse — Audit Control
- Physical Inventory Count — Procedure
- Vendor Assessment — FMC as Sole Supplier


# Inventory, COGS & Consumable Management Reference — Dialysis Operations

## Consumable Supply Chain

### FMC Supply Model (PPT Agreement)

Under both PPT 2025/112 and PPT 2026/114, consumables are supplied exclusively by FMC.

**Order process:**
1. CUSTOMER raises Purchase Order (PO) — minimum 2 weeks in advance (Clause 6.3)
2. PO must specify PPT contract number (PPT 2025/112 or PPT 2026/114)
3. FMC delivers within 5 Working Days of confirmed PO (Clause 5.3)
4. GRN signed on delivery — quantity recorded by FMC at Premises (Clause 6.4)
5. Monthly reconciliation: FMC delivery records vs CUSTOMER GRNs

**Key compliance controls:**
- CUSTOMER cannot order from non-FMC suppliers without FMC written consent (Clause 6.1(v))
- Citrosteril: ONLY authorised disinfectant; any substitution = breach
- Diasafe filter: mandatory on all FMC machines; replacement triggered by machine notification
- Consumables not destroyed without FMC written authorisation (Schedule V Clause 2.4)

---

## Inventory Accounting — MFRS 102

**Classification:** Consumables = Inventories (current assets)
**Valuation:** Lower of cost and net realisable value (NRV)
**Cost formula:** Weighted Average or FIFO — consistently applied; disclose policy in notes

**Expiry date management (FIFO required):**
- Dialysers, bloodlines, dressing sets: expiry date on each box
- FIFO = oldest stock issued first = minimises expired write-offs
- `[INS]` GRN receipt date vs issuance date: must be chronological (older lots issued first)

**Write-off policy:**
- Near-expiry (< 3 months): write down to NRV (estimated selling price minus costs to sell)
- Expired: write off fully; FMC authorisation required before disposal
- Damaged on receipt: return to FMC per Clause 6.7 within 3 months; must be unopened/sealed

---

## Full Inventory Reconciliation Template

### Per Consumable Line — Monthly Reconciliation

```
CONSUMABLE: _________________ | Month: _________ | Centre: _________________
══════════════════════════════════════════════════════════════════════════════
Opening Stock (units):                     ___  [from prior month closing]
+ Receipts from FMC (per GRN):            ___  [3-way match: PO/GRN/Invoice]
- Theoretical usage (per treatment ratio): ___  [Treatments × Consumption Ratio]
= Theoretical Closing Stock:               ___
Physical Count (actual):                   ___  [PHY evidence]
Variance (Physical − Theoretical):         ___  [MUST investigate if >±5%]
Variance %:                                ___  %

If Positive Variance (Physical > Theoretical):
  → Possible over-receipt or usage below expected (good if intentional; suspect if unexplained)
If Negative Variance (Physical < Theoretical):
  → Possible diversion / theft / unrecorded consumption / unrecorded GRN returns
══════════════════════════════════════════════════════════════════════════════
```

### COGS Per Treatment — Reconciliation

| Consumable | Consumption Ratio | Units Used | Cost per Unit (RM) | COGS (RM) |
|-----------|------------------|-----------|-------------------|----------|
| Dialyser | 1 per 10 treatments | | | |
| Concentrate Part A | 1 per 3 treatments | | | |
| Bibag 500g | 1 per treatment | | | |
| Diasafe Plus | 1 per 100 treatments | | | |
| Citrosteril 5L | 1 per 150 treatments | | | |
| Bloodline 3-in-1 | 1 per treatment | | | |
| AVF Needles | 2 per treatment | | | |
| HD Dressing Set | 1 per treatment | | | |
| **TOTAL COGS** | | | | |
| **COGS per Treatment** | | | | |
| **PPT Rate** | | | RM 56.00 / RM 42.75 | |
| **Variance (PPT rate vs COGS)** | | | | |

**Note:** Under PPT model, COGS = PPT payment to FMC (all consumables bundled). The above reconciliation validates that actual consumption matches the PPT schedule ratios — deviations indicate either wastage, pilferage, or reuse ratio issues.

---

## Dialyser Reuse — Audit Control

**PPT Schedule IV specification:** "One piece per treatment (based on 9 reuses and 1 first use)"
**Maximum reuse per dialyser:** 10 uses total (1 first use + 9 reuses)
**FMC policy (Clause 6.1(v)):** Diasafe filter mandatory; disinfection per schedule

### Reuse Validation Test

```
Per Machine, Per Month:
  Treatments performed:              ___
  Theoretical dialysers consumed:    ___ = Treatments ÷ 10 (if all dialysers reach 9 reuses)
  Actual dialysers consumed (GRN):   ___
  Variance:                          ___

If Actual > Theoretical (e.g., actual = treatments ÷ 7 instead of ÷ 10):
  → Average reuses = Treatments ÷ Actual Dialysers = ___ (should be ~10)
  → If < 8: premature disposal / reuse falsification → consumable diversion or fraud risk
  → If > 10: exceeding maximum reuse limit → patient safety risk + PPT breach

Patient-level reuse register (for sample of 10 patients):
  Patient ID | Month | Dialyser Serial/Batch | Reuse Count (1–10) | Signed by RN
```

---

## Physical Inventory Count — Procedure

**Frequency:** Minimum quarterly; surprise counts at high-risk centres
**Scope:** All FMC consumables at all centres

**Count procedure:**
1. Notify centre on day of count only (surprise element)
2. Freeze all issuances during count
3. Count team: internal audit (≥2 persons) + centre staff (witness only, do not count)
4. Count all consumable categories using pre-printed count sheets
5. Identify and segregate expired, damaged, and near-expiry items
6. Reconcile to system closing stock
7. Obtain signature of centre manager on count sheet
8. Report variance to Finance and Internal Audit

**High-risk indicators requiring priority count:**
- Consistent positive variance in theoretical reconciliation
- High dialyser turnover (low reuse ratio)
- Centre located away from HQ (limited supervision)
- Recent staff changes (centre manager / store keeper)
- Benford anomaly in consumable purchase invoice amounts

---

## Vendor Assessment — FMC as Sole Supplier

Under both PPT agreements, FMC is the exclusive consumable supplier. Vendor assessment framework:

| Area | Audit Test |
|------|-----------|
| Delivery timeliness | PO date vs delivery date vs required 5-day lead time (Clause 5.3) |
| Quantity accuracy | PO qty vs GRN qty vs Invoice qty — 3-way match |
| Product quality — defects | Complaint log vs Schedule V; resolved within 5 Working Days |
| Cold chain (if applicable) | Temperature-sensitive items: delivery condition on GRN |
| Recall management | FMC recall notifications vs Nephrocare response time |
| Adverse event reporting | Incidents reported within 24 hours per Schedule V Clause 3.2 |
