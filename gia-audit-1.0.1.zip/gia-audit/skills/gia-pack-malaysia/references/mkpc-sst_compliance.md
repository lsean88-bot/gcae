> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- SST (Sales & Service Tax) — Current Position (2025)
- Income Tax — Corporate Rate & Incentives
- Transfer Pricing (ITA s.140A, TP Rules 2012, LHDN TP Guidelines 2024)
- Withholding Tax (ITA s.109)


# SST, Income Tax, Incentives & Transfer Pricing Reference — MKPC Malaysia

## SST (Sales & Service Tax) — Current Position (2025)

### Sales Tax Act 2018 — Key Rates (Sales Tax Rate Order 2025, effective 1 Jul 2025)
- **Default rate:** per [MY-017]
- **Reduced rate [MY-017]:** specified goods in Schedule — verify automotive parts HS classification
- **Exempt:** Goods listed in Schedule A (many industrial raw materials, exported goods)

### MKPC-Specific SST Classification

| Product Type | HS Chapter | SST Rate | Basis |
|-------------|-----------|---------|------|
| Die cast parts (Al/Zn) — sold to Perodua/Denso (domestic) | Chapter 87 (auto parts) or Chapter 73 (iron/steel articles) | **Verify against current tariff** — likely the default or reduced rate [MY-017] | RMCD tariff schedule |
| Stampings — sold domestic | Chapter 73 or 87 | **Verify** | RMCD tariff schedule |
| Assemblies — sold domestic | Chapter 87 | **Verify** | RMCD tariff schedule |
| Parts exported | All chapters | **Exempt** (s.21 STA 2018, Schedule A) | STA 2018 |
| Raw material inputs (Al ingots, steel coil) | Chapter 76, 72 | Exempt (manufacturer exemption, Schedule C) | STO(E) 2018 Schedule C |

**Critical:** Always verify HS code and applicable rate at `mysst.customs.gov.my` or official RMCD tariff. Do not rely on prior-year rate — Sales Tax Rate Order 2025 changed rates from 1 Jul 2025.

### Schedule C Manufacturing Exemption
- Registered manufacturers may purchase/import raw materials, components, packaging exempt from Sales Tax
- Apply via MySST portal for exemption certificate
- Eligible: steel coil, Al ingots, Zn ingots, welding consumables, mould release agents (where used in manufacturing process)
- **Audit test:** `[INS]` Schedule C exemption certificate; verify inputs claimed match actual production materials; flag inputs not eligible for exemption

### Service Tax (Service Tax Act 2018)
- **Rate from 1 Jul 2025:** per [MY-018] (increased from the earlier rate)
- MKPC as a manufacturer typically pays service tax on:
  - **Import of technical services** from Japanese parent/Denso (reverse charge; self-account at the [MY-019] rate)
  - **Logistics/freight services** ([MY-018] from 1 Jul 2025)
  - **Financial services** ([MY-018] from 1 Jul 2025 — banking fees, LC charges)
- **Audit test:** `[INS]` invoices from foreign service providers; `[REC]` verify service tax self-accounted ([MY-019]) in SST-02 Table 2

### e-Invoice (MyInvois) — Phase Implementation

| Phase | Turnover | Effective Date |
|-------|---------|--------------|
| Phase 1 | per [MY-034] | 1 Aug 2024 |
| Phase 2 | per [MY-034] | 1 Jan 2025 |
| **Phase 3** | **per [MY-020]** | **1 Jul 2025** |
| Phase 4 | All businesses | 1 Jan 2026 |

**Finance Act 2024 — Deductibility Rule:**
From 1 Jan 2025: Expenses above the per-transaction threshold in [MY-035] must be supported by validated MyInvois e-invoice to be deductible for income tax purposes. Supplier must submit to MyInvois → validated with UUID/QR code → MKPC retains validated e-invoice.

**Audit test:** `[CON]` MyInvois portal — verify all MKPC-issued invoices have validated status; `[CON]` MyInvois portal — verify top 20 purchase invoices by value are validated (for deductibility).

## Income Tax — Corporate Rate & Incentives

### Corporate Tax Rate
- **Standard rate:** per [MY-037] (Income Tax Act 1967)
- **SME rate:** per [MY-037] (conditions on paid-up capital and group control as stated there)

### Pioneer Status (PS) — Promotion of Investments Act 1986 (PIA)
- **Tax relief:** statutory income exempted per [MY-038]
- **Qualifying activities:** Automotive component manufacturing is a promoted activity
- **MIDA approval required**; conditions include: employment of Malaysian staff, local content, minimum capex
- **Audit test:** `[INS]` MIDA PS approval letter + conditions; `[INS]` pioneer income segregation in management accounts; `[REC]` verify only pioneer-qualifying income enjoys exemption; non-pioneer income taxed at the standard rate [MY-037]

### Investment Tax Allowance (ITA)
- **Alternative to PS:** ITA on qualifying capex ([MY-038])
- **Qualifying capex:** Plant, machinery, factory used in promoted activity
- **Audit test:** `[INS]` ITA schedule; `[INS]` qualifying asset invoices; `[REC]` recalculate ITA claim; verify assets still in use

### Reinvestment Allowance (RA) — Schedule 7A ITA
- **For existing manufacturers** reinvesting in expansion/modernization/diversification
- **RA** on qualifying capex ([MY-038])
- **15-year period** from first claim year
- **Audit test:** `[INS]` RA schedule (last 15 years); `[INS]` qualifying capex invoices; verify period not expired; `[REC]` RA claim quantum

### MIDA New Incentive Framework (NIF) — January 2026
- MIDA introduced NIF guidelines dated 15 Jan 2026 for new manufacturing investment
- **Tiered approach:** NIA Scorecard-based; outcome-based incentives
- Key criteria: Product complexity, R&D %, technology level, 4IR adoption, high-skilled workers %, median salary
- OECD Pillar Two: If MK Tron Group consolidated revenue exceeds the [MY-039] threshold → Global Minimum Tax applies (Qualified Domestic Minimum Top-up Tax — QDMTT)
- **Audit test:** `[INS]` any NIF application submitted/approved; verify conditions compliance

## Transfer Pricing (ITA s.140A, TP Rules 2012, LHDN TP Guidelines 2024)

### When TP Applies to MKPC
TP documentation required if MKPC has transactions with:
- Japanese parent company (if any)
- Denso Manufacturing Malaysia (if related — check shareholding)
- Any other MK Tron Group entity (inter-company sales, management fees, royalties, loans)

### Documentation Threshold (LHDN TP Guidelines 2024)
- Related-party transactions above the [MY-039] threshold → TP documentation mandatory
- Contemporaneous documentation required (prepared before/at filing date — not after LHDN inquiry)
- **Form CP207** (advance pricing agreement) available for certainty

### Common TP Issues in Malaysian Auto Parts
| Issue | Risk | Test |
|-------|------|------|
| Royalty/technical fee to Japanese parent | Arm's length rate? | `[REC]` benchmarked royalty % vs. published comparable transactions |
| Management fee to MK Tron holding company | Basis of allocation arm's length? | `[INS]` management fee agreement; `[REC]` cost + reasonable mark-up |
| Intercompany loan interest | s.140C thin cap; arm's length rate | `[REC]` interest rate vs. BNM base rate + arm's length spread |
| Sales to related OEM entity at below-market price | Understated revenue | `[REC]` APA price with related OEM vs. independent OEM equivalent |

### Thin Capitalisation (ITA s.140C)
- **3:1 debt-to-equity ratio** for related-party borrowings (verify current ITA s.140C threshold)
- Excess interest not deductible
- **Audit test:** `[REC]` total related-party debt ÷ equity from audited FS; flag if ratio >3:1

## Withholding Tax (ITA s.109)

| Payment Type | WHT Rate | Remarks |
|------------|---------|---------|
| Royalties | [MY-040] | Standard; may be reduced by Double Tax Agreement (DTA) |
| Technical services fees | [MY-040] | DTA may reduce; verify applicable treaty |
| Interest to non-resident | [MY-040] | Standard; DTA may reduce |
| Contract payments to non-resident | [MY-040] | ITA s.109B |

**Malaysia–Japan DTA:** Verify current reduced WHT rates under Malaysia-Japan DTA for royalties and technical fees payable to Japanese parent or Denso Japan.

**Audit test:** `[INS]` all foreign vendor invoices for royalties, technical fees, interest; `[REC]` WHT deducted at correct rate; `[CON]` LHDN e-WHT portal for remittance confirmation.
