> Case figures from a prior clinic engagement were moved to example-2026-Q1.md (illustrative, dated).
## Contents
[case figure moved to example-2026-Q1.md]
- E2 — MFRS 9 Expected Credit Loss Framework
- E3 — MFRS 124 Related Party Disclosure Requirements
- E4 — Transfer Pricing Risk (Interest-Free Interco Loans)
- E5 — Companies Act 2016: Director & Related Party Obligations
- E6 — Audit Tests: Related Party & Interco


> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.

# Reference E — Intercompany Receivables, Related Party & Corporate Structure

[case figure moved to example-2026-Q1.md]

[case figure moved to example-2026-Q1.md]
|--------|-------------|---------------|-------------------------------|--------------------------|
| Perfect Healthcare Sdn Bhd | Parent / audited entity | — | — | 10/11 |
| Perfect Physio Sdn Bhd | Subsidiary (investment RM 90,000) | RM 90,000 | RM 739,618 | 3/7 (57% vacant) |
| Perfect Healthy Cuisine Sdn Bhd | Subsidiary (investment RM 90,000) | RM 90,000 | RM 844,615 | N/A |
| Perfect Dental Sdn Bhd | Subsidiary (investment RM 60,000) | RM 60,000 | RM 888,659 | 5/8 (37.5% vacant) |
[case figure moved to example-2026-Q1.md]

[case figure moved to example-2026-Q1.md]
**Total investment in subsidiaries: RM 240,000**
**Total related-party exposure: RM 2,712,892**

---

## E2 — MFRS 9 Expected Credit Loss Framework

### Stage Classification
| Stage | Condition | Measurement |
|-------|-----------|-------------|
| Stage 1 | No significant increase in credit risk since origination | 12-month ECL |
| Stage 2 | Significant increase in credit risk | Lifetime ECL |
| Stage 3 | Credit-impaired (objective evidence of impairment) | Lifetime ECL — interest on net carrying amount |

### ECL Calculation: PD × LGD × EAD
- **PD** (Probability of Default): Estimate based on borrowing entity's financial health, trading status, industry
- **LGD** (Loss Given Default): For unsecured interco loans to start-up subsidiaries, 40–70% is a conservative estimate
- **EAD** (Exposure at Default): Outstanding balance + undrawn commitment

[case figure moved to example-2026-Q1.md]
| Entity | Stage Indicator | ECL Trigger |
|--------|----------------|-------------|
| Perfect Physio | Balance unchanged YoY + 57% headcount vacancy + no PIC | 🔴 Stage 2 or 3 — significant credit risk increase |
| Perfect Dental | 37.5% vacancy; balance unchanged YoY | 🟠 Stage 2 — assess |
| Perfect Healthy Cuisine | Balance increased RM 28K (net borrowing); no revenue data | 🟠 Stage 2 — assess |

### ECL Workpaper Template
```
Entity:
Carrying amount (EAD):
Last financial statements reviewed: [date / "Not obtained"]
Revenue of borrower: RM
Profit/(Loss) of borrower: RM
Net assets of borrower: RM
Days outstanding since first advance:
Repayments received in past 12 months: RM
PD estimate: % [document basis]
LGD estimate: % [document basis]
ECL = PD × LGD × EAD = RM
Stage: 1 / 2 / 3
Provision required: RM
```

---

## E3 — MFRS 124 Related Party Disclosure Requirements

Transactions and balances to disclose in annual financial statements:
1. Nature of each related-party relationship
2. Amount of transactions during the period
3. Outstanding balance (payable or receivable) at period end
4. Terms (interest rate, repayment, security)
5. Provision for doubtful debts on related-party balances
6. Director remuneration — aggregate (Companies Act 2016 s.228 + s.230)

[case figure moved to example-2026-Q1.md]
[case figure moved to example-2026-Q1.md]
[case figure moved to example-2026-Q1.md]
- All interco loans — disclose interest rate (or nil if interest-free, then Transfer Pricing risk applies)

---

## E4 — Transfer Pricing Risk (Interest-Free Interco Loans)

**Law:** Income Tax Act 1967 s.140A; Income Tax (Transfer Pricing) Rules 2012

[case figure moved to example-2026-Q1.md]
1. Deem interest income at arm's length rate (benchmark: 12-month KLIBOR or BNM OPR-linked rate)
[case figure moved to example-2026-Q1.md]
3. Apply the surcharge per [MY-039] on additional tax assessed if Transfer Pricing documentation is absent

**Mitigation:** Prepare Transfer Pricing documentation per ITA s.140A — document arm's length basis for nil interest (e.g., parent-subsidiary nature, equity relationship, management control). OR charge a market-rate interest and collect.

---

## E5 — Companies Act 2016: Director & Related Party Obligations

| Section | Obligation |
|---------|-----------|
| s.217 | Director must disclose interest in contracts with company — written notice to Board |
| s.218 | Director must not use company property/information for personal benefit |
| s.223 | Prohibition on loans to directors — exceptions: director's ordinary salary advance, director-owned company with shareholder approval |
| s.228 | Related-party transactions — director with material interest must abstain from voting |
| s.245 | Proper books of accounts — must give true and fair view |

[case figure moved to example-2026-Q1.md]
- Was the RM 3M cash injection from the director personally?
- Was the director loan formally set off against the share subscription?
- Is there a signed settlement agreement?
- Has SSM Form 24A (return of allotment) been filed within 14 days?

---

## E6 — Audit Tests: Related Party & Interco

| Test | Evidence | Assertion |
|------|---------|-----------|
| Interco loan agreements — signed, dated, terms specified | `[INS]` loan agreements | RO, CO |
| Interest rate charged (or nil with TP documentation) | `[INS]` loan terms | AC |
| Repayment movements in past 12 months | `[REC]` ledger movement analysis | CO |
| Management fee and rental income supported by formal agreements | `[INS]` management fee agreement, tenancy agreement | RO, OC |
| MFRS 9 ECL assessment completed and documented | `[INS]` ECL workpaper | VA |
| MFRS 124 disclosures in draft financial statements | `[INS]` FS draft notes | DI |
| Share allotment — board resolution + SSM Form 24A | `[INS]` board minutes + `[CON]` SSM portal | OC, CP |
| Director loan/advance — board approved and disclosed | `[INS]` board minutes | AU, DI |
