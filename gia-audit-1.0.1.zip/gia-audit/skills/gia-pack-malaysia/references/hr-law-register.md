> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.

# Malaysia HR Audit — Law Register

> Refresh this register at audit commencement against primary sources.
> Primary sources: MoHR gazettes, EPF/PERKESO/LHDN circulars, IMI/ESD notices, state notifications.

## Law Register Table

| Law ID | Law / Instrument | Provision / Ref | Effective From | Jurisdiction | Coverage Criteria | Key Obligation | Verify At Audit |
|--------|-----------------|-----------------|---------------|--------------|-------------------|----------------|-----------------|
| EA1955_A1651 | Employment Act 1955 (Act 265) as amended by Act A1651 | All provisions | 2023-01-01 | Peninsular Malaysia + Federal Territories | All employees (scope expanded; no longer limited to RM2,000/month) | 45h/week cap; 98-day maternity; 7-day paternity; flexible work; enhanced termination protections | Confirm no Sabah/Sarawak employees (use state ordinances if yes) |
| MINWAGE_2024 | Minimum Wages Order 2024 | National minimum wage | 2025-08-01 | Malaysia (all states) | All covered employees | Basic wage at or above the national minimum wage [MY-003] | Confirm if subsequent order issued; check MoHR gazette |
| EPF_RATE_CUR | EPF Act 1991 — Contribution Schedule | Third Schedule | Current | Federal | All EPF-eligible employees | Rates per [MY-004], [MY-005], [MY-006]; foreign workers see [MY-043] | Confirm current schedule via KWSP circular; rates subject to Budget amendments |
| SOCSO_EIS_CUR | Employees' Social Security Act 1969 + Employment Insurance System Act 2017 | Contribution Schedule | per register (ceiling change) | Federal | All SOCSO/EIS-eligible employees | Insurable wage ceiling [MY-007]; SOCSO rates [MY-008]; EIS rate [MY-009] | Confirm ceiling in payroll system updated to the register ceiling; verify via PERKESO circular |
| PCB_TABLE_CUR | Income Tax Act 1967 — PCB/MTD Schedule | s.107 and PCB schedule | Current tax year | Federal | All resident employees with taxable income | Monthly PCB per LHDN schedule; remit by 15th; employer liable for under-deduction | Obtain current year PCB schedule from LHDN; confirm payroll system using correct year |
| ACT446_STD | Accommodation and Amenities Act 1990 (Act 446) | Core standards | 2020-09-01 (federal order); state notifications vary | States where in force | Employer-provided worker accommodation | Minimum space, bedding, sanitation, kitchen, fire safety; registration with MoHR required | Confirm Act 446 in force in relevant state; obtain state notification |
| ACT446_CAP | Act 446 — Accommodation Deduction Cap | Gazette notification (state-specific) | Varies by state | State-specific | Workers in employer accommodation with wage deduction | Monthly deduction ≤ gazetted cap (commonly cited RM150/month where gazetted — confirm state-specific amount); written consent required; shown on payslip | MANDATORY: obtain current gazette for entity's state before testing |
| EP_2026 | Employment Pass Policy — ESD/MOHA | EP Category I–III Salary Thresholds | 2026-06-01 | Federal | EP applications and renewals on/after 1 Jun 2026 | Cat I, Cat II and Cat III salary bands per [MY-013] | Verify via ESD/MOHA notices; confirm any sector-specific variations (e.g., MDEC Digital Hub) |
| IMMI_VPTE | Immigration Act 1959/63 — Temporary Employment Visit Pass | VP(TE) conditions | Current | Federal | Foreign workers in approved sectors | Sector-specific permits; employer and sector must match permit; no off-permit employment | Verify approved sectors for each entity; check IMI portal for any quota or levy rate changes |
| CLRA_1966 | Contract Labour (Restriction and Abolition) Act 1966 | All provisions | Current | Federal | Employers using contract/outsourced labour | Principal employer obligations; contractor registration; worker rights maintained | Confirm applicability if entity uses third-party manpower suppliers |
| MACC_17A | MACC Act 2009 s.17A | Corporate Liability | 2020-06-01 | Federal | All commercial organisations | Corporate liability for corrupt acts by associated persons; adequate procedures defence | Confirm entity has s.17A compliance programme; review manpower agent and recruitment payments |
| PDPA_2024 | Personal Data Protection Act 2010 (Amdt Act 2024) | All provisions incl. Amdt | 2025-06-01 (breach notification) | Federal | Data processors handling personal data | 72h breach notification to PDPC; DPO appointment (if threshold met); consent for sensitive HR data | Confirm DPO appointment status; verify breach notification protocol in place |
| OSHA_2022 | Occupational Safety and Health Act 1994 (Amdt 2022) | Working time and safety | 2022 | Federal + States | All employers | Working time compliance has OSH implications (fatigue); safety-critical roles | Apply to MKPC factory and Erawan cylinder operations; DOSH inspection records |
| FACTORIES_ACT | Factories and Machinery Act 1967 | Working hours in factories | Current | Federal | Factory operations | Shift duration and OT limits in registered factories; certificates of fitness | Apply to MKPC, Erawan; cross-reference with EA working time |

---

## Decision Tree — Which Law Applies?

**Step 1 — Worksite jurisdiction?**
- Peninsular Malaysia / Federal Territory → EA 1955 applies
- Sabah → Sabah Labour Ordinance (not EA 1955); flag scope limitation
- Sarawak → Sarawak Labour Ordinance; flag scope limitation

**Step 2 — Worker category?**
- Malaysian citizen/PR, local contract → EA 1955 full scope; EPF/SOCSO/EIS/PCB
- Foreign worker (VP(TE)) → EA 1955 + Immigration Act + Act 446 (if employer accommodation); SOCSO (EI only, employer); EPF voluntary
- Expatriate (EP holder) → EA 1955 + EP salary policy; EPF (if Malaysian PR / opted-in); SOCSO voluntary
- Contract clinician / visiting consultant → PCB s.107C; SOCSO voluntary; EPF voluntary; employment classification risk

**Step 3 — Effective date mapping**
- Hire/increment after 1 Jan 2023 → EA 1955 as amended (Act A1651)
- Salary effective after the minimum wage order's effective date → MWO 2024 floor [MY-003]
- SOCSO/EIS contributions from the ceiling's effective date → ceiling [MY-007]
- Accommodation deductions → state gazette date for Act 446 cap (confirm state)
- EP applications/renewals from 1 Jun 2026 → new EP salary thresholds

**Step 4 — Document in working paper**
For each test: Law ID | Effective date logic | Jurisdiction confirmed | Worker type | Evidence | Conclusion
