> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- Agreement Summary
- Monthly Treatment Commitment Schedule
- Consumable Consumption Ratios — Audit Verification
- Contract Residual Value (CRV) Calculation
- Key Audit Tests — PPT Compliance
- Fraud Red Flags — PPT Specific


# PPT Agreement Audit Reference — FMC / Nephrocare

## Agreement Summary

| Item | PPT 2025/112 (1st Agreement) | PPT 2026/114 (2nd Agreement) |
|------|------------------------------|------------------------------|
| Contract number | PPT 2025/112 | PPT 2026/114 |
| Signed date | 16 Jan 2026 | [blank — undated] |
| Machines (E1) | 84 × Fresenius 4008S Next Gen | 34 × Fresenius 4008S Next Gen |
| Centres covered | 7 PERKESO centres | 12 centres (mixed) |
| Final Installation Date | 31 Dec 2026 | 6 months from 1st unit installation |
| Contract Period expiry | 31 Mar 2033 (7 yrs 3 months from 31 Dec 2026) | Later of: latest Commitment Period expiry or 7 yrs 3 months from Final Installation Date |
| Commitment Period per machine | 7 years from Commitment Start Date | 7 years from Commitment Start Date |
| Total Contract Commitment | 411,264 treatments (84 machines) | 411,264 treatments (34 machines) |
| Machine Treatment Commitment | 4,896 per machine (7 years) | 12,096 per machine (7 years) |
| PPT rate | RM 56.00 per treatment | RM 42.75 per treatment |
| FX baseline | EUR/MYR 4.98 | EUR/MYR 4.98 |
| FX threshold | >6.5% deviation → renegotiate | >6.5% deviation → renegotiate |
| First FX assessment | 31 Dec 2026 | 31 Dec 2026 |
| Late payment charge | 1.0% per month | 1.0% per month |
| Payment terms | 60 days from invoice | 60 days from invoice |
| Price escalation clause | FX + equipment upgrade | FX only |
| 250-machine total commitment | Yes — within 2.5 years of signing (≈ 30 Jun 2028) | PPT 114 machines count towards 250 |
| Penalty for missing 250-machine | PPT rate increases to RM 58.50 | N/A (counted in PPT 112 commitment) |
| Personal guarantors | [named director guarantors] | Same |
| CRV formula | P × Q × 1.25 | P × Q × 1.25 |

## Monthly Treatment Commitment Schedule

### PPT 2025/112 — Per Machine
| Year | Monthly Min | Annual Min | Per 84 Machines/Month |
|------|------------|-----------|----------------------|
| Year 1 | 48 | 576 | 4,032 |
| Year 2–7 | 60 | 720 | 5,040 |
| **7-year total (per machine)** | | **4,896** | **Total: 411,264** |

### PPT 2026/114 — Per Machine
| Year | Monthly Min | Annual Min | Per 34 Machines/Month |
|------|------------|-----------|----------------------|
| Year 1–7 | 144 | 1,728 | 4,896 |
| **7-year total (per machine)** | | **12,096** | **Total: 411,264** |

**Note:** PPT 114 machine commitment is significantly higher per machine (144/month vs 48/month Year 1, 60/month Years 2–7 in PPT 112). This reflects higher utilisation expected from existing established centres.

## Consumable Consumption Ratios — Audit Verification

| Consumable | Theoretical Ratio | Calculation | Benchmark Check |
|-----------|------------------|-------------|----------------|
| Dialyser (HF80S / F60S / F70S / HdF100S) | 1 per 10 treatments (1 first-use + 9 reuses) | Treatments ÷ Dialysers consumed ≈ 10 | < 8: possible reuse falsification; > 12: unlikely |
| Concentrate Part A | 1 canister per 3 treatments | Treatments ÷ Concentrate units ≈ 3 | Significant variance = suspect |
| Bibag 500g | 1 per treatment | Treatments = Bibags used | 1:1 ratio |
| Diasafe Plus filter | 1 per 100 treatments | Treatments ÷ Diasafe ≈ 100 | |
| Citrosteril 5L | 1 per 150 treatments | Treatments ÷ Citrosteril ≈ 150 | |
| Bloodline 3-in-1 | 1 per treatment | Treatments = Bloodlines | 1:1 ratio |
| AVF needles | 2 per treatment | Treatments × 2 = AVF needles | |
| HD Dressing Set | 1 per treatment | Treatments = Dressing sets | 1:1 ratio |

**COGS per treatment (theoretical PPT 112):** RM 56.00 (all consumables bundled in PPT rate)
**COGS per treatment (theoretical PPT 114):** RM 42.75 (all consumables bundled in PPT rate)

## Contract Residual Value (CRV) Calculation

**Formula:** CRV = P × Q × R

Where:
- **P** = Price Per Treatment (RM 56.00 or RM 42.75 as applicable)
- **Q** = Total Contract Commitment less actual treatments completed to date
- **R** = Risk Multiple of 1.25×

**CRV Example — PPT 2025/112 if terminated at Year 1 Month 6:**
- Treatments completed (assumed): 84 machines × 48/month × 6 = 24,192
- Remaining: 411,264 − 24,192 = 387,072
- CRV = RM 56.00 × 387,072 × 1.25 = **RM 27,094,080**

**CRV Example — PPT 2026/114 if terminated early:**
- Similar calculation at RM 42.75 × remaining treatments × 1.25
- Maximum CRV (at inception): RM 42.75 × 411,264 × 1.25 = **RM 21,974,040**

**Combined maximum CRV exposure at inception:** ~RM 49,068,120

## Key Audit Tests — PPT Compliance

### Monthly Reconciliation Workpaper (per agreement)

```
Month: ______  |  Agreement: PPT 2025/112 / PPT 2026/114
─────────────────────────────────────────────────────────
(A) Installed machines this month:               ___
(B) Monthly Treatment Commitment per machine:    ___
(C) Total Monthly Commitment (A × B):            ___
(D) Actual treatments — from PO/invoice:         ___
(E) Monthly shortfall (C − D):                   ___
(F) Shortfall carry-forward from prior months:   ___
(G) Total shortfall to recover this Contract Year: ___
(H) Months remaining in Contract Year:           ___
(I) Treatments needed per remaining month:        ___
```

### Annual Reconciliation
```
Contract Year: ___  |  Agreement: ___
─────────────────────────────────────────────────────────
Annual Treatment Commitment:              ___
Actual treatments purchased (POs):        ___
Yearly Shortfall:                         ___
Penalty payment due (if Yearly Shortfall > 0): RM ___ (within 60 days of FMC notice)
```

### FX Adjustment Monitoring
```
Assessment Date: ___
6-month average EUR/MYR:                  ___
Current Baseline:                         4.98
Variance from baseline:                   ___  %
Threshold:                                6.5%
Action required (if >6.5%):              Negotiate PPT adjustment; sign written amendment
New PPT rate (if adjusted):              RM ___
Effective date of new price:             ___
```

## Fraud Red Flags — PPT Specific

| Flag | Test |
|------|------|
| Treatments claimed to FMC without machine evidence | Machine session log vs PO count |
| PO raised for treatments in advance of actual performance | PO date vs treatment date in patient records |
| Consumable ratio deviated significantly from theoretical | COGS reconciliation per consumable line |
| Machine registered at wrong centre | Asset register vs CKAPS-approved location |
| Equipment subleased to third party without FMC consent | Site visit + inquiry of third parties |
| PPT contract number missing from PO | `[INS]` PO documents — Clause 6.3 requirement |
