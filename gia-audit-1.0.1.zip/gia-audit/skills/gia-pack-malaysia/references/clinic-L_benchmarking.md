> Case figures from a prior clinic engagement were moved to example-2026-Q1.md (illustrative, dated).
## Contents
- L1 — Malaysian Comparators
- L2 — Global Best-in-Class Comparators
[case figure moved to example-2026-Q1.md]
- L4 — Quality & Patient Safety KPIs
- L5 — Benchmarking: Corporate Governance & Compliance


> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.

# Reference L — Benchmarking: Malaysian & Global Private Healthcare

## L1 — Malaysian Comparators

### KPJ Healthcare Berhad (listed, Bursa Malaysia)
Malaysia's largest private hospital group (28 hospitals, ~4,500 beds, FY2023).
- **Revenue per patient day:** ~RM 1,200–1,800 (inpatient); RM 250–400 (outpatient consultation)
- **EBITDA margin:** ~15–18%
- **Net margin:** ~8–12%
- **Revenue per clinic/outpatient visit:** RM 180–350 (KPJ Klinik range)
- **Panel mix:** 55–65% corporate panel/insurance
- **Debtor days:** 35–50 days
- **Staff cost as % of revenue:** 40–48%
- **Digital:** KPJ MyHealth app; MyKad patient identification; telehealth integration (teleconsult launched 2022)
- **Governance:** Listed entity — full Bursa disclosure, RPT committee, audit committee mandatory

### Pantai Holdings / Ramsay Sime Darby
- **Net margin:** ~10–15%
- **Outpatient revenue per visit:** RM 200–600
- **Staff cost %:** 38–44%
- **Key differentiator:** JCI-accreditated hospitals; international patient programme

### Columbia Asia (now Ramsay Sime Darby)
- **Revenue per outpatient:** RM 150–400
- **Panel mix:** 60–70%

[case figure moved to example-2026-Q1.md]
- **Revenue per encounter:** RM 80–200 (panel GP rate)
- **Net margin:** 15–25% (low-overhead GP model)
- **Staff cost %:** 25–35%
[case figure moved to example-2026-Q1.md]

---

## L2 — Global Best-in-Class Comparators

### Mayo Clinic (USA)
- **Revenue:** USD 17B+ (FY2022)
- **Net margin:** ~5–8% (non-profit model)
- **Revenue per outpatient visit:** USD 450–800
- **Quality KPIs:** Top 1 in US News Rankings; Near-zero preventable adverse events
- **Digital:** Electronic Health Record (Epic EMR) — 100% digital; AI-assisted diagnostics; remote patient monitoring
- **Staffing:** Physician-to-patient ratio excellence; no physician bonuses (quality-first model)
- **Governance:** Independent board; comprehensive conflict-of-interest policy; public quality reporting

### Cleveland Clinic (USA)
- **Revenue per encounter:** USD 600–1,200 (specialist)
- **Net margin:** ~4–7%
- **Key metric:** Caregiver engagement score — world benchmark
- **Digital:** AI predictive analytics for patient deterioration; Epic EHR
- **International expansion:** Abu Dhabi, London — SOPs exportable model

### Singapore Health Services (SingHealth) / Raffles Medical Group
- **Raffles Revenue per outpatient:** SGD 200–600 (RM 700–2,100)
- **Net margin (Raffles Medical):** 10–14%
- **SST/GST equivalent:** Singapore GST applies ([MY-055]) to private healthcare
- **PDPA:** Singapore PDPA 2012 — 3-day breach notification (stricter than Malaysia's 72-hour)
- **Quality:** JCI accreditation; ACHS (Australian Council on Healthcare Standards)
- **Telehealth:** MyDoc, Speedoc — fully integrated telehealth ecosystem

### IHH Healthcare Berhad (Singapore/Malaysia dual-listed)
- **Revenue (FY2023):** RM 20B+
- **Net margin:** ~6–9%
- **Revenue per bed per day:** RM 2,000–3,500 (Gleneagles, Pantai premium)
- **EBITDA margin:** 20–25%
- **Digital:** IHH My Health app; integrated HIS (Hospital Information System) across all entities; AI radiology reading (Gleneagles)
- **Governance:** Listed entity, comprehensive ESG reporting, IHH Healthcare Code of Ethics (anti-bribery)

---

[case figure moved to example-2026-Q1.md]

[table moved to example-2026-Q1.md]

---

## L4 — Quality & Patient Safety KPIs

[case figure moved to example-2026-Q1.md]
|-----|-----------|------------------------|------------|
| Patient complaints per 1,000 encounters | <5 | <10 (MOH benchmark) | <2 (JCI) |
| Adverse event reporting rate | 100% of events | 100% per PHFSA | 100% + root cause analysis |
| Drug dispensing error rate | <0.01% | <0.1% | <0.005% (Mayo) |
| Informed consent rate for procedures | 100% | 100% (PHFSA requirement) | 100% |
| Patient satisfaction score | >85% | >80% | >90% (NPS-based) |
| Re-visit rate within 7 days (unplanned) | <5% | <8% | <3% |

---

## L5 — Benchmarking: Corporate Governance & Compliance

[case figure moved to example-2026-Q1.md]
|-----------|-----------------|--------------------|--------------------|
| Board composition | Not assessed | Min 1/3 independent directors | Majority independent |
| Audit committee | Not confirmed | Mandatory (listed entity) | Quarterly meeting minimum |
[case figure moved to example-2026-Q1.md]
| Anti-bribery policy (MACC s.17A) | Not confirmed | Published + training records | ISO 37001 certification |
| Whistleblower channel | Not confirmed | Mandatory (Whistleblower Protection Act 2010) | Anonymous hotline + independent review |
| PDPA DPO appointed | Not confirmed | Required if large processor | Mandatory (GDPR equivalent) |
| ESG reporting | None | Annual (listed only) | GRI framework |
| Quality accreditation | None confirmed | MOH quality standard | JCI / ISO 9001 |
