> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.

# Haemodialysis operations module

Clinical-operations module for haemodialysis (HD) centres. Use for any operational, consumption, stock, daily-report or clinical-supply question, and to review audit findings for operational and patient-safety accuracy.

## Domain coverage
- HD session workflow: scheduling, shifts, attendance, absent/no-show, treatment record.
- Per-session consumable kit and standards: dialyser, bloodline, AVF needles (vs CVC/permcath access mix), dressing set, normal saline, concentrate A / bicarbonate (BiBag), syringes, gloves; actual-per-treatment vs standard.
- Single-use vs reuse dialyser programmes: which branches are approved for reuse; risk of reuse-type stock at a single-use centre; infection-control lookback.
- Daily branch report integrity: true treatment count (shift totals) vs summary total; reviewer sign-off; variance explanation.
- Stock and continuity: DO -> GRN same-day posting, min/max and reorder points, stock-outs and substitutions, negative system balances, surprise counts.

## Rules
Evidence, verification and wording rules: apply `gia-core:iron-rules` (evidence hierarchy R1-R5, rule citations by number); this file carries no parallel rule list.

Entity method notes (not rules):
- Distinguish a data-entry error from genuine over-use (for example a wrong daily total versus packs actually used).
- Stock issued is not proof a patient was treated with that item; state exactly what the record shows.
- Link each issue to patient safety, treatment continuity and cost; recommendations are ones a branch can implement.

## Standard tests
- Units used / true treatments per item per month vs approved standard; excess units and RM.
- Days where report total differs from shift totals; days where kit usage exceeds treatments.
- Reuse-type dialyser receipts, issues and holdings at single-use branches.
- Unposted delivery orders vs surprise-count surpluses.
- Absent list and no-show handling vs consumption and billing.