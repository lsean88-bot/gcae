> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- MKPC — MK Tron Manufacturing (Die Casting & Stamping)
- Nephrocare — Nephrocare Management Sdn Bhd (Dialysis Operations)
- Erawan — Erawan Malaysia (LMW Gas Cylinder Manufacturing)
- MK Tron Group (Holding / HQ)


# MK Tron Group — Malaysia Entity Profiles

## MKPC — MK Tron Manufacturing (Die Casting & Stamping)

**Industry:** Automotive parts manufacturing — HPDC/GDC die casting, metal stamping, sub-assembly  
**Customers:** Perodua (P2SA), Denso, Daihatsu, other OEMs  
**Certification:** IATF 16949:2016 (6th Ed Rules 2025)  
**Locations:** Shah Alam, Johor (confirm at audit)

### HR Profile
- **Workforce mix:** Local production operators, foreign workers (VP(TE) — typically Bangladesh, Indonesia, Nepal, Myanmar), supervisors (local), engineers/managers (local + expatriates)
- **Shift pattern:** 3-shift (typically 8h/shift); OT common during peak OEM demand
- **Foreign worker volume:** High — major audit risk area
- **Accommodation:** Employer-provided hostel (Act 446 applies)

### Entity-Specific Risks
1. **Foreign worker management:** Expired VP(TE), sector/employer mismatch, permit forging via subcontractor; levy back-charging to workers; overcrowded hostel (Act 446)
2. **OT inflation:** Production supervisors and operators during OEM push periods; T&A override by shift supervisors; flat "production allowance" replacing OT
3. **Ghost workers:** Headcount mismatch between IMI records and physical roster; duplicate IC/passport numbers across foreign worker pool
4. **IATF headcount requirement:** OEM CSRs (Perodua P2SA) may specify minimum staffing ratios — verify compliance; ghost worker detection also a quality audit risk
5. **Contract labour (CLRA):** Third-party manpower suppliers — verify REPSE-equivalent registration not applicable (Mexico only); verify PCB/EPF treatment for Malaysian contract workers; MACC s.17A on agent payments

### Applicable Statutes (beyond EA 1955 core)
- Immigration Act 1959/63 — VP(TE) permits
- Act 446 — Worker Housing; state gazette rent deduction cap
- CLRA 1966 — Contract Labour (if using third-party manpower)
- Factories and Machinery Act 1967 / OSHA 1994 (Amdt 2022) — working hours in factories
- MACC Act 2009 s.17A — manpower agent payments

### Key Audit Focus
- Full foreign worker reconciliation (IMI ↔ HR master ↔ physical headcount ↔ payroll)
- Act 446 accommodation inspection and deduction cap test
- T&A-to-payroll OT reconciliation across all three shifts
- Levy payment confirmation (employer-borne; not deducted from wages)
- Manpower agent payment review (MACC s.17A)

---

## Nephrocare — Nephrocare Management Sdn Bhd (Dialysis Operations)

**Industry:** Private kidney dialysis (haemodialysis); multi-centre operator  
**Regulatory framework:** PHFSA 1998 (Act 586), CKAPS/MOH licensing  
**Centres:** 15 existing + 3 new clinics (expansion pipeline)

### HR Profile
- **Workforce mix:** Nephrologists (consultant/visiting), registered nurses (RN), assistant nurses, dialysis technicians, receptionists, centre managers, lab staff
- **Staffing ratios:** MOH/CKAPS — nephrologist-to-patient ratio; nurse-to-machine ratio (1:4 per session)
- **Employment types:** Full-time employees (EPF/SOCSO/EIS/PCB applicable), visiting consultants (self-employed — check PCB s.107C, SOCSO Vol.), PERKESO panel contract clinicians
- **Shift pattern:** Morning/afternoon/evening dialysis sessions; nurses on rotation

### Entity-Specific Risks
1. **Ghost clinical staff:** Staff on PERKESO panel billing roster not physically working; nurse headcount inflated to meet CKAPS ratio on paper
2. **EPF/SOCSO misclassification:** Visiting nephrologists treated as "self-employed" but with characteristics of employment — EPF/SOCSO exposure; PCB s.107C obligation for fees paid
3. **PERKESO panel billing vs actual staff:** Panel agreement specifies staffing requirements — audit cross-reference
4. **Night shift OT:** Nurses accumulating OT during dialysis sessions; OT authorisation and payment compliance
5. **Locum/contract clinician PCB:** Fees to locum doctors — check PCB deduction (s.107C) and documentation
6. **Staff-to-patient ratio compliance:** If ratios breached, MOH licensing risk — HR audit finding has regulatory consequence

### Applicable Statutes (beyond EA 1955 core)
- PHFSA 1998 — private healthcare facility staffing requirements
- CKAPS — dialysis-specific licensing conditions including staffing ratios
- PERKESO Panel Agreement — staffing and billing conditions
- Income Tax Act 1967 s.107C — PCB for contract service payments (non-employee)
- Allied Health Act 2016 — allied health professional registration (technicians)

### Key Audit Focus
- Employment classification review: employee vs contractor vs visiting consultant
- PCB compliance for locum/consultant fee payments (s.107C)
- EPF/SOCSO for all employees including part-time RNs (hours ≥ threshold)
- Nurse:machine ratio reconciliation against CKAPS licence condition
- Night shift OT calculation and authorisation
- PERKESO panel staff billing vs HR payroll cross-reconciliation

---

## Erawan — Erawan Malaysia (LMW Gas Cylinder Manufacturing)

**Industry:** Gas cylinder manufacturing under Licensed Manufacturing Warehouse (LMW)  
**Regulatory:** Customs Act 1967 s.65/65A (LMW); DOSH; OSHA 1994 (Amdt 2022); Gas Cylinder Guidelines 2021  
**Location:** Peninsula Malaysia (confirm state for Act 446 cap)

### HR Profile
- **Workforce mix:** Local operators (cylinder fabrication, testing), foreign workers (production — high volume), engineers (local), managers, quality/DOSH compliance staff
- **Shift pattern:** 2–3 shifts; OT during export order peaks
- **Accommodation:** Employer-provided (Act 446 applies); **rent deduction cap is state-gazette specific — confirm applicable gazette before testing**
- **DOSH exposure:** Pressurised equipment environment; working time compliance has safety implications

### Entity-Specific Risks
1. **Act 446 rent over-deduction:** Foreign worker accommodation charges exceeding gazetted cap; amounts reclassified as "utilities" or "meals" to circumvent cap; no written consent forms on file
2. **Levy back-charging:** Foreign worker immigration levy deducted from wages (prohibited); buried in "deductions" line on payslip
3. **Factory OT — unrecorded:** Pre-shift and post-shift work not captured in T&A; pressure to meet DOSH cylinder test quotas
4. **Permit mismatch:** Foreign workers on permits for different sector/employer (common with subcontracting chains)
5. **DOSH competency staff — fake qualifications:** Pressure vessel inspection staff — certificate verification
6. **LMW headcount compliance:** RMCD may impose minimum local worker ratio — verify if applicable; ghost local workers to meet ratio

### Applicable Statutes (beyond EA 1955 core)
- Act 446 — Worker Housing (state gazette deduction cap — MANDATORY to verify)
- Immigration Act — VP(TE) sector-specific permits for manufacturing
- Factories and Machinery Act 1967 — working time and OT for factories
- OSHA 1994 (Amdt 2022) — safety-critical working time provisions
- Gas Cylinder Guidelines 2021 — competency/certification of testing staff (HR record link)
- Customs Act 1967 — LMW conditions (may include local worker ratio obligations)

### Key Audit Focus
- Act 446 accommodation inspection: obtain state gazette; compute deduction cap; test all accommodation deductions with consent form check
- Levy payment audit: confirm employer-borne; check payslip deduction line items for disguised levy recovery
- T&A reconciliation with DOSH shift-safety overlay (working time in high-risk environment)
- Foreign worker permit audit: sector/employer match to IMI records
- LMW local worker ratio compliance (confirm with RMCD licence conditions)

---

## MK Tron Group (Holding / HQ)

**Entity type:** Malaysian-incorporated holding company and group functions  
**Staff profile:** Senior management, finance, HR, legal, internal audit, group services

### HR Profile
- **Workforce mix:** Mostly local professionals and managers; expatriate senior management (EP holders)
- **EP holders:** Typically Cat I and Cat II; subject to new thresholds from 1 Jun 2026
- **Third-party arrangements:** Outsourced functions, management consultants, board secretaries — PCB/EPF treatment and MACC s.17A

### Entity-Specific Risks
1. **EP salary inconsistency:** Contract salary inflated for EP approval; actual payslip lower; shadow payroll for difference; non-disclosure to LHDN
2. **MACC s.17A — recruitment and manpower:** Payments to recruitment agents, headhunters, EP facilitation services — no due diligence on file; commission structures
3. **PDPA compliance:** Employee personal data (IC, medical, salary, biometric for group HR system) — data retention, consent, DPO appointment, 72h breach notification protocol
4. **Board-level payroll:** Director fees — PCB treatment (directors are employees for PCB purposes); EPF for executive directors
5. **Related-party HR:** Family members of senior management on payroll — verify role, market-rate remuneration, approval authority

### Applicable Statutes (beyond EA 1955 core)
- MACC Act 2009 s.17A — corporate liability; all associated person payments
- PDPA 2010 (Amdt 2024) — employee data; DPO; 72h breach notification
- Immigration/ESD — EP applications and renewals (thresholds from 1 Jun 2026)
- Income Tax Act 1967 — director fees (s.4(b) income); PCB obligation
- Companies Act 2016 — director remuneration disclosure

### Key Audit Focus
- EP triangulation: contract salary ↔ payslip ↔ ESD submission ↔ LHDN EA form
- MACC s.17A: all recruitment/manpower agent payments — vendor due diligence file review
- PDPA: HR system data mapping; DPO appointment evidence; breach response protocol
- Director fee PCB: reperformance; EA form accuracy
- Related-party employment: approval trail; remuneration benchmarking
