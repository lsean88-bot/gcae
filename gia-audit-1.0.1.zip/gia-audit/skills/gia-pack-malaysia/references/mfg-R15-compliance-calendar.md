> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.

# R15 — Malaysia Manufacturing Compliance Calendar & Penalty Matrix

## Monthly Recurring Obligations

| Due Date | Obligation | Statute | Portal |
|---------|-----------|---------|--------|
| 15th | EPF monthly contribution — local + foreign workers | EPF Act 1991 | kwsp.gov.my (i-Akaun) |
| 15th | SOCSO monthly contribution (ceiling [MY-007]) | SOCSO Act 1969 | perkeso.gov.my (ASSIST) |
| 15th | EIS monthly contribution (ceiling [MY-007]) | EIS Act 2017 | perkeso.gov.my |
| 15th | PCB/MTD monthly tax deduction remittance | ITA 1967 | lhdn.gov.my (e-PCB) |
| 15th | HRD Corp monthly levy | HRD Corp Act 2001 | hrdcorp.gov.my |
| 28th | SST-02 return (bi-monthly taxable period — verify period) | Sales Tax Act 2018 | mysst.customs.gov.my |

## Quarterly / Periodic Obligations

| Period | Obligation | Statute | Due Date |
|--------|-----------|---------|---------|
| Every 6 months | OSH Committee meeting (≥40 employees) | OSHA 1994 Sec 30 | Within each 6 months |
| Annual | IATF 16949 surveillance audit | IATF Rules 6th Ed | Within 12 months ±30 days of cert anniversary |
| Annual | DOSH machinery inspection (classified machinery) | FMA 1967 | Per inspection schedule |
| Annual | BOMBA fire certificate renewal | Fire Services Act 1988 | Before expiry |
| Annual | DOE scheduled waste annual return | EQA 1974 | Verify DOE notification |
| Annual | SSM annual return | Companies Act 2016 | Within 30 days of AGM; AGM within 6 months of FYE |
| Annual | LHDN CP204 (advance tax estimate) | ITA 1967 Sec 107C | By 30th day before FY commencement |
| 6th month | CP204A mandatory revision | ITA 1967 | Month 6 of financial year |
| Annual | HRD Corp annual grant utilisation return | HRD Corp Act | Per HRD Corp notification |
| Annual | MIDA incentive utilisation report (if Pioneer/ITA/RA) | PIA 1986 | Per MIDA conditions |
| Annual | e-Invoice implementation review | Finance Act 2024 | Per MyInvois phase threshold |

## Key Fixed Annual Deadlines

| Due Date | Obligation | Statute | Penalty for Default |
|---------|-----------|---------|-------------------|
| 30 Apr (for Dec FY) | Corporate income tax filing (CP204 estimate) | ITA 1967 | [MY-041] |
| 30 Apr | CP204 payment — 1st instalment | ITA 1967 | [MY-041] |
| 30 Jun | Audited accounts filing with SSM (for Dec FY within 6 months of AGM) | Companies Act 2016 | [MY-052] |
| 31 Jul | Tax return (Form C — December FY) | ITA 1967 | [MY-041] |
| 30 Sep | MFRS financial statements — audit completion target | MFRS; Companies Act | Audit opinion basis |
| 31 Dec | Year-end inventory physical count | IAS 2 / MFRS 102 | Audit qualification risk |

## Penalty Quick Reference — Malaysia Manufacturing

| Violation | Penalty |
|-----------|---------|
| EPF late contribution | EPF Act 1991 Sec 43 — see [MY-044] |
| SOCSO late contribution | SOCSO Act 1969 — penalty [MY-030] |
| Minimum wage violation (below [MY-003]) | NWCCA 2011 Act 732 Sec 43 — penalty [MY-029] |
| Foreign worker — expired VP(TE) | Immigration Act 1959/63 Sec 55E — see [MY-054] |
| Employer retaining passport | Passports Act 1966 Sec 12A — see [MY-054] |
| OSHA violation (post-2022) | OSHA 1994 (Amdt 2022) — see [MY-048] |
| Accident not reported to DOSH | OSHA 1994 — see [MY-048] |
| DOE scheduled waste violation | EQA 1974 — see [MY-049] |
| SST non-registration | Sales Tax Act 2018 — see [MY-033] |
| SST under-declaration | Sales Tax Act 2018 — see [MY-033] |
| ITA late filing | ITA 1967 — see [MY-041] |
| Transfer pricing adjustment | ITA s.140A — principal adjustments + surcharge per [MY-039] |
| IATF certificate suspension | Suspension → customer notification obligation → OEM qualification risk |
| MACC s.17A corporate liability | MACC Act 2009 — see [MY-053] |
| e-Invoice non-compliance | Finance Act 2024 — expense deductibility denied; RMCD fine |
| EPF foreign worker non-contribution (from Oct 2025) | EPF Act 1991 — same penalties as local worker non-contribution |
