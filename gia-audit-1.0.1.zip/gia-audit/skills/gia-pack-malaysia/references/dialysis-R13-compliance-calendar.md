> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.

# R13 — Malaysia Healthcare Compliance Calendar & Penalty Matrix

## Monthly Recurring Obligations

| Due Date | Obligation | Statute | Portal |
|---------|-----------|---------|--------|
| 15th | EPF monthly contribution | EPF Act 1991 | kwsp.gov.my (i-Akaun) |
| 15th | SOCSO monthly contribution (ceiling [MY-007]) | SOCSO Act 1969 | perkeso.gov.my (ASSIST) |
| 15th | EIS monthly contribution (ceiling [MY-007]) | EIS Act 2017 | perkeso.gov.my |
| 15th | PCB/MTD monthly tax deduction remittance | ITA 1967 | lhdn.gov.my (e-PCB) |
| 15th | HRD Corp monthly levy (if ≥10 Malaysian employees) | HRD Corp Act 2001 | hrdcorp.gov.my |
| 28th | SST-02 return (if registered; bi-monthly) | Service Tax Act 2018 | mysst.customs.gov.my |

## Periodic / Annual Obligations

| Due Date | Obligation | Statute | Authority |
|---------|-----------|---------|---------|
| Before expiry | CKAPS operating licence renewal (2-year cycle) | PHFSA 1998 Act 586 | MOH eSPKKS |
| 31 Dec (annual) | MMC APC renewal application by 31 Dec for following year | Medical Act 1971 | MMC MeRITS |
| Before opening | CKAPS pre-approval for each new centre | PHFSA 1998 Act 586 | CKAPS / MOH |
| Every 6 months | RO water quality testing (bacteria, endotoxin, chemical) | MOH/AAMI/ISO 23500 | Accredited lab |
| Quarterly | Adverse event / incident report review with management | PHFSA regulations | MOH |
| Annual | PDPA / data protection audit (internal) | PDPA Act 709 / Amdt 2024 | JPDP |
| Within 72 hours | PDPA data breach notification to JPDP | PDPA Amdt 2024 | pdp.gov.my |
| Annual | SSM annual return | Companies Act 2016 | SSM — within 30 days of AGM |
| Annual | LHDN CP204 (advance corporate tax estimate) | ITA 1967 Sec 107C | hasil.gov.my |
| 6th month of FY | CP204A mandatory revision | ITA 1967 | hasil.gov.my |
| Annual | Audited financial statements filing (SSM) | Companies Act 2016 | SSM — within 6 months of FYE |
| Annual | MFRS 119 actuarial valuation (employee benefits) | MFRS 119 | External actuary |
| Per PPT terms | FMC quarterly treatment report | PPT Agreement | FMC / PERKESO |

## Penalty Quick Reference — Malaysia Healthcare

| Violation | Penalty |
|-----------|---------|
| Operating without PHFSA licence | Act 586 Sec 6 — see [MY-050] |
| Employing unlicensed doctor (no valid APC) | Act 586 Sec 31(1)(c) — show cause notice; compounding fine |
| Doctor practising without APC | Medical Act 1971 — fine + suspension |
| EPF late contribution | EPF Act 1991 Sec 43 — see [MY-044] |
| SOCSO late contribution | SOCSO Act 1969 — penalty [MY-030] |
| Minimum wage violation (below [MY-003]) | NWCCA 2011 Act 732 — penalty [MY-029] |
| PDPA breach — no notification within 72 hrs | PDPA Amdt 2024 — see [MY-051] |
| PDPA processing without consent | PDPA Act 709 — see [MY-051] |
| SST non-registration (if liable) | Service Tax Act 2018 — see [MY-033] |
| SST under-declaration | see [MY-033] |
| ITA late filing | see [MY-041] |
| MACC s.17A — corporate corruption liability | MACC Act 2009 — see [MY-053] |
| Referral kickbacks to doctors | MACC Act 2009 + Medical Ethics — prosecution; MMC disciplinary action |
| Dialyser reuse >10 sessions | PPT Schedule IV breach; MOH enforcement; patient safety incident |
| No RO water quality test | PHFSA / MOH — regulatory enforcement; facility licence review |
| Phantom PERKESO billing | SOCSO Act; criminal fraud — prosecution + claim recovery |
| Medical waste — unlicensed disposal | EQA 1974 — see [MY-049] |
