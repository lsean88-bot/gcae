> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.

# LMW Customs Compliance Reference — Erawan Malaysia

## Legal Basis
- **Customs Act 1967 (Act 235)** — Section 65 (licensed warehouse) / Section 65A (licensed manufacturing warehouse)
- **26 LMW Appendix C Conditions** — issued by Director General of Customs
- **RMCD LMW Guidelines** — `customs.gov.my`

## Key LMW Compliance Requirements

### Export Ratio
- Minimum **80%** of total value of finished goods must be exported for 12 months
- Local sales ≤20% without MIDA approval
- Local sales above the [MY-022] ratio requires **MIDA special approval**; goods treated as imported; duty + SST applies
- Local sales require **Customs Form K9** (In-Situ Transfer) + payment of applicable duty/SST before release

### Mandatory Monthly/Annual Returns
| Form | Frequency | Content |
|------|-----------|---------|
| **M1** | Monthly | Raw material usage — duty-free imports consumed in production |
| **M2** | Monthly | Finished goods — exported vs. local sales vs. work-in-progress |
| **M4** | Annual | Annual summary + reconciliation; must accompany audited annual financial statements |
| **K2** | Per export | Export declaration form — each export shipment |
| **K1** | Per import | Import declaration form — each duty-free raw material import |
| **K9** | Per local sale | In-situ transfer — local sales treated as deemed imports |

### Submission Deadline
- M1/M2: Due by **last day of the following month**
- M4 annual: Due within **30 days of FY-end**; accompanied by audited FS

### Raw Material Control
- Duty-free imports restricted to approved tariff codes per LMW approval letter
- Inventory tracking mandatory: separate storage for LMW raw materials
- No commingling of dutiable and duty-free materials

### License Renewal
- Annual renewal; application must be submitted **≥1 month before expiry**
- Late renewal = penalty; lapsed license = all duty exemptions retroactively void

### Bank Guarantee / Bond
- Gas cylinders (steel/composite) classified as **non-critical items** → general bond with Customs
- Critical items (e.g., textiles, electronics) require bank guarantee
- Bond amount set by RMCD based on estimated annual duty value

## Key Audit Tests — LMW Specific
1. Export ratio calculation: `[REC]` export FOB value ÷ total production value × 100% ≥ 80%
2. M1 material balance: Opening stock + imports = production consumption + closing stock (should zero-reconcile)
3. Local sales K9 reconciliation: All local sales in M2 must have corresponding K9 + duty/SST payment
4. Tariff code verification: Imported raw materials (steel tubes, valves, paint) must be on RMCD-approved list
5. Subcontract: If Erawan subcontracts any process (e.g., hydrostatic testing externally), RMCD approval required

## Common LMW Violations (High Audit Risk)
- 🔴 Export ratio <80% without MIDA approval → back-duty assessment on all imports
- 🔴 M1/M2 returns not filed or inaccurate → RMCD audit triggers; penalty up to 20× evaded duty
- 🔴 Duty-free materials diverted to local use without K9 + duty payment
- 🟠 LMW license expired or conditions not met → license revocation risk
- 🟠 Subcontract activities not approved by RMCD → violates Appendix C condition

## Quantification of Exposure
- Back-duty = import duty rate × dutiable value of all duty-free imports for non-compliant period
- Gas cylinder steel tubes: customs duty rate typically 0–10% depending on HS code (verify current tariff at `tariff.customs.gov.my`)
- RMCD penalty: up to 20× evaded duty under Customs Act s.135
