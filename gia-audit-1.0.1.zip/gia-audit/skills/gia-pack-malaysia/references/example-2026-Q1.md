# Example: clinic engagement, Q1 2026 (illustrative, dated, role-not-name)

## Contents
- From clinic-A2_medicine_price_display.md
- A2.6 — Compliance Recommendation for the clinic
- From clinic-A_regulatory_compliance.md
- From clinic-B_revenue_pos_panel.md
- B2 — Panel Billing: Key Panels for the clinic
- From clinic-C_sst_compliance.md
- C2 — SST Registration: the clinic
- From clinic-D_financial_reporting.md
- From clinic-E_intercompany_rpt.md
- E1 — the clinic Group Structure (as at Mar 2026)
- From clinic-F_statutory_hr.md
- F3 — the clinic-Specific Payroll Observations
- From clinic-G_H_I_cash_inventory_fraud.md
- I1 — ACFE Fraud Tree: Relevant Branches for the clinic
- From clinic-J_it_pdpa.md
- J1 — the clinic Group IT Architecture
- From clinic-K_governance.md
- J1 — the clinic Group IT Architecture
- J3 — the POS system-Specific Controls (the clinic POS)
- From clinic-L_benchmarking.md
- L3 — the clinic Performance vs Benchmarks (Q1 2026)
- From clinic-M_future_trends.md
- M8 — the clinic 3-Year GRC Roadmap
- M9 — Benchmarking: KPJ vs Pantai vs IHH vs the clinic (Updated 2026)


Illustrative only. Dated Q1 2026. Entity and system names replaced by roles. Not current, not a benchmark, not to be reused as fact.


## From clinic-A2_medicine_price_display.md

**KEY AUDIT NOTE AS AT MAY 2026:** The Price Control and Anti-Profiteering (Medicine Price Labelling) Order 2025 remains VALID AND GAZETTED, but the High Court has stayed its enforcement pending judicial review by medical associations (Malaysian Medical Association + 6 groups) and PMPASKL-Medipulse. Enforcement is stayed pending full disposal. the clinic should monitor court outcome — enforcement could resume at any time.
**Current audit approach (May 2026):** Document the gap as a RISK observation, not an active finding. Note the High Court stay and recommend the clinic prepare a compliant price list ready for deployment when stay is lifted or JR dismissed.
## A2.6 — Compliance Recommendation for the clinic
Given the fluid legal status, recommend the clinic:
The medicine price display policy is part of MOH's broader **12th Malaysia Plan (RMK-12)** price transparency initiative. Even if this specific order is quashed by the court, MOH has signalled intent to legislate price transparency through PHFSA amendments. the clinic should treat price transparency as a long-term compliance obligation to prepare for.

## From clinic-A_regulatory_compliance.md

The High Court held that aesthetic practice at a healthcare facility not shown to have accreditation or licensing under PHFSA 1998 = unlicensed, illegal business. **Key implication for the clinic:** Even if the doctor holds LCP, the PREMISES must be separately and correctly licensed under PHFSA for aesthetic services.
| Class | Description | the clinic Status |
| C | Store/Use (Menstor Mengguna) — clinic X-ray | the clinic holds KKM/R/1813, valid 08/12/2025–07/12/2028 |
| Role | the clinic — Current Status | Risk |
| Profession | Registering Body | Relevant the clinic Entity |
| Radiographer | AHPC | the clinic (2 radiographers) |
| Medical Lab Technologist | AHPC | the clinic (if in-house lab) |

## From clinic-B_revenue_pos_panel.md

### the clinic Revenue Streams
## B2 — Panel Billing: Key Panels for the clinic
| KPI | the clinic Q1 2026 | KPJ Clinic Benchmark | Pantai/Columbia | Global Best (Mayo) | Risk |
|-----|------------|---------------------|----------------|-------------------|------|
| Monthly net revenue | RM 394,282 avg | RM 300K–1.5M per clinic | RM 500K–2M | Multi-million USD | Within range |
| Revenue per encounter | RM 375 avg | RM 80–200 (GP); RM 300–800 (specialist) | RM 400–1,200 | USD 300–1,200 | High — suggests premium billing or specialist mix |
| Panel as % of revenue | ~52% | 40–60% typical | 50–70% | Varies | Normal |
| Gross margin | 54.6% | 45–65% | 50–70% | 65–75% | Acceptable |
| Net margin | 0.04% | 10–20% | 12–25% | 20–35% | 🔴 Critical underperformance |
| Bad debt as % of AR | <1% target | <2% | <1% | <0.5% | Monitor |
| Debtor days (trade AR) | ~26 days | <30 days panel; <60 days corporate | <30 days | <20 days | Acceptable |

## From clinic-C_sst_compliance.md

## C2 — SST Registration: the clinic
### Filing Calendar — the clinic
**the clinic Gap:** POS the POS system system does not appear to generate SST-compliant invoices (SST captured at RM 0.00 in all Q1 2026 POS records). Action required: the POS system invoice template must be updated post-registration.

## From clinic-D_financial_reporting.md

the clinic (incorporated 2022, Sdn Bhd) — applies **MPERS (Malaysian Private Entity Reporting Standards)** if it qualifies as a private entity OR full **MFRS** if it is a subsidiary of a public-listed entity. Until clarified, apply MFRS conservatively.
| Standard | Application to the clinic |

## From clinic-E_intercompany_rpt.md

- E1 — the clinic Group Structure (as at Mar 2026)
## E1 — the clinic Group Structure (as at Mar 2026)
| Entity | Relationship | the clinic Investment | Interco Balance (Due From the clinic) | Headcount Filled/Required |
| **Group HQ (on the clinic payroll)** | Division | — | — | 8/8 |
**Total interco receivables: RM 2,472,892 (60.7% of the clinic total assets)**
### the clinic Interco ECL Indicators
**For the clinic specifically:**
- Management fee income from subsidiaries (RM 39,000 Q1 2026) — disclose basis and agreement
- Rental income from subsidiaries (RM 18,000 Q1 2026) — disclose tenancy terms
the clinic grants interest-free loans to three subsidiaries. LHDN may:
2. Adjust the clinic's assessable income upward by deemed interest
**the clinic-Specific:** Director current account (440-000) reduced from RM 2,877,325 to RM 173,337 — concurrent with RM 3,000,000 share capital injection. Document:

## From clinic-F_statutory_hr.md

- F3 — the clinic-Specific Payroll Observations
**Key 2025 change:** Foreign worker EPF contributions became mandatory from October 2025 ([MY-043]). This affects all the clinic clinic staff on work permits.
| the clinic status | At 10 employees (at threshold) | Confirm registration and eligibility category |
## F3 — the clinic-Specific Payroll Observations
| the clinic payroll system | Worksy | Separate from Dental/Physio (Payroll Panda) |
| HRDF payable | RM 1,153 | the clinic at exactly 10 employees — confirm threshold status |
| Group HQ (8 staff on the clinic payroll) | Group HQ staff on the clinic payroll | Management fee from subsidiaries should recover this cost |
| Section | Requirement | the clinic Relevance |
| the clinic Sdn Bhd | 10/11 | 9.1% | Minimal — 1 Customer Care vacant |
| Group HQ (on the clinic payroll) | 8/8 | 0% | No concern |

## From clinic-G_H_I_cash_inventory_fraud.md

| Control | Best Practice | the clinic Status | Risk |
**the clinic-Specific:** Stock at RM 137,171.45 — identical opening and closing for all Q1 2026 months. This means COGS is calculated as a plug. Physical count required immediately.
## I1 — ACFE Fraud Tree: Relevant Branches for the clinic
| Fraud Category | Specific Risk | Red Flag at the clinic |

## From clinic-J_it_pdpa.md

- J1 — the clinic Group IT Architecture
## J1 — the clinic Group IT Architecture
| Function | the clinic Sdn Bhd | Perfect Dental Sdn Bhd | Perfect Physio Sdn Bhd |
Patient health and medical records processed by the clinic, Perfect Dental, and Perfect Physio constitute **sensitive personal data** under PDPA s.5. This triggers:
the clinic almost certainly meets the DPO threshold because it:
3. Operates across multiple entities (the clinic, Dental, Physio) — potentially "large-scale processing"
**the clinic action required:** Appoint DPO immediately. DPO can be internal (qualified staff) or external (specialist data protection consultant).
| PDPA assessment per entity per POS platform | `[INS]` 3 × PDPA assessments (the clinic/Dental/Physio) | CP | |
| Revenue Threshold | Mandatory From | Status for the clinic |
| RM 500K–RM 25M | **1 July 2025** | **the clinic FALLS HERE** (~RM 4.7M annualised) |
**the clinic's annualised revenue ~RM 4.7M → MyInvois mandatory since 1 July 2025.**
Per research (einvoicingmalaysia.com, verified Mar 2026): **Medical and healthcare services are broadly exempt from Service Tax under Schedule B of Service Tax Regulations 2018.** Therefore the clinic should use **Exempt (E)** tax code for most services. The 6% SST on non-citizen healthcare (F-03 finding) is a SEPARATE obligation from the eInvoice system — both must be applied concurrently.

## From clinic-K_governance.md

- J1 — the clinic Group IT Architecture
- J3 — the POS system-Specific Controls (the clinic POS)
## J1 — the clinic Group IT Architecture
**Key Risk:** No automated data integration between the POS system (the clinic POS) and Doctor Partner (Dental/Physio POS). No integration between Worksy (the clinic payroll) and Payroll Panda (Dental/Physio payroll). Manual extraction required for any group-level report.
### the clinic PDPA Obligations
- the POS system (the clinic) and Doctor Partner (Dental/Physio) — each processes patient health data = sensitive personal data
## J3 — the POS system-Specific Controls (the clinic POS)
| Section | Duty | the clinic Relevance |
**the clinic-Specific Risks:**
- Referral commissions (P&L shows RM 0 commission Q1 2026, but RM 10,081 in Nov/Dec 2025) — document referral arrangement and screen for kickbacks

## From clinic-L_benchmarking.md

- L3 — the clinic Performance vs Benchmarks (Q1 2026)
### Poliklinik / Chain GP Clinics (comparable to the clinic Umum scope)
- **PHFSA Umum scope — expected benchmarks for the clinic if operating as GP clinic**
## L3 — the clinic Performance vs Benchmarks (Q1 2026)
| KPI | the clinic Q1 2026 | Malaysian GP Benchmark | KPJ/Pantai (hospital) | Global Best (Mayo/IHH) | the clinic Risk |
|-----|------------|----------------------|----------------------|------------------------|---------|
| Revenue per encounter | RM 375 | RM 80–200 | RM 250–600 | USD 450–1,200 | 🟡 Premium vs GP; needs specialist justification |
| Gross margin | 54.6% | 50–65% | 45–60% | 60–75% | 🟢 Acceptable |
| Net margin | 0.04% | 15–25% | 8–15% | 5–10% | 🔴 Critical — near breakeven |
| Staff cost % revenue | ~30.1% | 25–35% | 40–48% | 40–55% | 🟢 Efficient staffing cost |
| Rental % revenue | 8.9% | 5–15% | 5–10% | 3–8% | 🟡 High for GP; monitor |
| Single-practitioner concentration | 57.5% the sole practitioner | <30% best practice | <15% (hospital) | <5% | 🔴 Extreme risk |
| Interco % of assets | 60.7% | <5% (no interco) | <10% | <5% | 🔴 No comparable |
| Cash/liquid % assets | 3.4% | >10% | >15% | >20% | 🟠 Low liquidity |
| SST compliance | Periods 1–3 unconfirmed | 100% | 100% | 100% | 🔴 Filing risk |
| IT integration (group) | Fragmented (3 payroll, 2 POS) | Centralised ERP | Full EHR/HIS | Epic/Oracle Health | 🟠 Lagging |
| PHFSA scope compliance | Umum — cell therapy outside scope | All services within scope | All within scope | — | 🔴 Breach |
| KPI | the clinic Target | Industry Standard (MOH) | Global Best |
| Dimension | the clinic Current State | KPJ / IHH Standard | Global Best Practice |
| Internal audit function | GCAE (MKTron Group — external to the clinic) | In-house IA + external audit | CAE reporting to Audit Committee |

## From clinic-M_future_trends.md

- M8 — the clinic 3-Year GRC Roadmap
- M9 — Benchmarking: KPJ vs Pantai vs IHH vs the clinic (Updated 2026)
**Audit implication:** the clinic must ensure the POS system is on a roadmap to FHIR interoperability. Data exported to national registry requires explicit PDPA consent (processing agreement with MOH).
| Impact on the clinic | Panel billing rates for corporate and SOCSO panels may be capped per DRG code from 2027 |
**Strategic risk for the clinic:** Current high revenue per encounter (RM 375 average) may not be sustainable under DRG-capped rates. Management should model revenue impact under DRG scenarios.
### the clinic Telemedicine Opportunity
- **the clinic risk:** F-16 finding (scope breach) will be compounded by HTA non-compliance once framework is gazetted
**the clinic action:** DPO appointment should not wait for subsidiary legislation — the clinic almost certainly meets threshold given health data processing scale.
## M8 — the clinic 3-Year GRC Roadmap
- Target: net margin ≥ 12% (vs 0.04% Q1 2026)
## M9 — Benchmarking: KPJ vs Pantai vs IHH vs the clinic (Updated 2026)
| KPI | the clinic Q1 2026 | KPJ Klinik Network | Pantai / Columbia Asia | IHH (Gleneagles) | Global Best (Mayo) |
|-----|------------|-------------------|----------------------|-------------------|-------------------|
| Net margin | 0.04% | 8–12% | 10–15% | 15–20% | 20–30% |
| Revenue per encounter | RM 375 | RM 80–200 (GP) | RM 300–800 | RM 400–1,200 | USD 450–1,200 |
| Dr concentration | 57.5% | <20% | <10% | <5% | <3% |
| PDPA DPO | ❌ Not confirmed | ✓ (group policy) | ✓ | ✓ | ✓ |
| MyInvois active | ❌ Not confirmed | ✓ | ✓ | ✓ | N/A |
| SST compliance | ⚠ Filings unconfirmed | ✓ | ✓ | ✓ | N/A |
| Interco % of assets | 60.7% | <5% | <5% | <5% | <2% |
| Key-person backup | ❌ None | ✓ Multi-doctor | ✓ | ✓ | ✓ |