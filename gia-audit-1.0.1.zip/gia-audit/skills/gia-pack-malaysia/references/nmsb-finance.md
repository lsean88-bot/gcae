> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.

# Dialysis finance and risk module

Finance, revenue-cycle and risk module for haemodialysis (HD) centres. Use for any finance, billing, collections, inventory-valuation, cut-off or billing-fraud question, and to review audit findings for accounting accuracy.

## Domain coverage
- Per-session HD billing by payer: government/PERKESO (SOCSO), JPA, MOE/KPM, corporate panels, NGOs, cash/self-paid; monthly caps; EPO and ancillary charges; approved rate master (e.g. HD charges by panel type).
- Revenue cycle: treatment -> bill -> panel claim -> collection -> bank-in -> debtor clearing; credit notes and reversals.
- Unidentified receipts / unknown bank-in suspense: effect on trade debtors, ageing, revenue and disclosure; clearing discipline.
- Inventory: consumables costing, stock-take valuation (variance value = unit price x difference, never x physical), month-end cut-off, GRN-received-not-invoiced accruals, branch-to-GL tie-out.
- Fraud and error red flags: duplicate patient-months, second sub-reference vouchers, off-list rates, round amounts, no credit/reversal entries, sessions billed vs sessions treated.

## Rules
Evidence, verification and wording rules: apply `gia-core:iron-rules` (evidence hierarchy R1-R5, rule citations by number); this file carries no parallel rule list.

Entity method notes (not rules):
- Label impacts precisely: duplicate billing is an over-claim or refund exposure (not revenue leakage); unidentified receipts are an unidentified balance netted against debtors (not a liability).
- Separate FACT, ESTIMATE (state basis) and GAP; every number is cited file | sheet | cell or page.
- Recommendations are SMART: action, owner role, measure, deadline.

## Standard tests
- Sessions treated (daily report shift totals) vs sessions billed per month.
- Duplicate patient-month scan (same name, same batch, second sub-reference, amount = cap).
- Billed rate vs approved rate master per payer.
- Unknown bank-in monthly build-up vs branch collection logs and daily reports.
- Branch closing consumables in P&L vs stock-take recompute; company stock vs balance sheet.
- Delivery order date vs GRN posting vs supplier invoice posting (cut-off).