> Case figures from a prior clinic engagement were moved to example-2026-Q1.md (illustrative, dated).
## Contents
- M1 — Malaysian Digital Health Landscape (2025–2030 Roadmap)
- M2 — Diagnosis-Related Group (DRG) Payment System — Deferred to 2027
- M3 — Telemedicine & Remote Consultation
- M4 — AI Diagnostics & Decision Support
- M5 — Healthcare Technology Assessment (HTA) for Biologics — EXPECTED 2026
- M6 — PDPA Subsidiary Legislation (Expected 2026)
- M7 — Companies Act 2016 — SSM Compliance Calendar
[case figure moved to example-2026-Q1.md]
[case figure moved to example-2026-Q1.md]


> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.

# Reference M — Future Trends, Digital Health & Emerging Regulatory Landscape
*Updated May 2026 — verified current; includes DRG 2027, MyHEALTH FHIR, telemedicine LCP, AI diagnostics*

---

## M1 — Malaysian Digital Health Landscape (2025–2030 Roadmap)

### MyHEALTH Portal & National Health Information System (NHIS)

| Item | Detail | Timeline |
|------|--------|---------|
| MyHEALTH Portal | National health data repository — www.myhealth.gov.my | Active |
| Malaysia Health Data Warehouse (MyHDW) | MOH centralised data platform | Rolling out 2025–2027 |
| Private clinic interface | Private clinics expected to submit patient records in HL7 FHIR format | 2026–2027 pilot expected |
| Klinify readiness | Confirm Klinify FHIR API capability | **Audit test required** |

[case figure moved to example-2026-Q1.md]

---

## M2 — Diagnosis-Related Group (DRG) Payment System — Deferred to 2027

**Malaysia delays fixed-fee diagnosis-based healthcare payment system to 2027** (Deputy Minister, The Edge Malaysia, Aug 2025).

| Item | Detail |
|------|--------|
| What is DRG? | Fixed government payment rate per diagnosis group — used by SOCSO, insurance panels |
| Original plan | 2025 |
| Current status | **Deferred to 2027** |
[case figure moved to example-2026-Q1.md]
| Audit risk | Revenue model dependent on current fee-for-service billing; DRG could compress margins significantly |

[case figure moved to example-2026-Q1.md]

---

## M3 — Telemedicine & Remote Consultation

### MMC Telehealth Guidelines (2020, updated guidance 2023)

| Rule | Detail |
|------|--------|
| Who can conduct teleconsultation | MMC-registered doctors with established doctor-patient relationship, or for low-risk conditions |
| Permitted | Video / telephone consultation; basic advice; referrals; medication review (non-controlled drugs only) |
| NOT permitted | First presentation of serious symptoms; prescribing controlled drugs; certificates requiring physical examination |
| Medical Device Authority | Wearables used for remote diagnostics may be classified as medical devices requiring MDA registration |
| LCP for aesthetic teleconsult | Not permitted — aesthetic procedures require physical presence |

[case figure moved to example-2026-Q1.md]

| Opportunity | Regulatory Gate | Klinify Capability |
|-------------|----------------|-------------------|
| Panel corporate teleconsult (MiCare, AIA) | MMC Guidelines compliance | Confirm Klinify teleconsult module |
| Chronic disease monitoring (diabetes, hypertension) | Established patient relationship required | Within MMC rules |
| Post-procedure follow-up | MMC compliant | Within MMC rules |
| Aesthetic consultation (pre-procedure) | Physical LCP-verified procedure still required | Teleconsult for assessment only |

---

## M4 — AI Diagnostics & Decision Support

| Technology | Application | Regulatory Position (Malaysia 2026) |
|-----------|-------------|--------------------------------------|
| AI radiology reading | X-ray, CT, MRI interpretation assistance | MDA medical device registration if AI makes diagnostic claims |
| AI diagnostic triage | Symptom checker → consultation routing | No specific regulation yet; MMC Professional Standards apply |
| AI prescribing support | Drug interaction checking, dose recommendation | Must remain advisory — doctor retains prescribing responsibility |
| AI aesthetics | Face scanning → treatment recommendation | No specific regulation; LCP still required for procedures |

---

## M5 — Healthcare Technology Assessment (HTA) for Biologics — EXPECTED 2026

MOH's HTA framework for advanced biological therapies (cell therapy, gene therapy, PRP, NK cells) is under active development. Current status:

- MOH Health Technology Assessment Section reviewing cell therapy safety and efficacy evidence
- No mandatory pre-market HTA approval for cell therapy yet (as at May 2026)
- **Pending:** HTA framework expected to be gazetted — any commercial cell therapy service will require HTA clearance once in force
[case figure moved to example-2026-Q1.md]

---

## M6 — PDPA Subsidiary Legislation (Expected 2026)

| Expected Gazette | Content |
|-----------------|---------|
| DPO Threshold Order | Defines exactly which organisations must appoint DPO (by employee count, data volume, or sector) |
| Data Portability Technical Standards | Format requirements for data portability requests |
| Data Breach Notification Format | Standard form for 72-hour notification to PDPC |
| Cross-Border Transfer Whitelist | Countries with "adequate protection" — no separate consent needed |

[case figure moved to example-2026-Q1.md]

---

## M7 — Companies Act 2016 — SSM Compliance Calendar

| Obligation | Deadline | Consequence |
|-----------|----------|-------------|
| Annual financial statements — FY2025 (Dec 2025 FYE) | **30 June 2026** | Companies Act 2016 s.259 — see [MY-052] |
| Annual return — Section 68 | 30 days after AGM | see [MY-052] |
| SSM eForm submission (post-CA 2016) | Online via My CoID 2.0 | Mandatory digital filing |

---

[case figure moved to example-2026-Q1.md]

### Year 1 — FY2026: Remediate & Comply

| Priority | Action | Deadline |
|----------|--------|----------|
| 🔴 CRITICAL | Halt cell therapy; engage PHFSA lawyer; DCA registration or scope upgrade | IMMEDIATE |
| 🔴 CRITICAL | File SST-02 Periods 1–4; reconfigure Klinify SST module | 31 May 2026 |
| 🔴 CRITICAL | Formal interco loan agreements + MFRS 9 ECL assessment | 14 Jun 2026 |
| 🟠 HIGH | Activate Klinify MyInvois API (overdue since Jul 2025) | IMMEDIATE |
| 🟠 HIGH | Appoint Group DPO; PDPA breach response procedure | Jun 2026 |
| 🟠 HIGH | Physical inventory count + Poisons Register | 13 Jun 2026 |
| 🟠 HIGH | MOH application to amend PHFSA operating hours for weekends | 28 May 2026 |
| 🟠 HIGH | AELA backup RPO — confirm radiographer licences; sponsor new RPO | 60 days |
| 🟡 MEDIUM | SQL Accounting ITGC — individual user accounts; dual-approval JV | Q3 2026 |
| 🟡 MEDIUM | Prepare medicine price display list (ready for deployment when court stay lifted) | Q3 2026 |
| 🟡 MEDIUM | Group payroll consolidation assessment | 60 days |

### Year 2 — FY2027: Strengthen & Systematise

- Group IT integration map + POS API or single-platform migration
- PDPA DPO: full data protection programme; consent audit; retention schedules
- MACC adequate procedures — anti-bribery policy + training records
- Quarterly management accounts reviewed by Board
- Revenue diversification — second senior GP; reduce the sole practitioner concentration below 40%
- DRG 2027 readiness: model revenue impact; diversify panel mix

### Year 3 — FY2028: Scale & Achieve Best Practice

- PHFSA scope upgrade to Specialist or Aesthetic Clinic (clinically justified)
- ISO 9001 or MOH Quality Standards accreditation pathway
- AI-assisted continuous audit analytics deployed in Klinify
- Telehealth module with MMC-compliant protocols
- MHTC medical tourism programme membership
[case figure moved to example-2026-Q1.md]
- NHIS / FHIR interface active and compliant

---

[case figure moved to example-2026-Q1.md]

[table moved to example-2026-Q1.md]
