> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- F1 — Current Statutory Rates (Malaysia, May 2026)
- F2 — Payroll Recalculation Template (For Audit Use)
[case figure moved to example-2026-Q1.md]
- F4 — Employment Act 1955 (as amended 2022) Key Provisions
- F5 — Audit Tests: Payroll & HR
- F6 — Headcount & Vacancy Impact on ECL (MFRS 9 Linkage)


# Reference F — Statutory Labour, HR & Payroll Compliance
*Updated May 2026 — incorporates all 2024–2025 rate changes, foreign worker EPF, EIS ceiling*

---

## F1 — Current Statutory Rates (Malaysia, May 2026)

**ALL RATES RESEARCH-VERIFIED against multiple sources dated 2025–2026**

### EPF (Employees Provident Fund) — EPF Act 1991

| Employee Category | Employer Rate | Employee Rate | Notes |
|-------------------|--------------|--------------|-------|
| Malaysian / PR, age <60, lower wage band | employer [MY-005] | employee [MY-004] | per register |
| Malaysian / PR, age <60, higher wage band | employer [MY-005] | employee [MY-004] | EPF Third Schedule |
| Malaysian / PR, age 60–75 | see [MY-005] | see [MY-004] | Reduced rate for older workers |
| Foreign workers (ALL) | per [MY-043] | per [MY-043] | Mandatory effective **Oct 2025** (previously optional, see [MY-006]) |
| Foreign domestic workers | Exempt | Exempt | Not covered |

[case figure moved to example-2026-Q1.md]

**EPF ceiling:** No cap — applies to total monthly wages regardless of amount.

### SOCSO (Social Security Organisation) — SOCSO Act 1969

| Category | Employer Rate (approx) | Employee Rate (approx) | Ceiling |
|----------|----------------------|----------------------|---------|
| First Category (Employment Injury + Invalidity) | [MY-008] | [MY-008] | [MY-007] |
| Second Category (Employment Injury only — age >60) | [MY-008] | Nil | [MY-007] |

**Key 2024 change:** the SOCSO and EIS insurable wage ceiling was raised; see [MY-007] for the current ceiling and effective date. Employees between the old and new ceiling now contribute on full salary up to the new ceiling.

**Important:** SOCSO uses fixed contribution table (not exact percentage) — use PERKESO official table, not formula.

### EIS (Employment Insurance System) — Employment Insurance System Act 2017

| Item | Rate | Ceiling |
|------|------|---------|
| Employer contribution | [MY-009] | [MY-007] (same ceiling as SOCSO per register) |
| Employee contribution | [MY-009] | [MY-007] |
| Foreign workers | NOT applicable | — |

**NOTE:** the register shows one insurable wage ceiling for both SOCSO and EIS [MY-007]. An earlier version of this file stated different ceilings; that text is withdrawn.

### PCB / MTD (Monthly Tax Deduction) — ITA 1967 s.83

| Item | Basis |
|------|-------|
| Method | Monthly Tax Deduction (MTD) — Kaedah Jadual (Schedule Method) or Kaedah Lain (Alternative Method) |
| Due date | 15th of following month |
| Non-resident employees | per [MY-040] |
| PCB Table 2026 | LHDN MTD Table — updated annually |

### HRDF / HRD Corp — Human Resources Development Act 2001

| Item | Rate | Threshold |
|------|------|-----------|
| Levy | per [MY-045] | Employer threshold per [MY-045] |
[case figure moved to example-2026-Q1.md]

### Minimum Wage — Minimum Wages Order 2024

| Item | Rate | Effective |
|------|------|-----------|
| Monthly minimum wage | [MY-003] | per register (by employer size) |
| Hourly equivalent | see register row | — |
| Applies to | ALL employees including part-time, contract, foreign workers | P.U.(A) 48/2024 |

---

## F2 — Payroll Recalculation Template (For Audit Use)

For each employee, verify:

```
Employee: [Name] | IC/Passport: | Nationality: | Monthly Gross Wages (RM):
┌────────────────────────────────┬──────────────┬──────────────┬──────────────┐
│ Contribution                   │ Per Policy   │ Per Payroll  │ Variance     │
├────────────────────────────────┼──────────────┼──────────────┼──────────────┤
│ EPF — Employer                 │              │              │              │
│ EPF — Employee                 │              │              │              │
│ SOCSO — Employer (First Cat.)  │              │              │              │
│ SOCSO — Employee               │              │              │              │
│ EIS — Employer                 │              │              │              │
│ EIS — Employee                 │              │              │              │
│ HRDF (if applicable)           │              │              │              │
│ PCB / MTD                      │              │              │              │
│ Min Wage compliance (≥ minimum wage [MY-003])│              │              │              │
└────────────────────────────────┴──────────────┴──────────────┴──────────────┘
```

---

[case figure moved to example-2026-Q1.md]

| Item | Current Status | Risk |
|------|---------------|------|
[case figure moved to example-2026-Q1.md]
| EPF payable (BS Mar-26) | RM 26,953 (+50.6% YoY) | Verify monthly KWSP i-Akaun remittance confirmation |
| SOCSO payable | RM 1,581.80 | Verify the register ceiling [MY-007] applied for staff above the superseded ceiling |
| EIS payable | RM 268 | Verify the register ceiling [MY-007] applied |
| PCB payable | RM 11,252 (+107% YoY) | Consistent with salary growth; confirm LHDN monthly remittance |
[case figure moved to example-2026-Q1.md]
| Foreign staff | Unknown | If any work permit holders: EPF per [MY-043] mandatory since Oct 2025 |
| Weekend operations (F-17) | POS shows weekend encounters | EA 1955 s.60 rest-day pay at 2× rate for all weekend shifts |
[case figure moved to example-2026-Q1.md]

---

## F4 — Employment Act 1955 (as amended 2022) Key Provisions

[case figure moved to example-2026-Q1.md]
|---------|-------------|---------------|
| s.12 | Written contract of service | All staff must have signed employment contract |
| s.59 | Rest day — 1 per week | If weekend ops continue, rest day must be scheduled in lieu |
| s.60 | Work on rest day — 2× daily rate | Apply to ALL Saturday/Sunday shifts confirmed in POS data |
| s.60A | Overtime — 1.5× ordinary rate; max 104 hours/month | Confirm overtime not exceeding limit |
| s.60E | Annual leave — 8 days (≤2 yrs), 12 days (2–5 yrs), 16 days (>5 yrs) | Accrue in payroll system |
| s.60F | Sick leave + hospitalisation | 14/18/22 days + up to 60 days hospitalisation |
| s.81F | Flexible working arrangement | Employee has right to request — policy required |
| s.34A | Sexual harassment — employer must investigate | Written policy and ICC required |
| Part XII | Maternity leave — 98 days paid (2022 amendment) | Applies to all female employees |

---

## F5 — Audit Tests: Payroll & HR

| Test | Evidence | Assertion |
|------|----------|-----------|
| Payroll register total agrees to GL salary + wages accounts | `[REC]` payroll total vs P&L lines | AC |
| EPF recalculation — correct rate per employee category and nationality | `[REC]` gross × employer and employee rates per [MY-004], [MY-005], [MY-043] | AC |
| KWSP i-Akaun contribution history — 12 months | `[CON]` KWSP employer portal extract | CP |
| SOCSO — verify register ceiling [MY-007] applied (not the superseded ceiling) | `[REC]` min(salary, ceiling) × PERKESO table | AC |
| EIS — verify register ceiling [MY-007] applied | `[REC]` min(salary, ceiling) × EIS rate [MY-009] | AC |
| PCB — Kaedah Jadual recomputation | `[REC]` gross → MTD 2026 table | AC |
| HRDF — verify levy rate per [MY-045] on Malaysian employee wages; confirm threshold | `[REC]` payroll × rate per [MY-045] | AC |
| Minimum wage compliance — ALL staff at or above [MY-003] | `[REC]` lowest salary in payroll register | CP |
| Foreign worker EPF (Oct 2025 onwards) — [MY-043] | `[REC]` payroll register — check nationality flag | CP |
| Weekend rest-day pay — 2× rate for Sat/Sun work | `[REC]` POS weekend dates × 2× daily rate | AC, CP |
| Ghost employee test — Benford's Law on salary amounts + new payees | `[ANA]` Benford + new payee review last 6 months | OC |

---

## F6 — Headcount & Vacancy Impact on ECL (MFRS 9 Linkage)

| Entity | Filled / Required | Vacancy % | ECL Implication |
|--------|------------------|-----------|-----------------|
[case figure moved to example-2026-Q1.md]
| Perfect Physio Sdn Bhd | 3/7 | 57.1% | 🔴 Near-operationally-inactive — Stage 2/3 ECL for RM 739,618 interco receivable |
| Perfect Dental Sdn Bhd | 5/8 | 37.5% | 🟠 Constrained capacity — Stage 2 ECL for RM 888,659 |
[case figure moved to example-2026-Q1.md]

Vacancy rate is the leading indicator of trading decline. Use in MFRS 9 ECL Stage assessment (Reference E).
