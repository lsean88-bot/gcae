> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- Expansion Framework
- MFRS 16 — Lease Accounting for Dialysis Centres
- Capex Governance Controls
- MFRS 116 — Property, Plant & Equipment (Fit-Out)
- Expansion Financial Model — Audit Reference


# Expansion Governance Reference — 6 Centres Per Year

## Expansion Framework

### CKAPS Pre-Approval Process (Mandatory Sequence)

```
Stage 1: Site Identification & Feasibility
  ├── Market assessment (patient catchment, competition, PERKESO eligibility)
  ├── Nephrologist commitment obtained
  ├── Preliminary building assessment (floor area, RO room, isolation room)
  └── Management / board approval for site selection

Stage 2: Regulatory Pre-Approval (before lease/capex commitment)
  ├── Form A — Planning Intent submitted to CKAPS
  ├── Building plan submission (BOMBA fire safety, local council)
  ├── CKAPS building inspection (floor plan, water, power, drainage, waste)
  └── CKAPS provisional approval received

Stage 3: Lease & Fit-Out (after CKAPS provisional approval)
  ├── Tenancy agreement signed and stamped (LHDN stamp duty per Stamp Act 1949)
  ├── MFRS 16 lease commencement date recorded
  ├── Fit-out commencement (board-approved capex)
  ├── RO water system installation (AquaBplus 1000 if FMC-supplied)
  ├── Electrical and plumbing works (stable supply per PPT Clause 6.1(iii))
  └── FMC machine installation (within 60 days per PPT Clause 2.2)

Stage 4: CKAPS Final Licence Application
  ├── Form B — Licence application submitted (minimum 3 months before opening)
  ├── CKAPS final inspection
  ├── Certificate of Registration issued
  └── Annual Practising Certificate for nephrologist at this centre

Stage 5: Operations Launch
  ├── Commitment Start Date triggered (first PO within 3 months of installation)
  ├── PERKESO panel application (if applicable centre)
  ├── First patient treatment
  └── Ramp-up monitoring (monthly treatment count vs PPT commitment)
```

**🔴 CRITICAL AUDIT ALERT:** If CKAPS pre-approval has NOT been obtained before lease is signed or fit-out capex committed → finding: regulatory sequence breach + contingent loss (forfeited lease payments if CKAPS denies)

---

## MFRS 16 — Lease Accounting for Dialysis Centres

### Lease Recognition at Each New Centre

**Commencement date:** Date of lease commencement = date CUSTOMER obtains access to the Premises (per MFRS 16.26) — NOT date of CKAPS approval

**Right-of-Use (ROU) Asset calculation:**
```
ROU = Initial lease liability
    + Initial direct costs
    + Prepaid lease payments at commencement
    − Lease incentives received
    + Estimated cost of restoration (if required by lease)
```

**Lease Liability calculation:**
```
Lease Liability = Present Value of future lease payments
               = Σ [Monthly Rent × (1 − (1 + r)^-n) / r]
Where:
  r = Incremental borrowing rate (IBR) — typically 5%–8% in Malaysia (verify BNM base rate)
  n = Lease term in months (economic life, not necessarily contractual term)
```

**Lease term determination:**
- **CKAPS alignment:** Dialysis centres typically have 3-year tenancy agreements with options to renew
- If exercise of renewal option is reasonably certain (centre established, patients committed, PPT machines deployed): include renewal option period in lease term
- PPT machine Commitment Period = 7 years → in most cases, the economic lease term should be ≥ 7 years to match PPT commitment
- Short-term lease exception (≤ 12 months): CANNOT be applied if centre is a going-concern dialysis operation under 7-year PPT commitment

**Depreciation of ROU:**
- Depreciate over SHORTER of lease term or useful life of underlying asset
- For dialysis centres: depreciate over lease term (since tenant does not own building)
- Method: straight-line

**Audit test:**
1. Obtain all lease agreements for all 14+ centres + new expansion centres
2. Build MFRS 16 lease schedule:

| Centre | Commencement Date | Monthly Rent (MYR) | Lease Term (months) | IBR | ROU Asset | Lease Liability |
|--------|-----------------|-------------------|--------------------|----|----------|----------------|
| Centre 1 | | | | | | |
| Centre 2 | | | | | | |
| ... | | | | | | |

3. Verify ROU asset and lease liability per audited financial statements
4. Verify depreciation charge and interest unwinding for the period

---

## Capex Governance Controls

**Required controls per Limits of Authority (LOA):**

| Capex Amount | Required Approval |
|-------------|------------------|
| < RM 20,000 | Centre Manager or Finance Manager |
| RM 20,000–RM 100,000 | Chief Executive Officer |
| > RM 100,000 | Board of Directors |
| Related-party vendor | Board + independent valuation |

**Audit tests:**
1. `[INS]` LOA schedule — verify existence and board approval
2. `[INS]` all capex POs and contracts for new centres — match to LOA approval level
3. `[INS]` competitive quotations: ≥ 3 quotations for contracts > RM 10,000 (anti-corruption)
4. `[INS]` board minutes — capex line items on agenda and approved

---

## MFRS 116 — Property, Plant & Equipment (Fit-Out)

**Capitalisation threshold:** Establish and consistently apply (typically RM 1,000–RM 5,000 for healthcare; board to approve)

**What to capitalise (MFRS 116.7):**
- Purpose-built fit-out: air-conditioning, electrical fit-out for RO, plumbing, isolation wall construction
- RO water system (if not FMC-supplied): major installation
- Built-in storage and utility room construction

**What to expense:**
- General repairs and maintenance
- Decorative items (curtains, paint, non-structural)
- Items below capitalisation threshold

**Useful life policy — dialysis centre fit-out:**
| Asset | Typical Useful Life |
|-------|-------------------|
| Electrical installation | 10 years |
| Air-conditioning | 8 years |
| RO plumbing and pipework | 10 years |
| Leasehold improvement (general) | Shorter of lease term or 10 years |

---

## Expansion Financial Model — Audit Reference

### Key assumptions to challenge (for each new centre):
1. **Ramp-up rate:** Is the assumed patient intake rate achievable? Compare to actual ramp-up of comparable existing centres (Months 1–12)
2. **Nephrologist referral base:** Is the nephrologist contracted? Has confirmed patient referral pipeline?
3. **PERKESO vs private split:** Is PERKESO panel application submitted? Timeline to panel approval?
4. **FMC machine installation:** Confirmed within PPT Clause 2.2 deadline?
5. **PPT commitment start date:** 3-month window after installation; first PO must be placed
6. **Break-even:** Does the model achieve EBITDA breakeven within 12–18 months at assumed treatment volume?

### Red flags in expansion plans:
- New centre planned in area where CKAPS has indicated moratorium on new licences
- Lease signed before CKAPS pre-approval
- No confirmed nephrologist at opening
- Treatment volume assumption exceeds chair capacity × 3 shifts
- Capex approved without competitive quotation
- Related-party landlord (owner = shareholder or director) — RPT disclosure and arm's-length test required
