> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- Governing Legislation (as of 2025)
- Contribution Rates Summary (2025)
- Employment Act 1955 — Key Manufacturing Obligations
- Foreign Worker Compliance (Erawan manufacturing)
- Ghost Employee Detection
- 4-Way Headcount Reconciliation


# Employment & Statutory Payroll Compliance Reference — Malaysia (Erawan)

## Governing Legislation (as of 2025)

| Statute | Current Version | Key 2022–2025 Change |
|---------|----------------|----------------------|
| Employment Act 1955 (EA) | Amended by Act A1651; effective 1 Jan 2023 | Extended coverage; OT limit change; flexible work; domestic violence leave; sexual harassment |
| EPF Act 1991 | Multiple amendments | Employer and employee rates [MY-005], [MY-004]; foreign workers [MY-006] |
| SOCSO Act 1969 | — | SOCSO and EIS insurable wage ceiling [MY-007] |
| EIS Act 2017 | — | EIS insurable wage ceiling [MY-007]; rate [MY-009] |
| HRD Corp Act 2001 (HRDF) | — | levy per [MY-045]; registration threshold as stated there |
| Minimum Wages Order 2024 | Gazette P.U.(A) 376/2024 | [MY-003] |
| Income Tax Act 1967 — MTD/PCB | — | CP39 monthly; CP39A for additional deduction |

## Contribution Rates Summary (2025)

### EPF (KWSP)
| Employee Category | Employer | Employee | Cap |
|-----------------|---------|---------|-----|
| Malaysian/PR aged <60, lower wage band | employer [MY-005] | employee [MY-004] | No cap |
| Malaysian/PR aged <60, higher wage band | employer [MY-005] | employee [MY-004] | No cap |
| Malaysian/PR aged 60–75 | see [MY-005] | see [MY-004] | — |
| Foreign workers (from Oct 2025) | 2% | 2% | No cap |

Contribution must be paid by **15th of the following month**.
Late payment: penalty per [MY-044].

### SOCSO (PERKESO)
| Scheme | Employer Rate | Employee Rate | Wage Ceiling |
|--------|--------------|--------------|-------------|
| Employment Injury + Invalidity (combined) | [MY-008] | [MY-008] | [MY-007] |
| Employment Injury only (age ≥60) | [MY-008] | [MY-008] | [MY-007] |

Malaysian citizens and PRs only. Foreign workers excluded from invalidity scheme.
Due: **15th of following month** together with EIS.

### EIS (Employment Insurance System)
| Rate | Employer | Employee | Eligibility |
|------|---------|---------|------------|
| Standard | [MY-009] | [MY-009] | Malaysian/PR in the covered age band; excludes foreign workers, domestic workers |
| Wage ceiling | — | — | [MY-007] |

### PCB / MTD (Monthly Tax Deduction)
- Calculated per LHDN MTD schedule or Computerised Calculation method
- Non-residents: flat **30%** on employment income
- Remit via **CP39** by 15th of following month
- LHDN penalty for late remittance: per [MY-044]

### HRD Corp (HRDF)
- Manufacturing sector with **≥10 Malaysian employees**: mandatory levy per [MY-045] on Malaysian employee wages
- Paid monthly to HRD Corp by 15th of following month
- Training claims submitted through HRD Corp portal to recover levy

## Employment Act 1955 — Key Manufacturing Obligations

### Overtime (Section 60A)
- Ordinary hours: max 8 hours/day, 48 hours/week
- Overtime: max **104 hours/month** (note: EA Amendment 2022 — verify current limit)
- Overtime rate: 1.5× for work beyond normal hours on ordinary day; 2× rest day; 3× public holiday

### Leave Entitlements (Sections 60D–60F)
| Leave Type | Entitlement |
|-----------|------------|
| Annual leave | 8–16 days depending on service years |
| Sick leave (non-hospitalization) | 14–22 days |
| Sick leave (hospitalization) | 60 days |
| Maternity leave | 98 days (EA Amendment 2022, increased from 60) |
| Paternity leave | 7 days (EA Amendment 2022 — new) |
| Domestic violence leave | 5 days (EA Amendment 2022 — new) |

### EA Amendment 2022 — New Requirements
1. **Flexible working arrangement (FWA):** Employee may request; employer must respond within 60 days
2. **Sexual harassment policy:** Mandatory; complaints procedure documented
3. **Domestic violence leave:** 5 days paid; policy required
4. **Forced labour provisions:** Section 90A — prohibition on employer retaining travel documents

## Foreign Worker Compliance (Erawan manufacturing)
- Foreign workers common in gas cylinder manufacturing (press operators, painters, general labour)
- **Work Permit:** Employment Pass (professional) or Temporary Employment Visit Pass (PLKS/VDLK) via JTK
- **JTK online notification:** Employer must register and notify changes in foreign worker count
- **Levy:** Annual foreign worker levy to Ministry of Home Affairs (rate depends on sector/source country)
- **SOCSO (from 1 Jul 2024):** All employees under contract of service including foreigners → Employment Injury Scheme (EIS); Invalidity Scheme (EIS for citizens/PR only)
- **EPF (from Oct 2025):** Foreign workers in private sector must contribute at the [MY-043] rates

## Ghost Employee Detection
1. `[ANA]` Cross-reference payroll bank account numbers — any shared by ≥2 employees = 🔴 immediate flag
2. `[ANA]` Cross-reference EPF/SOCSO numbers — EPF number should be unique per individual
3. `[OBS]` + `[INS]` Physical headcount vs. payroll list vs. KWSP portal count
4. `[INS]` IC/passport number per employee → verify unique, not duplicated
5. `[ANA]` Employees with no access card swipes/attendance records in pay period → follow up

## 4-Way Headcount Reconciliation
| Register | Source | Evidence Tag |
|---------|--------|-------------|
| EPF register | `[CON]` KWSP i-Akaun employer | Highest reliability |
| SOCSO register | `[CON]` PERKESO portal | High reliability |
| Payroll register | `[INS]` payroll system extract | Medium |
| Physical/access card | `[OBS]` or `[INS]` access system | Corroborative |

Expected: All four counts match. Any discrepancy by employee name/IC = finding.
