> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- SKILL ARCHITECTURE
- Step 0 — Evidence Standard (Mandatory Before Any Fieldwork)
- Step 1 — Entity & Engagement Context
- Step 2 — Mandatory Web-Validation Searches
- Step 3 — Document Inventory (Tiered)
- Step 4 — Audit Domains
- Step 5 — Report structure
- Non-Negotiable Validation Standards


# Malaysia Healthcare, Clinical & Kidney Dialysis — Internal Audit Skill

**Jurisdiction:** Malaysia (Peninsular; Sabah/Sarawak where applicable)
**Standard:** IIA GIAS 2024 (effective 9 Jan 2025) | COSO ERM 2017 | ACFE Fraud Tree
**Healthcare scope:** GP Clinics | Specialist Clinics | Aesthetic Clinics | Multi-Specialty Centres | Kidney Dialysis (Haemodialysis) Centres
**Version:** 1.0 — May 2026 (SST on private healthcare for non-Malaysians from 1 Jul 2025 ([MY-032]); EPF foreign workers Oct 2025; minimum wage [MY-003]; SOCSO/EIS ceiling [MY-007]; PDPA Amendment 2024; MMC APC 2026 backdate per MOH Jan 2026)

> **IRON RULE:** No finding on assumption. No estimate without source data and formula.
> **IRON RULE:** Every rate, threshold, deadline cited must be verified against official portal before use.
> **IRON RULE:** Cite Act + Section + Year + effective date on every finding.
> **EVIDENCE TAGS:** `[INS]` `[PHY]` `[CON]` `[REC]` `[OBS]` `[ANA]` `[REP]` — tag every test.
> **CLINICAL RULE:** Treatment-count findings must reconcile: machine log → consumable PO → invoice → collection.

---

## SKILL ARCHITECTURE

```
my-healthcare-clinical-dialysis-audit/
├── SKILL.md                               ← This file
└── references/
    ├── R01_phfsa_ckaps_licensing.md       ← PHFSA 1998 Act 586, CKAPS, MOH licensing, MMC/APC
    ├── R02_dialysis_clinical.md           ← CKAPS dialysis, nephrologist ratio, nurse:machine, RO water, PPT
    ├── R03_ppt_fmc_contracts.md           ← PPT 2025/112 & 2026/114, commitment, CRV, consumable pricing
    ├── R04_perkeso_panel_billing.md       ← PERKESO dialysis tariff, panel billing, claims reconciliation
    ├── R05_sst_tax_healthcare.md          ← SST non-Malaysians (Jul 2025, [MY-032]), exempt Malaysians, MyInvois
    ├── R06_income_tax_mfrs.md             ← ITA 1967, MFRS 15/16/102/116/119, Companies Act 2016
    ├── R07_employment_payroll.md          ← EA 1955, EPF, SOCSO, EIS, HRD Corp, PCB, min wage [MY-003]
    ├── R08_pdpa_data_governance.md        ← PDPA 2010 (Amdt 2024), patient data, breach notification
    ├── R09_fraud_clinical.md              ← Phantom treatments, reuse falsification, cash diversion, kickbacks, MACC
    ├── R10_financial_controls.md          ← AP/AR, cash, 3-way match, billing system, bank reconciliation
    ├── R11_capex_expansion.md             ← CKAPS pre-approval, centre build capex, MFRS 16 lease, equipment
    ├── R12_benchmarking_kpis.md           ← Treatments/chair, chair utilisation, COGS/treatment, Kt/V, MSDS
    └── R13_compliance_calendar_hc.md      ← Full Malaysia healthcare compliance calendar + penalties
```

---

## Step 0 — Evidence Standard (Mandatory Before Any Fieldwork)

| Tag | Type | Reliability |
|-----|------|------------|
| `[CON]` | External confirmation / portal extract | MOH eSPKKS, SSM MyCoID, LHDN MyTax, KWSP i-Akaun, PERKESO ASSIST, JPDP, BNM — Rank 1 |
| `[PHY]` | Physical observation / count | Rank 1 for existence; auditor must witness |
| `[INS]` | Document inspection | Original preferred; authenticated copy |
| `[REC]` | Recalculation / reperformance | Auditor independently recomputes from primary data |
| `[OBS]` | Process observation | Supplement with other evidence; timing risk |
| `[ANA]` | Analytical procedure | Benford, trend, ratio, population — system-extracted |
| `[REP]` | Management report/representation | Rank 5 — initiate inquiry only; never close finding |

**Operational rules:**
1. Every 🔴 Critical finding requires at least one `[CON]` or `[PHY]` or witnessed `[REC]`
2. Treatment-count findings: reconcile machine log → PO → invoice → collection (4-leg test)
3. All monetary findings quantified in **MYR**
4. "Evidence Not Obtained" = valid conclusion; document what was requested and risk
5. Contradict, don't defer — evidence governs over management

---

## Step 1 — Entity & Engagement Context

| Field | Verified Source |
|-------|----------------|
| SSM company status | mydata.ssm.com.my — active, directors, paid-up capital |
| CKAPS operating licence(s) — each facility | `[CON]` MOH eSPKKS portal (sppkk.moh.gov.my) — per centre |
| Specialist/physician registration | `[CON]` MMC register (mmc.gov.my) — valid APC 2026 |
| Total facilities operating | Count: dialysis centres / clinics / branches |
| PPT agreement(s) | PPT 2025/112 and/or PPT 2026/114 — machine count, commitment, expiry |
| PERKESO panel status | PERKESO portal — panel approval, contracted centres |
| Patient census (dialysis) | Chair utilisation, treatments per month per centre |
| Cash vs cashless payment split | Cash-diversion risk; reconciliation controls |
| Billing/HIS system | ClinicMaster, HIS, custom — evidence availability |
| EPF / SOCSO headcount | `[CON]` i-Akaun employer portal |
| SST registration (if applicable) | `[CON]` MySST portal — registered for service tax? |
| e-Invoice phase | `[CON]` myinvois.hasil.gov.my — annual turnover vs phase |
| Lease structure | MFRS 16 — all premises leases |
| Prior MOH / CKAPS inspection | Any prior inspection findings → elevate clinical domains |

---

## Step 2 — Mandatory Web-Validation Searches

Run before ANY finding:

```
Malaysia PHFSA 1998 Act 586 CKAPS private healthcare facility licensing 2025 2026
Malaysia MOH CKAPS dialysis centre licence requirements nephrologist nurse ratio
Malaysia MMC APC annual practising certificate 2026 renewal
Malaysia PERKESO dialysis tariff per session rate 2025 2026
Malaysia SST private healthcare service tax non-citizen July 2025
Malaysia SST private healthcare Malaysian citizen exemption 2025
Malaysia e-Invoice MyInvois healthcare clinic threshold 2025 2026
Malaysia EPF contribution rate 2026 employer healthcare sector
Malaysia EPF foreign workers mandatory October 2025 rate
Malaysia SOCSO EIS wage ceiling current PERKESO notice
Malaysia minimum wage order current effective dates by employer size
Malaysia PDPA 2010 amendment 2024 healthcare patient data breach
Malaysia MACC section 17A corporate liability healthcare adequate procedures
Malaysia FMC PPT dialysis consumable agreement 2025 2026
Malaysia MSDS MOH dialysis national registry benchmark
CKAPS pre-approval new dialysis centre floor area requirements
RO water quality dialysis AAMI ISO 23500 Malaysia MOH
Malaysia Employment Act 1955 amendment 2022 healthcare worker overtime
```

---

## Step 3 — Document Inventory (Tiered)

**Mark:** ✅ Obtained | ⚠️ Partial | ❌ Not Provided

### Tier 1 — Mandatory
- [ ] CKAPS operating licence — per centre `[CON]` eSPKKS portal verification
- [ ] PPT Agreement (FMC) — PPT 2025/112 and/or PPT 2026/114 `[INS]`
- [ ] Monthly treatment count logs (machine-level) `[INS]`
- [ ] PERKESO billing submissions and claim receipts `[CON]` PERKESO portal
- [ ] Audited financial statements — last 2 years + current management accounts
- [ ] EPF contributions `[CON]` i-Akaun employer portal — all periods
- [ ] SOCSO/EIS contributions `[CON]` PERKESO ASSIST — all periods
- [ ] PCB/MTD returns `[CON]` LHDN e-PCB
- [ ] Bank statements — all accounts (all facilities)

### Tier 2 — Domain-Specific
- [ ] Monthly consumable purchase orders (dialysers, Diasafe, Citrosteril, AVF needles, acid/bicarbonate)
- [ ] Dialyser reuse records (machine log / reuse tags)
- [ ] RO water quality test certificates (every 6 months minimum)
- [ ] Adverse event register + MOH notification records
- [ ] Patient billing ledger — PERKESO vs private vs other payers (by facility)
- [ ] SST registration and SST-02 returns (if applicable post-Jul 2025)
- [ ] Tenancy/lease agreements — all premises (MFRS 16 computation)
- [ ] CKAPS expansion pre-approval letters (for centres under development)
- [ ] Actuarial report — MFRS 119 employee defined benefit obligations
- [ ] Referral records — any referral fee arrangement (MACC s.17A risk)
- [ ] Medical waste management records (Kualiti Alam / DOE manifest)

---

## Step 4 — Audit Domains

### Domain 1 — PHFSA 1998 / CKAPS Regulatory Compliance

**Statute:** Private Healthcare Facilities and Services Act 1998 (Act 586); PHFSA Regulations 2006 P.U.(A) 138/2006; PHFSA (Private Hospitals and Other Private Healthcare Facilities) Regulations 2006

| Test | Evidence | Key Rule |
|------|---------|---------|
| Operating licence — per facility | `[CON]` MOH eSPKKS portal — licence number, expiry, facility address match | Every private healthcare facility must be licensed under Act 586 Sec 6; operating without licence = penalty per [MY-050] |
| Licence renewal — timely | `[INS]` renewal application vs licence expiry | Licence valid 2 years; must apply for renewal before expiry |
| Physician/specialist MMC registration | `[CON]` MMC register (mmc.gov.my) — registration number valid | All doctors practising must be registered with MMC (Medical Act 1971) |
| Annual Practising Certificate (APC) | `[CON]` MMC MeRITS system — 2026 APC issued | APC mandatory each year; MOH Jan 2026 clarification: no enforcement against doctors with pending 2026 APC if applied by 31 Dec 2025 |
| CKAPS pre-approval — new centres | `[INS]` CKAPS approval letter vs actual opening date | Must obtain approval before establishing or modifying facility; CKAPS inspects premises |
| Facility compliance with PHFSA schedule | `[INS]` facility compliance checklist + `[OBS]` site visit | First Schedule: minimum standards for private hospitals, specialist clinics, dialysis centres |
| Medical waste disposal | `[CON]` DOE / Kualiti Alam licence + manifests | Scheduled waste — clinical waste (Category A/B); contractor must be DOE-licensed |
| Adverse event / incident reporting | `[INS]` adverse event register vs MOH notification | PHFSA regulations — serious adverse events must be reported to MOH |

---

### Domain 2 — Dialysis Clinical Compliance (CKAPS / MOH)

**Statute:** PHFSA 1998 Act 586; MOH CKAPS Dialysis Centre Standards; AAMI/ISO 23500 (RO water quality)

| Test | Evidence | MOH Standard |
|------|---------|-------------|
| Nephrologist-to-chair ratio | `[REC]` registered nephrologists per centre ÷ installed chairs `[CON]` MMC | MOH: minimum **1 nephrologist per 20 chairs** per centre; verify CKAPS licence endorsement |
| Nurse-to-machine ratio | `[INS]` staff rota per shift + `[OBS]` site visit | MOH: **1 trained dialysis nurse per 4 machines** during operation |
| Dialysis nurse qualification | `[INS]` nurse certificates + MOH-endorsed dialysis training | Must be trained in haemodialysis; training certificate from accredited institution |
| RO water quality (reverse osmosis) | `[INS]` test certificates (every 6 months minimum) | AAMI/ISO 23500: total viable bacteria <100 CFU/mL; endotoxin <0.25 EU/mL; chemical contaminants within limits |
| Dialyser reuse protocol | `[INS]` reuse log; `[OBS]` reuse room | PPT Schedule IV: 9 reuses + 1 first use = **10 sessions per dialyser maximum**; patient-specific reuse; germicide testing |
| Reuse ratio reconciliation | `[REC]` Total sessions ÷ Dialysers consumed | Should approximate 10; significantly lower = wastage or under-recording; higher = protocol violation |
| Hepatitis B seroconversion monitoring | `[INS]` patient HBsAg records | Benchmark: <1% new Hep B positives among susceptible patients; MOH reporting obligation |
| Kt/V adequacy | `[INS]` patient dialysis adequacy records | KDOQI: ≥1.2 Kt/V for single-pool; ≥80% of patients achieving target |
| Emergency equipment availability | `[PHY]` site inspection | Crash cart; defibrillator; oxygen; emergency drugs — verified per CKAPS requirement |
| Isolation room for infected patients | `[PHY]` physical verification | HBsAg+ / HCV+ patients: separate machines; isolation protocols per MOH guideline |

---

### Domain 3 — PPT / FMC Contract Compliance

**Contracts:** PPT 2025/112; PPT 2026/114 (verify actual contract numbers and terms)

| Test | Evidence | Key Rule |
|------|---------|---------|
| Treatment commitment — tracking | `[REC]` Contracted treatments vs actual per month per machine | PPT Clauses 2.4–2.7 — minimum treatment commitment; shortfall → Commitment Reconciliation Value (CRV) payable |
| CRV computation | `[REC]` (Committed treatments − Actual treatments) × PPT rate | PPT rate: Schedule IV — **PPT 2025/112: RM56.00/session; PPT 2026/114: RM42.75/session** (web-verify current rates) |
| Machine count per agreement | `[PHY]` machine serial count vs PPT Schedule VIII | Machine inventory matches contract; any unregistered machine = contract breach |
| Consumable billing — 3-way match | `[INS]` PO + Delivery Note (DN) + Invoice | All consumable invoices: matched to DN and patient treatment count |
| Consumable pricing vs Schedule IV | `[REC]` Invoice price vs PPT Schedule IV rates | Overcharging by FMC = claim for rebate; undercharging may indicate PPT amendment |
| Change of control — advance notice | `[INS]` correspondence per PPT Clause 9.2(vi) | Any change in shareholding/control: 21 days advance written notice to FMC |
| Guarantor obligations | `[INS]` signed guarantees per PPT Clause 4.9 | Personal guarantees — verify still in force; any change in guarantor status |
| RO water machine — FMC supplied vs operator | `[INS]` PPT schedule — machine ownership | Water treatment equipment under PPT: who owns, maintains, replaces — verify |

---

### Domain 4 — PERKESO Panel Billing & Revenue Reconciliation

**Statute:** Employees' Social Security Act 1969; SOCSO dialysis tariff schedule

| Test | Evidence | Key Rule |
|------|---------|---------|
| PERKESO panel approval — per centre | `[CON]` PERKESO portal — approved panel list | Each centre must be individually approved; billing only from approved centres |
| PERKESO tariff per session | `[CON]` PERKESO portal — current approved rate | Web-verify current PERKESO dialysis tariff (per session, including consumables vs separate billing) |
| Billing submission vs treatment count | `[REC]` PERKESO claim submission vs machine treatment log | complete reconciliation — every billed session must correspond to a logged treatment |
| Collection from PERKESO | `[INS]` PERKESO remittance advice vs AR | PERKESO credit terms: ~45–60 days; ageing >60 days = collection risk |
| Private patient billing | `[INS]` private billing ledger vs collection | Trace to bank statement; cash vs cashless breakdown |
| Revenue per treatment — by payer type | `[ANA]` Revenue ÷ Treatments per payer type | PERKESO capped rate vs private (higher); mixed payer economics |
| Debtors ageing — PERKESO vs private | `[INS]` AR ageing | PERKESO DSO target: <60 days; Private DSO target: <30 days |

---

### Domain 5 — SST Compliance (Healthcare — Post-July 2025)

**Statute:** Service Tax Act 2018; Service Tax (Rates of Tax) Order 2018 (expanded 1 Jul 2025); MOF Press Release 9 Jun 2025

| Test | Evidence | Key Rule (Effective 1 Jul 2025) |
|------|---------|--------------------------------|
| Malaysian citizen patients — SST | `[INS]` billing system nationality classification | **Exempt: services to Malaysian citizens** regardless of facility type |
| Non-Malaysian patients — SST | `[INS]` sample invoices to non-Malaysians | **service tax ([MY-032])** on ALL private healthcare services to non-Malaysian patients (hospitals, clinics, dental, aesthetic, allied health, dialysis) from **1 Jul 2025** |
| SST registration (threshold) | `[CON]` MySST portal — registration status | Registration mandatory if SST-taxable turnover (non-Malaysian patient revenue) exceeds the threshold in [MY-031] |
| SST-02 returns | `[CON]` MySST portal submission history | Filed bi-monthly; due 28th of following period |
| Traditional & complementary medicine | `[INS]` service classification | T&CM services to non-Malaysians also subject to SST ([MY-032]) from 1 Jul 2025 |
| e-Invoice MyInvois | `[CON]` myinvois.hasil.gov.my — phase applicability | Phases per [MY-020] and [MY-034]; all invoices to non-Malaysians require e-invoice for SST compliance |
| RMCD grace period | Grace period ended 31 Dec 2025 — no penalties for non-compliance during grace | Verify compliance status from 1 Jan 2026 onwards |
| PERKESO patients — SST | `[INS]` PERKESO is Malaysia government agency | Government-funded treatments may be exempt — verify RMCD guidance |
| Imported medical services | `[INS]` any payments to foreign specialists / telemedicine | Import of taxable services by registered person: reverse charge mechanism |

---

### Domain 6 — Income Tax & MFRS

**Statute:** Income Tax Act 1967; MFRS (MFRS 15, MFRS 16, MFRS 102, MFRS 116, MFRS 119); Companies Act 2016

| Test | Evidence | Key Rule |
|------|---------|---------|
| Revenue recognition (MFRS 15) | `[INS]` revenue policy + treatment billing | Revenue recognised when treatment delivered (point in time); subscription/package revenue: over period |
| Lease — MFRS 16 | `[INS]` all lease agreements + ROU asset and lease liability schedule | All leases >12 months: ROU asset + lease liability on balance sheet; dialysis centre premises, equipment leases |
| Inventory (MFRS 102) | `[INS]` consumable stock valuation | Lower of cost or NRV; FIFO or WA; dialysers, Diasafe, AVF needles, acid/bicarbonate |
| Employee benefits (MFRS 119) | `[INS]` actuarial report + provision | Defined benefit: actuarial valuation required; short-term: EA entitlements accrued |
| Fixed assets (MFRS 116) | `[INS]` FA register + depreciation | Dialysis machines: useful life; Fresenius 4008S typically 10–12 years; maintenance capitalisation vs expense |
| Corporate tax — CP204 | `[INS]` CP204 + computation | Corporate tax per [MY-037]; Pioneer Status if applicable |
| SSM annual return | `[CON]` SSM portal | Within 30 days of AGM; AGM within 6 months of FYE |
| Related party transactions | `[INS]` RPT register; `[REC]` arm's length test | Companies Act 2016 s.228; MFRS 124 disclosure |

---

### Domain 7 — Employment, Payroll & HR (Healthcare)

**Statute:** Employment Act 1955 (Amdt 2022 — Act A1651); EPF Act 1991; SOCSO Act 1969; EIS Act 2017; HRD Corp Act 2001; Minimum Wages Order 2024

| Test | Evidence | Current Rate |
|------|---------|-------------|
| Minimum wage — all staff | `[REC]` payroll register all employees | Basic salary at or above the national minimum wage [MY-003]; applies to nurses, technicians, admin, cleaners |
| EPF — local employees | `[CON]` i-Akaun employer | Employer rate [MY-005] and employee rate [MY-004] by salary band |
| EPF — foreign staff (Employment Pass holders) | `[CON]` i-Akaun — foreign worker ECR | Foreign-worker EPF status, rates and start date [MY-006] (conflict MY-C12) |
| SOCSO — all employees | `[CON]` PERKESO ASSIST | Rates [MY-008]; insurable wage ceiling [MY-007] |
| EIS — all employees | `[CON]` PERKESO ASSIST | Rate [MY-009]; insurable wage ceiling [MY-007] |
| HRD Corp levy | `[CON]` HRD Corp portal | levy per [MY-045]; healthcare included |
| OT compliance (nurses, technicians) | `[INS]` time records vs EA 1955 Amdt 2022 | Max **45 hours/week**; OT rate: 1.5× (>45 hr/wk); 2× (rest day); 3× (public holiday) |
| Shift allowance | `[INS]` payroll vs employment contract | Shift premium must be documented; not counted toward minimum wage base |
| PCB/MTD monthly remittance | `[CON]` LHDN e-PCB | Deducted and remitted by 15th |
| Maternity leave (nurses) | `[INS]` HR records | EA 2022: **98 days** paid maternity leave |

---

### Domain 8 — PDPA & Patient Data Governance

**Statute:** Personal Data Protection Act 2010 (Act 709); PDPA (Amendment) Act 2024 (effective verify); Health data = sensitive personal data

| Test | Evidence | Key Rule |
|------|---------|---------|
| PDPA registration (if commercial processor) | `[CON]` JPDP portal (pdp.gov.my) | Healthcare is a designated data user class — registration mandatory |
| Privacy notice to patients | `[INS]` patient registration form + privacy notice | PDPA Sec 7 — privacy notice must be provided before or at time of data collection |
| Consent for sensitive data | `[INS]` signed patient consent forms | Health/medical data = sensitive personal data; explicit consent required for processing |
| Data breach notification | `[INS]` breach response policy + any incident log | PDPA Amdt 2024: breach notification to JPDP **within 72 hours** of becoming aware |
| Data retention policy | `[INS]` data retention schedule | Medical records — PHFSA: retain for minimum 7 years (private hospital) |
| Cross-border data transfer | `[INS]` any patient data sent overseas | PDPA Sec 129: data may only be transferred to countries with adequate protection |
| Data Protection Officer (DPO) | `[INS]` DPO appointment letter | PDPA Amdt 2024: DPO appointment mandatory for certain data user classes — verify if applicable |
| IT system access controls | `[INS]` user access matrix for HIS/billing system | Role-based access; no shared logins; audit trail in billing system |
| Backup and recovery | `[OBS]` + `[INS]` backup logs + restoration test | Patient data backup: daily minimum; off-site or cloud with encryption |

---

### Domain 9 — Fraud Detection & MACC

**Framework:** ACFE Fraud Tree; Benford's Law; MACC Act 2009 (Act 694) Sec 17A

| Fraud Scenario | Test | Evidence |
|----------------|------|---------|
| Phantom treatments (PERKESO) | `[REC]` PERKESO billing vs machine log vs consumable PO | Treatments billed to PERKESO with no corresponding machine session or consumable usage |
| Dialyser reuse falsification | `[REC]` Reuse ratio > 10 (PPT limit) | Reuse records showing >10 sessions per dialyser = protocol violation; may be falsified to reduce consumable cost |
| Cash diversion (private patients) | `[ANA]` Cash collection vs billing system; Benford on cash receipts | Cash collected from private patients not recorded in billing system |
| Ghost staff (nurses/technicians) | `[CON]` EPF ECR headcount vs payroll; `[PHY]` site visit | Payroll inflated; nurse:machine ratio artificially met on paper only |
| Referral kickbacks | `[INS]` referral records; `[ANA]` referral source concentration | Payments to referring doctors = corruption under MACC s.17A; Medical Ethics violation |
| Consumable purchase fraud | `[ANA]` Benford on PO amounts; `[INS]` vendor concentration | Inflated consumable prices; single-source without tender; vendor related to buyer |
| Over-billing PERKESO | `[REC]` PERKESO claim per patient per month vs actual sessions | Maximum 12–13 sessions/month per PERKESO protocol; claims exceeding = fraud risk |
| Related party consumable supply | `[INS]` vendor KYC vs director/shareholder | Consumables purchased from company owned by director/shareholder at inflated price |
| MACC s.17A adequate procedures | `[INS]` 6-pillar documentation: (1) Top management commitment; (2) Policies & procedures; (3) Risk assessment; (4) Due diligence; (5) Training; (6) Monitoring | Organisation liable if any person associated commits corruption; management must prove adequate procedures |

**Benford's Law targets:** PERKESO claims per session; private billing per patient; consumable PO amounts; payroll amounts; cash receipt amounts.

---

### Domain 10 — Financial Controls & AP/AR

| Test | Evidence | Key Rule |
|------|---------|---------|
| 3-way match — consumables | `[INS]` PO + DN/GRN + invoice | All consumable invoices matched before payment; PPT consumables: verify pricing vs Schedule IV |
| Cash collection controls | `[INS]` daily cash count + billing system report | Cash ≠ billing system = gap; reconcile daily per facility |
| Bank reconciliation | `[INS]` monthly bank rec — all accounts | All facilities; reconciled by accounts team; reviewed by Finance Manager |
| PERKESO AR ageing | `[INS]` AR report | PERKESO DSO target <60 days; any >90 days = collection risk; dispute with PERKESO |
| Petty cash controls | `[PHY]` surprise count | Float amount vs vouchers; medical consumables not purchased from petty cash (procurement policy) |
| Vendor payment | `[INS]` dual authorization; bank statement | Above-threshold payments: dual authorization; no cash payments for invoices |
| Intercompany transactions | `[INS]` intercompany loan/management fee | MFRS 124; arm's length test; if related party consumable supply → conflict of interest |

---

### Domain 11 — Centre Expansion & Capex (CKAPS)

| Test | Evidence | Key Rule |
|------|---------|---------|
| CKAPS pre-approval before opening | `[INS]` CKAPS approval letter vs centre opening date | Must obtain CKAPS pre-approval before establishing; violation = unlicensed operation |
| Floor area compliance | `[INS]` CKAPS approval letter specifying min floor area | CKAPS prescribes minimum floor area, chair spacing, isolation room, water treatment room |
| Capex commitment vs budget | `[INS]` capex approval (board minutes) + actual spend | All centre build capex above threshold → Board approval; no pre-approved overspend |
| MFRS 16 — new centre lease | `[REC]` lease term + ROU asset + lease liability | All leases >12 months: ROU asset (discounted future payments) + lease liability; disclosure in financial statements |
| Fresenius/other machine procurement | `[INS]` machine purchase vs PPT | PPT may specify machine types; procurement outside PPT = contract breach risk |
| Dialysis machine commissioning | `[PHY]` + `[INS]` commissioning certificate | Machine must be tested and commissioned before patient use |
| New centre EPF/SOCSO registration | `[CON]` EPF/SOCSO employer registration | Each new centre: separate employer registration if different entity; or sub-code under parent |

---

### Domain 12 — Key Performance Benchmarks (Dialysis)

| KPI | Formula | Benchmark | Source |
|-----|--------|-----------|--------|
| Treatments per machine per month | Total treatments ÷ installed machines | 130–156 (PERKESO); up to 180 (optimised private) | MOH ESRD, MSDS |
| Chair utilisation | Patient-sessions ÷ (chairs × shifts × days) | ≥85% | ANRS; global dialysis |
| Revenue per chair per month | Total revenue ÷ installed chairs | RM6,000–RM12,000 | MSDS estimate |
| COGS as % of revenue | Consumable COGS ÷ revenue | 25–35% | FMC PPT economics |
| PPT cost per treatment (PPT 112) | RM56.00 | PPT 2025/112 Schedule IV | Verify current |
| PPT cost per treatment (PPT 114) | RM42.75 | PPT 2026/114 Schedule IV | Verify current |
| Dialyser reuse ratio | Total sessions ÷ dialysers consumed | 10 (1 first + 9 reuses) | PPT Sched IV; AAMI |
| Hep B seroconversion | New Hep B+ ÷ susceptible patients | <1% | CMS ESRD QIP |
| Kt/V adequacy | Patients ≥1.2 Kt/V ÷ total patients | ≥80% | KDOQI / MOH |
| Nurse-to-machine ratio | Nurses on shift ÷ machines operating | 1:4 | PHFSA / MOH |
| PERKESO DSO | PERKESO AR ÷ (PERKESO rev ÷ 365) | <60 days | Best practice |
| Private DSO | Private AR ÷ (private rev ÷ 365) | <30 days | Best practice |
| Treatment shortfall vs PPT | Actual ÷ committed × 100% | 100% | PPT commitment clauses |

---

## Step 5 — Report structure

Owned by `gia-report-qa:gia-ia-report` (standard concise report plus Excel working paper). This pack emits a findings register and its supporting tables only; the long-form overall-opinion layout in the retired source is a legacy conversion reference and is not used. Dashboards named in the retired layout (yield, labour compliance, OEM scorecard, benchmarks) are working-paper sheets.

## Non-Negotiable Validation Standards

| Standard | Rule |
|----------|------|
| Evidence first | No finding without tag, source, date |
| Quantify always | MYR / treatment count / % — or "Unquantified — [reason]" |
| Cite specifically | Act + Section + Year + effective date; MFRS + para; IIA GIAS 2024 Standard |
| Treatment 4-leg | Machine log → PO → invoice → collection — mandatory for dialysis billing |
| SST — Jul 2025 | **Malaysian patients: exempt**; **Non-Malaysians: service tax ([MY-032])** from 1 Jul 2025 |
| Minimum wage | [MY-003] (never a superseded value) |
| EPF foreign | **[MY-043]** mandatory from Oct 2025 |
| SOCSO/EIS ceiling | [MY-007] |
| CKAPS | No centre opens without CKAPS pre-approval — always verify |
| PPT | Always verify actual current PPT schedule rates; do not assume RM56/RM42.75 without web check |
| Passport custody | Employer holding staff passports = criminal offence |
| Disclaimer | Every report: MIA/licensed tax/healthcare lawyer/clinical advisor review |

*Professional internal audit framework. Not legal, clinical, regulatory, or statutory advice. All regulatory positions verified as at May 2026 — confirm current status with MOH, CKAPS, RMCD, LHDN, EPF, PERKESO, JPDP before action.*
