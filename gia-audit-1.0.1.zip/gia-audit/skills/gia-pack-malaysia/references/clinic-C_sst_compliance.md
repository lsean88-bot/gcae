> Case figures from a prior clinic engagement were moved to example-2026-Q1.md (illustrative, dated).

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.

# Reference C — SST Compliance: Private Healthcare Non-Citizen Patients

## C1 — Legal Framework

**Law:** Service Tax Act 2018 (STA 2018); Service Tax (Amendment) Regulations 2025 (effective 1 July 2025); RMCD Guide on Healthcare Services by Private Healthcare Facilities (June 2025 version)

### Key Parameters (Post-1 July 2025)
| Parameter | Value |
|-----------|-------|
| SST rate on private healthcare to non-citizens | per [MY-032] |
| Registration threshold | per [MY-031] (conflict MY-C14) |
| Basis | **Payment basis** (charge when payment received, not invoice date) |
| Taxable period | **Every 2 months** (bimonthly) |
| SST-02 filing | Last day of following month after period end |
| Malaysian citizens | **EXEMPT** |
| Services exempt regardless of nationality | Government hospital services, social welfare facilities |
| Prescribed services (subject to SST) | Consultation fees, treatment fees, medication (if bundled), diagnostic tests, nursing fees — all to non-citizens |

---

[case figure moved to example-2026-Q1.md]

| Field | Detail |
|-------|--------|
| Registration Number | W10-2508-32000606 |
| Application Date | 08/08/2025 |
| Effective Date | **01/09/2025** |
| Accounting Basis | Payment |
| RMCD Reference | W10-2508-38000606 |
| Controlling Station | Kuala Lumpur (Kompleks Kastam WPKL) |

[case figure moved to example-2026-Q1.md]
| Period No. | Taxable Period | SST-02 Due | Status (as at May 2026) |
|-----------|--------------|-----------|------------------------|
| 1 | 01 Sep – 31 Oct 2025 | **30 Nov 2025** | Unknown — not sighted |
| 2 | 01 Nov – 31 Dec 2025 | **31 Jan 2026** | Unknown — not sighted |
| 3 | 01 Jan – 28 Feb 2026 | **31 Mar 2026** | Unknown — overdue |
| 4 | 01 Mar – 30 Apr 2026 | **31 May 2026** | IMMINENT |
| 5 | 01 May – 30 Jun 2026 | 31 Jul 2026 | Upcoming |

---

## C3 — Audit Tests

| Test | Evidence | Assertion |
|------|---------|-----------|
| SST-02 returns for all periods filed and paid | `[CON]` MySSTportal extract or filed return copies | CP |
| No late filing surcharges accrued | `[REC]` compare due dates vs payment dates | CP |
| Patient nationality captured at registration | `[INS]` patient registration forms / IC vs passport | CO |
| SST separately itemised on invoices to non-citizens | `[INS]` sample invoices post-01 Sep 2025 | CP |
| POS SST payment field captures SST per transaction | `[REP]` POS Sst Payment column | AC |
| SST collected reconciles to SST-02 declared | `[REC]` POS SST sum vs SST-02 declared | AC, CO |
| GL SST-KASTAM and SST-203 balances reconcile to SST-02 | `[REC]` GL balances vs returns | AC |

---

## C4 — Penalty Framework (STA 2018)

| Offence | Penalty |
|---------|---------|
| Late payment of SST | per [MY-033] |
| Non-filing of SST-02 | per [MY-033] |
| Tax evasion / understated SST | per [MY-033] |
| Failure to register | per [MY-033] |
| Non-compliant invoice | per [MY-033] |
| Records not kept 7 years | per [MY-033] |

---

## C5 — Invoice Compliance Requirements (Post-SST)

RMCD Appendix I requires all SST-registered persons to issue invoices containing:
1. Serial invoice number
2. Invoice date
3. Supplier name, address, registration number
4. Customer name and address
5. Quantity and description of services
6. Any discounts
7. Net amount (excl. SST)
8. SST rate and SST amount **shown separately**
9. Total amount including SST
10. Foreign currency equivalent in RM if applicable

[case figure moved to example-2026-Q1.md]

---

## C6 — Voluntary Disclosure Mechanism

Under STA 2018 s.50, a person who makes a voluntary disclosure of tax underpaid before RMCD commences an audit:
- Penalty is **waived or substantially reduced**
- Requires written disclosure to RMCD with full computation of tax due
- Engage a RMCD-accredited SST tax agent to prepare and submit

**Recommended for Periods 1–3 if not yet filed.**
