> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- 1. Entity-Aware Context
- 2. Statutory Framework & Current Baselines
- 3. Audit Lifecycle
- 4. Risk-Control Matrix (Summary)
- 5. Statutory Reperformance Tests
- 6. Fraud Risk Assessment
- 7. Key Audit Tests Checklist
- 8. Finding Draft Template (5C)
- Reference Files


# Malaysia HR & Payroll Internal Audit Skill

**Jurisdiction:** Peninsular Malaysia and Federal Territories (EA 1955). Sabah/Sarawak: use state labour ordinances — flag and exclude from EA tests.  
**IIA Standard:** GIAS 2024 | COSO IC 2013 | COSO ERM 2017 | ACFE CFE | MAC Art.12 (zero assumption) | Art.13 (zero hallucination)  
**Effective-date discipline:** All statutory rates and thresholds must be verified against primary sources (EPF/PERKESO/LHDN circulars, MoHR gazettes) at audit commencement. Rates below are reference baselines only.

---

## 1. Entity-Aware Context

Read the relevant entity section before scoping tests. Multiple entities may apply in one engagement.

→ See `references/hr-entities.md` for full entity profiles (MKPC, Nephrocare, Erawan, Group-level).

**Quick selector:**
| Entity | Primary HR risks | Key statutes beyond EA |
|--------|-----------------|------------------------|
| MKPC (die casting/stamping, Shah Alam/Johor) | Foreign worker permits, Act 446 housing, levy deductions, OT manipulation, IATF headcount | Act 446, Immigration Act, IATF 16949 headcount CSRs |
| Nephrocare (dialysis, multi-centre) | PERKESO panel staff classification, nephrologist/nurse ratios, clinical OT, PCB for contract clinicians | PHFSA 1998, CKAPS, PERKESO Panel Agreement |
| Erawan (LMW gas cylinders) | Act 446 rent deduction cap, foreign worker levy, DOSH compliance, factory hours | Act 446 (state gazette cap), Factories Act, DOSH |
| MK Tron Group (holding/HQ) | EP salary consistency, MACC s.17A third-party payments, PDPA HR data | MACC Act 2009, PDPA 2010 (Amdt 2024) |

---

## 2. Statutory Framework & Current Baselines

> ⚠️ Verify all figures against primary sources before fieldwork. These are audit-commencement baselines.

### 2.1 Employment Act 1955 (EA 1955)
- **Amended:** Act A1651, effective **1 Jan 2023** — scope expanded (all employees regardless of wage), 45-hour/week cap, enhanced maternity (98 days), paternity leave (7 days), flexible work arrangement provisions
- **OT multipliers:** 1.5× on normal day; 2× on rest day (>8h); 3× on public holiday
- **Leave minima:** Annual leave 8–16 days by tenure; sick leave 14–22 days; hospitalisation up to 60 days

### 2.2 Minimum Wages
- **Current:** [MY-003] (Minimum Wages Order 2024; value and effective date by employer size in the register)
- **Audit test:** Basic pay at or above the national minimum wage [MY-003]; allowances excluded from basic cannot be used to meet the floor

### 2.3 EPF (KWSP)
- **Employee:** 11% (age ≤60); 5.5% (age 60+)
- **Employer:** rate by wage band [MY-005]; reduced rate for age 60 and above or certain categories also in the register
- **Foreign workers:** status, rates and start date [MY-006]
- **Remittance deadline:** [MY-010]

### 2.4 SOCSO & EIS
- **Ceiling wage:** [MY-007]
- **SOCSO:** Employment Injury Scheme + Invalidity Scheme; rates [MY-008]
- **EIS:** rate [MY-009]; capped at the insurable wage ceiling [MY-007]
- **Remittance:** 15th of following month; via i-Akaun/ASSIST portal
- **Foreign workers:** SOCSO (Employment Injury only, employer only); EIS not applicable

### 2.5 PCB/MTD (Income Tax)
- **Authority:** LHDN; computed per current year PCB schedule
- **Obligation:** Deduct monthly from employee wages; remit by 15th of following month
- **Risk:** Outdated tables, manual overrides, non-deduction for part-month joiners/leavers

### 2.6 Employment Pass (Expatriates)
- **Categories:** Cat I, Cat II and Cat III salary bands and the date they apply from: [MY-013] (verify ESD/MOHA notices for any sector-specific variations)
- **Audit test:** Contract salary vs payslip vs ESD submission — all three must align; no downgrade post-approval

### 2.7 Act 446 — Worker Housing
- **Scope:** Employer-provided accommodation for workers (primarily foreign)
- **Rent deduction cap:** State-gazette specific; **verify current applicable cap in your state at audit date** (commonly cited RM150/month where gazetted — confirm via MoHR notice)
- **Standards:** Minimum space per person, bedding, sanitation, kitchen, fire safety; registration with MoHR required

### 2.8 MACC Act 2009 s.17A
- **Applies to:** All commercial organisations; corporate liability for corrupt acts by associated persons
- **HR relevance:** Recruitment fees to agents, manpower supplier payments, headhunter arrangements, EP facilitation payments

### 2.9 PDPA 2010 (Amdt 2024)
- **DPO:** Appointment mandatory for organisations meeting threshold (verify current threshold)
- **Breach notification:** 72-hour notification to PDPC effective **1 Jun 2025**
- **HR relevance:** Employee personal data (payslips, IC, medical records, biometric), data retention, consent for use

---

## 3. Audit Lifecycle

### Phase 1 — Engagement Setup
1. Confirm entity scope → apply entity profile from `references/hr-entities.md`
2. Determine audit period (typically 12 months)
3. Issue PBC request → see `references/hr-pbc-template.md`
4. Refresh Law Register: confirm effective dates for minimum wage order, EPF/SOCSO/EIS/PCB rates, Act 446 cap, EP thresholds
5. Identify headcount by category: local, foreign (VP(TE)), EP holders, contract/outsourced

### Phase 2 — Walkthrough & Risk Assessment
1. Obtain HR process narratives: hire-to-retire, payroll run, statutory remittance, termination
2. Map controls to risks (see Section 4 RCM)
3. Perform fraud risk assessment (see Section 6)
4. Apply entity-specific risk overlays from `references/hr-entities.md`

### Phase 3 — Test of Control Design (ToD)
Assess whether each control is designed to prevent/detect the identified risk. Document design gaps as Control Deficiencies (CD).

### Phase 4 — Test of Operating Effectiveness (ToE)
- Sample sizes: IIA/PCAOB-aligned (25 for high-frequency; 15 for monthly; 5–10 for quarterly)
- Perform reperformance tests for EPF/SOCSO/EIS/PCB (see Section 5)
- Reconcile T&A to payroll OT
- Execute bank file three-way reconciliation

### Phase 5 — Findings & Reporting
- Draft findings using **5C structure**: Condition | Criteria | Cause | Consequence | Corrective Action
- Rate: Critical / High / Medium / Low
- Quantify exposure where possible (e.g., underpayment RM amount, penalty exposure)
- CAE quality gate before issuance

---

## 4. Risk-Control Matrix (Summary)

→ Full RCM in `references/hr-rcm.md`

| Risk | Control | Test Procedure | Red Flag |
|------|---------|----------------|----------|
| Minimum wage breach | Wage floor check on hire/increment | Compare basic pay vs MWO; list exceptions | Basic below [MY-003] |
| Ghost employee | 3-way reconcile HR master/payroll/bank | Match headcount; check bank account uniqueness | Duplicate IC/bank; no T&A record |
| OT manipulation | T&A to payroll OT reconciliation | Spot-test 4 weeks; check 45h cap | OT > 20% of basic; spikes |
| EPF under-declaration | Payroll system config; reperformance | Recalculate sample; compare to EPF submission | Allowances excluded from EPF base |
| SOCSO/EIS ceiling error | System rate table | Verify the register ceiling [MY-007] is applied from its effective date | Superseded ceiling still in system |
| PCB shortfall | LHDN table version control | Recompute sample vs current PCB schedule | Manual overrides; wrong table year |
| Foreign worker undocumented | Permit register vs physical audit | Match all FW to IMI records; check expiry | Expired VDR/VP(TE); sector mismatch |
| Act 446 rent over-deduction | Payslip deduction review | Compare deduction to gazetted cap; check consent | Deduction > cap; no written consent |
| EP salary inconsistency | HR-payroll-ESD triangulation | Compare contract/payslip/ESD form | Contract ≠ payslip; EP category mismatch |
| Termination irregularity | Domestic inquiry records | Review termination files; notice/PILON check | No inquiry minutes; forced resignation markers |
| MACC s.17A — agent payments | Vendor master; payment approvals | Review manpower supplier contracts and payments | No due diligence; cash payments; no contract |

---

## 5. Statutory Reperformance Tests

### EPF Reperformance (per employee sample)
```
EPF Wages = Basic Pay + Commissions + OT + Bonuses (subject to EPF)
           [Exclude: travelling allowance, goods/service reimbursements, gifts]
Employee EPF = EPF Wages × employee rate per [MY-004]
Employer EPF = EPF Wages × employer rate for the wage band [MY-005]
Compare to: payroll deduction + EPF portal submission
```

### SOCSO/EIS Reperformance
```
If wages are within the insurable ceiling [MY-007]: use PERKESO contribution table for exact band
If wages exceed the insurable ceiling [MY-007]: apply contribution at the ceiling band
EIS: employer and employee rate [MY-009] of insurable wages (up to the ceiling)
Compare to: payslip deduction + PERKESO i-Akaun submission
```

### PCB Reperformance
```
Use current LHDN PCB table for the tax year
Input: annual gross remuneration (basic + allowances subject to tax), relief eligibility
Compute monthly PCB; compare to payslip deduction
Flag: manual override amounts, zero-PCB for taxable employees
```

---

## 6. Fraud Risk Assessment

→ Full fraud schemes and indicators in `references/hr-fraud-schemes.md`

**High-priority fraud risks by entity:**

**MKPC:** Ghost foreign workers (permit exists, worker absent); levy back-charging to workers; OT inflation for production supervisors; duplicate IC numbers across foreign worker pool

**Nephrocare:** Ghost clinical staff on PERKESO panel billing; contract clinician misclassified as employee to avoid EPF; nurse overtime inflated during night shifts; payroll for resigned staff not terminated in system

**Erawan:** Act 446 rent deduction above gazetted cap (disguised as "utilities"); levy costs charged back to workers; factory OT unrecorded (pre-/post-shift); foreign worker permit mismatch (sector/employer)

**Group/HQ:** EP salary inflation in ESD application vs actual payslip; manpower agent payments without MACC s.17A due diligence; dual payroll for EP holders (local + shadow)

**Benford's Law application:** Apply to payroll amounts (1st digit test), OT hours, deduction amounts, and bank transfer values. Run it via `gia-fraud:gia-fraud-analytics` (MAD primary with per-digit z-scores); a deviation is an indicator for follow-up only.

---

## 7. Key Audit Tests Checklist

### Employment & Contracts
- [ ] Written contracts for all employees; EA-aligned clauses; multilingual alignment where applicable
- [ ] Probation terms, notice periods, OT provisions stated

### Wages & Time
- [ ] Basic pay at or above the national minimum wage [MY-003] for all employees (verify the order's effective date by employer size)
- [ ] OT paid at correct multipliers (1.5×/2×/3×)
- [ ] Weekly hours ≤ 45h average; daily OT authorised
- [ ] T&A records (biometric preferred) reconciled to payroll OT

### Statutory Deductions
- [ ] EPF: correct rates applied; correct wage base; remitted by 15th
- [ ] SOCSO/EIS: register ceiling [MY-007] applied from its effective date; remitted by the due date [MY-010]
- [ ] PCB: current LHDN table; no unauthorised manual overrides
- [ ] Payslips transparent; deductions itemised

### Foreign Workers
- [ ] All VP(TE) matched to IMI records; no expired passes
- [ ] Levy paid by employer; not deducted from worker wages
- [ ] Act 446: accommodation registered; space/sanitation standards met; rent deduction ≤ gazetted cap with written consent

### Expatriates
- [ ] EP category matches role and salary
- [ ] Contract salary = payslip salary = ESD submission (for applications/renewals from 1 Jun 2026: meets new thresholds)
- [ ] No post-approval salary downgrade

### Payroll Integrity
- [ ] 3-way reconcile: HR master ↔ payroll register ↔ bank credit file
- [ ] Bank account uniqueness check (no duplicate accounts across headcount)
- [ ] No off-cycle payments without CFO/CAE approval
- [ ] Maker-checker SoD for HR master changes and payroll approval

### Termination
- [ ] Notice or PILON per EA; domestic inquiry records present
- [ ] No pattern of forced resignations; settlement documentation
- [ ] Leaver access revoked; system terminated on last working day

### Governance
- [ ] HR handbook updated post-1 Jan 2023 EA amendments
- [ ] PDPA: DPO appointed (if threshold met); 72h breach notification procedure in place (eff. 1 Jun 2025)
- [ ] MACC s.17A: manpower agents on approved vendor list; due diligence on file

---

## 8. Finding Draft Template (5C)

```
FINDING: [Short title]
RATING: [Critical / High / Medium / Low]
ENTITY: [MKPC / Nephrocare / Erawan / Group]

CONDITION:
[What was found — specific, evidence-based, quantified where possible]

CRITERIA:
[The law, regulation, policy, or standard breached — cite Law ID and effective date]

CAUSE:
[Root cause: system configuration / policy gap / control absence / management override / awareness]

CONSEQUENCE:
[Financial exposure | Regulatory penalty | Reputational risk | Operational impact]
Quantified exposure: RM _____ / penalty range: _____

CORRECTIVE ACTION:
[Specific, measurable, time-bound action; assign owner]
Target completion: [date]
```

---

## Reference Files

| File | Contents | When to read |
|------|----------|--------------|
| `references/hr-entities.md` | Full entity profiles: MKPC, Nephrocare, Erawan, Group | Start of every engagement |
| `references/hr-rcm.md` | Full Risk-Control Matrix (30+ risks) | Walkthrough and ToD phases |
| `references/hr-fraud-schemes.md` | Detailed fraud schemes, indicators, Benford tests | Fraud risk assessment phase |
| `references/hr-pbc-template.md` | PBC request list for HR/payroll audit | Engagement setup |
| `references/hr-law-register.md` | Full Law Register with effective dates | Law scoping and ToE |
