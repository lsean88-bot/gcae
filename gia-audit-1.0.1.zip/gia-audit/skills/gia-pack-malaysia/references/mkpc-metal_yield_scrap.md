> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.

# Metal Yield, MTC & Scrap Reconciliation Reference — MKPC Die Casting & Stamping

## Die Casting — Material Turnover Coefficient (MTC)

### Why MTC is the Critical Audit Metric
In die casting, raw metal input is always greater than good casting output due to:
1. **Runners & gates** — metal in the gating system that fills the die (always scrap; recycled)
2. **Overflow biscuit** — excess metal at injection point (always scrap; recycled)
3. **Dross/slag** — oxidised surface layer on molten metal (external scrap — sold to processor)
4. **Rejected/scrapped castings** — quality failures (may be recycled or externally sold)
5. **Melt loss** — metal oxidised in furnace (3–5% of melt; not recoverable)

**MTC = Good Casting Weight (kg) ÷ Total Metal Input (kg) × 100%**

| Alloy / Process | MTC Benchmark | Notes |
|----------------|--------------|-------|
| Aluminium HPDC — A380, ADC12 (standard structural) | 65–75% | Runners ~25–30% of shot weight |
| Aluminium HPDC — vacuum die casting | 68–78% | Less turbulence; slightly better yield |
| Zinc HPDC (Zamak) | 70–80% | Higher MTC due to cold chamber efficiency |
| Cold chamber Al — large structural parts | 60–70% | Larger gating system for complex parts |
| Gravity die casting (GDC) | 75–85% | Slower pour; lower turbulence; better MTC |
| Steel stamping — blanking/forming | 70–85% | Depends on blank nesting efficiency |
| Steel stamping — progressive die | 60–75% | Skeleton scrap = significant portion |

**Below-benchmark MTC = 🔴 finding** — quantify as:
```
Exposure (MYR) = (Benchmark MTC% − Actual MTC%) × Total metal input (kg) × Metal price/kg (LME)
```

### Scrap Category Classification

| Category | Control | Accounting | Audit Approach |
|---------|--------|-----------|----------------|
| **Clean runners/gates (internal recycle)** | Returned to furnace; weighed | No cost — included in melt | `[INS]` remelt weight vs. scrap register; `[PHY]` observe at furnace |
| **Overflow/biscuit (internal recycle)** | Returned to furnace | No cost | Same as above |
| **Dross (Al oxide)** | Sold to licensed dross processor | Revenue (other income) | `[INS]` dross weight ticket + invoice; `[CON]` processor receipt |
| **Rejected castings — reworkable** | Rework; re-inspect | WIP cost | `[INS]` rework order; `[INS]` re-inspection pass |
| **Rejected castings — condemned** | Sent to scrap dealer | Write-off + scrap revenue | `[INS]` condemnation authorization; weigh-gate |
| **Stamping skeleton/offcuts** | Sold to scrap dealer | Revenue | `[INS]` weigh-gate; `[INS]` scrap invoice |

### Weigh-Gate Controls (Critical)
- Every scrap dispatch must have a **signed, timestamped weigh-gate record** by an independent weighmaster
- Weigh-gate records must not be accessible for editing by production or warehouse personnel
- Scrap dealer's weighbridge ticket must be retained and reconciled to weigh-gate record
- Tolerance: ±0.5% between MKPC weigh-gate and dealer weighbridge (flag >0.5% discrepancy)

### Fraud Risk: Metal Diversion
**Scheme:** Weigh-gate operator colludes with scrap dealer to record lower weight for MKPC than actual → excess metal exits premises without being invoiced → cash kickback to weigh-gate operator.

**Detection:**
1. `[ANA]` Compare MKPC weigh-gate weight vs. scrap dealer invoice weight — any systematic shortfall
2. `[PHY]` Surprise count of metal inventory vs. ERP closing stock — unaccounted metal = diversion
3. `[ANA]` Benford's Law on all weigh-gate records — round numbers or recurring patterns signal manipulation
4. `[OBS]` CCTV footage at weigh-gate (if available) — verify vehicles only weighed once

## Stamping Steel Yield Calculation

```
Theoretical yield = (Part weight × good quantity) ÷ Coil input weight × 100%

Nesting efficiency (from OEM-approved nesting plan): typically 70–85%
If actual yield < (nesting efficiency − 2%): investigate
```

**Offcut/skeleton scrap:**
- Progressive die: skeleton is continuous strip → weigh per run → reconcile to weigh-gate
- Blanking die: individual blanks punched from sheet → offcuts weighed in bulk

**Steel scrap benchmark price (Malaysia):** MYR 700–950/tonne for HMS 1&2 (verify MITI published price)
**Aluminium scrap (clean die cast):** MYR 3,500–5,000/tonne depending on grade and contamination (verify LME spot + Malaysia premium)

## Alloy Chemistry & CoA Verification

For aluminium HPDC (ADC12, A380, A356):
- Incoming ingot must have CoA with spectrometric results confirming alloy chemistry per JIS/ASTM standard
- Verify: Si (8–12% for ADC12), Cu (<3.5%), Fe (<1.3%), Mg (<0.3%), Zn (<1.0%)
- Out-of-spec ingot used in production = risk of casting defects + OEM claim/warranty → quantify as DPPM × warranty cost per unit

**Audit test:** `[INS]` last 12 months' incoming CoAs; `[INS]` in-house spectrometer records; flag any out-of-spec lots used in production.

## LME & Published Price Sources for Valuation

| Metal | Source | Frequency | Use |
|------|-------|---------|-----|
| LME Aluminium (primary) | `lme.com` | Daily | Al ingot purchase benchmark |
| LME Zinc | `lme.com` | Daily | Zn ingot purchase benchmark |
| Malaysia HRC (steel) | MITI published price; local steel distributor published price | Monthly | Stamping coil benchmark |
| Malaysia Al scrap | Published by licensed scrap dealers; MITI | Weekly | Scrap sale benchmark |
| Malaysia Zn scrap | Same | Weekly | Scrap sale benchmark |
