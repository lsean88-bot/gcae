> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- Step 0 — Evidence Standard (Non-Negotiable — Read First)
- Step 1 — Establish Erawan Company Context
- Step 2 — Web-Validate Current Regulations Before Writing
- Step 3 — Document Scan (If Files Provided)
- Step 4 — Execute Audit Tests Across All Fifteen Domains
- Step 5 — Report structure
- Step 6 — Optional: Excel Audit Workbook Output
- Validation Standards — Non-Negotiable


# /my-erawan-lmw-audit — Erawan Malaysia Gas Cylinder Manufacturing (LMW) Internal Audit

Conduct a rigorous internal audit of Erawan's gas cylinder manufacturing operations under
Malaysia's LMW regime, validated against current Malaysian law, RMCD regulations, DOSH/DOE
safety requirements, MFRS/MPERS financial reporting standards, and sector-specific
Petronas/industrial gas customer requirements. Output follows **2024 IIA Global Internal
Audit Standards (GIAS)** effective January 9, 2025. **All findings must be grounded in
sufficient appropriate audit evidence — zero assumptions, zero unverified claims, zero fuzzy logic.**

Finding structure: **Condition → Criteria → Cause → Effect → Recommendation**
Each finding must additionally state: **Evidence Basis** and **Assertion(s) Tested**

---

## Step 0 — Evidence Standard (Non-Negotiable — Read First)

Seven evidence types — tag every test:

| Tag | Type | Reliability Note |
|-----|------|-----------------|
| `[INS]` | Documentary inspection | Original > certified copy > management-supplied copy |
| `[PHY]` | Physical observation/count | `[PHY]` count + `[INS]` system = strongest inventory evidence |
| `[CON]` | External confirmation | Bank, RMCD portal, LHDN MyTax, SSM, DOSH portal — independently obtained |
| `[REP]` | Management representation | Lowest reliability; never standalone for 🔴 findings |
| `[REC]` | Recalculation | Auditor recomputes using primary data |
| `[OBS]` | Observation of process | Timing risk — may not represent normal operations |
| `[ANA]` | Analytical procedure | Benford, ratio analysis, trend, population data |

Nine assertion codes: `EX` (existence) · `CO` (completeness) · `AC` (accuracy) · `VA` (valuation)
`CU` (cut-off) · `RO` (rights & obligations) · `CL` (classification) · `PR` (presentation) · `CP` (compliance)

**Operational rules:**
1. `[INQ]` alone is never sufficient — always corroborate
2. Every 🔴 Critical finding requires at least one `[CON]` or `[PHY]` item
3. All monetary findings quantified in **MYR** (or kg / units for physical findings)
4. Full-population testing preferred over sampling where ERP/system data available
5. "Cannot be verified" is a valid finding — state what was requested, what was unavailable, and the risk

---

## Step 1 — Establish Erawan Company Context

Collect or confirm before auditing (single concise question to management):

| Field | Why It Matters |
|-------|---------------|
| **Cylinder types manufactured** | Steel vs. composite; LPG, oxygen, acetylene, nitrogen, CO₂ — determines DOSH standard applicable |
| **LMW license number & expiry** | Core compliance; renewal must be submitted ≥1 month before expiry |
| **Export ratio last 12 months** | Must be ≥80% of finished goods value; triggers MIDA approval if <80% |
| **Local sales %** | Within the ratio in [MY-022] without MIDA approval; above it requires MIDA special approval + duty/SST payment |
| **Key customers** | Petronas (PLMS-licensed), other O&G companies, industrial gas distributors — drives billing audit depth |
| **Customer contract type** | Outright sale vs. cylinder rental vs. deposit scheme — critical for revenue recognition (MFRS 15) |
| **DOSH hydrostatic test status** | All cylinders: 5-year cycle mandatory; overdue = critical finding |
| **SIRIM certification** | MS/EN/ISO cylinder standards; certification must be current |
| **DOE EQA scheduled waste** | Manufacturing produces scheduled waste (paint, rust inhibitor, testing media) |
| **ERP/accounting system** | SAP, Sage, SQL, custom — determines data extraction approach |
| **Financial reporting framework** | MFRS (if subsidiary of listed/public entity) or MPERS (if private entity) |
| **Foreign parent?** | Triggers TP rules (ITA s.140A), thin cap, group recharge |
| **Related-party transactions** | Sales to related entities at non-arm's-length = TP risk |
| **Documents available?** | If none: FRAMEWORK ONLY label — no line-item findings |

---

## Step 2 — Web-Validate Current Regulations Before Writing

Validation is `[CON]` — obtained from official portals:

| Regulation | Source to Verify |
|-----------|-----------------|
| LMW conditions & M-forms | `customs.gov.my` — RMCD LMW portal |
| SST rates & exemptions | `mysst.customs.gov.my` |
| e-Invoice phase & MyInvois | `myinvois.hasil.gov.my` + LHDN website |
| Income tax rates & TP rules | `hasil.gov.my` |
| DOSH gas cylinder guidelines | `dosh.gov.my` |
| SIRIM standards (MS standards) | `sirim.my` |
| DOE EQA scheduled waste list | `doe.gov.my` |
| EPF contribution rates | `kwsp.gov.my` |
| SOCSO/EIS rates | `perkeso.gov.my` |
| Minimum Wages Order 2024 | `mohr.gov.my` or `jtksm.gov.my` |
| PETRONAS PLMS vendor status | `plms.petronas.com` |
| SSM company status | `mydata.ssm.com.my` |
| BOMBA fire certificate | state BOMBA authority |

---

## Step 3 — Document Scan (If Files Provided)

Read the retired `document_scan_guide` module (not a separate file in this suite). Key document types for Erawan LMW:

| Document | Evidence Tag | Priority |
|----------|------------|---------|
| LMW license + all 26 Appendix C conditions | `[INS]` | 🔴 |
| Monthly M1/M2/M4 returns (all periods under review) | `[INS]`; cross-validate `[CON]` against RMCD portal | 🔴 |
| DOSH hydrostatic test records per cylinder serial | `[INS]`; `[PHY]` cylinder marking spot-check | 🔴 |
| SIRIM type approval certificates | `[INS]` | 🔴 |
| Customer sales invoices — Petronas & other O&G | `[INS]` | 🟠 |
| Delivery orders (DO) / cylinder movement records | `[INS]` + `[PHY]` physical count at gate | 🟠 |
| Cylinder deposit ledger vs. customer statements | `[CON]` confirmation with customers | 🟠 |
| Bank statements all accounts | `[CON]` bank confirmation preferred; `[INS]` if not available | 🟠 |
| EPF/SOCSO/EIS contribution statements | `[CON]` portal extract from KWSP/PERKESO | 🟠 |
| SST-02 returns filed with RMCD | `[INS]`; cross-validate against `[CON]` RMCD MySST portal | 🟠 |
| e-Invoice MyInvois validated records (if Phase 3 applicable) | `[CON]` MyInvois portal | 🟠 |
| BOM (Bill of Materials) per cylinder type | `[INS]` | 🟡 |
| Production records — fill volume, test records | `[INS]`; `[OBS]` production floor | 🟡 |
| DOE scheduled waste manifest (Borang SW) | `[INS]` | 🟡 |
| BOMBA fire certificate | `[INS]` | 🟡 |

If no documents: label **"FRAMEWORK ONLY — No Documents Reviewed — No Line-Item Findings"**

---

## Step 4 — Execute Audit Tests Across All Fifteen Domains

For every test: state assertion → obtain evidence from highest-reliability source → quantify → write condition.

---

### Domain 1 — LMW Customs Compliance (RMCD)
Read: `references/lmw-lmw_customs.md`

**Legal basis:** Customs Act 1967 s.65/65A; LMW Appendix C (26 conditions)

| Test | Evidence | Assertion |
|------|---------|-----------|
| LMW license validity & conditions (all 26 Appendix C) | `[INS]` license + `[CON]` RMCD portal confirmation | CP, EX |
| Export ratio ≥80% last 12 months | `[REC]` export value ÷ total production from M2 + customs K2 forms | AC, CP |
| Local sales within the [MY-022] ratio (or MIDA approval obtained above it) | `[REC]` local sales value ÷ total manufacturing output; `[INS]` MIDA approval letter if above the [MY-022] ratio | AC, CP |
| Duty/SST paid on local sales — correct rate applied | `[REC]` recalculate duty + SST on local sales; `[INS]` payment receipts | AC, CP |
| M1/M2/M4 monthly returns — timely submission & accuracy | `[INS]` all returns + `[REC]` reconcile raw material usage per M1 against production records | CO, AC, CP |
| Raw material import duty-free vs. approved tariff codes | `[INS]` import K1 forms vs. RMCD approved list for LMW | CP, CL |
| Bond/bank guarantee — adequacy & currency | `[INS]` current bank guarantee letter vs. RMCD requirement | CP |
| LMW renewal — submitted ≥1 month before expiry | `[INS]` renewal application date vs. license expiry date | CP |
| Subcontract activities — approved by RMCD | `[INS]` RMCD subcontract approval + subcontractor's LMW/FIZ status | CP, RO |
| Local sales duty/tax — correct K9 form filed | `[INS]` K9 forms for all local sales transactions | CP, CO |

**Key fraud risk:** Understating local sales to avoid duty/SST; diverting duty-free materials to unauthorized use.

---

### Domain 2 — SST Compliance (Sales Tax Act 2018 / Service Tax Act 2018)
Read: `references/mkpc-sst_compliance.md`

**Rates as of 2025:** Sales Tax per [MY-017]; Service Tax per [MY-018]
**e-Invoice:** MyInvois Phase 3 — turnover band per [MY-020], effective 1 July 2025; deductibility conditioned on validated e-invoice (Finance Act 2024)

| Test | Evidence | Assertion |
|------|---------|-----------|
| SST registration status & threshold compliance | `[CON]` MySST portal registration certificate | CP, EX |
| SST-02 returns — all taxable periods filed & paid | `[INS]` SST-02 + `[CON]` MySST portal filing history | CO, CP |
| Correct SST rate applied on local cylinder sales | `[REC]` re-classify each cylinder type → verify tariff code → confirm the rate per [MY-017] | AC, CL, CP |
| Manufacturing exemption schedule B/C — eligibility validated | `[INS]` exemption certificates; `[REC]` verify eligible items match approved list | CP |
| LMW exemption — raw materials (duty-free inputs) not double-claimed for SST refund | `[ANA]` cross-check LMW M1 imports against SST purchase claims | CP, AC |
| e-Invoice compliance — MyInvois validated invoices for all taxable supplies | `[CON]` MyInvois portal; verify QR/UUID on sample invoices | CP, CO |
| e-Invoice — expense deductibility: all purchase invoices ≥RM threshold have validated e-invoice | `[CON]` MyInvois portal; `[INS]` supplier e-invoices for top 20 by value | AC, CP |
| Service tax on imported taxable services (reverse charge) | `[INS]` invoices from foreign service providers; `[REC]` service tax self-account | CP, AC |

---

### Domain 3 — Income Tax & Transfer Pricing
Read: the retired `income_tax_tp` module (not a separate file in this suite)

**Legal basis:** Income Tax Act 1967; TP Rules 2012; LHDN TP Guidelines 2024

| Test | Evidence | Assertion |
|------|---------|-----------|
| Corporate tax filing (CP204 estimation + CP204A revision + annual return) | `[CON]` LHDN MyTax portal; `[INS]` CP204 acknowledgements | CO, CP |
| Reinvestment Allowance (RA) — eligibility & quantum | `[INS]` qualifying plant/machinery capex invoices + LHDN approval | VA, CP |
| Pioneer Status / ITA — compliance with conditions | `[INS]` MIDA approval letter + conditions checklist | CP |
| Transfer pricing — related-party sales/purchases at arm's length | `[INS]` TP documentation; `[REC]` benchmarking vs. published comparables | AC, CP |
| Thin capitalisation — related-party debt ÷ equity ratio (ITA s.140C) | `[REC]` calculate ratio from audited FS + loan agreements `[INS]` | AC, CP |
| PCB/MTD — correct deduction & timely remittance (CP39) | `[CON]` LHDN portal; `[REC]` recalculate PCB for sample of 10 employees | AC, CP |
| Withholding tax on foreign payments (ITA s.109) | `[INS]` foreign vendor invoices; `[REC]` verify WHT applied at correct rate | AC, CP |

---

### Domain 4 — DOSH Safety & Gas Cylinder Regulatory Compliance
Read: `references/lmw-dosh_gas_cylinder.md`

**Legal basis:** Occupational Safety & Health Act 1994 (OSH Act, Act 514) as amended by Act A1648 (2022);
Factories & Machinery (Repeal) Act 2022 (Act 835, effective 2024); Petroleum (Safety Measures) Act 1984 (Act 302);
DOSH Guidelines for Industrial Gas Cylinder 2021; DOSH Guideline GPC Domestik 2023

| Test | Evidence | Assertion |
|------|---------|-----------|
| DOSH registration of all pressure vessels/cylinders | `[CON]` DOSH eSIHA portal; `[INS]` DOSH registration certificates per vessel | EX, CP |
| Hydrostatic testing — 5-year cycle compliance (100% population) | `[INS]` test records with authorized tester stamp; `[PHY]` cylinder markings vs. test register | CO, CP |
| DOSH-authorized competent person (Inspector of Machinery) on-site | `[INS]` appointment letter + DOSH appointment confirmation | CP |
| OSH Coordinator appointment (≥5 employees — OSH Amendment 2022) | `[INS]` appointment letter; `[CON]` DOSH portal if registered | CP |
| CHRA (Chemical Health Risk Assessment) — current for all chemicals used | `[INS]` CHRA report (≤5 years old); `[OBS]` chemicals in use vs. CHRA scope | CP |
| Manufacturing SOP compliance — fill pressure, valve torque, purity checks | `[OBS]` production floor; `[INS]` SOP documents; `[INS]` QC records | CP, AC |
| SIRIM/MS standard compliance for cylinder design & materials | `[INS]` SIRIM type approval certificate; `[INS]` material test certificates (MTCs) | CP, AC |
| Cylinder rejection & quarantine — defective cylinder control | `[PHY]` quarantine area observation; `[INS]` rejection register | EX, CP |
| Emergency response plan (ERP) — current & exercised | `[INS]` ERP document + last drill record | CP |
| Accident/near-miss reporting to DOSH (OSH Act s.32) | `[INS]` DOSH Form 7 (if any incident); `[CON]` DOSH notification records | CO, CP |

**Key fraud/safety risk:** Falsified hydrostatic test records (cylinder diversion — selling untested cylinders at discount).

---

### Domain 5 — Environmental Compliance (DOE / EQA)
Read: the retired `doe_eqa` module (not a separate file in this suite)

**Legal basis:** Environmental Quality Act 1974 (EQA, Act 127) as amended; EQA (Scheduled Wastes) Regulations 2005; DOE licensing

| Test | Evidence | Assertion |
|------|---------|-----------|
| DOE scheduled waste — classification, storage & disposal | `[INS]` Scheduled Waste inventory list; `[PHY]` storage area inspection; `[INS]` Borang SW (consignment notes) | EX, CP |
| Licensed scheduled waste contractor — current license | `[CON]` DOE eKastam portal; `[INS]` contractor license | RO, CP |
| DOE effluent discharge — license compliance (trade effluent) | `[INS]` DOE license; `[INS]` effluent monitoring reports | CP |
| ISO 14001 environmental management system (if certified) | `[INS]` current ISO 14001 certificate | CP |
| BOMBA fire safety certificate — current | `[INS]` fire certificate from state BOMBA; `[OBS]` fire suppression systems | CP |

---

### Domain 6 — Financial Reporting (MFRS/MPERS)
Read: `references/clinic-D_financial_reporting.md`

**Framework:** MFRS (if subsidiary of listed/public entity) or MPERS (private entity, Companies Act 2016). MPERS (2025) applies from 1 Jan 2027; currently MPERS (2016). If MK Tron Group is subject to MFRS, Erawan as subsidiary must use MFRS.

#### 6A — Revenue Recognition (MFRS 15 / MPERS Section 23)

| Test | Evidence | Assertion |
|------|---------|-----------|
| Outright cylinder sales — revenue recognized at point of control transfer | `[INS]` DO signed by customer + `[INS]` invoice; verify DO date = revenue recognition date | CU, AC |
| Cylinder rental income — recognized over rental period | `[INS]` rental agreements; `[REC]` recalculate monthly accrual vs. posted revenue | AC, CU |
| **Cylinder deposit — classified as liability NOT revenue** (MFRS 15 / MPERS s.23.28) | `[INS]` deposit receipts; `[INS]` GL ledger classification; deposit refundable = financial liability | CL, AC |
| Gas fill charges — revenue recognized on delivery/fill | `[INS]` fill records + DO | CU |
| Retest/re-certification charges — revenue timing | `[INS]` test certificates + invoices | CU |

#### 6B — Inventory & COGS (MFRS 102 / MPERS Section 13, equivalent to IAS 2)

| Test | Evidence | Assertion |
|------|---------|-----------|
| Inventory valuation — lower of cost or NRV | `[INS]` last purchase invoices; `[REC]` NRV calculation for slow-moving items | VA, AC |
| BOM costing — steel tube, valve, paint, gas fill — reconcile to standard cost | `[INS]` approved BOM; `[REC]` compare standard to actual cost per cylinder type | AC, VA |
| **Cylinder deposit asset — accounted as refundable deposit (financial asset) if paid to supplier; financial liability if received from customer** | `[INS]` deposit agreements; `[INS]` GL classification | CL, AC |
| COGS completeness — all manufacturing costs captured | `[INS]` production cost records; `[REC]` absorption rate | CO, AC |
| Scrap/waste valuation — net realizable value for cylinder offcuts & rejects | `[ANA]` scrap weight × market price vs. carrying value | VA |
| Cylinder inventory — reconcile physical count to ERP | `[PHY]` count at yard vs. `[INS]` ERP stock register | EX, AC |

#### 6C — PPE & Capex (MFRS 116 / MPERS Section 17)

| Test | Evidence | Assertion |
|------|---------|-----------|
| Capitalization policy — filling equipment, testing rigs, cylinder tooling | `[INS]` capex invoices vs. expense postings; `[OBS]` asset register | AC, CL |
| Depreciation method & useful life — appropriate for gas cylinder manufacturing equipment | `[INS]` accounting policy note; `[REC]` recalculate depreciation for sample | AC |
| Impairment review (MFRS 136 / MPERS s.27) — old tooling, idle equipment | `[ANA]` utilisation data; `[INS]` management assessment | VA |

#### 6D — Leases (MFRS 16 / MPERS Section 20)

| Test | Evidence | Assertion |
|------|---------|-----------|
| MFRS 16 ROU asset & lease liability recognized for factory/land leases ≥12 months | `[INS]` lease agreements; `[REP]` management policy; `[REC]` PV of lease payments | VA, CL |
| Short-term / low-value lease exemptions applied appropriately | `[INS]` lease register | CL |

---

### Domain 7 — Petronas & Industrial Gas Customer Billing / Collection
Read: `references/lmw-gas_customer_billing.md`

**Context:** Petronas vendors must be PLMS-licensed. Sales to Petronas subsidiaries (PGB, PCSB, PETRONAS Dagangan) are typically on purchase order / SAP workflow. Billing terms vary by contract — DO-based, monthly consolidated, or delivery milestone.

| Test | Evidence | Assertion |
|------|---------|-----------|
| PETRONAS PLMS vendor license — current & scope matches products supplied | `[CON]` PLMS portal (`plms.petronas.com`) for Erawan's vendor status | CP, EX |
| Sales invoice vs. customer PO/contract — 3-way match (PO + DO + Invoice) | `[INS]` sample 25 highest-value invoices: PO, DO, invoice; verify qty, price, terms | AC, CP |
| DO reconciliation — all deliveries invoiced within billing cycle | `[ANA]` DOs issued vs. invoices raised (population); flag unbilled DOs | CO, CU |
| **Cylinder deposit — charged correctly & reconciled per customer account** | `[INS]` deposit schedule in contracts; `[CON]` customer deposit confirmations; `[REC]` deposit received vs. ledger | AC, EX |
| **Cylinder rental — daily/monthly rate correct; no free-issue without authorization** | `[INS]` rental agreements; `[ANA]` rental days × rate vs. billed amount | AC |
| Retest charges — billed when cylinder reaches 5-year hydrostatic test milestone | `[INS]` test register vs. retest invoice register; flag overdue unbilled retests | CO, CU |
| Collection aging — Petronas 30/60/90 day payment terms; flag overdue | `[INS]` AR aging report as at audit date; `[CON]` customer statement confirmations for top 10 | VA, CO |
| Cash receipts — posted to correct customer account; no unapplied receipts | `[ANA]` unapplied credits in AR sub-ledger | AC, EX |
| Credit note authorization — valid reason, MD/Finance approval | `[INS]` credit note register + authorization trail | CP |
| Revenue completeness — Benford on invoice amounts | `[ANA]` first-digit frequency of all invoices (population) | CO, AC |

**Key fraud risks:** Fictitious credit notes; diverting cash collections; billing at contract price but pocketing rebate; unauthorized cylinder free-issue to related parties.

---

### Domain 8 — Cash Payments & Disbursement Controls
Read: the retired `cash_controls` module (not a separate file in this suite)

| Test | Evidence | Assertion |
|------|---------|-----------|
| Petty cash — count vs. float; authorization limits | `[PHY]` surprise cash count; `[INS]` petty cash vouchers | EX, CP |
| Vendor payment — 4-eye approval; no single-authorizer payment | `[INS]` payment vouchers; `[OBS]` system access segregation | CP |
| **Cash payments to gas cylinder customers — deposit refunds; verify customer identity & bank account** | `[INS]` refund payment vouchers; `[CON]` bank IBFT confirmations | EX, AC |
| Benford on payment amounts — detection of round-sum or threshold payments | `[ANA]` full population of payment transactions | AC |
| Vendor master changes — authorization trail | `[INS]` vendor master change log vs. change request forms | CP |
| Related-party payments — arm's length; disclosed in financial statements | `[INS]` related-party transaction schedule; `[CON]` confirmation with related entities | AC, PR |
| MACC Act 2009 — gifts, entertainment, political contributions register | `[INS]` gifts & entertainment register; `[INS]` corporate social responsibility policy | CP |

---

### Domain 9 — Cylinder Inventory, COGS & Utilisation
Read: `references/lmw-cylinder_inventory_cogs.md`

This is the most operationally unique domain for gas cylinder manufacturing. Cylinders are simultaneously a manufactured product, a customer-facing returnable asset, and a cost driver.

| Test | Evidence | Assertion |
|------|---------|-----------|
| **Cylinder population reconciliation** — manufactured + opening = sold outright + on loan to customers + in yard + scrapped | `[PHY]` physical count (yard + production) + `[INS]` customer cylinder register + `[INS]` scrap register | EX, CO |
| **COGS per cylinder type** — steel + valve + paint + gas fill + labour + overhead absorption | `[INS]` BOM; `[REC]` actual cost vs. BOM standard; variance explanation | AC, VA |
| Cylinder utilisation rate = cylinders on loan ÷ total cylinder fleet × 100% | `[INS]` cylinder movement register; industry benchmark 70–85% | AC |
| **Cylinder on loan (COL) not in customer location — detect lost/diverted cylinders** | `[ANA]` cross-reference COL register vs. customer delivery records vs. returned cylinder log | EX |
| Fill rate = cylinders filled in period ÷ cylinder capacity (fills available) | `[INS]` production fill records | AC |
| **Gas fill quantity — meter-measured fill weight vs. invoiced fill weight** | `[INS]` fill manifold records; `[PHY]` weigh-check sample of filled cylinders at dispatch | AC |
| Scrap cylinder authorization — authorized write-off; condemned cylinders destroyed | `[INS]` scrap authorization; `[PHY]` observe destruction or DOSH-authorized disposal | EX, CP |
| FIFO or WAC inventory method — consistently applied | `[INS]` accounting policy; `[REC]` trace batch costing | CP, AC |
| Slow-moving & obsolete cylinder inventory — NRV assessment | `[INS]` aging report; `[ANA]` days in yard > 90 days without movement | VA |
| **Gas shrinkage/loss between fill and delivery** — acceptable industry loss vs. actual | `[REC]` fill weight vs. delivery weight; benchmark <0.5% loss for compressed gas | AC |

**Key fraud risks:** Cylinder diversion (selling LMW-manufactured cylinders in black market without invoicing); fake scrap write-offs; gas fill short-charging; deposit misappropriation.

---

### Domain 10 — Employment & Statutory Payroll Compliance
Read: `references/lmw-employment_payroll.md`

**Legal basis:** Employment Act 1955 (as amended by EA Amendment 2022, Act A1651, effective 1 Jan 2023);
EPF Act 1991; SOCSO Act 1969; EIS Act 2017; HRD Corp Act 2001; Minimum Wages Order 2024

**2024–2025 key rates:**
- **EPF:** employer rate [MY-005]; employee rate [MY-004]; foreign workers [MY-006]
- **SOCSO:** rates [MY-008]; insurable wage ceiling [MY-007]
- **EIS:** rate [MY-009]; insurable wage ceiling [MY-007]; coverage limited to citizens and permanent residents in the covered age band
- **PCB/MTD:** Due by 15th of following month via CP39
- **Minimum wage:** [MY-003] (take the current order and effective date by employer size from the register)
- **HRDF/HRD Corp:** levy per [MY-045]

| Test | Evidence | Assertion |
|------|---------|-----------|
| EPF — monthly contributions correct & paid by 15th | `[CON]` KWSP i-Akaun employer portal; `[REC]` recalculate for sample of 10 employees | AC, CP |
| SOCSO — contributions correct & timely; ceiling [MY-007] applied correctly (current ceiling, not the superseded one) | `[CON]` PERKESO portal; `[REC]` recalculate | AC, CP |
| EIS — contributions correct; only Malaysian/PR employees < 60 years | `[REC]` compare EIS deductees vs. employee nationality/age register | AC, CP |
| PCB/MTD — correct monthly deduction; CP39 submitted; no LHDN penalty | `[CON]` LHDN MyTax portal; `[INS]` CP39 payment receipts | AC, CP |
| HRD Corp — levy paid ([MY-045]); training claims submitted | `[CON]` HRD Corp portal; `[INS]` training levy payment receipts | CP |
| Minimum wage compliance — all employees at or above the national minimum wage [MY-003] | `[REC]` compare lowest payroll entries to gazette rate | AC, CP |
| **Ghost employee — bank account (CLABE equivalent = bank account number) shared by ≥2 employees** | `[ANA]` full-population bank account analysis from payroll data | EX |
| **4-way headcount reconciliation** — EPF register + SOCSO register + payroll + physical headcount/access card | `[CON]` EPF + SOCSO portals vs. `[INS]` payroll + `[OBS]` headcount | EX, CO |
| Foreign workers — PTPTN/JTK work permit (Employment Pass/Visa With Reference); notify JTK | `[CON]` JTK online worker registration; `[INS]` work permits | CP |
| EA 1955 compliance — overtime limits, rest days, paid leave accrual | `[INS]` payroll records; `[INS]` overtime claims vs. EA Section 60A limits | CP |
| EA Amendment 2022 — flexible working arrangement policy; domestic violence leave; sexual harassment policy | `[INS]` HR policies updated post-1-Jan-2023 | CP |

---

### Domain 11 — Anti-Bribery, Fraud & MACC Compliance
Read: the retired `abac_fraud` module (not a separate file in this suite)

**Legal basis:** Malaysian Anti-Corruption Commission Act 2009 (MACC Act); Corporate Liability provision (MACC Act s.17A, effective 1 Jun 2020) — company liable for corruption by associated persons unless adequate procedures proven; Companies Act 2016

**ACFE Fraud Tree — Key Erawan-specific risks:**

| Fraud Scheme | Red Flags | Test |
|-------------|----------|------|
| **Cylinder diversion** | Cylinder serial in COL register but no customer record; scrap write-off cylinders later seen in market | `[PHY]` cylinder count + `[ANA]` serial number gap analysis |
| **Deposit misappropriation** | Deposit collected per invoice but not in deposit ledger; refund without return of cylinder | `[ANA]` deposit collected vs. deposit ledger (population) |
| **Gas fill short-charging** | Invoiced fill weight > metered fill weight | `[INS]` fill records vs. invoice |
| **Ghost employee** | Payroll entry with no access card swipes | `[ANA]` access log vs. payroll |
| **Procurement kickback** | Sole-source procurement of steel tubes at above-market price | `[ANA]` unit price trend + `[CON]` market benchmark |
| **Fictitious credit note** | Credit note to Petronas without valid return/complaint | `[INS]` credit note file; `[CON]` Petronas confirmation |
| **LMW diversion** | Duty-free raw materials used for local production sold without paying duty | `[REC]` M1 material balance vs. local sales K9 |

| Test | Evidence | Assertion |
|------|---------|-----------|
| MACC s.17A "adequate procedures" — written anti-corruption policy, tone from top | `[INS]` ABAC policy + Board approval; `[OBS]` training records | CP |
| Gifts & entertainment — register maintained; approval required for >RM500 | `[INS]` G&E register (full year) | CP |
| Benford on cylinder deposit collections | `[ANA]` first-digit analysis of all deposit receipts (population) | CO, AC |
| Benford on credit notes | `[ANA]` first-digit analysis of all credit notes (population) | CO |
| Vendor due diligence — MACC & SSM check on key raw material suppliers | `[CON]` SSM company search; `[CON]` MACC sanction list | CP, RO |
| Related-party transactions — fully disclosed; arm's length documentation | `[INS]` TP documentation; `[INS]` board minutes approving RPT | PR, AC |

---

### Domain 12 — Governance & ERM / COSO
Read: the retired `governance_erm` module (not a separate file in this suite)

**Framework:** COSO Enterprise Risk Management 2017; IIA GIAS 2024 Standard 9 (Governance), Standard 10 (Risk)

| Test | Evidence | Assertion |
|------|---------|-----------|
| Board/AC oversight — minutes reviewed; audit findings tabled | `[INS]` board/AC minutes last 4 quarters | CP |
| Risk register — maintained; gas cylinder-specific risks (DOSH, LMW, price) included | `[INS]` risk register; `[REP]` management | CP |
| Internal controls — segregation of duties in billing, collection, payroll | `[OBS]` system access rights; `[INS]` user access matrix | CP |
| Whistleblower channel — functional; Whistleblower Protection Act 2010 compliance | `[INS]` whistleblower policy; `[OBS]` reporting channel | CP |
| Companies Act 2016 — statutory filings (annual return, audited FS) current | `[CON]` SSM MyData portal | CP |
| Directors' duties — no conflict of interest in customer/vendor selection | `[INS]` directors' declaration of interests | CP |

---

### Domain 13 — Benchmark & Comparative Analysis
Read: `references/lmw-benchmarks.md`

Gas cylinder manufacturing KPIs — compare Erawan actuals to industry norms:

| KPI | Formula | Industry Benchmark | Data Source |
|----|--------|--------------------|------------|
| Cylinder utilisation rate | Cylinders on loan ÷ total fleet | 70–85% | Industry practice |
| Fill rate | Cylinders filled ÷ available capacity | >85% | Operations |
| Retest compliance rate | Cylinders tested within 5-yr cycle ÷ total due | 100% | DOSH requirement |
| Gas shrinkage loss | (Fill weight − Delivery weight) ÷ Fill weight | <0.5% (compressed); <1% (LPG) | Industry CGA/IGAM |
| Debtor days (DSO) | AR × 365 ÷ Revenue | <45 days (Petronas 30-day terms) | Contract |
| LMW export ratio | Export value ÷ Total manufacturing output | ≥80% | RMCD requirement |
| Local sales ratio | Local sales ÷ Total output | ≤20% (or MIDA approval) | RMCD |
| COGS % of revenue | COGS ÷ Revenue | 55–70% (gas cylinder mfg) | Sector data |
| Scrap rate | Rejected cylinders ÷ Total produced | <2% | Manufacturing norm |
| Deposit turnover | Cylinder depositsreturned ÷ Deposits held | >60% p.a. | Contractual |

---

### Domain 14 — SSM & Corporate Governance Compliance

| Test | Evidence | Assertion |
|------|---------|-----------|
| Companies Act 2016 — annual return filed within 30 days of AGM | `[CON]` SSM MyData portal | CP |
| Audited financial statements lodged — within 6 months of FY-end | `[CON]` SSM portal | CP |
| Director/beneficial owner information — accurate & updated | `[CON]` SSM MyData vs. management representation | CP, EX |
| Companies Act 2016 s.221 — proper accounting records maintained | `[INS]` chart of accounts; `[OBS]` accounting system | CP |

---

### Domain 15 — Gas Supply Act / Petroleum Act Compliance

**Legal basis:** Gas Supply Act 1993 (Act 501); Petroleum (Safety Measures) Act 1984 (Act 302)

| Test | Evidence | Assertion |
|------|---------|-----------|
| Gas supply license (if distributing regulated gas) — current | `[CON]` ST (Suruhanjaya Tenaga) portal or DOE license | CP |
| Petroleum (Safety Measures) Act compliance — hazardous area classification | `[INS]` hazardous area classification drawings; `[CON]` DOSH/ST approval | CP |
| Gas cylinder labels — correct gas identification, pressure rating, tare weight stamped | `[PHY]` physical inspection sample of filled cylinders at dispatch | CP, AC |
| Transportation compliance — cylinders secured; Dangerous Goods by Road (ADNR-equivalent Malaysia) | `[OBS]` delivery vehicles; `[INS]` driver training records | CP |

---

## Step 5 — Report structure

Owned by `gia-report-qa:gia-ia-report` (standard concise report plus Excel working paper). This pack emits a findings register and its supporting tables only; the long-form overall-opinion layout in the retired source is a legacy conversion reference and is not used. Dashboards named in the retired layout (yield, labour compliance, OEM scorecard, benchmarks) are working-paper sheets.

## Step 6 — Optional: Excel Audit Workbook Output

When generating an Excel audit workbook for Erawan follow MK Tron GIA house style:
- **Colour palette:** Navy (#002060) headers, Teal (#00B0A8) sub-headers, Midblue (#0070C0) accent
- **Sheets:** Cover | Executive Summary | Priority Matrix | Findings (per Domain) | Cylinder Reconciliation | Deposit Ledger Audit | Payroll Reconciliation | LMW M-Form Tracker | Benchmark Dashboard | Evidence Index | SETTINGS (hidden)
- **Conditional formatting:** 🔴 Critical = red fill, 🟠 High = orange, 🟡 Medium = yellow, 🟢 Low = green
- **Formulas:** Auto-count findings by priority; auto-calculate exposure totals; fill rate, utilisation rate, DSO, export ratio
- **MK Tron GIA reference:** GIA-20[YY]-ERAWAN-[DOMAIN]-[NN]

---

## Validation Standards — Non-Negotiable

| Standard | Rule |
|----------|------|
| **Evidence first** | No finding stated before evidence obtained and documented |
| **Quantify always** | Every finding states exposure in MYR/kg/units — or explains why not possible |
| **Cite specifically** | Law + Act number + section + year; MFRS standard + paragraph; DOSH guideline title + year |
| **Tag evidence** | Every test tagged: `[INS]` `[PHY]` `[CON]` `[REP]` `[REC]` `[OBS]` `[ANA]` |
| **Challenge always** | Professional skepticism; corroborate all management explanations |
| **Assumption = disclosure** | Any assumed fact stated prominently in header |
| **No inference as finding** | "Appears to" / "likely" / "probably" prohibited in findings |
| **Regulatory calendar** | Always include next 3–5 filing deadlines specific to LMW/DOSH/LHDN/KWSP |
| **IIA 2024 alignment** | All recommendations reference specific IIA GIAS 2024 Standards |
| **Disclaimer** | Every report includes MIA/MICPA/legal counsel review disclaimer |
| **Benchmark** | Every operational domain includes comparison to Malaysian industry benchmark |
