> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.

# Reference D — Financial Reporting, Accounting & SQL Accounting

## D1 — Applicable Financial Reporting Standards

[case figure moved to example-2026-Q1.md]

[case figure moved to example-2026-Q1.md]
|----------|-------------------|
| MFRS 15 | Revenue recognition — all clinic revenue streams |
| MFRS 102 | Inventories — pharmacy stock, medical consumables |
| MFRS 116 | Property, plant and equipment — medical equipment, renovation, X-ray |
| MFRS 136 | Impairment of assets — PPE, investments in subsidiaries |
| MFRS 9 | Financial instruments — interco loans (ECL), trade receivables |
| MFRS 124 | Related party disclosures — interco balances, director transactions |
| MFRS 132 | Financial instruments presentation — director loan equity vs liability classification |
| MFRS 137 | Provisions, contingent liabilities — legal matters, regulatory penalties |
| MFRS 1 | Presentation of financial statements — BS, P&L structure |
| MFRS 16 | Leases — clinic premises, equipment leases (MFRS 16 threshold: lease >12 months) |
| MFRS 119 | Employee benefits — bonus provisions, leave accruals |

---

## D2 — Balance Sheet Audit Tests

| Account | Test | Evidence | Assertion |
|---------|------|---------|-----------|
| Trade Debtors (300-000) | Agree to AR aging; test aged items for collectibility | `[REC]` + `[INS]` | CO, VA |
| Other Debtors (305-000) | Obtain itemised schedule; confirm nature of each item | `[INS]` | EX, VA |
| Bank (310-000) | Bank confirmation + reconciliation | `[CON]` bank statement | EX, AC |
| Petty Cash (320-xxx) | Physical count; investigate negative balances | `[PHY]` | EX |
| Petty Cash — Cash Sales (320-002) | Confirm cash deposited to bank; day-end reconciliation | `[REC]` | EX |
| Stock (330-000) | Physical count; check opening=closing (MFRS 102 breach) | `[PHY]` | EX, VA |
| Deposit & Prepayment (340-000) | Itemised schedule; confirm recoverable; amortisation for prepaid | `[INS]` | VA, EX |
| Interco Receivables (350-xxx) | See Reference E | — | VA, RO |
| Trade Creditors (400-000) | Agree to AP aging; test cut-off | `[REC]` | CO, VA |
| Director's A/C (440-000) | Movement schedule; board approval for any advance | `[INS]` board minutes | AU, DI |
| Provision for Tax (450-001) | Tax computation; current year estimate | `[INS]` tax computation | AC |

---

## D3 — P&L Audit Tests

| Category | Specific Test | Flag Threshold |
|----------|--------------|----------------|
| Salaries | Payroll register vs GL; headcount × average | Variance >5% |
| EPF/SOCSO/EIS/HRDF | Recalculate against payroll register; compare to BS payable | Any shortfall |
| Rental | Verify tenancy agreement; MFRS 16 test if >12 months | Rental increase not in agreement |
| Marketing Fee | Invoice, contract, vendor SSM registration | Any payment with no contract |
| Travel & Accommodation | Expense claims, receipts, approval | Unsupported items; director personal travel |
| Legal Fee | Nature of matter; MFRS 137 contingency | Undisclosed proceedings |
| Consultation Fee | Sessional doctor agreements; timesheet; payment basis | Without contract |
| Bank Charges | Bank statement reconciliation | Unexplained charges |
| Depreciation | Recalculate against PPE register; rates per LHDN Schedule | Over/under depreciation |
| Management Fee Income | Interco agreement; amount per agreement | Without formal agreement |

---

## D4 — SQL Accounting IT General Controls (ITGC)

| Control | Test | Evidence | Risk |
|---------|------|---------|------|
| User access — individual named accounts (no shared login) | `[INS]` SQL user management screen | AU | 🔴 "ADMIN" account shared = no audit trail attribution |
| Segregation of duties — posting vs approving | `[INS]` user role matrix | AU | 🟠 |
| Journal entry approval — threshold-based | `[INS]` JV above RM X requires second approver | AU | 🟠 |
| Period lock — prior periods cannot be modified without CFO override | `[OBS]` attempt to post to locked period | CP | 🟠 |
| Backup — daily automated, offsite, tested | `[INS]` backup policy + restoration test log | CO | 🟠 |
| Audit trail — complete, tamper-evident | `[INS]` SQL audit log | CO | 🟠 |
| Password policy — min 8 chars, expiry 90 days | `[INS]` SQL security settings | CP | 🟡 |
| Physical server security | `[PHY]` server room access log | EX | 🟡 |

---

## D5 — Fixed Asset Register Review (MFRS 116)

| Test | Evidence | Assertion |
|------|---------|-----------|
| FA register agrees to GL PPE accounts | `[REC]` register total vs BS balances | AC |
| Depreciation rates align with LHDN capital allowance rates | `[REC]` recalculate depreciation | AC |
| Fully depreciated assets still in use — NBV = 0 but operational | `[PHY]` physical verification | EX |
| Capital expenditure properly capitalised (not expensed) | `[INS]` GL for items >RM 1,000 in repairs/upkeep | AC |
| AELA equipment on FA register matches AELA licence Appendix A | `[REC]` cross-reference | EX, CP |
| No negative NBV (signal of under-accumulated depreciation or manual error) | `[REC]` NBV calculation per asset | AC |

---

## D6 — Accounting Policy Disclosures Required (MFRS 1 / MPERS)

Annual financial statements must disclose:
- Revenue recognition policy (MFRS 15 — point in time vs over time per service type)
- Inventory valuation method (FIFO or weighted average — MFRS 102)
- PPE depreciation rates by asset category
- Basis for intercompany receivable carrying value (amortised cost; ECL provision)
- Related-party transaction nature and terms (MFRS 124)
- Lease obligations (MFRS 16 right-of-use if applicable)
- Contingent liabilities (MFRS 137 — legal proceedings, regulatory investigations)
- Director remuneration and transactions (Companies Act 2016 s.228)
