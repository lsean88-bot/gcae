> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- Step 0 — Evidence Standard (Read Before Any Fieldwork)
- Step 1 — Establish MKPC Company Context
- Step 2 — Web-Validate All Regulations Before Writing
- Step 3 — Document Inventory (Tiered Request)
- Step 4 — Execute Audit Tests Across All Seventeen Domains
- Step 5 — Report structure
- Step 6 — Excel Audit Workbook Output (MK Tron GIA House Style)
- Non-Negotiable Validation Standards


# /my-mkpc-mfg-audit — MKPC Malaysia Die Casting, Stamping & Assembly Internal Audit

Conduct a rigorous internal audit of MKPC's manufacturing operations across die casting (HPDC/GDC),
metal stamping, and sub-assembly processes, supplying Perodua, Denso, Daihatsu-affiliated entities,
Proton, and foreign OEM/Tier 1 customers. All output is grounded in **2024 IIA Global Internal
Audit Standards (GIAS)** effective January 9, 2025, and validated against current Malaysian law,
RMCD/LHDN/DOSH/DOE regulations, MFRS/MPERS financial standards, and IATF 16949 (Rules 6th Edition).

**Finding structure (mandatory):** Condition → Criteria → Cause → Effect → Recommendation
**Each finding additionally states:** Assertion(s) Tested · Evidence Basis · MYR Exposure (or Unquantified + reason)

**Zero tolerance rules:** No finding on assumption. No estimate without source data and formula.
No management representation as sole basis for 🔴 Critical finding. No generic citation — always
state Act + Section + year, MFRS standard + paragraph, IIA GIAS 2024 Standard number.

---

## Step 0 — Evidence Standard (Read Before Any Fieldwork)

Seven evidence types — tag every test performed:

| Tag | Type | Reliability |
|-----|------|------------|
| `[INS]` | Document inspection | Original preferred; authenticated copy acceptable |
| `[PHY]` | Physical observation/count | Highest for existence; auditor must witness |
| `[CON]` | External confirmation | Portal (LHDN, KWSP, PERKESO, MySST, SSM, IAQG OASIS) — Rank 1; written confirmation — Rank 2 |
| `[REP]` | Management representation | Rank 5 — lowest; initiate inquiry only, never close finding |
| `[REC]` | Recalculation/reperformance | Auditor independently recomputes using primary data |
| `[OBS]` | Process observation | Timing risk — may not represent normal operations |
| `[ANA]` | Analytical procedure | Benford, ratio, trend, population — source data must be system-extracted |

Nine assertions: `EX` (existence) · `CO` (completeness) · `AC` (accuracy) · `VA` (valuation)
`CU` (cut-off) · `RO` (rights & obligations) · `CL` (classification) · `PR` (presentation) · `CP` (compliance)

**Operational rules:**
1. Every 🔴 Critical finding requires at least one `[CON]` or `[PHY]` or witnessed `[REC]`
2. 100% population testing preferred where ERP/MES/WMS data is extractable
3. All monetary findings quantified in **MYR** (or kg for physical; ppm/% for quality)
4. "Evidence Not Obtained" is a valid conclusion — state what was requested and the risk
5. Contradict, don't assume — when evidence contradicts management, evidence prevails

---

## Step 1 — Establish MKPC Company Context

Confirm all fields from verifiable sources before fieldwork:

| Field | Verified Source |
|-------|----------------|
| **Process scope** | IATF 16949 scope certificate (IAQG OASIS database — `iaqg.org/oasis`) |
| **Alloy/material** | Material Test Certificates (MTC), BOM, supplier CoA |
| **IATF 16949 status** | IAQG OASIS portal — certificate number, expiry, CB name, surveillance dates |
| **OEM customers** | Customer-issued Purchase Agreements / Annual Supply Contracts / PO history |
| **Customer-Specific Requirements (CSRs)** | Published CSR documents for each OEM (Perodua/Daihatsu CSR, Denso SQA Manual) |
| **MIDA incentive status** | Pioneer Status / ITA / RA approval letter from MIDA; LHDN incentive register |
| **Manufacturing License** | MITI Manufacturing License (ML) — no renewal required but expansion needs MITI notification |
| **SST registration** | MySST portal (`mysst.customs.gov.my`) — manufacturer registration status |
| **e-Invoice phase** | MyInvois portal — MKPC's annual turnover determines applicable phase |
| **Transfer pricing** | Foreign parent / related-party structure — ITA s.140A triggers if related-party transactions exist |
| **DOE license** | DOE scheduled waste generator registration — `doe.gov.my` |
| **BOMBA** | Current fire certificate — state BOMBA authority |
| **Foreign workers** | JTK registration; work permit validity; EPF mandatory from Oct 2025 |
| **ERP/MES/WMS** | IT system inventory — data extraction capability for analytics |
| **CARO equivalent (Companies Act 2016)** | Statutory auditor report — note any qualifications |
| **Prior incidents** | Legal register, DOSH accident records, LHDN correspondence, SST audit history |

**If documents unavailable within 5 working days:** Label output **"FRAMEWORK ONLY — No Evidence Obtained — No Line-Item Findings"**

---

## Step 2 — Web-Validate All Regulations Before Writing

Validate every rate, threshold, deadline from official portals. Never cite from memory.

| Regulation | Validation Source | Key 2025 Changes |
|-----------|-----------------|-----------------|
| SST rate & exemptions | `mysst.customs.gov.my` | Sales Tax Rate Order 2025: default rate per [MY-017]; verify reduced rate or exempt for specific auto parts |
| e-Invoice phase threshold | `myinvois.hasil.gov.my` | Phase 3 per [MY-020]; Finance Act 2024 deductibility rule |
| Income Tax Act / Pioneer / RA | `hasil.gov.my`; `mida.gov.my` | MIDA NIF (New Incentive Framework) Jan 2026; OECD Pillar Two GMT for MNEs |
| TP Rules 2012 / LHDN TP Guidelines | `hasil.gov.my` | LHDN TP Guidelines 2024; documentation threshold |
| EPF rates | `kwsp.gov.my` | employer [MY-005]; employee [MY-004]; foreign workers [MY-006] |
| SOCSO/EIS ceiling | `perkeso.gov.my` | [MY-007] |
| Minimum Wage | `mohr.gov.my` | [MY-003] (effective dates by employer size in the register) |
| Employment Act 1955 | `mohr.gov.my` | EA Amendment 2022 (Act A1651); max 45 hrs/week; universal coverage |
| OSHA 1994 / Amendment 2022 | `dosh.gov.my` | Act A1648; penalty per [MY-048]; OSH Coordinator mandatory ≥5 employees |
| DOE EQA Scheduled Waste | `doe.gov.my` | EQA 1974; SW Regs 2005; SW list (SW codes for die casting waste) |
| IATF 16949 Rules 6th Edition | `iatfglobaloversight.org` | Rules 6th Ed (2024, effective 1 Jan 2025); 12-month surveillance; 15-day NC response |
| IAQG OASIS MKPC cert status | `iaqg.org/oasis` | Real-time certificate validity check |
| SSM company status | `mydata.ssm.com.my` | Annual return; director register |
| LME Al/Zn prices | `lme.com` | For metal yield valuation findings |
| Mild steel HRC/CRC prices | MITI / published steel indices | For stamping COGS variance |

---

## Step 3 — Document Inventory (Tiered Request)

Mark each: ✅ Obtained | ⚠️ Partial | ❌ Not Provided

**Tier 1 — Mandatory (engagement cannot proceed without these):**
- SST-02 returns — all taxable periods (cross-validate `[CON]` MySST portal)
- LHDN: CP204 + CP204A + last 3 years tax computations (`[CON]` MyTax portal)
- EPF: monthly contributions all periods (`[CON]` i-Akaun employer portal)
- SOCSO/EIS: monthly contributions (`[CON]` PERKESO ASSIST portal)
- IATF 16949 certificate + last surveillance audit report (`[CON]` IAQG OASIS portal for cert status)
- Audited financial statements (last 2 years) + management accounts (current year)
- ERP production records: BOMs, work orders, material consumption, scrap register
- Customer contracts/Annual Purchase Agreements: Perodua, Denso, all OEM customers

**Tier 2 — Domain-Specific:**
- Tooling/die register: die number, owner, location, condition, depreciation
- Metal yield reports: ingot/slab input → good casting output → scrap by category
- Weigh-gate scrap records (if applicable): signed, timestamped, per dispatch
- Customer DO (Delivery Order) register vs. invoice register
- AR aging report as at audit date
- BOM per part number per customer
- MRP/production planning records: customer demand releases, schedule, actual vs. plan
- OEM quality scorecards (customer-issued — not MKPC self-prepared)
- 3-way match samples: PO + GRN + vendor invoice (top 30 by value)
- Payroll register: all employees, all periods
- Bank statements and bank reconciliations: all accounts, all periods
- DOE scheduled waste manifests (Borang SW) — all periods
- BOMBA fire certificate (current)
- MACC-related: gifts & entertainment register, ABAC policy

**Document authenticity:** Verify ≥5 documents per domain against originating portal or system.

---

## Step 4 — Execute Audit Tests Across All Seventeen Domains

For each domain: state assertion → obtain evidence → quantify → write condition.
Apply `[ANA]` Benford's Law to all high-volume financial populations (invoices, payments, scrap weights).

---

### Domain 1 — SST Compliance (Sales Tax Act 2018 / Service Tax Act 2018)
Read: `references/mkpc-sst_compliance.md`

**Legal basis:** Sales Tax Act 2018 (STA 2018); Service Tax Act 2018 (STA 2018); Sales Tax (Rate of Tax) Order 2025; Finance Act 2024 (e-invoice deductibility)

**Key rate changes effective 1 Jul 2025 (Sales Tax Rate Order 2025):**
- Default rate: **10%** on all taxable goods
- Specific rates (5% or exempt): verify exact tariff code for each MKPC product (die castings, stampings, assemblies)
- Automotive parts (HS Chapter 87): verify SST treatment per RMCD tariff schedule

| Test | Evidence | Assertion |
|------|---------|----------|
| SST registration — manufacturer status, threshold compliance | `[CON]` MySST portal | CP, EX |
| SST-02 returns — all taxable periods filed & paid on time | `[INS]` SST-02 + `[CON]` MySST portal filing history | CO, CP |
| Correct SST rate per product type — die castings, stampings, assemblies classified correctly | `[REC]` re-classify each product by tariff code → confirm rate per [MY-017] or exempt | AC, CL, CP |
| Schedule C manufacturing exemption — raw materials (steel HRC/CRC, aluminium ingots, zinc) | `[INS]` exemption certificates; `[REC]` verify eligible inputs | CP |
| Sales to Perodua/Denso — SST correctly applied; exemption certificates on file | `[INS]` sample 25 sales invoices; verify customer's SST exemption cert (if any) | AC, CP |
| Service tax on imported services (reverse charge) — engineering fees to Japanese parent/Denso | `[INS]` foreign service invoices; `[REC]` service tax self-account ([MY-019]) | CP, AC |
| **e-Invoice (MyInvois) compliance** — all B2B invoices validated; QR/UUID on invoices | `[CON]` MyInvois portal; `[INS]` sample 30 invoices — verify QR against portal | CP, CO |
| **Finance Act 2024** — expense deductibility; all supplier invoices validated e-invoices | `[CON]` MyInvois portal for top 20 purchase invoices by value | CP, AC |
| Benford on sales invoice amounts | `[ANA]` full population of sales invoices | CO, AC |

**Key findings to probe:** Wrong SST rate on die-cast vs. stamped parts (different HS codes); SST not charged on local sales when applicable; e-invoice non-compliance losing deductibility on expenses.

---

### Domain 2 — Income Tax, Incentives & Transfer Pricing
Read: the retired `income_tax_tp` module (not a separate file in this suite)

**Legal basis:** Income Tax Act 1967 (ITA); Promotion of Investments Act 1986 (PIA); TP Rules 2012; LHDN TP Guidelines 2024; MIDA NIF Jan 2026; OECD Pillar Two Global Minimum Tax (applicability threshold per [MY-039])

| Test | Evidence | Assertion |
|------|---------|----------|
| Corporate tax filing (CP204 advance + CP204A revision + Form C) | `[CON]` LHDN MyTax portal; `[INS]` CP204 acknowledgements | CO, CP |
| **Pioneer Status / ITA compliance** — conditions met; qualifying activities performed; pioneer income not commingled with non-pioneer | `[INS]` MIDA approval letter + conditions; `[INS]` management accounts split between pioneer/non-pioneer | CP, AC |
| **Reinvestment Allowance (RA) — Schedule 7A ITA** — qualifying capex correctly identified; 15-year period tracked | `[INS]` capex invoices; `[INS]` RA schedule; `[REC]` recalculate RA claim | AC, VA, CP |
| **Transfer pricing (ITA s.140A, TP Rules 2012)** — related-party sales to Denso/Japanese parent at arm's length | `[INS]` TP documentation; `[INS]` comparable pricing benchmarks; `[REC]` arm's-length price vs. actual | AC, CP |
| **Thin capitalisation (ITA s.140C)** — related-party debt/equity ratio within allowable | `[REC]` related-party debt ÷ equity from audited FS | AC, CP |
| PCB/MTD — correct deduction; CP39 submitted by 15th | `[CON]` LHDN MyTax portal; `[REC]` recalculate PCB for sample 10 employees | AC, CP |
| Withholding tax (ITA s.109) — on royalties/technical fees to Denso Japan or foreign parent | `[INS]` royalty/technical fee invoices; `[REC]` WHT at the [MY-040] rate or contract rate | AC, CP |
| **OECD Pillar Two** — if MK Tron Group consolidated revenue >EUR750M, Global Minimum Tax 15% applies | `[REP]` group structure confirmation; `[INS]` group consolidated revenue | CP |
| MIDA NIF (Jan 2026) — if new investment incentive application pending or recently approved | `[INS]` NIF principle approval letter; conditions checklist | CP |

---

### Domain 3 — Employment & Statutory Payroll
Read: `references/mkpc-employment_payroll.md`

**2025 current rates (web-validated):**
- **Minimum wage:** [MY-003]
- **EPF:** employer [MY-005]; employee [MY-004]; foreign workers [MY-006]
- **SOCSO:** rates [MY-008]; insurable wage ceiling [MY-007]
- **EIS:** rate [MY-009]; insurable wage ceiling [MY-007]; Malaysian/PR in the covered age band only
- **HRD Corp:** levy per [MY-045]
- **PCB/MTD:** Due by 15th of following month (CP39)
- **EA 1955 max working hours:** 45 hours/week (EA Amendment 2022)
- **OT eligibility:** per Employment Act coverage [MY-001]

| Test | Evidence | Assertion |
|------|---------|----------|
| **4-way headcount reconciliation** — EPF + SOCSO + Payroll + PHY/access card | `[CON]` KWSP i-Akaun + PERKESO portal; `[INS]` payroll; `[OBS]` access records | EX, CO |
| EPF — monthly contributions correct rate & paid by 15th | `[CON]` KWSP i-Akaun employer portal; `[REC]` recalculate for sample 10 | AC, CP |
| **EPF foreign workers (Oct 2025)** — [MY-043] applied to all non-Malaysian employees | `[CON]` KWSP portal; `[REC]` identify foreign workers on payroll + verify EPF deduction from Oct 2025 wages | AC, CP |
| **SOCSO/EIS — register ceiling [MY-007] applied correctly** | `[CON]` PERKESO ASSIST portal; `[REC]` recalculate contributions for employees above the superseded ceiling | AC, CP |
| **Minimum wage [MY-003]** — all employees | `[REC]` compare lowest payroll entries to gazette; flag any entry below the minimum from its effective date | AC, CP |
| HRD Corp — levy ([MY-045]) paid monthly; training claims submitted | `[CON]` HRD Corp portal; `[INS]` levy payment receipts | CP |
| PCB/MTD — CP39 submitted; no LHDN penalty | `[CON]` LHDN MyTax portal; `[INS]` CP39 receipts | CP |
| EA 1955 — OT within the weekly hours limit; OT rate multipliers [MY-002] | `[INS]` OT records; `[REC]` OT hours vs. weekly limit; `[REC]` OT rate calculation | AC, CP |
| **Ghost employee** — bank account shared ≥2 employees; IC/passport duplicate | `[ANA]` full-population bank account analysis; IC/passport number uniqueness | EX |
| **Foreign worker permits** — Employment Pass/PLKS current; JTK registration | `[CON]` JTK online; `[INS]` work permits for all foreign workers | CP |
| EA Amendment 2022 compliance — written contracts; payslips issued; domestic violence leave policy; sexual harassment policy; FWA policy | `[INS]` HR policy documents (post 1 Jan 2023); sample payslips | CP |

---

### Domain 4 — IATF 16949 Quality Management System
Read: `references/mkpc-iatf_quality.md`

**Legal/Standard basis:** IATF 16949:2016 (currently transitioning to 6th Edition Rules effective Jan 2025); Customer-Specific Requirements (CSRs) for each OEM; AIAG Core Tools

**IATF 16949 Rules 6th Edition (effective 1 Jan 2025) key changes:**
- Surveillance audit interval: exactly 12 months (no flexibility)
- NC corrective action response: reduced from 20 to **15 days**
- Late surveillance = immediate certificate removal (no grace)
- Remote audits limited to support functions only
- Certificate valid 3 years with annual surveillance

| Test | Evidence | Assertion |
|------|---------|----------|
| **IATF 16949 certificate — current & valid** | `[CON]` IAQG OASIS portal (certificate number, expiry, CB name, scope) | EX, CP |
| **Surveillance audit — conducted within 12 months** | `[INS]` last surveillance audit report + certificate; `[CON]` OASIS portal | CP |
| **Open NCs from last audit — closed within 15 days** | `[INS]` audit NC log; corrective action evidence | CP |
| Customer-Specific Requirements (CSRs) — identified & documented for each OEM | `[INS]` CSR matrix per customer; `[OBS]` production floor application | CP |
| **APQP/PPAP** — all current production parts have approved PPAP (Level 3+ for Perodua/Denso) | `[INS]` PPAP files for all active part numbers; `[INS]` customer PPAP approval | CP, EX |
| **PFMEA** — current, reviewed within 12 months; all high RPN actions closed | `[INS]` current PFMEA per process; action tracker | CP |
| **Control Plan** — linked to PFMEA; operator instructions current | `[INS]` control plans vs. PFMEA linkage | CP |
| **MSA (Measurement System Analysis)** — Gage R&R for all critical measurement systems | `[INS]` MSA reports for gauges used in critical characteristics | CP |
| **SPC** — applied on all critical characteristics; Cpk ≥1.33 target | `[INS]` SPC charts; `[REC]` Cpk recalculation for sample | CP, AC |
| OEM quality scorecards — MKPC's PPM/DPPM/warranty claims vs. targets | `[CON]` OEM portal (customer-issued scorecard — not MKPC's own); compare vs. IATF internal targets | AC |
| Product safety representative — appointed | `[INS]` appointment letter + training record | CP |
| Counterfeit parts prevention — policy & supplier controls | `[INS]` anti-counterfeit policy; AVL verification records | CP |
| **Cybersecurity requirements (IATF 6th Ed)** — baseline assessment completed | `[INS]` cyber risk assessment; IT policy | CP |

---

### Domain 5 — OEM Customer Billing, DO Reconciliation & Collection
Read: `references/mkpc-oem_billing_collection.md`

**Context — Perodua supply chain:**
- Perodua (P2) sources via Perodua Suppliers Association (P2SA) framework
- Billing based on: customer-authorized delivery schedule → Kanban/Pull → DO → Invoice
- Payment terms: typically 30–60 days; Perodua known for prompt payment
- Price governed by Annual Purchase Agreement (APA) + periodic price revision (cost-down pressure)
- Part price includes: base component price + steel/aluminium surcharge (commodity-linked escalation clauses)

**Context — Denso supply chain:**
- Denso operates on Daihatsu-derived production system (DPS/TPS-aligned)
- Strict EDI-based demand management (830/862 equivalent in Japanese format)
- Supplier Quality Assurance (SQA) manual; incoming parts inspected per Denso AQL standards
- Billing: monthly consolidated or delivery-based; payment 30–45 days

**Context — Foreign OEM/Tier 1:**
- May involve cross-border invoicing; foreign exchange risk (USD/JPY vs. MYR)
- FEMA-equivalent: Malaysia — Bank Negara Malaysia (BNM) Financial Services Act 2013 for FX
- Transfer pricing risk if foreign customer is related party

| Test | Evidence | Assertion |
|------|---------|----------|
| **3-way match: PO + DO + Invoice** — sample 30 highest-value invoices per major customer | `[INS]` PO, DO, invoice; verify quantity, unit price, APA rate | AC, CP |
| **DO-Invoice completeness** — all DOs issued within period are invoiced within billing cycle | `[ANA]` DO register vs. invoice register (full population); flag unbilled DOs | CO, CU |
| **Unit price verification** — invoiced price matches APA/contract price; surcharge correctly applied | `[REC]` (APA price + surcharge formula) vs. invoiced price; exposure = (difference × volume) | AC |
| **Commodity surcharge (steel/Al)** — escalation formula applied correctly; supporting index used | `[REC]` APA formula × published steel/Al index (MITI/LME) vs. actual surcharge billed | AC |
| **Revenue cut-off** — revenue recognized when DO signed by customer, not invoice date | `[INS]` DO date vs. invoice date vs. ledger posting date; sample 20 end-of-period transactions | CU |
| **MFRS 15 / MPERS s.23** — no bill-and-hold, no early recognition | `[INS]` contract terms; `[OBS]` dispatch practice | AC, CU |
| AR aging — Perodua/Denso 30/45/60-day terms; overdue analysis | `[INS]` AR aging as at audit date; `[CON]` circularize top 10 customers by balance | VA, CO |
| **Foreign OEM invoicing** — correct currency; FX risk hedging | `[INS]` FX forward contracts (if any); `[INS]` FX gain/loss in P&L | AC |
| Credit note authorization — valid basis; MD/Finance approval; not fictitious | `[INS]` credit note register; `[INS]` underlying complaint/return documentation | CP |
| Benford on sales invoice amounts | `[ANA]` full population | CO, AC |
| Benford on credit note amounts | `[ANA]` full population | CO |

---

### Domain 6 — Financial Reporting (MFRS/MPERS)
Read: `references/clinic-D_financial_reporting.md`

**Framework determination:** MFRS if MKPC is subsidiary of listed/public entity or if MK Tron Group uses MFRS. MPERS for private entity (MPERS 2016 currently applicable; MPERS 2025 effective 1 Jan 2027 — transition planning required).

#### 6A — Revenue Recognition (MFRS 15 / MPERS s.23)

| Test | Evidence | Assertion |
|------|---------|----------|
| Revenue recognized at point of control transfer (DO signed by customer) | `[INS]` DO date vs. revenue posting date; sample 30 | CU, AC |
| Tooling/die revenue — recognized when tool approved by customer (PPAP) | `[INS]` PPAP approval; `[INS]` tooling invoice | CU |
| **Variable consideration** — price revisions, rebates, volume discounts — estimated correctly | `[INS]` APA; `[REC]` expected rebate vs. accrual | AC, VA |
| Contract modifications (price downs, volume changes) — accounting treatment | `[INS]` amendment letters; `[INS]` P&L impact | AC, CU |

#### 6B — Inventory & COGS (MFRS 102 / IAS 2 / MPERS s.13)

| Test | Evidence | Assertion |
|------|---------|----------|
| Inventory valuation — lower of cost or NRV | `[INS]` purchase invoices for last lot; `[REC]` NRV = selling price − selling costs | VA, AC |
| **BOM standard cost** — Al ingot/Zn ingot/steel HRC per part; labour + overhead | `[INS]` approved BOM; `[REC]` standard cost vs. actual cost variance | AC, VA |
| **Metal yield / Material Turnover Coefficient (MTC)** — see Domain 9 | Cross-reference to Domain 9 | AC, VA |
| FIFO/WAC — consistently applied | `[INS]` accounting policy; `[REC]` batch costing trace | AC, CP |
| **Tooling/die costs** — customer-owned tools: no capitalize; MKPC-owned: capitalize as PPE | `[INS]` tooling agreements; `[INS]` capitalization schedule | CL, AC |
| Slow-moving & obsolete inventory — NRV write-down assessed | `[ANA]` inventory aging >90 days; `[INS]` management NRV assessment | VA |

#### 6C — PPE, Tooling & Capex (MFRS 116 / MPERS s.17)

| Test | Evidence | Assertion |
|------|---------|----------|
| Die casting machines — useful life, depreciation rate appropriate | `[INS]` asset register + OEM machine spec; `[REC]` depreciation recalculation | AC |
| **Die/tooling governance** — MKPC-owned vs. customer-owned; correct capitalization/expense | `[INS]` tooling ownership clauses in OEM contract; `[INS]` asset register classification | CL, RO |
| **Impairment (MFRS 136 / MPERS s.27)** — idle machines, discontinued parts | `[INS]` utilisation data; `[INS]` management impairment assessment | VA |
| Capex authorization — all capex within approved budget; no opex misclassified as capex | `[INS]` capex budget vs. actuals; `[INS]` capex authorization forms | CP, AC |

#### 6D — Leases (MFRS 16 / MPERS s.20)

| Test | Evidence | Assertion |
|------|---------|----------|
| Factory/land lease — MFRS 16 ROU asset & lease liability | `[INS]` lease agreements; `[REC]` PV of lease payments (IBR used) | VA, CL |
| Short-term/low-value exemptions appropriately applied | `[INS]` lease register | CL |

---

### Domain 7 — Cash Payments & Disbursement Controls
Read: the retired `cash_controls` module (not a separate file in this suite)

| Test | Evidence | Assertion |
|------|---------|----------|
| Vendor payment — 4-eye approval; SoD between payment preparor and authorizer | `[INS]` payment vouchers + authorization trail; `[OBS]` system access segregation | CP |
| Petty cash — surprise count vs. float; voucher authorization | `[PHY]` surprise cash count; `[INS]` petty cash vouchers | EX, CP |
| **Benford on all payment amounts** — detect round-sum, just-below-threshold | `[ANA]` full population of ERP payment transactions | AC, CO |
| Vendor master changes — authorization trail; no unauthorized new vendor | `[INS]` vendor master change log vs. change request forms | CP |
| **Related-party payments** — disclosed; arm's length; board approval | `[INS]` RPT schedule; `[CON]` related-entity confirmation | AC, PR |
| **Tooling payments to die makers** — 3-way match (PO + completion certificate + invoice); stage payment verification | `[INS]` tooling POs, completion certs, invoices for all die purchases | AC, CP |
| MACC Act 2009 s.17A — gifts, entertainment register; hospitality to Perodua/Denso buyers | `[INS]` G&E register; `[OBS]` policy enforcement | CP |
| Cash advances — all settled; no long-outstanding advances | `[INS]` advance ledger; `[ANA]` advances outstanding >30 days | AC, EX |

---

### Domain 8 — Procurement, Vendor Management & AVL
Read: the retired `procurement_avl` module (not a separate file in this suite)

| Test | Evidence | Assertion |
|------|---------|----------|
| Approved Vendor List (AVL) — all raw material suppliers on approved list; re-qualification records | `[INS]` AVL + last approval date; `[INS]` supplier audit reports | CP, RO |
| **Steel (HRC/CRC) procurement** — competitive tender; price vs. MITI benchmark | `[REC]` MKPC purchase price vs. MITI/published HRC index; exposure = (MKPC price − index) × volume | AC |
| **Aluminium ingot (ADC12/A380) procurement** — price vs. LME Al basis | `[REC]` MKPC purchase price vs. LME Al spot + premium; `[INS]` CoA for alloy chemistry | AC |
| Sole-source procurement — authorized; reason documented; price benchmarked | `[INS]` sole-source authorization forms for all non-competed purchases | CP |
| GRN (Goods Received Note) — signed; IQC pass before GRN; no backdating | `[INS]` GRN register; `[OBS]` IQC process; `[ANA]` GRN date vs. IQC date | AC, CU |
| Inventory receipt — 3-way match: PO + GRN + vendor invoice | `[INS]` sample 30 highest-value purchases | AC |
| Kickback risk — procurement officer owns/is related to vendor | `[ANA]` cross-reference vendor masters vs. employee IC/address records | CP |

---

### Domain 9 — Die Casting Metal Yield, MTC & Scrap Reconciliation
Read: `references/mkpc-metal_yield_scrap.md`

This is the most technically complex and highest fraud-risk domain for MKPC die casting.

**HPDC Material Turnover Coefficient (MTC):**
```
MTC = Good Casting Weight Output ÷ Metal Input Weight × 100%

Industry benchmarks:
  Aluminium HPDC (ADC12/A380): MTC 65–75% (25–35% inherent scrap — runners, gates, overflow, dross)
  Zinc HPDC: MTC 70–80%
  Cold chamber Al (structural parts): MTC 60–70%

MTC below lower benchmark = unaccounted metal loss → fraud risk or process failure
```

**Material Balance Master Equation:**
```
Opening metal inventory
+ Metal purchased (Al ingot / Zn ingot / steel coil) [INS: GRN × certified weight + MTC CoA]
− Good castings/stampings output [INS: QC pass records × part weight per BOM]
− Authorized scrap (runners/gates/trim/overflow/dross) [INS: scrap register by category]
− Metal sold as scrap to dealer [INS: weigh-gate log + scrap invoice]
= Theoretical closing inventory

Actual closing inventory [PHY: physical count + WMS/ERP]

Variance = Theoretical − Actual = Unaccounted metal
Exposure (MYR) = Unaccounted kg × LME price/kg (portal-sourced)
```

| Test | Evidence | Assertion |
|------|---------|----------|
| **Metal balance (full population)** — all periods under review | `[INS]` GRN + production records + scrap register + weigh-gate; `[PHY]` physical count | EX, CO, AC |
| **MTC calculation** — actual vs. industry benchmark per alloy type | `[REC]` good output ÷ metal input; compare to 65–75% (Al HPDC) | AC, VA |
| **Scrap categorization** — runners/gates (clean, recycled internally) vs. contaminated (sold externally) | `[INS]` scrap register; `[PHY]` scrap bins at production floor | CO, AC |
| **Internal scrap recycling** — runners/gates returned to furnace; weight reconciled | `[INS]` recycled scrap weight vs. remelt records; no leakage | EX, AC |
| **Scrap sales to dealer** — authorized; competitive pricing; weigh-gate log signed by independent party | `[INS]` scrap invoices; `[INS]` weigh-gate log; `[REC]` price vs. market | AC, CP |
| **Benford on scrap weights** — detect pattern in recorded weights | `[ANA]` full population of weigh-gate scrap records | CO, AC |
| **Dross recovery** — Al dross treated/sold; weight and value reconciled | `[INS]` dross disposal records; `[CON]` licensed processor receipts | EX, AC |
| **Alloy chemistry control** — incoming ingot CoA vs. specification; spectrometric analysis records | `[INS]` supplier CoA; `[INS]` in-house spectrometer records | AC, CP |
| Scrap authorization — condemned parts written off with engineering sign-off | `[INS]` NCR/scrap authorization per batch | CP, EX |

**Stamping material balance (for stamping lines):**
```
Steel coil input weight
− Good blank/stamped part weight (part weight × good quantity)
− Authorized trim scrap (skeleton, offcuts)
= Theoretical closing steel coil stock

Actual closing = [PHY] count
Yield benchmark: 70–85% depending on blank nesting efficiency (DL/OEM approved nesting plan)
```

**Key fraud risks:** Metal diversion (selling ingots or good castings as scrap); MTC manipulation (recording higher good output than actual); scrap weight inflation by weigh-gate collusion.

---

### Domain 10 — Tooling & Die Governance
Read: the retired `tooling_die` module (not a separate file in this suite)

Tooling is one of the highest-value assets in die casting/stamping — typically MYR 50,000 to MYR 2,000,000+ per die. Governance failures are a major fraud and operational risk.

| Test | Evidence | Assertion |
|------|---------|----------|
| **Tooling register** — all dies; die number, part numbers served, material, date commissioned, shot count, maintenance record, location, ownership | `[INS]` tooling register vs. `[PHY]` physical dies in die store | EX, CO |
| **Ownership determination** — MKPC-owned vs. customer-owned (free-issue tool) | `[INS]` OEM contract tooling clause; separate register per ownership class | RO, CL |
| **Customer-owned tools** — not capitalized by MKPC; no depreciation; held as bailee | `[INS]` balance sheet vs. tooling register; verify no capitalize of customer-owned dies | CL, AC |
| **MKPC-owned tools** — correctly capitalized at cost; useful life = shots ÷ design life | `[INS]` capex invoices; `[REC]` depreciation per shot count method | VA, AC |
| **Die shot count** — tracked; planned maintenance at OEM-specified shot intervals | `[INS]` MES shot counter vs. maintenance log | CP |
| **Tooling procurement fraud** — multiple invoices for same die; phantom tooling | `[ANA]` tooling vendor invoice frequency; `[PHY]` count vs. invoice count | EX, CO |
| Die disposal/scrapping — authorized; customer approval for customer-owned dies | `[INS]` scrap/disposal authorization; `[INS]` customer written approval | CP, RO |
| Die condition — critical dies near end-of-life; capital plan for replacement | `[INS]` die condition report; `[INS]` capex forecast | VA |

---

### Domain 11 — Production Planning, S&OP & OTIF
Read: the retired `production_planning` module (not a separate file in this suite)

| Test | Evidence | Assertion |
|------|---------|----------|
| Customer demand release — received via EDI/email/portal; loaded into ERP MRP | `[CON]` OEM portal/EDI system (customer-issued); reconcile to ERP | AC |
| **MRP run** — current BOM and routing; capacity constraints identified | `[INS]` MRP run parameters; `[INS]` work center capacity | CP |
| **OTIF (On Time In Full)** — actual vs. Perodua/Denso target | `[CON]` OEM-issued OTIF scorecard (not MKPC self-report); `[INS]` DO register timestamps | AC |
| Demand forecast accuracy (MAPE) | `[REC]` (forecast − actual) ÷ actual; trend by month | AC |
| Safety stock — set by OEM requirement or MKPC policy; adequate vs. lead time | `[INS]` safety stock settings in ERP vs. OEM delivery lead-time | CP |
| **Production vs. schedule adherence** | `[INS]` daily production report vs. production schedule | AC |
| Expediting cost (airfreight, overtime) — authorized; root cause documented | `[INS]` expediting log; root cause reports | CP |

---

### Domain 12 — Warehouse, FG Inventory & WMS
Read: the retired `warehouse_ops` module (not a separate file in this suite)

| Test | Evidence | Assertion |
|------|---------|----------|
| **Physical inventory count** — blind count by auditor vs. WMS/ERP | `[PHY]` physical count (auditor-witnessed); count sheets co-signed | EX |
| **FIFO** — oldest stock dispatched first; WMS FIFO enforcement | `[OBS]` dispatch process; `[INS]` WMS FIFO config | CP |
| GRN authorization — all GRNs have supporting PO; IQC pass before GRN | `[INS]` GRN exception report; `[OBS]` IQC gate | AC, CU |
| **SLOB (Slow-moving & Obsolete)** — identified; provision assessed | `[ANA]` WMS/ERP age report (>90 days no movement); `[INS]` NRV assessment | VA |
| Consignment stock — separately identified; not included in MKPC's stock count | `[INS]` consignment agreement; `[PHY]` separate storage area | RO, EX |
| WMS access controls — SoD; no single user with create+approve+dispatch rights | `[OBS]` WMS user access matrix; `[INS]` IT access control log | CP |

---

### Domain 13 — OSHA & Factory Safety
Read: the retired `osha_factory` module (not a separate file in this suite)

**Legal basis:** Occupational Safety & Health Act 1994 (OSHA, Act 514) as amended by Act A1648 (2022); Factories & Machinery (Repeal) Act 2022 (Act 835, effective 2024)

| Test | Evidence | Assertion |
|------|---------|----------|
| **DOSH registration** — all pressure vessels, compressors, hoists, overhead cranes | `[CON]` DOSH eSIHA portal; `[INS]` DOSH registration certificates | EX, CP |
| **OSH Coordinator** — appointed (≥5 employees, EA Amendment 2022) | `[INS]` appointment letter; `[CON]` DOSH portal registration | CP |
| CHRA — current (≤5 years); covers all chemicals (mould release agents, coolants, paints) | `[INS]` CHRA report date vs. chemical list in use | CP |
| Safety & Health Committee — ≥40 employees; monthly meetings; minutes | `[INS]` committee appointment + last 12 months' minutes | CP |
| Die casting specific: **molten metal safety** — Personal Protective Equipment (PPE), emergency stop, splash shields | `[OBS]` production floor; `[INS]` PPE inventory | CP |
| Accident reporting — JKKP 6 (Form 7 equivalent) to DOSH within 7 days | `[INS]` accident register; `[CON]` DOSH notification records | CO, CP |
| BOMBA — current fire certificate; fire suppression systems functional | `[INS]` BOMBA certificate; `[OBS]` fire suppression systems | CP |

---

### Domain 14 — Environmental Compliance (DOE / EQA 1974)
Read: the retired `doe_eqa` module (not a separate file in this suite)

**Die casting scheduled wastes (SW codes — verify at `doe.gov.my`):**
- Spent mould release agent / die lubricant → SW410 class
- Used coolant / cutting fluid → SW322
- Paint/coating waste → SW102 / SW410
- Oily sludge from compressors → SW306
- Al dross (if hazardous classification) → confirm with DOE

| Test | Evidence | Assertion |
|------|---------|----------|
| DOE registration as scheduled waste generator | `[CON]` DOE eKastam portal | CP, EX |
| SW manifests (Borang SW) for all scheduled waste disposals | `[INS]` SW manifests vs. SW register; `[PHY]` storage area compliance | CO, CP |
| Licensed SW contractor — current DOE license | `[CON]` DOE portal for contractor license | RO, CP |
| Effluent treatment — trade effluent license compliance; monitoring reports | `[INS]` DOE license; `[INS]` effluent monitoring records | CP |
| EMS (ISO 14001 if certified) — certificate current | `[INS]` ISO 14001 certificate | CP |

---

### Domain 15 — Anti-Bribery, Fraud & MACC Compliance
Read: the retired `abac_fraud` module (not a separate file in this suite)

**Legal basis:** MACC Act 2009 (Act 694); Corporate Liability provision s.17A (effective 1 Jun 2020)
ACFE Fraud Tree — MKPC-specific schemes:

| Scheme | Red Flag | Detection Test |
|--------|---------|----------------|
| **Metal diversion** | MTC below benchmark; scrap weight spikes | `[PHY]` count + `[ANA]` Benford scrap + `[REC]` MTC |
| **Ghost employee** | Payroll entry; no access card; shared bank account | `[ANA]` bank account + `[CON]` EPF/SOCSO headcount |
| **Phantom tooling** | Tool invoiced; not in die store | `[PHY]` die count vs. invoice register |
| **Procurement kickback** | Sole-source at above-market price | `[ANA]` price vs. LME/MITI + vendor relationship check |
| **Fictitious credit note** | Credit note to Perodua/Denso without valid return | `[INS]` credit note file; `[CON]` OEM confirmation |
| **Billing at wrong price** | Invoice price differs from APA; difference pocketed | `[REC]` APA price × volume vs. actual revenue |
| **Over-invoicing tooling** | Tooling invoice > actual die cost; inflated quotation | `[INS]` die maker quotation vs. invoice vs. market rate |
| **Sales commission fraud** | Commissions paid to agents related to customer buyers | `[INS]` commission register; vendor relationship check |

| Test | Evidence | Assertion |
|------|---------|----------|
| **MACC s.17A "adequate procedures"** — ABAC policy; Board adoption; tone from top | `[INS]` ABAC policy + Board minutes approving; `[OBS]` training records | CP |
| Gifts & entertainment register — all >RM500 with approval; Perodua/Denso buyer hospitality | `[INS]` G&E register (full year population) | CP |
| Benford on all invoice populations (sales, purchase, scrap, tooling) | `[ANA]` each population separately | CO, AC |
| Vendor due diligence — SSM check; MACC sanction list for key vendors | `[CON]` SSM search; `[CON]` MACC sanction list | CP, RO |
| Whistleblower channel — functional; Whistleblower Protection Act 2010 | `[INS]` whistleblower policy; `[OBS]` channel operability | CP |

---

### Domain 16 — Governance, ERM & Companies Act 2016
Read: the retired `governance_erm` module (not a separate file in this suite)

| Test | Evidence | Assertion |
|------|---------|----------|
| Board/AC oversight — audit findings tabled quarterly | `[INS]` Board/AC minutes last 4 quarters | CP |
| Risk register — MKPC-specific risks (OEM concentration, Al/steel price, IATF suspension) | `[INS]` risk register; `[REP]` management | CP |
| Companies Act 2016 — annual return within 30 days of AGM; audited FS within 6 months of FY-end | `[CON]` SSM MyData portal | CP |
| Director interests declaration — no conflict with customer/vendor selection | `[INS]` directors' declaration register | CP |
| **Succession/concentration risk** — single OEM >50% revenue (Perodua concentration) | `[ANA]` revenue by customer; quantify Perodua revenue % | AC, VA |

---

### Domain 17 — Benchmark & Comparative Analysis
Read: `references/mkpc-benchmarks.md`

**Die Casting & Stamping Manufacturing KPIs (Malaysia / Asia context):**

| KPI | Formula | Benchmark | Source |
|----|--------|-----------|--------|
| **MTC — Al HPDC** | Good casting kg ÷ Metal input kg | 65–75% | NADCA; industry |
| **MTC — Zn HPDC** | Same | 70–80% | NADCA |
| **Stamping material yield** | Good blank weight ÷ Coil input weight | 70–85% | OEM nesting plan |
| OEE (Overall Equipment Effectiveness) | Availability × Performance × Quality | ≥85% target | World-class 85%; typical MY 70–80% |
| **DPPM (Defective Parts Per Million)** | Defects ÷ Output × 1,000,000 | <50 ppm (Perodua/Denso world-class) | OEM scorecard |
| **OTIF** | On-time in-full deliveries ÷ Total deliveries | ≥98% | OEM requirement |
| Scrap rate | Scrapped units ÷ Produced | <3% die casting; <5% stamping | Industry |
| Cycle time adherence | Actual cycle time ÷ Standard cycle time | ≤1.05 (within 5% of standard) | Internal |
| COGS % of revenue | COGS ÷ Revenue | 65–80% (auto parts MY) | Sector data |
| Gross margin | (Revenue − COGS) ÷ Revenue | 20–35% (auto parts MY) | MAA / sector |
| Debtor days (DSO) | AR × 365 ÷ Revenue | <45 days | Contract |
| Inventory days | Inventory × 365 ÷ COGS | 20–40 days | OEM requirement |
| Tooling capex % of revenue | Tooling spend ÷ Revenue | 5–10% (new model launch years) | Industry |
| EPF compliance rate | On-time contributions ÷ Total months | 100% | Legal |
| Minimum wage compliance | Employees at or above [MY-003] ÷ Total employees | 100% | Legal (see register) |

**OEM Concentration Analysis:**
| Customer | Revenue % | Risk Level |
|---------|----------|-----------|
| Perodua | if >60% | 🔴 High concentration; any Perodua model discontinuation = existential |
| Denso | if >30% | 🟠 Moderate; Denso supply chain changes = significant impact |
| Single OEM >80% | — | 🔴 Critical; COSO ERM enterprise risk |

---

## Step 5 — Report structure

Owned by `gia-report-qa:gia-ia-report` (standard concise report plus Excel working paper). This pack emits a findings register and its supporting tables only; the long-form overall-opinion layout in the retired source is a legacy conversion reference and is not used. Dashboards named in the retired layout (yield, labour compliance, OEM scorecard, benchmarks) are working-paper sheets.

## Step 6 — Excel Audit Workbook Output (MK Tron GIA House Style)

When generating Excel audit workbook for MKPC follow MK Tron GIA house style:
- **Colour palette:** Navy (#002060) headers, Teal (#00B0A8) sub-headers, Midblue (#0070C0) accent
- **Sheets:** Cover | Executive Summary | Priority Matrix | Findings (D1–D17) | Metal Balance Reconciliation | Tooling Register Audit | OEM Billing Reconciliation | Payroll Reconciliation | Scrap Audit | Benchmark Dashboard | Evidence Index | SETTINGS (hidden)
- **Conditional formatting:** 🔴 Critical = red fill, 🟠 High = orange, 🟡 Medium = yellow, 🟢 Low = green
- **Formulas:** Auto-count findings by priority; MTC calculation; OEE; DPPM; DSO; OT exposure
- **GIA Reference format:** GIA-20[YY]-MKPC-D[domain]-[NN] (e.g., GIA-2026-MKPC-D9-01)
- **Population analytics:** digit-distribution analysis via `gia-fraud:gia-fraud-analytics`

---

## Non-Negotiable Validation Standards

| Standard | Rule |
|----------|------|
| **Evidence first** | No finding stated before evidence tag, source, and date documented |
| **Quantify always** | Every finding: MYR/kg/ppm exposure with formula shown; or "Unquantified — [specific reason]" |
| **Cite specifically** | Act + Act number + Section + year; MFRS + paragraph; IATF clause; IIA GIAS 2024 Standard |
| **Tag every test** | `[INS]` `[PHY]` `[CON]` `[REP]` `[REC]` `[OBS]` `[ANA]` — every procedure |
| **Challenge always** | Professional skepticism; corroborate every management explanation |
| **Assumption = disclosure** | Any assumed fact stated prominently in report header |
| **No inference as finding** | "Appears to" / "likely" / "probably" prohibited in finding Condition field |
| **Regulatory calendar** | Always include next 5 filing deadlines relevant to MKPC |
| **IIA 2024 alignment** | All recommendations reference specific IIA GIAS 2024 Standards |
| **OEM validation** | All OEM-related findings cite customer-issued evidence (not MKPC self-report) |
| **Disclaimer** | Every report includes MIA/licensed tax advisor/IATF auditor/DOSH review disclaimer |
| **Benchmark** | Every operational domain compared to published Malaysia/Asia-Pacific industry benchmark |
| **Minimum Wage** | Always use [MY-003]; do not use a superseded figure |
| **EPF foreign workers** | Always check Oct 2025 mandatory contribution change for non-Malaysian employees |
| **SOCSO/EIS ceiling** | Always use [MY-007]; do not use a superseded ceiling |
| **IATF Rules 6th Ed** | Use 15-day NC response (not 20); 12-month exact surveillance interval |
