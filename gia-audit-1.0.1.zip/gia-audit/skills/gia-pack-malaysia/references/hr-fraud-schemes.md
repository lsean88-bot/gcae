> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- ACFE Fraud Tree Classification for HR/Payroll
- Benford's Law Application Guide


# Malaysia HR Audit — Fraud Schemes & Indicators

## ACFE Fraud Tree Classification for HR/Payroll

### Asset Misappropriation — Payroll Schemes

#### 1. Ghost Employees
**Definition:** Fictitious employees added to payroll; wages diverted to perpetrator-controlled account.

**Indicators:**
- Employee in HR master with no biometric/T&A records
- Employee bank account matches another employee's account
- Employee IC number does not match NRD records or is duplicated
- No leave records, no performance review, no disciplinary records
- Address matches payroll administrator or HR manager
- Employee not appearing in EPF/SOCSO portal despite payroll deduction

**Entity overlay:**
- MKPC/Erawan: Ghost foreign workers — permit exists (forged/borrowed), worker absent; headcount on paper meets OEM/DOSH ratio
- Nephrocare: Ghost nurses — appear on CKAPS staffing return but not on shift schedule; PERKESO billing based on ghost headcount

**Benford Test:** Apply 1st digit test to payroll amounts. New ghost employees often have round-number salaries (RM2,000, RM3,000 exactly) — check frequency of terminal digits (trailing zeros).

**Audit procedures:**
1. Extract full HR master vs payroll register vs bank credit file — three-way match
2. Check bank account uniqueness (no two employees share account number)
3. IC number validation against NRD format (YYMMDD-SS-GGGG); check for duplicates
4. Require physical sign-off or biometric verification for all active employees
5. Confirm EPF i-Akaun member records match HR headcount

---

#### 2. OT Manipulation
**Definition:** Fictitious or inflated OT hours recorded; higher OT rates misapplied.

**Indicators:**
- OT hours spike at period-end or before bonus/increment cycles
- T&A system shows clock-out at regular time; payroll shows OT hours
- Supervisors approve their own OT (SoD failure)
- "Production incentive" or "shift allowance" used as OT substitute (below statutory rate)
- OT exceeds EA legal limits with no records of Labour Department exemption

**Entity overlay:**
- MKPC: Shift supervisors approving production-line OT; peak OEM delivery periods
- Nephrocare: Night dialysis sessions; nurses accumulating uncapped OT; no biometric during session changeover
- Erawan: Factory OT near DOSH cylinder test deadlines; pre-shift setup work unrecorded

**Audit procedures:**
1. Reconcile biometric T&A punch records to payroll OT register — week by week for sample months
2. Compute OT hours as % of basic hours; flag employees exceeding 20%
3. Verify weekly hours ≤ 45h + authorised OT; check EA s.60A limit (104h/month max unless Labour Department exemption)
4. Recompute OT pay at statutory multipliers for sample; compare to payroll
5. Review OT authorisation: confirm independent approval (not self-approved)

---

#### 3. Falsified Deductions
**Definition:** Unauthorised payroll deductions (uniform, tools, accommodation in excess of cap, levy) diverted.

**Indicators:**
- Accommodation deduction exceeds gazetted Act 446 cap
- Deduction line labelled "utilities" or "meals" on foreign worker payslips — actual amount exceeds food/utilities value
- Levy cost charged back to foreign worker wages (prohibited)
- Deduction for "training" or "equipment" without written employee consent
- Deduction amounts vary by month without corresponding variation in service/cost

**Entity overlay:**
- MKPC/Erawan: Most common — Act 446 cap breach; levy recovery
- Nephrocare: Uniform deductions for nursing uniforms without consent; training bond deductions

**Audit procedures:**
1. Extract all deduction line items from payroll for foreign workers
2. Map each deduction category to legal authorisation (EA s.24 — permitted deductions only)
3. Compare accommodation deductions to current gazetted cap; flag excess
4. Confirm written consent forms on file for each permitted deduction type
5. Verify no levy deduction in any form (gross or disguised)

---

#### 4. Duplicate Payments
**Definition:** Same employee paid twice in same period; terminated employee continues in payroll.

**Indicators:**
- Same IC/passport number appears in two payroll records
- Terminated employee still receiving salary >1 month after last working day
- Two bank transfers to same account in same payroll run
- Employee appears in both direct payroll and outsourced payroll (double-dipping)

**Audit procedures:**
1. Duplicate IC/passport search across entire payroll master
2. Leaver report: extract all terminations; confirm payroll stopped on last working day
3. Bank file duplicate check: same account, same amount, same period
4. Cross-match in-house payroll vs outsourced/contract labour payroll (MKPC/Erawan)

---

### Corruption Schemes

#### 5. Manpower Agent Kickbacks (MACC s.17A)
**Definition:** Recruitment/manpower agents pay kickbacks to HR/management for contract awards; costs inflated to absorb kickback.

**Indicators:**
- Single-source manpower supplier without competitive tender
- Agent commission rate significantly above market (>5–8% of placed salary)
- Agent is related party to HR Manager or Director (check CTOS/SSM)
- Payments to agent in cash, gift cards, or third-party transfer
- No due diligence file (business registration, beneficial ownership, reference checks)
- Agent contract lacks specific deliverables or performance metrics

**Entity overlay:**
- MKPC/Erawan: Foreign worker recruitment agents (Bangladesh, Indonesia, Nepal sourcing); levy arrangement agents
- Group HQ: Executive search firms; EP facilitation agents

**Audit procedures:**
1. Obtain full vendor master for HR/manpower-related suppliers
2. Check SSM registration and beneficial ownership (MBRS); run related-party checks against HR/management names
3. Review contract terms: scope, rate, exclusivity, payment triggers
4. Trace payments to bank statements; verify no cash/unusual payment method
5. Request MACC s.17A due diligence file: confirm existence and completeness

---

#### 6. EP Salary Fraud
**Definition:** Salary inflated in EP application to meet threshold; actual salary paid is lower; difference via side letter, offshore payment, or allowance structure.

**Indicators:**
- Contract salary (for EP) differs from payslip gross
- EP renewal application shows higher salary than current payslip
- Allowances on payslip that existed at EP approval now reduced or removed
- LHDN EA Form 1 gross income lower than EP application declared salary
- EP category higher than role/salary should warrant

**Audit procedures:**
1. Extract all EP holders; obtain EP approval letters and current payslips
2. Three-way compare: EP declared salary vs contract salary vs payslip gross
3. Cross-check with LHDN EA Form 1 (prior year) for gross income consistency
4. Review EP category vs current salary: Cat I (≥RM10k), Cat II (RM5k–RM9,999), Cat III (RM3k–RM4,999)
5. Flag any downgrade in category or salary post-approval

---

### Financial Statement / Regulatory Schemes

#### 7. Statutory Under-Declaration
**Definition:** EPF/SOCSO/EIS/PCB computed on artificially narrow "wages" base; difference pocketed or used to reduce cost.

**Indicators:**
- Allowances (fixed monthly, productivity) excluded from EPF/SOCSO/EIS base without legal basis
- Two payroll systems — one for statutory purposes (lower), one for actual payment (higher)
- PCB computed on basic only; taxable allowances excluded
- SOCSO ceiling not updated to the current register ceiling [MY-007]

**Audit procedures:**
1. Map all remuneration components to EPF/SOCSO/EIS/PCB "wages" definition
2. Confirm which allowances are excluded (EA Schedule: travelling, meal reimbursement) vs which must be included (fixed productivity bonus, fixed shift allowance)
3. Reperform EPF/SOCSO/EIS/PCB for sample; compare to statutory submission
4. Verify SOCSO ceiling updated to the register ceiling [MY-007] in payroll system configuration

---

## Benford's Law Application Guide

**When to apply:** Benford and digit tests: run through `gia-fraud:gia-fraud-analytics` (Nigrini MAD primary with per-digit z-scores; chi-square supplementary for small populations). Confirm the preconditions (population size, range across orders of magnitude, no assigned or bounded numbers), segment fixed-amount populations first, and record the MAD table version in the workpaper. A deviation is an indicator, never a conclusion. Inline thresholds from the retired source were removed.
Apply to monthly salary amounts, OT amounts, deduction amounts and bank transfer amounts per payroll run.

**Red flags:**
- Excess of digit 1 or 2 in deductions (small unauthorised deductions)
- Excess of digit 9 in OT amounts (just-below-threshold approvals)
- Terminal digit analysis: excess of 0s and 5s (round-number fabrication)
- Departure measured by MAD and per-digit z-scores in the analytics output

**Note:** Benford does not apply to data with fixed amounts (e.g., minimum wage population where all earn the national minimum wage). Segment data first.
