> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- A1 — PHFSA 1998: Clinic Registration, Scope & Hours
- A2 — LCP: Letter of Credentialing and Privileging (Aesthetic Medical Practice)
- A3 — MOH / MMC: Medical Practitioner Registration
- A4 — Drug Control Authority (DCA): Product Registration
- A5 — Atomic Energy Licensing Act 1984 (AELA): X-Ray & Radiation
- A6 — Allied Health Professions Act 2016 (Act 774)
- A7 — Regulatory Calendar: MOH / DCA / AELA / AHPC / LCP


# Reference A — PHFSA / MOH / DCA / AELA / LCP Regulatory Compliance
*Updated May 2026 — incorporates LCP aesthetic credentialing, 2025 court cases, updated penalties*

---

## A1 — PHFSA 1998: Clinic Registration, Scope & Hours

**Law:** Private Healthcare Facilities and Services Act 1998 (Act 586); Private Healthcare Facilities and Services (Private Medical Clinics or Private Dental Clinics) Regulations 2006 P.U.(A) 138/2006

### Clinic Scope Types Under PHFSA Borang B

| Scope Classification | Services Permitted | Key Exclusions |
|---------------------|-------------------|---------------|
| Klinik Perubatan Swasta Umum | GP consultation, basic treatment, immunisation, health screening, wound care, minor procedures | Cell therapy, biologics infusion, specialist-only procedures, aesthetic procedures WITHOUT LCP, surgical procedures, in-patient care |
| Klinik Pakar (Specialist) | Named specialty only; requires named specialist on licence | Outside named specialty |
| Klinik Kesihatan Estetik | Aesthetic procedures with LCP; requires LCP for each procedure category | Invasive surgery; procedures outside LCP scope |

### PHFSA Audit Tests

| Test | Evidence Tag | Assertion | Priority if Failed |
|------|-------------|-----------|-------------------|
| Borang B scope vs POS SalesItems — match services rendered to licensed scope | `[INS]` Borang B + `[REP]` POS | CP, OC | 🔴 Criminal offence PHFSA s.4 |
| Operating hours — POS encounter dates vs Lampiran licensed hours | `[REP]` POS date/time + `[INS]` Lampiran | CP | 🟠 Penalty per [MY-050] |
| Responsible person on Borang B = active, practising at premises | `[CON]` MMC registry + `[INS]` duty roster | CP | 🟠 Reg.5 breach |
| PHFSA annual renewal / valid certificate displayed | `[INS]` renewal acknowledgement or current certificate | CP | 🔴 If expired — illegal operation |
| Physical facility meets Reg.4 minimum standards | `[PHY]` site visit — consultation room, treatment room, emergency resus equipment | CP | 🟠 |
| Change of address or scope notified to MOH | `[INS]` MOH amendment notification record | CP | 🟠 |

### PHFSA Penalties

| Offence | Penalty | Section |
|---------|---------|---------|
| Operating without / outside registration | see [MY-050] | s.4 |
| Breach of registration conditions (hours, scope) | see [MY-050] | s.26 |
| Operating without licence renewal | Same as s.4 | s.27 |
| Rafianee bt A Razak v Dr Suffia Hany bt Mohamad Amin & Ors [2025] MLJU 2234 | Court confirmed: aesthetic practice at unlicensed premises = illegal business | Case law precedent 2025 |

---

## A2 — LCP: Letter of Credentialing and Privileging (Aesthetic Medical Practice)

**Law:** MOH Medical Practice Division — Main Credentialing and Privileging Committee for Aesthetic Medical Practice; MMC Guidelines on the Ethical Aspects of Aesthetic Medical Practice (2023 edition)

**CRITICAL UPDATE (2025):** As of June 2025, **783 GPs** are registered on the National Registry with LCP Chapter 1. Any aesthetic procedure performed by a doctor without LCP is illegal regardless of PHFSA clinic registration.

### LCP Requirements for GPs

| Requirement | Detail |
|-------------|--------|
| MMC full registration + valid APC | Mandatory prerequisite |
| Recognised training courses | MOH-approved courses (MSAM, MAC, Aesthetic Academy Asia) |
| Clinical experience | Minimum 2 years private practice after structured aesthetic training |
| MCQ theory exam + VIVA assessment | Conducted by Main Credentialing & Privileging Committee |
| LCP scope | Each procedure category requires separate LCP (e.g., Botox, fillers, laser — separate LCPs) |
| National Registry registration | MOH Medical Practice Division maintains registry — publicly searchable |
| Renewal | Annual — tied to CPD requirements |

### LCP Audit Tests

| Test | Evidence | Assertion |
|------|----------|-----------|
| All doctors performing aesthetic procedures hold valid LCP for each procedure type | `[CON]` MOH National Registry of Aesthetic Practitioners | CP |
| LCP displayed at clinic premises | `[PHY]` site inspection | CP |
| LCP scope matches procedures offered — each treatment category has LCP | `[INS]` LCP certificate + `[REP]` POS SalesItems | CP |
| LCP renewal current — not expired | `[CON]` MOH registry; `[INS]` LCP certificate expiry | CP |
| Only LCP-holding doctors perform aesthetic procedures (not nurses, beauticians, or non-LCP doctors) | `[REP]` POS Doctor field + `[INS]` staff employment records | CP |

### Case Law — Rafianee v Dr Suffia Hany [2025] MLJU 2234
[case figure moved to example-2026-Q1.md]

---

## A3 — MOH / MMC: Medical Practitioner Registration

**Law:** Medical Act 1971 (Act 50); Malaysian Medical Council (MMC) — www.mmc.gov.my

| Test | Evidence | Risk |
|------|----------|------|
| Valid MMC Annual Practising Certificate (APC) — all doctors | `[CON]` MMC online registry | Practising without APC = Medical Act 1971 s.24 offence |
| Foreign-qualified doctors — full MMC register or NSR | `[CON]` MMC — check practitioner identity number (not recorded here) | NSR practitioners have conditions on practice |
| Specialist doctors practising within registered specialty | `[CON]` MMC specialist register | Scope breach |
| MMC APC displayed at each consultation room | `[PHY]` site inspection | MOH inspection non-compliance |
| No moonlighting government doctors | `[INQ]` + `[INS]` employment contracts | Dual practice offence |

---

## A4 — Drug Control Authority (DCA): Product Registration

**Law:** Control of Drugs and Cosmetics Regulations 1984 P.U.(A) 394/1984; CDCR Amendment 2021; Medicines (Advertisement and Sale) Act 1956

### Products Requiring DCA Registration by Category

| Category | Examples | DCA Registry |
|----------|----------|-------------|
| Biologics / cell therapy | NK cell preparations, stem cell products, PRP, exosome products | bpfk.moh.gov.my/bpfkeprod — search by product name |
| Aesthetic injectables | Botulinum toxin (Botox), hyaluronic acid fillers, collagen boosters | DCA registration mandatory per brand per formulation |
| CBD-based products | CBD oil, CBD topicals | Currently in regulatory grey area — Dangerous Drugs Act 1952 as amended 2017; MOH has not issued blanket exemption for medical use |
| Lasers / devices | IPL, HIFU, RF devices | Medical Device Act 2012 registration via MDA Malaysia |
| Nutraceuticals sold as treatment | Sold as medicine (not food supplement) | DCA registration required if therapeutic claims made |

### DCA Audit Tests

| Test | Evidence | Consequence |
|------|----------|-------------|
| DCA registration number for each dispensed product on Poisons Register | `[CON]` DCA registry search | CDCR 1984 s.12 — penalty per [MY-050] |
| Cell therapy / biologic preparations individually registered | `[CON]` DCA registry | Criminal liability + product seizure |
| Cold chain compliance for biologics (fridge temp log) | `[PHY]` fridge temperature log; min-max thermometer reading | Product efficacy; patient safety |
| Expired products not dispensed | `[PHY]` pharmacy stock check of all expiry dates | Poisons Act + CDCR offence |
| CBD — confirm MOH exemption obtained if dispensing | `[INS]` MOH approval letter | Dangerous Drugs Act 1952 offence if no exemption |

---

## A5 — Atomic Energy Licensing Act 1984 (AELA): X-Ray & Radiation

**Law:** AELA 1984 (Act 304); Radiation Protection (Licensing) Regulations 1986 P.U.(A) 144/1986

### Licence Class Reference

[case figure moved to example-2026-Q1.md]
|-------|-------------|-----------|
[case figure moved to example-2026-Q1.md]

### Required Roles (All Named on Licence)

[case figure moved to example-2026-Q1.md]
|------|---------------------|------|
| Licence Holder | the licence-holding practitioner (SOLE) | If the sole practitioner leaves, licence lapses |
| Radiation Protection Officer (RPO) | the licence-holding practitioner (SOLE) | No backup RPO — X-ray must cease if the sole practitioner unavailable |
| Supervisor | the licence-holding practitioner (SOLE) | Same |
| Radiographers (2 employed) | Individual AELA Class C licence status NOT CONFIRMED | AELA s.9 offence if operating without RPO present or own licence |

### AELA Audit Tests

| Test | Evidence | Consequence |
|------|----------|-------------|
| Licence current, not expired | `[INS]` AELA licence certificate | Operating without licence: RM 100,000 + 5 years |
| Equipment list on licence matches actual premises equipment | `[PHY]` equipment inspection vs Appendix A | Equipment not on licence = unlicensed use |
| RPO qualification valid — LPTA registry | `[CON]` LPTA RPO registry | |
| All X-ray operators individually licensed or under direct RPO supervision | `[INS]` operator licences OR supervision log showing the sole practitioner on-site | AELA s.9 criminal offence |
| Radiation dose monitoring (TLD badge) logs — quarterly | `[INS]` TLD badge records | LPTA compliance |
| X-ray room shielding survey certificate | `[INS]` survey certificate (required at installation + after renovation) | |
| Equipment calibration current (annual) | `[INS]` calibration records | |
| No backup RPO designated | Finding F-18 — CRITICAL | Operational single point of failure |

---

## A6 — Allied Health Professions Act 2016 (Act 774)

**Law:** Allied Health Professions Act 2016; Allied Health Professions (Physiotherapy) Regulations 2021; Allied Health Professions (Radiography) Regulations 2021

[case figure moved to example-2026-Q1.md]
|-----------|-----------------|---------------------|
| Physiotherapist | Allied Health Professions Council (AHPC) | Perfect Physio Sdn Bhd |
[case figure moved to example-2026-Q1.md]
[case figure moved to example-2026-Q1.md]

| Test | Evidence |
|------|----------|
| All physiotherapists — valid AHPC Annual Practising Certificate | `[CON]` AHPC registry |
| All radiographers — valid AHPC APC | `[CON]` AHPC registry |
| AHPC certificates displayed | `[PHY]` site inspection |
| Perfect Physio: 57% vacancy — AHPC ratio for any physiotherapy assistants | `[INS]` headcount + AHPC guidelines |

---

## A7 — Regulatory Calendar: MOH / DCA / AELA / AHPC / LCP

| Obligation | Frequency | Due | Responsible |
|-----------|-----------|-----|-------------|
| PHFSA Borang B renewal | Annual (MOH notice-based) | Per MOH notification | CEO/Ops |
| MMC APC renewal — all doctors | Annual | 31 December each year | Medical Director |
| LCP renewal — aesthetic practitioners | Annual (tied to CPD) | Per LCP expiry | Each practitioner |
| AHPC APC — allied health | Annual | Per profession | HR Manager |
| AELA X-ray licence renewal | Per licence term (3 years) | 07 Dec 2028 (current) | RPO |
| AELA TLD badge reading | Quarterly | Every 3 months | RPO |
| DCA product registration renewal | Per product | Per DCA registry | Pharmacy |
| MOH adverse event reporting | Within 24 hours of serious event | Immediate | Medical Director |
| PHFSA operating hours change | Before change | Immediate | CEO |
| Medicine price display compliance | Per order status | Monitor High Court JR disposal (ongoing 2026) | CEO/Ops |
