> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- Fraud Risk Framework
- Fraud Scheme Inventory — Dialysis Specific
- Benford's Law Application Guide
- MACC s.17A — Corporate Liability Checklist


# Healthcare Fraud Audit Reference — Malaysian Dialysis Operations

## Fraud Risk Framework

Standards applied: ACFE Fraud Tree (2024); IIA GIAS 2024 Standard 13.2 (Fraud Risk);
MACC Act 2009; PHFSA 1998; BNM AML/CFT Guidelines

---

## Fraud Scheme Inventory — Dialysis Specific

### Category A: Treatment Fraud (Revenue / Billing)

#### A1 — Phantom Treatments
**Definition:** Billing for dialysis sessions never performed.

**Detection tests:**
1. Cross-match: FMC Purchase Order treatments vs patient attendance register vs nursing notes vs machine session counter
2. If PO quantity > patient attendance: phantom risk
3. Machine hour log: each 4-hour session adds ~4 hours; total session hours ÷ 4 = theoretical treatments; compare to PO count
4. Check for treatments recorded on public holidays when centre is closed
5. Verify PERKESO claims: patient must have received treatment on claimed date

**Evidence required:** `[INS]` machine log + `[INS]` patient attendance + `[INS]` nursing notes + `[CON]` PERKESO claim
**Quantification:** Number of phantom treatments × PPT rate (RM 56 or RM 42.75)

#### A2 — Treatment Count Inflation
**Definition:** Machine logs or attendance records falsified upward to meet PPT commitment.

**Detection tests:**
1. Compare machine session counter (hardware-embedded) vs paper/system log
2. Unusual patterns: exactly meeting Monthly Treatment Commitment every month (Benford analysis)
3. Review nursing notes for corresponding clinical entries per session
4. Patient census: maximum treatments = patients × shifts × days per month

**Formula check:** Max possible treatments = Patients × 3 sessions/week × 4.33 weeks/month
If reported treatments > this figure: impossible → 🔴

#### A3 — PERKESO Dual Billing
**Definition:** Same treatment session billed to PERKESO and also charged to patient.

**Detection tests:**
1. Cross-match patient ID + date: PERKESO claims vs private billing ledger
2. Any match on same patient/same date = dual-billing
3. `[CON]` PERKESO portal: download all claims by patient ID; `[INS]` private billing system: extract by patient ID + date

**Criteria:** PERKESO panel agreement prohibits additional charges to patients for panel-covered services

#### A4 — Upcoding
**Definition:** Billing for higher-acuity ancillary services not delivered (e.g., billing Haemodiafiltrration when standard HD delivered).

**Detection tests:**
1. `[INS]` patient prescription / doctor's order vs billing code
2. Sample of 25 patients: verify dialysis modality on prescription matches modality billed

---

### Category B: Consumable Fraud

#### B1 — Dialyser Reuse Falsification
**Definition:** Recording fewer reuses than actually performed (to justify ordering more dialysers from FMC) or recording more reuses than allowed.

**Detection — under-recording reuses (ordering more dialysers):**
1. Theoretical consumption: Treatments ÷ 10 = dialysers needed
2. Actual GRN quantity from FMC: if GRN >> theoretical: surplus not accounted for
3. Physical count of dialysers in stock vs theoretical on-hand balance
4. Reuse register per machine, per patient: total reuse tags vs treatments

**Detection — over-recording reuses (using beyond 9 reuses):**
1. Reuse register: flag any dialyser used >9 times
2. Patient safety risk — escalate to clinical governance

**Quantification:** Excess dialysers ordered × RM cost per unit (from PPT schedule)

#### B2 — Consumable Diversion
**Definition:** Consumables received from FMC but diverted for resale or personal use.

**Detection tests:**
1. Full inventory reconciliation: Opening stock + FMC GRN receipts − theoretical usage = closing balance
2. If closing balance significantly exceeds physical count: diversion risk
3. Physical count at ≥3 centres with advance notice suppressed
4. Market check: dialysis consumables resale market (Grey market / informal)

**Formula:**
```
Theoretical Closing Stock = Opening Stock + GRN Receipts − (Treatments × Consumption Ratio)
Variance = Physical Count − Theoretical Closing Stock
If Variance < −[materiality threshold]: investigate diversion
```

#### B3 — Unapproved Supplier Purchases
**Definition:** Purchasing consumables from non-FMC suppliers without approval, in breach of PPT exclusivity (PPT Clause 6.1(v) and Citrosteril / Diasafe specific requirements).

**Detection:** Supplier list vs FMC as sole approved supplier; `[INS]` payment records for any consumable-type purchase from non-FMC vendor

---

### Category C: Cash Diversion

#### C1 — Cash Receipt Diversion
**Definition:** Cash payments from patients not deposited into company bank account.

**Detection tests:**
1. Official receipt sequence — print / number continuity; no gaps
2. Daily cash collection report vs bank deposit (same-day or next-day)
3. Missing receipts: `[INS]` receipt book stubs vs issued receipts
4. Surprise cash count at each centre vs daily collection report
5. Benford's Law on daily cash deposit amounts

**Key control:** Segregation of duties: receipt issuer ≠ deposit maker ≠ bank reconciliation preparer

#### C2 — Petty Cash Abuse
**Detection:** Petty cash log vs supporting vouchers; top-up frequency; cash balance vs log balance

---

### Category D: Referral / Kickback Fraud

#### D1 — Nephrologist Referral Kickbacks
**Definition:** Payments to nephrologists or GPs disguised as "consultancy" or "medical director" fees in exchange for patient referrals.

**MACC s.17A exposure:** Company liability if gratification paid through business entity.

**Detection tests:**
1. `[INS]` all consultancy / medical director agreements — payment basis vs expected referral volumes
2. `[ANA]` correlation: monthly payment to named doctor vs patient referral volume from that doctor
3. Compare consultancy fee rates to market (MOH/MMA published guidance)
4. `[INS]` board approval for all consultancy arrangements

**Red flags:**
- Consultancy fees paid monthly without documented deliverables
- Doctor billing for "advisory" services but no advisory output on file
- Payment increases aligned with patient census increases from that doctor

---

### Category E: Employee Fraud

#### E1 — Ghost Employees
**Detection:** 4-way headcount reconciliation (EPF vs SOCSO vs payroll vs HR roster); bank account duplication analysis; physical verification against staff rota

#### E2 — Payroll Manipulation
**Detection:** Overtime inflation; salary band analysis (Benford on net salary); comparison to approved salary structure

---

## Benford's Law Application Guide

**Applicable data sets:** Benford and digit tests: run through `gia-fraud:gia-fraud-analytics` (Nigrini MAD primary with per-digit z-scores; chi-square supplementary for small populations). Confirm the preconditions (population size, range across orders of magnitude, no assigned or bounded numbers), segment fixed-amount populations first, and record the MAD table version in the workpaper. A deviation is an indicator, never a conclusion. Inline thresholds from the retired source were removed.

| Data set | Indicator if the distribution departs |
|---|---|
| PERKESO claim amounts | Clustering just below approval thresholds |
| Cash receipts per day | Excess 9s or excess 1s |
| Consumable invoice amounts | Excess 9s or amounts just below the PO limit |
| Payroll net amounts | Departure warrants investigation (segment fixed-amount groups first) |
| Daily bank deposits | Consistent below-threshold deposits |
| Daily treatment count per centre | Bounded count: not suitable for a first-digit test; review for implausible uniformity instead |

---

## MACC s.17A — Corporate Liability Checklist

Six Adequate Procedures Pillars (as per MACC Guidelines 2019):
1. **Top level commitment** — board resolution on anti-bribery commitment
2. **Risk assessment** — documented anti-bribery risk assessment
3. **Undertaking and due diligence** — on all third-party business associates
4. **Communication and training** — ABAC training records
5. **Monitoring and review** — periodic ABAC audit
6. **Reporting and investigation** — whistleblower channel; investigation policy

**Dialysis-specific MACC risks:**
- Referral payments to doctors / GPs
- PERKESO panel application facilitation payments
- CKAPS licence facilitation
- Procurement favouritism (non-FMC consumables, renovation contracts)
- Payments to government-linked entities (PERKESO, MOH-linked entities)

**Penalty (MACC s.17A):** see [MY-053]
