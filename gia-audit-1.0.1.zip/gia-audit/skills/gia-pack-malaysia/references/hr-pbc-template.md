> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- Section A — HR Master & Headcount
- Section B — Employment Contracts & Policies
- Section C — Payroll
- Section D — Statutory Submissions
- Section E — Working Time & Attendance
- Section F — Foreign Workers (MKPC / Erawan)
- Section G — Expatriates (Group HQ / Senior Management)
- Section H — Terminations & Disciplinary
- Section I — Governance


# Malaysia HR Audit — PBC (Prepared by Client) Request Template

**Engagement:** Malaysia HR & Payroll Audit  
**Entity:** [MKPC / Nephrocare / Erawan / Group — specify]  
**Audit Period:** [dd MMM yyyy – dd MMM yyyy]  
**PBC Requested By:** Group Internal Audit  
**Due Date:** [date — recommend 10 working days from engagement open]

---

## Section A — HR Master & Headcount

| Ref | Document Required | Format | Priority |
|-----|-----------------|--------|----------|
| A1 | Full HR master data extract as at period end: Employee ID, Name, IC/Passport, Nationality, Job Title, Department, Employment Type (permanent/fixed-term/contract), Join Date, Basic Salary, EPF category, SOCSO/EIS status | Excel | HIGH |
| A2 | Headcount movement report for audit period: new hires, transfers, promotions, terminations — with effective dates | Excel | HIGH |
| A3 | Organisational chart (group-level and entity-level) | PDF/PPT | MEDIUM |
| A4 | Foreign worker register: Name, Nationality, Passport No, VP(TE) No, Permit Expiry, Sector, Employer Name on Permit, Work Location | Excel | HIGH (MKPC/Erawan) |
| A5 | Expatriate register: Name, Nationality, EP Category, EP No, EP Expiry, Declared Salary on EP Application, Current Basic Salary | Excel | HIGH (Group HQ) |
| A6 | Contract/outsourced labour register: Supplier name, contract period, number of workers, roles, SSM registration no | Excel | HIGH (MKPC/Erawan) |

---

## Section B — Employment Contracts & Policies

| Ref | Document Required | Format | Priority |
|-----|-----------------|--------|----------|
| B1 | Sample employment contracts (10 samples across: local permanent, fixed-term, foreign worker, EP holder) | PDF | HIGH |
| B2 | Current HR/Employee Handbook (latest version with version date) | PDF | HIGH |
| B3 | Offer letter templates currently in use | Word/PDF | MEDIUM |
| B4 | Any side letters or supplemental agreements for EP holders | PDF | HIGH |

---

## Section C — Payroll

| Ref | Document Required | Format | Priority |
|-----|-----------------|--------|----------|
| C1 | Monthly payroll registers for entire audit period (all months) | Excel | HIGH |
| C2 | Bank payment files / bank credit advice for each payroll run | Excel/PDF | HIGH |
| C3 | Payslip samples (20 samples: across job grades, including foreign workers and EP holders) | PDF | HIGH |
| C4 | Payroll remuneration structure: breakdown of all pay components (basic, allowances, OT, bonuses, deductions) and their EPF/SOCSO/EIS/PCB treatment | Excel | HIGH |
| C5 | List of off-cycle/manual payments made during audit period with approval documentation | Excel | MEDIUM |
| C6 | Payroll system configuration: EPF/SOCSO/EIS contribution rates and tables currently loaded; PCB table version | Screenshot/PDF | HIGH |

---

## Section D — Statutory Submissions

| Ref | Document Required | Format | Priority |
|-----|-----------------|--------|----------|
| D1 | EPF remittance receipts / i-Akaun payment confirmations for all months in audit period | PDF | HIGH |
| D2 | SOCSO/EIS ASSIST portal payment confirmations for all months | PDF | HIGH |
| D3 | LHDN PCB/MTD payment receipts (CP39 / e-PCB) for all months | PDF | HIGH |
| D4 | EPF Borang A (contribution statements) for 3 sample months | PDF | MEDIUM |
| D5 | LHDN EA Forms (prior year) for sample of 10 employees | PDF | MEDIUM |

---

## Section E — Working Time & Attendance

| Ref | Document Required | Format | Priority |
|-----|-----------------|--------|----------|
| E1 | T&A system extract for audit period: punch-in/punch-out records by employee by day | Excel | HIGH |
| E2 | OT authorisation forms / approval records for sample months | PDF/Excel | HIGH |
| E3 | Shift schedule / roster for production staff (MKPC/Erawan/Nephrocare) | Excel/PDF | HIGH (entity-specific) |
| E4 | Leave records: annual leave, sick leave, maternity/paternity — balance and transaction report | Excel | MEDIUM |
| E5 | Public holiday calendar applied for audit period | PDF | MEDIUM |

---

## Section F — Foreign Workers (MKPC / Erawan)

| Ref | Document Required | Format | Priority |
|-----|-----------------|--------|----------|
| F1 | Copies of VP(TE) permits for all foreign workers currently employed | PDF (scanned) | HIGH |
| F2 | Immigration levy payment receipts for audit period | PDF | HIGH |
| F3 | Foreign worker accommodation details: address, MoHR registration certificate, capacity, current headcount | PDF | HIGH |
| F4 | Accommodation deduction schedule and consent forms on file | PDF/Excel | HIGH |
| F5 | Manpower agent contracts and payment records for recruitment of foreign workers | PDF | HIGH |

---

## Section G — Expatriates (Group HQ / Senior Management)

| Ref | Document Required | Format | Priority |
|-----|-----------------|--------|----------|
| G1 | EP approval letters for all current EP holders | PDF | HIGH |
| G2 | ESD/MyExpat submission records for EP applications/renewals during audit period | PDF | HIGH |
| G3 | Shadow payroll or home-country payroll arrangements (if any) | PDF/Excel | HIGH |

---

## Section H — Terminations & Disciplinary

| Ref | Document Required | Format | Priority |
|-----|-----------------|--------|----------|
| H1 | Termination list for audit period: name, reason, last working day, notice/PILON details | Excel | HIGH |
| H2 | Domestic inquiry records for disciplinary terminations (minutes, findings, outcome) | PDF | HIGH |
| H3 | Resignation letters and acceptance acknowledgements | PDF | MEDIUM |
| H4 | Retrenchment notices (if any): MOHR notification, selection criteria, Termination Benefits calculations | PDF | HIGH (if applicable) |
| H5 | Settlement agreements executed during audit period | PDF | HIGH (if applicable) |

---

## Section I — Governance

| Ref | Document Required | Format | Priority |
|-----|-----------------|--------|----------|
| I1 | HR organisation chart with names and roles (HR, Payroll, Finance approval roles) | PDF | MEDIUM |
| I2 | System access rights: who has access to HR master data, payroll processing, bank payment approval | Excel/Screenshot | HIGH |
| I3 | Maker-checker / approval workflow documentation for payroll processing | PDF | MEDIUM |
| I4 | PDPA data mapping / personal data inventory for HR data (if available) | PDF | MEDIUM (Group HQ) |
| I5 | MACC s.17A compliance programme documentation | PDF | HIGH (Group HQ) |

---

**Note to Management:**  
All documents should cover the audit period stated above. Where a document is not available or does not exist, please advise in writing with explanation. Unavailability of key documents (e.g., domestic inquiry minutes, permit copies) will be noted as an audit finding.
