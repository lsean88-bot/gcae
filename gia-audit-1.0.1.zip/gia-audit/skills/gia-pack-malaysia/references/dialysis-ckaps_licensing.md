> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.

# CKAPS / MOH Licensing Reference — Malaysian Haemodialysis Centres

## Governing Legislation

| Statute | Key Provisions |
|---------|---------------|
| **Private Healthcare Facilities and Services Act 1998 (PHFSA 1998)** | s.6: Licence required for all private healthcare facilities; s.13: Conditions of licence; s.19: Revocation/suspension |
| **Private Healthcare Facilities and Services Regulations 2006** | Third Schedule: Minimum standards for haemodialysis centres; Part IV: Staffing requirements |
| **Medical Act 1971** | s.12: Registration of medical practitioners; s.13A: Specialist registration; s.29: Prohibited practice without registration |
| **Nurses Act 1950 (revised 1981)** | s.8: Nursing Board registration requirement; s.21: Offences |
| **Allied Health Professions Act 2016** | Registration of medical laboratory technologists, physiotherapists |

## CKAPS — Private Medical Practice Control Section

**Portal:** `sppkk.moh.gov.my` (eSPKKS online system)

### Licence Types for Dialysis Centres

| Licence | Issued By | Period | Notes |
|---------|----------|--------|-------|
| Certificate of Registration (premise) | CKAPS | 1 year renewable | Per physical location |
| Licence to operate (haemodialysis centre) | CKAPS | 1 year renewable | Per centre per approved speciality |
| Specialist registration | MMC / CKAPS | 1 year renewable | Named nephrologist per centre |

### Minimum Standards (Third Schedule, Regulations 2006)

**Staffing Ratios (MOH Haemodialysis Centre Guidelines, current edition):**
- Minimum 1 registered nurse per 4 dialysis machines (on each shift)
- Senior nurse / In-charge nurse must hold at least 1 year dialysis clinical experience
- Nephrologist — at minimum 1 registered nephrologist responsible per centre; sessional arrangements acceptable if documented with CKAPS

**Facility Requirements:**
- Minimum floor area per machine: 7.5 m² (Treatment area)
- Dedicated RO water treatment room
- Isolation station(s) for Hepatitis B positive patients (physically separated)
- Clean and dirty utility areas separated
- Adequate ventilation and infection control per MOH Environmental Health guidelines
- Emergency resuscitation equipment (crash cart, defibrillator, oxygen)

**Water Quality Standards:**
- RO water quality test: minimum every 6 months; per AAMI/ISO 23500 standards
- Maximum bacterial count: <100 CFU/mL (treated water); <200 CFU/mL (dialysate)
- Endotoxin: <0.25 EU/mL
- Chemical contaminants: per ISO 23500-3 Table 1

**Machine Specifications:**
- Each machine must have Diasafe Plus filter (per FMC requirement, also best practice)
- Machine maintenance log must be maintained on-site

### CKAPS Pre-Approval for New Centres (Expansion)

**Process sequence — mandatory:**
1. Submit Form A (Planning Intent) to CKAPS — building plan approval
2. CKAPS building inspection and fire certificate (BOMBA)
3. Application for Licence (Form B) — minimum 3 months before opening
4. CKAPS inspection — staffing, equipment, RO system, isolation
5. Certificate of Registration issued
6. Operational — first patient treatment

**Audit alert:** Any centre opened before Certificate of Registration = immediate 🔴 finding

### Medical Waste Management

- Scheduled Waste — governed by Environmental Quality (Scheduled Wastes) Regulations 2005
- Waste contractors must hold DOE licence (Kualiti Alam Sdn Bhd or licensed alternatives)
- Consignment note (scheduled waste manifest) must accompany every collection
- Audit: `[INS]` waste manifests last 12 months vs collection frequency

### Key Penalties Under PHFSA 1998

- Operating without licence (s.6): penalty per [MY-050]
- Failure to comply with conditions (s.13): penalty per [MY-050]
- False information to CKAPS: penalty per [MY-050]

### Audit Evidence for CKAPS Domain

**Priority evidence sequence:**
1. `[CON]` — verify licence on eSPKKS portal (independent, not management-supplied)
2. `[INS]` — physical licence certificate at each centre
3. `[OBS]` — site visit: nurse count, machine count, isolation room, RO room
4. `[INS]` — staff qualification file: MMC, Nursing Board, specialist registration
5. `[INS]` — RO water test certificates (last 2 test cycles)
6. `[INS]` — machine maintenance log

**Red flags requiring escalation:**
- Licence name / address does not match operating centre
- Licence expired or lapsed
- Named specialist no longer practicing at that centre
- Nurse count below 1:4 ratio observed on site visit
- No isolation station for Hep B patients
- RO test overdue
