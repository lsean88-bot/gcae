> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- Revenue Streams by Centre Type
- Billing Completeness — Key Controls
- MFRS 15 Revenue Recognition — Dialysis Context
- Debtor Management & MFRS 9 ECL
- PERKESO vs Non-PERKESO Centre — Revenue Risk Matrix


# Revenue Cycle Reference — Malaysian Dialysis Operations

## Revenue Streams by Centre Type

### PERKESO Panel Centres
**Payer:** Social Security Organisation (PERKESO/SOCSO)
**Eligibility:** PERKESO-insured workers with chronic kidney disease requiring regular haemodialysis
**Billing basis:** Fee-for-service per dialysis session — per approved PERKESO tariff
**Current PERKESO dialysis tariff:** Verify current rate at `perkeso.gov.my` — rates vary by panel agreement and negotiation; approximate range RM 60–RM 90 per session (verify against actual panel contract)
**Sessions per week per patient:** Maximum 3 sessions per week (standard ESRD protocol)
**Claim submission:** Via PERKESO online claim system — submit within stipulated period after service
**Payment timeline:** Typically 45–90 days after submission (government payer)
**Bad debt risk:** Very low — government guaranteed

**PERKESO billing controls required:**
1. Patient eligibility verified at each visit (PERKESO member status, contribution current)
2. Claim submitted per session (not bundled unless PERKESO allows monthly summary)
3. Rejected claims: resubmission within PERKESO's allowable correction period
4. Reconciliation: PERKESO portal approved claims vs billing ledger vs collections

### Non-PERKESO / Private-Pay Centres
**Payers:** Self-pay patients; private medical insurance; corporate/employer TPA; Skim Kesihatan Pekerja (SKP) or other government schemes; foreign patients / medical tourism

**Billing basis:** Centre's own fee schedule; per session rate + ancillary charges
**Typical private dialysis rate:** RM 150–RM 350 per session (varies by centre, location, services)
**Credit terms:** Self-pay — payment at time of service or on account
**Insurance/TPA:** Billed post-service; paid within 30–60 days per panel contract

---

## Billing Completeness — Key Controls

### Treatment-to-Bill Reconciliation

```
Step 1: Obtain machine session log (or TDMS export) for the period
Step 2: Obtain patient attendance register for the same period
Step 3: Obtain billing system extract — all invoices raised
Step 4: Reconcile:
  Machine sessions logged         ___
  Patient sessions recorded       ___
  Invoices issued                 ___
  Discrepancy (any pair):         ___
  If billing < machine sessions: UNDER-BILLING risk (revenue leakage)
  If billing > machine sessions: OVER-BILLING / phantom risk (fraud)
```

### Cash Collection Controls

**Required controls (segregation of duties):**
| Activity | Should NOT be same person |
|----------|--------------------------|
| Issue official receipt | Bank deposit |
| Count daily cash | Post to AR ledger |
| Prepare bank reconciliation | Handle cash receipts |
| Approve credit notes / waivers | Prepare billing |

**Official receipt control:**
- Pre-numbered, sequentially issued
- All copies accounted for (original to patient, duplicate to accounts)
- Cancelled receipts: both copies retained, voided
- `[INS]` receipt book stubs: no gaps in sequence

**Daily cash reconciliation:**
```
Official receipts issued (cash only)    RM ___
Less: Official receipts voided          RM ___
Net cash collected per receipts         RM ___
Physical cash counted                   RM ___
Variance                                RM ___  [Must = 0; any positive = collection gap]
Bank deposit (same or next day)         RM ___
Variance (collected vs deposited)       RM ___  [Must = 0; any positive = diversion risk]
```

---

## MFRS 15 Revenue Recognition — Dialysis Context

**Performance obligation:** Delivery of one dialysis treatment session
**Point of recognition:** When treatment is completed (point-in-time, not over time)
**Variable consideration:** If PPT agreement has shortfall penalties — evaluate constrained revenue
**Deferred revenue scenarios:**
- Pre-paid treatment packages (if sold): recognise per session delivered
- Treatments purchased under PPT PO but not yet delivered: deferred at FMC level; at customer (Nephrocare) level — expense when treatment delivered to patient

**Disclosure requirement:** Revenue disaggregated by:
- PERKESO
- Private / self-pay
- Insurance / TPA
- Medical tourism
- Per centre (management accounts)

---

## Debtor Management & MFRS 9 ECL

### PERKESO Receivables
**Credit risk:** Very low (government guaranteed)
**ECL approach:** Simplified approach — historical loss rate on government receivables (typically < 0.5%)
**Audit test:** `[CON]` PERKESO portal: approved claims in transit = valid receivable; rejected claims = impaired immediately

### Private / Self-Pay Receivables
**Credit risk:** Medium-High (individual patient ability to pay)
**ECL approach:** Provision matrix by aging bucket

| Aging Bucket | Historical Loss Rate (Healthcare — Malaysia) |
|-------------|---------------------------------------------|
| Current (0–30 days) | 2%–5% |
| 31–60 days | 10%–15% |
| 61–90 days | 25%–35% |
| 91–180 days | 50%–60% |
| > 180 days | 80%–100% |

**Write-off policy:** Document approval authority; board approval for amounts > threshold
**Recoveries:** Track post-write-off recoveries separately

### Insurance / TPA Receivables
**Credit risk:** Low (licensed insurance companies, regulated TPAs)
**ECL approach:** Based on historical dispute/rejection rate; typically 1%–3% provision

---

## PERKESO vs Non-PERKESO Centre — Revenue Risk Matrix

| Risk | PERKESO Centre | Non-PERKESO Centre |
|------|---------------|-------------------|
| Billing error — claim rejection | Medium (reversible) | Low (self-billing) |
| Bad debt | Very Low | Medium–High |
| Cash diversion | Low (mostly non-cash) | HIGH (cash-heavy) |
| Revenue leakage (unbilled sessions) | Medium | Medium |
| Dual billing | HIGH (PERKESO + patient) | N/A |
| Tariff compliance | HIGH (must match PERKESO rate) | Self-determined |
| Audit trail | Stronger (PERKESO portal) | Dependent on internal controls |
| Dependency risk | HIGH (if PERKESO contract terminated) | Lower diversification |
