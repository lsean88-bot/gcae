> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.

# DOSH & Gas Cylinder Safety Regulatory Reference — Erawan Malaysia

## Primary Legal Framework

| Law/Guideline | Authority | Key Provision |
|--------------|-----------|--------------|
| Occupational Safety & Health Act 1994 (OSHA, Act 514) as amended by Act A1648 (2022) | DOSH | Overall workplace OSH obligation; penalty per [MY-048] |
| Factories & Machinery (Repeal) Act 2022 (Act 835) | DOSH | Repeals F&M Act 1967; machinery/pressure vessel rules now under OSH framework |
| Petroleum (Safety Measures) Act 1984 (Act 302) | DOSH | Governs petroleum gas storage & handling in non-factory premises |
| Gas Supply Act 1993 (Act 501) | Suruhanjaya Tenaga (ST) | Governs reticulation/supply of piped gas; exempts factory internal gas under F&M Act (now OSH) |
| **DOSH Guidelines for Industrial Gas Cylinder (Design, Construction, Handling, Inspection and Testing) 2021** | DOSH | Primary standard for Erawan's manufactured cylinders |
| **DOSH Guideline — Pengurusan Keselamatan Silinder Domestik GPC 2023** | DOSH | For LPG cylinders specifically |

## Cylinder Manufacturing Standards

### SIRIM/MS Standards (verify current at `sirim.my`)
| Standard | Application |
|----------|-----------|
| MS 830 | Steel welded cylinders for LPG |
| MS 1057 | Seamless steel cylinders |
| MS EN 1442 | LPG cylinders — transportable refillable cylinders; design, construction, inspection |
| ISO 9809-1 / ISO 9809-3 | Seamless steel cylinders (high pressure — O₂, N₂, CO₂) |
| ISO 11118 | Non-refillable metallic cylinders |
| ISO 4706 | Refillable welded steel cylinders — LPG |

Erawan must hold **SIRIM type approval certificate** for each cylinder type manufactured. SIRIM approval must be renewed per SIRIM requirements.

## Hydrostatic Testing — 5-Year Mandatory Cycle

### Requirements (DOSH Guidelines for Industrial Gas Cylinder 2021)
- **Every cylinder must be hydrostatically tested every 5 years** from date of manufacture and from each subsequent test date
- Test must be performed by **DOSH-authorized competent person / authorized inspector**
- Test pressure: typically 5/3 × working pressure (varies by gas type and standard)
- Pass criteria: No permanent expansion >10% of total expansion; no leaks; no visible defects
- Marking: Date of test (month/year) stamped on cylinder neck ring or collar
- Cylinder that fails → condemned; must be decommissioned and destroyed (not re-used)

### Audit Approach
1. `[PHY]` physically inspect sample cylinders: read neck ring stamping → compare to test register
2. `[INS]` full cylinder serial number register → `[ANA]` calculate test due date for every cylinder (test date + 5 years)
3. Flag all cylinders where (last test date + 5 years) < audit date = **overdue — immediate 🔴 finding**
4. Verify authorized inspector's DOSH appointment letter is current

## OSH Act Obligations for Erawan (Manufacturing Facility)

| Obligation | Legal Basis | Frequency |
|-----------|-----------|---------|
| Safety & Health Policy — signed by MD | OSHA s.16 | Annual review |
| Safety & Health Committee (≥40 employees) | OSHA s.30 | Monthly meetings |
| OSH Coordinator (≥5 employees — Act A1648) | OSHA Amendment 2022 | Standing appointment |
| CHRA (Chemical Health Risk Assessment) | OSHA (Use & Standards of Exposure of Chemicals Hazardous to Health Regs 2000) | Every 5 years (or on change) |
| NRA (Noise Risk Assessment) | OSH (Noise Exposure) Regs 2019 | When noise exposure suspected |
| Accident reporting to DOSH (Form 7 / JKKP 6) | OSHA s.32 | Within 7 days of accident |
| DOSH registration of pressure vessels | F&M Act / OSH equivalent | Before commissioning |
| Machinery permit (filling equipment, compressors) | OSH Regs | Before operation |

## Common DOSH Violations (High Audit Risk)
- 🔴 Cylinders overdue for hydrostatic testing (>5 years since last test) — safety & regulatory breach
- 🔴 Cylinders filled without valid DOSH registration → criminal liability
- 🔴 No CHRA for chemicals used (paints, rust inhibitors, test media) → OSHA violation
- 🟠 No OSH Coordinator appointed (post 2022 amendment)
- 🟠 SIRIM type approval expired → cylinders manufactured without valid approval
- 🟠 Accident not reported to DOSH within 7 days

## Quantification
- OSHA fine: per [MY-048] (Act A1648 amended rates)
- Product liability: defective cylinder causing injury → Companies Act 2016 + Tortious liability
- DOSH stop-work order: immediate business interruption — quantify lost production per day
