> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- Corporate Income Tax (ITA 1967)
- SST — Service Tax (Healthcare Exemption)
- Capital Allowance on Medical Equipment
- Transfer Pricing (TP)
- Withholding Tax (ITA 1967 s.109)
- Stamp Duty (Stamp Act 1949)
- RPGT — Real Property Gains Tax (RPGT Act 1976)
- Malaysian Tax Compliance Calendar (Healthcare Company)


# Malaysia Tax Reference — Healthcare & Dialysis Companies

## Corporate Income Tax (ITA 1967)

| Item | Rate / Rule |
|------|------------|
| Standard corporate tax rate | per [MY-037] (ITA 1967 s.2; Schedule 1) |
| SME rate (paid-up capital and group-control conditions as stated in the register) | per [MY-037] (conflict MY-C15) |
| Estimated Tax Payable (CP204) | Filed by Day 30 before FY commencement; 12 monthly instalments |
| CP204A revision | Months 6 and 9 — optional upward/downward revision |
| Annual return filing (Form C) | 7 months after FYE |
| Tax payment | 7 months after FYE (balance after CP204 instalments) |
| Penalty — late CP204 | per [MY-041] |
| Penalty — late return | per [MY-041] |

---

## SST — Service Tax (Healthcare Exemption)

**Healthcare services — SST EXEMPT** under:
- Service Tax (Exemption) Order 2018, First Schedule — healthcare services provided by registered healthcare facilities are exempt from Service Tax

**This means:** Dialysis treatment fees charged to patients are **NOT subject to SST ([MY-032])**

**Audit test:** Verify no SST charged on dialysis billing — if SST has been collected, must be remitted; if not remitted, RMCD exposure

**Consumables imported from FMC (German origin):** May be subject to import duties and/or SST on goods — verify with customs classification of each consumable line item

---

## Capital Allowance on Medical Equipment

**ITA 1967, Schedule 3:**
| Allowance | Rate | Asset |
|-----------|------|-------|
| Initial Allowance (IA) | 20% on cost (Year 1) | Plant and machinery |
| Annual Allowance (AA) | 14% per year (standard) | Plant and machinery |
| Annual Allowance — medical equipment | 20% per year (accelerated) | Per gazette notification; verify with LHDN |
| Residual Expenditure | Cost − IA − cumulative AA | Balance sheet carrying amount |
| Balancing Allowance / Charge | On disposal | Disposal value vs residual expenditure |

**Note:** FMC-supplied machines under PPT agreement are LEASED, not owned by Nephrocare. No capital allowance claimed by Nephrocare on FMC machines.
**Nephrocare's capital allowance claims:** Restricted to assets actually owned (fit-out, RO systems if purchased, TDMS if purchased, medical equipment under direct ownership)

---

## Transfer Pricing (TP)

**Relevant only if:** Related-party transactions with FMC or related parties above TP documentation threshold

**ITA 1967 s.140A + Transfer Pricing Rules 2012:**
- Arm's length principle applies to all cross-border related-party transactions
- TP documentation required above the threshold in [MY-039]
- Contemporaneous documentation must be maintained in place by the time tax return is filed
- Penalty for non-compliance: per [MY-039]

**Transactions to review for TP:**
1. PPT payments to FMC (Germany-related entity)
2. Management fees charged by parent/shareholder entities
3. Shared services charged between group entities
4. Intercompany loans — interest rate arm's length test

---

## Withholding Tax (ITA 1967 s.109)

| Transaction | WHT Rate | Payee |
|------------|---------|-------|
| Royalties to non-resident | 10% | FMC if IP licensed |
| Technical / management services to non-resident | 10% | Any non-resident service provider |
| Interest to non-resident | 15% | FMC or foreign lender |
| Contract payments (construction/installation) | 10% (individual) / 3% (company) | Foreign contractor on-site |

**Trigger for Nephrocare:** FMC invoices for PPT — likely NOT WHT if categorised as goods supply/lease
But: If any element of FMC invoice is re-characterised as service/royalty → WHT applies
**Audit test:** `[INS]` nature of FMC charges per PPT agreement → maintenance services component may attract WHT; seek tax counsel opinion

---

## Stamp Duty (Stamp Act 1949)

| Document | Duty |
|---------|------|
| Tenancy agreement (lease < 3 years) | RM 1 per RM 250 of total rent |
| Tenancy agreement (lease > 3 years) | RM 2 per RM 250 of total rent |
| PPT Agreement (service agreement) | RM 10 (fixed duty) |
| Transfer of shares | RM 3 per RM 1,000 of consideration |

**Note:** PPT Clause 18.7 states stamp duty borne by FME — verify compliance
**Lease stamp duty:** Borne by CUSTOMER — `[INS]` stamped tenancy agreements for all centres

---

## RPGT — Real Property Gains Tax (RPGT Act 1976)

**Applicable only if:** Nephrocare disposes of real property or shares in a real property company
**Healthcare context:** If any centre premises are owned (not leased) and subsequently disposed
**Rates (companies):**
- Disposal within 3 years: 30%
- Disposal Year 4: 20%
- Disposal Year 5: 15%
- Disposal Year 6+: 10%

---

## Malaysian Tax Compliance Calendar (Healthcare Company)

| Deadline | Filing | Reference |
|---------|--------|---------|
| 30th day before FYE | CP204 (estimated tax) | ITA s.107C |
| Monthly (15th) | PCB/MTD remittance | ITA s.83 |
| Monthly (last day) | SOCSO / EIS contributions | ESSA 1969 |
| Monthly (15th) | EPF contributions | EPFA 1991 |
| Monthly (last day) | SST return (if applicable) | STA 2018 |
| 28 February | EA form to employees | ITA s.83A |
| 7 months after FYE | Form C — corporate tax return | ITA s.77A |
| 7 months after FYE | Balance tax payment | ITA s.103 |
