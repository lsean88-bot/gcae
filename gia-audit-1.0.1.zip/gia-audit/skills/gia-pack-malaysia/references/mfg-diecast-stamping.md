> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- SKILL ARCHITECTURE
- Step 0 — Evidence Standard (Mandatory Before Any Fieldwork)
- Step 1 — Entity & Engagement Context
- Step 2 — Mandatory Web-Validation Searches
- Step 3 — Document Inventory (Tiered)
- Step 4 — Audit Domains
- Step 5 — Report structure
- Non-Negotiable Validation Standards


# Malaysia Die Casting, Metal Stamping & Manufacturing — Internal Audit Skill

**Jurisdiction:** Malaysia (Peninsular Malaysia primary; Sabah/Sarawak Labour Ordinances where applicable)
**Standard:** IIA GIAS 2024 (effective 9 Jan 2025) | COSO ERM 2017 | ACFE Fraud Tree
**Manufacturing context:** HPDC/GDC die casting + metal stamping + sub-assembly; automotive OEM supply chain
**Labour types:** Local (Malaysian) | Contract (via contractor/agent) | Foreign (VP(TE) / Employment Pass / PVP)
**Version:** 1.0 — May 2026 (SST expanded Jul 2025; EPF foreign workers Oct 2025; minimum wage [MY-003]; SOCSO/EIS ceiling [MY-007]; IATF Rules 6th Ed Jan 2025; Employment Pass salary thresholds Jun 2026)

> **IRON RULE:** No finding on assumption. No estimate without source data and formula.
> **IRON RULE:** Every rate, threshold, deadline cited must be verified against official portal before use.
> **IRON RULE:** Cite Act + Section + Year + effective date on every finding. Generic citations are not acceptable.
> **EVIDENCE TAGS:** `[INS]` `[PHY]` `[CON]` `[REC]` `[OBS]` `[ANA]` `[REP]` — tag every test.

---

## SKILL ARCHITECTURE

```
my-mfg-diecast-stamping-audit/
├── SKILL.md                              ← This file
└── references/
    ├── R01_sst_tax.md                    ← SST Act 2018, Sales Tax (manufacturing), e-Invoice MyInvois
    ├── R02_income_tax_incentives.md      ← ITA 1967, Pioneer Status, ITA/RA, TP s.140A, LHDN
    ├── R03_employment_local.md           ← EA 1955 (Amdt 2022), EPF, SOCSO, EIS, HRD Corp, PCB/MTD
    ├── R04_foreign_labour.md             ← Immigration Act 1959/63, JTK, VP(TE), work permit, EPF Oct 2025, levy
    ├── R05_contract_labour.md            ← Contractor/outsourcing, CIDB, sub-contractor controls, liability
    ├── R06_osha_safety.md                ← OSHA 1994 (Amdt 2022), FMA 1967, DOSH, BOMBA, ERP
    ├── R07_environment_doe.md            ← EQA 1974, Scheduled Waste Regs 2005, DOE, MITI
    ├── R08_iatf_quality.md               ← IATF 16949 Rules 6th Ed, APQP, PPAP, PFMEA, MSA, SPC, OEM CSRs
    ├── R09_die_casting_ops.md            ← HPDC/GDC process, MTC, metal yield, alloy (ADC12/A380/Zn), scrap
    ├── R10_stamping_ops.md               ← Stamping/blanking/forming, HRC/CRC coil, nesting, material yield
    ├── R11_tooling_governance.md         ← Die/tooling register, ownership, amortisation, maintenance, capex
    ├── R12_supply_chain_oem.md           ← OEM billing, DO reconciliation, AR ageing, OTIF, S&OP, MRP
    ├── R13_financial_controls.md         ← AP/AR, cash, 3-way match, Ind AS equivalent (MFRS), payroll controls
    ├── R14_fraud_detection.md            ← ACFE tree, Benford, ghost workers, scrap diversion, kickbacks, MACC
    └── R15_compliance_calendar_my.md     ← Full Malaysia manufacturing compliance calendar + penalties
```

---

## Step 0 — Evidence Standard (Mandatory Before Any Fieldwork)

| Tag | Type | Reliability |
|-----|------|------------|
| `[INS]` | Document inspection | Original preferred; authenticated copy acceptable |
| `[PHY]` | Physical observation/count | Highest for existence; auditor must witness |
| `[CON]` | External confirmation (portal) | MySST, LHDN MyTax, KWSP i-Akaun, PERKESO ASSIST, SSM, IAQG OASIS, JTK, Immigration Dept — Rank 1 |
| `[REC]` | Recalculation/reperformance | Auditor independently recomputes from primary data |
| `[OBS]` | Process observation | Timing risk; supplement with other evidence |
| `[ANA]` | Analytical procedure | Benford, ratio, trend, population — system-extracted data |
| `[REP]` | Management report/representation | Rank 5 — initiate inquiry only; never close finding alone |

**Operational rules:**
1. Every 🔴 Critical finding requires at least one `[CON]` or `[PHY]` or witnessed `[REC]`
2. 100% population testing preferred where ERP/MES data is extractable
3. All monetary findings quantified in **MYR** (kg/ppm/% for physical and quality findings)
4. "Evidence Not Obtained" is a valid conclusion — document what was requested and the risk
5. Contradict, don't defer — when evidence contradicts management, evidence governs

---

## Step 1 — Entity & Engagement Context

Confirm all fields from verifiable sources before fieldwork:

| Field | Verified Source |
|-------|----------------|
| SSM company status | mydata.ssm.com.my — active, directors, paid-up capital |
| Manufacturing licence (MITI) | MITI notification; no annual renewal but expansion needs MITI |
| SST registration (manufacturer) | mysst.customs.gov.my — registered manufacturer status |
| e-Invoice phase | myinvois.hasil.gov.my — annual turnover vs phase threshold |
| IATF 16949 certificate | iaqg.org/oasis — cert number, expiry, CB, surveillance dates |
| OEM customers | Purchase Agreements / Annual Supply Contracts — customer-issued |
| MIDA incentive status | Pioneer Status / ITA / RA approval letter; LHDN incentive register |
| DOE scheduled waste | doe.gov.my — SW generator licence number |
| BOMBA fire certificate | State BOMBA authority — current fire cert |
| DOSH factory registration | dosh.gov.my — factory registration; HIRARC on file |
| Total headcount | EPF ECR portal i-Akaun (Rank 1) — local + foreign breakdown |
| Foreign worker count | JTK employer portal; Immigration Dept VP(TE) list |
| Contract workers | Contractor/outsourcing agreements; JTK contractor registration |
| ERP/MES/WMS | System inventory — data extraction capability for analytics |

---

## Step 2 — Mandatory Web-Validation Searches

Run before ANY finding is raised:

```
Malaysia SST manufacturing Sales Tax Act 2018 rate 2025 2026
Malaysia e-Invoice MyInvois Phase 3 threshold July 2025
Malaysia Income Tax Act 1967 Pioneer Status incentives 2025
Malaysia LHDN transfer pricing TP Rules 2012 documentation 2025
Malaysia EPF contribution rate 2026 employer employee
Malaysia EPF foreign workers mandatory October 2025 rate
Malaysia SOCSO EIS wage ceiling current PERKESO notice
Malaysia minimum wage order current effective dates by employer size
Malaysia Employment Act 1955 Amendment 2022 overtime leave
Malaysia OSHA 1994 Amendment 2022 A1648 penalties
Malaysia foreign worker levy manufacturing 2025 2026 VP TE
Malaysia JTK contractor foreign worker registration
Malaysia DOE scheduled waste regulations 2005 die casting
IATF 16949 Rules 6th Edition 2025 changes surveillance
Malaysia HRD Corp levy rate 2025 manufacturing
Malaysia SST healthcare private non-citizen July 2025
Malaysia e-Invoice MyInvois Phase 4 threshold 2025
```

---

## Step 3 — Document Inventory (Tiered)

**Mark:** ✅ Obtained | ⚠️ Partial | ❌ Not Provided

### Tier 1 — Mandatory (Engagement Cannot Proceed Without)
- [ ] SST-02 returns — all taxable periods `[CON]` MySST portal
- [ ] LHDN: CP204 + CP204A + last 3 years tax computations `[CON]` MyTax
- [ ] EPF: monthly contributions all periods `[CON]` i-Akaun employer portal
- [ ] SOCSO/EIS: monthly contributions `[CON]` PERKESO ASSIST portal
- [ ] IATF 16949 certificate + last 2 surveillance reports `[CON]` IAQG OASIS
- [ ] Audited financial statements — last 2 years + current management accounts
- [ ] ERP production records: BOMs, work orders, material consumption, scrap register
- [ ] OEM customer contracts/APAs — Perodua, Proton, Honda etc.
- [ ] Payroll register — all employees (local + contract + foreign), all periods

### Tier 2 — Domain-Specific
- [ ] Metal yield reports: ingot/coil input → good output → scrap by category
- [ ] Weigh-gate records: signed, timestamped, per scrap dispatch `[PHY]`
- [ ] Tooling/die register: die number, owner, location, condition, depreciation
- [ ] Customer DO (Delivery Order) register vs. invoice register
- [ ] AR ageing report as at audit date
- [ ] BOM per part number per customer
- [ ] MRP/S&OP records: customer demand releases vs. actual schedule
- [ ] OEM quality scorecards — customer-issued (not company self-prepared) `[CON]`
- [ ] Foreign worker list: name, IC/passport, VP(TE) number, expiry, job title, wages
- [ ] JTK employer registration + contractor registration certificates
- [ ] DOSH factory registration + HIRARC + accident register (JKKP 8)
- [ ] DOE Scheduled Waste manifest (SW tracking forms)
- [ ] BOMBA fire certificate — current

---

## Step 4 — Audit Domains

### Domain 1 — SST Compliance (Sales Tax — Manufacturing)

**Statute:** Sales Tax Act 2018; Sales Tax (Rates of Tax) Order 2018 (as amended Jul 2025); Custom Act 1967

| Test | Evidence | Rate/Threshold |
|------|---------|----------------|
| SST registration as manufacturer | `[CON]` MySST portal — registered status, registration date | Mandatory above the threshold in [MY-031] |
| Sales tax rate applied to finished goods | `[INS]` SST-02 returns + `[REC]` rate test | rate per [MY-017] — verify per HSN/tariff code |
| CKD/CBU exemptions (if applicable) | `[INS]` exemption certificates | Auto parts supplied to licensed vehicle manufacturers may carry specific exemptions |
| Raw material exemptions | `[INS]` exemption letter from RMCD | Raw materials used in manufacture of taxable goods — may be exempt; verify per Schedule B |
| Input SST recovery | SST is single-stage — no input recovery mechanism (unlike GST) | Confirm no ITC claim mechanism; cost-in pricing model |
| SST-02 filing compliance | `[CON]` MySST portal submission history | Due 28th of following month after taxable period (bi-monthly) |
| e-Invoice MyInvois compliance | `[CON]` myinvois.hasil.gov.my — LHDN validation | Phases per [MY-020] and [MY-034] |
| Sales invoice format (e-invoice) | `[INS]` sample invoices — IRN/UUID present | Mandatory for applicable phases; Finance Act 2024 — e-invoice required for tax deductibility |

**Red flags:** SST under-declared on sales; incorrect rate applied; raw material exemption claimed without RMCD approval; e-invoice not implemented despite threshold crossed.

---

### Domain 2 — Income Tax, Incentives & Transfer Pricing

**Statute:** Income Tax Act 1967 (ITA 1967); Promotion of Investments Act 1986 (PIA 1986); TP Rules 2012 (ITA s.140A); LHDN TP Guidelines 2024

| Test | Evidence | Key Rules |
|------|---------|-----------|
| Tax computation — current year | `[INS]` CP204 + CP204A + tax computation | Corporate tax rate per [MY-037] |
| Pioneer Status / ITA / RA compliance | `[INS]` MIDA approval letter + LHDN incentive register `[CON]` | Pioneer, ITA and RA incentives per [MY-038] |
| MIDA NIF (New Incentive Framework) | Verify if entity applied/eligible under new framework launched Jan 2026 | NIF replaces some legacy incentives — web-validate current MIDA guidance |
| Capital allowance — plant & machinery | `[INS]` fixed asset register + CA schedule | Initial 20% + Annual 14% (die casting machines, stamping presses); accelerated CA for some categories |
| Transfer pricing — related parties | `[INS]` TP documentation + `[REC]` tested-party margin | ITA s.140A: Arm's length principle; LHDN TP Guidelines 2024; documentation threshold RM25M |
| OECD Pillar Two (GMT) | Verify if MNE parent group revenue >EUR 750M | Global Minimum Tax 15% — Malaysia implementing via Qualified Domestic Minimum Top-up Tax (QDMTT); verify Finance Act 2025 |
| PCB/MTD monthly deduction | `[CON]` LHDN e-PCB extract | Deducted and remitted by 15th of following month |
| Advance tax (CP204A) | `[INS]` CP204A submissions | 6th month revision mandatory; 9th month optional |

---

### Domain 3 — Local Employment: EA 1955, EPF, SOCSO, EIS, HRD

**Statute:** Employment Act 1955 (Act 265) as amended by Act A1651 (2022); EPF Act 1991; SOCSO Act 1969; EIS Act 2017; HRD Corp Act 2001

| Test | Evidence | Current Rate |
|------|---------|-------------|
| Minimum wage compliance — all employees | `[REC]` payroll register; `[CON]` EPF ECR headcount cross-check | [MY-003]; effective date by employer size per register. Basic salary only — allowances excluded |
| EPF employer contribution | `[CON]` i-Akaun employer portal — all months | Employer rate [MY-005] and employee rate [MY-004] by salary band |
| SOCSO contribution (Employment Injury + Invalidity) | `[CON]` PERKESO ASSIST portal | Rates [MY-008]; insurable wage ceiling [MY-007] |
| EIS contribution | `[CON]` PERKESO ASSIST portal | Rate [MY-009]; insurable wage ceiling [MY-007] |
| HRD Corp levy | `[CON]` HRD Corp employer portal | levy per [MY-045] |
| Working hours / overtime | `[INS]` time records; `[OBS]` production schedule | **Max 45 hours/week** (EA 2022); OT: 1.5× for hours 40–45/week; 2× for rest day; 3× public holiday |
| Leave entitlements | `[INS]` leave records vs EA 1955 Schedule | AL: 8 days (<2 yr) / 12 days (2–5 yr) / 16 days (>5 yr); MC: 14/18/22 days; Maternity: 98 days |
| Termination / retrenchment | `[INS]` Industrial Relations Act compliance | Notice per EA; retrenchment — MITI notification if ≥50 workers |
| EA universal coverage (post-2022) | `[INS]` Confirm EA applies to ALL employees (not just ≤RM2,000) | EA 2022 removed wage ceiling — EA now covers all employees regardless of salary |
| PCB/MTD deduction | `[CON]` LHDN e-PCB | Deducted monthly; remitted by 15th following month |

---

### Domain 4 — Foreign Labour Compliance

**Statute:** Immigration Act 1959/63 (Act 155); Passports Act 1966; Employment Act 1955; Employees Provident Fund Act 1991; SOCSO Act 1969; Anti-Trafficking in Persons Act 2007

| Test | Evidence | Key Requirement |
|------|---------|-----------------|
| Work permit validity — 100% population | `[INS]` VP(TE) / Employment Pass / relevant pass — expiry dates; `[CON]` Immigration Dept portal | Every foreign worker must hold a valid work pass. Expired = illegal worker; employer liable |
| Work pass category matches job title | `[INS]` VP(TE) endorsement vs actual job scope | VP(TE) = manual/semi-skilled; Employment Pass = managerial/professional; must match actual role |
| Foreign worker levy payment | `[INS]` levy receipts; `[CON]` JTK/Immigration portal | Manufacturing levy rates per [MY-046] |
| EPF — mandatory from Oct 2025 | `[CON]` i-Akaun employer portal — foreign worker ECR | **From Oct 2025: mandatory for all non-citizen workers ([MY-043])** with valid work pass (excl. domestic workers); contributed same as Malaysians from Oct 2025 |
| SOCSO — foreign workers | `[CON]` PERKESO ASSIST | Foreign workers covered under Employment Injury Scheme (First Category); ceiling [MY-007] |
| Minimum wage — foreign workers | `[REC]` payroll register for all foreign workers | [MY-003] applies equally to foreign workers (effective dates by employer size per register) |
| Passport custody | `[PHY]` passport inspection — held by worker (not employer) | Illegal for employer to retain passports — Sec 12A Passports Act 1966; TIP Act offence |
| Accommodation adequacy | `[OBS]` site visit if company-provided | JTKSM standard: min 35 sqft per person; clean water; proper sanitation |
| Forced labour indicators | `[INS]` + `[OBS]` | Freedom of movement; no wage deductions beyond legal limits; no recruitment fee debt bondage |
| JTK employer registration | `[CON]` JTK portal | Employers of foreign workers must register with JTK; inspection records |
| Repatriation insurance | `[INS]` FWCS (Foreign Workers Compensation Scheme) | Mandatory for VP(TE) holders — FWCS policy or PERKESO |
| Employment Pass salary threshold (Jun 2026) | Verify the Category III threshold and effective date per [MY-013] | Must review all EP holders approaching the new threshold |

**Red flags:** Expired VP(TE); passports held by employer; wage below the national minimum wage for foreign workers; no EPF contribution for foreign workers post-Oct 2025; recruitment fee debt bondage indicators; overcrowded accommodation.

---

### Domain 5 — Contract/Outsourced Labour

**Statute:** Employment Act 1955; SOCSO Act 1969; EPF Act 1991; CIDB Act 1994 (if construction); Occupational Safety and Health Act 1994

| Test | Evidence | Key Rule |
|------|---------|---------|
| Contractor registration — JTK | `[CON]` JTK contractor portal | Labour contractors supplying workers must be registered with JTK |
| Contractor EPF/SOCSO compliance | `[CON]` i-Akaun + PERKESO — contractor's contributions for deployed workers | Principal employer may be liable if contractor defaults — verify challan copies |
| Minimum wage paid by contractor | `[REC]` contractor payroll extract + rate per worker | national minimum wage [MY-003] — principal employer exposure if contractor underpays |
| Contract workers on principal employer's payroll? | `[INS]` contractor vs direct employee boundary | Disguised employment risk — if control, supervision, tools all from principal = deemed employee |
| Contractor invoice validation | `[INS]` invoice + e-invoice IRN (if applicable) | Standard invoice validation; SST on labour supply (service, not goods) |
| DOSH — contractor safety | `[INS]` HIRARC for contractor activities; `[OBS]` PPE | Principal employer responsible for contractor safety under OSHA 1994 Sec 15 |
| CIDB registration (if civil/construction work) | `[CON]` CIDB portal | Civil/construction contractors must be CIDB-registered |

---

### Domain 6 — OSHA & Factory Safety

**Statute:** Occupational Safety and Health Act 1994 (Act 514, Amdt 2022 — Act A1648); Factories and Machinery Act 1967 (FMA 1967); DOSH

| Test | Evidence | Key Requirement (Post-2022 Amendment) |
|------|---------|--------------------------------------|
| OSH Coordinator appointment | `[INS]` appointment letter + training certificate | Mandatory for employers with ≥5 employees — OSH Coordinator (certificate from DOSH-accredited institution) |
| OSH Committee | `[INS]` committee constitution + minutes | Mandatory for employers with ≥40 employees; meets at least once every 3 months |
| HIRARC (Hazard Identification, Risk Assessment, Risk Control) | `[INS]` HIRARC document — signed, reviewed annually | OSHA 1994 Sec 15; must cover all work processes including die casting, stamping, hot metal handling |
| Accident reporting — JKKP 8 | `[INS]` accident register; `[CON]` DOSH accident records | Fatal/serious injury: report to DOSH within 7 days (JKKP 8 form); near-miss: internal record |
| Medical surveillance | `[INS]` annual medical check records | For workers exposed to chemical/physical hazards; OSHA Regs |
| PPE provision | `[PHY]` physical inspection of PPE stocks + usage | Employer provides PPE at no cost; documented training |
| Machinery inspection (FMA 1967) | `[INS]` DOSH Form A certificates — pressure vessels, cranes, die casting machines (if classified machinery) | Periodic DOSH inspection for classified machinery |
| BOMBA fire certificate | `[INS]` current fire certificate from state BOMBA | Annual renewal; fire extinguisher certification |
| Emergency Response Plan (ERP) | `[INS]` ERP document + drill records | OSHA 2022 — annual drill; attendance record |
| Penalty awareness | OSHA 2022 increased penalties: penalties per [MY-048] | Verify management aware of new penalty regime |

---

### Domain 7 — Environment & DOE

**Statute:** Environmental Quality Act 1974 (EQA 1974); Scheduled Wastes Regulations 2005; DOE

| Test | Evidence | Key Rule |
|------|---------|---------|
| DOE SW generator registration | `[CON]` doe.gov.my — registration number; category | Die casting: shot blasting dust (SW 410), paint/coating waste (SW 322), lubricant waste (SW 306), spent solvents (SW 322); Stamping: metal cutting/grinding sludge |
| SW manifest (Borang SW) | `[INS]` SW tracking manifests (Form SW-A) | Mandatory for every scheduled waste consignment; kept 3 years |
| Licensed SW contractor | `[INS]` contractor DOE licence — valid | Only DOE-licensed contractors may transport and dispose SW |
| Annual environmental report | `[INS]` DOE submission acknowledgement | Some operations require periodic environmental reporting per EQA licence conditions |
| Effluent treatment | `[INS]` trade effluent licence (if applicable) | Any discharge to drains/rivers requires DOE approval; pH, BOD limits |
| Air emission | `[INS]` boiler/incinerator licence (if applicable) | Licenced burning/emission sources require DOE approval |

---

### Domain 8 — IATF 16949 Quality Management

**Standard:** IATF 16949:2016 (Rules for Achieving and Maintaining IATF Recognition, 6th Edition, effective 1 Jan 2025)

| Test | Evidence | Key Rule (Rules 6th Ed) |
|------|---------|------------------------|
| Certificate validity | `[CON]` IAQG OASIS — cert number, expiry, CB name, surveillance | Max 3-year certificate; surveillance: every 12 months (±30 days); recertification: before expiry |
| Nonconformity response | `[INS]` NC response records + CB correspondence | Rules 6th Ed: **15-day** response to major NC (not 20); failure = certificate suspension |
| Customer-Specific Requirements (CSRs) | `[INS]` CSR documents from each OEM (Perodua/P2SA, Honda, Proton, Denso) | Auditor must verify latest version of each OEM's CSR is implemented |
| PPAP (Production Part Approval Process) | `[INS]` PPAP packages per OEM submission level | AIAG PPAP 4th Ed (aligned with IATF); Level 3 most common for new parts |
| APQP (Advanced Product Quality Planning) | `[INS]` APQP plans; Gate reviews per phase | Mandatory for new part launches; phased approval |
| PFMEA (Process Failure Mode Effects Analysis) | `[INS]` PFMEA per production process | Must be reviewed and updated after process changes; severity/occurrence/detectability ratings |
| MSA (Measurement System Analysis) | `[INS]` MSA studies — Gauge R&R | All measurement gauges/systems must have acceptable Gauge R&R (typically <30% study variation) |
| SPC (Statistical Process Control) | `[INS]` SPC charts for key product/process characteristics | Cpk ≥1.33 for special characteristics; ongoing monitoring |
| Internal audit programme | `[INS]` IA schedule + completed audit reports | Annual cycle covering all processes; risk-based frequency |
| Management review | `[INS]` management review minutes | At least annually; input/output requirements per IATF |

---

### Domain 9 — Die Casting Operations & Metal Yield

**Process:** High-Pressure Die Casting (HPDC) / Gravity Die Casting (GDC) — Aluminium (ADC12, A380) / Zinc alloys

| Test | Evidence | Benchmark |
|------|---------|-----------|
| Material Test Certificate (MTC) — ingots | `[INS]` MTC per lot; chemical composition vs. ADC12/A380 spec | Supplier MTC required for every ingot/slab delivery; chemistry verification |
| Metal yield / MTC calculation | `[REC]` Metal-in vs. good-casting-out vs. scrap | **Al HPDC: 65–75% yield (NADCA benchmark); Zn HPDC: 70–80%** |
| Scrap classification and recording | `[INS]` scrap register; `[PHY]` scrap area inspection | Runner scrap (internal recycle): measured, recorded; Reject scrap: SFG/FG defects — quantified separately |
| Weigh-gate scrap reconciliation | `[INS]` weigh-gate log; `[PHY]` observe scrap dispatch | Net weight on dispatch ticket vs. scrap register; any variance = diversion risk |
| Cold chamber / hot chamber settings | `[INS]` process parameters vs. engineering spec | Shot velocity, injection pressure, cooling time — deviation → quality defect causation |
| Shot monitoring data | `[INS]` machine shot log extract | Real-time monitoring; excessive shots without PM = die wear risk |
| Die/mould maintenance | `[INS]` die maintenance log; `[PHY]` die condition | Preventive maintenance schedule; condition score vs. planned PM |
| LME aluminium / zinc price used for valuation | `[CON]` LME.com spot price on valuation date | Scrap valued at LME ± agreed premium; verify contract rate |

**Scrap diversion red flags:** Weight on dispatch ≠ weight recorded; scrap dealer payments in cash without invoice; scrap proceeds not credited to P&L; unusually low internal metal yield despite no quality issues.

---

### Domain 10 — Stamping Operations & Material Yield

**Process:** Cold stamping/blanking/forming of HRC (Hot-Rolled Coil) and CRC (Cold-Rolled Coil) steel

| Test | Evidence | Benchmark |
|------|---------|-----------|
| Steel MTC — coil | `[INS]` MTC per coil; grade vs. OEM spec (e.g. SPCC, SPCD, high-tensile) | Required per coil delivery; OEM specifies material grade |
| Material yield / nesting efficiency | `[REC]` (Coil weight in − Good blank weight) ÷ Coil weight in | **Benchmark: 70–85% yield** (depending on blank shape/nesting; OEM-approved nesting plan governs) |
| Coil weight reconciliation | `[INS]` GRN vs. weigh-bridge records vs. ERP consumption | Total coil received vs. good blanks produced + remnants + scrap; balance = unexplained |
| Scrap (skeleton/offal) disposal | `[INS]` scrap invoice; `[PHY]` scrap yard | SST on scrap steel sale; scrap buyer must issue receipt; proceeds to P&L |
| Press tonnage and tooling setup | `[INS]` press settings vs. tooling card | Correct tonnage prevents die damage; OT settings per approved tooling card |
| Progressive die vs. transfer die | `[INS]` die configuration per part | Die type drives cycle time and material efficiency; BOM must reflect correct die |

---

### Domain 11 — Tooling Governance

| Test | Evidence | Key Rule |
|------|---------|---------|
| Tooling register — completeness | `[INS]` tooling register vs. physical count `[PHY]` | Every die/tool must be numbered, recorded, location tracked |
| Ownership — customer vs. company | `[INS]` tooling agreement in customer contract | OEM-paid tooling: belongs to OEM; company-paid: company asset. Must be correctly classified |
| Amortisation / write-off policy | `[INS]` accounting policy + schedule | Customer-owned tools: not capitalised by company; company-owned: capitalise + amortise per MFRS 116 |
| Tooling capex approval | `[INS]` capex approval vs. board minutes | All tooling capex above approved threshold → board/management approval |
| Tool condition and PM schedule | `[INS]` PM schedule; `[PHY]` die room inspection | Worn tools → quality defects → OEM claim risk |
| OEM tooling recovery billing | `[INS]` tooling recovery billing vs. OEM agreement | If company advanced tooling cost for OEM: recovery must be documented and reconciled |

---

### Domain 12 — OEM Billing & Supply Chain

| Test | Evidence | Key Rule |
|------|---------|---------|
| DO (Delivery Order) vs. invoice reconciliation | `[INS]` DO log vs. sales invoice register | Every DO must have a corresponding invoice; unmatched DO = unrecognised revenue |
| AR ageing | `[INS]` AR ageing report | OEM credit terms (typically 60–90 days); overdue = collection risk |
| Customer price schedule vs. invoiced price | `[REC]` price schedule × quantity vs. invoice | Any deviation (surcharge, discount) must have OEM written approval |
| OTIF (On-Time In-Full) | `[ANA]` delivery records vs. customer requirement | OEM target: typically ≥98%; shortfall = potential premium freight or line-stop claim |
| Customer claims / debit notes | `[INS]` claim register; `[CON]` customer-issued debit notes | 100% population; match to root cause and corrective action; financial impact |
| MRP / S&OP — demand release | `[INS]` customer demand release vs. production plan | Rolling 3-month demand; firm vs. flexible portion per contract |
| Forecast accuracy | `[ANA]` customer forecast vs. actual demand | Significant forecast misses → over/under-production; inventory/capacity risk |
| FIFO inventory | `[PHY]` WMS / warehouse inspection | FIFO enforced for raw material, WIP, FG; aged stock = quality/obsolescence risk |

---

### Domain 13 — Financial Controls & MFRS

**Standards:** MFRS (Malaysian Financial Reporting Standards — IFRS-converged); MPERS (for eligible private entities); Companies Act 2016

| Test | Evidence | Key MFRS |
|------|---------|---------|
| Revenue recognition | `[INS]` revenue recognition policy + DO vs. invoice | MFRS 15 — revenue at point of transfer of control (typically delivery per OEM terms) |
| Lease — MFRS 16 | `[INS]` all lease agreements + ROU asset schedule | MFRS 16: All leases >12 months on balance sheet (ROU asset + lease liability); MIDC factory lease, equipment lease |
| Inventory costing | `[INS]` inventory valuation policy | MFRS 102 (IAS 2): FIFO or WA; not LIFO; lower of cost or NRV; die casting: include direct material + labour + overhead |
| Fixed assets / PPE | `[INS]` FA register + depreciation schedule | MFRS 116: cost model or revaluation model; useful life review annually; die casting machines, stamping presses |
| Impairment | `[INS]` impairment assessment | MFRS 136: test when indicators exist; annual for goodwill |
| 3-way match (AP) | `[INS]` sample PO + GRN + vendor invoice | 100% for top 30 by value; SST on purchases correctly captured |
| Cash controls | `[INS]` petty cash + bank recon | Bank reconciliation monthly; cash limit per payment (ITA s.82 — over RM25,000 cash payment disallowed) |
| SSM annual return | `[CON]` SSM portal | Must be filed within 30 days of AGM (within 6 months of FYE for Companies Act 2016) |

---

### Domain 14 — Fraud Detection & MACC

**Framework:** ACFE Fraud Tree; Benford's Law; MACC Act 2009 (Act 694) Sec 17A (corporate liability)

| Test | Evidence | Fraud Scenario |
|------|---------|---------------|
| Scrap diversion | `[PHY]` weigh-gate; `[ANA]` metal yield vs. benchmark | Scrap metal sold outside recorded system; proceeds pocketed |
| Ghost workers (local/foreign) | `[CON]` EPF ECR vs. payroll; `[PHY]` biometric attendance | Payroll inflated; ghost foreign worker levy claims |
| Vendor kickbacks (raw material) | `[ANA]` Benford on purchase amounts; `[INS]` vendor concentration | Single-source procurement; price above LME/market; vendor related to buyer |
| Tooling cost inflation | `[REC]` tooling quotes vs. market; `[INS]` quotation documentation | Inflated tooling quotes; kickback from tooling supplier |
| OEM invoice manipulation | `[ANA]` Benford on invoices; `[INS]` DO vs. invoice | Fictitious shipment; over-billing on quantity or price |
| Customer claim concealment | `[INS]` claim register vs. P&L provision | Unrecorded claims → overstatement of receivables/revenue |
| Excess scrap recycling to related party | `[INS]` inter-company transactions | Internal scrap sold below market to related recycler |
| MACC s.17A — corporate liability | `[INS]` adequate procedures documentation | Organisation liable if commercial associate (employee, agent, contractor) commits corruption; 6 pillars of adequate procedures |

**Benford's Law targets:** Purchase invoice amounts; scrap sale amounts; payroll amounts; tooling capex; OT claims.

---

### Domain 15 — Key Performance Benchmarks

| KPI | Formula | Benchmark | Source |
|-----|--------|-----------|--------|
| Al HPDC metal yield | Good casting kg ÷ Metal input kg | 65–75% | NADCA; industry |
| Zn HPDC metal yield | Same | 70–80% | NADCA |
| Stamping material yield | Good blank wt ÷ Coil input wt | 70–85% | OEM nesting plan |
| OEE | Availability × Performance × Quality | ≥85% world-class; 70–80% typical MY | Industry |
| DPPM | Defects ÷ Output × 1,000,000 | <50 ppm (Perodua/Honda) | OEM scorecard |
| OTIF | On-time in-full ÷ Total shipments | ≥98% | OEM contract |
| Scrap rate | Scrapped ÷ Produced | <3% HPDC; <5% stamping | Industry |
| COGS % revenue | COGS ÷ Revenue | 65–80% | Auto parts MY sector |
| Gross margin | (Rev − COGS) ÷ Rev | 20–35% | MAA / sector |
| DSO | AR × 365 ÷ Revenue | <60 days (OEM 90-day terms) | Contract |
| Inventory days | Inventory × 365 ÷ COGS | 20–40 days | OEM requirement |
| Minimum wage compliance | Employees at or above the national minimum wage [MY-003] ÷ Total | 100% | Legal (see register) |
| EPF compliance rate | On-time months ÷ Total months | 100% | Legal |

---

## Step 5 — Report structure

Owned by `gia-report-qa:gia-ia-report` (standard concise report plus Excel working paper). This pack emits a findings register and its supporting tables only; the long-form overall-opinion layout in the retired source is a legacy conversion reference and is not used. Dashboards named in the retired layout (yield, labour compliance, OEM scorecard, benchmarks) are working-paper sheets.

## Non-Negotiable Validation Standards

| Standard | Rule |
|----------|------|
| Evidence first | No finding stated without evidence tag, source, date |
| Quantify always | MYR / kg / ppm — or "Unquantified — [specific reason]" |
| Cite specifically | Act + Section + Year + effective date; MFRS std + para; IATF clause; IIA GIAS 2024 Standard |
| Tag every test | `[INS]` `[PHY]` `[CON]` `[REC]` `[OBS]` `[ANA]` `[REP]` |
| Minimum wage | Always [MY-003]; never a superseded value |
| EPF foreign workers | **[MY-043]** mandatory from Oct 2025 — never the old flat amount |
| SOCSO/EIS ceiling | Always [MY-007]; never a superseded ceiling |
| IATF Rules 6th Ed | **15-day** NC response (not 20); **12-month** surveillance interval |
| SST healthcare | Private healthcare to non-Malaysians: **service tax from 1 Jul 2025 ([MY-032])** |
| Passport custody | Employer holding passports = criminal offence — always flag |
| Disclaimer | Every report includes MIA/licensed tax/IATF/DOSH/advocate review disclaimer |
| Benchmark | Every operational domain compared to published industry benchmark |

*Professional internal audit framework. Not legal, tax, IATF certification, or DOSH engineering advice. Verify all regulatory positions with RMCD, LHDN, DOSH, DOE, JTK, and IATF-accredited CB before action.*
