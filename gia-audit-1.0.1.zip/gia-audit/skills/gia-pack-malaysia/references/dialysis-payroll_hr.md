> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- Governing Statutes (Current — validated April 2026)
- EPF Contribution Rates (Effective 2024)
- SOCSO (PERKESO) Contribution Table (2024)
- PCB / Monthly Tax Deduction (MTD)
- Clinical Staff Credentialing Requirements
- Headcount Reconciliation — 4-Way Test
- Minimum Wages Compliance Test
- Employment Act 2022 Key Amendments
- Anti-Sexual Harassment Act 2022 — Employer Obligations
- OSHA 1994 — Healthcare / Dialysis Specific


# Payroll, HR & Malaysian Employment Compliance Reference

## Governing Statutes (Current — validated April 2026)

| Statute | Key Provisions | Effective |
|---------|---------------|-----------|
| **Employment Act 1955** (EA 1955), as amended 2022 | Coverage per [MY-001]; 2022 amendments expanded scope | 1 Jan 2023 |
| **Minimum Wages Order 2024** | [MY-003] national minimum wage | per register |
| **Employees Provident Fund Act 1991** (EPF/KWSP) | Mandatory retirement savings contribution | Current |
| **Employees' Social Security Act 1969** (SOCSO/PERKESO) | Employment Injury and Invalidity Scheme | Current |
| **Employment Insurance System Act 2017** (EIS/SIP) | Retrenchment insurance | Current |
| **Income Tax Act 1967** (PCB/MTD) | Monthly Tax Deduction (PCB) | Current |
| **Workers' Minimum Standards of Housing and Amenities Act 1990** | If foreign workers accommodated | Current |
| **Immigration Act 1959/63** | Foreign worker passes (PLKS) | Current |
| **Anti-Sexual Harassment Act 2022** | Employer complaint mechanism mandatory | 1 Jan 2023 |
| **Occupational Safety and Health Act 1994 (OSHA)** | Workplace safety; dialysis centre specific: biohazard, needle-stick | Current |
| **Medical Act 1971** | MMC registration — doctors | Current |
| **Nurses Act 1950** | Nursing Board registration | Current |
| **Private Healthcare Facilities and Services Act 1998** | Allied health practitioner requirements | Current |

---

## EPF Contribution Rates (Effective 2024)

| Employee Salary | Employer Rate | Employee Rate |
|----------------|--------------|--------------|
| lower wage band | [MY-005] | [MY-004] |
| higher wage band | [MY-005] | [MY-004] |
| Age 60 and above | see [MY-005] | see [MY-004] |
| Non-citizen employees | 4% | Not mandatory (voluntary) |

**Maximum contribution ceiling:** No salary ceiling for EPF (unlike SOCSO)
**Payment deadline:** 15th of the following month (late payment: penalty per [MY-044])
**Evidence:** `[CON]` KWSP i-Akaun employer portal — contribution history by employee

---

## SOCSO (PERKESO) Contribution Table (2024)

| Monthly Salary | Employer (EIS) | Employer (SOCSO EI) | Employer (SOCSO IS) | Employee (EIS) | Employee (SOCSO) |
|----------------|---------------------|---------------------|---------------------|----------------|-----------------|
| Up to the insurable ceiling | Per table | Per table | Per table | Per table | Per table |
| Above the insurable ceiling [MY-007] | Ceiling band | Ceiling band | Ceiling band | Ceiling | Ceiling |

**Note:** the insurable wage ceiling is [MY-007]. Employees earning above it contribute as if earning the ceiling.
**EIS:** rate [MY-009] (same ceiling)
**Payment deadline:** [MY-010]; late-payment consequences per the PERKESO notice
**Evidence:** `[CON]` PERKESO employer portal — contribution records

---

## PCB / Monthly Tax Deduction (MTD)

**Basis:** ITA 1967 s.107C; PCB computed per LHDN PCB Algorithm (annual revision)
**Filing:** e-PCB system (`pch.hasil.gov.my`); submit by 15th of following month
**Remittance:** To LHDN by 15th
**Documentation:** CP39 (monthly PCB schedule); CP8A (annual EA form to employees by 28 Feb)
**Evidence:** `[CON]` LHDN MyTax / e-PCB portal — monthly submissions and payments

---

## Clinical Staff Credentialing Requirements

### Nephrologist (Specialist in Nephrology)
- **MMC (Malaysian Medical Council)** full registration — verify `mmc.gov.my`
- **Specialist registration** — Nephrology (sub-speciality of Internal Medicine)
- **CKAPS specialist approval** — per centre where practising
- **Annual Practising Certificate (APC)** — renewed each January
- Annual retention: MOH requirement — nephrologist must be reachable within 30 minutes of centre during operational hours

### Registered Nurses (RN) — Dialysis Trained
- **Nursing Board of Malaysia (NBM)** registration — verify `nbm.moh.gov.my`
- **Annual Practising Certificate**
- Dialysis training: MOH-recognised dialysis nursing training programme
- Minimum 1 RN per 4 machines during any operating shift
- In-charge nurse: minimum 1 year dialysis clinical experience

### Medical Laboratory Technologist
- **MQAP** (Malaysian Qualifications Agency) or **Allied Health Professions Act 2016** registration (if applicable)

---

## Headcount Reconciliation — 4-Way Test

```
Source 1: EPF (KWSP) portal contributor count       ___
Source 2: SOCSO (PERKESO) portal contributor count  ___
Source 3: Payroll system headcount                  ___
Source 4: HR records / employment contract files    ___
─────────────────────────────────────────────────
Discrepancy (any source vs payroll):                ___
Flag for investigation if > 0
```

**Additional tests:**
- Ghost employee: `[ANA]` full payroll extract — two employees sharing identical bank account number
- IC duplication: two employees with same MyKad number
- Address duplication: two employees with identical home address (excluding genuine family members)
- Terminated employee still receiving salary: cross-match termination letters vs final payroll month

---

## Minimum Wages Compliance Test

**Minimum Wages Order 2024:** [MY-003]

**Audit test:**
1. Extract full payroll — all employees, all employment categories
2. Calculate gross salary (basic + fixed allowances) — must exclude reimbursements
3. Compare each employee's gross at or above [MY-003]
4. Flag all exceptions
5. Annualise: if monthly pay is below [MY-003] → breach of MWO 2024

**Penalty:** per [MY-047] — Employment Act s.102

---

## Employment Act 2022 Key Amendments

| Area | Pre-2022 | Post-2022 (effective 1 Jan 2023) |
|------|---------|--------------------------------|
| Scope | Pre-2022 coverage limit | Coverage per [MY-001] (most provisions) |
| OT rate | 1.5× for >8h/day | 1.5× for >8h/day (unchanged) |
| Rest day OT | 2× | 2× (unchanged) |
| Paternity leave | Not mandated | 7 consecutive days |
| Maternity leave | 60 days | 98 days |
| Flexible work | No provision | Employee can request flexible work arrangement |
| Sexual harassment | Complaint provision only | Mandatory inquiry procedure (read with Anti-Sexual Harassment Act 2022) |
| Foreign worker | No specific | Employer obligations on accommodation, salary payment |

---

## Anti-Sexual Harassment Act 2022 — Employer Obligations

**Effective:** 1 January 2023
**Applicability:** All private sector employers

**Mandatory requirements:**
1. Written policy prohibiting sexual harassment
2. Complaint mechanism (dedicated, confidential)
3. Inquiry committee procedure — mandatory inquiry within specified timeline
4. Remedial action
5. Non-retaliation policy for complainants

**Audit test:** `[INS]` HR manual (current version) — verify all 5 elements present; `[INS]` complaint register (if any complaints received)

**Penalty (employer non-compliance):** per [MY-047]

---

## OSHA 1994 — Healthcare / Dialysis Specific

**Applicable risks:**
- Needle-stick injury (sharps handling — AVF needles, bloodlines)
- Biohazard exposure (blood-borne pathogens — Hep B, Hep C, HIV)
- Chemical exposure (Citrosteril — irritant; concentrate chemicals)
- Ergonomic risk (patient handling — manual lifting)

**OSHA requirements:**
- Workplace safety and health policy (OSHC)
- Safety Officer: if >40 employees, must appoint registered Safety Officer
- JKKP 8 form: industrial accident reporting (within 7 days to DOSH for accidents resulting in ≥4 days MC)
- First Aid Box (Factories and Machinery regulations)
- Hepatitis B vaccination: employer must offer and record

**Evidence:** `[INS]` DOSH (JKKP) accident register; `[INS]` Safety Officer registration; `[INS]` HBV vaccination records for clinical staff
