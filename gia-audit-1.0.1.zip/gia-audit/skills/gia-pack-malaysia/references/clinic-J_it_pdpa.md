> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
[case figure moved to example-2026-Q1.md]
- J2 — PDPA 2024: Personal Data Protection (Amendment) Act 2024
- J3 — PDPA Audit Tests
- J4 — LHDN eInvoice (MyInvois) — Mandatory Compliance
- J5 — SQL Accounting IT General Controls (ITGC)
- J6 — Group IT Consolidation Assessment


# Reference J — IT Systems, PDPA 2024 Amendment & Digital Compliance
*Updated May 2026 — PDPA DPO mandatory Jun 2025; MyInvois mandatory Jul 2025; penalties per [MY-051]*

---

[case figure moved to example-2026-Q1.md]

[case figure moved to example-2026-Q1.md]
|----------|------------|------------------------|------------------------|
| Accounting / GL | SQL Accounting | SQL Accounting | SQL Accounting |
| POS / Clinic System | **Klinify** | **Doctor Partner** | **Doctor Partner** |
| Payroll / HR | **Worksy** | **Payroll Panda** | **Payroll Panda** |
| eInvoice / MyInvois | Status: **UNCONFIRMED** | Unconfirmed | Unconfirmed |
| PDPA DPO | **NOT CONFIRMED** | Not confirmed | Not confirmed |
| Patient data backup | Klinify cloud (unverified) | Doctor Partner (unverified) | Doctor Partner (unverified) |

**Integration gaps:**
- No API between Klinify and Doctor Partner → no automated group revenue consolidation
- No integration between Worksy and Payroll Panda → manual extraction for group payroll reporting
- eInvoice integration status unconfirmed across all three entities

---

## J2 — PDPA 2024: Personal Data Protection (Amendment) Act 2024

**Law:** Personal Data Protection Act 2010 (Act 709) as amended by Personal Data Protection (Amendment) Act 2024; rolled out in three phases January–June 2025.

### What Changed (2024 Amendments) — Research-Verified May 2026

| Change | Detail | Effective |
|--------|--------|-----------|
| Terminology | "Data Users" → **"Data Controllers"**; new category: **"Data Processors"** | 2025 |
| DPO Appointment | **Mandatory** for organisations that: (a) process sensitive personal data at scale, (b) process large volumes of personal data, (c) systematically monitor data subjects | **June 2025** |
| Data Breach Notification | Must notify PDPA Commissioner within **72 hours** of becoming aware | 2025 |
| Data Portability | Data subjects have right to request transfer of their data in structured format | 2025 |
| Right to Erasure | Data subjects can request deletion of personal data | 2025 |
| Penalties | Increased maximum fine, see [MY-051] | 2025 |
| Biometric data | Explicitly classified as sensitive personal data | 2025 |
| GDPR alignment | Substantially aligned with EU GDPR framework | — |

### Health Data = Sensitive Personal Data (s.5)

[case figure moved to example-2026-Q1.md]
- Heightened security controls
- Explicit consent required for processing
- DPO appointment (if threshold met)
- 72-hour breach notification obligation per entity per POS platform

### DPO Requirements (Effective June 2025)

[case figure moved to example-2026-Q1.md]
1. Processes sensitive personal data (health/medical records) at scale (3,072+ encounters per quarter)
2. Systematically monitors data subjects (patient history, panel billing, follow-up)
[case figure moved to example-2026-Q1.md]

[case figure moved to example-2026-Q1.md]

---

## J3 — PDPA Audit Tests

| Test | Evidence | Assertion | Risk |
|------|----------|-----------|------|
| DPO appointed — appointment letter | `[INS]` DPO appointment letter | CP | Penalty per [MY-051] |
| DPO qualification/competency documented | `[INS]` DPO CV, training records | CP | |
| Patient registration forms include PDPA collection notice | `[INS]` sample registration form (5 patients) | CP | |
| Privacy notice updated post-2024 amendment (Data Controller terminology) | `[INS]` clinic privacy notice / website | CP | |
| Data breach response procedure documented and tested | `[INS]` breach response SOP; tabletop exercise record | CP | |
| Role-based access in Klinify — clinical vs billing vs admin | `[OBS]` Klinify user access matrix | AU | |
| Patient data not shared with third parties without consent | `[INS]` data sharing agreements; panel billing consent | CP | |
| 72-hour breach notification register | `[INS]` incident log | CO | |
| Cross-border data transfer controls (e.g. cloud servers outside Malaysia) | `[INS]` Klinify data residency documentation | CP | |
| Data retention policy — how long patient records retained | `[INS]` data retention policy | CP | |
[case figure moved to example-2026-Q1.md]

---

## J4 — LHDN eInvoice (MyInvois) — Mandatory Compliance

**Law:** Income Tax Act 1967 read with LHDN eInvoice Guidelines v3.2 (2025); Finance Act 2023; Income Tax (Digital Services) provisions

### Mandatory Deadlines

[case figure moved to example-2026-Q1.md]
|------------------|---------------|----------------|
| Phase 1 band per [MY-034] | 1 August 2024 | N/A |
| Phase 2 band per [MY-034] | 1 January 2025 | N/A |
[case figure moved to example-2026-Q1.md]
| ALL taxpayers | 1 July 2026 | Universal mandate |

[case figure moved to example-2026-Q1.md]

### Key Compliance Requirements

| Requirement | Detail |
|-------------|--------|
| Invoice submission | All invoices must be submitted to LHDN MyInvois portal via API or direct upload |
| Validation | LHDN validates invoice and returns UUID + QR code |
| QR code on receipt | Printed patient receipt must include MyInvois QR code (UUID embedded) |
| Timing | Invoice must be submitted to MyInvois within specified timeframe (real-time or consolidated daily) |
| Consolidated e-invoice | Clinics may issue standard receipts to patients during day, then submit consolidated e-invoice at day-end — LHDN compliant for B2C transactions |
| Individual e-invoice | If patient requests individual e-invoice (e.g. for insurance reimbursement), must issue separately |
| SST code on invoice | Healthcare services: use tax code **E (Exempt)** for Malaysian citizens; **S (Standard, per [MY-032])** for non-citizen SST-taxable services |
| Record retention | 7 years |

### Healthcare eInvoice — SST Exemption Note

[case figure moved to example-2026-Q1.md]

### eInvoice Audit Tests

| Test | Evidence | Assertion | Consequence |
|------|----------|-----------|-------------|
| Klinify MyInvois API integration active since Jul 2025 | `[OBS]` test transaction in Klinify → check UUID generation | CP | Penalty per [MY-036] |
| Sample patient receipts contain MyInvois QR code (UUID) | `[PHY]` sample 10 recent receipts | CP | |
| Consolidated e-invoice submitted daily to LHDN | `[INS]` MyInvois portal submission log | CO | |
| Individual e-invoice issued on patient request | `[INQ]` staff knowledge test | CP | |
| Tax code correct (E for Malaysian citizens, S for non-citizens with SST) | `[INS]` sample e-invoice XML | AC, CP | |
| LHDN eInvoice registration (MyInvois account active) | `[CON]` MyInvois portal login confirmation | CP | |

### Penalty

Penalty per invoice not submitted to MyInvois: [MY-036]. With ~3,072 encounters per quarter, quantify exposure per quarter as encounters × the [MY-036] amount if 100% non-compliant.

---

## J5 — SQL Accounting IT General Controls (ITGC)

| Control | Test | Evidence | Risk |
|---------|------|----------|------|
| User access — individual named accounts (no shared "ADMIN" login) | `[OBS]` SQL user management screen | AU | 🔴 Shared ADMIN = no audit trail attribution |
| Segregation of duties — posting vs approving | `[INS]` user role matrix | AU | 🟠 |
| Journal entry approval above threshold | `[INS]` JV workflow — check JV-00236 (RM 3M) had dual approval | AU | 🟠 |
| Period lock — prior periods cannot be modified without CFO override | `[OBS]` attempt to post to locked period | CP | 🟠 |
| Automated daily backup — offsite, tested | `[INS]` backup policy + restoration test log | CO | 🟠 |
| Audit trail — complete, tamper-evident | `[INS]` SQL audit log | CO | 🟠 |
| Password policy — min 8 chars, 90-day expiry | `[INS]` SQL security settings | CP | 🟡 |

---

## J6 — Group IT Consolidation Assessment

| Gap | Business Impact | Recommended Solution |
|-----|----------------|---------------------|
| 2 POS systems (Klinify vs Doctor Partner) | No automated group revenue dashboard | Assess API integration or single platform migration |
| 2 payroll systems (Worksy vs Payroll Panda) | Manual extraction for group payroll reporting | Assess Kakitangan.com / Talenox / BambooHR Malaysia |
| No PDPA DPO across 3 entities | Fine exposure per entity per breach, see [MY-051] | Appoint Group DPO |
| MyInvois not confirmed for any entity | Per-invoice penalty [MY-036]; Q3 2025 onwards | Immediate: activate Klinify MyInvois integration |
| Klinify SST module capturing RM 0 | SST-02 returns may be understate actual liability | Reconfigure post-SST registration (01 Sep 2025) |
