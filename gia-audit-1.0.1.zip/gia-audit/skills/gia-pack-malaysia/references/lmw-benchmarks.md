> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.

# Benchmark & Comparative Analysis Reference — Erawan Gas Cylinder Manufacturing

## Industry KPI Benchmarks

### Operational KPIs (Gas Cylinder Manufacturing)

| KPI | Formula | Erawan Target | Industry Benchmark | Source/Basis |
|----|--------|--------------|-------------------|-------------|
| Cylinder utilisation rate | COL cylinders ÷ Total fleet | ≥75% | 70–85% | Industry practice; Lincoln Industrial |
| Fill rate | Cylinders filled ÷ Fill capacity | ≥85% | 80–90% | CGA (Compressed Gas Association) |
| Retest compliance | Cylinders tested on time ÷ Total due | 100% | 100% | DOSH mandatory |
| Hydrostatic test pass rate | Passed tests ÷ Total tests | ≥95% | 90–97% | Industry; high pass rate indicates good maintenance |
| Cylinder condemnation rate | Condemned ÷ Total tested | <5% | 2–5% | Industry; rising rate = aging fleet |
| Gas shrinkage/loss (compressed) | (Fill wt − Dispatch wt) ÷ Fill wt | <0.5% | 0.2–0.5% | CGA; IGAM guidelines |
| Gas shrinkage/loss (LPG) | Same | <1.0% | 0.5–1.0% | Industry |
| Cylinder turnaround days | Avg COL days outstanding | 30–60 days | 30–90 days (customer-dependent) | Contract terms |
| Scrap/rejection rate | Cylinders scrapped ÷ Produced | <2% | 1–3% | Manufacturing norm |

### Financial KPIs (Malaysia Manufacturing Context)

| KPI | Formula | Benchmark | Notes |
|----|--------|-----------|-------|
| COGS % revenue | COGS ÷ Revenue | 55–70% | Gas cylinder mfg; steel-intensive |
| Gross margin | (Revenue − COGS) ÷ Revenue | 30–45% | Erawan vs. market competitors |
| Debtor days (DSO) | Trade AR × 365 ÷ Revenue | <45 days | Petronas 30-day; others 45–60 |
| Inventory days | Inventory × 365 ÷ COGS | 30–60 days | Cylinder fleet + raw materials |
| Cylinder deposit as % of revenue | Deposit liability ÷ Annual revenue | 10–25% | Varies by product mix |
| Export ratio | Export value ÷ Total production | ≥80% | LMW regulatory minimum |
| Local sales ratio | Local sales ÷ Total production | ≤20% | LMW regulatory maximum |
| Revenue per employee | Revenue ÷ Headcount | MYR 200–400K p.a. | Malaysian mfg sector median |

### Payroll Compliance KPIs

| KPI | Target | Regulatory Basis |
|----|--------|-----------------|
| EPF compliance rate | 100% | EPF Act 1991 |
| SOCSO compliance rate | 100% | SOCSO Act 1969 |
| Minimum wage compliance | 100% | Minimum Wages Order 2024 ([MY-003]) |
| OT within legal limit | 100% | EA 1955 s.60A |
| Ghost employee ratio | 0% | — |
| PCB remittance on time | 100% | ITA 1967 |

### LMW Compliance KPIs

| KPI | Target | Regulatory Basis |
|----|--------|-----------------|
| Export ratio | ≥80% | Customs Act 1967 s.65A |
| Local sales without MIDA approval | ≤20% | RMCD LMW conditions |
| M1/M2/M4 returns filed on time | 100% | LMW Appendix C conditions |
| LMW license renewed before expiry | Yes | Appendix C condition |
| All local sales with K9 + duty/SST paid | 100% | Customs Act + SST |

## Fraud Risk Indicators (Red Flags)

| Indicator | Threshold | Risk |
|----------|---------|------|
| Unaccounted cylinders (recon gap) | >0 (any gap) | 🔴 |
| Debtor days trend (quarter-on-quarter increase) | >15% QoQ increase | 🔴 |
| Gas shrinkage > benchmark | >0.5% compressed / >1% LPG | 🔴 |
| Deposit liability < (COL × deposit rate) | Any shortfall | 🔴 |
| Retest compliance <100% | Any overdue cylinder | 🔴 |
| Export ratio <80% | Any month below 80% | 🔴 |
| Credit notes > 2% of revenue | Rolling 12 months | 🟠 |
| Single-vendor procurement >60% spend | Any category | 🟠 |
| Cylinder utilisation <60% | | 🟠 |
| Fill rate <75% | | 🟠 |

## Peer Comparison (Malaysia Industrial Gas Sector)

### Major Gas Cylinder Manufacturers in Malaysia (public information)
- **Mega First Corporation Berhad** — diversified including gas
- **Gas Malaysia Berhad** (natural gas distribution)
- **Air Products Malaysia** — industrial gas, not cylinder mfg
- **PETRONAS Dagangan** — LPG distribution/filling
- **PaxAir / Linde Malaysia** — industrial gas, cylinder service

Benchmark against **Erawan's actual financials** vs. any available industry survey data (MIDA annual report, DOSM manufacturing statistics).

### DOSM (Department of Statistics Malaysia) Reference
- Annual Survey of Manufacturing Industries (ASMI) — sector-specific COGS ratios for fabricated metal products (HS Chapter 73)
- Verify at `dosm.gov.my`

## Regulatory Exposure Quantification Matrix

| Risk | Calculation Method | Maximum Penalty |
|------|------------------|----------------|
| LMW — understatement of local sales | Back-duty × 20 (RMCD Act s.135) | Up to 20× evaded duty |
| DOSH — overdue hydrostatic test | Fine per cylinder per violation | see [MY-048] |
| EPF late payment | see [MY-044] | Per KWSP Act |
| SOCSO late payment | see [MY-044] | Per SOCSO Act |
| SST non-compliance | see [MY-033] | Sales Tax Act 2018 |
| MACC s.17A corporate liability | Conviction → fine (no cap specified) | Unlimited; reputation risk |
| e-Invoice non-compliance (Phase 3) | Tax deductibility denied on expenses | Effective tax cost |
