> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- Industry KPI Benchmarks — Malaysia Automotive Die Casting / Stamping
- Fraud Red-Flag Thresholds (Malaysia Auto Parts Sector)


# Benchmark & Comparative Analysis Reference — MKPC Malaysia Die Casting & Stamping

## Industry KPI Benchmarks — Malaysia Automotive Die Casting / Stamping

### Process KPIs

| KPI | Formula | World-Class | Malaysia Tier 1 Typical | Benchmark Source |
|----|--------|------------|------------------------|----------------|
| **MTC — Al HPDC** | Good output kg ÷ Metal input kg | 70–78% | 65–75% | NADCA; industry practice |
| **MTC — Zn HPDC** | Same | 75–82% | 70–80% | NADCA |
| **MTC — Steel stamping** | Good part weight ÷ Coil input weight | 80–88% | 70–85% | OEM nesting plan |
| OEE (HPDC machine) | Availability × Performance × Quality | ≥85% | 65–80% | JIPM world-class 85% |
| OEE (Stamping press) | Same | ≥80% | 60–78% | Industry |
| Scrap rate (HPDC) | Scrapped units ÷ Total produced | <2% | 2–5% | NADCA |
| Scrap rate (Stamping) | Same | <3% | 3–7% | Industry |
| Die casting cycle time adherence | Actual ÷ Standard | ≤1.05 | 0.95–1.10 | Internal standard |
| Shot monitoring — velocity consistency (HPDC) | Std dev ÷ Mean velocity | <5% | 5–15% | NADCA process control |
| Furnace efficiency | Actual melt ÷ Energy input | >75% | 65–75% | Industry |

### Quality KPIs

| KPI | World-Class | Malaysia Tier 1 | Perodua Target | Denso Target |
|----|------------|----------------|---------------|-------------|
| Customer DPPM | <10 | 20–100 | <50 (typical) | <50 |
| Internal scrap rate | <1% | 1–3% | — | — |
| Supplier DPPM | <100 | 200–500 | — | — |
| First Pass Yield (FPY) | >98% | 95–98% | — | — |
| Cpk (critical chars) | ≥1.67 | ≥1.33 | ≥1.33 | ≥1.67 (safety parts) |
| 8D on-time response | 100% | 80–90% | 100% mandatory | 100% mandatory |
| OTIF | ≥99.5% | 95–99% | ≥98% | ≥98% |

### Financial KPIs (Malaysia Auto Parts Supplier Context)

| KPI | Formula | Benchmark | Notes |
|----|--------|-----------|-------|
| COGS % revenue | COGS ÷ Revenue | 65–80% | Al/steel-intensive; higher raw material % |
| Gross margin | (Revenue − COGS) ÷ Revenue | 20–35% | Malaysia Tier 1–2 range |
| EBITDA margin | EBITDA ÷ Revenue | 8–18% | Depends on automation level |
| Debtor days (DSO) | AR × 365 ÷ Revenue | <45 days | Perodua 30–45d; Denso 30–45d |
| Creditor days (DPO) | AP × 365 ÷ COGS | 30–60 days | Steel suppliers: 30–45d |
| Inventory days | Inventory × 365 ÷ COGS | 20–40 days | OEM JIT requirement |
| Revenue per employee | Revenue ÷ Headcount | MYR 150–350K | Depends on automation; higher for HPDC |
| Tooling capex % revenue | Tooling spend ÷ Revenue | 5–15% (new model years) | Lower in steady-state years |
| Al/Zn raw material % COGS | Metal cost ÷ COGS | 40–60% (Al HPDC) | Significant sensitivity to LME price |
| Steel raw material % COGS | Steel cost ÷ COGS | 35–55% (stamping) | Sensitivity to HRC/CRC price |

### Payroll & Statutory Compliance KPIs (2025 Verified Rates)

| Requirement | Current Rate/Threshold | Effective Date | Source |
|------------|----------------------|---------------|--------|
| Minimum Wage | [MY-003] | per register (by employer size) | MOHR gazette |
| EPF employer (lower wage band) | [MY-005] | per register | KWSP `kwsp.gov.my` |
| EPF employer (higher wage band) | [MY-005] | per register | KWSP |
| EPF employee | [MY-004] | per register | KWSP |
| EPF foreign workers (employer) | [MY-006] | per register | KWSP |
| EPF foreign workers (employee) | [MY-006] | per register | KWSP |
| SOCSO employer | [MY-008] | per register | PERKESO `perkeso.gov.my` |
| SOCSO employee | [MY-008] | per register | PERKESO |
| SOCSO/EIS wage ceiling | [MY-007] | per register | PERKESO |
| EIS employer | [MY-009] | per register | PERKESO |
| EIS employee | [MY-009] | per register | PERKESO |
| HRD Corp levy | per [MY-045] | Ongoing | HRD Corp |
| Max working hours | **45 hours/week** | 1 Jan 2023 | EA Amendment 2022 |
| OT eligibility | per Employment Act coverage [MY-001] | per register | EA 1955 |

### OEM Concentration Risk Thresholds

| Single Customer Revenue % | Risk Rating | COSO ERM Classification |
|--------------------------|------------|------------------------|
| <30% | 🟢 Low | Diversified |
| 30–50% | 🟡 Medium | Monitor; develop diversification plan |
| 50–70% | 🟠 High | Concentration risk; single OEM program discontinuation = significant P&L impact |
| >70% | 🔴 Critical | Existential risk; immediate board-level action required |

### Regulatory Exposure Quantification

| Non-Compliance | Maximum Penalty | Calculation |
|---------------|----------------|------------|
| SST non-declaration | see [MY-033] | Sales Tax Act 2018 |
| EPF late payment | see [MY-044] | EPF Act 1991 |
| SOCSO late payment | see [MY-044] | SOCSO Act 1969 |
| Minimum wage breach | Fine per employee per month | Minimum Wages Order |
| OSHA violation | see [MY-048] | OSHA Act A1648 |
| MACC s.17A corporate liability | Unlimited fine | MACC Act 2009 |
| IATF certificate suspension | Revenue at risk = OEM revenue × % of supply that requires IATF | Business continuity |
| TP adjustment (LHDN) | Back tax + penalty per [MY-039] (ITA s.140A) | ITA 1967 |
| e-Invoice non-compliance | Tax deductibility denied on expenses | Finance Act 2024 |

### Raw Material Price Benchmarks (April 2026 — Validate Before Use)

| Material | Indicative Price | Source to Verify |
|---------|----------------|-----------------|
| LME Aluminium (primary) | ~USD 2,200–2,600/tonne | `lme.com` |
| ADC12 (secondary alloy) | LME Al − USD 100–200 discount | Malaysia alloy suppliers |
| LME Zinc | ~USD 2,600–3,000/tonne | `lme.com` |
| Malaysia HRC (hot rolled coil) | MYR 2,800–3,500/tonne | MITI published; steel distributors |
| Malaysia CRC (cold rolled) | MYR 3,200–4,000/tonne | MITI / distributors |
| Al scrap (die cast clean) | ~MYR 3,500–5,000/tonne | Malaysia scrap dealer published |
| Steel scrap (HMS 1&2) | ~MYR 700–950/tonne | Malaysia scrap dealer published |

**Note:** Always verify current prices from portal sources at time of audit. Do not use indicative prices above as definitive figures.

## Fraud Red-Flag Thresholds (Malaysia Auto Parts Sector)

| Indicator | Threshold | Risk Level |
|---------|---------|-----------|
| MTC below benchmark | > 3% below lower bound | 🔴 |
| Scrap sale price vs. market | < 10% below market price | 🟠 |
| Scrap weight deviation (MKPC vs. dealer) | > 0.5% systematic shortfall | 🔴 |
| Credit notes > 2% of revenue | Rolling 12 months | 🔴 |
| DSO increase QoQ | > 15% | 🟠 |
| Ghost employee ratio | Any | 🔴 |
| Procurement sole-source > 60% by value in any category | — | 🟠 |
| Tooling capex invoice without physical die | Any | 🔴 |
| OT hours > 104 hours/month per employee | Any | 🟠 |
| Customer DPPM trend: 3 consecutive months increasing | — | 🟠 |
