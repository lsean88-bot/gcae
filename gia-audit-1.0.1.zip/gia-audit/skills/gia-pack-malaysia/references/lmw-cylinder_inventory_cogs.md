> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- Cylinder Classification Framework
- Bill of Materials (BOM) — Standard Cost per Cylinder Type
- Cylinder Population Reconciliation — Master Equation
- Cylinder Utilisation KPIs
- COGS Absorption — Manufacturing Overhead
- Scrap & Condemned Cylinder Controls
- Inventory Valuation — NRV Assessment (MFRS 102 / IAS 2)


# Cylinder Inventory, COGS & Utilisation Reference — Erawan

## Cylinder Classification Framework

Gas cylinders at Erawan exist in multiple states simultaneously — this is the core complexity of the audit:

| State | Location | Accounting Treatment |
|-------|----------|---------------------|
| **WIP cylinders** | Production floor | Inventory (MFRS 102 / IAS 2) |
| **Finished goods — yard** | Erawan compound | Inventory — Finished Goods |
| **Cylinders sold outright** | Customer premises | Revenue recognized; asset derecognized |
| **Cylinders on loan (COL)** | Customer premises | PPE or Financial Asset (if rental); deposit liability raised |
| **Cylinders on retest** | Test station | Inventory — restricted |
| **Condemned/scrapped cylinders** | Scrap yard / destroyed | Derecognize; recognize scrap value or loss |

**Critical determination:** Cylinder on loan vs. cylinder sold outright — drives:
- Revenue recognition (MFRS 15 / MPERS s.23)
- Deposit liability recognition
- PPE vs. Inventory classification
- Cylinder diversion fraud risk

## Bill of Materials (BOM) — Standard Cost per Cylinder Type

Typical BOM for a **standard 47kg LPG steel cylinder** (illustrative structure):

| Component | Unit | Estimated Cost Driver |
|----------|------|-----------------------|
| Steel tube (seamless / welded) | kg | Steel price (LME HRC/CRC) |
| End caps (dished heads) | pcs | Steel fabrication |
| Valve (CGA/BS standard) | pcs | Brass/SS valve cost |
| Foot ring / neck ring | pcs | Steel fabrication |
| Paint / coating | litres | Commodity price |
| Welding consumables | kg | Commodity |
| Gas fill (first fill for factory test) | kg | Gas price |
| Direct labour — forming, welding, testing | hours | Wage rate |
| Machine overhead — pressing, spinning, filling rig | hours | Absorption rate |
| QC / inspection cost | per unit | Overhead |

**BOM Audit Test:**
1. `[INS]` approved BOM per cylinder type → `[REC]` multiply component qty × unit cost = standard cost per cylinder
2. `[INS]` actual purchase invoices for top 3 components (steel, valve, paint) → actual unit cost
3. `[REC]` standard cost vs. actual cost variance analysis → explain material variances
4. `[ANA]` trend in COGS % of revenue → flag if COGS% rising without corresponding material price movement

## Cylinder Population Reconciliation — Master Equation

```
[Opening Cylinder Count by Type]
+ Cylinders Manufactured in Period          [INS: production register]
− Cylinders Sold Outright                   [INS: sales invoices + DOs]
− Cylinders Condemned/Scrapped              [INS: scrap authorization + DOSH disposal record]
= Theoretical Closing Count

Actual Closing Count:
  In-yard                                   [PHY: physical count]
+ On loan to customers                      [INS: COL register per customer]
+ At retest station                         [INS: retest batch register]
+ In transit (dispatched, not yet received) [INS: outstanding DOs]
= Actual Closing Count

Reconciling difference: Theoretical − Actual = Unaccounted cylinders → 🔴 FINDING if material
```

**Tolerance:** Zero tolerance for unaccounted cylinders — each cylinder has serial number.
Any gap = potential cylinder diversion, theft, or record-keeping failure.

## Cylinder Utilisation KPIs

### Utilisation Rate
```
Cylinder Utilisation Rate = Cylinders on Loan (COL) ÷ Total Cylinder Fleet × 100%
Industry benchmark: 70–85%
Below 60%: excess inventory / poor sales
Above 90%: capacity constraint; Erawan may need to manufacture more
```

### Fill Rate
```
Fill Rate = Cylinders filled in period ÷ Cylinder fill capacity available × 100%
Industry benchmark: >85%
Below 70%: production underutilisation (check: gas supply, manpower, maintenance downtime)
```

### Cylinder Turnaround (Days)
```
Cylinder Turn = Average cylinders on loan ÷ (Total cylinders dispatched ÷ Period days)
Industry benchmark: 30–90 days depending on customer type
Long turn = cylinders not being returned promptly → cash flow impact + deposit liability aging
```

### Gas Loss/Shrinkage
```
Gas Shrinkage % = (Total fill weight − Total dispatch weight) ÷ Total fill weight × 100%
Acceptable: <0.5% for compressed gas (O₂, N₂, CO₂); <1% for LPG
Excess shrinkage: valve leaks, fill meter inaccuracy, theft, unauthorized sampling
```

## COGS Absorption — Manufacturing Overhead

Standard overhead absorption for gas cylinder manufacturing:
- Based on **machine hours** (filling rig hours, pressing machine hours) or **direct labour hours**
- Monthly overhead rate = Budgeted overhead ÷ Budgeted hours
- Under/over-absorption = variance to P&L

**Audit test:** `[REC]` recalculate absorption rate; compare to actual overhead; flag material under/over-absorption
> Under-absorption > 10% of budgeted overhead = 🟠 High risk finding (overhead not properly matched to output)

## Scrap & Condemned Cylinder Controls

**Mandatory controls:**
1. Condemnation must be authorized by DOSH competent person + management
2. Written condemnation certificate per cylinder serial number
3. Physical destruction (cutting/crushing) witnessed; record with date, witness, serial numbers destroyed
4. DOE scheduled waste manifest (Borang SW) for disposed paint/rust materials from condemned cylinders
5. Scrap proceeds (steel weight × market price) recognized as other income; reconcile to scrap dealer's weight tickets

**Fraud risk:** Cylinders "condemned" on paper but sold undocumented → cylinder diversion fraud
**Test:** `[PHY]` verify condemned cylinder serials are physically present (quarantined or destroyed) at audit date

## Inventory Valuation — NRV Assessment (MFRS 102 / IAS 2)

| Inventory Category | NRV Test |
|-------------------|---------|
| Finished cylinders — standard products | Selling price − estimated selling costs |
| Obsolete cylinder types (discontinued) | Realizable value as scrap if no market |
| WIP cylinders | Expected completion cost to finish + selling price |
| Raw material (steel) | Replacement cost as proxy for NRV if finished goods are profitable |

MFRS 102 para 34: If NRV < cost → write down to NRV; recognize loss in P&L.
`[ANA]` flag inventory items with no movement >90 days → impairment assessment required.
