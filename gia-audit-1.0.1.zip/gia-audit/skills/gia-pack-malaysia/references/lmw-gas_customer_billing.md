> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- Customer Types & Billing Structures
- Cylinder Deposit Scheme — Critical Accounting Issue
- Collection Controls & Fraud Risks
- Regulatory — e-Invoice (MyInvois) Impact on Billing


# Gas Customer Billing, Collection & Cylinder Deposit Reference — Erawan

## Customer Types & Billing Structures

### 1. Petronas / O&G Customers (Highest-value segment)
**Vendor Requirements:**
- Must hold valid **PETRONAS License** via PLMS (Petronas License Management System — `plms.petronas.com`)
- License scope must match products: industrial gas cylinders, LPG cylinders, compressed gas
- Procurement via **GEP SMART™** (Unified Procurement Platform) for PETRONAS subsidiaries
- Purchase orders raised in GEP SMART; invoice submission through Supplier Self Service (SUS) or GEP SMART

**Billing Cycle:**
- Standard: 30-day payment terms from invoice date (verify per contract)
- Consolidated monthly invoice vs. per-delivery invoice (contract-specific)
- 3-way match required: **Purchase Order + Delivery Order + Invoice**

**DO Reconciliation Risk:**
- Deliveries made without PO (emergency/verbal authorization) — high risk of unbilled revenue
- DO not invoiced within billing period = revenue completeness risk

### 2. Industrial Gas Distributors
- Typically framework agreement or spot purchase
- DO-based billing; payment 30–60 days
- May use consignment model (cylinders placed at distributor; billed on fill/dispatch)

### 3. Direct End-Users (SME / institutional)
- Retail or contracted; possibly cash on delivery for smaller customers
- Higher collection risk; manual receipting → cash misappropriation risk

## Cylinder Deposit Scheme — Critical Accounting Issue

### Commercial Purpose
Cylinder deposit is a refundable security deposit charged to the customer to:
- Secure return of the cylinder (high asset value — MYR 150–800+ per cylinder depending on type/size)
- Incentivize cylinder turnaround

### Accounting Treatment (MFRS 15 / IAS 15 / MPERS Section 23)
**CRITICAL:** Cylinder deposit received from customer is a **FINANCIAL LIABILITY (refundable)**
- NOT revenue
- NOT deferred revenue
- Classified under: Current Liabilities (if short-term) or Non-Current Liabilities (if long-term)

**Deposit asset paid to gas supplier** (where Erawan is the buyer/customer):
- Classified as **Financial Asset** (receivable)

**Common misclassification errors:**
- Posting deposit as revenue → overstatement of revenue
- Posting deposit as deferred revenue → incorrect but less severe than revenue
- Not recording deposit at all → off-balance-sheet liability

**Deposit Reconciliation — Full Population Test:**
```
Opening deposit liability balance
+ Deposits received during period     [per cash receipts + invoice]
− Deposits refunded during period     [per bank payments]
= Closing deposit liability balance   [per GL]
Cross-check: Closing balance must equal cylinder serial register × deposit rate per cylinder type
```

**Audit Test:**
1. `[INS]` deposit schedule per customer contract → extract deposit rate per cylinder type
2. `[INS]` cylinder serial register (all cylinders on loan to customers) × deposit rate = expected deposit liability
3. `[CON]` circularize top 10 customers by deposit balance → confirm cylinder quantity on loan + deposit held
4. `[ANA]` flag: customers where cylinders returned but deposit not refunded (unearned liability)
5. `[ANA]` flag: cylinders on loan but no deposit recorded (completeness failure)

### Cylinder Rental Charges
- Where cylinders are rented (not sold outright): daily/monthly rental rate per cylinder
- Revenue recognized over rental period (straight-line if no variable element)
- `[REC]` Rental revenue = cylinders on loan × rental rate × days ÷ 365 × period rate

### Retest / Re-certification Charges
- At 5-year hydrostatic test: some contracts allow Erawan to charge customer for retest
- `[INS]` contract clause; `[INS]` test certificate vs. retest invoice — verify all tested cylinders billed

## Collection Controls & Fraud Risks

### Ageing Analysis
| Bucket | Concern | Action |
|--------|---------|--------|
| 0–30 days | Normal | Monitor |
| 31–60 days | Watch | Payment follow-up |
| 61–90 days | Elevated | Formal demand |
| >90 days | High risk | Provision assessment under MFRS 9 ECL |

**Petronas subsidiaries:** Typically pay within 30 days; delays often system/approval holds in GEP SMART.

### Key Fraud Risks
1. **Collection diversion:** Cash/cheque payment from customer intercepted before banking; receipt issued but cash pocketed
2. **Deposit misappropriation:** Deposit collected and recorded in customer account but not deposited; personal use
3. **Fictitious credit notes:** Credit notes issued to reduce AR without valid return/complaint; cash side-payment to customer contact
4. **Lapping:** Customer A's payment applied to Customer B to conceal overdue; aging artificially suppressed
5. **Cylinder rental free-issue:** Cylinders issued to related parties / favored customers without rental charge

### Detection Tests
- `[ANA]` Benford on invoice amounts — flag abnormal digit distribution
- `[ANA]` Cash receipts — compare bank deposit slips to cash receipt entries; time gap analysis
- `[CON]` Direct customer confirmation (AR circularization) — top 10 by balance + all overdue >90 days
- `[ANA]` Credit notes — all credit notes to single customer; credit notes just below approval threshold
- `[ANA]` DO-Invoice gap analysis — DOs not invoiced within 14 days flag as completeness risk

## Regulatory — e-Invoice (MyInvois) Impact on Billing
- **Phase 3 (1 Jul 2025):** Turnover band per [MY-020] must issue validated e-invoices
- Finance Act 2024: Tax deductibility of expenses conditioned on validated e-invoice from supplier
- For Erawan: All sales invoices must be submitted to MyInvois portal; validated with QR code before issuance to customer
- **Audit test:** `[CON]` MyInvois portal — verify all invoices in period have validated status; spot-check QR codes on sample
