> Case figures from a prior clinic engagement were moved to example-2026-Q1.md (illustrative, dated).

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.

# Reference B — Revenue, POS & Panel Billing

## B1 — Revenue Recognition (MFRS 15)

**Standard:** MFRS 15 Revenue from Contracts with Customers (effective FY2018+)

[case figure moved to example-2026-Q1.md]
| Stream | Recognition Point | Control Risk |
|--------|------------------|-------------|
| Walk-in cash | Point of service delivery | Cash diversion |
| Walk-in bank/card | Point of service delivery | Card reversal, day-end reconciliation |
| Panel billing (MiCare, AIA, SOCSO, corporate) | On invoice/claim submission, adjusted to expected collectible | Over/under-billing, rejected claims |
| Management fee (interco) | Monthly accrual per agreement | Related-party terms — need formal agreement |
| Rental income (interco) | Monthly accrual per tenancy | Related-party — need formal tenancy agreement |

### POS-to-GL Reconciliation Tests
| Test | Evidence | Assertion |
|------|---------|-----------|
| POS total fees vs GL Net Sales — monthly tie-out | `[REC]` POS export vs GL P&L by month | CO, AC |
| Panel claims submitted vs GL panel revenue | `[REC]` panel claim registers vs GL | CO |
| Cash POS collections vs bank deposits | `[REC]` POS cash payments vs bank statement receipts | CO, EX |
| Card payments vs merchant settlement | `[REC]` POS card vs merchant statements | CO |
| Cancelled/reversed POS entries — authorisation log | `[INS]` POS cancellation log | AU |
| Revenue per encounter trend analysis | `[ANA]` Monthly revenue ÷ encounters (flag >±25% month variance) | AC |
| Benford's Law on POS FeesAmount (n≥500) | `[ANA]` First-digit distribution vs log10(1+1/d) | OC, AC |

### Three-Way Reconciliation Framework
```
POS Total Fees Billed
  Less: POS returns/cancellations
= Net POS Billable
  [±] Timing: panel invoices accrued in GL not yet in POS
  [±] Manual GL entries bypassing POS
= GL Net Sales
  Confirm: Balance to bank deposits + AR movement
```

---

[case figure moved to example-2026-Q1.md]

| Panel | Billing Basis | Key Risk | Settlement Terms |
|-------|--------------|----------|-----------------|
| MiCare Sdn Bhd | Per-encounter claim | High volume / largest panel — overbilling, phantom claims | Monthly or per claim |
| AIA Berhad | Per-encounter claim | Coding accuracy | Per claim |
| SOCSO (PERKESO) | Approved tariff per procedure code | Must use approved ICD-10 codes; tariff cap applies | Monthly batch claim |
| PM Care Sdn Bhd | Per-encounter | Overdue >3 months — collectibility | Per claim |
| Corporate panels (China Communications, Propel Global, etc.) | Per-encounter | Concentration risk; single-company dependence | 30–60 days |
| Named individual (VIP / special panel) | Special panel / VIP arrangement | No formal credit policy sighted; governance risk if fee concessions | Unknown |

### Panel Billing Audit Tests
| Test | Evidence | Assertion |
|------|---------|-----------|
| Panel claim submissions agree to POS encounter records | `[REC]` claim register vs POS data by encounter ID | CO, AC |
| Received panel payments match AR aging | `[REC]` bank receipts vs panel AR | CO |
| Panel invoices issued with compliant SST breakout (post-01 Sep 2025 for non-citizens) | `[INS]` sample panel invoices | CP |
| Overdue panel balances reviewed and escalated | `[INS]` AR aging + collections correspondence | VA |
| No split billing (same patient, same visit, billed across multiple panels) | `[ANA]` patient ID cross-reference by date | OC |
| Phantom claims: panel claims for dates with zero POS encounters | `[REC]` claims vs POS date match | OC |

### Largest-panel risk
Test the largest panel's claim submission log against POS encounters (full population), service codes against the licensed scope, and the basis and recoverability of any service charges.

---

## B3 — High-value procedure revenue

Test every high-value procedure line (for example cell-therapy encounters) from the POS population: confirm the procedure is within the licensed scope, the practitioner holds the required credentialing, the payer (cash or panel) and amount agree to the receipt and bank deposit, and revenue recognition under MFRS 15 is supportable. Revenue for a service not lawfully provided is at risk of reversal. Name no patient in the working paper unless the report profile permits it.

---

## B4 — Revenue Benchmarks (Malaysian Private Clinic)

[table moved to example-2026-Q1.md]
