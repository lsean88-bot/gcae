> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- Governing Legislation
- EPF Contribution Table (2025)
- SOCSO Contribution Table (current ceiling per register)
- EIS Contribution (current ceiling per register)
- HRD Corp (HRDF)
- Employment Act 1955 — Key Manufacturing Provisions (Post EA Amendment 2022)
- Foreign Worker Compliance
- 4-Way Headcount Reconciliation — Template
- PCB/MTD Calculation Reference


# Employment & Statutory Payroll Reference — MKPC Malaysia (2025 Web-Validated)

## Governing Legislation

| Statute | Current Status | Key Recent Change |
|---------|--------------|-----------------|
| Employment Act 1955 (EA) | Amended by Act A1651 (EA Amendment 2022); effective **1 Jan 2023** | Universal coverage; 45hr week; paternity leave; FWA; domestic violence leave |
| EPF Act 1991 | Multiple amendments | Employer rate [MY-005]; foreign workers [MY-006] |
| SOCSO Act 1969 | Amendment 2022 (Act A1658) | Insurable wage ceiling [MY-007] |
| EIS Act 2017 | Amendment 2022 (Act A1657) | Insurable wage ceiling [MY-007] |
| HRD Corp Act 2001 | — | levy per [MY-045] |
| Minimum Wages Order 2024 | Gazetted | [MY-003]; effective dates by employer size in the register |
| ITA 1967 — PCB/MTD | — | CP39 by 15th of following month |

## EPF Contribution Table (2025)

| Employee Category | Employer Rate | Employee Rate | Effective |
|-----------------|-------------|-------------|---------|
| Malaysian/PR < 60, wages ≤RM5,000 | **13%** | 11% | Current |
| Malaysian/PR < 60, wages > RM5,000 | 12% | 11% | Current |
| Malaysian/PR aged 60–75 | 4% | 0% | Current |
| **Foreign worker (employment pass holder)** | **2%** | **2%** | **Oct 2025 wages onward** |
| Foreign worker (before Oct 2025) | RM5.00 flat (employer voluntary) | Exempt | Pre-Oct 2025 |

**Late payment penalty:** per [MY-044] (EPF Act s.47/48)
**Deadline:** By 15th of the following month

## SOCSO Contribution Table (current ceiling per register)

| Employee Category | Employer Rate | Employee Rate | Wage Ceiling |
|-----------------|-------------|-------------|-------------|
| Malaysian/PR, age <60 (EI + Invalidity) | per [MY-042] | per [MY-042] | [MY-007] |
| Malaysian/PR, age ≥60 (EI only) | per [MY-042] | per [MY-042] | [MY-007] |
| Foreign workers (EI only, no Invalidity) | per [MY-042] | per [MY-042] | [MY-007] |

**Transition:** any grace period after a ceiling change is stated in the PERKESO notice cited in [MY-007]; confirm before relying on it

## EIS Contribution (current ceiling per register)

| Eligibility | Rate (Each) | Ceiling |
|-----------|-----------|--------|
| Malaysian/PR, age 18–60 | [MY-009] | [MY-007] |
| Foreign workers | Not applicable (EIS for Malaysian/PR only) | — |
| Age ≥60 | Not applicable | — |

## HRD Corp (HRDF)

- **Mandatory:** Manufacturing companies with ≥10 Malaysian employees
- **Rate:** 1% of monthly wages of Malaysian employees
- **Deadline:** 15th of following month
- **Purpose:** Employer can claim back for approved training courses via HRD Corp portal
- **Audit test:** `[CON]` HRD Corp portal — verify levy payments; `[INS]` training claims submitted vs. levy paid (under-claiming = opportunity cost; non-payment = non-compliance)

## Employment Act 1955 — Key Manufacturing Provisions (Post EA Amendment 2022)

### Working Hours (Universally Applied from 1 Jan 2023)
- Maximum: **45 hours/week** (reduced from 48 hours — EA Amendment 2022)
- Daily cap: 8 hours per day (with OT: 12 hours including OT)
- Applicable to ALL employees regardless of salary (coverage extended by EA 2022)

### Overtime
- **Coverage:** per Employment Act coverage [MY-001]
- OT rate: 1.5× hourly rate (ordinary day OT)
- Rest day OT: 2× hourly rate
- Public holiday: 3× hourly rate
- **Maximum OT:** Verify current gazette (previously 104 hours/month — confirm current limit)

### Leave Entitlements (Post EA 2022)
| Leave | Entitlement |
|------|------------|
| Annual leave | 8 days (<2 years); 12 days (2–5 years); 16 days (>5 years) |
| Sick leave (outpatient) | 14 days (<2 years); 18 days (2–5 years); 22 days (>5 years) |
| Sick leave (hospitalization) | 60 days additional |
| **Maternity leave** | **98 days** (EA Amendment 2022 — increased from 60 days) |
| **Paternity leave** | **7 days** (EA Amendment 2022 — **new**; Malaysia's first statutory paternity leave) |
| **Domestic violence leave** | **5 days** (EA Amendment 2022 — new) |

### New EA 2022 Compliance Requirements (Audit checklist)
☐ Written employment contract for all employees (no exceptions from 1 Jan 2023)
☐ Itemized payslip issued monthly to all employees
☐ Flexible Working Arrangement (FWA) policy documented — employer must respond within **60 days** to FWA request
☐ Sexual harassment policy and complaint procedure
☐ Domestic violence leave policy
☐ Forced labour prohibition — employer must not retain employee's travel documents (s.90A EA)
☐ Employees above the coverage threshold in force for the period: confirm coverage [MY-001] before treating any group as exempt from OT provisions

## Foreign Worker Compliance

### Work Authorization Types (Malaysia)
| Type | Category | Authority |
|-----|---------|---------|
| Employment Pass (EP) | Expatriate/professional | MDEC / Immigration Department |
| Temporary Employment Visit Pass (PLKS/VDLK) | Semi-skilled/unskilled manufacturing | JTK (Department of Labour) via Ministry of Home Affairs |
| Professional Visit Pass (PVP) | Short-term specialist | Immigration Department |

### JTK Registration & Notification
- Employer must register foreign workers with JTK (Jabatan Tenaga Kerja)
- Any change in foreign worker count: notify JTK within prescribed timeframe
- Foreign worker annual levy paid to Immigration Department (rate varies by source country)

### EPF for Foreign Workers — Oct 2025 (Critical New Requirement)
- **Effective October 2025 wages** (November 2025 contribution): Mandatory EPF per [MY-043]
- Applies to: Employment Pass holders, Professional Visitor Pass holders, Residence Pass holders, certain other valid work permits
- KWSP: Registration of foreign workers as EPF members (mostly automatic for EP holders)
- **Audit test:** `[CON]` KWSP i-Akaun employer — verify all non-Malaysian employees with Oct 2025+ wages have EPF contributions at the [MY-043] rates; flag any omissions

## 4-Way Headcount Reconciliation — Template

| Register | Source | Evidence Tag | Expected Count |
|---------|-------|------------|--------------|
| EPF employer register | KWSP i-Akaun (portal extract) | `[CON]` Rank 1 | [X] |
| SOCSO employer register | PERKESO ASSIST (portal extract) | `[CON]` Rank 1 | [X] |
| Payroll register | ERP/payroll system extract | `[INS]` Rank 3 | [X] |
| Physical/access card | Biometric/access system | `[OBS]`/`[INS]` Rank 2–3 | [X] |

**Reconciling items to investigate:**
- In EPF but not in payroll: ghost EPF registration or terminated employee not removed
- In payroll but not in EPF: EPF non-remittance fraud or exempt category (explain)
- In payroll but not in SOCSO: SOCSO evasion (exposing employee to unprotected risk)
- In payroll but no access card swipes in pay period: potential ghost employee

## PCB/MTD Calculation Reference

- Calculated per LHDN Monthly Tax Deduction (MTD) table or computerized calculation
- Non-resident employees: flat **30%** on total employment income
- **Deadline:** CP39 submission + payment by **15th of the following month**
- **LHDN penalty for late remittance:** per [MY-044]
- **Audit test:** `[CON]` LHDN MyTax portal — verify all CP39 submissions current; `[REC]` recalculate MTD for sample of 10 employees using official MTD calculator
