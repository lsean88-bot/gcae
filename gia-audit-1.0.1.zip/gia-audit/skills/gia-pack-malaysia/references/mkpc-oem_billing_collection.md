> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- Perodua (P2) Supply Chain — Billing & Collection
- Denso Supply Chain — Billing & Collection
- Foreign OEM / Tier 1 Customers — Additional Considerations
- DO-Invoice Completeness Reconciliation (Full Population)
- AR Aging & Collection Analysis
- Fraud Risks in Billing & Collection


# OEM Customer Billing, DO Reconciliation & Collection Reference — MKPC

## Perodua (P2) Supply Chain — Billing & Collection

### Perodua Supplier Framework (P2SA)
- **Perodua Suppliers Association (P2SA):** 129+ members; annual performance review
- Perodua is Malaysia's #1 car manufacturer; 358,102 vehicles registered in 2024 (MAA)
- Suppliers are subject to Perodua's annual cost-down target (typically 2–5% YoY price reduction)
- Perodua known for **prompt payment** — P2SA President quoted "prompt payments, clear directions" (Jan 2025)
- Payment terms: typically **30–60 days** from invoice date (verify current APA)

### Perodua Billing Cycle
1. Perodua issues rolling production forecast → MKPC MRP
2. Perodua issues firm Kanban/production order → MKPC produces
3. MKPC dispatches with Delivery Order (DO) + supplier DO number
4. Perodua GRN confirms receipt + IQC acceptance
5. MKPC issues invoice after confirmed GRN (not on dispatch)
6. Payment by Perodua within APA payment terms (EFT/cheque)

**Key audit risk:** MKPC invoices on dispatch date, not GRN confirmation date → premature revenue recognition (MFRS 15 — control passes at customer acceptance for inspection-required parts, not dispatch)

**Annual Price Revision:**
- APA specifies annual price: base price + steel/Al surcharge formula
- **Surcharge = (Current steel index − Base steel index) × Steel content per part × Agreed sharing %**
- Audit: `[REC]` recalculate surcharge entitlement vs. invoiced; exposure = difference × volume

### Perodua-Specific Audit Tests

| Test | Risk | Evidence |
|------|------|---------|
| Customer-issued OTIF scorecard ≥98% | Penalty clause risk | `[CON]` Perodua portal / formal scorecard |
| Warranty claim reconciliation — Perodua deductions vs. MKPC provisions | Understatement of liability | `[CON]` Perodua warranty claim statements; `[INS]` MKPC provision |
| APA price vs. invoiced price — 100% population | Revenue leakage or overbilling | `[REC]` full population price reconciliation |
| Annual cost-down — correctly applied from effective date | Revenue completeness | `[INS]` APA amendment letter + effective date |

## Denso Supply Chain — Billing & Collection

### Denso Context
- Denso Corporation (Japan) is a global Tier 1 automotive supplier; Malaysian operations supply Perodua and other OEMs via Denso Manufacturing Malaysia (DMMY) and affiliates
- Denso operates on **Daihatsu Production System (DPS)** — lean manufacturing, JIT
- Denso SQA (Supplier Quality Assurance) Manual: zero-defect philosophy; supplier 8D response within 24 hours for quality issues
- Payment terms: typically **30–45 days** (Japanese style — monthly cut-off + payment run)

### Denso Billing Mechanics
1. Denso issues EDI demand forecast (830 schedule) + firm release (862)
2. MKPC fulfils per Kanban → delivers to Denso DC/line-side
3. Denso electronic goods receipt → triggers invoice
4. Monthly consolidated invoice (cut-off typically 25th or last day of month)
5. Payment within terms

**Key audit risk:** Month-end cut-off — parts delivered before month-end but not receipted until next period → DO-invoice gap; revenue completeness risk

### Transfer Pricing Risk — Denso
If Denso Malaysia is a **related party** of MKPC (via MK Tron Group or shareholder overlap):
- All transactions with Denso Malaysia entities → subject to ITA s.140A TP Rules
- Arm's length price = APA price must be benchmarked vs. independent Tier 1 suppliers
- TP documentation must be maintained; LHDN TP audit risk is real for Japanese-related entities

## Foreign OEM / Tier 1 Customers — Additional Considerations

### Cross-Border Invoicing
- Invoice in USD/JPY for exports → MFRS 121 FX translation
- FX risk: USD/MYR fluctuation → hedging via BNM-licensed bank forward contracts
- Audit: `[INS]` FX hedge policy; `[INS]` forward contracts vs. USD exposure; `[REC]` FX P&L vs. hedge effectiveness

### SST on Exports
- **Exports are zero-rated for Sales Tax** (s.21 STA 2018; Schedule A STO 2018)
- Verify export evidence: customs K2 / shipping bill / Bill of Lading per shipment
- If export not evidenced: SST liability reverts to full rate → `[REC]` exposure = revenue × applicable SST rate

### Revenue Recognition — MFRS 15 (MPERS s.23) — OEM Specific

| Contract Type | Revenue Recognition Point | Audit Evidence |
|--------------|--------------------------|----------------|
| Standard delivery (F.O.B. factory) | DO signed by customer logistics | `[INS]` signed DO date |
| CIF delivery (freight included) | Port of destination arrival | `[INS]` Bill of Lading + POD |
| Consignment | When customer withdraws from consignment stock | `[INS]` withdrawal notice |
| Bill-and-hold | Only if strict MFRS 15.B81 criteria met (rare) | `[INS]` written customer request + storage segregation |

## DO-Invoice Completeness Reconciliation (Full Population)

**Required test — all periods:**
```
Step 1: Extract all DOs issued from ERP/WMS (by date range, all customers)
Step 2: Extract all sales invoices from ERP
Step 3: Match DOs to invoices by DO number
Step 4: Identify DOs with no corresponding invoice = Unbilled revenue risk
Step 5: Identify invoices with no corresponding DO = Fictitious invoice risk
Step 6: Quantify unbilled revenue = unbilled DOs × unit price from APA
```

**Flags:**
- DO-Invoice gap >5 business days: 🟠 High — cut-off risk or billing control weakness
- DO with no invoice after 30 days: 🔴 Critical — completeness failure or deliberate suppression

## AR Aging & Collection Analysis

| Aging Bucket | Perodua | Denso | Foreign OEM | Action |
|-------------|---------|-------|------------|--------|
| 0–30 days | Normal | Normal | Normal | Monitor |
| 31–60 days | Watch | Watch | Watch | Follow-up |
| 61–90 days | Elevated | Elevated | Elevated | Formal demand |
| >90 days | 🔴 Provision | 🔴 Provision | 🔴 Provision | MFRS 9 ECL; legal |

**MFRS 9 ECL (Expected Credit Loss):** Perodua and Denso are creditworthy; provision rate may be low (<1%) for current receivables. Foreign OEMs — assess individually.

**AR Circularization:** Mandatory for top 10 customers by balance + all >90 days overdue. Use SA 505 format (written confirmation only; verbal not accepted).

## Fraud Risks in Billing & Collection

| Risk | Description | Detection |
|------|------------|---------|
| **Lapping** | Customer A's payment applied to Customer B to conceal overdue | `[ANA]` bank receipt date vs. GL posting date; AR sub-ledger sequencing |
| **Fictitious credit notes** | Credit note to customer without valid return; cash payment to buyer | `[INS]` credit note + underlying complaint; `[CON]` customer confirmation |
| **Unauthorised discount** | Salesperson gives unapproved price discount; pockets cash from customer | `[ANA]` invoice price vs. APA price; customer confirmation |
| **Collection diversion** | Cheque payment intercepted before banking | `[CON]` bank statement vs. AR receipt ledger; timing analysis |
| **Duplicate invoicing** | Same DO invoiced twice | `[ANA]` duplicate DO number in invoice register |
