> Case figures from a prior clinic engagement were moved to example-2026-Q1.md (illustrative, dated).

> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.

# Reference G — Cash, Bank & Treasury Controls

## G1 — Cash Control Framework

[case figure moved to example-2026-Q1.md]
|---------|--------------|-----------|------|
| Daily banking — all cash banked same day | Industry standard | 320-002 balance RM 17,695 at 31 Mar 2026 | 🟠 |
| Dual custody for cash collections | Two staff count and sign | Not confirmed | 🟠 |
| POS end-of-day Z-report vs physical cash count | Daily reconciliation | Not confirmed | 🟠 |
| Cash drawer per clinic per shift | No co-mingling | Not confirmed | 🟡 |
| Bank reconciliation — monthly, independent | CFO review | Not provided for audit | 🔴 |
| Petty cash imprest system — fixed float | Periodic reimbursement | 320-001 negative RM 720 (Jodia) | 🟡 |
| Surprise petty cash counts | Quarterly minimum | Not confirmed | 🟡 |

## G2 — Audit Tests: Cash & Bank

| Test | Evidence | Assertion |
|------|---------|-----------|
| Bank confirmation — HLB balance at 31 Mar 2026 | `[CON]` bank confirmation letter or portal | EX |
| Bank reconciliation for all accounts | `[INS]` bank recon | AC |
| POS cash collections → daily banking trace | `[REC]` POS cash × date vs bank deposits | CO |
| 320-002 Cash Sales cleared post period | `[INS]` bank deposit slip post Mar 2026 | EX |
| Contra account 320-003 RM 944 — nature and clearance | `[INS]` GL entry narrative + supporting document | OC |
| Petty cash Jodia — physical count + reconciliation | `[PHY]` count + `[INS]` imprest record | EX |
| Bank charges — verify against bank statement | `[REC]` GL bank charges vs bank statement | AC |
| Bank mandate — current authorised signatories | `[INS]` bank mandate | AU |
| Foreign currency transactions (e.g. NEUROPRO) | `[INS]` FX conversion records + BNM AML threshold | CP |

---

# Reference H — Inventory, Pharmacy & Poisons Act Compliance

## H1 — Legal Framework

| Law | Requirement |
|-----|-------------|
| Poisons Act 1952 (Act 366) | Registered pharmacist or licensed medical practitioner must maintain a Poisons Register for all Scheduled drugs |
| Dangerous Drugs Act 1952 (Act 234) | Schedule I/II/III controlled drugs — separate register, dual-key cabinet, AADK reporting |
| Control of Drugs and Cosmetics Regulations 1984 | Only DCA-registered products may be dispensed |
| Sale of Drugs Act 1952 | No adulterated, counterfeit, or expired drugs may be sold |
| PHFSA 1998 regulations | Drug storage standards at registered clinic |

## H2 — Inventory Audit Tests

| Test | Evidence | Assertion |
|------|---------|-----------|
| Physical stock count — all pharmacy inventory | `[PHY]` count sheets with independent witness | EX |
| Count vs SQL Accounting stock balance (330-000) | `[REC]` count total vs RM 137,171.45 | EX, VA |
| FIFO valuation — check no expired stock at front | `[PHY]` expiry date check | VA |
| Poisons Register — all Schedule drugs recorded | `[INS]` Schedule B/C/D Poisons Register | CP |
| Dangerous drug register — if any Schedule I/II | `[INS]` DD register + dual-key cabinet count | CP |
| Cold chain — fridge temp log for biologics/vaccines | `[PHY]` fridge log + min-max thermometer | CP |
| Write-off of expired stock with approval | `[INS]` write-off authorisation | AU |
| Purchase invoices → GRN → stock movement | `[REC]` 3-way match | CO |
| Opening stock ≠ closing stock in months where purchases occurred | `[REC]` COGS calculation | AC |

[case figure moved to example-2026-Q1.md]

---

# Reference I — Fraud Risk, Benford's Law & ACFE Analytics

[case figure moved to example-2026-Q1.md]

[case figure moved to example-2026-Q1.md]
|---------------|--------------|-----------------|
| Asset misappropriation — cash | Cash sales undeposited; till skimming | 320-002 RM 17,695 unbanked |
| Asset misappropriation — inventory | Drug theft; counterfeit drug substitution | Static inventory balance |
| Billing fraud | Phantom panel claims; upcoded procedures | Cell therapy RM 262,583 — all single practitioner |
| Payroll fraud | Ghost employees; fictitious allowances | Allowances spike Mar-26 RM 15,629 vs avg RM 12,000 |
| Expense reimbursement | Personal travel expensed; unsupported claims | Travel Mar-26 RM 11,757 (56% of YTD) |
| Financial statement fraud | Revenue manipulation; provision reversal | Marketing fee RM 14,800 — 100% in one month |
| Corruption — kickbacks | Patient referral fees; vendor rebates | the sole practitioner sole cell therapy practitioner |
| Corruption — conflict of interest | Related-party transactions without disclosure | [related-party review panel]; director account |

## I2 — Digit-distribution protocol

Populations: POS fee amounts, GL journal entry amounts, AP invoice amounts, payroll gross amounts. Benford and digit tests: run through `gia-fraud:gia-fraud-analytics` (Nigrini MAD primary with per-digit z-scores; chi-square supplementary for small populations). Confirm the preconditions (population size, range across orders of magnitude, no assigned or bounded numbers), segment fixed-amount populations first, and record the MAD table version in the workpaper. A deviation is an indicator, never a conclusion. Inline thresholds from the retired source were removed.

## I3 — Additional Analytical Procedures

| Test | Method | Flag |
|------|--------|------|
| Round number test | % of fees exactly divisible by 1,000 vs 100 | >15% of round numbers = potential manipulation |
| Same-amount test | Duplicate fee amounts across different patients on same date | Any cluster = phantom billing risk |
| Weekend encounter anomaly | Count encounters on PHFSA-closed days | All are potential licence breach and irregular |
| Single-practitioner revenue concentration | Largest single practitioner share of total by month | >55% consistently = key-person + concentration |
| Unusual journal entries | Month-end JVs >RM 10,000 with no supporting document | All flagged for inquiry |
| Vendor recurrence | AP invoices from vendor registered within 3 months of first invoice | Flag all new vendors |
