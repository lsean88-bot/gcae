> Ported source text. Any rate, threshold or effective date in this file is historical and [UNVERIFIED]; the authoritative values are in statutory-register-malaysia.md. Evidence ranking uses the canonical R1-R5 scale in gia-core:iron-rules. Benford and digit tests: use gia-fraud:gia-fraud-analytics (MAD primary), not inline thresholds.
## Contents
- Business, Operational, Financial, Compliance & Governance Audit
- STEP 0 — Evidence Standards (Non-Negotiable)
- STEP 1 — Entity Context Checklist
- STEP 2 — Domain Reference Files
- STEP 3 — Assertion Codes
- STEP 4 — Finding Format
- Step 5 — Report structure
- STEP 6 — 2025–2026 Regulatory Changes Checklist (CRITICAL — AUDIT EVERY ENGAGEMENT)
- STEP 7 — Presentation Standards (L99 Rule)
- STEP 8 — Validation Rules


# my-phc-clinic-audit v2.0 — Malaysian Private Multi-Specialty Clinic
## Business, Operational, Financial, Compliance & Governance Audit

**Entity context:** Perfect Healthcare Sdn Bhd (202201028578) and comparable Malaysian private clinic groups.
**Standard:** IIA Global Internal Audit Standards (GIAS) 2024 | COSO ERM 2017
**Updated:** May 2026 — incorporates 2025–2026 regulatory changes researched and verified.

---

## STEP 0 — Evidence Standards (Non-Negotiable)

| Tag | Source Type | Reliability |
|-----|-------------|-------------|
| `[CON]` | Regulatory portal / bank / independent confirmation | Highest |
| `[PHY]` | Physical observation / stock count / site inspection | High |
| `[INS]` | Document inspection (licence, contract, invoice, register) | Medium-High |
| `[REC]` | Mathematical reperformance / recalculation | High |
| `[ANA]` | Analytical procedures / Benford's Law / trend analysis | Medium |
| `[REP]` | Management-prepared reports (POS, payroll, aging) | Medium |
| `[OBS]` | Process observation | Medium |
| `[INQ]` | Inquiry only — NEVER stand-alone | Lowest |

**Rules:** Every finding states Assertion(s) + Evidence tag + Source + Date. `[INQ]` must always be corroborated. All monetary amounts in RM. "Not sighted / cannot verify" is itself a valid finding.

---

## STEP 1 — Entity Context Checklist

Before auditing, confirm or obtain:

| Item | Regulatory Reference | Why Critical |
|------|---------------------|--------------|
| PHFSA Borang B — scope, hours, holder | PHFSA 1998 s.4; PMC Regs 2006 Reg.3 | Scope breach = criminal offence |
| LCP (Letter of Credentialing & Privileging) — if aesthetic services offered | MOH Medical Practice Division; MMC Guidelines on Aesthetic Practice | Mandatory for ALL aesthetic procedures since 2023; 783 GPs registered Jun 2025 |
| DCA product registration for each drug/biologic/aesthetic product | CDCR 1984 P.U.(A) 394/1984 | Cell therapy, aesthetics, CBD — individual registration required |
| AELA licence(s) — X-ray, laser | AELA 1984; Rad Protection Regs 1986 | RPO, supervisor, class, expiry, equipment list |
| SST registration + filing calendar | Service Tax Act 2018; STA Amendment Order 2025 | Period 4 (Mar–Apr 2026) due 31 May 2026 — imminent |
| MMC APC — all medical practitioners | Medical Act 1971; www.mmc.gov.my | Current APC mandatory |
| Allied Health APC — physiotherapists, radiographers | Allied Health Professions Act 2016 | AHPC registration per profession |
| Medicine price display compliance | Price Control & Anti-Profiteering (Medicine Price Labelling) Order 2025 P.U.(A) 141/2025 | High Court stay granted 21 May 2026 pending JR — monitor status |
| MyInvois / LHDN eInvoice integration | Income Tax (Digital Services) Act 2019; LHDN eInvoice Guideline 3.2 | Mandatory since Jul 2025 (threshold per [MY-034]) |
| PDPA compliance — DPO appointed, breach procedures | PDPA (Amendment) Act 2024; DPO requirement effective Jun 2025 | Penalty per [MY-051]; 72-hour breach notification |
| EPF foreign worker contributions | EPF Act 1991; effective Oct 2025 | rates per [MY-043] |
| Companies Act 2016 — SSM registration, annual return | Companies Act 2016 s.68 | File within 30 days of AGM |
| Group structure — entities, interco balances, payroll home | MFRS 9, MFRS 124 | ECL, RPT disclosure |
| IT systems per entity (POS, accounting, payroll) | PDPA 2024; Companies Act 2016 s.245 | Integration gaps, PDPA per-entity |

---

## STEP 2 — Domain Reference Files

| Domain | File | Trigger |
|--------|------|---------|
| A — PHFSA / MOH / DCA / AELA / LCP | `references/clinic-A_regulatory_compliance.md` | Any clinical, licence, scope, aesthetic, or medical practice question |
| A2 — Medicine Price Display (NEW 2025) | `references/clinic-A2_medicine_price_display.md` | Any drug pricing, KPDN, price transparency question |
| B — Revenue, POS & Panel Billing | `references/clinic-B_revenue_pos_panel.md` | Revenue, POS, panel billing, Benford |
| C — SST Compliance | `references/clinic-C_sst_compliance.md` | SST, RMCD, service tax, SST-02 filing |
| D — Financial Reporting & SQL | `references/clinic-D_financial_reporting.md` | BS, P&L, MFRS, SQL Accounting ITGC |
| E — Intercompany & Related Party | `references/clinic-E_intercompany_rpt.md` | Interco loans, ECL, MFRS 9, TP rules |
| F — Statutory Labour & HR (2025 rates) | `references/clinic-F_statutory_hr.md` | EPF, SOCSO, EIS, MWO, EA 1955, HRDF |
| G — Cash, Bank & Treasury | the retired `G_cash_bank` module (not a separate file in this suite) | Cash controls, banking, undeposited cash |
| H — Inventory & Pharmacy | the retired `H_inventory_pharmacy` module (not a separate file in this suite) | Poisons Act, DCA, FIFO, cold chain |
| I — Fraud Risk & Benford | the retired `I_fraud_benford` module (not a separate file in this suite) | ACFE fraud tree, analytics, red flags |
| J — IT / PDPA 2024 (UPDATED) | `references/clinic-J_it_pdpa.md` | PDPA DPO Jun 2025, MyInvois Jul 2025, PDPA penalties per [MY-051] |
| K — Corporate Governance | `references/clinic-K_governance.md` | Board, SSM, MACC, director duties |
| L — Benchmarking | `references/clinic-L_benchmarking.md` | KPJ, IHH, Raffles, global KPIs |
| M — Future Trends & Digital (UPDATED) | `references/clinic-M_future_trends.md` | MyHEALTH, NHIS, AI diagnostics, DRG 2027 |

---

## STEP 3 — Assertion Codes

`EX` Existence | `CO` Completeness | `AC` Accuracy | `OC` Occurrence | `VA` Valuation | `RO` Rights & Obligations | `CP` Compliance | `DI` Disclosure | `AU` Authorisation | `GC` Going Concern

---

## STEP 4 — Finding Format

```
**[Ref]: [Title]** | Priority: 🔴/🟠/🟡/🟢
- Assertion(s): [codes]
- Evidence: [tag] [source] [date]
- Condition: [What found — RM quantified, tables preferred]
- Criteria: [Law / clause / standard — specific section + year + P.U.(A) if applicable]
- Cause: [Root cause from evidence, not speculation]
- Effect: [RM exposure, regulatory penalty, clinical/operational risk]
- Quantified Exposure: [RM OR "TBD — requires [specific test]"]
- Recommendation: [Action + responsible party + deadline]
- Supporting References: [list of specific acts, registries, guidelines]
```

---

## Step 5 — Report structure

Owned by `gia-report-qa:gia-ia-report` (standard concise report plus Excel working paper). This pack emits a findings register and its supporting tables only; the long-form overall-opinion layout in the retired source is a legacy conversion reference and is not used. Dashboards named in the retired layout (yield, labour compliance, OEM scorecard, benchmarks) are working-paper sheets.

## STEP 6 — 2025–2026 Regulatory Changes Checklist (CRITICAL — AUDIT EVERY ENGAGEMENT)

Run this checklist on every clinic audit. These are NEW since the original skill build.

| # | Change | Effective Date | Audit Test | Risk if Non-Compliant |
|---|--------|---------------|------------|----------------------|
| 1 | LCP mandatory for ALL aesthetic procedures | Ongoing enforcement 2025 | [CON] MOH LCP National Registry for each aesthetic practitioner | PHFSA scope breach; Rafianee v Dr Suffia [2025] — unlicensed facility = illegal |
| 2 | Medicine Price Display Order P.U.(A) 141/2025 | Effective 01 May 2025; enforcement under HIGH COURT STAY as at 21 May 2026 | [PHY] Price list displayed at reception; [INS] current court stay status | Penalty per [MY-050] — stayed pending JR disposal |
| 3 | SST on non-citizen healthcare ([MY-032]) | 01 Jul 2025 | [CON] SST registration; [CON] SST-02 filing Periods 1–4 | Penalty per [MY-033] |
| 4 | LHDN MyInvois eInvoice mandatory | Phased by revenue per [MY-034]: Aug 2024, **Jul 2025**, **Jul 2026** | [CON] Klinify MyInvois API integration status; [INS] e-invoice UUID on sample receipts | Penalty per [MY-036] |
| 5 | PDPA (Amendment) Act 2024 — DPO mandatory | Phase 1–3: Jan–Jun 2025; DPO: Jun 2025 | [INS] DPO appointment letter; [INS] breach response procedure | Penalty per [MY-051]; 72-hour breach notification obligation |
| 6 | EPF foreign workers mandatory ([MY-043]) | Oct 2025 | [REC] payroll register — foreign worker EPF at the [MY-043] rates | EPF Act 1991 penalty + surcharge |
| 7 | SOCSO/EIS wage ceiling change [MY-007] | per register | [REC] payroll — verify the current ceiling is applied to all eligible staff | Under-contribution for staff above the superseded ceiling |
| 8 | EIS wage ceiling [MY-007] (same ceiling as SOCSO per register) | per register | [REC] payroll — EIS capped at the register ceiling | Over/under contribution error |
| 9 | EPF employer rate by salary band [MY-005] | per register | [REC] payroll EPF employer rate | Under-contribution for lower-salary staff |
| 10 | PDPA "Data Controller" / "Data Processor" terminology | 2024 | [INS] contracts, privacy notices — updated terminology | PDPA compliance gap; fines per [MY-051] |

---

## STEP 7 — Presentation Standards (L99 Rule)

**Every finding MUST present data in tables, not prose.**

Data table format:
```
┌──────────────────────────────────┬──────────────────────────────────┐
│ Column header                    │ Column header                    │
├──────────────────────────────────┼──────────────────────────────────┤
│ Data cell                        │ Data cell                        │
└──────────────────────────────────┴──────────────────────────────────┘
```

Required tables per finding type:
- **Revenue findings:** Monthly trend table + gap reconciliation table
- **Regulatory findings:** Compliance gap table (Requirement | Status | Reference)
- **Intercompany findings:** Entity × balance × headcount × ECL stage table
- **Payroll findings:** Rate recalculation table (employee × gross × statutory × computed vs actual)
- **Inventory findings:** Opening/closing/movement table per month
- **Cash findings:** Account × LY × current × movement table
- **Benchmarking:** clinic actual | Malaysia benchmark | Global best | Gap | Risk colour

---

## STEP 8 — Validation Rules

| Rule | Requirement |
|------|-------------|
| Evidence first | No finding without documented evidence tag + source |
| Quantify always | RM exposure or count — or explain why not quantifiable |
| Cite P.U.(A) numbers | Every gazette order cited with gazette number |
| Law + section + year | Full citation: Act name, Act number, section, year |
| Professional scepticism | Corroborate all management explanations |
| Regulatory calendar | Include next 10 compliance deadlines with due dates |
| 2025–2026 changes | Run Step 6 checklist on every engagement |
| Digit tests | Via `gia-fraud:gia-fraud-analytics`; no inline population threshold |
| Tables | All findings data in tables per Step 7 |

---

> **No documents:** Label "FRAMEWORK ONLY — risk indicators, no line-item findings."
> **Partial documents:** State which domains are evidence-supported vs framework-only.
