#!/usr/bin/env python3
"""Audit-plan consistency invariants (read-only; reports, never repairs).

Inputs (JSON or CSV; keys matched case-insensitively, non-alphanumerics ignored):
  --plan          plan master (JSON list, or {"engagements": [...]})  [required]
  --plan-csv      tabular mirror of the plan (must match the master)
  --risks         risk register (JSON list or CSV): risk_id, likelihood, impact,
                  inherent_score, residual_score (scores optional)
  --tiers         JSON {"Entity": "Critical|High|Medium|Low"}  (tier coverage check)
  --root          directory to resolve engagement file_location paths against
  --expected-count N    asserted engagement count (e.g. the number quoted in the app/AC paper)
  --capacity-days D     available fieldwork days over the plan horizon
  --reserve-pct P       minimum investigation reserve, default 20
  --json

Engagement fields: id, entity, status, linked_risks (list or ;/, separated),
file_location, days. Exit 1 if any ERROR.
Coverage thresholds come from the tier rules in references/plan-invariants.md.
"""
import argparse
import csv
import json
import os
import re
import sys
from collections import Counter, defaultdict

MIN_TOUCHES = {"critical": 2, "high": 1, "medium": 1, "low": 0}


def norm(k):
    return re.sub(r"[^a-z0-9]", "", str(k).lower())


def load(path):
    if path.lower().endswith(".json"):
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            for key in ("engagements", "plan", "risks", "items"):
                if key in data and isinstance(data[key], list):
                    data = data[key]
                    break
        rows = data
    else:
        with open(path, newline="", encoding="utf-8-sig") as f:
            rows = list(csv.DictReader(f))
    return [{norm(k): v for k, v in r.items()} for r in rows]


def ids(v):
    if v is None:
        return []
    if isinstance(v, list):
        return [str(x).strip() for x in v if str(x).strip()]
    return [x.strip() for x in re.split(r"[;,|]", str(v)) if x.strip()]


def num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def run(plan, plan_csv=None, risks=None, tiers=None, root=None, expected_count=None,
        capacity_days=None, reserve_pct=20.0):
    issues = []

    def add(sev, where, msg):
        issues.append({"severity": sev, "where": where, "message": msg})

    plan_ids = [str(r.get("id", "")).strip() for r in plan]
    for i, pid in enumerate(plan_ids):
        if not pid:
            add("ERROR", "plan row %d" % (i + 1), "engagement has no id")
    for pid, c in Counter(p for p in plan_ids if p).items():
        if c > 1:
            add("ERROR", pid, "duplicate engagement id (%d rows)" % c)

    if expected_count is not None and len(plan) != expected_count:
        add("ERROR", "count", "plan has %d engagements, asserted count is %d" % (len(plan), expected_count))

    if plan_csv is not None:
        csv_ids = [str(r.get("id", "")).strip() for r in plan_csv]
        if len(csv_ids) != len(plan_ids):
            add("ERROR", "csv-vs-json", "engagement count differs: json %d, csv %d" % (len(plan_ids), len(csv_ids)))
        for x in sorted(set(plan_ids) - set(csv_ids)):
            add("ERROR", x, "in plan master but not in csv mirror")
        for x in sorted(set(csv_ids) - set(plan_ids)):
            add("ERROR", x, "in csv mirror but not in plan master")
        sj = Counter(str(r.get("status", "")).strip().lower() for r in plan)
        sc = Counter(str(r.get("status", "")).strip().lower() for r in plan_csv)
        if sj != sc:
            add("ERROR", "csv-vs-json", "status distribution differs: json %s, csv %s" % (dict(sj), dict(sc)))
        cj = {str(r.get("id", "")).strip(): r for r in plan}
        for r in plan_csv:
            k = str(r.get("id", "")).strip()
            if k in cj:
                for f in ("entity", "status"):
                    if str(cj[k].get(f, "")).strip().lower() != str(r.get(f, "")).strip().lower():
                        add("ERROR", k, "field '%s' differs between json and csv" % f)

    if risks is not None:
        risk_ids = {str(r.get("riskid", r.get("id", ""))).strip() for r in risks}
        for r in plan:
            for rid in ids(r.get("linkedrisks")):
                if rid not in risk_ids:
                    add("ERROR", str(r.get("id", "")), "linked risk '%s' not in risk register" % rid)
        for r in risks:
            rid = str(r.get("riskid", r.get("id", ""))).strip()
            L, I = num(r.get("likelihood")), num(r.get("impact"))
            inh, res = num(r.get("inherentscore")), num(r.get("residualscore"))
            if L is not None and I is not None and inh is not None and abs(L * I - inh) > 1e-9:
                add("ERROR", rid, "inherent score %s != likelihood x impact (%s x %s)" % (inh, L, I))
            if inh is not None and res is not None and res > inh:
                add("ERROR", rid, "residual score %s exceeds inherent score %s" % (res, inh))

    if root is not None:
        for r in plan:
            loc = str(r.get("filelocation", "")).strip()
            if loc and not os.path.exists(os.path.join(root, loc.replace("\\", os.sep))):
                add("ERROR", str(r.get("id", "")), "file_location does not resolve: %s" % loc)

    if tiers is not None:
        touches = defaultdict(int)
        for r in plan:
            touches[str(r.get("entity", "")).strip().lower()] += 1
        for ent, tier in tiers.items():
            need = MIN_TOUCHES.get(str(tier).strip().lower())
            if need is None:
                add("ERROR", ent, "unknown tier '%s'" % tier)
            elif touches.get(ent.strip().lower(), 0) < need:
                add("ERROR", ent, "tier %s needs at least %d engagements in the horizon, plan has %d (record any accepted gap in the coverage map)" % (tier, need, touches.get(ent.strip().lower(), 0)))

    if capacity_days is not None:
        planned = sum(num(r.get("days")) or 0 for r in plan)
        limit = capacity_days * (1 - reserve_pct / 100.0)
        if planned > limit + 1e-9:
            add("ERROR", "capacity", "planned %.1f days exceeds %.1f available after a %.0f%% investigation reserve (capacity %.1f)" % (planned, limit, reserve_pct, capacity_days))
    return issues


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--plan", required=True)
    ap.add_argument("--plan-csv")
    ap.add_argument("--risks")
    ap.add_argument("--tiers")
    ap.add_argument("--root")
    ap.add_argument("--expected-count", type=int)
    ap.add_argument("--capacity-days", type=float)
    ap.add_argument("--reserve-pct", type=float, default=20.0)
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)
    tiers = None
    if a.tiers:
        with open(a.tiers, encoding="utf-8") as f:
            tiers = json.load(f)
    issues = run(load(a.plan), load(a.plan_csv) if a.plan_csv else None,
                 load(a.risks) if a.risks else None, tiers, a.root, a.expected_count,
                 a.capacity_days, a.reserve_pct)
    errs = [i for i in issues if i["severity"] == "ERROR"]
    if a.json:
        print(json.dumps({"errors": len(errs), "issues": issues}, indent=2))
    else:
        for i in issues:
            print("%-5s %-16s %s" % (i["severity"], i["where"], i["message"]))
        print("RESULT: %s (%d errors)" % ("FAIL" if errs else "PASS", len(errs)))
    return 1 if errs else 0


if __name__ == "__main__":
    sys.exit(main())
