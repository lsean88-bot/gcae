# Engagement strategy postures

Pick one posture and state why. Do not leave it implicit.

| Posture | When it fits | What changes downstream |
|---|---|---|
| Comprehensive | High inherent risk, unproven controls, first engagement | Full ToD and ToE; no reliance shortcuts |
| Reliance-based | Mature controls, prior clean results, monitoring data exists | Reduced samples where ToD/ToE history supports it; document the reliance rationale |
| Forensic | Suspected fraud, allegation, enforcement trigger | Stop and hand to `gia-fraud:gia-fraud-investigation`; do not run a standard walkthrough |
| Agile sprint | Fast-changing environment or technology deployment | Short cycles; interim reporting each sprint |
| Continuous assurance | Real-time monitoring and automated testing feasible | `gia-analytics:gia-continuous-assurance`; supplements, never replaces, periodic testing |

## Scope precision (six boundaries, all required)
| Boundary | Define as |
|---|---|
| Process | Start trigger to end trigger, every hand-off named |
| System | Named applications, schemas, tables |
| Time | Exact period under review |
| Entity | Legal entities and branches; consolidation basis stated |
| Population | Complete, statistical sample or judgmental sample, with the reason |
| Materiality | Quantitative threshold and qualitative threshold (for example any regulatory non-compliance) |

## Non-negotiables to state to the client
No scope expansion without a documented, re-approved change request. No analysis on data that has not passed a completeness and accuracy check. No finding without cited evidence. Every assumption labelled with its impact if wrong and how it would be validated. State only what the evidence supports; do not attach a fixed confidence percentage as a style habit.
