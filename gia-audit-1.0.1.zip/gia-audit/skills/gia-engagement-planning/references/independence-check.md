# Mandate, authority and independence check (before acceptance)

Establish and record these before drafting terms of engagement. If an answer is not supplied, ask or record an open dependency; never infer an authority or independence position.

## Contents
- Trigger assessment
- Independence threats
- Acceptance decision

## Trigger assessment
| Question | Why it matters |
|---|---|
| Who holds engagement authority (Board, Audit Committee, CEO, regulator, self-initiated)? | Decides who approves scope changes and receives the report |
| Mandate type (internal audit, forensic investigation, governance review, risk assessment, compliance certification, advisory)? | Decides the method skill |
| Urgency: routine, priority, emergency, regulatory deadline | Timeline and resourcing |
| Prior-period findings: open items, repeat deficiencies, escalated matters | Carried into scope and risk focus |
| Entity code, jurisdiction, audit period, headcount, team, scope domains | Phase 2 exit; unsupplied facts become open dependencies |

## Independence threats
Self-review, advocacy, familiarity, intimidation, financial dependence. Document each threat and its mitigation. Unmitigated threats mean the engagement is not accepted as scoped.

## Acceptance decision
Accept, accept with documented mitigations, or decline. Record who decided and when. No fieldwork starts until the terms of engagement are agreed and scope boundaries are locked.
