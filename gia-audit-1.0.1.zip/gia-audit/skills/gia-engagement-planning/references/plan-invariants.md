# Rolling plan: file map, tier coverage, update discipline, invariants

The plan of record is the machine-readable master. Always read the live files before scheduling or reporting plan status; this file describes the discipline, not the plan. Run `scripts/plan_consistency.py` after any change.

## Contents
- File map (roles, not paths)
- Tier coverage rules
- Update discipline
- Invariants checked by the script
- Planning input versus plan of record
- Cadence

## File map (roles, not paths)
| Role | Rule |
|---|---|
| Machine-readable master (JSON) | Single source of truth for engagements; edit first |
| Tabular mirror (CSV) | Must match the master exactly |
| Narrative rolling plan | Must agree with the master on every engagement |
| Methodology note | How tiers and resourcing assumptions were built |
| Coverage map | The one place accepted coverage gaps are recorded |
| Audit Committee approval paper | Prepared, never represented as approved |
| Next-cycle working folder | Planning input only until promoted |
Paths are environment-specific: record them in the engagement's project memory (`gia-core:project-memory`), not in this skill.

## Tier coverage rules (ASSUMED house convention; confirm per plan cycle)
| Tier | Minimum coverage over the 24-month horizon |
|---|---|
| Critical | At least 2 touches |
| High | Full audit plus follow-up |
| Medium | At least 1 touch |
| Low | Rotational or advisory |
Hold at least 20% of capacity as investigation reserve; do not schedule fieldwork at full utilisation against planned engagements alone.

## Update discipline
1. Identify the change: engagement added, rescheduled, rescoped, closed, or a coverage gap opened or closed.
2. Edit the master first, then mirror to the CSV and the narrative so all three agree.
3. If a tier rule is now unmet, record the gap in the coverage map; never absorb it by renumbering or quietly dropping an engagement.
4. If the change needs Audit Committee awareness (new critical-entity engagement, significant rescope, plan-wide capacity issue), flag it for the next approval paper or an interim memo.
5. Re-run the invariants before treating the update as complete.

## Invariants checked by the script
- Engagement ids unique and present; count equals the count asserted everywhere it is quoted (update every quote at once if the plan grows).
- Master and CSV agree on ids, entity, status and status distribution.
- Every linked risk resolves to a risk in the register; risk scores equal likelihood times impact; residual never exceeds inherent.
- Every engagement file location resolves on disk.
- Tier coverage met, or the gap is recorded.
- Planned days fit within capacity after the investigation reserve.

## Planning input versus plan of record
A working paper for the next cycle is planning input. It is not authority to change the master. Resolve entity-mapping ambiguities explicitly (clean match versus requires interpretation) before writing engagement lines; do not silently choose a classification. Promote to the master only after approval.

## Cadence
Monthly: list engagements starting, continuing or closing; check resourcing and reserve; queue newly surfaced risk for the next quarterly refresh rather than folding it into the current month; check follow-up due dates. Quarterly: re-run tier adequacy against the risk register, review the coverage map, update the approval paper if the refresh is material. The `/gia-monthly-cycle` command runs the monthly pass.

## Coverage map and approval paper: required content
The source skills named both documents but gave no layout; the layout below is an ASSUMED house convention to be confirmed by the CAE.
| Document | Minimum content |
|---|---|
| Coverage map | Per risk or domain: covered by (engagement id) or NOT covered; tier of the entity; rule unmet; reason the gap is accepted; accepting role; review date |
| Audit Committee approval paper | Plan period and engagement count; changes since the last cycle; tier coverage result; accepted gaps copied from the coverage map; capacity and investigation reserve; decision requested |
The paper is prepared, never represented as approved. Board-facing layout: `gia-report-qa:gia-board-brief`.
