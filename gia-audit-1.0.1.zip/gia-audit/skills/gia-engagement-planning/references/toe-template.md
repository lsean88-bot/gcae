# Terms of Engagement (TOE) — Template


## Contents
- Independence threat quick-reference

> Note on naming: this document type is called "TOE" (Terms of Engagement) in full caps,
> deliberately distinct from "ToE" (Test of Operating Effectiveness) used in the testing skills
> of the `gia-racm-icfr-testing` skill. Don't shorten this to
> "ToE" in filenames, headers, or cross-references — pick a name that won't collide, e.g.
> `TOE-<entity>-<year>.docx` or `Engagement-Charter-<entity>-<year>.docx`.

Fill every field. Leave nothing implicit — an unstated boundary is the one that gets
disputed later.

---

**ENGAGEMENT PARTIES**
- Client entity:
- Engaging party (Board / Audit Committee / CEO / Regulator / self-initiated):
- GIA lead:
- Named workstream owners / specialists:

**MANDATE TYPE**
☐ Statutory audit ☐ Internal audit ☐ Forensic investigation ☐ Governance review
☐ Risk assessment ☐ Compliance certification ☐ Advisory

**SCOPE BOUNDARIES**
- In-scope entities:
- In-scope processes:
- In-scope systems:
- In-scope geographies:
- Time period under review:
- **Explicitly out of scope:**

**SCOPE CHANGE PROTOCOL**
- Who can approve a scope change:
- Process: written change request → impact assessment (timeline/cost) → re-approval →
  update this TOE with an addendum (never a silent scope change)

**OBJECTIVES**
- Primary objective(s):
- Secondary objective(s):
- Success criteria (measurable):

**DELIVERABLES**
- Named reports / dashboards / presentations / filings this engagement will produce:

**TIMELINE AND MILESTONES**
- Kickoff:
- Fieldwork start / end:
- Interim reporting date(s):
- Draft report target:
- Final report target:
- Closure target:

**RESOURCE REQUIREMENTS**
- Data access needed:
- System credentials needed:
- Personnel availability required from client:
- Physical access required:
- Third-party cooperation required:

**CONFIDENTIALITY AND DATA HANDLING**
- Classification level of data handled:
- Storage / encryption expectations:
- Retention period:
- Destruction protocol at closure:

**INDEPENDENCE AND OBJECTIVITY**
- Independence confirmed: Yes / No — if No, do not proceed until resolved
- Any conflicts disclosed:
- Mitigation measures, if any:

**LIMITATIONS OF SCOPE**
- Known constraints:
- Data known to be unavailable:
- Reliance placed on prior or third-party work (state what, and why that reliance is reasonable):

**JURISDICTION AND GOVERNING LAW**
- Applicable legal framework:
- Regulatory body, if any:
- Dispute resolution mechanism:

**TERMINATION CONDITIONS**
- Grounds for termination by either party:
- Handover protocol if terminated early:

**SIGN-OFF**
- Engagement sponsor: _______________ Date: _______
- GIA lead: _______________ Date: _______

---

## Independence threat quick-reference

Use this at Step 1 of the engagement, before drafting the TOE — if any of these apply
and can't be mitigated, the engagement shouldn't be accepted as currently scoped:

| Threat | What it looks like in practice |
|---|---|
| Self-review | Auditing a process you (or GIA) designed or previously implemented |
| Advocacy | Being asked to defend a management position rather than test it |
| Familiarity | Long-standing personal relationship with process owner under review |
| Intimidation | Pressure from a senior stakeholder to soften scope or findings |
| Financial dependence | Fee or role dependent on a favourable outcome |
