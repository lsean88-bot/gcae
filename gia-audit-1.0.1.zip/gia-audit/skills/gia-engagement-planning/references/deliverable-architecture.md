# Deliverable Architecture & Data Request List

## Reporting cadence — set this in the TOE, hold to it in delivery

| Deliverable | Audience | Content | Typical timing |
|---|---|---|---|
| Interim status report | Engagement sponsor, GIA lead | Progress, emerging issues, scope adjustments | Weekly / bi-weekly |
| Risk alert memorandum | Audit Committee, C-suite | Urgent risk requiring immediate attention | As needed — don't wait for the final report |
| Draft findings report | Management, process owners | Findings, evidence, recommendations | End of fieldwork |
| Management response | Management | Agreed actions, owners, deadlines | ~2 weeks after draft |
| Final report | Board, Audit Committee, regulator (if applicable) | Opinion, findings, recommendations, management responses | At closure |
| Board presentation | Board of Directors | Executive summary, key risks, strategic implications | Board meeting cycle |
| Regulatory filing | Regulator | Standardised per the applicable regulation | Per regulatory calendar |
| Continuous monitoring dashboard | Risk Committee, GIA | Real-time indicators, control health, trend | Ongoing (Continuous Assurance posture only) |

Report quality bar that applies to all of the above:
- Every statement traceable to a workpaper, evidence item, or validated data point.
- Constructive but unflinching tone — no management appeasement, no regulator provocation.
- Recommendations are SMART.
- Any inference is labelled as an inference, with its evidentiary basis stated.

## Data Request List (DRL) template

| Data element | Format | Source system | Extraction method | Owner | Due date | Received? |
|---|---|---|---|---|---|---|
| | | | | | | ☐ |

Fill one row per named data element — not "financial records," but "GL detail export,
Jan–Dec [year], from [ERP], .csv, extracted by [name]." A vague DRL is the single
biggest cause of fieldwork delay; be specific here even if it takes longer to draft.

## Project Charter (one page, for sign-off)

```
PROJECT CHARTER

Engagement:            [Title]
Sponsor:                [Name / role]
GIA Lead:               [Name]
Strategy selected:      [Comprehensive / Reliance-Based / Forensic / Agile Sprint / Continuous Assurance]
Objective (1 sentence): [ ]
Scope (1–2 sentences):  [ ]
Timeline:               [Kickoff] → [Final report target]
Key deliverables:       [List]
Approved by:            [Sponsor signature/date]  [GIA lead signature/date]
```

## Emergency / exception triggers during an already-accepted engagement

These override the normal cadence above — escalate immediately, don't wait for the
next scheduled interim report:

| Scenario | Immediate action |
|---|---|
| Suspected fraud discovered mid-fieldwork | Escalate to GIA lead and, where warranted, legal counsel; preserve evidence; do not tip off the subject |
| Surprise regulatory examination | Cooperate without waiving privilege; loop in legal counsel before substantive responses |
| Data breach discovered during the engagement | Trigger the client's incident response process; preserve forensic evidence |
| Scope dispute with the client | Refer to the TOE's scope change protocol; escalate to engagement sponsor if unresolved |
