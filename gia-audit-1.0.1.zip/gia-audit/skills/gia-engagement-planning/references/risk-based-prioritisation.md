# Risk-based engagement prioritisation (RACM-driven)

### Risk-Based Engagement Prioritisation
```
Scoring algorithm for process risk ranking:
Score = (CRITICAL controls × 4) + (HIGH controls × 2) + (MEDIUM controls × 1)
Sorted descending → highest score = highest audit priority
```

### Engagement Fields
```
Title       : Descriptive name (e.g. "Procure to Pay ICFR Review Q2 2026")
Process     : Source process from RACM
Priority    : CRITICAL | HIGH | MEDIUM | LOW
Quarter     : Q1 | Q2 | Q3 | Q4
Budget Days : Estimated audit days
Lead Auditor: Named individual
Rationale   : Risk-based justification (required for AC paper)
Status      : Planned | In Progress | Completed | Deferred
```

### AI Auto-Plan Logic
```
1. Rank all processes by risk score (above formula)
2. Assign top quartile (CRITICAL) to Q1/Q2 → no rotation
3. Assign HIGH processes to Q2/Q3 → biennial rotation acceptable
4. Assign MEDIUM processes to Q3/Q4 → triennial rotation
5. Assign LOW processes → risk-based rotation only
6. Validate: ensure Entity-Level Controls reviewed annually
7. Validate: ensure ITGC reviewed every period (no rotation)
8. Output: draft audit plan with justification per engagement
```

---

