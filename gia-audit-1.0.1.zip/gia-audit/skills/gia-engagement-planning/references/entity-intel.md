# Entity risk snapshot (planning input, dated)

Snapshot of the retired entity-intelligence digest, as of its last update in October 2026. It is **planning input, not the plan of record and not assurance**. Re-read the live risk register before relying on any row. Investigation case facts, amounts and named subjects were removed from this file on purpose: they belong to `gia-fraud:gia-fraud-entity-watch` under its confidentiality rules.

## Contents
- Tier table
- Standing coverage observations
- Group themes
- Entity-mapping ambiguities
- How to use

## Tier table (as of source snapshot)
| Entity | Tier | Control maturity (1-5) | Avg residual score | Risks recorded |
|---|---|---|---|---|
| MKSDL (Mexico; alias MKSLD in older files) | Critical | 2 | 7.7 | 15 |
| MKPC (Malaysia) | Critical | 2 | 7.4 | 16 |
| MKTRON (Malaysia metals, legacy predecessors) | High | 2 | 7.1 | 12 |
| Sekhar India umbrella (Sathya Auto, Jack Division, Die Casting Division India, Pune Stamping, Gencor) | High | 2 | 6.3 | 18 |
| MKAPL Die Casting | High | 2 | 7.0 | 12 |
| Nephrocare Management Sdn Bhd | High | 3 | 7.7 | 9 |
| MKAPL Stamping | Medium | 3 | 5.6 | 7 |
| MKAPL Corporate-ICFR | Medium | 3 | 4.4 | 5 |
| MKAPL BCP Division | Medium | 2 | 8.0 | 3 |
| IIWAM | Medium | 3 | 6.0 | 5 |
| Erawan LMW | Medium | 3 | 6.5 | 4 |
| Gencor | Medium | 3 | 4.8 | 5 |
| Fleet Parade | Medium | 3 | 5.7 | 3 |
| Perfect Health | Low (information gap, not assurance) | 2 | 8.0 | 3 |
Perfect Health's Low tier reflects thin coverage (one narrow-scope audit), not a confirmed low-risk finding. Do not present it as assurance. Group average control maturity was 2.4 of 5 at the snapshot; 10 of 14 entities (71%) sit at Medium to Critical. Scores and risk counts are the source snapshot's own, not recomputed; they are ASSUMED until re-read from the live register. Per-entity history and risk ids: `entity-profiles.md`.

## Standing coverage observations (to verify against the live register)
- Several entities show findings that remain open across audit cycles; closure discipline is a group-level theme.
- LMW customs and bonded inventory (Erawan LMW) and IATF 16949 / OEM customer-specific requirements across manufacturing entities were recorded as under-covered.
- Dialysis consumables stock control and clinical governance / privacy coverage (Nephrocare, Perfect Health) were recorded as under-covered.
- Subcontractor reconciliation under GST (India) was recorded as under-covered.
- Entity-governance documentation gaps (no corporate description for one entity; a division whose name does not match its activity) are referred to Group Legal and Corporate Secretarial, not only to the audit plan.

## Group themes (planning lenses)
1. Procurement and tooling segregation of duties as a recurring root cause across manufacturing entities.
2. Investigation case management consistency (intake, custody, closure memo): see `gia-fraud:gia-fraud-investigation`.
3. Closure validation: no closure without validation date and evidence note (`gia-audit-lifecycle`, `follow-up-std15.md`).
4. HR and payroll governance as a foundational risk, not a routine compliance item.
5. Specialised regulatory coverage (customs, OEM requirements, clinical governance, GST subcontracting).

## Entity-mapping ambiguities
State the ambiguity explicitly; do not silently pick one classification.
- Jack/Jacks Division: tracked inside the Sekhar India umbrella, with no own risk register or RACM folder.
- Chennai ICFR work for MKTRON is reported as filed under the MKAPL Die Casting folder tree.
- Gencor reports have been branded MKTRON although Gencor is a separate legal entity.

## How to use
Before drafting scope for a named entity: confirm tier and maturity; check whether the issue is a known recurring pattern or new; check whether it fits a group theme and, if so, frame the recommendation at group-standard level; state any mapping ambiguity.
