---
name: gia-engagement-planning
description: "New engagement, independence, terms of engagement (TOE, never test of operating effectiveness), scope, planning memo, rolling plan, tier coverage. Use when accepting or scoping an engagement or refreshing the 24-month plan. Do NOT use for control testing (use gia-audit:gia-racm-icfr-testing) or fieldwork (use gia-audit:gia-fieldwork-workpapers)."
---

# Engagement planning

Front door of an engagement and keeper of the rolling plan. Ends where the RACM is built (`gia-audit:gia-racm-icfr-testing`).

**Terminology guard.** Write "Terms of Engagement" or "TOE" in capitals for the engagement letter. "ToE" always means test of operating effectiveness. Never shorten one into the other in file names or headers.

## Workflow
1. Mandate, authority and independence: `references/independence-check.md`. Ask for what is not supplied; do not infer authority or an independence position.
2. Entity facts: entity name and code, jurisdiction, audit period, headcount, team, scope domains. Anything missing goes to an open-dependency table in the planning memorandum.
3. Strategy posture: `references/strategy-postures.md`. Pick one and state why. A forensic posture hands off to `gia-fraud:gia-fraud-investigation`.
4. Scope precision: six boundaries (process, system, time, entity, population, materiality) in the same file.
5. Terms of engagement: `references/toe-template.md`. No fieldwork until terms are agreed and scope is locked. Scope changes need a documented, re-approved change request.
6. Hand-off package: planning memorandum stub (strategy, scope, risk focus, resources, timeline, open dependencies), data request list and project charter; templates in `references/deliverable-architecture.md`. Reporting cadence is set in the TOE.
7. Entity risk context before scoping a named entity: `references/entity-intel.md` (tiers) and `references/entity-profiles.md` (history, risk ids, group themes); dated snapshots, planning input only.
8. Risk-based ordering of engagements: `references/risk-based-prioritisation.md`.

## Rolling plan
Rules, update discipline and cadence: `references/plan-invariants.md`. After any plan change run:
`python3 -I ${CLAUDE_PLUGIN_ROOT}/skills/gia-engagement-planning/scripts/plan_consistency.py --plan <master.json> [--plan-csv <mirror.csv>] [--risks <risk_register.json>] [--tiers <tiers.json>] [--root <dir>] [--expected-count N] [--capacity-days D]`
It reports and never repairs. Exit code 1 means at least one error. The script checks ids, master versus mirror, risk links and score arithmetic, file locations, tier coverage and capacity after the investigation reserve.
Planning input (a next-cycle working paper) is not the plan of record. Do not represent an approval paper as approved; approval is a human gate.

## Guardrails
- State only what the evidence supports; no fixed confidence percentages.
- Every assumption is labelled with its impact if wrong and how it will be validated, or carried as an open dependency. Plant, state and entity facts are never assumed.
- Re-evaluate any scope exclusion whenever new operational facts emerge.
- Role names, not personal names, in method text.

## References
`references/independence-check.md`, `strategy-postures.md`, `toe-template.md`, `deliverable-architecture.md`, `plan-invariants.md`, `entity-intel.md`, `entity-profiles.md`, `risk-based-prioritisation.md`. Command: `/gia-engage-start`, `/gia-monthly-cycle`. Agent: `audit-planner`.
