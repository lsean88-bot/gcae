---
name: gia-audit-lifecycle
description: "Audit lifecycle, engagement status, which phase, finding pipeline, management response, follow-up, closure, lessons learned. Use when running, resuming or closing an engagement or classifying a finding. Do NOT use for Iron Rules (use gia-core:iron-rules), report drafting (use gia-report-qa:gia-ia-report) or fraud (use gia-fraud:gia-fraud-investigation)."
---

# Audit lifecycle

Orchestrates an engagement end to end. It holds the phase map, the hand-off rules and the finding pipeline. Method detail lives in the other `gia-audit` skills; rules live in `gia-core:iron-rules`.

## Rules this skill relies on (by pointer, not restated)
- Iron rules, evidence grades R1 to R5 with the strict R3 test, the 12-item Quality Gate, the fraud ladder and the human sign-off gate: `gia-core:iron-rules`.
- Model and effort per task: `gia-core:model-effort-routing`. Do not set models or effort here.
- Lessons capture across sessions: `gia-core:self-learning`.
- Report format: `gia-report-qa:gia-ia-report` (standard concise report plus Excel working paper; profile A auditee/EXCO, profile B Board/Audit Committee/Chairman).

## How to use
1. Establish where the engagement is. It may arrive mid-fieldwork or at draft report. Do not restart at phase 1.
2. Open `references/phase-map.md` and read only the row and references for the current phase.
3. Dispatch only the roles the scope needs (`references/agent-briefs.md`). One complete brief per role: objective, input paths, output file, acceptance test. Independent tasks run in parallel; every agent saves output to disk before returning.
4. Hold the conclusion yourself. Before accepting a sub-agent result that reverses or materially changes a finding, check the single deciding cell or source yourself.
5. Do not pass phase 2 without confirmed entity name and code, jurisdiction, audit period, headcount, team and scope domains. Facts not supplied become explicit open dependencies in the working paper; never assume them.

## Phase summary
| # | Phase | Skill that holds the method |
|---|---|---|
| 1-3 | Universe and plan, scope and terms, knowledge acquisition | `gia-audit:gia-engagement-planning` |
| 4, 7, 8 | Data gathering, testing, workpapers | `gia-audit:gia-fieldwork-workpapers` |
| 5, 10 | Risk and control assessment, scoring and aggregation | `gia-audit:gia-racm-icfr-testing` |
| 6 | Domain review by jurisdiction | `gia-audit:gia-pack-india`, `-mexico`, `-malaysia` |
| 9 | Findings and root cause | `gia-audit:gia-fieldwork-workpapers` (5C) |
| 11, 14 | Management response, follow-up | `references/follow-up-std15.md` |
| 12-13 | Draft QA and reporting | `gia-report-qa:gia-report-qa`, `gia-report-qa:gia-ia-report` |
| 15 | Lessons learned | `references/lessons-kaizen.md` |
Standards citations at sub-clause level: `gia-audit:gias-navigator`.

## Finding pipeline (summary)
`DRAFT -> reviewer check -> VALIDATED | CHALLENGED | RETRACTED | SCOPE-LIMITED | MERGED`. Classification tree, status states and the standard finding record are in `references/lifecycle-evidence-chain.md`. A finding flagged as invalid, unproven or mischaracterised is removed entirely, not softened. A narrower restatement is allowed only if it can be independently verified without asserting anything unconfirmed.

## Guardrails
- Evidence chain `Source -> Evidence -> Test -> Result -> Conclusion -> Finding`; a missing link blocks the finding.
- Never invent a management response, owner, date, control or evidence. Record management responses verbatim; owners are named roles or persons, not departments.
- A document not produced for audit review is recorded exactly that way. Do not write "does not exist".
- A suspicion of fraud stops standard testing: hand to `gia-fraud:gia-fraud-investigation`; state indicators only, never motive.
- A scope exclusion made because documents were unavailable or a plant was newly commissioned is re-evaluated whenever a new operational fact appears (for example trial production started). Absence of documents is not evidence that a statutory obligation does not exist.
- The independent reviewer is always a different agent from the preparer.
- Nothing is issued without the human sign-off gate in `gia-core:iron-rules`.

## Outputs
Phase status table, open-dependency list, findings register, follow-up register, lessons entry. Save each to disk as it is produced.

## References
| File | Use |
|---|---|
| `references/phase-map.md` | 15 phases, leads, exit gates |
| `references/agent-briefs.md` | 19 role briefs and mapping to plugin agents |
| `references/lifecycle-evidence-chain.md` | Evidence chain, test discipline, classification tree, pipeline, correction triggers |
| `references/follow-up-std15.md` | Management response tracker, follow-up matrix (ASSUMED), closure rule |
| `references/lessons-kaizen.md` | Lessons entry template |
| `references/pack-routing.md` | Jurisdiction and industry routing |
| `references/methodology-playbook.md` | Modules, fieldwork 4A-4D, law validation record, QA standards, naming and version block, framework hierarchy |
