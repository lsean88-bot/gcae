# Lessons learned log (human-reviewed)

Durable cross-session capture belongs to `gia-core:self-learning`. This template is the engagement-level entry; every change to methodology it triggers is a deliberate edit reviewed by a human, never an automatic rewrite (an unsupervised self-modifying audit method is itself a control weakness).

## Entry template
```
Engagement ref / date:
What went well:
What caused rework or delay: (late evidence gap, rejected root cause, score inconsistent with heat map)
Recurring pattern seen before? (check prior entries and other entities in the same sector)
Correction going forward: (the exact wording to add to a skill, agent brief or checklist)
Applied: [ ] yes - file/section/date   [ ] not yet - reason
```

## Standards currency
At engagement start, check for changes to the IIA standards and topical requirements (`gias-navigator`) and to the statutory register for the jurisdiction (`statutory-validator`). Treat what is found as evidence to cite, not as a silent rewrite of this plugin.
