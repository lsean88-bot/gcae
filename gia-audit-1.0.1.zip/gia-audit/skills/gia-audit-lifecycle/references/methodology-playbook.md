# Methodology playbook (ported from the retired methodology and master-agent skills)

Operating detail that the phase map does not carry. Rules, evidence grades, the Quality Gate and the fraud ladder stay in `gia-core:iron-rules`; this file does not restate them. Report layout and tone: `gia-report-qa:gia-ia-report`.

## Contents
- Module view of the lifecycle
- Fieldwork sub-stages 4A to 4D
- Law validation record
- Reconciliation additions
- Risk reassessment at QA
- Management response and follow-up status
- Report naming, version block and structure
- Workpaper and QA standards
- Governing framework hierarchy

## Module view of the lifecycle
The source playbook used eight modules; they map onto the 15 phases in `phase-map.md`.
| Module | Content | Phases |
|---|---|---|
| 1 Setup and scope | Confirm entity, jurisdiction, audit period before anything else | 1-3 |
| 2 Document inventory | Log and rank evidence (R1-R5) | 4, 8 |
| 3 Fieldwork and test | Walkthroughs, ToD, ToE, standard test programs | 5, 7 |
| 4 Compliance and law | Check every rate, section and threshold against the statutory register and primary source | 6 |
| 5 Reconciliation | Mandatory cross-domain tests | 7 |
| 6 Findings pipeline | Draft, reviewer check, VALIDATED / CHALLENGED / RETRACTED / SCOPE-LIMITED / MERGED | 9-11 |
| 7 Report and output | Quality Gate, then issue | 12-13 |
| 8 Learning | Lessons loop | 15 |
Confirm the statutory framework for the jurisdiction and industry, and any effective-date change inside the audit period, before scoping test programs. Standard programs and the rolling-plan tier rules: `gia-fieldwork-workpapers`, `gia-engagement-planning`.

## Fieldwork sub-stages 4A to 4D
- **4A Walkthrough (five stages):** preparation checklist, inquiry guide, transaction trace per process step, segregation-of-duties matrix, walkthrough conclusion memo.
- **4B Test of design:** five techniques (inquiry, observation, inspection, re-performance, re-execution) with a design-adequacy assessment per control; rate Adequate, Enhancement Required or Inadequate. Detail: `gia-racm-icfr-testing/references/tod.md`.
- **4C Test of operating effectiveness:** sampling matrix by control frequency; five steps (population, sample selection, attribute definition, workpaper, conclusion); roll-forward protocol for interim-to-year-end coverage; rate Pass, Exception or Fail. Sample size from frequency, risk and key-control flag (`gia-racm-icfr-testing/scripts/sample_size.py` in `gia-racm-icfr-testing`).
- **4D Deficiency classification:** CD, SD, MW tree plus an aggregation register with ids (AGG-1, AGG-2, ...) that rolls individually immaterial deficiencies into one escalatable item. Decide SOX applicability before using the SD/MW pair; where it does not apply, say so and use CD with a severity rating. Detail: `gia-racm-icfr-testing/references/deficiency-aggregation.md`.
Apply the five-step test discipline (`lifecycle-evidence-chain.md`) to every individual test.

## Law validation record
Before any statutory rate, section or threshold is cited, record:
```
Statute        : [Act, section, notification]
Rate/Threshold : [exact value]
Effective date : [dd-mmm-yyyy]
Source URL     : [official portal]
Validated by   : [method and date]
```
Rule: do not rely on training data. If the official portal cannot be reached, mark "Pending validation" and do not use the value in a finding. In this suite the record lives in the pack registers (`gia-pack-india`, `gia-pack-malaysia`, `gia-pack-mexico`: `references/statutory-register-*.md`); the freshness gate is `gias-navigator/scripts/check_rates.py` in `gias-navigator`.

## Reconciliation additions
The RT-01 to RT-12 table is in `gia-fieldwork-workpapers/references/reconciliation-tests.md`. Also from the source playbook:
- A step-by-step ghost-employee detection protocol sits with the payroll test programs (`gia-fieldwork-workpapers/references/test-programs-T001-T015.md`); run it whenever RT-01 or RT-09 shows a difference.
- The Mexico anti-fraud analytics suite is always run for a Mexico engagement, not optional (`gia-fraud:gia-fraud-analytics`, `gia-pack-mexico`).

## Risk reassessment at QA
- Never accept management's or a prior report's rating. Reassess inherent risk (financial, operational, compliance, legal, fraud, reputational, customer, continuity, strategic; likelihood; severity) and the control environment (design, implementation, operating effectiveness, ownership, monitoring, evidence of execution, segregation of duties, compensating controls).
- Reduce to residual only to the extent design and operating effectiveness are evidenced, never because a control exists on paper (`gia-racm-icfr-testing/references/racm-standard.md`).
- One consistent scoring method: likelihood, impact, inherent, control effectiveness, residual, classification, rank, heat-map position. Check the arithmetic. The score follows the risk; never bend the narrative to a predetermined score. Recompute the heat map against final scores; every issue appears once.

## Management response and follow-up status
- A missing management response is an exception status, distinct from a normal open finding.
- Follow-up status vocabulary from the source: not started; in progress; implemented and verified; implemented, not yet verified; overdue; management declined (with rationale). Map to the register fields in `follow-up-std15.md`. Do not accept a self-reported "done" without evidence at the original evidentiary bar.
- Board and Audit Committee package: quarterly Audit Committee pack, entity audit summary, follow-up status report; formats in `gia-report-qa:gia-board-brief`.
- Independent re-performance of prior findings' statutory citations against primary sources is a numbered workpaper (for example `WP-RP-F01-F02-F03`).

## Report naming, version block and structure
Layout is owned by `gia-report-qa:gia-ia-report`; these are the source conventions, kept so the two stay aligned.
- File name: `[EntityCode]-IAR-[YYYYMM]-v[X.Y]-[STATUS]`, for example `CHNAP-IAR-202503-v1.0-FINAL`. Group standard for new engagements: `GIA-xxxx-nnn`, `CIAR-xxxx-nnn` or `IAR-xxxx-nnn` (rolled out from Q1 2026). Legal deliverables: `<Subject>_<DocType>_FINAL_<DDMonYYYY>`. Convention names are ASSUMED until confirmed against the live group standard.
- Version control block, top and bottom of every report: report reference; entity (full legal name); audit period; report date; classification (confidential, internal audit use only); prepared by (role); reviewed by (role); status (DRAFT, CAE FINAL REVIEW, ISSUED); version history; disclaimer (professional internal audit report; not a statutory audit, legal opinion or certificate; standards named by sub-clause via `gias-navigator`).
- Never overwrite a shipped version; each revision is a new version file. If a file corrupts after an edit, branch forward with a clean rewrite instead of patching further.
- The source called its gate a "14-item" Quality Gate; the current gate is the 12-item gate in `gia-core:iron-rules`, with the pass count stated (for example 12/12) before DRAFT becomes FINAL.
- Full-report order in the source: cover and classification, 5-sentence chairman summary (BLUF), assurance opinion (reasonable or limited), findings dashboard, 5x5 heat map, per-finding cards, financial exposure table (confirmed and estimated; contingent items excluded from the headline), action plan tracker, exit-meeting guide, distribution, sign-off, disclaimer, appendices. The house standard is the concise report plus Excel working paper, not the long form.

## Workpaper and QA standards
- Independent adversarial QA by a reviewer who is not the preparer, before any significant deliverable is presented as final.
- Changes to a master document (RACM, risk register, plan) are diff-verified: report the exact number of cells or fields changed.
- When consolidating conflicting source drafts, document what was wrong with each source and what was done; never merge silently (this table is internal, never in the issued report).
- Self-corrections made in a review pass are logged internally, not absorbed silently and not narrated in the issued report.
- Recompute every total, count and percentage against the underlying data; this is the most frequent source of caught errors.
- Standards currency: at engagement start, check for changes to IIA standards and topical requirements (`gias-navigator`) and to the jurisdiction register (`statutory-validator`).

## Governing framework hierarchy
1. Mandatory: IIA Global Internal Audit Standards 2024 and Topical Requirements; applicable law, statute, regulation, contract.
2. Organisational: charter, group and entity policy, delegation of authority, SOPs, Board directives, risk appetite, control framework.
3. Engagement-specific: approved scope, process documents, prior reports, incidents, investigations, external audit points.
4. Guidance: IIA practice guides and GTAGs, COSO, COBIT, ISO, accounting standards, industry frameworks. Used only where relevant; never a substitute for tiers 1 to 3.
