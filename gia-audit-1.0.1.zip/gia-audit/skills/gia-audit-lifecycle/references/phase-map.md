# Fifteen-phase map

Each phase names its lead role, the skill that holds the method and the exit gate. Load only the references for the phase in hand.

## Contents
- Phase table
- Entry rules
- Hand-offs

## Phase table
| # | Phase | Lead role (see agent-briefs.md) | Method lives in | Exit gate |
|---|---|---|---|---|
| 1 | Audit universe and risk-based plan | 01 | `gia-engagement-planning` | Plan consistency check passes (`plan_consistency.py`) |
| 2 | Scoping, objectives and terms of engagement | 01 | `gia-engagement-planning` | Mandate and independence check recorded; terms of engagement agreed; scope locked |
| 3 | Knowledge acquisition | 02 | `gia-engagement-planning` | Business and operating model note |
| 4 | Document and data gathering | 10, 13 | `gia-fieldwork-workpapers` | PBC tracker reconciled; population completeness checks done |
| 5 | Risk and control assessment | 03 | `gia-racm-icfr-testing` | RACM rows complete; design assessed |
| 6 | Domain review | 04 to 09, 11 | entity pack skill | Candidate issues listed with criteria from the statutory register |
| 7 | Testing (ToD, ToE, standard test programs) | 12 | `gia-racm-icfr-testing`, `gia-fieldwork-workpapers` | Every test has population, sample, result, conclusion |
| 8 | Evidence and workpapers | 13 | `gia-fieldwork-workpapers` | Evidence graded R1 to R5; index complete |
| 9 | Findings and root cause | 14 | `gia-fieldwork-workpapers` | 5C complete; classification tree applied |
| 10 | Risk scoring and heat map | 15 | `gia-racm-icfr-testing` | Scores recomputed; deficiency aggregation register complete |
| 11 | Management action-plan validation | 16 | this skill, `follow-up-std15.md` | Response, owner and date recorded verbatim |
| 12 | Draft report QA | independent | `gia-report-qa:gia-report-qa` | Quality Gate per `gia-core:iron-rules`; independent reviewer is not the preparer |
| 13 | Reporting | 17 | `gia-report-qa:gia-ia-report` | Standard report plus Excel working paper issued |
| 14 | Follow-up | lead auditor | `follow-up-std15.md` | Closure only with validation date and evidence note |
| 15 | Lessons learned | lead auditor | `lessons-kaizen.md`, `gia-core:self-learning` | Entry logged and reviewed by a human |

## Entry rules
- Establish where the engagement is. An engagement can arrive mid-fieldwork or at draft report; do not restart at phase 1.
- Do not pass phase 2 without confirmed entity name and code, jurisdiction, audit period, headcount, team and scope domains. Unsupplied facts are carried as open dependencies, never assumed.
- Planning input is not the plan of record until promoted through the update discipline in `gia-engagement-planning`.

## Hand-offs
- The lead auditor holds the conclusion; role outputs inform it. A sub-agent conclusion that reverses or materially changes a finding is spot-checked by the lead against the single deciding cell or source before it is accepted.
- Every agent saves its output to disk before returning.
