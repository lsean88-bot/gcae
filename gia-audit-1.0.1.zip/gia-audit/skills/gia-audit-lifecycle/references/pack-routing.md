# Jurisdiction and industry routing

Generic roles carry no jurisdiction-specific statutory detail. Before any statutory conclusion, load the entity pack and take values from its statutory register. If no pack covers the site, record an open dependency; do not improvise a requirement.

## Contents
- India
- Mexico
- Malaysia
- Cross-cutting
- Combined requests and parallel work

## India (skill `gia-pack-india`)
| Site type | Reference to load |
|---|---|
| Tamil Nadu operations | `tn-R01` to `tn-R14` (domain index in the pack SKILL.md) |
| Maharashtra operations | `mh-R01` to `mh-R14` |
| Puducherry | `puducherry.md` and `puducherry-verification-register.md` |
| Manufacturing (die casting, stamping) in any state | `general-mfg.md` plus the state delta table |
| HR and payroll fraud | `hr-*.md` |
| Healthcare dialysis | Gap: no India dialysis pack. Record as an open dependency |
| Any other state | Gap: record as an open dependency |

## Mexico (skill `gia-pack-mexico`)
Manufacturing (auto parts, stamping, tooling) and Mexico HR (REPSE, union, expatriate) are both inside the pack. Healthcare: gap, open dependency.

## Malaysia (skill `gia-pack-malaysia`)
| Site type | Reference |
|---|---|
| Die casting and stamping, general | `mfg-diecast-stamping.md` |
| MKPC OEM overlay | `mkpc-overlay.md` |
| Gas cylinder under LMW | `lmw-gas-cylinder.md` |
| Dialysis | `healthcare-dialysis.md` (canonical), `nmsb-finance.md`, `nmsb-ops.md` |
| Clinic | `healthcare-clinic.md` |
| HR and payroll | `hr.md` and `hr-*.md` |

## Cross-cutting
`gia-core:iron-rules` (evidence and quality gate), `gias-navigator` (standards), `gia-fraud:gia-fraud-investigation` (any fraud suspicion), `gia-report-qa:gia-ia-report` (reporting), `gia-core:self-learning` (lessons).

## Combined requests and parallel work
A multi-domain single-site request loads more than one reference together (for example dialysis plus HR). Independent multi-entity workstreams are dispatched as separate sub-agent runs, one complete brief each, per `gia-core:gcgo-router`.
