# Management response and follow-up (GIAS Standards 14.4 and 15.2)

Citation precision: use `gias-navigator` for the exact sub-clause. Standard 14.4 covers recommendations and action plans; 15.2 covers confirming implementation.

## Contents
- Management response tracker
- Escalation triggers
- Follow-up timing matrix (ASSUMED)
- Follow-up register fields
- Closure rule

## Management response tracker
Per finding: reference and title; rating; management position (agree, partly agree, disagree, no response); rationale recorded verbatim; action steps; owner (a named role or person, never a department); target date; completion evidence promised; reviewer assessment (adequate or insufficient); reviewer position (accept or escalate to Audit Committee, with reason). Every validated finding carries a response before the report advances to final.

## Escalation triggers
| Trigger | Action |
|---|---|
| No response 14 days after issue | Flag; send chaser |
| Disagreement on a critical or high finding | Prepare escalation memo for the Audit Committee |
| Reviewer assessment is insufficient | Report does not advance to final |
| Partly agreed with an incomplete action plan | Reviewer follow-up |

## Follow-up timing matrix (ASSUMED)
House convention from the retired fieldwork engine; not sourced to a standard. Confirm or replace.
| Rating | Initial follow-up | Escalation trigger | Audit Committee reporting |
|---|---|---|---|
| Critical | 30 days | 15 days overdue: immediate alert to the CAE | Next meeting |
| High | 60 days | 30 days overdue: Audit Committee escalation | Quarterly |
| Medium | 90 days | 30 days overdue: management chaser | Semi-annual |
| Low | 120 days | 45 days overdue: management chaser | Annual |

## Follow-up register fields
Finding reference and title; rating (drives timing); action summary; owner; target date (days remaining or overdue); status (open, in progress, evidence submitted, verified closed, overdue, escalated, partly implemented, rejected); evidence of completion; reviewer verification (not started, in progress, verified implemented, not implemented, partly implemented); Audit Committee reported (yes or no, date). Plan follow-up for every engagement with critical, high or medium findings.

## Closure rule
No finding reaches "closed - validated" without a validation date and an evidence note. A verbal confirmation of closure is R5 evidence and cannot close a finding. Overdue or declined items follow the escalation ladder (chaser, escalation memo, Audit Committee notice) rather than being carried forward silently.
