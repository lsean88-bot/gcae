# Evidence chain, test discipline, findings pipeline

Evidence grades R1 to R5, the strict R3 test, the fraud ladder and the Quality Gate are defined in `gia-core:iron-rules`. This file does not restate them.

## Contents
- Evidence chain
- Five-step test discipline
- Finding classification tree
- Findings pipeline and status states
- Standard finding record
- Common correction triggers

## Evidence chain
`Source -> Evidence -> Test -> Result -> Conclusion -> Finding`
Every finding traces back through this chain. A missing link means the finding is not ready; close the gap or state the limitation. A walkthrough is not an operating-effectiveness sample.

## Five-step test discipline
Apply to every individual test.
1. PLAN: objective, evidence needed, criteria, sample size.
2. VERIFY: confirm the evidence is available before executing.
3. EXECUTE: perform; record population, sample, procedure, result.
4. CHECK: would a reviewer approve this workpaper as it stands? If not, redo.
5. LOG: record the exception or pass; draft a preliminary finding if there is an exception.

## Finding classification tree
```
Evidence graded R1 to R4 (strict R3 test)?  NO  -> RETRACT (no evidence, no finding)
        | YES
Criteria verified against the statutory register / primary source?  NO -> CHALLENGE (verify, then reassess)
        | YES
Duplicate of an existing finding?  YES -> MERGE (one master finding)
        | NO
VALIDATE: assign finding reference; proceed to classification (CD / SD / MW) and rating
```
Retracted findings never appear in an issued report. A finding the reviewer flags as invalid or unproven is removed entirely, not softened; restate it only in a narrower form that can be independently verified without asserting anything unconfirmed.

## Findings pipeline and status states
`DRAFT -> reviewer check -> VALIDATED | CHALLENGED | RETRACTED | SCOPE-LIMITED | MERGED`
Duplicates are merged, never double-counted. A document that was not produced for audit review is recorded exactly that way; do not write "does not exist" or "no process exists".

## Standard finding record
Reference; title (who, what breach, which criteria); rating; domain; observation; evidence; criteria (Act, section, notification, year, from the register); exposure (formula and source, or "to be quantified"); root cause; risk and impact; recommendation (specific action, named role as owner, target date); reviewer note (never in the issued report); management response (verbatim). Keep observation, root cause, risk and recommendation as separate fields. The 5C labels (condition, criteria, cause, consequence, corrective action) are the field-level equivalent.

## Common correction triggers
1. Risk score arithmetic not matching the stated rating.
2. Statutory citation or section errors, especially rate and frequency.
3. Template or placeholder content from another engagement or jurisdiction surviving.
4. Findings carried forward without re-verifying the evidence.
5. "Does not exist" language where the fact is "not produced for audit review".
6. Tone mismatch with the audience (profile A versus profile B in `gia-report-qa:gia-ia-report`).
7. Totals and counts not recomputed against the underlying data after a scope change.
