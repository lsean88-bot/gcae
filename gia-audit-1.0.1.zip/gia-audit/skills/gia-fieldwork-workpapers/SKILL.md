---
name: gia-fieldwork-workpapers
description: "Fieldwork, PBC list, walkthrough, test programs T-001 to T-015, sampling, observation log, 5C finding, WP-A to WP-H. Use when starting fieldwork, executing a test or assembling workpapers. Do NOT use for RACM or ToD/ToE (use gia-audit:gia-racm-icfr-testing), reports (use gia-report-qa:gia-ia-report) or fraud (use gia-fraud:gia-fraud-investigation)."
---

# Fieldwork and workpapers

Draft-only: workpapers, test conclusions and preliminary findings are prepared here. Issuing a report, escalating to the Audit Committee or triggering a fraud notification is a human decision.

## Workflow
1. Assignment brief (WP-A): entity, scope, objectives, risk areas, team. Unsupplied facts are open dependencies.
2. PBC (WP-B): `references/pbc-presets.md` (8 domain presets). Do not start testing a domain until its required evidence arrives. Source ranks in the presets are the old tool's labels; grade evidence R1 to R5 per `gia-core:iron-rules`.
3. Walkthroughs (WP-C): `references/interview-guides.md` (6 process guides). Record what was observed, not what is assumed; if observed and documented processes differ, record both.
4. Tests (WP-D): `references/test-programs-T001-T015.md` and `references/reconciliation-tests.md`. Apply the five-step discipline PLAN, VERIFY, EXECUTE, CHECK, LOG (`gia-audit:gia-audit-lifecycle`, `lifecycle-evidence-chain.md`). Criteria come from the statutory register of the pack for the jurisdiction, never from memory.
5. Samples (WP-E): ToE sizes from `gia-audit:gia-racm-icfr-testing` (`sample_size.py`, ASSUMED). Prefer 100% population where an extract exists. Record method, seed and list.
6. Observation log (WP-F) and escalation: `references/wp-index-A-H.md`. Stop and notify the CAE on fraud evidence, tampering, obstruction, conflict of interest, staff allegations or breach indicators.
7. Findings (WP-G): `references/5c-finding.md`. Observation, root cause, risk and recommendation stay in separate fields.
8. Validated rates (WP-H): populate from the statutory register with verified-on dates; unverified rows are listed as gaps, not used.
9. Submission: the fieldwork submission checklist in `references/wp-index-A-H.md`. It is not the Quality Gate.

## Evidence wording
Use "not produced for audit review" for a missing document; never "does not exist" or "no process exists". An R5 (verbal) item never supports a conclusion. Web-validate any statutory item that the register marks unverified (agent `statutory-validator`).

## Digit tests
T-011 and any Benford request go through `gia-fraud:gia-fraud-analytics` (Nigrini MAD primary with per-digit z-scores). No inline thresholds.

## Guardrails
- No assumption stated as fact; no invented owner, date or evidence.
- Full-population analytics where possible; the retired HTML apps are not bundled (`references/workbench-apps.md` maps their tabs to this suite).
- Fieldwork agent: `gia-fieldworker`. Commands: `/gia-pbc`, `/gia-sample-size`.

## References
`pbc-presets.md`, `interview-guides.md`, `test-programs-T001-T015.md`, `reconciliation-tests.md`, `5c-finding.md`, `wp-index-A-H.md`, `workbench-apps.md`, `document-grounded-outputs.md`.
