# Retired fieldwork apps (not bundled)

Two single-file HTML apps came from the retired fieldwork plugins: the audit workbench v5.0 and the field auditor dashboard v1.0. They are not bundled: they embed stale rates and names, an old 15-item gate, and JSON exports for engines that are not part of this suite. The method they held is in this skill's references. This file keeps what a user needs to know if they still have a copy.

## Contents
- Where the method went
- Tab map of the retired apps
- Known limitation of the workbench
- If a user asks to launch one

## Where the method went
| App tab or content | Now in |
|---|---|
| PBC presets (8 domains) | `pbc-presets.md`, `/gia-pbc` |
| Walkthroughs and interviews (6 guides, 4 test techniques, design assessment) | `interview-guides.md`, `gia-racm-icfr-testing/references/tod.md` |
| Test programs (15 tests, 10 domains) | `test-programs-T001-T015.md` |
| Sample selection (random, systematic, stratified, calculator) | `gia-racm-icfr-testing/references/toe-sampling.md`, `/gia-sample-size` |
| Observation log with escalation triggers (fraud evidence, document tampering, management obstruction, conflict of interest, staff allegations) | this skill's SKILL.md; fraud indicators hand off to `gia-fraud:gia-fraud-investigation` |
| 5C finding draft | `5c-finding.md` |
| Regulatory validation (validated rates register) | the pack statutory registers and `gias-navigator/scripts/check_rates.py` |
| Workpaper package WP-A to WP-H | `wp-index-A-H.md` |
| Submit to CAE (15-item gate) | Quality Gate in `gia-core:iron-rules` (12 items) |
| Workbench lifecycle tabs, Version Control, Iron Rules | `gia-audit:gia-audit-lifecycle`, `gia-racm-icfr-testing/references/version-control.md`, `gia-core:iron-rules` |

## Tab map of the retired apps
Workbench: Setup and Scope, Documents, Fieldwork and Tests, Compliance, Reconciliation, Findings, Report and Output; AI Analysis, Learning Engine, Cowork Prompts; Version Control, Workpaper Export, Iron Rules. Dashboard: My Assignment, Document Request, Walkthroughs and Interviews, Test Execution, Sample Selection, Observation Log, 5C Finding Draft, Regulatory Validation, Workpaper Package, Submit to CAE.

## Known limitation of the workbench
Its AI Analysis tab and AI Finding Import Parser call `api.anthropic.com` with no API key in the request. That works only inside the Claude.ai sandboxed artifact runtime. Opened as a plain local file in a browser, those two buttons fail (CORS or 401); every other tab works offline. This is expected, not a defect.

## If a user asks to launch one
Say the apps are retired and not part of this plugin, and offer the in-suite equivalents above. If they hold a copy and want to use it, open a copy, never the original, disclose the limitation first, and do not quote any rate or threshold pre-loaded in it (take values from the registers). Data entered in such an app is audit data: keep it local and keep identifiers out of shared deliverables (IR-03). Only add an API-key field if the user explicitly asks.
