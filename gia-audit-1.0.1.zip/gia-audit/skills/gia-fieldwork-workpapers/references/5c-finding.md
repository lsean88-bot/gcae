# 5C finding format and root-cause dimensions

The 5C format is the field-level finding structure. Citation of the standard behind each element is in `gias-navigator` (14.2 analyses, 14.3 evaluation of findings, 14.4 recommendations).

## Contents
- Five elements
- Title rule
- Root-cause dimensions
- Quantification rule
- SMART recommendation

## Five elements
1. Condition: what is, stated as fact with the evidence reference. No inference.
2. Criteria: what should be. Act, section, notification and year from the statutory register or the policy clause; never a generic Act name.
3. Cause: why it happened. Classify as design gap, operating failure, override or unknown, then deepen with the five-whys in `gias-navigator/references/five-whys.md`. Reject superficial causes ("human error", "lack of awareness") unless the evidence shows it is the true cause.
4. Consequence: the effect, with the formula and the source data. If it cannot be quantified, write "to be quantified with [the specific data needed]".
5. Corrective action: specific action, named role as owner, target date, completion evidence to be provided.

## Title rule
The title alone must say who is affected, what the breach or deficiency is and which requirement it breaches. Not "TDS compliance review"; rather "[Vendor or function] [what was not done] under [section] over [period]". Do not put a private individual's name in a title unless the report profile allows it.

## Root-cause dimensions
Governance, process, people, technology, culture. Pick the primary dimension, then run the five-whys within it.

## Quantification rule
Every amount shows its derivation and source. Estimates are labelled estimates. Contingent items are excluded from a headline total.

## SMART recommendation
Specific, measurable, achievable, relevant, time-bound. Internal audit recommends; management owns the process and the remediation, so the recommendation does not become an operating instruction beyond what is appropriate.
