# Workpaper package index (WP-A to WP-H) and submission checklist

## Contents
- Index and completeness check
- Fieldwork submission checklist
- Escalation triggers and observation log

## Index and completeness check
| WP | Content | Complete when |
|---|---|---|
| WP-A | Assignment brief and objectives | Objectives, scope, team and period recorded |
| WP-B | PBC list and evidence inventory | Every item tracked as received, partial or refused |
| WP-C | Walkthroughs | Documented for every in-scope process |
| WP-D | Test programs | Run for every in-scope domain |
| WP-E | Sample selection | Basis documented for every sampled test (use `sample_size.py` for ToE) |
| WP-F | Observation log | Complete; every exception has an entry |
| WP-G | Findings | All in 5C format with evidence |
| WP-H | Validated rates register | Populated from the statutory register with verified-on dates |

## Fieldwork submission checklist
This is the staff-to-reviewer submission checklist. It is **not** the report Quality Gate, which is defined in `gia-core:iron-rules` and applied by `gia-report-qa:gia-report-qa`.
1. All PBC items accounted for: received, partial, or refusal documented.
2. Every in-scope domain has at least one completed test.
3. Every test has a documented conclusion (pass, exception, scope limited).
4. Every exception has an observation log entry.
5. Every finding is in 5C format with all five elements.
6. Finding titles name who, what breach and which requirement.
7. No finding rests on R5 evidence.
8. Every law citation traces to a verified statutory-register row with effective date.
9. Financial exposures are quantified or marked "to be quantified with [data]".
10. Every recommendation names an owner role, an action and a date.
11. Walkthroughs documented for in-scope processes.
12. Sample selection basis documented for sampled tests.
13. Scope limitations declared for refused or unavailable documents.
14. No assumption stated as fact.
15. Preparer role and date recorded on every workpaper section.

## Escalation triggers and observation log
Observation log fields: reference, domain, observation, evidence and grade, risk flag, status (under investigation, ready to draft finding, closed - explained, escalate).
Stop and notify the CAE immediately if any of these appear:
- Evidence of fraud or deliberate falsification.
- Suspected tampering with or destruction of documents.
- Management obstruction or refusal to provide documents.
- Material transactions outside scope.
- Conflict of interest involving senior management.
- Any allegation from staff during interviews.
- Cybersecurity or data breach indicators.
Do not investigate fraud unilaterally; hand over to `gia-fraud:gia-fraud-investigation` and keep to the fraud ladder in `gia-core:iron-rules`.
