# PBC presets (8 domains)

> Ported verbatim from the retired field-auditor dashboard (v1.0 HTML). Statutory references, rates and thresholds in the test text are historical source text and are [UNVERIFIED]; the authoritative dated values are in the jurisdiction statutory register (gia-pack-india/references/statutory-register-india.md). Evidence ranks in the PBC table are the source tool's labels; classify evidence using the canonical R1-R5 scale in gia-core:iron-rules.

## payroll
| Document | Source type | Source rank (tool label) | Period |
|---|---|---|---|
| Payroll Register (all employees, all months) | Payroll / HRMS | 2 | Full audit period |
| EPF ECR Challan & Portal Extract | EPF ECR Portal | 1 | Full audit period |
| ESIC ECR & Portal Extract | ESIC Portal | 1 | Full audit period |
| Salary Slip sample (10 employees) | Payroll / HRMS | 3 | Latest month |
| Bank statement — salary disbursement account | Bank Statement | 2 | Full audit period |
| New joiner and resignation list | Payroll / HRMS | 2 | Full audit period |

## tax
| Document | Source type | Source rank (tool label) | Period |
|---|---|---|---|
| Form 26Q — TDS returns (all quarters) | TRACES / TDS | 1 | Full audit period |
| TRACES Challan download | TRACES / TDS | 1 | Full audit period |
| GSTR-1 filed (all months) | GST Portal / GSTR | 1 | Full audit period |
| GSTR-3B filed (all months) | GST Portal / GSTR | 1 | Full audit period |
| GSTR-2B reconciliation statement | GST Portal / GSTR | 1 | Full audit period |
| Vendor invoice register with GST | Vendor Invoice Register | 2 | Full audit period |

## labour
| Document | Source type | Source rank (tool label) | Period |
|---|---|---|---|
| Contractor master list (name, activity, headcount, CLRA licence) | Other | 3 | Current |
| CLRA Form V — contractor licences (all contractors) | Licence / Certificate | 1 | Current |
| Principal employer Form I / CLRA registration | Licence / Certificate | 1 | Current |
| Muster roll / attendance register (contract staff) | Muster Roll / Attendance | 2 | Full audit period |
| Minimum wage notification — applicable state (latest) | Other | 1 | Current |
| Wage register / payment receipts (contract staff) | Payroll / HRMS | 3 | Full audit period |

## cash
| Document | Source type | Source rank (tool label) | Period |
|---|---|---|---|
| Cash book (all months) | Financial Statements | 2 | Full audit period |
| Bank statements (all accounts) | Bank Statement | 2 | Full audit period |
| Bank reconciliation statements | Financial Statements | 2 | Full audit period |
| Petty cash register | Financial Statements | 2 | Full audit period |
| Cash payment vouchers >₹10,000 | Financial Statements | 3 | Full audit period |
| Cheque issue register / online transfer log | Financial Statements | 2 | Full audit period |

## vendor
| Document | Source type | Source rank (tool label) | Period |
|---|---|---|---|
| Vendor master list | IT / System Report | 2 | Current |
| Purchase order register | IT / System Report | 2 | Full audit period |
| Vendor invoice register (all invoices) | Vendor Invoice Register | 2 | Full audit period |
| Payment vouchers and supporting invoices (sample) | Financial Statements | 3 | Full audit period |
| Vendor empanelment / due diligence records | Policy Document | 3 | Current |
| Three-quotation comparison statements | Financial Statements | 3 | Full audit period |

## hr
| Document | Source type | Source rank (tool label) | Period |
|---|---|---|---|
| Organisation chart (current) | Policy Document | 4 | Current |
| HR policy manual | Policy Document | 3 | Current |
| Recruitment records (sample — 10 joiners) | Policy Document | 3 | Full audit period |
| POSH — ICC constitution document | Policy Document | 3 | Current |
| POSH annual report filed with DLC | Licence / Certificate | 1 | Last financial year |
| POSH training attendance register | Policy Document | 3 | Last 2 years |

## it
| Document | Source type | Source rank (tool label) | Period |
|---|---|---|---|
| User access list — all systems | IT / System Report | 2 | Current |
| Privileged access / admin user list | IT / System Report | 2 | Current |
| Password policy document | Policy Document | 3 | Current |
| Access review / recertification records | IT / System Report | 2 | Full audit period |
| Change management log | IT / System Report | 2 | Full audit period |
| Backup and recovery test records | IT / System Report | 2 | Last 12 months |

## corporate
| Document | Source type | Source rank (tool label) | Period |
|---|---|---|---|
| Certificate of Incorporation | Licence / Certificate | 1 | Current |
| Board minutes (all meetings) | Board / Management Minutes | 3 | Full audit period |
| Annual return filed with MCA (MGT-7) | Licence / Certificate | 1 | Last 2 years |
| Statutory registers (members, directors, charges) | Policy Document | 3 | Current |
| Directors disclosure declarations (Form MBP-1) | Policy Document | 3 | Current |
| MSME vendor declaration register | Policy Document | 3 | Full audit period |

