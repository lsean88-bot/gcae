# Interview guides (6 processes)

> Ported verbatim from the retired field-auditor dashboard (v1.0 HTML). Statutory references, rates and thresholds in the test text are historical source text and are [UNVERIFIED]; the authoritative dated values are in the jurisdiction statutory register (gia-pack-india/references/statutory-register-india.md). Evidence ranks in the PBC table are the source tool's labels; classify evidence using the canonical R1-R5 scale in gia-core:iron-rules.

## Payroll Process Interview Guide
1. Who is responsible for preparing the payroll each month?
2. Who approves payroll before disbursement — at what level?
3. How are new employees added to the payroll system? Who authorizes?
4. How are salary changes (increments, restructuring) processed and approved?
5. Who has system access to modify salary figures? Is there a maker-checker?
6. How are terminations removed from payroll? What is the last-month process?
7. How is EPF/ESIC computed — is it automated or manual?
8. Has the payroll system been configured by HR or outsourced? When was it last reviewed?
9. Are contract staff wages processed separately? Who verifies contractor headcount?

## Procurement / AP Process Interview Guide
1. Walk me through the full procure-to-pay cycle for a typical purchase.
2. Who authorizes purchase requisitions? At what value thresholds?
3. How are new vendors empanelled? Who approves and are background checks conducted?
4. How are three quotations obtained — email, written, or system?
5. Who approves purchase orders? Is there a system-based approval workflow?
6. How are invoices matched to POs before payment? Three-way match in place?
7. Who authorizes final payment? Is dual authorization required?
8. How are advance payments controlled and reconciled?
9. Has any vendor complained of delayed payment or disputed amounts?

## Cash & Treasury Process Interview Guide
1. Who has custody of petty cash? What is the float limit?
2. How is petty cash replenishment authorized and documented?
3. Who has internet banking access? Are there transaction limits?
4. How are bank transfers authorized — dual approval in system?
5. Who performs bank reconciliation? How frequently and who reviews it?
6. Are there any cash payments made above ₹10,000 to single persons in a day?
7. How are cheques signed — single or dual signatories? Is there a threshold?
8. Are all bank accounts disclosed in the books? Any undisclosed accounts?
9. How are dormant accounts managed?

## HR & Recruitment Interview Guide
1. What is the end-to-end process to hire a new employee?
2. Who approves new headcount — is it budget-controlled?
3. Are background verification checks conducted for all hires? Who conducts them?
4. How are employment contracts issued and stored?
5. How is the POSH ICC constituted? Who are the current members?
6. When was the last POSH training conducted? Who attended?
7. How are leave records maintained — system or manual?
8. How are disciplinary matters handled? Is there a policy?
9. Are there any pending labour disputes or union grievances?

## IT Controls & Access Interview Guide
1. How are new user accounts created? Who authorizes access?
2. Is there a formal access request and approval process in place?
3. How are access rights reviewed when employees change roles or leave?
4. Who has administrator / privileged access to key systems? How is this monitored?
5. When was the last user access review conducted?
6. How are password policies enforced — complexity, expiry, shared passwords?
7. How are system changes managed — is there a change management process?
8. Are production systems accessible by developers?
9. When were data backups last tested for successful recovery?

## Governance & Ethics Interview Guide
1. Is there a code of conduct / ethics policy? When was it last updated?
2. Are employees required to sign the code of conduct? Frequency?
3. Is there a whistleblower / grievance mechanism? Is it anonymous?
4. Have any ethics complaints been received in the past 12 months?
5. Are related-party transactions disclosed and approved by the board?
6. Is there an anti-bribery policy? Are gifts/hospitality limits defined?
7. Who reviews and approves related-party contracts?
8. Are board minutes maintained and signed? How are resolutions documented?
9. Is there an audit committee? When did it last meet?

