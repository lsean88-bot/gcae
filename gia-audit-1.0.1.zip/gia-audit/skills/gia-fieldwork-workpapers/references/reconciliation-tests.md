# Cross-domain reconciliation tests (RT-01 to RT-12, India payroll and tax set)

Each test links two independent sources. A non-zero difference is an exception to investigate, not a conclusion. Tests that need statutory rates take them from `gia-pack-india/references/statutory-register-india.md`. Execution of the arithmetic may use `gia-analytics:gia-data-reconciliation`. Sections cited in the red-flag column are as stated in the retired source and are [UNVERIFIED]; verify through the statutory register before citing.

IDs were R1-R12 in the source; renamed RT-nn to avoid collision with the evidence grades R1-R5.

## Contents
- Test table
- Recording

## Test table
| # | Test | Link | Indicator if exception (not a conclusion) |
|---|------|------|----------|
| RT-01 | Payroll headcount vs EPF ECR | HR register ↔ ECR | Possible unreported or non-existent employees |
| RT-02 | GST on invoice vs GSTR-2B | AP ledger ↔ GSTR-2B | ITC risk — CGST Sec 16(2)(aa) |
| RT-03 | TDS deducted vs TRACES challan | GL ↔ TRACES | Sec 40(a)(ia) 30% disallowance |
| RT-04 | Worker wage vs state min wage | Payslip ↔ Min Wage notification | Min Wages Act violation |
| RT-05 | Contractor headcount vs CLRA licence | Attendance ↔ CLRA licence | Unlicensed deployment |
| RT-06 | PT deducted vs PT challan | Payroll deduction ↔ PT challan | Amounts deducted but not remitted |
| RT-07 | LWF deducted vs LWF remittance | Payroll ↔ LWF board receipt | Amounts deducted but not remitted |
| RT-08 | Bonus computation vs P&L surplus | Bonus workings ↔ P&L | Overpayment or underpayment |
| RT-09 | Salary paid vs bank debit | Payroll register ↔ bank statement | Payroll paid to unreconciled accounts |
| RT-10 | Inventory per system vs physical count | System stock ↔ physical verification | Shrinkage or unrecorded movements |
| RT-11 | Fixed assets per register vs physical | Asset register ↔ physical tag/location | Assets not found; capitalisation anomalies |
| RT-12 | Intercompany vs counterparty confirmations | Interco ledger ↔ counterparty confirmation | Unconfirmed intercompany balances; transfer-pricing risk |

## Recording
Per test: result (pass, exception, partial, not applicable), difference quantified with formula, source extracts and their dates, population completeness check, and the follow-up finding reference.
