# Document-grounded outputs: record formats

Ported from the retired document-intelligence skill. Grounding rules, labels and citation: `gia-core:project-memory`, `references/document-grounded-rules.md`. All outputs are drafts for CAE review.

## Contents
1. Policy gap
2. Minutes analysis
3. Evidence sufficiency

## 1. Policy gap
| Gap ID | Policy section | Requirement | Gap description | Risk | Priority | Recommendation |
|---|---|---|---|---|---|---|
Input is a policy in the library and a requirement that is in the library or stated. Gaps are draft findings and enter the findings pipeline (`references/5c-finding.md`).

## 2. Minutes analysis
| Item | Meeting date | Type (Action, Decision, Commitment, Risk) | Description | Owner (role) | Due date | Status | Follow-up required |
|---|---|---|---|---|---|---|---|
Extract only what the minutes state.

## 3. Evidence sufficiency
For each finding, assess: is the evidence rank appropriate to the assertion (R1 versus R4); is an R4 item corroborated; do gaps need further procedures. Conclude Sufficient, Partially sufficient or Insufficient. The assessment is advisory until the CAE confirms.
