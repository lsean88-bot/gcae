# Test programs T-001 to T-015 (India field tests)

> Ported verbatim from the retired field-auditor dashboard (v1.0 HTML). Statutory references, rates and thresholds in the test text are historical source text and are [UNVERIFIED]; the authoritative dated values are in the jurisdiction statutory register (gia-pack-india/references/statutory-register-india.md). Evidence ranks in the PBC table are the source tool's labels; classify evidence using the canonical R1-R5 scale in gia-core:iron-rules.

## Contents
- Index
- T-001 to T-015 detail

## Index
| ID | Domain | Objective |
|---|---|---|
| T-001 | EPF & ESIC | Verify EPF contribution accuracy on all wage components |
| T-002 | EPF & ESIC | Verify ESIC applicability and contribution rate accuracy |
| T-003 | TDS / Direct Tax | Verify TDS deduction at correct rates on contractor payments |
| T-004 | TDS / Direct Tax | Verify TDS on salary (Sec 192) — correct slab applied |
| T-005 | GST & Indirect Tax | Reconcile ITC claimed in GSTR-3B against GSTR-2B |
| T-006 | Minimum Wages | Verify wages paid not below statutory minimum |
| T-007 | Contract Labour (CLRA) | Verify CLRA licence compliance for all contractors |
| T-008 | Cash & Bank | Test cash payment limit compliance (Sec 40A(3)) |
| T-009 | Cash & Bank | Bank reconciliation completeness and timing test |
| T-010 | Accounts Payable | Three-way match — PO, GRN, Invoice |
| T-011 | Fraud Risk | Benford's Law test on payment ledger |
| T-012 | Fraud Risk | Ghost employee detection — payroll vs EPF headcount reconciliation |
| T-013 | POSH & Governance | Verify POSH Act compliance — ICC constitution and annual reporting |
| T-014 | IT General Controls | User access review — inappropriate access |
| T-015 | IT General Controls | Password policy compliance test |

## T-001 - Verify EPF contribution accuracy on all wage components
- Domain: EPF & ESIC
- Evidence: Payroll Register (all months); EPF ECR Portal extract
- Population: All employees × 12 months
- Sample: 100% population
- Criteria (as in source): EPF & MP Act 1952, Sec 6, Para 29 EPF Scheme 1952 [UNVERIFIED]
- Procedure:
  1. Extract payroll register for all 12 months
  2. Identify EPF wage base per employee (Basic+DA — include all regular allowances per Para 29)
  3. Recompute 12% employee + 12% employer contribution
  4. Compare computed vs ECR portal figures
  5. Identify variance employees and compute total shortfall
  6. Note employees earning above the EPF wage ceiling [IN-006] for the voluntary EPF check [IN-016]

## T-002 - Verify ESIC applicability and contribution rate accuracy
- Domain: EPF & ESIC
- Evidence: ESIC ECR Portal; Payroll Register
- Population: All employees ≤₹21,000/mo gross
- Sample: 100% eligible population
- Criteria (as in source): ESIC Act 1948, Sec 2(22), Sec 40, 46; 0.75% employee + 3.25% employer [UNVERIFIED]
- Procedure:
  1. Filter payroll for employees with gross ≤₹21,000/month
  2. Verify 0.75% (employee) + 3.25% (employer) applied
  3. Compare ESIC contributions deducted vs ECR portal
  4. Identify employees wrongly excluded
  5. Test mid-year salary changes — was ESIC adjusted correctly when employee crossed ₹21,000 threshold

## T-003 - Verify TDS deduction at correct rates on contractor payments
- Domain: TDS / Direct Tax
- Evidence: Vendor invoice register; Form 26Q; TRACES challan; contractor PAN list
- Population: All contractor payments
- Sample: 100% population
- Criteria (as in source): Income Tax Act 2025 Sec 393 (formerly 194C); 1% individual/HUF, 2% company contractors [UNVERIFIED]
- Procedure:
  1. Extract all contractor payments from vendor register
  2. Segregate by contractor type (individual/HUF vs company)
  3. Verify TDS rate applied (1% vs 2%)
  4. Check single contract ≥₹30,000 or aggregate ≥₹1,00,000 threshold
  5. Match TDS deducted to Form 26Q
  6. Verify challan deposit within due date (7th of following month)
  7. Identify Sec 206AA cases — no PAN deductees (TDS at 20%)

## T-004 - Verify TDS on salary (Sec 192) — correct slab applied
- Domain: TDS / Direct Tax
- Evidence: Form 16 / Salary TDS workings; Form 24Q; TRACES
- Population: All employees
- Sample: 25 random employees
- Criteria (as in source): Income Tax Act 2025 Sec 192; applicable slab rates FY under audit [UNVERIFIED]
- Procedure:
  1. Obtain Form 16 / TDS workings for sample employees
  2. Verify gross salary, exemptions (HRA, LTA), and net taxable income
  3. Recompute tax liability using applicable slabs
  4. Compare TDS deducted (Form 24Q) vs recomputed
  5. Verify that new tax regime vs old regime election is on file
  6. Check for excess/short deduction and annualized impact

## T-005 - Reconcile ITC claimed in GSTR-3B against GSTR-2B
- Domain: GST & Indirect Tax
- Evidence: GSTR-3B filed; GSTR-2B portal download; vendor invoice register
- Population: All months in audit period
- Sample: 100% — all months
- Criteria (as in source): CGST Act 2017, Sec 16(2)(aa) — ITC eligible only if reflected in GSTR-2B (w.e.f. 01 Jan 2022) [UNVERIFIED]
- Procedure:
  1. Download GSTR-2B for all months
  2. Extract ITC claimed in GSTR-3B (Table 4)
  3. Identify ITC claimed NOT appearing in GSTR-2B
  4. Identify top 10 vendors by ITC value — check if GST-registered and filing regularly
  5. Compute ITC at risk (GSTR-3B claim minus GSTR-2B eligible)
  6. Identify vendors who have stopped filing — assess reversal requirement

## T-006 - Verify wages paid not below statutory minimum
- Domain: Minimum Wages
- Evidence: Payroll Register; State minimum wage notification (latest gazette)
- Population: All workers — unskilled/semi-skilled
- Sample: 100% unskilled/semi-skilled category
- Criteria (as in source): Minimum Wages Act 1948; applicable state gazette notification [UNVERIFIED]
- Procedure:
  1. Obtain current state minimum wage notification (web-validate effective date)
  2. Extract all workers in unskilled/semi-skilled category
  3. Identify Basic+DA paid per payroll
  4. Compare to statutory minimum (Basic+DA per gazette)
  5. Flag employees below minimum
  6. Compute total shortfall (headcount × monthly shortfall × months)
  7. Check if VDA (Variable DA) is included as required by gazette formula

## T-007 - Verify CLRA licence compliance for all contractors
- Domain: Contract Labour (CLRA)
- Evidence: Contractor master list; CLRA Form V copies; muster rolls
- Population: All active contractors
- Sample: 100% — all contractors
- Criteria (as in source): CLRA Act 1970, Sec 7 (contractor licence), Sec 12 (principal employer registration), Sec 21(4) [UNVERIFIED]
- Procedure:
  1. Obtain master list of all contractors including activity, headcount, and period
  2. Obtain CLRA Form V (licence) for each contractor
  3. Compare actual headcount deployed vs licence limit
  4. Verify principal employer registration (Form I)
  5. Check renewal dates — any expired licences
  6. Verify EPF/ESIC of contract workers on contractor bills
  7. Check if contractor has filed Form XII (register) on-site

## T-008 - Test cash payment limit compliance (Sec 40A(3))
- Domain: Cash & Bank
- Evidence: Cash book; payment vouchers
- Population: All cash payments
- Sample: All payments >₹9,999 in a day to same person
- Criteria (as in source): Income Tax Act 2025 (Sec 40A(3) equivalent) — disallows cash payments >₹10,000/day to same person [UNVERIFIED]
- Procedure:
  1. Extract all cash transactions from cash book
  2. Aggregate by payee per day — identify total >₹10,000
  3. Obtain vouchers for flagged transactions
  4. Compute total disallowable expenditure
  5. Test bank reconciliation for completeness — all items cleared within 30 days

## T-009 - Bank reconciliation completeness and timing test
- Domain: Cash & Bank
- Evidence: Bank statements; bank reconciliation statements
- Population: All bank accounts × 12 months
- Sample: 3 months random + last month
- Criteria (as in source): Companies Act 2013, Sec 128 (books of account) [UNVERIFIED]
- Procedure:
  1. Obtain bank reconciliation for sampled months
  2. Verify all book entries reconcile to bank statement
  3. Identify reconciling items >30 days outstanding
  4. Test for unusual credits to bank not in books
  5. Verify no payments in bank missing from books (unrecorded payments)

## T-010 - Three-way match — PO, GRN, Invoice
- Domain: Accounts Payable
- Evidence: Purchase orders; GRNs; vendor invoices; payment vouchers
- Population: All invoices >₹50,000
- Sample: 25 random or 100% if <50 invoices
- Criteria (as in source): Internal policy; Companies Act 2013 Sec 128 [UNVERIFIED]
- Procedure:
  1. Extract invoices >₹50,000 from AP register
  2. For each: locate matching PO and GRN in system
  3. Verify quantities and amounts tally across all three documents
  4. Check invoice date vs GRN date — payment not before goods received
  5. Identify any invoices with no PO backing (maverick spend)
  6. Compute total maverick spend as % of total AP

## T-011 - Digit-distribution (Benford) test on payment ledger
- Domain: Fraud Risk
- Evidence: Full payment ledger / cash book, all amounts
- Population: All payment transactions
- Sample: 100% population
- Criteria: ACFE guidance on digit analysis [UNVERIFIED edition]
- Procedure: Run the Benford analysis in `gia-fraud:gia-fraud-analytics` (Nigrini MAD primary with per-digit z-scores; chi-square supplementary for small N). Do not apply an ad hoc deviation threshold here. First confirm the preconditions (population size, range spanning orders of magnitude, no assigned or bounded numbers) and record the MAD table version in the workpaper. Investigate flagged digits and round-number clusters as indicators only, per the fraud ladder in `gia-core:iron-rules`.
- Superseded source text: the original v1.0 procedure used a flat ">5% deviation" digit flag; removed as methodologically unsound.

## T-012 - Ghost employee detection — payroll vs EPF headcount reconciliation
- Domain: Fraud Risk
- Evidence: Payroll Register (all months); EPF ECR portal extract; employee master
- Population: All employees — all months
- Sample: 100% population
- Criteria (as in source): ACFE Fraud Tree — Asset Misappropriation; EPF & MP Act 1952 [UNVERIFIED]
- Procedure:
  1. Extract unique employee IDs from payroll register
  2. Extract unique UAN numbers from EPF ECR portal
  3. Match payroll IDs to EPF UANs — identify employees on payroll with no EPF
  4. For each gap: check if legitimately exempt (salary above the EPF wage ceiling [IN-006] and opted out, new joiner in last month, etc.)
  5. Flag unexplained gaps as ghost employee indicators
  6. Cross-reference with physical attendance / biometric data if available

## T-013 - Verify POSH Act compliance — ICC constitution and annual reporting
- Domain: POSH & Governance
- Evidence: ICC constitution; annual report to DLC; training records
- Population: Document review
- Sample: 100% — all documents
- Criteria (as in source): POSH Act 2013, Sec 4 (ICC), Sec 21 (annual report), SH Rules 2013 [UNVERIFIED]
- Procedure:
  1. Obtain ICC constitution document
  2. Verify: ≥50% women members; external member present and qualified
  3. Verify member terms not expired
  4. Obtain copy of annual report filed with District Officer (DLC)
  5. Confirm filing within 31 Jan deadline for prior year
  6. Review complaints register — any pending cases
  7. Verify awareness training conducted: obtain attendance register and training material
  8. Check any penalties or DLC notices received

## T-014 - User access review — inappropriate access
- Domain: IT General Controls
- Evidence: User access list; HR records; joiner-mover-leaver log
- Population: All system users
- Sample: All active users
- Criteria (as in source): COSO IC 2013 — Control Activities (CC9); ISO 27001 A.9 [UNVERIFIED]
- Procedure:
  1. Obtain full user access list for key systems (ERP, payroll, banking)
  2. Cross-reference to current employee list — identify terminated employees with active access
  3. Identify users with excessive privileges (e.g. payroll preparer also has approval access)
  4. Identify shared accounts / generic logins
  5. Confirm last password change date — check for accounts with no recent activity
  6. Verify that users who changed roles had access adjusted (mover process)

## T-015 - Password policy compliance test
- Domain: IT General Controls
- Evidence: Password policy document; system configuration screenshots
- Population: All systems
- Sample: Key systems: ERP, payroll, banking, HR
- Criteria (as in source): COSO IC 2013; NIST SP 800-63B password guidelines [UNVERIFIED]
- Procedure:
  1. Obtain password policy document
  2. For each key system: verify policy enforced in system settings (min length ≥8, complexity, expiry ≤90 days)
  3. Test for default passwords in any accounts
  4. Verify multi-factor authentication on critical systems (banking, ERP)
  5. Identify any shared credentials or service accounts with no expiry
