# Migration (old to new)

| Old source | New location | Unique strength | Status |
|---|---|---|---|
| super-grc lifecycle and agent briefs | gia-audit-lifecycle | phase map, evidence chain | PORTED |
| engagement planning and prioritisation | gia-engagement-planning | plan invariants, posture | PORTED |
| RACM, ICFR and ToE skills | gia-racm-icfr-testing | one ASSUMED sample table, CD/SD/MW | PORTED |
| fieldwork HTML (T-001..T-015) | gia-fieldwork-workpapers/references | test programs, PBC presets | PORTED |
| standards navigator | gias-navigator | standards map, topical requirements | PORTED |
| India state skills (TN, MH, Puducherry), HR | gia-pack-india | R01..R14 risk sets, register | PORTED (pre-Code citations flagged) |
| Mexico manufacturing and HR | gia-pack-mexico | register, UMA year check | PORTED |
| Malaysia mfg, LMW, clinic, dialysis, HR | gia-pack-malaysia | register, entity references | PORTED (clinic case figures open) |
| HTML dashboards and workbench (cae-audit-workbench, cae-field-auditor) | not bundled; tab map and launch limitation in gia-fieldwork-workpapers/references/workbench-apps.md | method ported to references; apps themselves retired (carry names, stale rates, 15-item gate) | PORTED (method); apps OPEN if CAE wants them archived |
| entity intelligence digest (cae-entity-intel) | gia-engagement-planning/references/entity-intel.md, entity-profiles.md | tier heatmap with scores, profiles, group themes (case names and amounts left out) | PORTED |
| methodology playbook and master agent references | gia-audit-lifecycle/references/methodology-playbook.md | modules, 4A-4D, law validation record, QA standards, framework hierarchy | PORTED |
| framework reference | gias-navigator (COBIT, GARP, standards), gia-racm-icfr-testing/references/framework-reference-additions.md | DE/OE, SOX 302/404, technique table, analytics choices | PORTED |
| Pune VDA tracker command | gia-pack-india/references/plant-readiness-tracker.md, /gia-plant-readiness-tracker | two-workstream framing, tab pattern | PORTED |
| governance-suite statutory freshness script | gias-navigator/scripts/check_rates.py | dated-register tripwire, now reads the three registers | PORTED (adapted) |

## Port disposition (1.0.1, closes the PARTIAL port-check row)

| Source | Element | Disposition |
|---|---|---|
| cae-24m-plan-manager | File map (roles of master, mirror, narrative, methodology, coverage map, approval paper, next-cycle folder) | PORTED→gia-engagement-planning/references/plan-invariants.md (File map) |
| same | Tier coverage minimums, 20% investigation reserve | PORTED→plan-invariants.md (Tier coverage rules, marked ASSUMED) |
| same | Named entity-to-tier assignments | DROPPED (case and entity facts; tier heat map is in entity-intel.md) |
| same | Update discipline, consistency invariants, cadence | PORTED→plan-invariants.md; checked by scripts/plan_consistency.py |
| same | Plan identity convention (AP-2026-01 to 35) and fixed count | DROPPED (generalised: the count invariant stays, the numbering and number are engagement facts) |
| same | Audit Committee approval paper and coverage-map layout | PORTED→plan-invariants.md (Coverage map and approval paper: required content; layout ASSUMED, the source gave none) |
| same | Handling an in-progress refresh, entity-mapping ambiguity | PORTED→plan-invariants.md (Planning input versus plan of record), without the named entities |
| same | File-location repair log reference | DROPPED (case history) |
| same | What the skill does not do (no risk scoring, no Board issue) | PORTED→SKILL.md guardrails and plan-invariants.md |
| same | Pointer to the board reporting skill | DROPPED (obsolete name; use gia-report-qa:gia-board-brief, now cited in the approval paper row) |
| same | Orchestrator co-use note | DROPPED (meta-layer; gcgo-router is the only router) |
