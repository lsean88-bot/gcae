# Changelog

## 1.0.1
- QA R2 N1 and N2: 25 Malaysia rows (MY-031 to MY-055) and 17 Mexico rows (MX-039 to MX-055) added as `[UNVERIFIED]` with conflict rows MY-C14 to C17 and MX-C4; about 200 inline SST, tax, penalty, levy, REPSE, IVA, PTU and social-security values in the two packs replaced by row pointers. Port disposition for cae-24m-plan-manager recorded in MIGRATION.md; coverage-map and approval-paper content added to `plan-invariants.md`; `document-grounded-outputs.md` added to gia-fieldwork-workpapers.
- D1: stable row ids in the three statutory registers (IN-001.., MY-001.., MX-001..; conflict ids IN-C9..C16, MY-C7..C13, MX-C1..C3). Every `[register]` pointer in the packs now cites a row id (912 pointers, 139 rows); new rows added as `[UNVERIFIED]` where no row fit. New `tests/test_register_pointers.py` (ids exist, prefix matches pack, topic list for review).
- D2: stale inline values in the Malaysia and Mexico references replaced by register pointers; values in the register carry source and status.
- D3: eight real eval files (5 should-trigger, 5 should-not-trigger with the correct other skill) and `tests/test_evals.py`.
- D4: `gias-navigator/scripts/check_rates.py` ported from the governance suite's freshness check and adapted: reads the three registers, flags rows not VERIFIED, verified-on older than 180 days, missing or bad dates, unknown ids; `--ids`, `--used-in`, `--pack`. 11 tests.
- D6, D8: `itgc-erp-reviewer` is Read, Grep, Glob only; Malaysia entity finance and ops files point to `gia-core:iron-rules` instead of a parallel rules list; first name removed from method text.
- Economy: all skill descriptions 347-378 characters (limit 400), trigger words first, "Use when" and "Do NOT use for ... (use ...)" kept; `tests/test_descriptions.py`.
- Port check: content gaps against the retired sources ported to `entity-profiles.md`, `entity-intel.md` (scores, counts), `methodology-playbook.md`, `framework-reference-additions.md`, `plant-readiness-tracker.md`, `workbench-apps.md`. Results in `tests/RESULTS.md`.
- Link and format pass: dangling reference links repointed to the renamed files, or reworded where the retired module has no file here; frontmatter descriptions and hints quoted (valid YAML); script paths use `${CLAUDE_PLUGIN_ROOT}`; plugin.json 1.0.1.
- Banned-string gate: entity code expanded to Nephrocare in five HR references; example file given a table of contents.

## 1.0.0
- Initial consolidation: 8 skills, 6 agents, 5 commands, 3 scripts with tests, 3 statutory registers.
- Registers updated from the validated-facts run of 29-Oct-2026.
