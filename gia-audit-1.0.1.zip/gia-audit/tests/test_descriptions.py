import glob, os, re, unittest

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
LIMIT = 400


def frontmatter(path):
    with open(path, encoding="utf-8") as f:
        text = f.read()
    m = re.match(r"---\n(.*?)\n---\n", text, re.S)
    return dict(re.findall(r"^([a-z-]+):\s*(.*)$", m.group(1), re.M)) if m else {}


class T(unittest.TestCase):
    def test_description_length(self):
        paths = glob.glob(os.path.join(ROOT, "skills", "*", "SKILL.md")) + glob.glob(os.path.join(ROOT, "agents", "*.md")) \
            + glob.glob(os.path.join(ROOT, "commands", "*.md"))
        self.assertGreaterEqual(len(paths), 19)
        for p in paths:
            d = frontmatter(p).get("description", "")
            self.assertTrue(d, p)
            self.assertLessEqual(len(d), LIMIT, f"{os.path.relpath(p, ROOT)}: {len(d)} chars")

    def test_skills_keep_do_not_use_with_pointer(self):
        for p in glob.glob(os.path.join(ROOT, "skills", "*", "SKILL.md")):
            d = frontmatter(p)["description"]
            self.assertIn("Do NOT use for", d, p)
            self.assertRegex(d, r"\(use [^)]+\)", p)
            self.assertFalse(d.startswith(("Use when", "Use this")), p)  # trigger words first

    def test_skill_md_under_500_lines_and_name_matches_folder(self):
        for p in glob.glob(os.path.join(ROOT, "skills", "*", "SKILL.md")):
            with open(p, encoding="utf-8") as f:
                self.assertLess(len(f.read().splitlines()), 500, p)
            self.assertEqual(frontmatter(p)["name"], os.path.basename(os.path.dirname(p)))

    def test_reviewer_agent_is_read_only(self):
        tools = [x.strip() for x in frontmatter(os.path.join(ROOT, "agents", "itgc-erp-reviewer.md"))["tools"].split(",")]
        self.assertEqual(tools, ["Read", "Grep", "Glob"])


if __name__ == "__main__":
    unittest.main()
