import importlib.util, os, unittest
P = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "skills", "gia-racm-icfr-testing", "scripts", "sample_size.py")
spec = importlib.util.spec_from_file_location("sample_size", P); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

class T(unittest.TestCase):
    def test_table_values(self):
        for f, (_, s, h, l) in m.TABLE.items():
            self.assertEqual(m.compute(f, "standard")["sample"], s)
            self.assertEqual(m.compute(f, "high")["sample"], min(h, m.TABLE[f][0]))
            self.assertEqual(m.compute(f, "low")["sample"], l)
    def test_always_assumed(self):
        for f in m.FREQUENCIES:
            r = m.compute(f, "standard", itgc_effective=True)
            self.assertTrue(r["assumed"]); self.assertIn("ASSUMED", r["note"])
    def test_uplift_and_cap(self):
        self.assertEqual(m.compute("monthly", "high", ["first_time", "manual"])["sample"], 12)  # 8 * 1.5
        self.assertEqual(m.compute("quarterly", "high", ["prior_exceptions"])["sample"], 4)     # capped at 4
        self.assertIn("capped", m.compute("quarterly", "high", ["prior_exceptions"])["basis"])
    def test_reduction_only_low(self):
        self.assertEqual(m.compute("daily", "low", ["prior_clean"])["sample"], 11)  # 15*0.75=11.25
        with self.assertRaises(m.SampleError): m.compute("daily", "standard", ["prior_clean"])
    def test_automated(self):
        self.assertEqual(m.compute("continuous", itgc_effective=True)["sample"], 1)
        self.assertIsNone(m.compute("continuous", itgc_effective=False)["sample"])
        with self.assertRaises(m.SampleError): m.compute("continuous")
    def test_population_override_and_errors(self):
        self.assertEqual(m.compute("weekly", "standard", population=10)["sample"], 10)
        with self.assertRaises(m.SampleError): m.compute("weekly", "bogus")
        with self.assertRaises(m.SampleError): m.compute("weekly", "standard", ["nope"])
        with self.assertRaises(m.SampleError): m.compute("weekly", population=0)
    def test_adhoc(self):
        self.assertIsNone(m.compute("adhoc", "high")["sample"])
    def test_cli(self):
        self.assertEqual(m.main(["--frequency", "annual", "--risk", "high"]), 0)
        self.assertEqual(m.main(["--frequency", "continuous"]), 2)  # ITGC status required
        self.assertEqual(m.main(["--frequency", "continuous", "--itgc-effective", "yes"]), 0)

if __name__ == "__main__": unittest.main()
