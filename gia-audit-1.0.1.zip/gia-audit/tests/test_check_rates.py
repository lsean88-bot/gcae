import importlib.util, json, os, subprocess, sys, tempfile, unittest
from datetime import date

HERE = os.path.dirname(os.path.abspath(__file__))
P = os.path.join(HERE, "..", "skills", "gias-navigator", "scripts", "check_rates.py")
spec = importlib.util.spec_from_file_location("check_rates", P); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

HEAD = "| id | item | Act/section | value | effective date | source URL | verified-on | status |\n|---|---|---|---|---|---|---|---|\n"


def row(i, ver, status):
    return f"| {i} | item {i} | Act | v | Current | src | {ver} | {status} |\n"


class T(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.TemporaryDirectory(); self.addCleanup(self.d.cleanup)

    def reg(self, name, body):
        p = os.path.join(self.d.name, name)
        with open(p, "w", encoding="utf-8") as f:
            f.write("# Register\n\n" + HEAD + body)
        return p

    def run_cli(self, *args):
        r = subprocess.run([sys.executable, "-I", P, *args], capture_output=True, text=True)
        return r.returncode, r.stdout, r.stderr

    def test_parse_date(self):
        self.assertEqual(m.parse_date("29-Oct-2026"), date(2026, 10, 29))
        self.assertEqual(m.parse_date("2026-10-29"), date(2026, 10, 29))
        self.assertEqual(m.parse_date("29-Oct-2026 (re-read)"), date(2026, 10, 29))
        self.assertIsNone(m.parse_date(""))
        self.assertIsNone(m.parse_date("n/a"))
        self.assertIs(m.parse_date("31-Feb-2026"), False)
        self.assertIs(m.parse_date("yesterday"), False)

    def test_norm_status(self):
        self.assertEqual(m.norm_status("[UNVERIFIED]"), "UNVERIFIED")
        self.assertEqual(m.norm_status("SECONDARY-ONLY (re-read the gazette)"), "SECONDARY-ONLY")
        self.assertEqual(m.norm_status("VERIFIED"), "VERIFIED")
        self.assertEqual(m.norm_status(""), "EMPTY")

    def test_clean_row_passes(self):
        p = self.reg("statutory-register-x.md", row("IN-001", "01-Sep-2026", "VERIFIED"))
        code, out, _ = self.run_cli("--registers", p, "--asof", "2026-10-30")
        self.assertEqual(code, 0); self.assertIn("No findings", out)

    def test_status_not_verified_flagged(self):
        body = "".join(row(f"IN-00{i}", "01-Sep-2026", s) for i, s in enumerate(["[UNVERIFIED]", "SECONDARY-ONLY", "CONFLICT", "CORRECTED"], 1))
        rows, _ = m.load_rows([self.reg("statutory-register-x.md", body)])
        f = m.check_rows(rows, date(2026, 10, 30), 180)
        self.assertEqual({x["id"] for x in f}, {"IN-001", "IN-002", "IN-003", "IN-004"})
        self.assertTrue(all(x["category"] == "NOT_VERIFIED" for x in f))

    def test_stale_boundary(self):
        rows, _ = m.load_rows([self.reg("statutory-register-x.md",
                                        row("MY-001", "03-May-2026", "VERIFIED") + row("MY-002", "02-May-2026", "VERIFIED"))])
        f = m.check_rows(rows, date(2026, 10, 30), 180)  # 180 days vs 181 days
        self.assertEqual([x["id"] for x in f], ["MY-002"]); self.assertEqual(f[0]["category"], "STALE")

    def test_verified_without_date_and_bad_dates(self):
        body = row("MX-001", "", "VERIFIED") + row("MX-002", "garbage", "VERIFIED") + row("MX-003", "01-Jan-2027", "VERIFIED")
        rows, _ = m.load_rows([self.reg("statutory-register-x.md", body)])
        cats = {x["id"]: x["category"] for x in m.check_rows(rows, date(2026, 10, 30), 180)}
        self.assertEqual(cats, {"MX-001": "NO_DATE", "MX-002": "BAD_DATE", "MX-003": "BAD_DATE"})

    def test_ids_filter_and_unknown_id(self):
        p = self.reg("statutory-register-x.md", row("IN-001", "01-Sep-2026", "VERIFIED") + row("IN-002", "", "[UNVERIFIED]"))
        code, out, _ = self.run_cli("--registers", p, "--asof", "2026-10-30", "--ids", "IN-001")
        self.assertEqual(code, 0)
        code, out, _ = self.run_cli("--registers", p, "--asof", "2026-10-30", "--ids", "IN-002,IN-999", "--format", "json")
        self.assertEqual(code, 1)
        cats = {(x["id"], x["category"]) for x in json.loads(out)["findings"]}
        self.assertEqual(cats, {("IN-002", "NOT_VERIFIED"), ("IN-999", "UNKNOWN_ID")})

    def test_used_in_checks_only_cited_rows(self):
        p = self.reg("statutory-register-x.md", row("IN-001", "01-Sep-2026", "VERIFIED") + row("IN-002", "", "[UNVERIFIED]"))
        ref = os.path.join(self.d.name, "ref.md")
        with open(ref, "w", encoding="utf-8") as f:
            f.write("Rate [IN-001] applies.\n")
        code, _, _ = self.run_cli("--registers", p, "--asof", "2026-10-30", "--used-in", ref)
        self.assertEqual(code, 0)
        with open(ref, "w", encoding="utf-8") as f:
            f.write("Rate [IN-001] and [IN-002] and [IN-777].\n")
        code, out, _ = self.run_cli("--registers", p, "--asof", "2026-10-30", "--used-in", ref, "--format", "json")
        self.assertEqual(code, 1)
        cats = {(x["id"], x["category"]) for x in json.loads(out)["findings"]}
        self.assertEqual(cats, {("IN-002", "NOT_VERIFIED"), ("IN-777", "UNKNOWN_ID")})

    def test_pack_filter(self):
        a = self.reg("statutory-register-a.md", row("IN-001", "", "[UNVERIFIED]"))
        b = self.reg("statutory-register-b.md", row("MY-001", "01-Sep-2026", "VERIFIED"))
        code, _, _ = self.run_cli("--registers", a, b, "--asof", "2026-10-30", "--pack", "malaysia")
        self.assertEqual(code, 0)
        code, _, _ = self.run_cli("--registers", a, b, "--asof", "2026-10-30", "--pack", "india")
        self.assertEqual(code, 1)

    def test_usage_errors_exit_2(self):
        self.assertEqual(self.run_cli("--registers", os.path.join(self.d.name, "missing.md"))[0], 2)
        empty = os.path.join(self.d.name, "statutory-register-empty.md")
        with open(empty, "w", encoding="utf-8") as f:
            f.write("# nothing\n")
        self.assertEqual(self.run_cli("--registers", empty)[0], 2)
        p = self.reg("statutory-register-x.md", row("IN-001", "", "[UNVERIFIED]"))
        self.assertEqual(self.run_cli("--registers", p, "--asof", "not-a-date")[0], 2)
        with open(p, "a", encoding="utf-8") as f:
            f.write("| IN-002 | short | row |\n")
        self.assertEqual(self.run_cli("--registers", p)[0], 2)

    def test_shipped_registers_load_and_gate_trips(self):
        paths = m.default_registers()
        self.assertEqual(len(paths), 3)
        rows, errors = m.load_rows(paths)
        self.assertEqual(errors, [])
        self.assertGreater(len(rows), 200)
        ids = [r["id"] for r in rows]
        self.assertEqual(len(ids), len(set(ids)))
        code, out, _ = self.run_cli("--asof", "2026-10-30")
        self.assertEqual(code, 1)  # seeded rows are UNVERIFIED, so the gate must trip
        self.assertIn("NOT_VERIFIED", out)
        # a verified row recorded on 29-Oct-2026 goes stale after 180 days
        verified = [r["id"] for r in rows if m.norm_status(r["status"]) == "VERIFIED"]
        self.assertTrue(verified)
        code, out, _ = self.run_cli("--asof", "2026-10-30", "--ids", ",".join(verified))
        self.assertEqual(code, 0)
        code, out, _ = self.run_cli("--asof", "2027-06-01", "--ids", ",".join(verified), "--format", "json")
        self.assertEqual(code, 1); self.assertTrue(all(x["category"] == "STALE" for x in json.loads(out)["findings"]))


if __name__ == "__main__":
    unittest.main()
