# Test results

Run date: 2026-10-30. Command: `python3 -I -m unittest discover -s tests -p 'test_*.py'`. Result: Ran 54 tests, OK.

| Suite | Tests | Result |
|---|---|---|
| test_sample_size.py | 8 | OK |
| test_deficiency_aggregation.py | 10 | OK |
| test_plan_consistency.py | 10 | OK |
| test_register_pointers.py | 7 | OK (1206 pointers, 88 files, 204 distinct rows; re-run 30-Oct-2026 after N1 rows MY-031..055, MX-039..055) |
| test_check_rates.py | 11 | OK |
| test_evals.py | 4 | OK |
| test_descriptions.py | 4 | OK |
| Total | 54 | OK |

Also run: `python3 -I build/validate_structure.py gia-audit`: 279 checks passed, 0 failures.

Live gate, `python3 -I skills/gias-navigator/scripts/check_rates.py --asof 2026-10-30`: 214 register rows, 205 flagged (not VERIFIED). Expected until the statutory validator runs. 9 rows are VERIFIED, dated 29-Oct-2026; they go stale after 180 days.

## Pointer review
`python3 -I tests/test_register_pointers.py --list` prints each pointer with the topic of the row it cites and writes `tests/pointer_topics.tsv`. The topic list was read in full for semantic mismatches after the mapping; mismatches found were remapped. A residual risk is a plausible but wrong row, which only a human read of the sentence against the row can catch.

## Port check (rows of migration/PORT_CHECK.md that target gia-audit)
Method: each source heading's content was compared with the target skill, references included (token coverage first, then a read of every low-coverage section). Environment paths, file names and counts of the retired plan files were deliberately generalised.
| Source | Target | Result |
|---|---|---|
| cae-24m-plan-manager | gia-engagement-planning | Covered by `plan-invariants.md`; paths and the engagement-count convention generalised on purpose |
| cae-entity-intel | gia-engagement-planning | Gap found. Ported: residual scores and risk counts into `entity-intel.md`; per-entity profiles, risk ids, cross-cutting categories, 7 group themes into new `entity-profiles.md`. Left out on purpose: named subjects, recovery amounts, case numbers (IR-03) |
| cae-methodology | gia-audit-lifecycle | Partly covered (5-step discipline, pipeline, finding record, correction triggers, RT tests). Gap ported to new `methodology-playbook.md`: module view, 4A-4D, law validation record, risk reassessment, follow-up status vocabulary, WP-RP workpaper, report naming and version block, QA standards, framework hierarchy |
| master-audit-superagent | gia-audit-lifecycle | Agent roles, phase map, hand-offs, follow-up and lessons already covered; routing text points to gia-core:model-effort-routing and risk-based reporting to gia-report-qa; gaps (risk reassessment, standards currency, framework hierarchy, QA standards) in `methodology-playbook.md` |
| cae-audit-workbench | gia-fieldwork-workpapers | Launch steps and AI-tab limitation ported to `workbench-apps.md`; the HTML asset is not bundled (names, stale rates; banned-string gate) |
| cae-field-auditor | gia-fieldwork-workpapers | Tabs, PBC presets, T-001..T-015, 5C, WP-A..H already covered; tab-to-reference map in `workbench-apps.md`; dashboard HTML not bundled |
| cae-framework-reference (hybrid and composed-layers, identical) | gia-racm-icfr-testing | COBIT, GARP, GIAS, COSO and SOX references already in gias-navigator and `coso-sox-testing.md`; gap ported to `framework-reference-additions.md`. Not ported: GIAS "Std 21-37" numbering, duplicate 6.2/9.2 entries, "20 principles", unverified survey statistics (tagged) |
| dialysis-finance-risk-audit-chief | gia-pack-malaysia | Covered; no gap |
| dialysis-operations-chief | gia-pack-malaysia | Covered; no gap |
| in-manufacturing-audit | gia-pack-india | Covered: all 16 domains, steps 0-7 and evidence rules present |
| pune-vda-tracker | gia-pack-india | Gap ported to `plant-readiness-tracker.md` (framing, workflow, tab pattern); command now points to it |
| mac-audit-constitution-l99 | gia-core | Not a gia-audit row (retired stub) |

## Open
- Sample table is ASSUMED; follow-up timing matrix is ASSUMED.
- All register rows added in 1.0.1 are `[UNVERIFIED]`; conflict rows IN-C14..16 and MY-C11..13 need the statutory validator.
- Residual inline non-register values remain in a few Malaysia and Mexico references (for example SST thresholds); register rows to be added.
- Entity profile and entity-intel scores are a dated snapshot, ASSUMED until re-read from the live register.
- The two retired HTML apps are not archived in the plugin; archive them outside it if the CAE wants them.

## 1.0.1 closing pass
`xref_check.py`: 0 findings for gia-audit (122 dangling links fixed or reworded, 8 invalid-YAML frontmatters quoted, 3 relative script paths now `${CLAUDE_PLUGIN_ROOT}`); all descriptions quoted and <= 400; plugin.json 1.0.1. Tests re-run: 54 OK.
