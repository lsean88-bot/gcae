import importlib.util, os, unittest, tempfile
P = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "skills", "gia-engagement-planning", "scripts", "plan_consistency.py")
spec = importlib.util.spec_from_file_location("pc", P); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

def eng(i, ent="EntA", st="Planned", risks="R1", loc="", days=10):
    return {m.norm(k): v for k, v in {"ID": i, "Entity": ent, "Status": st, "Linked Risks": risks, "File Location": loc, "Days": days}.items()}
def msgs(**kw):
    return [i["message"] for i in m.run(**kw)]

class T(unittest.TestCase):
    def test_clean(self):
        plan = [eng("AP-1"), eng("AP-2", "EntB")]
        self.assertEqual(m.run(plan, plan_csv=[dict(p) for p in plan], expected_count=2), [])
    def test_duplicates_and_count(self):
        out = msgs(plan=[eng("AP-1"), eng("AP-1")], expected_count=3)
        self.assertTrue(any("duplicate" in x for x in out)); self.assertTrue(any("asserted count" in x for x in out))
    def test_csv_mismatch(self):
        plan = [eng("AP-1"), eng("AP-2")]; csvp = [eng("AP-1"), eng("AP-3", st="Done")]
        out = msgs(plan=plan, plan_csv=csvp)
        self.assertTrue(any("in plan master but not in csv" in x for x in out))
        self.assertTrue(any("in csv mirror but not in plan master" in x for x in out))
        self.assertTrue(any("status distribution" in x for x in out))
    def test_field_difference(self):
        out = msgs(plan=[eng("AP-1", "EntA")], plan_csv=[eng("AP-1", "EntZ")])
        self.assertTrue(any("'entity' differs" in x for x in out))
    def test_risk_links_and_scores(self):
        risks = [{"riskid": "R1", "likelihood": 3, "impact": 4, "inherentscore": 12, "residualscore": 8},
                 {"riskid": "R2", "likelihood": 3, "impact": 3, "inherentscore": 10, "residualscore": 12}]
        out = msgs(plan=[eng("AP-1", risks="R1;R9")], risks=risks)
        self.assertTrue(any("'R9' not in risk register" in x for x in out))
        self.assertTrue(any("!= likelihood x impact" in x for x in out))
        self.assertTrue(any("exceeds inherent" in x for x in out))
    def test_file_location(self):
        with tempfile.TemporaryDirectory() as d:
            open(os.path.join(d, "a.txt"), "w").close()
            out = msgs(plan=[eng("AP-1", loc="a.txt"), eng("AP-2", loc="missing.txt")], root=d)
            self.assertEqual(len([x for x in out if "does not resolve" in x]), 1)
    def test_tier_coverage(self):
        plan = [eng("AP-1", "Crit"), eng("AP-2", "Hi")]
        out = msgs(plan=plan, tiers={"Crit": "Critical", "Hi": "High", "Med": "Medium", "Lo": "Low"})
        self.assertTrue(any("Crit" in x and "at least 2" in x for x in out))
        self.assertTrue(any("Med" in x for x in out))
        self.assertFalse(any(x.startswith("tier Low") for x in out))
        self.assertTrue(any("unknown tier" in x for x in msgs(plan=plan, tiers={"X": "Bogus"})))
    def test_reserve(self):
        plan = [eng("AP-1", days=85), eng("AP-2", days=10)]
        self.assertTrue(any("investigation reserve" in x for x in msgs(plan=plan, capacity_days=100)))
        self.assertEqual(msgs(plan=plan, capacity_days=120), [])
    def test_missing_id(self):
        self.assertTrue(any("no id" in x for x in msgs(plan=[eng("")])))
    def test_cli(self):
        import json
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "p.json"); json.dump({"engagements": [{"ID": "A1", "Entity": "E"}]}, open(p, "w"))
            self.assertEqual(m.main(["--plan", p]), 0)
            self.assertEqual(m.main(["--plan", p, "--expected-count", "2"]), 1)

if __name__ == "__main__": unittest.main()
