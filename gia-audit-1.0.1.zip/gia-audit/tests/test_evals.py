import glob, os, re, unittest

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SIBLINGS = os.path.abspath(os.path.join(ROOT, ".."))
MIN = 3


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


def parse(path):
    text = read(path)
    skill = re.search(r"^skill:\s*(\S+)\s*$", text, re.M).group(1)
    head, _, tail = text.partition("should_not_trigger:")
    pos = re.findall(r'^\s+-\s+"(.+)"\s*$', head, re.M)
    neg = re.findall(r'^\s+-\s+prompt:\s+"(.+)"\s*\n\s+use_instead:\s+"(.+)"\s*$', tail, re.M)
    return skill, pos, neg, tail


def known_targets():
    t = set()
    for plugin_dir in glob.glob(os.path.join(SIBLINGS, "gia-*")):
        plugin = os.path.basename(plugin_dir)
        for d in glob.glob(os.path.join(plugin_dir, "skills", "*")):
            t.add(f"{plugin}:{os.path.basename(d)}")
        for a in glob.glob(os.path.join(plugin_dir, "agents", "*.md")):
            t.add(f"{plugin}:{os.path.basename(a)[:-3]}")
    return t


class T(unittest.TestCase):
    def setUp(self):
        self.files = sorted(glob.glob(os.path.join(ROOT, "evals", "*.yaml")))
        self.skills = sorted(os.path.basename(d) for d in glob.glob(os.path.join(ROOT, "skills", "*")))

    def test_every_skill_has_an_eval_and_no_orphans(self):
        self.assertEqual(sorted(parse(f)[0] for f in self.files), self.skills)
        for f in self.files:
            self.assertEqual(parse(f)[0], os.path.basename(f)[:-5])

    def test_counts_and_no_stub_text(self):
        for f in self.files:
            skill, pos, neg, tail = parse(f)
            self.assertGreaterEqual(len(pos), MIN, f)
            self.assertGreaterEqual(len(neg), MIN, f)
            self.assertEqual(tail.count("prompt:"), len(neg), f"{f}: malformed should_not_trigger entry")
            self.assertNotIn("Request in the domain", read(f))
            self.assertEqual(len(set(pos)), len(pos), f)

    def test_use_instead_names_a_real_other_skill_or_agent(self):
        known = known_targets()
        self.assertIn("gia-audit:gia-racm-icfr-testing", known)
        for f in self.files:
            skill, _, neg, _ = parse(f)
            for prompt, target in neg:
                self.assertIn(target, known, f"{f}: {target}")
                self.assertNotEqual(target.split(":")[1], skill, f"{f}: use_instead is the skill itself")

    def test_prompts_are_not_shared_between_positive_and_negative(self):
        allp = {}
        for f in self.files:
            skill, pos, neg, _ = parse(f)
            for p in pos:
                allp.setdefault(p, set()).add(("pos", skill))
            for p, _t in neg:
                allp.setdefault(p, set()).add(("neg", skill))
        for p, s in allp.items():
            self.assertEqual(len(s), 1, f"prompt reused across cases: {p}")


if __name__ == "__main__":
    unittest.main()
