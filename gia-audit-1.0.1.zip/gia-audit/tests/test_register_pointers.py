"""Register pointer integrity for the three statutory registers.

Checks (1) every register row has a unique, sequential id; (2) every `[IN-nnn]`, `[MY-nnn]`,
`[MX-nnn]` pointer in the pack resolves to a row; (3) no bare `[register]`, legacy slug or
non-row id such as `IN-1` remains. Run `python3 -I tests/test_register_pointers.py --list` to print
the pointer -> row topic list used for the semantic review (also written to tests/pointer_topics.tsv).
"""
import os, re, sys, unittest

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
REGS = {
    "IN": os.path.join(ROOT, "skills", "gia-pack-india", "references", "statutory-register-india.md"),
    "MY": os.path.join(ROOT, "skills", "gia-pack-malaysia", "references", "statutory-register-malaysia.md"),
    "MX": os.path.join(ROOT, "skills", "gia-pack-mexico", "references", "statutory-register-mexico.md"),
}
ID = r"(?:IN|MY|MX)-\d{3}"
PTR = re.compile(r"\[(" + ID + r"(?:\s*,\s*" + ID + r")*)\]")
SKIP_NAMES = {"pointer_topics.tsv"}


def read_lines(path):
    with open(path, encoding="utf-8") as fh:
        return fh.read().split("\n")


def load_rows(prefix):
    rows, order = {}, []
    for line in read_lines(REGS[prefix]):
        if re.match(r"^\| " + prefix + r"-\d{3} \|", line):
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            rows[cells[0]] = cells[1:]
            order.append(cells[0])
    return rows, order


ALL_ROWS = {}
ORDERS = {}
for _p in REGS:
    r, o = load_rows(_p)
    ALL_ROWS.update(r)
    ORDERS[_p] = o


def pack_files():
    for dp, _, fns in os.walk(os.path.join(ROOT, "skills")):
        for fn in fns:
            if fn.endswith(".md") and not fn.startswith("statutory-register-"):
                yield os.path.join(dp, fn)
    for sub in ("agents", "commands"):
        d = os.path.join(ROOT, sub)
        for fn in os.listdir(d):
            if fn.endswith(".md"):
                yield os.path.join(d, fn)


def pointers():
    """Yield (relpath, lineno, id, row_topic, sentence)."""
    for p in pack_files():
        for n, line in enumerate(read_lines(p), 1):
            for m in PTR.finditer(line):
                for pid in re.findall(ID, m.group(1)):
                    topic = ALL_ROWS[pid][0] if pid in ALL_ROWS else "MISSING"
                    yield os.path.relpath(p, ROOT), n, pid, topic, line.strip()


class RegisterPointers(unittest.TestCase):
    def test_rows_present_and_sequential(self):
        for prefix, order in ORDERS.items():
            self.assertGreaterEqual(len(order), 30, prefix)
            self.assertEqual(order, [f"{prefix}-{i:03d}" for i in range(1, len(order) + 1)], prefix)

    def test_every_row_has_status_and_topic(self):
        for pid, cells in ALL_ROWS.items():
            self.assertGreaterEqual(len(cells), 7, pid)
            self.assertTrue(cells[0], pid)
            self.assertRegex(cells[-1], r"UNVERIFIED|VERIFIED|CORRECTED|CONFLICT|NOT FOUND|SECONDARY", pid)

    def test_every_pointer_resolves(self):
        missing = [(f, n, pid) for f, n, pid, topic, _ in pointers() if topic == "MISSING"]
        self.assertEqual(missing, [])

    def test_pointers_exist_in_volume(self):
        n = sum(1 for _ in pointers())
        self.assertGreater(n, 600)

    def test_no_bare_or_legacy_pointers(self):
        bad = []
        legacy = re.compile(r"\[register\]|\bIN-\d{1,2}\b(?!\d)|\b(?:IN|MY|MX)-[A-Z]{2,}[A-Z0-9-]*\b")
        for p in pack_files():
            for n, line in enumerate(read_lines(p), 1):
                for m in legacy.finditer(line):
                    if re.fullmatch(r"(?:IN|MY|MX)-C\d+", m.group(0)):
                        continue
                    bad.append((os.path.relpath(p, ROOT), n, m.group(0)))
        self.assertEqual(bad, [])

    def test_conflict_ids_do_not_collide_with_row_ids(self):
        for p in REGS.values():
            for line in read_lines(p):
                m = re.match(r"^\| ((?:IN|MY|MX)-C\d+) \|", line)
                if m:
                    self.assertNotIn(m.group(1), ALL_ROWS)

    def test_pointer_prefix_matches_pack(self):
        # India rows are cited from the India pack, MY from Malaysia, MX from Mexico (plus fieldwork test programs)
        for f, n, pid, _, _ in pointers():
            if "gia-pack-india" in f:
                self.assertTrue(pid.startswith("IN-"), (f, n, pid))
            if "gia-pack-malaysia" in f:
                self.assertTrue(pid.startswith("MY-"), (f, n, pid))
            if "gia-pack-mexico" in f:
                self.assertTrue(pid.startswith("MX-"), (f, n, pid))


def print_list(out=sys.stdout):
    rows = sorted(pointers(), key=lambda r: (r[0], r[1]))
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pointer_topics.tsv")
    with open(path, "w", encoding="utf-8") as fh:
        for f, n, pid, topic, sent in rows:
            fh.write(f"{f}:{n}\t{pid}\t{topic}\t{sent[:200]}\n")
    for f, n, pid, topic, sent in rows:
        out.write(f"{os.path.basename(f)}:{n}\t{pid}\t{topic}\n")
    out.write(f"# {len(rows)} pointers across {len({r[0] for r in rows})} files, {len({r[2] for r in rows})} distinct rows\n")


if __name__ == "__main__":
    if "--list" in sys.argv:
        print_list()
    else:
        unittest.main()
