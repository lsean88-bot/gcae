import importlib.util, os, unittest, tempfile, csv, json
P = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "skills", "gia-racm-icfr-testing", "scripts", "deficiency_aggregation_check.py")
spec = importlib.util.spec_from_file_location("dac", P); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

def row(i, sc="CD", ac=None, proc="P2P", comp="Control Activities", **kw):
    r = {"Def ID": i, "Control ID": "C-" + i, "Finding Ref": "F-" + i, "Process": proc, "COSO Component": comp,
         "Standalone Class": sc, "Aggregated Class": ac or sc, "Rationale": "x", "Related To": "", "Mgmt Response Ref": ""}
    r.update(kw); return {m.norm(k): v for k, v in r.items()}

def msgs(rows): return [(i["severity"], i["message"]) for i in m.check(rows)]

class T(unittest.TestCase):
    def test_clean(self):
        self.assertEqual(m.check([row("D1"), row("D2", proc="Payroll")]), [])
    def test_missing_and_dup(self):
        r = row("D1"); r["rationale"] = ""
        self.assertTrue(any("missing required field: rationale" in x[1] for x in msgs([r])))
        self.assertTrue(any("duplicate" in x[1] for x in msgs([row("D1"), row("D1")])))
    def test_bad_class_and_mn(self):
        out = msgs([row("D1", sc="MN", ac="MN")])
        self.assertTrue(any("MN is retired" in x[1] for x in out))
    def test_aggregated_below_standalone(self):
        self.assertTrue(any("below standalone" in x[1] for x in msgs([row("D1", sc="SD", ac="CD", **{"Mgmt Response Ref": "MR1"})])))
    def test_related_unresolved(self):
        self.assertTrue(any("does not resolve" in x[1] for x in msgs([row("D1", **{"Related To": "D9"})])))
    def test_sd_mw_need_response(self):
        self.assertTrue(any("management response" in x[1] for x in msgs([row("D1", sc="SD")])))
        self.assertFalse(any("management response" in x[1] for x in msgs([row("D1", sc="SD", **{"Mgmt Response Ref": "MR1"})])))
    def test_three_cd_trigger(self):
        out = msgs([row("D1"), row("D2"), row("D3")])
        self.assertTrue(any(s == "WARN" and "aggregation to SD" in t for s, t in out))
        resolved = [row("D1", ac="SD", **{"Mgmt Response Ref": "M"}), row("D2"), row("D3")]
        self.assertFalse(any("aggregation to SD" in t for _, t in msgs(resolved)))
    def test_two_sd_trigger(self):
        a = row("D1", sc="SD", **{"Mgmt Response Ref": "M1"}); b = row("D2", sc="SD", proc="AR", **{"Mgmt Response Ref": "M2"})
        self.assertTrue(any("aggregation to MW" in t for _, t in msgs([a, b])))
    def test_itgc(self):
        r = row("D1", sc="SD", **{"Mgmt Response Ref": "M", "ITGC Failure": "yes", "ITGC Dependent Controls": 5})
        self.assertTrue(any("MW trigger" in t for _, t in msgs([r])))
        r2 = row("D1", **{"ITGC Failure": "yes"})
        self.assertTrue(any("without dependent" in t for _, t in msgs([r2])))
    def test_empty_and_cli(self):
        self.assertEqual(msgs([])[0][0], "ERROR")
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "r.csv")
            rows = [row("D1"), row("D2", proc="Payroll")]
            with open(p, "w", newline="") as f:
                w = csv.DictWriter(f, fieldnames=["Def ID","Control ID","Finding Ref","Process","COSO Component","Standalone Class","Aggregated Class","Rationale","Related To","Mgmt Response Ref"]); w.writeheader()
                for r in rows: w.writerow({"Def ID": r["defid"], "Control ID": r["controlid"], "Finding Ref": r["findingref"], "Process": r["process"], "COSO Component": r["cosocomponent"], "Standalone Class": r["standaloneclass"], "Aggregated Class": r["aggregatedclass"], "Rationale": r["rationale"], "Related To": "", "Mgmt Response Ref": ""})
            self.assertEqual(m.main([p]), 0)
            pj = os.path.join(d, "r.json"); json.dump([{"Def ID": "D1"}], open(pj, "w"))
            self.assertEqual(m.main([pj]), 1)

if __name__ == "__main__": unittest.main()
