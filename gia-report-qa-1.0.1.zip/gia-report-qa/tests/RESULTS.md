# Test results (run 29-30 Oct 2026, python3 -I)

| Suite | Command | Result |
|---|---|---|
| Ported selftest (evidence-trace and board-brief scripts, incl. LibreOffice recalculation) | `python3 -I tests/selftest.py` | 121 checks, ALL PASSED (log: tests/selftest_output.txt) |
| New checks: consolidated_iar_check, profile_b_lint, tieout_check, qa_scan smoke, run_critique | `python3 -I tests/test_new_checks.py` | 36/36 passed (positive and negative cases) |
| Structure and hygiene (frontmatter, lengths, evals counts, agent tools, stale names, emoji, inline statutory figures) | `python3 -I tests/check_structure.py` | 118/118 passed |
| Evals (offline) | `python3 -I tests/run_evals.py` | 16/16 passed; lexical routing 39/42 should-trigger, 29/31 in-plugin redirects |

## Limits
- Live trigger evaluation needs Claude Code and was NOT run. The lexical router is a word-overlap heuristic.
- Overlap watchpoints from the heuristic: "escalated to the Board" routes to gia-presentation; "investigation summary for the AC" routes to gia-board-brief (description now says investigation summary belongs to gia-ia-report); "proofread this document" routes to gia-external-release.
- 10 retained legacy presentation evals are judge-graded and were only parsed; 3 runtime-layer evals not ported.
- build_pptx.py and render_pptx.py ported as-is, not exercised here.
- Scans test patterns, not truth.

## 1.0.1 defect-fix pass (30-Oct-2026)

| Item | Result |
|---|---|
| Test entry point re-run | selftest 121/121, new checks 36/36, structure 118/118, evals 16/16; shared validate_structure 218/0 (eval parser fixed). |
| `build/xref_check.py` (colon refs, in-skill links, router selections, description length, relative script paths, YAML frontmatter) | PASS: 0 findings |
| Economy: always-loaded name plus description tokens (chars/4) | skills 680, agents 697, commands 309, total 1686; longest skill or agent description 400 chars or fewer (target of 700 total still not met; each description is capped at 400) |
| D5 cross-references, D7 links, D13 script paths | Fixed and checked by xref_check.py |
