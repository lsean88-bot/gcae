#!/usr/bin/env python3
"""Self-test for the plugin's scripts. Run: python3 tests/selftest.py

Each detector is exercised on a known-positive case (must be flagged) AND a known-negative
case (must NOT be flagged). A script that merely runs without error has not been shown to work.
"""
import datetime as dt
import importlib.util
import json
import os
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
REG_DIR = os.path.join(ROOT, "skills", "gia-evidence-trace", "scripts")
BRIEF_DIR = os.path.join(ROOT, "skills", "gia-board-brief", "scripts")

failures = []
total = 0


def check(name, cond, detail=""):
    global total
    total += 1
    print(("PASS  " if cond else "FAIL  ") + name + ("" if cond else f"  -> {detail}"))
    if not cond:
        failures.append(name)


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def fill(ws, rows):
    headers = [c.value for c in ws[1]]
    for r, row in enumerate(rows, 2):
        for k, v in row.items():
            ws.cell(r, headers.index(k) + 1, v)


def run(script, *args):
    return subprocess.run([sys.executable, script, *args], capture_output=True, text=True)



def extended_checks(builder, load, tmp):
    """v1.1 additions: every defect found in the 5 Oct 2026 edge-case probe has a known-positive and
    a known-negative test here, so it cannot regress silently."""
    from openpyxl import load_workbook
    D = dt.date
    tc = os.path.join(REG_DIR, "trace_check.py")
    bd = os.path.join(BRIEF_DIR, "brief_data.py")

    def base(name, mutate=None):
        path = os.path.join(tmp, name + ".xlsx")
        builder.build(path, "x", blank=True)
        wb = load_workbook(path)
        fill(wb["Evidence"], [{"EV ID": "EV-021", "Reliability (R1-R5)": "R2"},
                              {"EV ID": "EV-031", "Reliability (R1-R5)": "R4"},
                              {"EV ID": "EV-040", "Reliability (R1-R5)": "R5"}])
        fill(wb["Criteria"], [{"CRIT ID": "CRIT-DOA-02"}])
        fill(wb["Procedures"], [{"PROC ID": "PROC-P2P-07", "Linked CRIT IDs": "CRIT-DOA-02"}])
        fill(wb["Workpapers"], [
            {"WP ID": "WP-P2P-07", "PROC ID": "PROC-P2P-07", "Evidence IDs": "EV-021", "Population size": 120,
             "Sample size": 25, "Exceptions found": 4, "Linked FIND IDs / reason no finding": "FIND-P2P-03",
             "Reviewed by": "Senior Auditor"},
            {"WP ID": "WP-CLS-01", "PROC ID": "PROC-P2P-07", "Evidence IDs": "EV-021", "Population size": 30,
             "Sample size": 10, "Exceptions found": 0, "Linked FIND IDs / reason no finding": "Closure test, no new finding"}])
        fill(wb["Findings"], [{"FIND ID": "FIND-P2P-03", "CRIT IDs": "CRIT-DOA-02", "WP IDs": "WP-P2P-07",
                               "EV IDs": "EV-021", "Rating": "High", "Approval status": "Auditor-approved",
                               "Approved by": "CAE", "Approved on": D(2026, 9, 25), "Owner": "FC",
                               "Target date": D(2026, 12, 31)}])
        fill(wb["Mgmt_Responses"], [{"MR ID": "MR-P2P-03", "FIND ID": "FIND-P2P-03"}])
        fill(wb["Actions"], [{"ACT ID": "ACT-P2P-03a", "FIND ID": "FIND-P2P-03", "Action": "x", "Owner": "FC",
                              "Target date": D(2026, 12, 1), "Status": "In progress"}])
        if mutate:
            mutate(wb)
        wb.save(path)
        return path

    def setc(sheet, header, value, row=2):
        def f(wb):
            ws = wb[sheet]
            ws.cell(row, [c.value for c in ws[1]].index(header) + 1).value = value
        return f

    def both(*fs):
        def f(wb):
            for g in fs:
                g(wb)
        return f

    def items(path, *extra):
        out = os.path.join(tmp, "o.json")
        r = run(tc, "--register", path, "--json", out, *extra)
        return r, (json.load(open(out))["items"] if os.path.exists(out) and r.returncode in (0, 1) else [])

    def codes(its, sev=None):
        return {i["code"] for i in its if sev is None or i["severity"] == sev}

    if os.path.exists(os.path.join(tmp, "o.json")):
        os.remove(os.path.join(tmp, "o.json"))

    # baseline negative: clean register raises nothing
    r, its = items(base("x0"))
    check("v1.1 NEGATIVE: clean register has no errors or warnings", r.returncode == 0 and not codes(its, "WARN") and not codes(its, "ERROR"), its)

    # R12 closure rule
    r, its = items(base("x1", setc("Actions", "Status", "Closed - validated")))
    check("R12: 'Closed - validated' with no validation workpaper is an ERROR, exit 1",
          r.returncode == 1 and any(i["code"] == "R12" and i["severity"] == "ERROR" for i in its), its)
    ok_close = both(setc("Actions", "Status", "Closed - validated"), setc("Actions", "Validation WP ID", "WP-CLS-01"),
                    setc("Actions", "Closure evidence EV IDs", "EV-021"), setc("Actions", "Validated (Y/N)", "Y"))
    r, its = items(base("x2", ok_close))
    check("R12 NEGATIVE: validated closure with a workpaper, R2 evidence and Y raises nothing",
          r.returncode == 0 and not codes(its, "WARN") and not codes(its, "ERROR"), its)
    r, its = items(base("x3", both(ok_close, setc("Actions", "Closure evidence EV IDs", "EV-040"))))
    check("R12: validated closure resting on R5 closure evidence is an ERROR",
          any(i["code"] == "R12" and i["severity"] == "ERROR" and "R5" in i["message"] for i in its), its)
    r, its = items(base("x3b", both(ok_close, setc("Actions", "Closure evidence EV IDs", "EV-031"))))
    check("R12: validated closure resting only on R4 closure evidence is a WARN, not an ERROR",
          any(i["code"] == "R12" and i["severity"] == "WARN" for i in its) and r.returncode == 0, its)
    r, its = items(base("x3c", both(ok_close, setc("Actions", "Validated (Y/N)", "N"))))
    check("R12: status validated but 'Validated (Y/N)' = N is flagged", any(i["code"] == "R12" for i in its), its)
    r, its = items(base("x3d", both(ok_close, setc("Findings", "Approval status", "Draft"))))
    check("R12: validated closure against an unapproved finding is an ERROR",
          any(i["code"] == "R12" and i["severity"] == "ERROR" and "not an approved" in i["message"] for i in its), its)

    # R13 vocabulary
    r, its = items(base("x4", setc("Findings", "Approval status", "Auditor approved")))
    check("R13: misspelt approval status flagged with a suggestion, finding treated as unapproved",
          any(i["code"] == "R13" and "Auditor-approved" in i["message"] for i in its), its)
    r, its = items(base("x5", setc("Actions", "Status", "closed - validated")))
    check("R13: lower-case action status flagged as WARN", any(i["code"] == "R13" and i["severity"] == "WARN" for i in its), its)
    # R14 orphan
    r, its = items(base("x6", both(setc("Findings", "Title", "orphan", row=3), setc("Findings", "Rating", "High", row=3))))
    check("R14: content row with no ID flagged as WARN", any(i["code"] == "R14" and i["severity"] == "WARN" for i in its), its)
    check("R14 NEGATIVE: unused formatted rows (formulas only) are not flagged",
          not any(i["code"] == "R14" for i in items(base("x6b"))[1]))
    # R15 text dates
    r, its = items(base("x7", setc("Actions", "Target date", "31/08/2026")))
    check("R15: text date in Target date flagged as WARN", any(i["code"] == "R15" and i["severity"] == "WARN" for i in its), its)
    # R16 R4 only
    r, its = items(base("x8", setc("Findings", "EV IDs", "EV-031")))
    check("R16: approved finding resting only on R4 evidence flagged (WARN)",
          any(i["code"] == "R16" and i["severity"] == "WARN" for i in its) and r.returncode == 0, its)
    r, its = items(base("x8b", setc("Findings", "EV IDs", "EV-021, EV-031")))
    check("R16 NEGATIVE: R4 alongside R2 evidence is not flagged", not any(i["code"] == "R16" for i in its), its)
    # R17 empty
    blank_reg = os.path.join(tmp, "blank.xlsx")
    builder.build(blank_reg, "blank", blank=True)
    r, its = items(blank_reg)
    check("R17: blank register is an ERROR with exit 1, not a silent pass",
          r.returncode == 1 and any(i["code"] == "R17" and i["severity"] == "ERROR" for i in its), (r.returncode, its))
    # graceful failures
    r = run(tc, "--register", os.path.join(tmp, "nope.xlsx"))
    check("graceful: missing register -> exit 2 with message, no traceback",
          r.returncode == 2 and "Traceback" not in r.stderr and "not found" in r.stderr, r.stderr)
    junk = os.path.join(tmp, "junk.xlsx")
    open(junk, "w").write("not a zip")
    r = run(tc, "--register", junk)
    check("graceful: corrupt .xlsx -> exit 2, no traceback", r.returncode == 2 and "Traceback" not in r.stderr, r.stderr)
    r = run(bd, "--register", junk)
    check("graceful: brief_data on corrupt .xlsx -> exit 2, no traceback", r.returncode == 2 and "Traceback" not in r.stderr, r.stderr)
    good = base("x9")
    pdf = os.path.join(tmp, "r.pdf")
    open(pdf, "wb").write(b"%PDF-1.4\xff\xfe")
    binf = os.path.join(tmp, "r.bin")
    open(binf, "wb").write(b"\xff\xfe\x00\x01")
    for name, path in (("pdf", pdf), ("binary", binf), ("missing", os.path.join(tmp, "nope.md"))):
        r, its = items(good, "--report", path)
        check(f"graceful: {name} report -> P00 ERROR, no traceback",
              any(i["code"] == "P00" and i["severity"] == "ERROR" for i in its) and "Traceback" not in r.stderr, (r.stderr, its))
    # P07 loose references
    lc = os.path.join(tmp, "lc.md")
    open(lc, "w").write("# S\n\nIn 4 of 25 payments approval was missing. [find-p2p-03; WP-P2P-3]\n")
    r, its = items(good, "--report", lc)
    check("P07: lower-case and malformed IDs in a report are flagged, not ignored",
          sum(1 for i in its if i["code"] == "P07") == 2, [i for i in its if i["code"] == "P07"])
    ok_md = os.path.join(tmp, "ok.md")
    open(ok_md, "w").write("# S\n\nIn 4 of 25 payments approval was missing. [FIND-P2P-03; WP-P2P-07] The act-of-God clause and Mr-Rao were not used.\n")
    r, its = items(good, "--report", ok_md)
    check("P07 NEGATIVE: valid IDs and ordinary hyphenated words raise nothing", not any(i["code"] == "P07" for i in its), its)

    # P08 declared-untraced document: one warning, not one per paragraph
    decl = os.path.join(tmp, "decl.md")
    open(decl, "w").write("# Brief\n\nBasis: draft. Evidence reference not available — auditor validation required "
                          "(none supplied).\n\n38 workers were affected for 8 months.\n\nThe estimate is Rs 4.2 lakh.\n\n"
                          "About 12% of contractors may be affected.\n")
    r, its = items(good, "--report", decl)
    check("P08: declared-untraced draft gives exactly one P08 warning and no per-paragraph P04",
          sum(1 for i in its if i["code"] == "P08") == 1 and not any(i["code"] == "P04" for i in its), [i["code"] for i in its])
    undecl = os.path.join(tmp, "undecl.md")
    open(undecl, "w").write("# Brief\n\n38 workers were affected for 8 months.\n\nThe estimate is Rs 4.2 lakh.\n")
    r, its = items(good, "--report", undecl)
    check("P08 NEGATIVE: an undeclared untraced document still gets P04 on its figures, and no P08",
          any(i["code"] == "P04" for i in its) and not any(i["code"] == "P08" for i in its), [i["code"] for i in its])
    mixed = os.path.join(tmp, "mixed.md")
    open(mixed, "w").write("# Brief\n\nEvidence reference not available — auditor validation required.\n\n"
                           "In 4 of 25 payments approval was missing. [FIND-P2P-03; WP-P2P-07]\n\nThe estimate is Rs 4.2 lakh.\n")
    r, its = items(good, "--report", mixed)
    check("P08 NEGATIVE: a banner does not excuse figures when the document does cite IDs (P04 still fires, no P08)",
          any(i["code"] == "P04" for i in its) and not any(i["code"] == "P08" for i in its), [i["code"] for i in its])

    def bdata(path, today="2026-10-06"):
        jo = os.path.join(tmp, "b.json")
        r = run(bd, "--register", path, "--json", jo, "--md", os.path.join(tmp, "b.md"), "--today", today)
        return r, (json.load(open(jo)) if r.returncode == 0 else None)
    # ---- critique round (7 Oct 2026): each item below came from the independent review
    import re as _re, glob as _glob
    try:
        import yaml as _yaml
        bad_fm = []
        for fp in _glob.glob(os.path.join(ROOT, "commands", "*.md")) + _glob.glob(os.path.join(ROOT, "agents", "*.md")) \
                + _glob.glob(os.path.join(ROOT, "skills", "*", "SKILL.md")):
            m = _re.match(r"---\n(.*?)\n---", open(fp).read(), _re.S)
            try:
                _yaml.safe_load(m.group(1))
            except Exception as e:
                bad_fm.append((os.path.basename(fp), str(e)[:50]))
        check("frontmatter: every command, agent and SKILL.md parses as strict YAML", not bad_fm, bad_fm)
    except ImportError:
        print("SKIP  frontmatter YAML check (pyyaml not installed)")
    r, its = items(base("z1", setc("Findings", "Rating", "high")))
    check("R13: rating 'high' flagged for case; High/Critical checks still run", any(i["code"] == "R13" and "rating" in i["message"] for i in its), its)
    r, its = items(base("z1b", both(setc("Findings", "Rating", "Severe"), setc("Findings", "Owner", None))))
    check("R13: unknown rating 'Severe' flagged", any(i["code"] == "R13" and "Severe" in i["message"] for i in its), its)
    r, its = items(base("z2", both(ok_close, setc("Actions", "Validation WP ID", "WP-P2P-07"))))
    check("R12: validation WP equal to the finding's own original test WP is flagged",
          any(i["code"] == "R12" and "original test" in i["message"] for i in its), its)
    check("R12 NEGATIVE: a separate re-test WP is not flagged for independence", not any("original test" in i["message"] for i in items(base("z2b", ok_close))[1]))
    r, its = items(base("z3", both(setc("Findings", "Approval status", "Withdrawn"))))
    check("R12: in-progress action on a Withdrawn finding is flagged", any(i["code"] == "R12" and "Withdrawn" in i["message"] for i in its), its)
    r, its = items(base("z4", setc("Findings", "CRIT IDs", "CRIT-DOA-02;")))
    check("R18: semicolon in a list cell flagged (workbook counts commas)", any(i["code"] == "R18" for i in its), its)
    def ce_mut(wb):
        fill(wb["Exceptions_Gaps"], [{"Item ID": "CE-001", "Type": "CE", "WP ID": "WP-P2P-07", "Status": "open"}])
    r, its = items(base("z5", ce_mut))
    check("R11: open contradictory-evidence item (status 'open', any case) surfaced for the approved finding",
          any(i["code"] == "R11" and "CE-001" in i["message"] for i in its), its)
    r, d = bdata(base("z5b", ce_mut))
    check("brief_data: open CE item listed with the finding's open evidence gaps", d["findings"][0]["open_evidence_gaps"] == ["CE-001"], d["findings"][0]["open_evidence_gaps"])
    def blank_approval(wb):
        ws = wb["Findings"]; hdr = [c.value for c in ws[1]]
        for h in ("Approved by", "Approved on"):
            ws.cell(2, hdr.index(h) + 1).value = None
    r, d = bdata(base("z6", blank_approval))
    check("brief_data: approved finding with blank approver/date raises a data-quality warning",
          any("approver or approval date" in w for w in d["warnings"]), d["warnings"])
    r, d = bdata(base("z7", both(setc("Actions", "Status", "Risk accepted"), setc("Actions", "Target date", D(2026, 1, 1)))))
    check("brief_data: past-due 'Risk accepted' action is not reported OVERDUE",
          d["findings"][0]["actions"][0]["flag"].startswith("Risk accepted"), d["findings"][0]["actions"][0]["flag"])
    r, d = bdata(base("z8", setc("Findings", "Rating", "high")))
    check("brief_data: rating 'high' still counted as High", d["summary"]["high_or_critical"] == 1, d["summary"])
    ra = both(setc("Actions", "Status", "Risk accepted"))
    r, its = items(base("ra1", ra))
    check("R19: 'Risk accepted' with no authority/date is an ERROR", any(i["code"] == "R19" and i["severity"] == "ERROR" for i in its), its)
    ra_ok = both(setc("Actions", "Status", "Risk accepted"), setc("Actions", "Risk accepted by", "Audit Committee"),
                 setc("Actions", "Risk accepted on", D(2026, 9, 30)))
    r, its = items(base("ra2", ra_ok))
    check("R19 NEGATIVE: 'Risk accepted' with authority and date raises no R19", not any(i["code"] == "R19" for i in its), its)
    for nm, keep in (("ra5", "Risk accepted by"), ("ra6", "Risk accepted on")):
        val = "Audit Committee" if keep.endswith("by") else D(2026, 9, 30)
        r, its = items(base(nm, both(setc("Actions", "Status", "Risk accepted"), setc("Actions", "Risk accepted by" if keep.endswith("by") else "Risk accepted on", val))))
        check(f"R19: only '{keep}' filled (the other blank) is still an ERROR", any(i["code"] == "R19" for i in its), its)
    r, d = bdata(base("ra3", ra_ok))
    check("brief_data: Risk accepted shows the authority and date", "Audit Committee" in d["findings"][0]["actions"][0]["flag"], d["findings"][0]["actions"][0]["flag"])
    r, d = bdata(base("ra4", ra))
    check("brief_data: Risk accepted with blank authority is warned, not reported as accepted",
          "do not report" in d["findings"][0]["actions"][0]["flag"] and any("Risk accepted" in w for w in d["warnings"]), d["warnings"])
    r, its = items(base("rv1", setc("Workpapers", "Reviewed by", None)))
    check("R20: workpaper behind an approved finding with no reviewer is warned", any(i["code"] == "R20" and "no reviewer" in i["message"] for i in its), its)
    r, its = items(base("rv2", setc("Workpapers", "Reviewed by", "UNREVIEWED")))
    check("R20: workpaper marked UNREVIEWED is surfaced for the approver", any(i["code"] == "R20" and "UNREVIEWED" in i["message"] for i in its), its)
    import openpyxl as _ox
    wbb = _ox.load_workbook(base("ft1")); fb = [c.value for c in wbb["Dashboard"]["A"] if c.value and "Counts" in str(c.value)]
    check("blank register: Dashboard footnote does not mention an example row", fb and "illustrative" not in fb[0], fb)
    p04_rep = os.path.join(tmp, "p04.md"); open(p04_rep, "w").write("# B\n\nLosses reached RM 9,000,000 last year.\n")
    r2 = run(tc, "--register", good, "--report", p04_rep)
    check("trace_check: P04 heuristic note is printed when P04 is raised", "P04" in r2.stdout and "heuristic" in r2.stdout, r2.stdout[-400:])
    # P10 --source
    src = os.path.join(tmp, "src.md")
    open(src, "w").write("4 of 25 sampled payments lacked approval. Estimated gap Rs 4.2 lakh. 38 workers.")
    rep_ok = os.path.join(tmp, "rep_ok.md")
    open(rep_ok, "w").write("# B\n\nIn 4 of 25 sampled payments approval was missing; 38 workers; Rs 4.2 lakh. [FIND-P2P-03; WP-P2P-07]\n")
    rep_bad = os.path.join(tmp, "rep_bad.md")
    open(rep_bad, "w").write("# B\n\nIn 4 of 25 sampled payments approval was missing; 38 workers; Rs 4.2 lakh, about 30% of vendors and RM 9,000,000. [FIND-P2P-03; WP-P2P-07]\n")
    r, its = items(good, "--report", rep_bad, "--source", src)
    check("P10: figures absent from the source (30%, 9000000) are flagged",
          any(i["code"] == "P10" and "9000000" in i["message"] and "30" in i["message"] for i in its), [i for i in its if i["code"] == "P10"])
    r, its = items(good, "--report", rep_ok, "--source", src)
    check("P10 NEGATIVE: report whose figures all come from the source raises no P10", not any(i["code"] == "P10" for i in its), its)
    # ---- qa_gate: sign-off tied to file bytes
    qg = os.path.join(REG_DIR, "qa_gate.py")
    import shutil
    rep_g = os.path.join(tmp, "gate_rep.md"); shutil.copy(rep_ok, rep_g)
    reg_g = os.path.join(tmp, "gate_reg.xlsx"); shutil.copy(good, reg_g)
    r = run(qg, "verify", "--register", reg_g, "--report", rep_g)
    check("qa_gate: verify with no record is NOT passed", r.returncode == 1 and "no QA record" in r.stderr, r.stderr)
    r = run(qg, "record", "--register", reg_g, "--report", rep_g, "--reviewer", "not-run")
    r = run(qg, "verify", "--register", reg_g, "--report", rep_g)
    check("qa_gate: reviewer step not run -> NOT passed", r.returncode == 1 and "reviewer" in r.stderr, r.stderr)
    r = run(qg, "record", "--register", reg_g, "--report", rep_g, "--reviewer", "reviewed")
    r = run(qg, "verify", "--register", reg_g, "--report", rep_g)
    check("qa_gate NEGATIVE: clean checks + reviewer declared + unchanged files -> PASSED", r.returncode == 0 and "GATE PASSED" in r.stdout, r.stderr + r.stdout)
    with open(rep_g, "a") as fh: fh.write("\nOne more sentence added after QA.\n")
    r = run(qg, "verify", "--register", reg_g, "--report", rep_g)
    check("qa_gate: report edited after the checks -> NOT passed", r.returncode == 1 and "report changed" in r.stderr, r.stderr)
    rep_bad2 = os.path.join(tmp, "gate_bad.md"); shutil.copy(rep_bad, rep_bad2)
    reg_bad = os.path.join(tmp, "gate_reg2.xlsx"); shutil.copy(base("gq2", setc("Findings", "Approval status", "Draft")), reg_bad)
    run(qg, "record", "--register", reg_bad, "--report", rep_bad2, "--reviewer", "reviewed")
    r = run(qg, "verify", "--register", reg_bad, "--report", rep_bad2)
    check("qa_gate: trace_check failure (cites an unapproved finding) -> NOT passed", r.returncode == 1 and "trace_check exit" in r.stderr, r.stderr)
    r = run(qg, "verify", "--register", os.path.join(tmp, "nope.xlsx"), "--report", rep_g)
    check("qa_gate: missing file -> exit 2, no traceback", r.returncode == 2 and "Traceback" not in r.stderr, r.stderr)

    # ---- import_rows
    ir = os.path.join(REG_DIR, "import_rows.py")
    csvp = os.path.join(tmp, "in.csv")
    open(csvp, "w", encoding="utf-8").write(
        "Ref,Heading,Level,Sign off,Days to due\nFIND-IMP-01,Missing approval,High,CAE-approved,5\nFIND-IMP-02,Late posting,Low,,\n")
    wbi = base("imp0")
    outp = os.path.join(tmp, "imp_out.xlsx")
    r = run(ir, "--workbook", wbi, "--sheet", "Findings", "--csv", csvp, "--out", outp,
            "--map", "Ref=FIND ID", "Heading=Title", "Level=Rating", "Sign off=Approval status")
    wi = load_workbook(outp)["Findings"]; hi = [c.value for c in wi[1]]
    rows_i = {wi.cell(r_, 1).value: r_ for r_ in range(2, wi.max_row + 1) if wi.cell(r_, 1).value}
    check("import_rows: rows appended below existing data, mapped by column name",
          "FIND-IMP-01" in rows_i and "FIND-IMP-02" in rows_i and wi.cell(rows_i["FIND-IMP-01"], hi.index("Rating") + 1).value == "High", rows_i)
    check("import_rows: an imported 'CAE-approved' is forced to Draft and reported (approval is a human act)",
          wi.cell(rows_i["FIND-IMP-01"], hi.index("Approval status") + 1).value == "Draft" and "reset to Draft" in r.stdout, r.stdout)
    check("import_rows: unmapped column reported and not written", "NOT IMPORTED" in r.stdout and "Days to due" in r.stdout, r.stdout)
    check("import_rows: original workbook left untouched when --out differs",
          load_workbook(wbi)["Findings"].cell(3, 1).value != "FIND-IMP-01")
    r = run(ir, "--workbook", wbi, "--sheet", "Nope", "--csv", csvp)
    # repeated --map flags must all apply (UAT3 defect)
    outp2 = os.path.join(tmp, "imp_out2.xlsx")
    r2 = run(ir, "--workbook", wbi, "--sheet", "Findings", "--csv", csvp, "--out", outp2,
             "--map", "Ref=FIND ID", "--map", "Heading=Title", "--map", "Level=Rating", "--map", "Sign off=Approval status")
    w2 = load_workbook(outp2)["Findings"]
    ids2 = [w2.cell(r_, 1).value for r_ in range(2, w2.max_row + 1)]
    ni = r2.stdout.split("NOT IMPORTED")[1] if "NOT IMPORTED" in r2.stdout else ""
    check("import_rows: repeated --map flags all apply, none silently dropped",
          "FIND-IMP-01" in ids2 and "Heading" not in ni and "Level" not in ni and "Ref" not in ni, r2.stdout)
    check("import_rows: unknown sheet -> exit 2, no traceback", r.returncode == 2 and "Traceback" not in r.stderr, r.stderr)

    # docx table order + heading with figure
    try:
        import docx as _docx
        dp = os.path.join(tmp, "t.docx")
        dd = _docx.Document()
        dd.add_heading("BOARD-LEVEL MESSAGE", 1); dd.add_paragraph("Prose message with no tags.")
        dd.add_heading("Findings", 1)
        tb = dd.add_table(rows=1, cols=2); tb.rows[0].cells[0].text = "Exposure"; tb.rows[0].cells[1].text = "RM 5,000,000 lost"
        dd.add_paragraph("# RM 7,000,000 lost")
        dd.save(dp)
        r, its = items(good, "--report", dp)
        p04 = [i for i in its if i["code"] == "P04"]
        check("docx: unreferenced figure in a table (after a Board-message section) and in a heading are both flagged",
              len(p04) >= 2, [i["message"][:60] for i in its])
    except ImportError:
        print("SKIP  docx table-order check (python-docx missing)")

    # ---- brief_data hardening
    r, d = bdata(base("y1", setc("Actions", "Status", "Closed - validated")))
    fl = d["findings"][0]["actions"][0]["flag"]
    check("brief_data: 'Closed - validated' with no validation WP is NOT reported as validated",
          fl.startswith("Marked validated but NO validation") and d["summary"]["actions_closed_validated"] == 0, fl)
    r, d = bdata(base("y2", ok_close))
    check("brief_data NEGATIVE: properly validated closure is reported as validated",
          d["findings"][0]["actions"][0]["flag"] == "Closed and validated" and d["summary"]["actions_closed_validated"] == 1)
    r, d = bdata(base("y3", setc("Actions", "Status", "closed - validated")))
    check("brief_data: lower-case status is 'not recognised', never silently 'On track'",
          d["findings"][0]["actions"][0]["flag"].startswith("Status not recognised"))
    r, d = bdata(base("y4", setc("Findings", "Approval status", "Auditor approved")))
    check("brief_data: misspelt approval status excluded WITH a typo hint and a warning",
          not d["findings"] and "did you mean 'Auditor-approved'" in d["excluded"][0]["reason"] and d["warnings"])
    def gap_mut(wb):
        setc("Findings", "WP IDs", "WP-P2P-07; WP-P2P-08")(wb)
        fill(wb["Exceptions_Gaps"], [{"Item ID": "GAP-001", "Type": "GAP", "WP ID": "WP-P2P-07", "Status": "Open"}])
    r, d = bdata(base("y5", gap_mut))
    check("brief_data: open GAP found when the finding lists WPs separated by a semicolon",
          d["findings"][0]["open_evidence_gaps"] == ["GAP-001"], d["findings"][0]["open_evidence_gaps"])
    r, d = bdata(base("y6", setc("Actions", "Target date", "31/08/2026")))
    check("brief_data: text date is 'not machine-readable', not 'No due date recorded'",
          d["findings"][0]["actions"][0]["flag"].startswith("Due date not machine-readable"))
    r, d = bdata(base("y7", setc("Findings", "Approval status", "Draft")))
    check("brief_data: no approved findings -> loud notice in the output, exit 0",
          r.returncode == 0 and "NO APPROVED FINDINGS" in open(os.path.join(tmp, "b.md")).read())

    # ---- drift guards between scripts and the workbook builder
    tcm = load(tc, "tcm"); bdm = load(bd, "bdm")
    check("drift guard: finding statuses in both scripts equal the workbook dropdown",
          list(tcm.FIND_STATUSES) == builder.LISTS["Findings"]["L"].split(",") == list(bdm.FIND_STATUSES))
    check("drift guard: action statuses in both scripts equal the workbook dropdown",
          list(tcm.ACT_STATUSES) == builder.LISTS["Actions"]["F"].split(",") == list(bdm.ACT_STATUSES))
    probes = ["EV-021 to EV-024", "WP-P2P-07; WP-P2P-08, WP-INV-01", "FIND-P2P-03a", "EV-021–EV-023", "none", "", None,
              "ev-021 EV-1 CRIT-DOA-02", "WP-01 to 15 samples", "WP-01–15 samples", "EV-021 to 024", "EV-021–024; WP-03"]
    for mod_name, mod in (("trace_check", tcm), ("brief_data", bdm)):
        check(f"{mod_name}: 'WP-01 to 15 samples' is one ID, not a range", sorted(set(mod.extract_ids("WP-01 to 15 samples"))) == ["WP-01"])
        check(f"{mod_name}: 'WP-01\u201315 samples' is one ID", sorted(set(mod.extract_ids("WP-01\u201315 samples"))) == ["WP-01"])
        check(f"{mod_name} NEGATIVE: 'EV-021\u2013024' and 'EV-021 to EV-024' still expand to four IDs",
              len(set(mod.extract_ids("EV-021\u2013024"))) == 4 and len(set(mod.extract_ids("EV-021 to EV-024"))) == 4)
    r, its = items(base("rg1", setc("Findings", "WP IDs", "WP-P2P-07 to 08")))
    check("R18: ambiguous 'WP-P2P-07 to 08' in a register cell is warned", any(i["code"] == "R18" and "ambiguous" in i["message"] for i in its), its)
    check("drift guard: trace_check and brief_data extract identical IDs",
          all(tcm.extract_ids(x) == bdm.extract_ids(x) for x in probes),
          [(x, tcm.extract_ids(x), bdm.extract_ids(x)) for x in probes if tcm.extract_ids(x) != bdm.extract_ids(x)])

    # ---- workbook closure-check column (recalculated)
    recalc = "/mnt/skills/public/xlsx/scripts/recalc.py"
    if os.environ.get("GIA_SKIP_RECALC"):
        recalc = "/nonexistent"
    if os.path.exists(recalc):
        def two_rows(wb):
            fill(wb["Actions"], [
                {"ACT ID": "ACT-P2P-03a", "FIND ID": "FIND-P2P-03", "Status": "Closed - validated"},
                {"ACT ID": "ACT-P2P-03b", "FIND ID": "FIND-P2P-03", "Status": "Closed - validated",
                 "Validation WP ID": "WP-CLS-01"}])
        p1 = base("w1", two_rows)
        subprocess.run([sys.executable, recalc, p1, "180"], capture_output=True, text=True)
        w1 = load_workbook(p1, data_only=True)
        check("workbook: Closure check says NO VALIDATION WP when the workpaper is missing",
              w1["Actions"]["M2"].value == "NO VALIDATION WP", w1["Actions"]["M2"].value)
        check("workbook NEGATIVE: Closure check says OK when a validation workpaper is named",
              w1["Actions"]["M3"].value == "OK", w1["Actions"]["M3"].value)
        dash1 = {r[0]: r[1] for r in w1["Dashboard"].iter_rows(min_row=4, max_row=30, values_only=True) if r[0]}
        key = [k for k in dash1 if k.startswith("Marked 'Closed - validated' but NO")][0]
        check("workbook: dashboard counts validated-without-workpaper = 1 in the two-row case", dash1[key] == 1, dash1[key])


def main():
    from openpyxl import load_workbook
    builder = load(os.path.join(REG_DIR, "build_register_workbook.py"), "builder")
    tmp = tempfile.mkdtemp()
    reg = os.path.join(tmp, "fixture.xlsx")
    builder.build(reg, "Selftest", blank=True)
    D = dt.date

    wb = load_workbook(reg)
    fill(wb["Evidence"], [
        {"EV ID": "EV-021", "Reliability (R1-R5)": "R2"},
        {"EV ID": "EV-022", "Reliability (R1-R5)": "R2"},
        {"EV ID": "EV-030", "Reliability (R1-R5)": "R5"},
        {"EV ID": "EV-031", "Reliability (R1-R5)": "R4"},
    ])
    fill(wb["Criteria"], [{"CRIT ID": "CRIT-DOA-02"}, {"CRIT ID": "CRIT-INV-01"}])
    fill(wb["Procedures"], [{"PROC ID": "PROC-P2P-07", "Linked CRIT IDs": "CRIT-DOA-02"},
                            {"PROC ID": "PROC-INV-01", "Linked CRIT IDs": "CRIT-INV-01"}])
    fill(wb["Workpapers"], [
        {"WP ID": "WP-P2P-07", "PROC ID": "PROC-P2P-07", "Evidence IDs": "EV-021 to EV-022",
         "Population size": 120, "Sample size": 25, "Exceptions found": 4,
         "Linked FIND IDs / reason no finding": "FIND-P2P-03"},
        {"WP ID": "WP-INV-01", "PROC ID": "PROC-INV-01", "Evidence IDs": "EV-031",
         "Population size": 50, "Sample size": 60, "Exceptions found": 2,
         "Linked FIND IDs / reason no finding": "FIND-INV-01"},
        {"WP ID": "WP-HR-01", "PROC ID": "PROC-INV-01", "Evidence IDs": "EV-030",
         "Population size": 10, "Sample size": 10, "Exceptions found": 1,
         "Linked FIND IDs / reason no finding": "FIND-HR-02"},
    ])
    fill(wb["Exceptions_Gaps"], [{"Item ID": "GAP-001", "Type": "GAP", "WP ID": "WP-P2P-07", "Status": "Open"}])
    fill(wb["Findings"], [
        {"FIND ID": "FIND-P2P-03", "Title": "Approval evidence missing",
         "Business-language title": "Higher-value payments not consistently evidenced as approved",
         "Condition": "4 of 25 sampled payments lacked a Business Head approval record",
         "CRIT IDs": "CRIT-DOA-02", "WP IDs": "WP-P2P-07",
         "EV IDs": "EV-021 to EV-022", "Approved cause": "Not established",
         "Evidenced impact": "No confirmed unauthorised payment", "Potential impact": "Not quantified",
         "Rating": "High", "Approval status": "Auditor-approved",
         "Approved by": "CAE", "Approved on": D(2026, 9, 25), "Owner": "Finance Controller",
         "Target date": D(2026, 12, 31)},
        {"FIND ID": "FIND-INV-01", "CRIT IDs": "CRIT-INV-01", "WP IDs": "WP-INV-01, WP-INV-99",
         "EV IDs": "EV-031", "Rating": "High", "Approval status": "Auditor-approved",
         "Approved by": "CAE", "Approved on": D(2026, 9, 25), "Owner": None, "Target date": None},
        {"FIND ID": "FIND-HR-02", "CRIT IDs": "CRIT-INV-01", "WP IDs": "WP-HR-01", "EV IDs": "EV-030",
         "Rating": "Medium", "Approval status": "Auditor-approved", "Approved by": None, "Approved on": None},
        {"FIND ID": "FIND-DRAFT-01", "Rating": "Low", "Approval status": "Draft"},
    ])
    fill(wb["Mgmt_Responses"], [{"MR ID": "MR-P2P-03", "FIND ID": "FIND-P2P-03"}])
    fill(wb["Actions"], [
        {"ACT ID": "ACT-P2P-03a", "FIND ID": "FIND-P2P-03", "Action": "Workflow block",
         "Owner": "Finance Controller", "Target date": D(2026, 9, 1), "Status": "In progress",
         "Benefit measure": "100% approval trail"},
        {"ACT ID": "ACT-P2P-03b", "FIND ID": "FIND-P2P-03", "Action": "Interim review",
         "Owner": "Finance Controller", "Target date": D(2026, 10, 20), "Status": "Not started"},
        {"ACT ID": "ACT-P2P-03c", "FIND ID": "FIND-P2P-03", "Action": "Training",
         "Owner": "HR", "Target date": D(2026, 8, 1), "Status": "Closed - validated",
         "Validation WP ID": "WP-P2P-07"},
    ])
    wb.save(reg)

    good = os.path.join(tmp, "good.md")
    bad = os.path.join(tmp, "bad.md")
    with open(good, "w") as fh:
        fh.write("# Director summary\n\n## What the audit found\n\n"
                 "In 4 of 25 sampled payments, the approval record was missing. "
                 "[FIND-P2P-03; WP-P2P-07; EV-021 to EV-022]\n\n"
                 "## BOARD-LEVEL MESSAGE\n\n"
                 "Management cannot show that 4 of 25 higher-value payments were approved, and the Board "
                 "should ask for a dated fix.\n")
    with open(bad, "w") as fh:
        fh.write("# Director summary\n\n"
                 "The audit relied on EV-999 for this point.\n\n"
                 "A further matter is recorded in FIND-DRAFT-01.\n\n"
                 "In 5 of 25 sampled payments the approval was missing. [WP-P2P-07]\n\n"
                 "The company faces exposure of ₹4.2 lakh over eight months.\n\n"
                 "Remediation could cost RM 90,000. Evidence reference not available — auditor validation required.\n")

    tc = os.path.join(REG_DIR, "trace_check.py")
    out = os.path.join(tmp, "res_good.json")
    p = run(tc, "--register", reg, "--report", good, "--json", out)
    items = json.load(open(out))["items"]

    check("register: dangling WP-INV-99 detected (R04 error)",
          any(i["code"] == "R04" and "WP-INV-99" in i["message"] and i["severity"] == "ERROR" for i in items))
    check("register: sample > population detected (R10 error)",
          any(i["code"] == "R10" and "WP-INV-01" in i["message"] and i["severity"] == "ERROR" for i in items))
    check("register: High finding without owner/date detected (R07 error)",
          any(i["code"] == "R07" and "FIND-INV-01" in i["message"] and i["severity"] == "ERROR" for i in items))
    check("register: R5 evidence behind approved finding detected (R05 error)",
          any(i["code"] == "R05" and "FIND-HR-02" in i["message"] and i["severity"] == "ERROR" for i in items))
    check("register: approved finding without approver detected (R06 error)",
          any(i["code"] == "R06" and "FIND-HR-02" in i["message"] for i in items))
    check("register: draft finding with no links is a warning, not an error (R03 warn)",
          any(i["code"] == "R03" and "FIND-DRAFT-01" in i["message"] and i["severity"] == "WARN" for i in items))
    check("register NEGATIVE: fully linked FIND-P2P-03 raises no error",
          not any(i["severity"] == "ERROR" and "FIND-P2P-03" in i["message"] for i in items),
          [i for i in items if i["severity"] == "ERROR" and "FIND-P2P-03" in i["message"]])
    check("register NEGATIVE: range 'EV-021 to EV-022' resolves (no dangling EV-022)",
          not any(i["code"] == "R04" and "EV-02" in i["message"] for i in items))
    check("register: exit code 1 when errors exist", p.returncode == 1)

    rep_codes = {i["code"] for i in items if i["where"] == "good.md"}
    check("report NEGATIVE: well-referenced report with Board-message exemption raises nothing (P01-P05)",
          not (rep_codes & {"P01", "P02", "P03", "P04", "P05"}), rep_codes)

    out2 = os.path.join(tmp, "res_bad.json")
    run(tc, "--register", reg, "--report", bad, "--json", out2)
    bi = [i for i in json.load(open(out2))["items"] if i["where"] == "bad.md"]
    bc = {i["code"] for i in bi}
    check("report: cited ID absent from register flagged (P01)",
          "P01" in bc and any("EV-999" in i["message"] for i in bi))
    check("report: cited draft finding flagged as error (P02)",
          any(i["code"] == "P02" and i["severity"] == "ERROR" and "FIND-DRAFT-01" in i["message"] for i in bi))
    check("report: '5 of 25' contradicts WP-P2P-07 (4 of 25) flagged (P05)",
          any(i["code"] == "P05" and "5 of 25" in i["message"] for i in bi))
    check("report: figure with no reference flagged as possible untraced (P04)",
          any(i["code"] == "P04" and "4.2 lakh" in i["message"] for i in bi))
    check("report NEGATIVE: figure paragraph with the 'not available' wording is not P04, is acknowledged (P06)",
          not any(i["code"] == "P04" and "90,000" in i["message"] for i in bi) and "P06" in bc)

    out3 = os.path.join(tmp, "res_allow.json")
    run(tc, "--register", reg, "--report", bad, "--allow-draft", "--json", out3)
    ai = [i for i in json.load(open(out3))["items"] if i["code"] == "P02"]
    check("--allow-draft downgrades P02 to a warning", ai and all(i["severity"] == "WARN" for i in ai))

    clean = os.path.join(tmp, "clean.xlsx")
    builder.build(clean, "Clean example", blank=False)
    pc = run(tc, "--register", clean)
    check("register NEGATIVE: shipped illustrative example passes with exit 0", pc.returncode == 0, pc.stdout)

    exw = load_workbook(clean)
    exr = {h.value: i for i, h in enumerate(exw["Findings"][1])}
    check("workbook: shipped example finding is Draft with no approver or date (no approval a human did not set)",
          exw["Findings"].cell(2, exr["Approval status"] + 1).value == "Draft"
          and not exw["Findings"].cell(2, exr["Approved by"] + 1).value
          and not exw["Findings"].cell(2, exr["Approved on"] + 1).value)
    rp_ok = os.path.join(tmp, "p04note.md"); open(rp_ok, "w").write("# T\n\nPlain text with no figures.\n")
    pn = run(tc, "--register", clean, "--report", rp_ok, "--allow-draft")
    check("trace_check: P04 heuristic note printed whenever a report is checked", "P04 is a heuristic" in pn.stdout, pn.stdout)

    # ---- brief_data.py
    bd = os.path.join(BRIEF_DIR, "brief_data.py")
    jo = os.path.join(tmp, "facts.json")
    mo = os.path.join(tmp, "facts.md")
    pb = run(bd, "--register", reg, "--json", jo, "--md", mo, "--today", "2026-10-03")
    facts = json.load(open(jo))
    ids = [f["id"] for f in facts["findings"]]
    check("brief_data: approved findings included, draft excluded",
          set(ids) == {"FIND-P2P-03", "FIND-INV-01", "FIND-HR-02"}
          and any(e["id"] == "FIND-DRAFT-01" for e in facts["excluded"]), (ids, facts["excluded"]))
    check("brief_data: findings ordered by rating (High before Medium)",
          ids.index("FIND-P2P-03") < ids.index("FIND-HR-02") and ids.index("FIND-INV-01") < ids.index("FIND-HR-02"), ids)
    acts = {a["id"]: a for f in facts["findings"] for a in f["actions"]}
    check("brief_data: past-due action flagged OVERDUE", acts["ACT-P2P-03a"]["flag"] == "OVERDUE", acts)
    check("brief_data NEGATIVE: action due in 17 days is 'Due within 30 days', not overdue",
          acts["ACT-P2P-03b"]["flag"] == "Due within 30 days", acts)
    check("brief_data NEGATIVE: validated-closed action is never overdue even with a past date",
          acts["ACT-P2P-03c"]["flag"] == "Closed and validated", acts)
    p3 = [f for f in facts["findings"] if f["id"] == "FIND-P2P-03"][0]
    check("brief_data: condition text copied verbatim (no paraphrase)",
          p3["condition"] == "4 of 25 sampled payments lacked a Business Head approval record", p3["condition"])
    check("brief_data: open evidence gap on cited workpaper surfaced", p3["open_evidence_gaps"] == ["GAP-001"])
    md = open(mo).read()
    check("brief_data: judgement items left as TO BE DECIDED, not guessed",
          "Executive sponsor: TO BE DECIDED" in md and "Business themes (max 5): TO BE DECIDED" in md)
    check("brief_data: exit 0 on valid register", pb.returncode == 0, pb.stderr)
    bad_reg = os.path.join(tmp, "notareg.xlsx")
    from openpyxl import Workbook
    w = Workbook(); w.active.title = "Sheet1"; w.save(bad_reg)
    pn = run(bd, "--register", bad_reg)
    check("brief_data NEGATIVE: non-register workbook rejected with a clear message",
          pn.returncode != 0 and "not found" in (pn.stderr + pn.stdout), pn.stderr)

    # ---- jargon scanner
    js = load(os.path.join(BRIEF_DIR, "jargon_scan.py"), "jargon")
    hits, _ = js.scan("The review found a segregation of duties conflict in payments.")
    check("jargon: bare 'segregation of duties' flagged unexplained",
          any(h["term"] == "segregation of duties" and not h["explained"] for h in hits))
    hits, _ = js.scan("Segregation of duties means different people request, approve and pay.")
    check("jargon NEGATIVE: term followed by 'means' is treated as explained",
          hits and all(h["explained"] for h in hits))
    hits, _ = js.scan("The test of design (ToD) was completed.")
    check("jargon NEGATIVE: acronym introduced as '(ToD)' is explained",
          hits and all(h["explained"] for h in hits), hits)
    hits, _ = js.scan("We completed ToD and ToE in July.")
    check("jargon: bare acronyms ToD and ToE flagged",
          {h["term"] for h in hits if not h["explained"]} == {"ToD", "ToE"}, hits)
    _, longs = js.scan("word " * 40 + ".", max_words=35)
    check("jargon: 40-word sentence reported as long", len(longs) == 1)
    _, longs = js.scan("This sentence is short and clear.", max_words=35)
    check("jargon NEGATIVE: short sentence not reported", not longs)

    # ---- workbook formulas, if LibreOffice recalculation is available
    recalc = "/mnt/skills/public/xlsx/scripts/recalc.py"
    if os.environ.get("GIA_SKIP_RECALC"):
        recalc = "/nonexistent"      # fast mode for mutation testing: skips the slow LibreOffice checks
    if os.path.exists(recalc):
        rc = subprocess.run([sys.executable, recalc, clean, "180"], capture_output=True, text=True)
        try:
            res = json.loads(rc.stdout)
        except Exception:
            res = {}
        check("workbook: recalculates with zero formula errors", res.get("total_errors") == 0, rc.stdout[-300:])
        wv = load_workbook(clean, data_only=True)
        check("workbook: example finding evaluates as TRACEABLE", wv["Trace_Matrix"]["J2"].value == "TRACEABLE",
              wv["Trace_Matrix"]["J2"].value)
        check("workbook: example exception rate = 4/25 = 16%", abs((wv["Workpapers"]["H2"].value or 0) - 0.16) < 1e-9,
              wv["Workpapers"]["H2"].value)
    else:
        print("SKIP  workbook recalculation checks (recalc.py not found)")

    extended_checks(builder, load, tmp)

    print(f"\n{total} checks. " + ("ALL PASSED" if not failures else f"{len(failures)} FAILED: " + ", ".join(failures)))
    sys.exit(1 if failures else 0)


if __name__ == "__main__":
    main()
