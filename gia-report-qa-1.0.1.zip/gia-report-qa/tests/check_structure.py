#!/usr/bin/env python3
"""Structure and hygiene checks for the plugin. Run: python3 -I tests/check_structure.py"""
import glob
import json
import os
import re
import subprocess
import sys
import tempfile

import yaml

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
total, fails = 0, []


def check(name, cond, detail=""):
    global total
    total += 1
    print(("PASS  " if cond else "FAIL  ") + name + ("" if cond else f"  -> {str(detail)[:300]}"))
    if not cond:
        fails.append(name)


def fm(path):
    m = re.match(r"---\n(.*?)\n---\n", open(path, encoding="utf-8").read(), re.S)
    return yaml.safe_load(m.group(1)) if m else None


pj = json.load(open(os.path.join(ROOT, ".claude-plugin", "plugin.json")))
check("plugin.json has name, version 1.0.1, description, author", pj.get("name") == "gia-report-qa" and pj.get("version") == "1.0.1"
      and pj.get("description") and pj.get("author", {}).get("name") == "Sean - MKTron GIA", pj)

SKILLS = ["gia-ia-report", "gia-board-brief", "gia-disclosure-calibration", "gia-external-release",
          "gia-evidence-trace", "gia-report-qa", "gia-presentation"]
check("exactly the 7 specified skills", sorted(os.listdir(os.path.join(ROOT, "skills"))) == sorted(SKILLS))

for s in SKILLS:
    p = os.path.join(ROOT, "skills", s, "SKILL.md")
    f = fm(p)
    n = len(open(p, encoding="utf-8").read().split("\n"))
    check(f"{s}: frontmatter name matches folder, kebab, <=64", f and f.get("name") == s and re.fullmatch(r"[a-z0-9-]{1,64}", f["name"]), f)
    d = (f or {}).get("description", "")
    check(f"{s}: description <=1024 chars and has Use when / Do NOT use", 0 < len(d) <= 1024 and "Use when" in d and "Do NOT use" in d, len(d))
    check(f"{s}: SKILL.md under 500 lines ({n})", n < 500)
    # references one level deep and existing
    txt = open(p, encoding="utf-8").read()
    refs = set(re.findall(r"`((?:references|templates|scripts)/[A-Za-z0-9_.\-]+)`", txt))
    missing = [r for r in refs if not os.path.exists(os.path.join(ROOT, "skills", s, r))]
    check(f"{s}: every references/templates/scripts path named in SKILL.md exists", not missing, missing)
    for rp in glob.glob(os.path.join(ROOT, "skills", s, "references", "*.md")):
        lines = open(rp, encoding="utf-8").read().split("\n")
        if len(lines) > 100:
            check(f"{s}/{os.path.basename(rp)}: >100 lines has a Contents section", any(re.match(r"#+ Contents", l) for l in lines))
    # eval file
    ep = os.path.join(ROOT, "evals", s + ".yaml")
    e = yaml.safe_load(open(ep)) if os.path.exists(ep) else {}
    check(f"{s}: eval has >=3 should-trigger and >=3 should-NOT-trigger", len(e.get("should_trigger", [])) >= 3 and len(e.get("should_not_trigger", [])) >= 3)

agents = glob.glob(os.path.join(ROOT, "agents", "*.md"))
check("12 agent files (8 generic list + presentation subset, 4 shared names)", len(agents) == 12, len(agents))
READONLY = {"Read", "Grep", "Glob"}
for a in agents:
    f = fm(a)
    nm = os.path.basename(a)[:-3]
    tools = {t.strip() for t in str(f.get("tools", "")).split(",")}
    check(f"agent {nm}: name, model sonnet|haiku, tools present", f.get("name") == nm and f.get("model") in ("sonnet", "haiku") and tools, f)
    if nm in ("report-builder", "board-pack-coordinator"):
        check(f"agent {nm}: only the builder/coordinator may Write", "Write" in tools)
    else:
        check(f"agent {nm}: reviewer is read-only (Read, Grep, Glob only)", tools <= READONLY, tools)
    check(f"agent {nm}: one-line effort note", "Effort:" in open(a).read().split("\n")[5] or "Effort:" in open(a).read())

cmds = glob.glob(os.path.join(ROOT, "commands", "*.md"))
check("11 commands", len(cmds) == 11, len(cmds))
for c in cmds:
    f = fm(c)
    check(f"command {os.path.basename(c)}: has description", bool(f and f.get("description")))

# forbidden strings
FORBID = [r"\bFable\b", r"mktron-sentinel", r"\bCraigs?\b", r"Dave's", r"(?<![\w])/independent-qa(?![-\w])", r"\b(?:25|27|30|38) Iron Rules\b", r"\b14-item\b", r"\b13-section template exactly\b"]
bad = []
for fp in glob.glob(os.path.join(ROOT, "**", "*"), recursive=True):
    if os.path.isfile(fp) and fp.endswith((".md", ".py", ".yaml", ".json")) and "legacy-presentation" not in fp \
            and os.path.basename(fp) not in ("check_structure.py", "MIGRATION.md", "CHANGELOG.md", "RESULTS.md"):
        t = open(fp, encoding="utf-8", errors="replace").read()
        for pat in FORBID:
            if re.search(pat, t):
                bad.append((os.path.relpath(fp, ROOT), pat))
check("no stale names/counts (Fable, mktron-sentinel, Craigs, Dave's, 14-item, stale rule counts)", not bad, bad[:6])

# emoji in the reporting content that ships as Board-grade (templates/references/skills)
EM = re.compile("[\U0001F300-\U0001FAFF☀-➿✅❌]")
bad = []
for fp in glob.glob(os.path.join(ROOT, "skills", "**", "*.md"), recursive=True):
    if "legacy-13-section" in fp:
        continue
    if EM.search(open(fp, encoding="utf-8").read()):
        bad.append(os.path.relpath(fp, ROOT))
check("no emoji in skill content (outside the legacy conversion reference)", not bad, bad)

# inline statutory figures heuristic: currency/percent rates tied to statute words in SKILL.md bodies
bad = []
for s in SKILLS:
    t = open(os.path.join(ROOT, "skills", s, "SKILL.md"), encoding="utf-8").read()
    for m in re.finditer(r"(EPF|ESIC|SOCSO|PF|IMSS|ceiling|minimum wage)[^.\n]{0,60}(Rs|RM|MXN|INR)\s?[\d,]+|(Rs|RM|MXN|INR)\s?[\d,]{4,}[^.\n]{0,40}(ceiling|threshold)", t):
        bad.append((s, m.group()[:60]))
check("no inline statutory rates/ceilings in SKILL.md bodies", not bad, bad)

# word cap on rule counting: no assertion of a total iron-rule count
bad = []
for fp in glob.glob(os.path.join(ROOT, "skills", "**", "SKILL.md"), recursive=True):
    t = open(fp, encoding="utf-8").read()
    if re.search(r"\b\d+\s+(?:iron\s+)?rules\b", t, re.I):
        bad.append(os.path.relpath(fp, ROOT))
check("no total iron-rule count asserted in SKILL.md files", not bad, bad)

# docs present
for f in ("README.md", "CHANGELOG.md", "MIGRATION.md"):
    check(f"{f} exists", os.path.exists(os.path.join(ROOT, f)))
if os.path.exists(os.path.join(ROOT, "README.md")):
    check("README.md <= 60 lines", len(open(os.path.join(ROOT, "README.md")).read().split("\n")) <= 61)
check("legacy conversion reference present", os.path.exists(os.path.join(ROOT, "skills", "gia-ia-report", "references", "legacy-13-section-conversion.md")))
for t in ("flash-report", "advisory-memo", "management-letter", "annual-plan", "investigation-summary"):
    check(f"template {t}.md present", os.path.exists(os.path.join(ROOT, "skills", "gia-ia-report", "templates", t + ".md")))
it = open(os.path.join(ROOT, "skills", "gia-ia-report", "templates", "investigation-summary.md")).read()
check("investigation summary uses the fraud ladder in order", "weakness > indicator > suspicion > allegation > corroborated > substantiated" in it)
check("investigation summary states no motive", re.search(r"never stated or implied|motive", it) is not None and "Intent, motive" in it)
check("evidence-label-map present with R1-R5 and Rule 37", os.path.exists(os.path.join(ROOT, "skills", "gia-evidence-trace", "references", "evidence-label-map.md")))

print(f"\n{total - len(fails)}/{total} checks passed")
sys.exit(1 if fails else 0)
