#!/usr/bin/env python3
"""Offline eval runner. Run: python3 -I tests/run_evals.py

What this does (and does not do):
 1. Parses every evals/<skill>.yaml and checks >=3 should-trigger and >=3 should-NOT-trigger prompts.
 2. Lexical routing smoke test: scores each prompt against each skill description + name words and
    predicts the best-matching skill. This is a crude word-overlap heuristic, NOT the model's routing.
    It is a trigger-overlap scan: a miss shows where two descriptions share the same trigger words.
 3. Parses the retained legacy presentation eval cases and runs the deterministic part
    (validate_deck.py on synthetic decks derived from the numerical-error and traceability cases).
Live trigger evaluation and judge-graded cases need Claude Code / a model and are NOT run here.
"""
import glob
import math
import os
import re
import subprocess
import sys
import tempfile
from collections import Counter

import yaml

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
total, fails = 0, []


def check(name, cond, detail=""):
    global total
    total += 1
    print(("PASS  " if cond else "FAIL  ") + name + ("" if cond else f"  -> {str(detail)[:300]}"))
    if not cond:
        fails.append(name)


STOP = set("the a an and or of to for in on with this that is are be it as by from at your my our we i me do does can how what when which not no use".split())


def toks(s):
    return [w for w in re.findall(r"[a-z][a-z0-9]+", s.lower()) if w not in STOP and len(w) > 2]


skills, docs = {}, {}
for d in sorted(glob.glob(os.path.join(ROOT, "skills", "*"))):
    n = os.path.basename(d)
    t = open(os.path.join(d, "SKILL.md"), encoding="utf-8").read()
    m = re.search(r'^description:\s*"(.*)"\s*$', t, re.M)
    desc = m.group(1)
    # positive part only: drop the Do NOT use sentence so negatives do not attract
    pos = desc.split("Do NOT use")[0]
    docs[n] = Counter(toks(pos + " " + n.replace("-", " ")))
df = Counter()
for c in docs.values():
    df.update(set(c))
N = len(docs)


def score(prompt, skill):
    q = Counter(toks(prompt))
    s = 0.0
    for w, qc in q.items():
        if w in docs[skill]:
            s += (1 + math.log(docs[skill][w])) * math.log((N + 1) / (df[w] + 0.5))
    return s


def route(prompt):
    sc = {k: score(prompt, k) for k in docs}
    best = max(sc, key=sc.get)
    return best, sc[best]


hit = miss_in = 0
neg_ok = neg_total = 0
misses = []
for ep in sorted(glob.glob(os.path.join(ROOT, "evals", "*.yaml"))):
    e = yaml.safe_load(open(ep))
    name = os.path.basename(ep)[:-5]
    check(f"{name}: >=3 should-trigger and >=3 should-NOT-trigger", len(e["should_trigger"]) >= 3 and len(e["should_not_trigger"]) >= 3)
    for p in e["should_trigger"]:
        b, _ = route(p["prompt"])
        if b == name:
            hit += 1
        else:
            misses.append(("TRIGGER", name, b, p["prompt"][:70]))
    for p in e["should_not_trigger"]:
        tgt = p["route_to"].replace("gia-report-qa:", "")
        if tgt in docs:
            neg_total += 1
            b, _ = route(p["prompt"])
            if b == tgt:
                neg_ok += 1
            else:
                misses.append(("ROUTE", name, f"{b} (expected {tgt})", p["prompt"][:70]))
n_trig = sum(len(yaml.safe_load(open(f))["should_trigger"]) for f in glob.glob(os.path.join(ROOT, "evals", "*.yaml")))
print(f"\nLexical routing smoke: should-trigger {hit}/{n_trig} routed to the intended skill; in-plugin redirect cases {neg_ok}/{neg_total}")
for m in misses:
    print("  miss", m)
check("lexical routing: at least 75% of should-trigger prompts land on the intended skill (heuristic)", hit / n_trig >= 0.75, f"{hit}/{n_trig}")
check("lexical routing: at least 60% of in-plugin redirect prompts land on the named skill (heuristic)", neg_ok / max(neg_total, 1) >= 0.60, f"{neg_ok}/{neg_total}")

# legacy presentation evals: structure
leg = glob.glob(os.path.join(ROOT, "evals", "legacy-presentation", "*.yaml"))
bad = []
for f in leg:
    try:
        d = yaml.safe_load(open(f))
        assert isinstance(d, dict) and len(d) >= 2
    except Exception as ex:
        bad.append((os.path.basename(f), str(ex)[:60]))
check(f"{len(leg)} retained legacy presentation eval files parse (judge-graded; need a live model to grade)", not bad and len(leg) == 10, bad or len(leg))

# deterministic: validate_deck on synthetic decks
VD = os.path.join(ROOT, "skills", "gia-presentation", "scripts", "validate_deck.py")
tmp = tempfile.mkdtemp()


def deck(slides):
    p = os.path.join(tmp, "d%d.yaml" % len(os.listdir(tmp)))
    yaml.safe_dump({"deck": {"title": "t"}, "slides": slides}, open(p, "w"))
    return p


def vd(p):
    r = subprocess.run([sys.executable, "-I", VD, p], capture_output=True, text=True)
    return r.returncode, r.stdout


rc, out = vd(deck([{"id": "S1", "title": "Net cash outflow is RM0.8m", "message": "Cash paid exceeded cash received by RM0.8m", "evidence_ids": ["EV-001"], "decision_action": "Note"}]))
check("validate_deck: numerical slide WITH evidence ID passes", rc == 0 and "PASS" in out, out)
rc, out = vd(deck([{"id": "S1", "title": "Net cash outflow is RM0.8m", "message": "Cash paid exceeded cash received", "evidence_ids": []}]))
check("validate_deck (numerical-error case): figure without evidence ID is a HARD FAIL", rc == 1 and "HARD FAIL" in out, out)
rc, out = vd(deck([{"id": "S1", "title": "A", "message": "m"}, {"id": "S1", "title": "B", "message": "m"}]))
check("validate_deck: duplicate slide IDs rejected", rc == 1 and "duplicate" in out, out)
rc, out = vd(deck([{"id": "S1", "title": "", "message": ""}]))
check("validate_deck: missing title and message rejected", rc == 1, out)
rc, out = vd(deck([{"id": "S1", "title": "A", "message": "m", "supporting_points": list("abcdefg"), "decision_action": "x"}]))
check("validate_deck: >6 supporting points raises a density warning", rc == 0 and "density" in out, out)

# arithmetic of the numerical-error eval case
check("numerical-error eval: 4.2 received - 5.0 paid = -0.8 (draft RM0.6m is wrong)", abs((4.2 - 5.0) + 0.8) < 1e-9 and abs(abs(4.2 - 5.0) - 0.6) > 1e-9)

print(f"\n{total - len(fails)}/{total} checks passed (live trigger evaluation not run)")
sys.exit(1 if fails else 0)
