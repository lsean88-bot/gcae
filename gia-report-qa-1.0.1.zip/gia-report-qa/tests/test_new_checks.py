#!/usr/bin/env python3
"""Positive and negative tests for the two new checks. Run: python3 -I tests/test_new_checks.py"""
import os
import subprocess
import sys
import tempfile

import docx
import openpyxl

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IAR = os.path.join(ROOT, "skills", "gia-ia-report", "scripts", "consolidated_iar_check.py")
LINT = os.path.join(ROOT, "skills", "gia-report-qa", "scripts", "profile_b_lint.py")
total, fails = 0, []


def check(name, cond, detail=""):
    global total
    total += 1
    print(("PASS  " if cond else "FAIL  ") + name + ("" if cond else f"  -> {detail}"))
    if not cond:
        fails.append(name)


def run(*args):
    r = subprocess.run([sys.executable, "-I", *args], capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr


tmp = tempfile.mkdtemp()


def mk_docx(name, paras):
    d = docx.Document()
    for p in paras:
        d.add_paragraph(p)
    p = os.path.join(tmp, name)
    d.save(p)
    return p


def mk_html(name, body, extra=""):
    p = os.path.join(tmp, name)
    open(p, "w").write(f"<html><head><style>.a{{padding:4px}}</style></head><body>{body}{extra}</body></html>")
    return p


def mk_xlsx(name, ids, extra=()):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Findings"
    ws.append(["ID", "Title"])
    for i in ids:
        ws.append([i, "Title of " + i])
    for e in extra:
        ws.append(["", e])
    p = os.path.join(tmp, name)
    wb.save(p)
    return p


def w(name, text):
    p = os.path.join(tmp, name)
    open(p, "w").write(text)
    return p


# ---------------- consolidated_iar_check
body = "Executive summary. 3 findings. F-01 Fire NOC expired by 637 days. F-02 Gross pay Rs 7,480,000. F-03 Stock difference 12,500."
d = mk_docx("a.docx", [body])
h = mk_html("a.html", "<p>" + body + "</p>")
x = mk_xlsx("a.xlsx", ["F-01", "F-02", "F-03"])
src = w("src.txt", "Fire NOC 637 days. gross pay 7480000. difference 12500")
figs = w("figs.csv", f"figure,source\n637,{src}\n\"7,480,000\",{src}\n12500,{src}\n")
dele = w("del.txt", "# deleted\nCanteen licence lapse\nF-09\n")

rc, out = run(IAR, "--docx", d, "--html", h, "--xlsx", x, "--deleted", dele, "--figures", figs, "--min-figures", "3")
check("IAR clean set exits 0", rc == 0, out)

d2 = mk_docx("b.docx", [body + " Canteen licence lapse noted."])
rc, out = run(IAR, "--docx", d2, "--html", h, "--deleted", dele)
check("D01 POSITIVE: deleted title in DOCX flagged", rc == 1 and "D01" in out and "docx" in out, out)

h2 = mk_html("b.html", "<p>" + body + "</p>", "<p>See F-09 for background.</p>")
rc, out = run(IAR, "--html", h2, "--deleted", dele)
check("D01 POSITIVE: deleted finding ID in HTML flagged", rc == 1 and "F-09" in out, out)

h3 = mk_html("c.html", "<p>" + body + "</p>", "<p>padding quantified</p><img src='data:font/woff;base64,QUFGLTA5QUFBQQ=='>")
dele2 = w("del2.txt", "uan\nF-09\n")
rc, out = run(IAR, "--html", h3, "--deleted", dele2)
check("D01 NEGATIVE: 'uan' inside 'quantified' and base64/CSS do not trigger", rc == 0, out)

x2 = mk_xlsx("b.xlsx", ["F-01", "F-02"])
rc, out = run(IAR, "--docx", d, "--html", h, "--xlsx", x2)
check("C01 POSITIVE: workbook missing F-03 flagged as count mismatch", rc == 1 and "C01" in out and "F-03" in out, out)
rc, out = run(IAR, "--docx", d, "--html", h, "--xlsx", x)
check("C01 NEGATIVE: identical ID sets pass", rc == 0 and "ERROR" not in out, out)

figs_bad = w("figs_bad.csv", f"figure,source\n999,{src}\n")
rc, out = run(IAR, "--docx", d, "--figures", figs_bad, "--min-figures", "1")
check("F01 POSITIVE: figure absent from report and source flagged", rc == 1 and out.count("F01") >= 2, out)
figs_src = w("figs_src.csv", f"figure,source\n637,{w('s2.txt', 'nothing here')}\n")
rc, out = run(IAR, "--docx", d, "--figures", figs_src, "--min-figures", "1")
check("F01 POSITIVE: figure in report but not in source flagged", rc == 1 and "not found in source" in out, out)
rc, out = run(IAR, "--docx", d, "--figures", figs, "--min-figures", "30")
check("F01: fewer than 30 figures traced is a WARN, not a pass-through", "only 3 figures" in out and rc == 0, out)
rc, out = run(IAR)
check("IAR no input exits 2 (cannot run is never a pass)", rc == 2, out)
rc, out = run(IAR, "--docx", os.path.join(tmp, "missing.docx"))
check("IAR unreadable file exits 2", rc == 2, out)

# ---------------- profile_b_lint
clean = "The review covered three plants. Fire NOC renewal is 637 days past its end date. Owner: Plant Head. Management response: Pending."
cf = w("clean.md", clean)
rc, out = run(LINT, cf)
check("LINT NEGATIVE: clean Board text exits 0", rc == 0 and "CLEAN" in out, out)
for label, text, code in [
    ("emoji", "Rating: \U0001F534 High", "E01"),
    ("status symbol", "Control operating ✅", "E01"),
    ("self-commentary", "This audit found the figure and independently confirmed it a third time.", "S01"),
    ("process narration", "435 documents read and the totals were re-performed.", "S01"),
    ("sheet/row ref", "See sheet Findings, rows 14-22 for the schedule.", "R01"),
    ("cell ref", "The total is in cell D45.", "R01"),
    ("declaration", "I have not changed approved audit facts.", "N01"),
]:
    rc, out = run(LINT, w("t.md", text))
    check(f"LINT POSITIVE: {label} flagged ({code})", rc == 1 and code in out, out)
rc, out = run(LINT, "--profile", "A", w("a.md", "How to check: see sheet Findings, rows 14-22."))
check("LINT profile A: row reference is WARN only", rc == 0 and "WARN" in out, out)
rc, out = run(LINT, w("o.md", "Weighted score in rows of 5 tables; 3 findings on pay and 4 on stock."))
check("LINT NEGATIVE: ordinary use of 'rows'/'tables' without a number reference is not flagged", rc == 0, out)
hh = mk_html("lint.html", "<p>Clean paragraph.</p>", "<img src='data:font/woff;base64,QUFGLTA5QUFBQQ=='>")
rc, out = run(LINT, hh)
check("LINT NEGATIVE: base64/CSS in HTML ignored", rc == 0, out)
dx = mk_docx("lint.docx", ["Findings are shown by theme.", "Status ⚠ attention"])
rc, out = run(LINT, dx)
check("LINT POSITIVE: emoji inside DOCX flagged", rc == 1 and "E01" in out, out)
xl = mk_xlsx("lint.xlsx", ["F-01"], extra=["Re-performed by auditor, see tab Findings"])
rc, out = run(LINT, xl)
check("LINT POSITIVE: self-commentary inside XLSX cell flagged", rc == 1 and "S01" in out, out)
rc, out = run(LINT, os.path.join(tmp, "nope.docx"))
check("LINT unreadable file exits 2", rc == 2, out)
rc, out = run(LINT, w("al.md", "Re-performed copy, quoted from source."), "--allow", "quoted from source")
check("LINT --allow skips documented false positives", rc == 0, out)

# ---------------- tieout_check, qa_scan smoke, run_critique smoke
TIE = os.path.join(ROOT, "skills", "gia-disclosure-calibration", "scripts", "tieout_check.py")
QS = os.path.join(ROOT, "skills", "gia-report-qa", "scripts", "qa_scan.py")
RC = os.path.join(ROOT, "skills", "gia-report-qa", "scripts", "run_critique.py")
rows14 = "item,value,in_body\n" + "\n".join(f"INV{i},100.00,yes" for i in range(14))
rc, out = run(TIE, w("t14.csv", rows14), "--population", "14", "--total", "1400")
check("TIEOUT: 14 items all in body, total ties -> pass", rc == 0 and "PASS" in out, out)
rc, out = run(TIE, w("t14b.csv", rows14), "--population", "14", "--total", "1500")
check("TIEOUT POSITIVE: total mismatch flagged", rc == 1 and "T02" in out, out)
rows14p = rows14.replace("INV13,100.00,yes", "INV13,100.00,no")
rc, out = run(TIE, w("t14c.csv", rows14p), "--population", "14", "--total", "1400")
check("TIEOUT POSITIVE: N<=15 with an item missing from the body flagged", rc == 1 and "T03" in out, out)
rows20 = "item,value,in_body\n" + "\n".join(f"INV{i},10.00,{'yes' if i < 3 else 'no'}" for i in range(20))
rc, out = run(TIE, w("t20.csv", rows20), "--population", "20", "--total", "200")
check("TIEOUT POSITIVE: N>15 with a partial list in the body flagged", rc == 1 and "partial list" in out, out)
rows20n = rows20.replace(",yes", ",no")
rc, out = run(TIE, w("t20n.csv", rows20n), "--population", "20", "--total", "200")
check("TIEOUT NEGATIVE: N>15 with schedule only passes", rc == 0, out)
rc, out = run(TIE, w("tdup.csv", "item,value,in_body\nA,1,yes\nA,1,yes\n"), "--population", "2", "--total", "2")
check("TIEOUT POSITIVE: duplicate items flagged", rc == 1 and "T04" in out, out)
rc, out = run(TIE, w("tbad.csv", "x,y\n1,2\n"), "--population", "1", "--total", "1")
check("TIEOUT: malformed CSV exits 2", rc == 2, out)

rc, out = run(QS, w("draft.md", "The plant has no fire licence. All payments were unauthorised across the company."), "--audience", "director")
check("QA_SCAN smoke: flags absence-as-proof / overreach wording", rc in (0, 1) and ("ABSENCE" in out or "OVERREACH" in out or "UNREF" in out), out[:300])

skd = os.path.join(tmp, "sk")
os.makedirs(skd)
open(os.path.join(skd, "SKILL.md"), "w").write('---\nname: demo-skill\ndescription: "Does x. Use when y. Do NOT use for z."\n---\nbody\n')
rc, out = run(RC, "--skill", skd, "--out", os.path.join(tmp, "crit.md"))
check("RUN_CRITIQUE: runs and writes skeleton with local structural fallback", rc == 0 and os.path.exists(os.path.join(tmp, "crit.md")) and "FILL IN" in open(os.path.join(tmp, "crit.md")).read(), out)
open(os.path.join(skd, "SKILL.md"), "w").write("no frontmatter here\n")
rc, out = run(RC, "--skill", skd, "--out", os.path.join(tmp, "crit2.md"))
check("RUN_CRITIQUE POSITIVE: missing frontmatter reported as structural FAIL", "FAIL" in out or "no YAML frontmatter" in open(os.path.join(tmp, "crit2.md")).read(), out)

print(f"\n{total - len(fails)}/{total} checks passed")
sys.exit(1 if fails else 0)
