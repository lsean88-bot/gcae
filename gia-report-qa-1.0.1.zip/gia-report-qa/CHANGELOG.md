# Changelog

## 1.0.1 (30-Oct-2026), QA defect fixes (D5, D7, D9 to D15)

- Cross-references: every `gia-*:<name>` now resolves to a built skill, agent or command (short blueprint names replaced with built names).
- Descriptions of all skills and agents are 400 characters or fewer, trigger words first, with the Do NOT use clause kept (one redirect where space was short); all quoted so frontmatter parses as YAML.
- Script paths in skills, commands and agents use `${CLAUDE_PLUGIN_ROOT}/skills/<skill>/scripts/...`.
- Dangling in-skill links fixed or removed; empty directories and caches deleted.
- `run_critique.py` finds the gia-core preflight under a `<plugin>/<version>/` cache layout (GIA_PREFLIGHT_SCRIPT, CLAUDE_PLUGIN_ROOT and version globs), no longer passes an unsupported flag, and prints a warning when it falls back to the weaker local check.
- Added `skills/gia-report-qa/references/assurance-chain.md` (stages S0 to S7, intake questions, chain rules) from the port check.
- Banned source-plugin string removed; legacy header renamed to Conversion rules RC-01 to RC-12; eval route_to values fixed.
- Always-loaded name plus description tokens (chars/4): skills 680, agents 697, commands 309, total 1686.

## 1.0.0 (29-Oct-2026)
Initial consolidation release (suite S5).

Added
- 7 skills, 12 agents (all pinned sonnet or haiku; reviewers read-only), 11 commands.
- `consolidated_iar_check.py` (deleted-finding grep, finding-count identity across DOCX/HTML/XLSX, figure trace).
- `profile_b_lint.py` (emoji, self-commentary, sheet/row references, in-file declarations).
- `tieout_check.py` (named + remainder = total; no partial list).
- Templates: flash report, advisory memo, management letter, annual plan paper, investigation summary (fraud ladder, no motive), standard IA report.
- `evidence-label-map.md` (R1-R5 and Rule 37 classes; older schemes mapped), `quality-gate-checks.md` (12 items mapped to checks).

Changed
- Canonical report is the standard concise IA report plus Excel working paper (Profiles A and B). The 13-section conversion is a legacy reference with a contents list, and its embedded change log and stale rule counts removed.
- Default tone is evidence-calibrated and balanced; emoji and alert boxes removed from Board-grade content.
- Declarations (no-drift, verification) move from the deliverable to the QA log or chat reply.
- Presentation skill split from 907 lines to a 60-line SKILL.md plus 11 references; duplicated section numbers removed; 29 specialists folded into 8 agents; runtime, UAT and continuation-guard meta layers not ported.
- Real-case data removed from method content (invoice example replaced by a synthetic one); statutory rates and dates removed (dated registers in the entity packs).
- `qa_gate.py` jargon-scan path and `run_critique.py` preflight search updated for this plugin; local structural fallback added to `run_critique.py`.

Removed
- References to missing files and uninstalled skills; stale agent and person names.
