---
name: gia-presentation
description: "Creates, reviews and quality-assures executive decks for the Chairman, Board, AC and EXCO, with a comprehension release gate and a four-outcome Judge. Use when evidence must become a decision deck, a deck needs review or revision, or Board Q&A needs preparing. Do NOT use for written briefs (use gia-report-qa:gia-board-brief) or the IA report (use gia-report-qa:gia-ia-report)."
argument-hint: "[audience] [topic] [period] [objective]"
---

# GIA Presentation

Highest communication requirement: **universal comprehension**. A non-technical business reader understands the message without specialist knowledge; a Chairman or Board member sees at once what matters, why, what is changing, what decision or oversight is required, and what evidence supports it. Evidence rules are those of `gia-core:iron-rules` (R1-R5; Rule 37 classes); disclosure depth follows `gia-report-qa:gia-disclosure-calibration`. Deck text is Profile B in tone: balanced, evidence-calibrated, no emoji decoration.

## Workflow

1. **Intake**: audience, decision question, period, objective, deadline, source of truth, confidentiality. Ask only what the project folder does not answer (`references/evidence-controls-and-stages.md`).
2. **Evidence**: build the evidence register (`templates/evidence-register.yaml`), validate each claim, record evidence state. Material numbers need evidence IDs.
3. **Plan**: `agents/presentation-planner.md` defines the decision question, important vs priority, value vs risk, executive vs appendix content, and the slide spine.
4. **Draft** from `templates/deck-spec.yaml`; one message per slide; message titles (the title states the conclusion, not the topic); see `references/narrative-and-slide-design.md`.
5. **Validate structure**: `python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-presentation/scripts/validate_deck.py deck-spec.yaml` (duplicate IDs, missing title or message, numbers without evidence IDs, density).
6. **Build**: `python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-presentation/scripts/build_pptx.py` / `render_pptx.py` (or the `pptx` skill); inspect rendered slides.
7. **Independent review** in parallel, read-only: `accuracy-advisor`, `audience-comprehension`, `objectivity-advisor`, plus the specialists the routing table triggers.
8. **Judge** (`agents/presentation-judge.md`): PASS / PASS WITH MINOR CHANGES / REQUIRES REWORK / HARD FAIL. Critical defects are never averaged away.
9. **Final comprehension test** and the final release test (`references/judge-and-scoring.md`), then human release decision. A deck is not represented as approved or sent.

## Universal Comprehension gate (every important slide)

1 one thing to understand; 2 a non-technical manager follows it unaided; 3 a Chairman sees why it matters in seconds; 4 business consequence explicit; 5 acronyms explained at first use; 6 technical terms translated; 7 chart self-explanatory; 8 period explicit; 9 units and currency explicit; 10 title states the conclusion; 11 no unnecessary information; 12 cannot easily be misunderstood; 13 evidence status clear; 14 requested decision or action explicit. A material slide fails if 2, 3, 4, 10 or 13 is no. Detail: `references/comprehension-and-language.md`.

## Non-negotiable evidence controls

No unsupported material number; no invented fact or source; allegation, assertion and inference never shown as confirmed finding; fraud wording at ladder level only, never motive (`gia-fraud:gia-fraud-investigation`); evidence state stated for any disputed material claim; contradictions between executive and appendix content resolved before release; statutory rates and dates only from the dated register, tagged [UNVERIFIED] if not verified. Full list: `references/evidence-controls-and-stages.md`.

## Routing: lean agent set (29 specialists folded into 8)

| Agent (`agents/`) | Absorbs | Trigger |
|---|---|---|
| `presentation-planner` | strategic planner, delegator | Always first |
| `accuracy-advisor` | data-evidence, financial-quantitative | Always |
| `audience-comprehension` | clarity, kiss, narrative, humanised tone | Always |
| `objectivity-advisor` | investigation, causal-root-cause | Always; mandatory for investigation or disputed findings |
| `executive-decision` | board-relevance, risk-value, stakeholder-governance, challenge-readiness, uncertainty-scenario | Decision, approval or option decks; Board, EXCO, high-stakes decks |
| `visual-design` | format, data-viz-integrity, accessibility, delivery-facilitation | Production decks; material charts; live delivery |
| `semantic-reconciliation` | narrative-pacing, logic | Decks over about eight slides, or with appendices |
| `presentation-judge` | judge | Always last |

Compliance and operations-process specialist roles belong to `gia-audit`. The same accuracy and objectivity advisors serve written reports (`gia-report-qa:gia-report-qa`).

## Commands

`/presentation` (full workflow), `/presentation-review` (defect register, no silent rewriting), `/presentation-qa` (validate, specialists, Judge). Create, revise and challenge are modes of `/presentation` (`references/modes.md`).

## Reference map

| File | Read when |
|---|---|
| `references/comprehension-and-language.md` | Comprehension levels, plain-language rules, Chairman reading model |
| `references/evidence-controls-and-stages.md` | Evidence controls, staged protocol |
| `references/team-tone-and-counsel.md` | Planner duties, specialist team, tone layer, independent counsel |
| `references/judge-and-scoring.md` | Judge outcomes, 16-dimension scoring, release tests |
| `references/narrative-and-slide-design.md` | Priority vs importance, slide architecture, visuals, accessibility |
| `references/audit-reporting-and-production.md` | Audit and investigation decks, deep dives, deliverables |
| `references/decision-deck-extensions.md` | Decision architecture, Q&A readiness, uncertainty, chart integrity, delivery, confidentiality |
| `references/capability-depth.md` | Complex decks: claim ledger, causal discipline, depth gate |
| `references/modes.md` | Command modes (create, revise, challenge) |
| `references/humanised-presentation-standard.md`, `references/comprehension-standard.md`, `references/scoring-rubric.md` | Standards behind the gates |
| `templates/` | deck-spec, evidence-register, decision-register |
