#!/usr/bin/env python3
import shutil, subprocess, sys
from pathlib import Path

def main(pptx, outdir):
    soffice = shutil.which("libreoffice") or shutil.which("soffice")
    if not soffice:
        print("LibreOffice/soffice not found; rendering unavailable in this environment.")
        return 2
    out = Path(outdir)
    out.mkdir(parents=True, exist_ok=True)
    subprocess.run([soffice, "--headless", "--convert-to", "pdf", "--outdir", str(out), str(pptx)], check=True)
    print("Rendered PDF:", out / (Path(pptx).stem + ".pdf"))
    return 0

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: render_pptx.py input.pptx output_directory")
        raise SystemExit(2)
    raise SystemExit(main(sys.argv[1], sys.argv[2]))
