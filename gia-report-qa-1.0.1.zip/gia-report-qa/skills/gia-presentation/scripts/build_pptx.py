#!/usr/bin/env python3
import sys, yaml
from pathlib import Path
from pptx import Presentation
from pptx.util import Inches, Pt

def main(spec_path, out_path):
    spec = yaml.safe_load(Path(spec_path).read_text(encoding="utf-8"))
    prs = Presentation()
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)
    blank = prs.slide_layouts[6]
    for s in spec.get("slides", []):
        slide = prs.slides.add_slide(blank)
        title = slide.shapes.add_textbox(Inches(.6), Inches(.35), Inches(12.1), Inches(.7))
        tf = title.text_frame
        tf.text = s.get("title","")
        tf.paragraphs[0].font.size = Pt(24)
        msg = slide.shapes.add_textbox(Inches(.7), Inches(1.25), Inches(11.8), Inches(1.0))
        mtf = msg.text_frame
        mtf.text = s.get("message","")
        mtf.paragraphs[0].font.size = Pt(20)
        body = slide.shapes.add_textbox(Inches(.8), Inches(2.45), Inches(11.7), Inches(3.8))
        btf = body.text_frame
        points = s.get("supporting_points", [])
        btf.text = "\n".join("• " + str(x) for x in points[:6])
        for p in btf.paragraphs:
            p.font.size = Pt(16)
        footer = slide.shapes.add_textbox(Inches(.7), Inches(6.9), Inches(11.8), Inches(.3))
        footer.text_frame.text = " | ".join(s.get("evidence_ids", []))
        footer.text_frame.paragraphs[0].font.size = Pt(9)
    prs.save(out_path)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: build_pptx.py deck-spec.yaml output.pptx")
        raise SystemExit(2)
    main(sys.argv[1], sys.argv[2])
