#!/usr/bin/env python3
import sys, yaml, re
from pathlib import Path

def main(path, strict=False):
    spec = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    errors, warnings = [], []
    seen = set()
    for i, s in enumerate(spec.get("slides", []), 1):
        sid = s.get("id", f"S{i}")
        if sid in seen: errors.append(f"{sid}: duplicate slide id")
        seen.add(sid)
        if not s.get("title"): errors.append(f"{sid}: missing title")
        if not s.get("message"): errors.append(f"{sid}: missing primary message")
        if len(s.get("supporting_points", [])) > 6:
            warnings.append(f"{sid}: more than 6 supporting points; review density")
        # Numerical claims in material slides require evidence IDs.
        combined = " ".join([str(s.get("title","")), str(s.get("message",""))] + [str(x) for x in s.get("supporting_points",[])])
        has_number = bool(re.search(r'(?i)(RM|USD|EUR|INR|MXN|\$|€|£)\s*[0-9]|\b[0-9]+(?:\.[0-9]+)?\s*(?:%|million|m|bn|billion)\b', combined))
        if has_number and not s.get("evidence_ids"):
            errors.append(f"{sid}: numerical/material claim has no evidence IDs")
        if i <= 5 and not s.get("decision_action"):
            warnings.append(f"{sid}: no explicit decision/action; check whether appropriate")
    print("ERRORS:")
    for e in errors: print(" -", e)
    print("WARNINGS:")
    for w in warnings: print(" -", w)
    print(f"RESULT: {'HARD FAIL' if errors else 'REVIEW WARNINGS' if warnings else 'PASS'}")
    return 1 if errors else 0

if __name__ == "__main__":
    args=sys.argv[1:]
    strict='--strict' in args
    args=[a for a in args if a!='--strict']
    if len(args)!=1:
        print("Usage: validate_deck.py [--strict] deck-spec.yaml")
        raise SystemExit(2)
    raise SystemExit(main(args[0], strict))
