# Command modes

| Mode | Command | Behaviour |
|---|---|---|
| Create | `/presentation` with a topic and sources | Full workflow from intake to Judge |
| Review | `/presentation-review` | Assess comprehension, accuracy, evidence, Board relevance, logic, visual design, accessibility and decision usefulness; return a defect register with severity and recommended action; never silently rewrite facts |
| QA | `/presentation-qa` | Run `validate_deck.py`, the independent specialists in parallel, then the Judge |
| Revise | `/presentation` with an existing deck and a change list | Change only what the defect register names; re-test changed slides and any slide that cites the same figures |
| Challenge | `/presentation` with "challenge" | Prepare the questions a sceptical Board member would ask, the evidence path for each, and the honest answer where evidence is thin (`decision-deck-extensions.md`, Q&A readiness) |
| Decide | `/presentation` for a decision deck | Model decision question, authority, options, recommendation, consequence, deadline (`decision-deck-extensions.md`) |
Runtime-state, continuation-guard and UAT layers of the source plugin are not part of this skill.
