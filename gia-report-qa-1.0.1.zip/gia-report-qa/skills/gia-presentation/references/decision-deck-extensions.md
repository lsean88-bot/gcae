# Pacing, reconciliation, decision architecture, Q&A readiness, uncertainty, data-viz integrity, delivery, context, confidentiality

## Contents
- Narrative pacing and attention
- Semantic cross-slide reconciliation
- Executive Decision Architecture — Mandatory for decision decks
- Challenge and Q&A Readiness
- Uncertainty, Scenarios and Sensitivity
- Data Visualisation Integrity
- Accessibility and Inclusive Design
- Delivery and Meeting Facilitation
- External Context and Benchmark Discipline
- Confidentiality, Classification and Information Hygiene
- Specialist routing: controlled expansion (superseded by SKILL.md routing table)

## Narrative pacing and attention

The Narrative Pacing Specialist reviews the whole deck, not just individual slides. It must identify repetition, excessive density, weak transitions, poor sequencing and attention fatigue. It may recommend merge, reorder, compression or appendix movement, but cannot change evidence, severity or conclusions.

## Semantic cross-slide reconciliation

The Semantic Reconciliation Specialist is the deck-level source-of-truth check. It compares metrics, definitions, periods, entities, evidence states, risk ratings, conclusions and actions across all slides and appendix material. Conflicts must be surfaced, not silently resolved.

A deck fails reconciliation when a material number, definition, period, evidence status, severity or conclusion materially conflicts across slides without an explicit explanation.

## Executive Decision Architecture — Mandatory for decision decks

If the presentation asks for approval, direction, escalation or a material management decision, explicitly model:
- decision question;
- decision authority;
- options;
- trade-offs;
- recommendation;
- consequences of delay/no action;
- required decision date;
- dependencies and conditions;
- owner after decision.

Do not manufacture choices merely to make a decision slide look complete.

## Challenge and Q&A Readiness

Before release, predict the questions a skeptical Chairman, Board member, EXCO member, CFO, operations leader or auditor is likely to ask.

Every material conclusion should have an answer path to:
- evidence;
- calculation;
- period/population;
- management explanation;
- uncertainty;
- business impact;
- action/owner.

If the answer is unknown, say so and identify the evidence required. Never fabricate an answer.

## Uncertainty, Scenarios and Sensitivity

For forecasts, estimates, valuations, financial impacts or material inferred consequences, distinguish:
- observed fact;
- assumption;
- estimate;
- forecast;
- scenario;
- sensitivity;
- uncertainty range.

Where decision-relevant, show base/upside/downside or equivalent scenarios. Do not create false precision.

Every material derived number must expose its calculation basis or link to the evidence register.

## Data Visualisation Integrity

Treat visualisation as an analytical control, not decoration.

Every material chart must be traceable to its underlying data and must pass:
- correct aggregation;
- correct denominator;
- correct period;
- correct units;
- correct baseline/axis;
- appropriate chart type;
- truthful visual emphasis;
- explicit treatment of missing data;
- text explanation of the key conclusion.

A visually attractive but materially misleading chart is a HARD FAIL.

## Accessibility and Inclusive Design

The deck must remain understandable across:
- mixed technical ability;
- projection/display environments;
- printed/PDF copies;
- colour-vision limitations;
- visual impairments where practical;
- readers who skim or use assistive technology.

Require meaningful slide titles, logical reading order, adequate contrast, non-colour-only meaning, readable text, simple tables and meaningful alternative descriptions for material visuals where supported.

## Delivery and Meeting Facilitation

A presentation is not complete merely because the slides are correct.

For substantive decks, assess:
- opening and closing;
- speaking time;
- slide pacing;
- transitions;
- discussion points;
- likely interruptions;
- speaker notes;
- questions requiring evidence;
- decision points;
- what can be skipped safely.

The live presentation must not depend on hidden information that is absent from the slide/evidence layer.

## External Context and Benchmark Discipline

External benchmarks, regulations, market data or peer comparisons may be used only when relevant and current.

For each external claim record:
- source;
- publication/update date;
- scope/geography;
- definition;
- comparability limitations.

Never compare unlike populations, periods, accounting definitions or business models merely because the numbers look comparable.

## Confidentiality, Classification and Information Hygiene

Before release, classify the deck's information sensitivity.

Check for:
- personal data;
- confidential commercial information;
- privileged/legal material;
- investigation-sensitive information;
- customer/supplier information;
- credentials or security-sensitive information;
- unnecessary names or identifiers.

Use minimum necessary disclosure. Redact or aggregate where appropriate. Do not place sensitive evidence into speaker notes merely to hide it from the visible slide.

## Specialist routing (lean set)

The 29 original specialists are folded into eight agents; see the routing table in `SKILL.md`. Uncertainty and scenario analysis, external research discipline and confidentiality remain core controls, not separate agents.

