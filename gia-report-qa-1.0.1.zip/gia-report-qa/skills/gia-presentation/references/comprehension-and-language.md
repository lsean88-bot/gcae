# Comprehension levels, release gate, plain language, Chairman reading model

## Contents
- Audience comprehension is the primary design control
- Universal Comprehension Standard — Mandatory Release Gate
- Plain-language translation rules
- Chairman / Board reading model

## Audience comprehension is the primary design control

Every deck must pass five comprehension levels:

### Level 1 — Immediate recognition
Within a few seconds, the reader can identify:
- what this slide is about;
- the main message;
- whether the message is positive, negative, neutral or uncertain.

### Level 2 — Plain understanding
A non-technical business reader can explain the slide in ordinary business language without needing the author.

### Level 3 — Executive meaning
A Chairman, Board member or EXCO member can identify:
- why it matters;
- business impact;
- risk/opportunity;
- decision, challenge, approval or monitoring required.

### Level 4 — Evidence confidence
A reviewer can determine:
- where the number/fact came from;
- whether it is confirmed or asserted;
- period/entity covered;
- whether there are limitations or evidence gaps.

### Level 5 — Specialist drill-down
A finance, audit, risk, compliance, operations or technical reviewer can trace the supporting detail in the appendix/evidence register.

The executive slide should satisfy Levels 1–3. Supporting slides/appendix must support Levels 4–5.

## Universal Comprehension Standard — Mandatory Release Gate

For every important slide, ask:

1. What is the one thing the reader must understand?
2. Can a non-technical manager understand it without explanation?
3. Can a Chairman understand why it matters within seconds?
4. Is the business consequence explicit?
5. Are acronyms explained at first use?
6. Are technical terms translated into business language?
7. Is the chart self-explanatory?
8. Is the time period explicit?
9. Are units/currency explicit?
10. Does the title state the conclusion rather than the topic?
11. Is there unnecessary information?
12. Could the slide be misunderstood?
13. Is the evidence status clear?
14. Is the requested decision/action explicit?

A material slide fails if the answer to #2, #3, #4, #10 or #13 is no.

## Plain-language translation rules

Prefer:

- "Cash received was RM2.1m below cash paid" over "negative net cash flow variance."
- "The supplier was paid before the purchase order was approved" over "procurement control non-compliance."
- "Seven patient-months exceeded the expected treatment billing range" over unexplained technical terminology.
- "The data has not yet been reconciled" over "reconciliation remains outstanding."

When a technical term is necessary:
- write the plain-language meaning first;
- put the technical term in brackets only if useful;
- explain the acronym on first use;
- never assume the reader knows system names, accounting codes, regulatory abbreviations or technical process terminology.

### Technical-to-business translation pattern

`Technical fact → Plain-language meaning → Business consequence → Required action`

Example:
`GRNI accrual not recorded → Goods were received but the invoice was not yet recorded → liabilities and expenses may be understated → record and reconcile month-end accruals.`

Do not change the underlying fact while simplifying the language.

## Chairman / Board reading model

The first 3–5 slides should normally answer:

1. Where are we?
2. What changed?
3. What matters?
4. Why does it matter?
5. What does the audience need to decide, challenge, approve or monitor?

Do not make the Chairman search for the conclusion.

Board-level content should prioritise:
- strategic consequences;
- material financial impact;
- significant operational exposure;
- regulatory/governance exposure;
- major customer/reputation consequences;
- management accountability;
- decisions and trade-offs;
- unresolved high-impact uncertainty.

Operational detail belongs in the appendix unless it changes a Board-level conclusion.

