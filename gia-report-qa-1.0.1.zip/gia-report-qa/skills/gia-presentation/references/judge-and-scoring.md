# Judge, QA scoring, reflection and final release tests

## Contents
- Judge / Quality Gate
- QA scoring
- Reflection and anti-regression
- Final release test
- Expanded Final Release Gate

## Judge / Quality Gate

The Judge decides:
- PASS;
- PASS WITH MINOR CHANGES;
- REQUIRES REWORK;
- HARD FAIL.

Critical hard-fail conditions:
- unsupported material number;
- material calculation error;
- invented fact/source;
- allegation presented as confirmed finding;
- materially misleading chart;
- contradiction between executive and appendix content;
- decision/action obscured;
- evidence state omitted for a material disputed claim;
- unreadable or technically broken slide;
- serious ambiguity likely to cause a wrong executive interpretation.

Never average away a critical defect.


## QA scoring

Score 0–5:

- Strategic relevance
- Decision usefulness
- Accuracy
- Evidence traceability
- Clarity
- Plain-language comprehension
- Chairman/Board usefulness
- Simplicity
- Objectivity
- Visual logic
- Narrative flow
- Consistency
- Accessibility
- Action/accountability clarity
- Naturalness and speakability
- Tone integrity

Target:
- 4.0+ overall;
- no critical dimension below 4;
- critical accuracy/evidence defects = hard fail.

## Reflection and anti-regression

After each substantive deck, capture only durable lessons:
- wording rule;
- visual rule;
- QA failure pattern;
- evidence-control improvement;
- audience comprehension lesson;
- reusable template improvement.

Do not store uncontrolled case-specific facts as general memory.

Before future work, check prior durable lessons and regression tests.

## Final release test

The deck is ready only when:

- a non-technical reader can explain the main message;
- a Chairman can identify what matters;
- a Board member can see why it matters;
- management can identify what action is required;
- a specialist can trace material evidence;
- numbers reconcile;
- claims are properly qualified;
- language sounds natural and audience-appropriate;
- tone matches the evidence and purpose;
- slides are readable;
- the appendix supports rather than contradicts the executive story.


## Expanded Final Release Gate

A deck cannot PASS if any of the following is unresolved:
- material unsupported claim;
- material numerical error;
- evidence-status distortion;
- materially misleading visualisation;
- decision authority or requested action unclear on a decision deck;
- material challenge has no evidence path;
- false precision in a material estimate/forecast;
- accessibility defect likely to impair comprehension;
- confidentiality/information-hygiene breach;
- material contradiction across slides;
- tone materially inconsistent with evidence or audience;
- presentation cannot be delivered coherently within the stated time.

The Judge must distinguish:
`PASS` / `PASS WITH MINOR CHANGES` / `REQUIRES REWORK` / `HARD FAIL`.


