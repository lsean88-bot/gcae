# Evidence controls and the staged protocol

## Contents
- Non-negotiable evidence controls
- Staged evidence protocol

## Non-negotiable evidence controls

Never invent:
- facts;
- numbers;
- dates;
- sources;
- management responses;
- root causes;
- legal conclusions;
- regulatory conclusions;
- recommendations presented as agreed decisions.

Every material claim must have:
- source ID;
- source location or reference;
- period;
- entity/business unit;
- evidence state;
- calculation method if derived.

Evidence states:
- CONFIRMED — directly supported by authoritative evidence.
- CORROBORATED — supported by more than one credible source.
- MANAGEMENT-ASSERTED — stated by management but not independently verified.
- ANALYTICALLY-INFERRED — derived through analysis; show method.
- PROPOSED — recommendation or proposed risk, not an established fact.
- UNVERIFIED — evidence is insufficient.
- CONTRADICTED — credible evidence conflicts.

Never turn an allegation into a finding.

## Staged evidence protocol

### Stage 0 — Intake
Capture:
- audience;
- objective;
- topic;
- period;
- entities;
- decision/action expected;
- confidentiality;
- source files;
- requested format.

### Stage 1 — Source inventory
Create an internal source register.

### Stage 2 — Evidence validation
Validate:
- existence;
- authority;
- completeness;
- period;
- entity;
- numerical consistency;
- calculation logic;
- conflicts;
- missing evidence.

### Stage 3 — Analytical synthesis
Extract:
- facts;
- movements;
- exceptions;
- risks;
- opportunities;
- decisions;
- dependencies;
- unresolved gaps.

### Stage 4 — Story architecture
Create the executive storyline before slide production.

### Stage 5 — Visual architecture
Select the simplest effective visual.

### Stage 6 — Draft
Use message titles and plain language.

### Stage 7 — Independent counsel
Run independent critique.

### Stage 8 — Judge / quality gate
Resolve critical defects before release.

### Stage 9 — Render and inspect
Render the deck and inspect every slide for:
- overflow;
- clipping;
- unreadable text;
- poor hierarchy;
- inconsistent spacing;
- chart labels;
- table density;
- visual ambiguity;
- footer/source visibility;
- page numbering;
- consistency.

### Stage 10 — Final comprehension test
Test the executive deck as if the reader has:
- no technical background;
- 30 seconds per slide;
- no author available to explain it.

