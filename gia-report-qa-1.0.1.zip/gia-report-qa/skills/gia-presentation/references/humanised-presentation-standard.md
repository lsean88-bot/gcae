# Humanised Natural Presentation & Tone Standard v2.2

## Purpose
The presentation should be understandable, credible and natural to read and to present aloud. It should sound like an experienced business executive, not an AI system.

## The six-layer communication test
1. **Recognition** — the reader immediately knows what the slide says.
2. **Understanding** — a non-technical reader can explain it.
3. **Meaning** — the reader knows why it matters.
4. **Decision** — the reader knows what is required.
5. **Evidence** — the reader can trace the material claim.
6. **Delivery** — the presenter can say it naturally without reading a machine-generated script.

## Tone formula
**Audience × Purpose × Severity × Evidence State × Relationship**

Tone must be selected, not assumed.

## Humanisation boundary
Humanisation may change wording, sentence structure, sequencing and emphasis. It may not change factual substance, numerical values, evidence state, severity, uncertainty, accountability or audit independence.

## Natural language rules
- Prefer short, concrete sentences.
- Use active voice where it improves clarity.
- State the conclusion before the explanation.
- Replace generic corporate language with specific business language.
- Use the language people would actually use in a senior meeting.
- Keep technical terminology where precision requires it, but explain it.
- Avoid filler transitions and repetitive sentence patterns.

## Tone rules
### Chairman / Board
Calm, concise, factual, consequence-oriented and decision-focused.

### EXCO / Management
Direct, practical, constructive and accountable.

### Audit Committee
Evidence-led, independent, precise and appropriately cautious.

### Investigation
Neutral, non-accusatory and explicit about what is and is not established.

## Hard failures
- Tone implies certainty beyond evidence.
- Tone materially understates a confirmed risk.
- Tone implies blame or misconduct without evidence.
- Humanisation changes a material number, date or conclusion.
- AI/corporate language makes a material message materially harder to understand.
- The wording obscures the required decision or action.

## Speak-it-aloud test
If a presenter would naturally rephrase the slide while speaking, the written slide should normally be rewritten first.
