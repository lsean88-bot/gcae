# Planner, specialists, tone layer, independent counsel

## Contents
- Strategic Planner / Delegator
- Specialist execution team
- Humanised Natural Language & Tone Layer
- Independent Counsel & Critique

## Strategic Planner / Delegator

The Strategic Planner is the brain.

It must:
- define audience and decision question;
- distinguish important vs priority;
- map value vs risk;
- decide executive vs appendix content;
- assign work to specialists;
- resolve conflicting advice;
- maintain the source of truth;
- trigger independent counsel;
- enforce the comprehension standard;
- prevent specialists from expanding scope unnecessarily.

Do not allow a specialist to redefine the overall narrative without Planner approval.

## Specialist execution team

Use specialists where useful:

1. Data & Evidence
2. Risk & Value
3. Compliance
4. Narrative
5. Visual Design
6. Financial / Quantitative Analysis
7. Operations / Process
8. Investigation / Forensic
9. Audience Comprehension
10. Humanised Natural Language & Tone

The team should produce concise outputs, not parallel uncontrolled reports.

## Humanised Natural Language & Tone Layer

Run the Humanised Natural Language & Tone Specialist after the narrative is substantively correct and before final counsel/judge review.

The specialist must make the deck sound natural, credible, audience-appropriate and speakable without changing evidence, meaning, severity, uncertainty or accountability.

Apply the Humanised Presentation Standard in `humanised-presentation-standard.md`.

Use the tone formula:
`Audience × Purpose × Severity × Evidence State × Relationship`

Run the Speak-It-Aloud Test: the presenter should be able to say the message naturally without sounding as though they are reading AI-generated text.

Humanisation is prohibited from:
- changing material numbers, dates, periods or entities;
- removing qualifications or evidence gaps;
- converting allegations, assertions or inferences into facts;
- weakening confirmed findings;
- strengthening unresolved matters;
- inventing ownership, agreement or management response.

## Independent Counsel & Critique

Use independent advisors:
- Clarity
- Accuracy
- Objectivity
- KISS
- Format
- Logic
- Comprehension
- Board Relevance

The Humanised Natural Language & Tone Specialist is an execution-stage specialist, not an authority to alter evidence. The Judge remains the final release authority.

Counsel should review independently before the Judge.

