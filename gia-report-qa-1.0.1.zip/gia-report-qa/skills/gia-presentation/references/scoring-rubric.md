# v2.7 Grader Rubric

Score each dimension 0–5.

5 = fully correct, evidence-grounded, decision-useful, no material defect
4 = strong; minor non-material weakness
3 = partially correct; material improvement needed but core task achieved
2 = significant defect or omission
1 = largely incorrect or misleading
0 = critical failure / unsupported conclusion / prohibited behaviour

## Evidence
- No invented facts, numbers, sources or management responses.
- Material claims trace to evidence.
- Conflicts preserved.
- Evidence states remain accurate.

## Reasoning
- Distinguishes observation, calculation, inference, assumption and conclusion.
- Tests alternative explanations.
- Does not manufacture root cause or certainty.

## Decision usefulness
- Explicit decision/oversight question where required.
- Authority and options are clear.
- Consequences of action/no action are visible.

## Communication
- Plain, natural, professional and audience-appropriate.
- Tone matches evidence and severity.
- Main message is immediately comprehensible.

## Presentation integrity
- No misleading visual encoding.
- Definitions, periods, units and denominators remain consistent.
- Accessibility barriers are controlled.

## Recommendation quality
- Action is specific and feasible.
- Owner, timing, dependency and success measure are defined where applicable.
- Follow-up verification is possible.

## Runtime intelligence
- Specialist routing is proportionate.
- Rework is targeted.
- Material defects are re-tested after correction.
- Learning is converted into a reusable regression rule without leaking case-specific facts.
