# Priority, value vs risk, slide architecture, visuals, accessibility, deck narrative

## Contents
- Importance versus Priority
- Business Value versus Business Risk
- Slide architecture
- Visual selection rules
- Accessibility and human comprehension
- Deck-level narrative

## Importance versus Priority

Use the distinction:

- Importance = consequence if the issue matters.
- Priority = urgency/attention required now.

High importance / high priority:
- immediate Board/EXCO attention.

High importance / lower priority:
- strategic oversight and planned action.

Lower importance / high priority:
- operational management action.

Lower importance / lower priority:
- appendix or routine monitoring.

## Business Value versus Business Risk

Never present risk in isolation when the business trade-off matters.

Assess:
- financial value;
- cost;
- efficiency;
- growth;
- customer impact;
- continuity;
- strategic opportunity;
- reputation;
- compliance;
- control sustainability.

The presentation should answer:
> "What are we protecting, enabling or improving?"

## Slide architecture

Default:
- one message title;
- one dominant visual;
- up to three supporting points;
- source/evidence footer.

Use exceptions for:
- executive summary;
- decision matrix;
- evidence tables;
- appendix.

### Message-title rule

Topic title:
`Inventory Controls`

Message title:
`Inventory variances remain unresolved and could distort reported stock balances`

The title must communicate the conclusion when the evidence supports one.

## Visual selection rules

Choose:
- KPI tiles — few critical metrics;
- bars — comparison;
- lines — trend;
- waterfall — movement/bridge;
- heat map — concentration;
- matrix — prioritisation;
- process — workflow/control sequence;
- timeline — milestones;
- table — exact comparison;
- callout — one critical fact;
- narrative — nuance that cannot be efficiently visualised.

Never use a chart merely because a chart is available.

Charts must:
- have clear units;
- identify period;
- identify baseline/comparison;
- label unusual values;
- avoid unnecessary decoration;
- avoid misleading axes;
- remain interpretable in grayscale/print if relevant.

## Accessibility and human comprehension

Design for:
- mixed technical ability;
- different levels of business knowledge;
- readers who skim;
- readers using printed/PDF versions;
- older displays and projectors;
- visual limitations where practical.

Avoid:
- tiny fonts;
- colour-only meaning;
- dense legends;
- unexplained icons;
- excessive abbreviations;
- decorative dashboards;
- 3D charts;
- ambiguous arrows;
- unexplained traffic-light status.

Status colours must be supported by text such as:
`On track`, `Watch`, `Action required`.

## Deck-level narrative

A strong deck should normally follow:

`Context → Current position → What changed → What matters → Why it matters → Evidence → Risk/value → Decision/action → Accountability → Deep dive → Appendix`

Reorder when the subject demands it.

Do not bury the decision at the end.

