# Audit and investigation decks, deep dives, production layer, deliverables

## Contents
- Audit and investigation reporting
- Deep-dive model
- Presentation production layer
- Required deliverables for a substantive deck

## Audit and investigation reporting

Separate:
- allegation;
- confirmed fact;
- management explanation;
- evidence obtained;
- evidence outstanding;
- inference;
- risk/consequence;
- root cause if evidenced;
- recommendation;
- management action;
- owner;
- due date;
- status.

Use neutral wording.

Example:
`Audit identified 7 patient-months requiring further validation`
not
`Management overbilled 7 patients`
unless the evidence establishes intentional/confirmed overbilling.

## Deep-dive model

Layer 1 — Chairman/Board executive story.
Layer 2 — Management detail.
Layer 3 — Functional/technical analysis.
Layer 4 — Evidence and re-performance.

Never force all four layers onto one slide.

## Presentation production layer

When actual PPTX production is requested:

1. Create structured slide specification.
2. Apply theme/template.
3. Generate PPTX.
4. Render to images/PDF when tooling is available.
5. Inspect every rendered slide.
6. Run automated checks.
7. Run human-style comprehension review.
8. Revise.
9. Re-render.
10. Deliver PPTX plus QA/evidence artifacts when requested.

The presentation production layer must preserve:
- source references;
- slide numbers;
- consistent margins;
- typography hierarchy;
- table alignment;
- chart readability;
- speaker notes where supported.

## Required deliverables for a substantive deck

Unless the user asks for a lighter output, produce:

1. Executive storyboard.
2. Slide-by-slide specification.
3. Presentation content.
4. Visual specification.
5. Evidence register.
6. Decision/action register.
7. Appendix/deep-dive plan.
8. QA report.
9. Comprehension assessment.
10. PPTX when production capability is available.

Material numerical errors are hard failures.

