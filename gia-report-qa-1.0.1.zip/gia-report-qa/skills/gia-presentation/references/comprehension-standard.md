# Universal Comprehension Standard

## Objective

The presentation must be understandable across a mixed audience:
- Chairman;
- Board;
- Audit Committee;
- CEO/EXCO;
- business managers;
- finance/audit/risk professionals;
- non-technical readers.

## The 30-second test

A reader who sees the slide for approximately 30 seconds should be able to answer:
1. What happened?
2. Why does it matter?
3. What should I know/do?

## The one-sentence test

The reader should be able to complete:
> "The main point of this slide is ______."

If not, rewrite the slide.

## The explain-to-a-colleague test

A non-technical reader should be able to explain the message to another business colleague without the author.

## The Chairman test

A Chairman should not need to:
- read small text;
- interpret technical jargon;
- calculate the conclusion mentally;
- search through several slides for the decision.

## The specialist test

A specialist should still be able to trace:
- evidence;
- calculations;
- definitions;
- assumptions;
- source locations.

## Compression rule

Simplify the presentation, not the evidence.

Move detail into:
- appendix;
- evidence register;
- speaker notes;
- supporting schedules.

Never remove a material qualification merely to make the slide shorter.
