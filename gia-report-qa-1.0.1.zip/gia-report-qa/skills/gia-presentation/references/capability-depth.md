# Capability depth protocol and release gate

## Contents
- Capability Depth Protocol — mandatory for complex presentations
- Capability-depth release gate

## Capability Depth Protocol — mandatory for complex presentations

Capability depth means improving the quality of reasoning, validation, challenge and learning — not merely adding more agents. For material or ambiguous work, the Planner must activate the following reasoning layers as needed:

### Claim ledger
Every material claim is represented as:
`claim → source → evidence state → calculation/method → implication → confidence → slide(s)`

No material claim may exist only as prose.

### Causal discipline
Separate:
- observed condition;
- contributing factor;
- root cause;
- consequence;
- correlation;
- hypothesis.

Do not call a contributing factor the root cause without sufficient evidence. Where root cause is not established, state what is known and what validation is required.

### Uncertainty discipline
For material estimates, forecasts or incomplete evidence, record:
- known;
- unknown;
- assumption;
- estimate;
- range/scenario where useful;
- sensitivity;
- decision implication.

Avoid false precision.

### Counterfactual / challenge reasoning
For material conclusions, test:
- what evidence would change the conclusion?
- what alternative explanation exists?
- what would happen if the assumption is wrong?
- what would a skeptical Board member challenge?
- what is the consequence of doing nothing?

### Stakeholder and governance dynamics
Consider who owns the issue, who can decide, who may disagree, who is affected, and whether escalation is required. Never infer motives. Use observable behaviour, governance roles and documented positions.

### Recommendation feasibility
A recommendation is not complete until the system can explain:
`problem → risk → root cause/evidence → proposed action → owner → authority → resources/cost → timing → dependency → success measure → verification`

### Decision-quality test
Before release, determine whether the presentation improves the audience's decision quality rather than merely increasing information. If more information does not improve the decision, move it to the appendix or evidence layer.

### Evidence graph / traceability
Maintain a graph or equivalent structured map linking:
`source → evidence → calculation → claim → finding → risk → recommendation → decision → action → verification`.

A broken material link is a release defect.

### Learning and anti-regression
Record reusable lessons from QA as rules/patterns, not uncontrolled case facts. New rules must be tested against prior failure cases before entering the release baseline.

## Capability-depth release gate

For complex, disputed, investigative, financial or Board-critical presentations, release requires PASS on:
- evidence traceability;
- causal/root-cause discipline;
- uncertainty/scenario discipline;
- counterargument/challenge readiness;
- stakeholder/governance fit;
- recommendation feasibility;
- decision usefulness;
- cross-slide semantic reconciliation;
- humanised tone integrity;
- accessibility;
- delivery readiness.

The Judge must not average away a critical defect.

