# Governance advisory memo template

Use for advisory work (policy, process or design review) where no assurance opinion is given. State plainly that it is advice, not assurance.

| Section | Content |
|---|---|
| Header | Reference, date, to / from by role, classification |
| Purpose and request | Who asked, what question, what decision it informs |
| Nature of the work | Advisory; no assurance opinion; scope and limits; sources used with evidence grade |
| Observations | Numbered; each states the fact, the criterion, and the evidence label (Verified / Supplied by others / Inference / Proposal) |
| Options | Two or three options with benefit, cost or effort where known, and risk of each; no option presented as the only choice unless the criterion requires it |
| Recommendation | Marked as a Proposal; owner role and date to be agreed by management |
| Management decisions needed | Decision, decision-maker role, date |
| Open dependencies | Facts not supplied; carried, not assumed |
