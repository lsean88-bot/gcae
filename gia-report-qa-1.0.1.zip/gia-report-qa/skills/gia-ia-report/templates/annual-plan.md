# Annual audit plan paper template (for Audit Committee approval)

Planning method and risk scoring belong to `gia-audit:gia-engagement-planning`; this template only packages the approved plan for the Committee. Approval is a human decision; the paper never states the plan is approved.

| Section | Content |
|---|---|
| Header | Reference, plan year, date, classification |
| Decision requested | Approve / re-approve the plan; resourcing; any scope limitation |
| Basis of the plan | Risk universe date, risk assessment method, inputs (management, prior findings, external events) with their evidence status |
| Plan table | Engagement, entity, risk driver, rating, quarter, hours, lead role, GIAS standard or coverage objective |
| Coverage | Entities and risk tiers covered; coverage gaps stated, not hidden |
| Resources | Available vs required hours; shortfall and proposed mitigation |
| Changes since last plan | Added, deferred, removed, with reason |
| Dependencies and assumptions | Facts not supplied are listed as open dependencies, not assumed |
| Approval record | Approver role, date, conditions (completed by the Committee secretary) |
