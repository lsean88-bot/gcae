# Flash report template

Use for a Critical or High matter that cannot wait for the next scheduled Audit Committee meeting. One page. Facts only; no motive; status of management awareness stated as it stands.

| Field | Content |
|---|---|
| Reference / date / classification | IA-FLASH-[YYYY]-[NNN]; [date]; Confidential |
| To / from | [AC Chair, CEO, CFO by role] / Group Chief Audit Executive |
| Basis | Approved finding [FIND-###] / draft pending approval (state which) |
| Situation | What was found, in two sentences, with extent and period |
| Exposure | Evidenced amount and potential amount, kept apart; "not yet confirmed" where unquantified |
| Evidence status | Source grade R1-R5 and what remains unverified |
| Recommended immediate action | Action, owner role, date |
| Management status | Informed or not; position as stated; actions so far |
| Next step and next update | What internal audit will do and when it will report again |
| Sensitive-channel note | Fraud-indicative or privileged matters go by the restricted channel (`gia-fraud:gia-fraud-investigation`); see Escalation Rule in `gia-report-qa:gia-external-release` for anything leaving the Group |
