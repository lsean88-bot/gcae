# Supporting Communication Templates

> Note: Template 1 (flash report) is superseded by `flash-report.md` in this folder. The 3P update and the other shells are retained. All templates take their disclosure rules from `gia-report-qa:gia-disclosure-calibration` and use text ratings, not emoji, in Board-grade files.

---

## TEMPLATE 1 — AUDIT FLASH REPORT
*Use for: Critical or High findings that cannot wait for the next scheduled AC meeting.*

```
══════════════════════════════════════════════════════════
INTERNAL AUDIT — FLASH REPORT
Classification: CONFIDENTIAL | Urgency: [HIGH / CRITICAL]
══════════════════════════════════════════════════════════
To      : [AC Chair / CEO / CFO]
From    : Group Chief Audit Executive
Date    : [Date]
Ref     : IA-FLASH-[YYYY]-[NNN]
══════════════════════════════════════════════════════════

SITUATION
[What was found — 2 sentences. Plain language. Factual.]

RISK & EXPOSURE
[Why this matters — financial, regulatory, reputational — quantified.]

RECOMMENDED IMMEDIATE ACTION
[Specific action — who must do what — by when.]

MANAGEMENT STATUS
[Have they been informed? Their position? Actions taken so far?]

NEXT STEPS
[What Internal Audit will do. When next update will be provided.]

══════════════════════════════════════════════════════════
[CAE Name] | Group Chief Audit Executive | [Date]
══════════════════════════════════════════════════════════
```

---

## TEMPLATE 2 — 3P LEADERSHIP UPDATE
*Use for: Weekly or monthly audit status updates to CEO, CFO, or senior management.*
*Progress, Plans, Problems format.*

```
══════════════════════════════════════════════════════════
INTERNAL AUDIT — STATUS UPDATE
Period: [Month / Quarter] | Date: [Date]
Prepared by: Group Chief Audit Executive
══════════════════════════════════════════════════════════

PROGRESS — What we completed this period
▸ [Audit/activity completed] — [Key outcome in one sentence]
▸ [Audit/activity completed] — [Key outcome in one sentence]
▸ [Management action verified closed] — [Brief description]

PLANS — What we are working on next
▸ [Audit/activity in progress] — [Expected completion date]
▸ [Audit/activity starting] — [Scope in one sentence] — [Start date]
▸ [Report being finalised] — [Expected issue date]

PROBLEMS — What needs attention or a decision
▸ [Issue] → Impact: [What is at risk] → Need: [What we need from leadership]
▸ [Issue] → Impact: [What is at risk] → Need: [What we need from leadership]

SCORECARD
  Audit plan completion : [N]% ([N] of [N] audits)    [↑ / → / ↓]
  High findings open    : [N] findings                [↑ / → / ↓]
  Overdue actions       : [N] past agreed date        [↑ / → / ↓]
  Whistleblower cases   : [N] active                  [↑ / → / ↓]

══════════════════════════════════════════════════════════
Questions? Contact: [CAE name] | [email] | [phone]
══════════════════════════════════════════════════════════
```

---

## TEMPLATE 3 — GOVERNANCE ADVISORY MEMORANDUM
*Use for: Advisory observations, policy gaps, or governance matters that are not
formal audit findings but warrant management or Board attention.*

```
══════════════════════════════════════════════════════════
GOVERNANCE ADVISORY MEMORANDUM
CONFIDENTIAL
══════════════════════════════════════════════════════════
To      : [Name, Role]
From    : Group Chief Audit Executive
Date    : [Date]
Ref     : IA-ADV-[YYYY]-[NNN]
Subject : [Plain language subject — what this is about]
══════════════════════════════════════════════════════════

BACKGROUND
[2–3 sentences. Why this is being raised now. What prompted it.]

OBSERVATION
[What has been identified. Factual. Neutral. Evidence-referenced.]

RISK / IMPLICATION
[What could go wrong. Governance, regulatory, operational, or reputational risk.]

RECOMMENDATION
[What the CAE recommends. Specific. Achievable. Time-bound.]

REQUESTED ACTION
[Exactly what the recipient needs to do — and by when.]

══════════════════════════════════════════════════════════
This memorandum is advisory in nature. It does not constitute
a formal audit finding. The CAE welcomes discussion on the
matters raised above.

[CAE Name] | Group Chief Audit Executive | [Date]
══════════════════════════════════════════════════════════
```

---

## TEMPLATE 4 — MANAGEMENT LETTER (Post-Audit)
*Use for: Formal transmittal of audit report to management after fieldwork.*

```
══════════════════════════════════════════════════════════
INTERNAL AUDIT — MANAGEMENT LETTER
CONFIDENTIAL
══════════════════════════════════════════════════════════
Date    : [Date]
To      : [Name, Role, Entity]
From    : Group Chief Audit Executive
Re      : [Audit Title] — Report Ref [IA-YYYY-NNN]
══════════════════════════════════════════════════════════

Dear [Name],

Thank you to you and your team for the cooperation and support extended during our
audit of [subject] covering the period [dates]. Your openness and engagement
contributed to a productive and constructive review.

AUDIT OPINION: [Satisfactory / Needs Improvement / Unsatisfactory / Critical]

We identified [N] findings — [N] rated High, [N] Medium, and [N] Low risk. The
key areas requiring your attention are:

  1. [Finding title] — [One sentence on the issue and required action]
  2. [Finding title] — [One sentence on the issue and required action]
  3. [Finding title] — [One sentence on the issue and required action]

The full report is attached. We ask that you review the findings and confirm your
agreed actions and target dates within [10 / 14] working days.

Internal Audit will follow up on all agreed actions and report remediation progress
to the Audit Committee at the [Quarter/Date] meeting.

Please do not hesitate to reach out if you wish to discuss any of the findings.
We are here as a partner in helping your team strengthen controls and governance.

Yours sincerely,

[CAE Name]
Group Chief Audit Executive
Date: [Date]

══════════════════════════════════════════════════════════
Attachment: Internal Audit Report [IA-YYYY-NNN]
Distribution: [As per report cover page]
══════════════════════════════════════════════════════════
```

---

## TEMPLATE 5 - INVESTIGATION SUMMARY
Superseded by `investigation-summary.md` in this folder, which uses the fraud ladder (weakness, indicator, suspicion, allegation, corroborated, substantiated) and never states motive. The earlier substantiated / unsubstantiated conclusion boxes are retired.
