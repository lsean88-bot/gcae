# Management letter template

Issued after the audit to the process owner's executive. Consistent with the final report; adds nothing new.

| Section | Content |
|---|---|
| Header | Reference, date, addressee role, report reference and version, classification |
| Opening | Scope and period in one sentence; thanks only where specific help was given |
| Summary | Count of findings by rating (identical to the report), overall opinion as stated in the report |
| Matters for attention | Table: finding, rating, agreed action, owner role, date, current status; High and overdue first |
| Positive practices | Only those the report evidences |
| Requests | Responses still pending, documents outstanding, evidence needed for closure |
| Follow-up | Validation approach per `gia-report-qa:gia-evidence-trace` (closure is tested, not asserted) and next reporting date |
| Sign-off | Role, date; sent only after human approval |
