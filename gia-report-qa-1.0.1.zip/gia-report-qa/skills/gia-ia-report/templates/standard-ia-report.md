# Standard IA report template (Profile B shown; Profile A adds the ten-element block)

```
INTERNAL AUDIT REPORT
Reference: [IA-YYYY-NNN]   Version: [n]   Date: [dd-Mmm-yyyy]   Classification: [Confidential]
Entity: [entity]   Process / scope: [scope]   Period: [from] to [to]
Status: Draft for Management Response | Final
Distribution: [roles]
Prepared / Reviewed / Approved: [role, date]
```

## 1. Executive Summary
Opinion: [internal audit's opinion based on the ratings of the individual reviews]
Headline exposure: [one line, sourced figures only]

| No | Finding | Rating | Money involved | Why it matters | Owner (role) | Due |
|---|---|---|---|---|---|---|
| 1 | | | | | | |

## 2. Background, Scope and Period
[Entity, process, period, population, limitations, scope exclusions with the basis for each]

## 3. Big Picture
| Theme | Findings | Exposure | What is working |
|---|---|---|---|

## 4. Findings by Theme
[One block per finding, `references/finding-blocks.md`]

## 5. Accountability Map
| Owner (role) | Findings | Actions | Dates |
|---|---|---|---|

## 6. Proposed Action Plan (subject to management agreement)
| Action | Finding | Owner (role) | Date | Proof of completion |
|---|---|---|---|---|

## 7. Conclusion
[Top three exposures first. Assurance statement if required.]

## Appendix A: Findings register
## Appendix B: Licence and statutory position (as at [date]; register source; [UNVERIFIED] items listed)
## Appendix C: Open dependencies, figures to be reconciled, statement classes (Verified / Supplied by others / Inference / Proposal), glossary and rating scale
