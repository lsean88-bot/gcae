# Audit Committee Paper — Master Template

---

## COVER

```
╔══════════════════════════════════════════════════════════════════╗
║        AUDIT COMMITTEE PAPER — CONFIDENTIAL                     ║
╠══════════════════════════════════════════════════════════════════╣
║  Subject        : [Topic in plain language]                     ║
║  Meeting Date   : [Date]                                        ║
║  Prepared by    : Group Chief Audit Executive                   ║
║  Date Prepared  : [Date]                                        ║
║  Paper Ref      : AC/[YYYY]/[NNN]                               ║
║  Action Required: [ ] For Decision  [ ] For Approval  [ ] For Noting ║
╚══════════════════════════════════════════════════════════════════╝
```

---

## 1. PURPOSE

> [One sentence: What this paper covers and what the Committee is asked to do.]
> *Example: "This paper presents the findings of the Q2 Internal Audit Plan and requests
> the Committee to note progress and approve the revised Q3 audit schedule."*

---

## 2. EXECUTIVE SUMMARY

**Overall Audit Opinion:** [Satisfactory / Needs Improvement / Unsatisfactory / Critical]

**Key Messages:**
1. [Most important point — one sentence]
2. [Second most important point — one sentence]
3. [Third most important point — one sentence]

**Action Required from Committee:**
- [Specific decision or approval needed — with clear options if a decision is required]

---

## 3. AUDIT ACTIVITY SUMMARY

| Audit | Entity | Risk Rating | Status | Key Outcome |
|---|---|---|---|---|
| [Name] | [BU/Location] | High | Complete | [One-liner] |
| [Name] | [BU/Location] | Medium | In Progress | [One-liner] |
| [Name] | [BU/Location] | Low | Planned | Due [date] |

**Plan Progress:** [N] of [N] planned audits complete ([%]) | On track / Delayed

---

## 4. SIGNIFICANT FINDINGS REQUIRING COMMITTEE ATTENTION

*Only Critical and High findings go here. Medium and Low are in the appendix.*

### Finding [F1] — [Plain Language Title]
**Risk Rating:** High | **Entity:** [Name] | **Owner:** [Name/Role]

| Element | Summary |
|---|---|
| **What we found** | [One paragraph — factual, plain language] |
| **Why it matters** | [Risk and estimated exposure] |
| **Why it happened** | [Root cause in plain language] |
| **What we recommend** | [SMART recommendation] |
| **Management position** | [ ] Agree [ ] Partially Agree [ ] Disagree |
| **Action committed** | [Action] by [Owner] by [Date] |

---

## 5. OVERDUE FINDINGS TRACKER

*Findings past their agreed remediation date — escalation for Committee awareness.*

| Finding | Entity | Original Due | Days Overdue | Owner | Revised Date | Escalation Risk |
|---|---|---|---|---|---|---|
| [F ref] | [Name] | [Date] | [N] days | [Name] | [Date] | High |

**CAE Comment:**
> [Brief explanation of why items are overdue and what the CAE is doing about it]

---

## 6. FRAUD & WHISTLEBLOWER SUMMARY

| Metric | This Quarter | Prior Quarter | Trend |
|---|---|---|---|
| New cases received | [N] | [N] | ↑ / → / ↓ |
| Cases closed | [N] | [N] | |
| Cases in progress | [N] | [N] | |
| Cases referred to legal/HR | [N] | [N] | |
| Substantiated cases | [N] | [N] | |

> *No case names or personal details included. Full case details available to Committee
> members on a confidential basis upon request.*

---

## 7. EMERGING RISKS

*Risks observed during audit work that are not yet in the formal audit plan.*

| Risk | Why It Matters | Proposed Response |
|---|---|---|
| [Risk description] | [Business impact] | [Add to plan / Monitor / Advisory] |
| [Risk description] | [Business impact] | [Add to plan / Monitor / Advisory] |

---

## 8. AUDIT RESOURCES & BUDGET

| Element | Budget | Actual | Variance | Comment |
|---|---|---|---|---|
| Headcount (FTE) | [N] | [N] | [±N] | [Brief note] |
| Budget utilised | [RM/USD] | [RM/USD] | [±%] | [Brief note] |
| External co-source spend | [RM/USD] | [RM/USD] | [±%] | [Brief note] |

---

## 9. CAE INDEPENDENCE DECLARATION

> *"I confirm that the Internal Audit function has maintained its independence and
> objectivity in the performance of all audit activities during this period, in
> accordance with IIA Global Internal Audit Standards (GIAS 2024) and the approved
> Group Internal Audit Charter."*
>
> — [CAE Name], Group Chief Audit Executive
> Date: [Date]

---

## APPENDICES

- **Appendix 1** — Full Audit Plan Status (all audits)
- **Appendix 2** — Medium and Low Findings Summary
- **Appendix 3** — Complete Management Action Tracker
- **Appendix 4** — Risk Heat Map (Portfolio View)
- **Appendix 5** — Audit Reports (attached separately)

---

*Confidential — Audit Committee Members Only*
*Not for distribution without prior approval of the Group Chief Audit Executive*
