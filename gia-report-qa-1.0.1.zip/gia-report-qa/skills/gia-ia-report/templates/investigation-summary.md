# Investigation summary template (Audit Committee)

Routing: fraud-indicative matters go to the Audit Committee by the restricted channel. Substance and method come from `gia-fraud:gia-fraud-investigation`; this template only packages the summary. The summary states what the evidence shows at the current rung of the fraud ladder and nothing more.

## Fraud ladder (use these terms only, in this order)
weakness > indicator > suspicion > allegation > corroborated > substantiated

Each rung needs its own evidence. Moving up the ladder requires independent corroboration (R1-R3 for corroborated; the standard of proof for substantiated is an open dependency for Legal, `gia-fraud:gia-fraud-investigation`). Intent, motive, character and blame are never stated or implied. Describe the pattern, the control gap, the amount at issue and the actions of roles, not the state of mind of people.

| Section | Content |
|---|---|
| Header | Reference, date, restricted distribution by role, privilege status (Legal to confirm) |
| Matter and trigger | How it came to attention (allegation source category, indicator, analytics exception); date |
| Current rung | One of the six ladder terms, with the evidence that supports it and the evidence that would be needed for the next rung |
| Facts established | Table: fact, amount, period, source, evidence grade R1-R5, statement class (Verified / Supplied by others) |
| What is not established | Gaps, contradictory evidence, items awaiting third-party confirmation |
| Control environment | Control gaps that allowed the pattern (design gap, operating failure, override, unknown) |
| Exposure | Evidenced and potential, kept apart; recovery position as stated by Legal / Finance |
| Actions taken and proposed | Containment, evidence preservation, notification obligations (Legal to confirm), disciplinary steps owned by HR and Legal |
| Persons | Roles only; no conclusions about individuals; no labelling of conduct |
| Decisions for the Committee | Authorise next step, escalate, notify, approve budget |
| Handling | Escalation Rule triggers (privilege, active investigation, litigation, regulator contact) noted for the authorised reviewer |
