# HTML build

- Use the MKTron HTML palette and the group report template (`gia-core` hosts the shared template reference; the MKTron GIA App workflow is outside this plugin).
- Wrap every table and the heat map in `overflow-x:auto`.
- Check at 390px and 1280px with a headless browser; no horizontal page scroll at 390px.
- Embedded fonts and CSS are stripped by `consolidated_iar_check.py` and `profile_b_lint.py` before text checks, so base64 and "padding" do not cause false hits.
- Heading numbers, finding IDs, counts and ratings must be identical to the DOCX and XLSX (`consolidated_iar_check.py`).
- Profile B: no emoji, no alert boxes; rating shown as text.
