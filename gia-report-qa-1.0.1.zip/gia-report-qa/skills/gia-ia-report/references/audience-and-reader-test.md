# Audience map, co-drafting stages and plain-language substitutions

## Contents
- Audience map
- Co-drafting stages
- Reader test
- Plain-language substitutions
- Sentence tests

## Audience map
| Audience | Needs | Tone | Length | Lead with | Profile |
|---|---|---|---|---|---|
| Board | Strategic risk picture, confidence in governance | Authoritative, concise | 1-page summary | Conclusion | B |
| Audit Committee | Full findings, assurance opinion, actions tracked | Objective, structured | 4-8 pages plus appendix | Ratings and trend | B |
| Chairman / CEO | Three key issues, decisions needed | Direct, plain | Half page | Bottom line | B (`gia-report-qa:gia-board-brief`) |
| CFO | Financial exposure, control gaps, numbers | Precise, data-led | 2-3 pages | Money involved | A or B |
| Management / plant head | What is wrong, what to fix, by when | Collaborative, solution-focused | Per finding | Root cause and fix | A |
| Operations teams | Practical steps, their role | Friendly, clear | 1 page per finding | Action required | A |
| Regulator, lender, external auditor | Factual record | Formal, exact | As required | Facts | `gia-report-qa:gia-external-release` |

## Co-drafting stages
1. Context: audience, decision, source of truth, profile, output set, what is already agreed. Ask only what is not in the project folder.
2. Structure and draft: build the skeleton from `report-structure.md`, then fill section by section; draft directly to final form for Board and external files.
3. Reader test: predict the five questions the reader will ask; check the draft answers each without a follow-up. Then hand to `gia-report-qa:gia-report-qa`.

## Reader test
| Check | Pass condition |
|---|---|
| So what | Each paragraph says why it matters to this reader |
| Five-second | Key message of each finding is clear in one read |
| Five questions | The five most likely reader questions are answered in the document |
| Decision | The reader can state the decision, owner, date and expected outcome |

## Plain-language substitutions
| Audit term | Plain wording |
|---|---|
| Control deficiency | A gap in the process that allowed an error or risk |
| Operating effectiveness | Whether the control works in practice |
| Inherent risk | The risk before any controls |
| Residual risk | The risk left after controls |
| Material weakness | A serious control gap that could lead to significant loss or error |
| Management override | A manager bypassing the normal approval or control |
| Scope limitation | Something that restricted what could be reviewed |
| Walkthrough / substantive testing | Following one transaction end to end / checking the records themselves |

## Sentence tests
Under 25 words (Profile A) or 30 (Profile B); paragraphs under four sentences; define each term at first use; no stock openers or formulaic closers; vary paragraph rhythm. Tone only: the test never changes a rating or a fact. More detail: `gia-report-qa:gia-report-qa` `references/writing-quality.md`.
