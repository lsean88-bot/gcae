# Consolidation workflow and writing rules

## Contents
- Roles and economy
- Baseline lock
- Edited draft from the CAE or GCAE
- Extraction schema
- Synthesis rules
- Writing rules
- QA loop

## Roles and economy
Planner plans and rules on disputes only. Sonnet specialists run in parallel by domain (fixed assets and stock, HR and payroll, licences and statutory, build). Read-only QA panel never edits: accuracy (Sonnet), clarity (Haiku), objectivity (Haiku). Convert each DOCX to markdown once with pandoc so read-only agents can trace cheaply. Save every stage to disk.

## Baseline lock
Done before any build (SKILL.md Step 0). The root causes of rework are an unlocked findings baseline, preparer rules that change source dates and owners, and generic impact text.

## Edited draft returned
1. Compare the previous version with the edited draft (difflib); record each change as Added, Deleted, Reworded or Figure.
2. A cut of a whole issue block is a candidate deletion: ask whether the finding is deleted or only trimmed; apply the answer everywhere including appendices and counts.
3. Where the editor's wording replaces source facts, ask. The user's own verification overrides the source text. A recast item reads "not risk-rated by decision of Group Internal Audit".
4. Trace every statement to the latest sources, one domain specialist per area. Verdicts: ACCURATE / WRONG VALUE / NOT IN LATEST SOURCE / OVERSTATED / MISCLASSIFIED / LEGAL CONCLUSION / UNSUPPORTED INTERPRETATION. List missing source findings too.
5. Keep the change log for the CAE only; it never goes into the report.

## Extraction schema
id, area, plant, title, condition, criteria, impact_company, impact_role, root_cause, rating, figures, recommendation, owner, target_date, mgmt_response, source (report + finding no.), evidence_status (Confirmed / Indicator / Open dependency), links. Figures copied exactly; Word wins over Excel; real conflicts recorded as CONFLICT with both values. Roles only; strip names and employee IDs including JSON keys.

## Synthesis rules
- 6 to 9 themes from the actual findings; drop empty ones.
- Every impact, root-cause, benefit and big-picture line names the finding's own figure, asset, licence, date, decision or role.
- Banned unless the source quantifies: "creates risk", "controls may fail", "reputational damage", "sound start", "most", "much", "low-cost".
- Strengths only where the source states them. Opinion wording: "internal audit's consolidated opinion based on the ratings of the individual reviews".

## Writing rules
- Dates, owners, ratings exactly as the source action plan: no weekend shifting, no minimum-lead-time rule, no merged actions. If a source contradicts itself, use its action-plan value and add one Appendix C row "to be confirmed with the report owner".
- Conflicting figures shown as a range with the role that will reconcile them.
- Absence and unverified items: "was not found", "not on file", "reported (not verified)"; no unsupported operational claims ("the plant operates", "untrained operators").
- Statutory content comes only from the dated register for the jurisdiction; show "position at <date>" and the register source; remove any citation that is neither in a source nor verified.
- No process narration in Profile B files ("documents read", "re-performed", "checked against"). No internal file, sheet, tab, row, location or action-ID references in the body.
- Missing plant facts are open dependencies; missing documents are never evidence of compliance or exemption.

## QA loop
Panel runs in parallel; accuracy traces at least 30 figures to ORIGINAL sources; counts identical in all files; grep titles and figures of deleted items (`consolidated_iar_check.py`). Planner rules on disputes; builder applies all fixes in one round; accuracy re-checks only changed wording. Final grep must allow for false positives (base64 fonts, CSS "padding", "uan" inside "quantified"); the script already strips style, script and base64.
