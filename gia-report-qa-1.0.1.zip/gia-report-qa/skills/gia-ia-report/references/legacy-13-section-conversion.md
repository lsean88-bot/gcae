# Legacy 13-section HTML conversion (reference)

Status: LEGACY MODE. The canonical report is the standard concise IA report plus Excel working paper (`SKILL.md`). Use this reference only when a source report must be converted into the legacy 13-section MKTron HTML layout (for example, to reconcile with an older issued report). It is not a quality gate: its checklist is conversion-only and sits beside, not in place of, the 12-item Quality Gate in `gia-core:iron-rules`. The 13-section structure is not to be used for new reports (decision 01-Sep-2026). Superseded wording below that conflicts with `gia-core:iron-rules` defers to that skill.

## Contents
- Purpose
- CRITICAL CONSTRAINTS — NEVER VIOLATE
- MODULE 0 — WHY THIS MATTERS: THE STANDARD FOR "GOOD"
- PROFESSIONAL STANDARDS ALIGNMENT
- MODULE 1 — PRE-CONVERSION ASSESSMENT
- MODULE 2 — CONTENT MAPPING MATRIX
- MODULE 3 — HTML TEMPLATE STRUCTURE
- MODULE 4 — FILE NAMING CONVENTION
- MODULE 5 — MIGRATION CHANGE LOG
- MODULE 6 — EXCEPTION LOG
- MODULE 7 — EDITORIAL AUTHORITY
- MODULE 8 — QA CHECKLIST (conversion-only checklist: 22 + 9 enhancements + 7-item Communication Quality Lens)
- MODULE 9 — REPORT STATUS WORKFLOW
- MODULE 10 — SIX REQUIRED DELIVERABLES
- SEND-TO-CLAUDE PROMPT BLOCKS
- Conversion rules RC-01 to RC-12
- INTEGRATION MAP


## Purpose

This skill governs the conversion of a completed Internal Audit report into the
approved official HTML publication template — and, within that mechanical conversion,
into the clearest, most decision-ready version of exactly what the source already
says. It does NOT govern audit fieldwork, findings development, or compliance
testing — those are covered by `cae-audit-cowork-plugin`. It does NOT draft a report
from raw notes or working papers before a complete source report exists — that is
`gia-report-qa:gia-ia-report`'s job; bring its output here once the source report is complete.

This skill activates when:
- A finished or draft audit report needs to be formatted into the official HTML template
- An existing report needs to be migrated between report formats
- A report requires publication-readiness review before stakeholder distribution
- A CAE review of report quality, completeness, and IIA GIAS 2024 alignment is needed
- A report is technically complete but reads flat, jargon-heavy, or hard to act on,
  and needs the value-add editorial pass Module 7 permits — without becoming a rewrite

---

## CRITICAL CONSTRAINTS — NEVER VIOLATE

```
CONSTRAINT 1: Do NOT create, invent, or fabricate any audit content.
              No new findings. No new recommendations. No new evidence.
              No new management responses. No new action plans. No new dates.
              No new responsible owners. No new risk ratings.

CONSTRAINT 2: Do NOT change risk ratings, conclusions, management responses,
              or action plans from the source report — ever.

CONSTRAINT 3: Do NOT delete valid source content — flag it in Exception Log instead.

CONSTRAINT 4: Do NOT reconstruct or infer missing evidence — flag it.

CONSTRAINT 5: Do NOT use accusatory, blame-oriented, or emotional language.

CONSTRAINT 6: Source accuracy > readability. When in conflict, source wins.

CONSTRAINT 7: Every finding, recommendation, response, and action must be
              traceable to a specific section of the source report.
```

**Constraint 5 in practice:** "blame-oriented language" is operationalised via the
Constructive Communication & Kaizen Language Layer (AKOS Module 16 /
`constructive-communication-lexicon.md`) — a hardcoded word-choice lexicon
covering phrasing only. Constraint 2 always takes precedence: risk ratings,
conclusions, management responses, and action plans are preserved exactly, and
the lexicon is never applied in a way that changes them.

---

## MODULE 0 — WHY THIS MATTERS: THE STANDARD FOR "GOOD"

A converted report that is merely accurate is necessary but not sufficient. GIAS 2024
Standard 2420 sets the bar explicitly: every audit communication must be **accurate,
objective, clear, concise, constructive, complete, and timely.** The 7-item
Communication Quality Lens at the end of Module 8 operationalises this — apply it as
a mental filter throughout the conversion, not only as a final gate.

In practice, "good" also means the report reads the way `gia-report-qa:gia-ia-report`'s Golden
Communication Rule defines it — **a smart, senior, non-auditor reader can understand
it and act on it without asking a clarifying question** — and passes the "so what /
who / by when / prove it" tests on every material sentence. None of that requires new
content. It requires disciplined use of the Editorial Authority already granted in
Module 7: plain language, thematic grouping, visual storytelling, and jargon
translation — applied to what the source already says, never to what it's assumed to
mean.

**The two failure modes to hold in tension:**
- *Too mechanical* — technically complete (the first 31 items of Module 8 all pass)
  but reads like a checklist: the "so what" is buried in paragraph three, or ten
  findings sit listed with no thread connecting them for the reader.
- *Too creative* — so polished and narrative-driven that a reader can no longer tell
  where the source's own words end and an editorial improvement begins. Constraint 6
  exists precisely for this: when readability and source accuracy pull in different
  directions, source accuracy wins, every time.

---

## PROFESSIONAL STANDARDS ALIGNMENT

Align every report with:

| Standard | Requirement | Where this skill applies it |
|---|---|---|
| GIAS 2024 Std 1.1 — Acting Honestly and Courageously (AMENDED) | Truthful, accurate, open, respectful communication — no omission or concealment of findings | Constraints 1–3; the Exception Log never suppresses a gap |
| GIAS 2024 Std 13.1 — Communicating During the Engagement (NEW) | Objectives, scope, timing changes, and disagreements communicated as they arise | Module 6 `Inconsistent`/`Ambiguous` items routed to CAE, not resolved unilaterally |
| GIAS 2024 Std 14.5 | Engagement conclusions tied to organizational goals and objectives | Module 3, Section 12 |
| GIAS 2024 Std 15.2 | Confirm implementation of recommendations; track at a risk-based interval | Module 9 — handoff to `cae-command-centre` |
| GIAS 2024 Std 2420 — Quality of Communications | Accurate, objective, clear, concise, constructive, complete, timely | Module 0 concept; Module 8 Communication Quality Lens (7 items) |
| GIAS 2024 Std 2440 | Findings communicated to parties with the authority to act | Cover Page distribution fields; Module 8 items 21–22 |
| IIA IPPF | Integrity, Objectivity, Competency, Due Care, Confidentiality | Throughout |
| COSO IC 2013 | Control environment, risk assessment, control activities, information, monitoring | Finding Cause/Impact fields |
| COSO ERM 2017 | Governance & culture, strategy & objective-setting, performance, review, communication | Module 3, Section 12 |
| G20/OECD CG 2023 | Board oversight, transparency, accountability, stakeholder engagement | Cover Page; Module 3, Section 3 |

**Topical Requirements — current status, confirm before citing in any specific report:**
Cybersecurity and Third-Party Topical Requirements are finalised. An AI Risk Engagement
document and an Ethics Topical Requirement were both still in development as of this
writing, with a public consultation window the IIA's own standards documents page
showed open 8 June–23 July 2026 — this area moves quickly, so re-check current status
with a fresh search rather than citing either as finalised from memory.

The report must support: effective governance, sound risk management, strong internal
controls, operational effectiveness, and continuous improvement.

---

## MODULE 1 — PRE-CONVERSION ASSESSMENT

Before converting any report, complete this assessment:

### Source Report Inventory Checklist
```
□ Executive Summary present?
□ Audit Opinion present?
□ Overall Conclusion present?
□ Scope defined?
□ Objectives stated?
□ Methodology described?
□ Audit criteria identified?
□ Risk assessment included?
□ Detailed findings present? (count: ___)
□ Root cause analysis per finding?
□ Impact per finding?
□ Recommendations per finding?
□ Management responses per finding?
□ Agreed action plans per finding?
□ Responsible owners named?
□ Target dates specified?
□ Appendices included?
□ Supporting evidence referenced?
□ Glossary included (if applicable)?
□ Positive practices observed (if applicable)?
```

**If any item is missing:** Record in Exception Log. Do NOT create replacement content.

### Classification and Metadata Check
```
□ Entity name confirmed?
□ Audit engagement name confirmed?
□ Report type confirmed? (Draft / Under Review / Management Discussion / Final)
□ Report date confirmed?
□ Audit period confirmed?
□ Prepared by confirmed?
□ Reviewed by / CAE name confirmed?
□ Version number assigned?
□ Classification level confirmed? (Confidential / Restricted / Internal)
```

### Iron Rule Integrity Signals *(diagnostic — never a reason to alter source content)*

The Iron Rules in `gia-core:iron-rules` (see the IRON RULES module) govern fieldwork, not
conversion — but a source report can still arrive with one of these unresolved.
Check for them here so a real problem reaches the CAE before the Board does, instead
of being silently carried into a polished HTML report:

```
□ Any finding relies solely on R5 (verbal-only) evidence, with no R1–R4
  corroboration stated? (Iron Rule 06)
□ Where 2+ related deficiencies exist, were they aggregated (CD → SD → MW) before
  final classification? (Iron Rule 15)
□ Was fraud risk formally considered in the engagement scope? (Iron Rule 11)
□ Does every recommendation read as SMART — specific, measurable, achievable,
  relevant, time-bound? (Iron Rule 08)
□ Does any finding state or imply personal motive rather than describing the
  pattern of what happened? (Iron Rule 25)
```

**A Fail here is an Exception Log entry for CAE judgement** (`Non-SMART`,
`R5-Only Evidence`, or similar — see Module 6) — never a reason to strengthen,
soften, remove, or reconstruct the source content itself.

---

## MODULE 2 — CONTENT MAPPING MATRIX

**Format** — complete for every source section before conversion:

| # | Source Section | Source Page/Para | Destination Template Section | Content Status | Action |
|---|---------------|-----------------|------------------------------|---------------|--------|
| 1 | Executive Summary | p. X, para Y | Section 2 — Executive Summary | Complete | Migrate |
| 2 | Audit Opinion | p. X | Section 3 — Audit Opinion | Present | Migrate |
| 3 | Finding 1 — [Title] | p. X | Section 7.1 — Finding F-001 | Complete | Migrate |
| 4 | Management Response F-001 | p. X | Section 7.1 — Mgmt Response | Present | Migrate |
| 5 | [Section] | [Location] | [Template section] | Missing | Exception Log |

**Content Status values:**
- `Complete` — fully present, ready to migrate
- `Partial` — present but incomplete — flag in Exception Log
- `Missing` — not in source — flag in Exception Log, do NOT create
- `Inconsistent` — contradicts other source content — flag for CAE review
- `Ambiguous` — unclear meaning — flag for clarification

---

## MODULE 3 — HTML TEMPLATE STRUCTURE

The approved HTML report template structure — populate all sections:

### Cover Page
```
Classification:    [CONFIDENTIAL / RESTRICTED / INTERNAL]
                   ⚠ Do not distribute outside intended audience.

Entity Name:       [Full legal entity name]
Audit Title:       [Full audit engagement title]
Report Type:       [Internal Audit Report / Management Letter / Advisory Report]
Audit Period:      [Start date] to [End date]
Report Date:       [YYYY-MM-DD]
Report Version:    v[X.Y]
Report Status:     [Draft / Under Review / Management Discussion / Final]
Prepared by:       [Name] — Group Chief Audit Executive / Internal Audit
Reviewed by:       [Name, designation]
Approved by:       [Name, designation — if Final]

File Name:         [Entity]_IA_[AuditName]_[ReportType]_v[X.Y].html
```

### Section 1 — Bottom Line Up Front (BLUF) *(Best Practice Addition)*
```
[5 sentences maximum]
Sentence 1: Overall audit opinion and rating.
Sentence 2: Top risk identified.
Sentence 3: Number of findings by risk tier.
Sentence 4: Most critical action required.
Sentence 5: Management's commitment / next steps.
```

### Section 2 — Executive Summary
```
- Key themes (not individual findings)
- Significant risks highlighted
- Improvement opportunities
- Balanced conclusions
- Audit opinion prominently stated
- Support for informed decision-making
Maximum 1 page. No operational detail. No technical audit language.
```

**Thematic grouping (best practice — structural reorganisation, not new content):**
When 3 or more Section 7 findings share a common root cause, process, or control
theme, the Executive Summary may group them under a named theme (e.g. "Payroll
Statutory Compliance," "Third-Party Onboarding Controls") instead of listing findings
one by one. Rules:
- Every finding still appears individually and unchanged in Section 7 — this is a
  summary narrative device only.
- The theme label must describe what the grouped findings actually share — never a
  softened or vaguer restatement of any individual finding.
- Do not create a theme that implies a conclusion (e.g. "isolated incident,"
  "systemic failure") beyond what the source's overall opinion and individual risk
  ratings already support.

### Section 3 — Audit Opinion
```
Opinion:     [Satisfactory / Needs Improvement / Unsatisfactory / Critical]
Rationale:   [Brief, evidence-based rationale — 2–3 sentences]
```

**Opinion Scale:**
| Rating | Meaning |
|--------|---------|
| 🟢 Satisfactory | Controls are effective; minor observations only |
| 🟡 Needs Improvement | Some control gaps; corrective action recommended |
| 🟠 Unsatisfactory | Significant control failures; prompt action required |
| 🔴 Critical | Fundamental control breakdown; immediate action required |

**Trend indicator (conditional — do not infer):** If the source report states or
clearly implies a comparison to the prior audit's opinion, add a trend arrow next to
the rating — ↑ Improving | → Stable | ↓ Deteriorating | ⚠ Escalating. If no
prior-period comparison exists in the source, omit the arrow entirely. Never compute
or estimate a trend the source doesn't state.

### Section 4 — Background and Context
```
- Entity overview
- Business context
- Audit mandate / authority
- Reason for audit
- Prior audit history (if applicable)
```

### Section 5 — Scope and Objectives
```
Objectives: [List from source]
Scope:      [Inclusions and exclusions — from source]
Period:     [Audit period]
Exclusions: [What was NOT in scope and why]
```

### Section 6 — Methodology
```
- Approach used (risk-based, thematic, process-based)
- Evidence gathering techniques
- Sampling methods (if applicable)
- Standards applied
- Tools used
- Limitations (if any)
```

### Section 7 — Detailed Findings

**Standard Finding Format (5-question test):**
```
1. What was observed?    → Condition
2. Why does it matter?   → Criteria / Standard breached
3. What risk may arise?  → Impact
4. What is the cause?    → Root Cause
5. What is recommended?  → Recommendation
```

**12-Field Finding Template:**
```
Finding Reference : F-[XXX]
Finding Title     : [Clear, descriptive — issue and entity, not blame]
Risk Rating       : 🔴 Critical | 🟠 High | 🟡 Medium | 🟢 Low
Criteria          : [Standard, policy, law, best practice breached]
Condition         : [What was found — factual, evidence-based]
Cause             : [Root cause — design gap / operating failure / override / unknown]
Impact            : [Consequence if unaddressed — financial, operational, regulatory, reputational]
Recommendation    : [Practical, actionable, proportionate — addresses root cause]
Management Response: [Management's response — verbatim from source]
Agreed Action     : [Specific action agreed]
Responsible Owner : [Named individual / role]
Target Date       : [YYYY-MM-DD or quarter]
```

**Field guidance — where Editorial Authority (Module 7) meets Iron Rules:**
- *Finding Title* — a readability improvement is permitted here (e.g. "EPF issue
  noted" → "EPF Under-Remittance on Restructured Salary Components"), provided the
  meaning is unchanged. Target Iron Rule 07's shape: WHO | WHAT breach | WHICH
  law/standard — self-explanatory without reading the rest of the finding.
- *Cause* — classify per Iron Rule 10: Design Gap | Operating Failure | Override |
  Unknown. Preserve the source's own classification exactly. If the source doesn't
  classify to this level of specificity, log an Exception ("Cause not classified to
  Iron Rule 10 taxonomy") rather than inferring one.
- *Impact* — plain-language jargon translation is permitted here (e.g. via
  `gia-report-qa:gia-ia-report`'s substitution table — "control deficiency" → "a gap in the
  process that allowed an error or risk"), provided the underlying risk or
  consequence stated in source is preserved exactly, not softened or amplified.

**Risk Rating Scale:**
| Rating | Criteria |
|--------|----------|
| 🔴 Critical | Immediate threat to operations, major financial loss, regulatory breach, potential fraud |
| 🟠 High | Significant control failure, material risk, requires prompt action |
| 🟡 Medium | Moderate control gap, manageable risk, corrective action within quarter |
| 🟢 Low | Minor observation, low risk, improvement opportunity |

**Action Status Tracking** *(Enhancement — for board/AC reporting):*
| Status | Meaning |
|--------|---------|
| 🔴 Overdue | Past target date, not completed |
| 🟠 In Progress | Action underway, within timeline |
| 🟡 Not Started | Action not yet commenced |
| 🟢 Completed | Action implemented and verified |

### Section 8 — Positive Practices Observed

**Format for each positive practice:**
```
Area               : [Function / process / control area]
Practice Observed  : [What was done well — factual]
Significance       : [Why it matters — governance / risk / control value]
```

*Include only if supported by source material. Do not create.*

### Section 9 — Risk Summary and Heat Map

**Risk Heat Map (Likelihood × Impact matrix):**
```
[Plot all findings by Likelihood (1=Rare to 4=Almost Certain) × Impact (1=Minor to 4=Critical)]
Quadrants:
  Top-right (High Likelihood, High Impact) = Critical/High priority zone
  Bottom-left (Low Likelihood, Low Impact) = Monitor zone
```

**Finding Summary Table:**
| Ref | Title | Risk Rating | Root Cause | Status |
|-----|-------|------------|------------|--------|
| F-001 | [Title] | 🔴 Critical | Design Gap | Open |

### Section 10 — Recommendations Summary
```
[Summary table linking all recommendations to owners and dates]
| Ref | Recommendation | Owner | Target Date | Status |
```

### Section 11 — Management Response Summary
```
[High-level summary of management's overall response and commitment]
[Individual responses are captured in Section 7 per finding]
```

### Section 12 — Conclusion
```
- Overall assurance opinion (reiterated)
- Key themes summary
- Forward-looking risk statement
- Audit team commitment to follow-up
```

**Standard 14.5 alignment (flag, don't fabricate):** GIAS 2024 Standard 14.5 requires
engagement conclusions to be tied to organizational goals and objectives. If the
source conclusion already makes that link, preserve it — and foreground it, since
this is exactly the kind of business-relevance a Board reads for. If the source
conclusion does NOT tie to organizational goals, do not add that link during
conversion. Note it instead in the Migration Change Log as a "recommended
enhancement for the next engagement" observation — a suggestion for the audit team,
not a change to this report.

### Section 13 — Appendices
```
Appendix A: Detailed Evidence and Supporting Documentation
Appendix B: Sampling Methodology (if applicable)
Appendix C: Glossary of Terms (if applicable)
Appendix D: Document Reference List
Appendix E: Revision History
```

### Footer (every page)
```
[Entity Name] | Internal Audit Report | [Audit Title] | [Version] | [Classification]
Page [X] of [Y] | Report Date: [YYYY-MM-DD]
Disclaimer: This is a professional internal audit report prepared in accordance with
IIA Global Internal Audit Standards 2024. It does not constitute a statutory audit,
legal opinion, or Chartered Accountant's certificate.
```

---

## MODULE 4 — FILE NAMING CONVENTION

**Corrected Pattern** *(source document had asterisk error — corrected here):*
```
[Entity_Name]_IA_[Audit_Name]_[Report_Type]_v[Major.Minor].html
```

**Rules:**
- Use underscores `_` as separators — no asterisks, no spaces, no special characters
- Entity name: abbreviated legal name (e.g. PAPPL, CHNAP, MKTRON)
- Audit name: descriptive (e.g. Payroll_Compliance, Inventory_Management)
- Report type: Report / Final_Report / Management_Letter / Advisory
- Version: v1.0, v1.1, v2.0

**Examples:**
```
CHNAP_IA_Payroll_Compliance_Report_v1.0.html
PAPPL_IA_Procurement_Final_Report_v2.0.html
MKTRON_IA_Cybersecurity_Report_v1.3.html
MKAPL_IA_Inventory_Management_Report_v1.0.html
```

---

## MODULE 5 — MIGRATION CHANGE LOG

**Format — populate for every change made:**

| # | Section | Source Content (before) | Template Content (after) | Change Type | Reason |
|---|---------|------------------------|--------------------------|------------|--------|
| 1 | Finding F-001 title | "EPF issue noted" | "EPF Under-Remittance on Restructured Salary Components" | Readability | Title made descriptive per template standard |
| 2 | Exec Summary | 4 pages | 1 page | Structural | Template limits Exec Summary to 1 page |
| 3 | Section numbering | Unnumbered | F-001, F-002… | Formatting | Template requires sequential finding refs |
| 4 | Exec Summary | F-002, F-004, F-007 listed separately | Grouped under theme "Third-Party Onboarding Controls" | Structural | Findings share root cause; Section 7 entries unchanged |
| 5 | Finding F-006 Impact | "Segregation of duties control deficiency" | "A gap in the process meant one person could both raise and approve payments" | Readability | Plain-language substitution; risk/consequence preserved |

**Change Types:**
- `Formatting` — visual/layout changes only
- `Structural` — reorganisation of content
- `Readability` — language improved, meaning preserved
- `Template Alignment` — required to fit template fields
- `Standardisation` — consistency corrections (spelling, grammar, numbering)

*NOT permitted change types: Content creation, Risk re-rating, Conclusion change,
Response change, Action plan change, Evidence reconstruction.*

---

## MODULE 6 — EXCEPTION LOG

**Format — record every content gap, inconsistency, or ambiguity:**

| # | Section | Issue Type | Description | Action Required | Status |
|---|---------|-----------|-------------|----------------|--------|
| 1 | Finding F-003 | Missing | Management response not provided in source | Request from management | Pending |
| 2 | Finding F-005 | Inconsistent | Target date in body text (Q3 2025) differs from action plan table (Sep 2025) | CAE to confirm | Pending |
| 3 | Appendix B | Incomplete | Evidence reference cited but document not attached | Request from audit team | Pending |

**Issue Types:**
- `Missing` — content not present in source
- `Incomplete` — partially present
- `Inconsistent` — conflicts with other source content
- `Ambiguous` — unclear or open to interpretation
- `Evidence Gap` — reference made but evidence not provided
- `Date Conflict` — dates contradict between sections
- `Non-SMART` — a recommendation lacks a specific owner, date, or measurable action
  (Iron Rule 08)
- `R5-Only Evidence` — a finding appears to rely solely on verbal/unverified evidence
  (Iron Rule 06)
- `Unaggregated Deficiency` — 2+ related deficiencies present but not aggregated
  before classification (Iron Rule 15)

**Exception Log Rules:**
- Do NOT create replacement content for any exception
- Do NOT leave exceptions unresolved in a Final report
- All Critical/High exceptions must be resolved before Final status
- Exceptions downgrade report status to "Under Review" until resolved

---

## MODULE 7 — EDITORIAL AUTHORITY

### PERMITTED (no CAE approval required)
```
✅ Grammar corrections
✅ Spelling corrections
✅ Formatting improvements (fonts, spacing, colours, alignment)
✅ Structural reorganisation (within approved template sections)
✅ Heading standardisation
✅ Numbering standardisation (F-001, F-002…)
✅ Readability improvements (plain language, shorter sentences)
✅ Removal of excessive jargon (meaning preserved)
✅ Constructive language reword per AKOS Module 16 lexicon (meaning, risk rating,
   and severity preserved)
✅ Consistent capitalisation and punctuation
✅ Table formatting
✅ Navigation improvements (hyperlinks, anchors)
✅ Cross-reference corrections
✅ Thematic grouping of related findings in the Executive Summary narrative
   (Section 7 findings unchanged — see Module 3, Section 2)
✅ Trend arrow (↑ → ↓ ⚠) next to the Audit Opinion, only where source states or
   clearly implies a prior-period comparison (see Module 3, Section 3)
✅ Plain-language jargon substitution using a standard lexicon (e.g.
   `gia-report-qa:gia-ia-report`'s substitution table) — meaning, risk rating, and severity
   preserved
✅ Visual storytelling elements — callout/key-takeaway boxes, one-sentence "so what"
   captions under heat maps and tables — summarising content already present
   elsewhere in the report, never introducing a new claim
✅ Applying the GIAS Standard 2420 Quality of Communications lens (Module 0) as a
   review filter, as long as no individual change crosses into a NOT PERMITTED item
   below
```

### NOT PERMITTED (requires CAE approval + source evidence)
```
❌ Creating new findings
❌ Creating new recommendations
❌ Creating new evidence or references
❌ Creating new management responses
❌ Creating new action plans or dates
❌ Changing risk ratings
❌ Changing audit conclusions or opinions
❌ Deleting valid findings or conclusions
❌ Strengthening or weakening observations
❌ Re-interpreting audit evidence
❌ Attributing fault to named individuals
❌ Adding fraud or investigative language without audit mandate
❌ Changing management responses (verbatim preservation required)
❌ Adding trend, benchmark, or comparison data not present in source
❌ A theme label, callout, or "so what" caption that implies a conclusion stronger
   or weaker than the source's own opinion and individual risk ratings support
```

---

## MODULE 8 — QA CHECKLIST (conversion-only checklist: 22 + 9 enhancements + 7-item Communication Quality Lens)

**Pre-publication validation — all items must pass for Final status:**

### Content Integrity (8 items)
```
□ 1.  No hallucinated / fabricated content
□ 2.  No unsupported assumptions
□ 3.  No unsupported conclusions
□ 4.  No missing findings from source
□ 5.  No duplicate findings
□ 6.  All source sections mapped (Content Mapping Matrix complete)
□ 7.  Evidence links preserved and traceable
□ 8.  Risk ratings match source (no changes made)
```

### Response and Action Integrity (4 items)
```
□ 9.  Management responses preserved verbatim
□ 10. Action plans preserved (no changes)
□ 11. Target dates preserved exactly as in source
□ 12. Responsible owners preserved exactly as in source
```

### Template Compliance (5 items)
```
□ 13. HTML template fully compliant (all sections populated)
□ 14. Formatting standardised throughout
□ 15. Metadata completed (version, date, status, prepared by)
□ 16. Revision history updated
□ 17. File naming convention applied correctly
```

### Standards Alignment (3 items)
```
□ 18. IIA GIAS 2024 alignment maintained
□ 19. Positive practices retained where present in source
□ 20. Report written in clear business language
```

### Stakeholder Readiness (2 items)
```
□ 21. Suitable for Management and Audit Committee review
□ 22. Suitable for Board review
```

### Enhanced QA Items (9 additions — beyond original 22; header previously said "8," corrected in v2.0)
```
□ 23. BLUF section is present and ≤5 sentences
□ 24. Exception Log is complete (all exceptions recorded and actioned)
□ 25. Content Mapping Matrix is complete (all source sections mapped)
□ 26. Migration Change Log documents all changes made
□ 27. Classification marking is present on cover and footer
□ 28. Disclaimer is present on every page footer
□ 29. Action status tracking populated (Open / In Progress / Completed / Overdue)
□ 30. Risk heat map included (if 3+ findings)
□ 31. Constructive language applied (AKOS Module 16) without altering any risk
      rating, conclusion, management response, or action plan
```

### Communication Quality Lens — GIAS 2024 Standard 2420 (7 items, checked separately)

Standard 2420 requires audit communications to be **accurate, objective, clear,
concise, constructive, complete, and timely.** Apply this as a distinct pass over the
finished report — it tests *how* the (unchanged) content reads, not *what* it says:

```
□ 32. Accurate — every statement in the converted report matches its source exactly;
      no rounding, softening, or amplifying of facts
□ 33. Objective — free of bias or advocacy in either direction (for or against
      management); constructive language (AKOS Module 16) never tips into either
□ 34. Clear — a reader outside internal audit (the "non-expert test" — see
      `gia-report-qa:gia-ia-report`) can understand every finding without a follow-up question
□ 35. Concise — no sentence, section, or appendix carries content that doesn't earn
      its place; BLUF ≤5 sentences and Executive Summary ≤1 page are enforced (RC-10)
□ 36. Constructive — findings are framed to help the organisation improve, never to
      assign blame (Constraint 5 / AKOS Module 16), while risk ratings stay exact
      (Constraint 2)
□ 37. Complete — every item the Content Mapping Matrix marked `Complete` or `Partial`
      made it into the report; nothing silently dropped
□ 38. Timely — Report Date, Audit Period, and version metadata are current and
      internally consistent; no stale dates carried over from a template default
```

**Both checklists must fully pass for Final status — conversion-only checklist; separate from the 12-item Quality Gate.**

---

## MODULE 9 — REPORT STATUS WORKFLOW

```
DRAFT
  ↓ [Internal review by audit team]
UNDER REVIEW
  ↓ [CAE approval]
MANAGEMENT DISCUSSION
  ↓ [Management responses received; exceptions resolved]
FINAL
  ↓ [Issued to Audit Committee / Board]
ARCHIVED
```

**Status Rules:**
- `Draft` — internal only; not for distribution
- `Under Review` — circulated for factual accuracy check; findings not yet agreed
- `Management Discussion` — findings agreed; management responses being obtained
- `Final` — all responses received; conversion QA checklist (Module 8) passed; CAE approved; issued
- `Archived` — retired status; a newer version now exists (see that version's own record for what replaced this one)

**After Archived:** follow-up tracking (implementation verification, closure
reporting — GIAS Standard 15.2 / Iron Rule 26) is out of scope for this skill — hand
off to `cae-command-centre`'s Follow-Up Audit module.

---

## MODULE 10 — SIX REQUIRED DELIVERABLES

Every report conversion must produce:

| # | Deliverable | Format | Purpose |
|---|-------------|--------|---------|
| 1 | Fully populated HTML report | .html | Primary stakeholder deliverable |
| 2 | Content Mapping Matrix | Table (within HTML or separate) | Traceability audit trail |
| 3 | Migration Change Log | Table (within HTML or separate) | Editorial change record |
| 4 | Revision History | Table (in HTML footer/appendix) | Version audit trail |
| 5 | Validation Summary | Conversion checklist (31 integrity/compliance + 7 Communication Quality Lens) | QA evidence |
| 6 | Exception Log | Table (if applicable) | Content gap record |

---

## SEND-TO-CLAUDE PROMPT BLOCKS

### Block A — Pre-Conversion Assessment
```
PRE-CONVERSION ASSESSMENT REQUEST

CHARLIE HILLS PLAN: Read source report → assess completeness → map to template.

Source report: [filename / content provided]

INSTRUCTION:
1. Read the complete source report
2. Complete the Source Report Inventory Checklist (20 items)
3. Complete the Classification and Metadata Check (9 items)
4. Identify all findings — list: ref, title, risk rating
5. Flag any missing, incomplete, or inconsistent sections in Exception Log format
6. Confirm: total findings count, total recommendations, management responses present Y/N
7. Run the Iron Rule Integrity Signals check (Module 1) — log any flag to Exception Log
8. Recommend report status: Draft / Under Review / Management Discussion / Final
9. Do NOT create, assume, or reconstruct any missing content

CHECK: Is every item traced to a specific source section? If no — flag as exception.
```

### Block B — Content Mapping Matrix Generation
```
CONTENT MAPPING MATRIX REQUEST

INSTRUCTION:
1. Map every source section to the approved template section
2. For each item: source location | template destination | content status | action
3. Flag Missing/Incomplete/Inconsistent in Exception Log
4. Produce the complete matrix in table format
5. State total mapped: [N] | total exceptions: [N]

Do NOT add content not present in the source.
```

### Block C — HTML Report Generation
```
GENERATE HTML AUDIT REPORT

CHARLIE HILLS PRE-CHECK:
✅ Source report fully read?
✅ Content Mapping Matrix complete?
✅ Exception Log updated?
✅ No missing Critical content unresolved?

INSTRUCTION:
1. Produce a complete, self-contained HTML report
2. File name: [Entity]_IA_[AuditName]_[Type]_v[X.Y].html
3. Follow the 13-section template structure exactly
4. Migrate ALL content from source — do not create or delete
5. Apply editorial improvements (grammar, formatting, readability) and, where the
   Module 7 PERMITTED list allows it, the value-add techniques (thematic grouping,
   plain-language substitution, trend arrows, callout boxes) through the Module 0
   Communication Quality Lens
6. Preserve: risk ratings, management responses, action plans, dates, owners
7. Include: BLUF, risk heat map, action status tracking, classification marking
8. Include in appendix: Content Mapping Matrix, Migration Change Log, Exception Log
9. Include: Revision History, Validation Summary (conversion QA checklist)
10. Apply file naming convention: underscores, no asterisks

IRON CONSTRAINT: No hallucination. No new content. No risk rating changes.
```

### Block D — QA Validation
```
QA VALIDATION REQUEST

INSTRUCTION:
Run the conversion QA checklist against the generated HTML report — the 31-item
integrity/compliance checklist (Module 8) plus the 7-item Communication Quality Lens
(GIAS Standard 2420).
For each item: ✅ Pass | ❌ Fail | ⚠ Partial
For any Fail or Partial: state what needs correction.
Do NOT pass the report if any content integrity items (1–8) fail.
Do NOT pass the report if any Critical exceptions remain unresolved.
Produce: Validation Summary table.
```

---

## Conversion rules RC-01 to RC-12

`gia-core:iron-rules` is the single source of truth for every numbered rule in this
portfolio, including the RC-series below — if
this section ever disagrees with that skill, that skill wins and this one is stale.
These twelve are report-conversion-specific; they do not duplicate the portfolio Iron Rules.

```
RC-01: No finding without named source reference — traceable to source report
RC-02: No content creation — every element must exist in the source
RC-03: Risk ratings preserved exactly — no upgrades or downgrades
RC-04: Management responses verbatim — no paraphrasing
RC-05: Missing content → Exception Log — never reconstruct
RC-06: Editorial changes only → Migration Change Log
RC-07: File naming: underscores only — no asterisks, spaces, or special characters
RC-08: QA Framework must fully pass before Final status — the conversion checklist in this reference's
       current checklist (Module 8). the source RACM namespace note still says "30 items" as of this writing —
       flagged for the portfolio owner to reconcile centrally, not silently changed
       here.
RC-09: Exception Log must be empty of unresolved Critical items before Final
RC-10: BLUF ≤5 sentences; Executive Summary ≤1 page
RC-11: Charlie Hills thought process (Plan→Verify→Execute→Check→Log) every time
RC-12: Disclaimer on every page footer — professional IA report, not CA/legal opinion
```

### Iron Rules that also apply to conversion work

Consult `gia-core:iron-rules` directly for the full rule set, the Evidence Hierarchy
(R1–R5), and the 12-item Quality Gate (Rule 09). These are the ones a report
conversion is most likely to touch, with where each is operationalised here:

| Rule | What it requires | Where this skill applies it |
|---|---|---|
| Rule 01 | Named evidence (R1–R4) or web-validated source | Module 2 Content Mapping Matrix — every migrated item traces to a source location |
| Rule 04 | Retracted findings never appear, not even partially | Module 1 Pre-Conversion Assessment inventory check |
| Rule 06 | R5 (verbal) evidence never cited in a finding | Module 1 Iron Rule Integrity Signals — flagged to Exception Log, never silently removed |
| Rule 07 | Self-explanatory finding title (WHO \| WHAT breach \| WHICH standard) | Module 3 Section 7 — permitted readability improvement, meaning preserved |
| Rule 08 | Every recommendation is SMART | Module 1 Iron Rule Integrity Signals; Module 6 `Non-SMART` Exception flag |
| Rule 15 | Deficiencies aggregated (CD→SD→MW) before final classification | Module 1 Iron Rule Integrity Signals |
| Rule 19 | Management response and action plan required before Final | Module 9 Report Status Workflow |
| Rule 25 | A finding describes the pattern, never states motive | Constraint 5; Module 6 Exception Log |
| Rule 26 | Follow-up audit planned and tracked (GIAS Std 15.2) | Module 9 — handoff to `cae-command-centre` after Archived |

---

## INTEGRATION MAP

This skill sits between fieldwork and distribution. Hand off to the right skill
instead of extending this one's scope:

| Need | Skill | Why not do it here |
|---|---|---|
| Audit fieldwork, findings development, control testing | `cae-audit-cowork-plugin` / `cae-audit-cowork-plugin-v4` | This skill converts a *completed* report — it never generates findings |
| Drafting a report from raw notes/working papers before one exists | `gia-report-qa:gia-ia-report` | This skill needs a completed source report to convert; draft it there first, then bring the result here |
| RC-01–RC-12 (conversion-only), the Iron Rules, Evidence Hierarchy, Quality Gate | `gia-core:iron-rules` | Single source of truth — this skill cites it rather than re-deriving it |
| Word-choice / constructive-language rules behind Constraint 5 | AKOS Module 16 (`constructive-communication-lexicon.md`) | Phrasing standard only — never overrides Constraint 2 |
| Chairman-specific one-page translation of a Final report | `gia-report-qa:gia-board-brief` | Different artifact (strategic briefing note) for a narrower audience |
| Follow-up tracking, implementation verification, Management Response Tracker, Group Dashboard feed | `cae-command-centre` | Post-issuance lifecycle — out of scope once this report reaches Final/Archived |
| The same report (or an extract) needs to go to a regulator, statutory authority, or external/statutory auditor | `gia-report-qa:gia-external-release` | Different Golden Rule and institutional voice for third-party readers — do not repurpose the internal AC/Board version as-is |
| A second, genuinely independent QA pass on a Critical-rated report before Board release | `gia-report-qa:gia-report-qa` (Mode B) | The conversion checklist in Module 8 is self-administered; for the highest-stakes reports, a separate adversarial read earns its cost |

### Reference file

| File | Purpose |
|------|---------|
| `constructive-communication-lexicon.md` (AKOS Module 16, if present in environment) | Word-choice standard behind Constraint 5 and the Module 7 reword permission |

*(v2.0 note: the previous version of this table listed version-pinned external
filenames — `CAE-Audit-Cowork-Plugin-v3.0.html` and a matching prompt file — that
could not be verified in this environment and conflict with `gia-fleet-roster`'s own
finding of a v4.0 file and an unresolved `cae-audit-cowork-plugin` /
`-v4` naming collision. Removed rather than repeated; the Integration Map above
points to the verified skill IDs instead.)*


