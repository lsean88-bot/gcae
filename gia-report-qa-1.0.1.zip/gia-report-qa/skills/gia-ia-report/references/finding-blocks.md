# Finding blocks

## Contents
- Profile A: ten-element thought process
- Profile B: theme block
- Grouping rule
- Wording rules

## Profile A (auditee / EXCO pack)
Explain each finding the way an experienced auditor would talk a smart non-accountant through it.
1. Title: plain sentence stating the issue and its consequence.
2. Rating, money involved, and label (Confirmed / Confirmed by management / Indicator / Evidence not provided).
3. What we looked at.
4. What we noticed: facts, figures, one concrete example from the evidence.
5. Why this concerns us: the reasoning chain (if X, then Y, which means Z).
6. What it means for the business: profit, cash, tax, safety, production, licence, lender or auditor confidence.
7. What the rule expects: plain words, plus a citation to the dated statutory register (no inline rates or dates).
8. Why it probably happened (to confirm with management).
9. What we recommend: SMART steps, owner role, proposed date.
10. How you can check it: workbook sheet and rows, with a one-line how-to. This is the only element that may carry a worksheet pointer, and only in Profile A.

## Profile B (Board, Audit Committee, Chairman, external-grade)
One block per finding, table form:

| Field | Content |
|---|---|
| Finding | ID and plain title |
| Rating / classification | Approved rating; CD / SD / MW where used |
| What was found | Condition with extent and period |
| Why it matters to the company | Names the finding's own figure, asset, date or role |
| Why it matters to the role | Named role consequence |
| Root cause | Established cause, or "Not established" |
| Benefit of fixing | Only if the source states or management agrees one; else "Expected benefit to be confirmed by management" |
| Recommendation | SMART: owner role, action, outcome, date, proof of completion |
| Management response | Pending / Agree / Partly agree / Disagree, with the response as given |
| Source | Report and finding number (the Source column carries traceability; no sheet or row references in the body) |

## Grouping rule
Grouping is a judgement. Combine two items only when they share root cause, fix and owner and the reader understands each better together. Otherwise keep separate. Rank all findings by risk, highest first, in one table; no top-N cut-off.

## Wording rules
- Absence: "was not found" or "not on file"; "the register shows ...; no document seen"; "reported (not verified)".
- Fraud: weakness or indicator only unless the ladder in `gia-fraud:gia-fraud-investigation` supports a higher rung; no motive. "Shown as zero; cause not established."
- No legal conclusions. "The requirement cited is ... (Legal to confirm)."
- Exposure the source estimates is never written "not quantified"; use "not yet confirmed".
- Define abbreviations in a glossary. Full action text; never truncate with an ellipsis.
