# Excel working paper specification

## Contents
- Sheets
- Build rules
- Profile differences
- Verification

## Sheets
| Sheet | Content |
|---|---|
| Executive_Summary | Opinion, bottom line (5 sentences), ranked table of ALL findings, count by rating (formulas), what is working, disclaimer |
| Findings | One row per finding; all block fields; management response dropdown (Agree / Partly agree / Disagree) plus comment; Source column |
| Finding_Cards | Printable vertical block per finding with page break (Profile A) |
| Schedules | Complete item schedules for findings over 15 items; named + remainder = total |
| Action_Plan | Action, owner role, date, status dropdown; status list follows `gia-report-qa:gia-evidence-trace` (seven statuses) |
| Statutory_Validation | Each statutory item: register source, URL, access date, verified-on date, [UNVERIFIED] flag |
| Documents_Needed | Open dependencies and requested documents |
| Terms | Glossary and rating scale |

The full evidence register (EV, CRIT, PROC, WP, FIND, MR, ACT, trace matrix) is built by `gia-report-qa:gia-evidence-trace`; this workbook is the report-facing working paper and may be generated from it.

## Build rules
- Formulas for summaries; recalculate in LibreOffice so cached values exist; zero formula errors before any report cites it.
- Read back the cells you cite; row numbers drift when rows are inserted.
- One Source column (report plus finding number). No raw JSON.
- No "we tested", "inference", "workpaper" wording in cells that feed a Profile B file.

## Profile differences
Profile A: the Findings sheet carries the "How you can check it" pointer. Profile B: the workbook supports the report, but the report body never points into it.

## Verification
Run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-ia-report/scripts/consolidated_iar_check.py` for count identity and figure trace across DOCX, HTML and XLSX, and `profile_b_lint.py` over the workbook text for Profile B.
