# Report structure: standard concise IA report

## Contents
- Cover
- Sections 1 to 7
- Appendices A to C
- Single-entity vs consolidated
- Status and sign-off
- Length guidance

## Cover
Reference, entity, period, report date, version, classification, status (`Draft for Management Response` or `Final`), distribution by role, prepared / reviewed / approved by role and date. Roles only; no personal names in method content.

## Sections
| # | Section | Content | Rule |
|---|---|---|---|
| 1 | Executive Summary | Overall opinion (internal audit's opinion on the ratings of the individual reviews), one headline-exposure line with sourced figures only, ranked table of ALL findings | Sentences of 30 words or fewer in Profile B, under 25 in Profile A |
| 2 | Background, Scope and Period | Entity, process, period, population, limitations and scope exclusions | Exclusions re-evaluated when new operating facts emerge |
| 3 | Big Picture | Themes, what is working (only where the source states it), exposure by theme | 6 to 9 themes for a plant IAR |
| 4 | Findings by Theme | One block per finding (`finding-blocks.md`) | Named-item and no-partial-list rules per `gia-report-qa:gia-disclosure-calibration` |
| 5 | Accountability Map | Owner role by finding and action | Must reconcile to the action owners in section 6 |
| 6 | Proposed Action Plan | Action, owner role, date; "(proposed)" only where the source calls owners proposed | Dates and owners exactly as the source action plan |
| 7 | Conclusion | Opens with the top three exposures; assurance statement (reasonable or limited) if the engagement requires one | No new facts |

## Appendices
| App. | Content |
|---|---|
| A | Findings register (all findings, one row each: ID, title, rating, source, owner, date, status) |
| B | Licence and statutory position as at a stated date, each item with its register source and verified-on date; unverified items tagged [UNVERIFIED] |
| C | Open dependencies and figures to be reconciled (missing plant facts, source contradictions, items "to be confirmed with the report owner"); Rule 37 statement-class table; glossary and rating scale |

## Single-entity vs consolidated
A single-entity IAR uses the same layout with themes optional. A consolidated IAR adds a Source column (source report and finding number) in Appendix A and applies the baseline lock in `consolidation-workflow.md`. Cross-report links are written as "related matters to be reviewed together" and kept only where both sources name the same asset or process; never state cause between reports.

## Status and sign-off
Draft for Management Response: responses may read "Pending". Final: management response and action plan present for every finding; Quality Gate (12) passed and sign-off recorded by a human via `gia-report-qa:gia-report-qa`. The report never states that it was signed off unless the register records the approver and date.

## Length
Aim for concise: tables over narrative; findings with more than 15 items carry a summary in the body and the complete schedule in the Excel WP or an appendix.
