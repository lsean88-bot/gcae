#!/usr/bin/env python3
"""consolidated_iar_check.py - deterministic cross-file checks for a consolidated IA report set
(DOCX + HTML + XLSX). Three checks:

  D01 deleted-finding grep   every term in --deleted must be ABSENT from every supplied file.
  C01 finding-count identity the set of finding IDs (and headline "N findings" statements) must
                             be identical across all supplied files.
  F01 figure trace           every figure in --figures (CSV: figure,source_file[,label]) must
                             appear in at least one report file AND in its named source text
                             file; fewer than --min-figures rows is a WARN (default 30).

Exit code: 0 = no ERROR; 1 = ERROR found; 2 = could not run (unreadable input, no files, bad CSV).
Exit 2 is never a pass. Limits: ID matching is regex-based (--id-regex); figure matching is exact
after removing thousands separators and spaces; a clean run does not prove wording is accurate.
HTML text is taken after removing <style>, <script> and base64 data URIs (avoids false hits on
embedded fonts and CSS such as 'padding').

Usage:
  python3 consolidated_iar_check.py --docx R.docx --html R.html --xlsx R.xlsx \
      --deleted deleted.txt --figures figures.csv [--id-regex REGEX] [--sheet Findings] \
      [--min-figures 30] [--json out.json]
deleted.txt: one term per line (title phrase, figure or finding ID); '#' starts a comment.
"""
import argparse
import csv
import json
import os
import re
import sys
import zipfile
from html.parser import HTMLParser
from xml.etree import ElementTree as ET

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
DEFAULT_ID = r"\b(?:F|FIND)[- ]?[A-Z0-9]{0,6}-?\d{1,3}\b"


class _Strip(HTMLParser):
    def __init__(self):
        super().__init__()
        self.out, self.skip = [], 0

    def handle_starttag(self, tag, attrs):
        if tag in ("style", "script"):
            self.skip += 1
        elif tag in ("p", "br", "tr", "li", "h1", "h2", "h3", "h4", "div"):
            self.out.append("\n")
        elif tag in ("td", "th"):
            self.out.append(" ")

    def handle_endtag(self, tag):
        if tag in ("style", "script") and self.skip:
            self.skip -= 1

    def handle_data(self, d):
        if not self.skip:
            self.out.append(d)


def read_docx(p):
    with zipfile.ZipFile(p) as z:
        out = []
        for n in z.namelist():
            if re.match(r"word/(document|footnotes|endnotes|header\d*|footer\d*)\.xml$", n):
                root = ET.fromstring(z.read(n))
                for para in root.iter(W + "p"):
                    out.append("".join(t.text or "" for t in para.iter(W + "t")))
        return "\n".join(out)


def read_html(p):
    raw = open(p, encoding="utf-8", errors="replace").read()
    raw = re.sub(r"data:[a-z0-9/+.-]+;base64,[A-Za-z0-9+/=]+", "", raw)
    s = _Strip()
    s.feed(raw)
    return re.sub(r"[ \t]+", " ", "".join(s.out))


def read_xlsx(p, sheet):
    import openpyxl
    wb = openpyxl.load_workbook(p, data_only=True)
    texts, ids_sheet = [], None
    for ws in wb.worksheets:
        for row in ws.iter_rows(values_only=True):
            texts.extend(str(v) for v in row if v is not None)
    return "\n".join(texts)


def norm_num(s):
    return re.sub(r"[,\s ]", "", s).lower()


def find_ids(text, rx):
    return {re.sub(r"[\s]", "", m.group()).upper() for m in re.finditer(rx, text)}


def headline_counts(text):
    return sorted({int(m.group(1)) for m in re.finditer(r"\b(\d{1,3})\s+(?:internal\s+audit\s+)?findings?\b", text, re.I)})


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--docx")
    ap.add_argument("--html")
    ap.add_argument("--xlsx")
    ap.add_argument("--deleted")
    ap.add_argument("--figures")
    ap.add_argument("--id-regex", default=DEFAULT_ID)
    ap.add_argument("--sheet", default="Findings")
    ap.add_argument("--min-figures", type=int, default=30)
    ap.add_argument("--json")
    a = ap.parse_args()

    files = {}
    try:
        if a.docx:
            files["docx"] = read_docx(a.docx)
        if a.html:
            files["html"] = read_html(a.html)
        if a.xlsx:
            files["xlsx"] = read_xlsx(a.xlsx, a.sheet)
    except Exception as e:
        print(f"CANNOT RUN: unreadable input: {e}")
        sys.exit(2)
    if not files:
        print("CANNOT RUN: supply at least one of --docx --html --xlsx")
        sys.exit(2)

    items = []

    def add(code, sev, msg):
        items.append({"code": code, "severity": sev, "message": msg})
        print(f"{sev:5} {code} {msg}")

    # D01 deleted-finding grep
    if a.deleted:
        try:
            terms = [t.strip() for t in open(a.deleted, encoding="utf-8") if t.strip() and not t.lstrip().startswith("#")]
        except Exception as e:
            print(f"CANNOT RUN: {e}")
            sys.exit(2)
        for t in terms:
            short = len(t) <= 4
            pat = re.compile((r"\b" + re.escape(t) + r"\b") if short else re.escape(t), re.I)
            for kind, txt in files.items():
                n = len(pat.findall(txt))
                if n:
                    add("D01", "ERROR", f"deleted term '{t}' still present in {kind} ({n} hit(s))")
        if not terms:
            add("D01", "WARN", "deleted-terms file is empty; nothing was grepped")
    else:
        add("D01", "INFO", "no --deleted file supplied; deleted-finding grep not run")

    # C01 finding-count identity
    idsets = {k: find_ids(v, a.id_regex) for k, v in files.items()}
    for k, s in idsets.items():
        print(f"INFO  C01 {k}: {len(s)} distinct finding IDs")
    if len(files) > 1:
        union = set().union(*idsets.values())
        for k, s in idsets.items():
            missing = sorted(union - s)
            if missing:
                add("C01", "ERROR", f"{k} lacks finding IDs present elsewhere: {', '.join(missing[:15])}")
        counts = {len(s) for s in idsets.values()}
        if len(counts) > 1:
            add("C01", "ERROR", "finding counts differ across files: " + ", ".join(f"{k}={len(s)}" for k, s in idsets.items()))
    elif not any(idsets.values()):
        add("C01", "WARN", "no finding IDs matched --id-regex; count identity not testable")
    for k, v in files.items():
        hc = headline_counts(v)
        n = len(idsets[k])
        bad = [h for h in hc if n and h != n and h > 1]
        # a headline 'N findings' that differs from the ID count is flagged for a human look (rating sub-counts are common)
        if bad:
            add("C01", "WARN", f"{k}: headline statement(s) of {bad} findings vs {n} distinct IDs; confirm they are sub-counts")

    # F01 figure trace
    if a.figures:
        try:
            rows = list(csv.reader(open(a.figures, encoding="utf-8")))
            rows = [r for r in rows if r and r[0].strip() and not r[0].startswith("#")]
            if rows and rows[0][0].strip().lower() == "figure":
                rows = rows[1:]
        except Exception as e:
            print(f"CANNOT RUN: {e}")
            sys.exit(2)
        if len(rows) < a.min_figures:
            add("F01", "WARN", f"only {len(rows)} figures traced; expected at least {a.min_figures}")
        report_norm = {k: norm_num(v) for k, v in files.items()}
        for r in rows:
            fig = r[0].strip()
            src = r[1].strip() if len(r) > 1 else ""
            nf = norm_num(fig)
            if not any(nf in t for t in report_norm.values()):
                add("F01", "ERROR", f"figure '{fig}' not found in any report file")
            if not src:
                add("F01", "ERROR", f"figure '{fig}' has no source file named")
                continue
            try:
                stext = norm_num(open(src, encoding="utf-8", errors="replace").read())
            except Exception as e:
                add("F01", "ERROR", f"figure '{fig}': source file unreadable ({e})")
                continue
            if nf not in stext:
                add("F01", "ERROR", f"figure '{fig}' not found in source '{os.path.basename(src)}'")
            else:
                miss = [k for k, t in report_norm.items() if nf not in t]
                if miss and len(miss) < len(report_norm):
                    add("F01", "WARN", f"figure '{fig}' present in some report files but missing from {', '.join(miss)}")
    else:
        add("F01", "INFO", "no --figures file supplied; figure trace not run")

    if a.json:
        json.dump(items, open(a.json, "w"), indent=1)
    errs = sum(1 for i in items if i["severity"] == "ERROR")
    print(f"SUMMARY errors={errs} warns={sum(1 for i in items if i['severity']=='WARN')}")
    sys.exit(1 if errs else 0)


if __name__ == "__main__":
    main()
