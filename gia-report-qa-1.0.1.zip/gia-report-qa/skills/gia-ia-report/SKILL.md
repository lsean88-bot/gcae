---
name: gia-ia-report
description: "Builds the standard concise internal audit report (cover, 7 sections, 3 appendices) plus Excel working paper, Profile A (auditee/EXCO) or Profile B (Board/AC), and consolidated IARs. Use when drafting, consolidating or finalising an IA report, flash report, management letter or investigation summary. Do NOT use for Chairman briefs (use gia-report-qa:gia-board-brief)."
---

# GIA IA Report

Canonical output: **standard concise IA report + Excel working paper (WP)**. The 13-section long form is legacy and is used only for conversion of an older issued report (`references/legacy-13-section-conversion.md`). Iron rules, the 12-item Quality Gate and the R1-R5 evidence hierarchy live in `gia-core:iron-rules`; cite by name and rule number, never restate or count them here.

## Step 0: choose the profile and the type

| | Profile A: auditee / EXCO pack | Profile B: Board, Audit Committee, Chairman, external-grade |
|---|---|---|
| Reader | Auditee, plant head, EXCO; not auditors | Chairman, Audit Committee, directors; external reporting |
| Finding style | Ten-element thought process (`references/finding-blocks.md`) | Compact theme block with Source column |
| WP pointer | One "how to check" line per finding is allowed | None in the body. Source column and appendix only |
| Tone and visuals | Plain, calm, firm on facts. Colour words allowed | Evidence-calibrated, balanced. Tables over narrative. No emoji, alert boxes or self-commentary |
| Lint | `profile_b_lint.py --profile A` (row refs WARN) | `profile_b_lint.py --profile B` (all ERROR) |

Report types: single-entity IAR, consolidated IAR (several source reports), or a shorter form from `templates/` (flash report, advisory memo, management letter, annual plan paper, investigation summary, AC paper, communications). If the request is ambiguous, ask once which profile and which output set (DOCX, HTML, XLSX).

## Step 1: lock the baseline before any build

Ask in one question: (1) the authoritative source per area (default: latest Word report; Excel and HTML are supporting and often stale); (2) the output set; (3) whether management responses are supplied or all "Pending". Then list the findings in each source report and get approval of the list before building.

- Body finding = own heading or numbered entry with condition text. Valid.
- Summary-only item (heat map, summary table, action table remnant) = deleted remnant. Exclude.
- Ask about editor remarks left in headings and about damaged findings (rebuild from summary wording, or drop).
- Exclude figures that internal audit derived itself unless asked.
- A source that contradicts itself is quoted as stated and raised as a question.
- A finding flagged invalid, unproven or mischaracterised is removed entirely, everywhere (body, appendices, held-out lists, conflict notes, workbook, counts, accountability map, linked causes). A narrower restatement is kept only if independently verifiable. Never mention that it was removed in the report.
- Where an entity or plant fact is not supplied, do not assume it. Carry it as an open dependency (Appendix C). A scope exclusion based on "no documents" or "newly commissioned" is re-evaluated whenever new operating facts appear (for example trial production). Missing documents are not evidence that a statutory obligation does not exist.

When the CAE or GCAE returns an edited draft, follow `references/consolidation-workflow.md` (diff, deletion questions, seven trace verdicts, change log kept outside the report).

## Step 2: extract, then synthesise with specific value

Schema, theme rules, banned vague phrases and cross-report link rules: `references/consolidation-workflow.md`. Core rules: copy figures exactly (Word wins over Excel; real conflicts are shown as a range with the reconciling role); roles only, no names or employee IDs; every impact statement names the finding's own figure, asset, date or role; 6 to 9 themes for a plant IAR (a one-page brief uses at most 5, see `gia-report-qa:gia-board-brief`).

## Step 3: build

Structure (`references/report-structure.md`): Cover (reference, date, status "Draft for Management Response", distribution by role), then 1 Executive Summary, 2 Background, Scope and Period, 3 Big Picture, 4 Findings by Theme, 5 Accountability Map, 6 Proposed Action Plan (subject to management agreement), 7 Conclusion (opens with the top three exposures); Appendix A findings register, B statutory and licence position, C open dependencies and figures to be reconciled. Rank ALL findings by risk in one table (No, title, rating, money involved, why it matters, owner, due date); no top-N cut.

- Rating: use the approved scale; deficiency classification CD / SD / MW with aggregation assessed (`gia-core:iron-rules`). Item 6 of the Quality Gate is met in Profile B by a text rating, not a colour symbol.
- Evidence: grade source evidence R1-R5 (strict R3 test); classify each report statement with the Rule 37 classes Verified / Supplied by others / Inference / Proposal; other label schemes map via the evidence-label-map reference of `gia-report-qa:gia-evidence-trace`. Absence of evidence is written "not found" or "not on file", never "there is no".
- Dates, owners, ratings: exactly as the source action plan. Management response "Pending" is allowed while the status is Draft for Management Response; it is required before FINAL.
- Fraud and misconduct: ladder weakness > indicator > suspicion > allegation > corroborated > substantiated; never motive; wording per `gia-fraud:gia-fraud-investigation`. No legal conclusions: "The requirement cited is ... (Legal to confirm)".
- Statutory content: no inline rates, thresholds or dates. Cite the dated register (`references/statutory-register-<juris>.md` in the entity pack, `gia-audit:gia-pack-india|pack-mexico|pack-malaysia`) and show "position at <date>". Anything unverified is tagged [UNVERIFIED] and listed in Appendix B.
- Excel WP: `references/excel-wp-spec.md`. Formulas for summaries, recalculated with zero errors, one Source column, no raw JSON.
- DOCX: use the `docx` skill; render and look at it. HTML: `references/html-build.md`.
- Disclosure by audience (named-item rule, no partial lists): `gia-report-qa:gia-disclosure-calibration`.

## Step 4: check, then QA

1. `python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-ia-report/scripts/consolidated_iar_check.py --docx F.docx --html F.html --xlsx F.xlsx --deleted deleted.txt --figures figures.csv` (deleted-finding grep, finding-count identity, figure trace; at least 30 figures traced to original sources).
2. `python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-report-qa/scripts/profile_b_lint.py FILES --profile B` (or A).
3. Hand off to `gia-report-qa:gia-report-qa` for the Quality Gate (12), independent QA passes and human sign-off. The preparer never signs off its own output.

## Delivery and economy

Save every stage to disk under the engagement folder; never hold a deliverable only in context. Planning stays with the planner model; execution goes to Sonnet/Haiku agents (`agents/report-builder.md` writes; reviewers are read-only). Deliver files as `_vN`; if a file is locked open, save under a new name and say so. Any change log against an edited draft is delivered separately, marked for the CAE only.

## References

| File | Read when |
|---|---|
| `references/report-structure.md` | Building cover, sections, appendices; single vs consolidated |
| `references/finding-blocks.md` | Writing a Profile A thought-process finding or Profile B theme block |
| `references/excel-wp-spec.md` | Building the working paper |
| `references/consolidation-workflow.md` | Consolidating reports; handling an edited draft; writing rules |
| `references/html-build.md` | HTML build and responsive check |
| `references/audience-and-reader-test.md` | Audience map, co-drafting stages, plain-language substitutions |
| `references/legacy-13-section-conversion.md` | Converting an older report to the legacy layout only |
| `templates/` | flash-report, advisory-memo, management-letter, annual-plan, investigation-summary, audit-report, ac-paper, comms-templates |
