---
name: gia-external-release
description: "Final submission-ready documents for readers outside the Group (regulators, external auditors, investors, lenders) in institutional voice with local statutory terms (Malaysia, India, Mexico). Use when asked for regulator submissions, statutory filings, auditor responses or representation letters. Do NOT use for Board or AC papers (use gia-report-qa:gia-board-brief)."
---

# GIA External Release

Governs how audit substance is packaged and released to people outside the Group. It does not generate findings; substance comes from the engagement work (`gia-audit`, `gia-fraud` for investigations). The output is the approved-for-release document only.

## Golden rule

Produce only the final document. Nothing before or after it: no framing sentence, no summary of changes, no process commentary, no AI disclaimers. The file carries no drafting notes, review comments, change log, TODO or placeholder text. Run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-report-qa/scripts/profile_b_lint.py FILE --profile B` before release.

## Missing information (resolves the stop-and-ask vs open-dependency tension)

| Situation | Action |
|---|---|
| Material fact is missing and release can proceed with a limitation | State it with a fallback phrase from `references/writing-standards.md` (for example "based on the information made available"); list the open dependency to the requester in the chat reply, not in the document |
| Material fact is missing and the conclusion depends on it | Do not release. Ask the requester for the fact. Never fill the gap with a plausible guess |
| Content touches the Escalation Rule (below) | Hard stop on that portion until the authorised reviewer confirms |

Material facts: dates, entities, amounts, ownership, accounting treatment, regulatory requirement, jurisdiction, control effectiveness, risk conclusions. Non-material drafting choices (structure, template, phrasing) take a sensible default.

## Escalation Rule: hard stop

If drafting touches legal privilege, an active investigation, a disciplinary matter, a fraud inquiry, pending litigation, M&A, pricing strategy, intellectual property, cybersecurity architecture or confidential third-party information, stop drafting that portion and flag it for legal or authorised management review. It is resolved only by the right person confirming what may be disclosed, not by careful wording.

## Institutional voice

| Prefer | Avoid |
|---|---|
| "The Company ...", "Management ...", "The review identified ...", "The evidence indicates ...", "Documentation provided demonstrates ..." | "We found ...", "I believe ...", "It appears ...", "Probably ...", "Likely ..." |
| "may result in", "could lead to", "increases the risk of" | "proves", "definitely", "obviously", "clearly fraudulent" |

Opinion or representation language is allowed only when labelled ("Management has represented that ..."). Tone is constructive and collaborative: pair each gap with the improvement it enables and treat Management as a partner. This governs tone only; a material finding stays exactly as material, and balance means no reassurance the evidence does not support (`references/human-voice.md`). No emoji or informal devices unless the recipient's own template uses them.

## Localisation

Use the recipient's own statutory bodies and terms, matched to the entity's jurisdiction (term banks in `references/localisation-terms.md`; unlisted jurisdictions: confirm terms before drafting). Spell out full names at first use for non-local readers. Rates, thresholds and effective dates are never typed from memory: cite the dated statutory register for the jurisdiction (`gia-audit:gia-pack-india|pack-mexico|pack-malaysia`, `references/statutory-register-<juris>.md`) and show the position date; unverified items are not placed in an external document.

## Evidence standard

State only what is supported by documentation, data, a labelled management representation, an applicable regulation or a named standard. For every number, date, name or conclusion, be able to point to its exact source (zero-fabrication check, `references/quality-assurance-gate.md`). Grade sources R1-R5 (`gia-core:iron-rules`). Cite a framework only when reasonably applicable (table in `references/writing-standards.md`).

## Workflow

1. Identify recipient, jurisdiction, framework.
2. Pull substance from the engagement work; do not re-derive from memory.
3. Check the Escalation Rule; apply `references/disclosure-governance.md` (three-tier boundary, Newspaper Test, Permanence Rule, minimum-necessary disclosure, which never justifies omitting a material fact).
4. Select the template and draft directly to final form.
5. Run the Output Gate silently (below), then the lint.
6. Return only the finished document; for a formatted file use the `docx` or `pdf` skill with this language standard.

| Document | Template |
|---|---|
| Regulator submission, statutory filing | `templates/regulator-submission.md` |
| External auditor response, representation letter | `templates/external-auditor-response.md` |
| Independent reviewer, certifying body response | `templates/statutory-compliance-report.md` |
| Investor or lender report | `templates/investor-lender-report.md` |
| Control matter block (inside any of the above) | `templates/control-finding-block.md` |

## Output Gate (add-on to the Quality Gate and QA passes; never a replacement)

Run the four QA passes first (independent read, proofread, internal consistency, zero-fabrication; `references/quality-assurance-gate.md`), then confirm:
- Reads as though a reviewer who did not draft it approved it; proofread; every repeated figure and classification identical.
- No internal reasoning, comments, change logs or process references; no placeholder text; nothing before or after the document in the response.
- Every claim traces to evidence, a labelled representation or a named standard; only applicable standards cited.
- Institutional voice; no first-person claims; risk language calibrated, no unproven certainty or fraud claims.
- Recommendations specific and actionable, each tied to an identified risk.
- Local terminology matches the entity's jurisdiction; statutory content matches the dated register.
- No Escalation Rule content included without confirmed authorisation; passes the Newspaper Test and Permanence Rule.
- Reads like an experienced human wrote it (`references/human-voice.md`).

## References

| File | Read when |
|---|---|
| `references/writing-standards.md` | Prohibited content, gap phrasing bank, framework table, completeness test |
| `references/human-voice.md` | Tone checklist and examples |
| `references/localisation-terms.md` | Term banks Malaysia, India, Mexico |
| `references/quality-assurance-gate.md` | Four release passes |
| `references/disclosure-governance.md` | Boundary, Escalation Rule, Newspaper and Permanence tests |
