# Localisation — Local Statutory & Regulatory Terms

Every external document uses the statutory bodies, agencies, and terminology the local
regulator/reader actually uses — never a generic international translation ("social security
fund" instead of the correct local name/acronym) and never another jurisdiction's acronym
borrowed by mistake (e.g. never write "PF" for Malaysia's EPF, or "IMSS" in a Malaysia document).

## How to apply this

- **Document going to the local regulator/authority itself** (e.g. LHDN, EPFO, SAT): use the
  term exactly as that body uses it — its own name, its own acronym, its own form/reference
  numbering. Do not spell out what the regulator already knows better than anyone.
- **Document going to a non-local reader** (e.g. an overseas investor, a foreign lender, group
  HQ): spell out the full name at first use, then use the acronym — "the Employees Provident Fund
  (EPF)" — so a reader unfamiliar with the jurisdiction can follow it.
- **Entity determines jurisdiction**: match the terms below to the entity actually in scope
  (MKPC/Erawan LMW/Nephrocare → Malaysia; MKAPL → India; MKSDL → Mexico). Never mix jurisdictions'
  terminology in one document.
- **Rates, thresholds, and current figures**: this file is for correct terminology only. For
  current rates, ceilings, or thresholds, use the dated statutory register in the matching
  entity pack (`gia-audit:gia-pack-malaysia`, `gia-audit:gia-pack-india`, `gia-audit:gia-pack-mexico`) rather than this list — figures here would go stale.
- **Any jurisdiction not listed below**: confirm the correct local statutory body names and
  acronyms before drafting. Do not default to Malaysia/India/Mexico terms or a generic English
  equivalent for an unlisted country — verify locally first (zero-assumption).

## Malaysia

| Term | Full Name |
|---|---|
| EPF | Employees Provident Fund (KWSP) |
| SOCSO / PERKESO | Social Security Organisation |
| EIS | Employment Insurance System |
| HRD Corp (HRDF) | Human Resources Development Corporation (formerly HRDF) |
| PCB / MTD | Potongan Cukai Bulanan / Monthly Tax Deduction |
| LHDN | Inland Revenue Board of Malaysia (Lembaga Hasil Dalam Negeri) |
| RMCD | Royal Malaysian Customs Department (Jabatan Kastam Diraja Malaysia) |
| SST | Sales and Service Tax |
| MyInvois | LHDN's e-Invoice platform |
| MACC | Malaysian Anti-Corruption Commission — s.17A (corporate liability) |
| DOSH | Department of Occupational Safety and Health |
| DOE | Department of Environment |
| PDPA | Personal Data Protection Act 2010 |
| SSM | Companies Commission of Malaysia (Suruhanjaya Syarikat Malaysia) |
| BNM | Bank Negara Malaysia (central bank) |
| MWO | Minimum Wages Order |
| CKAPS | Care Centre and Kidney Dialysis Centre licensing (healthcare entities) |

## India (entity-dependent: Tamil Nadu / Maharashtra)

| Term | Full Name |
|---|---|
| EPF / EPS | Employees' Provident Fund / Employees' Pension Scheme (EPFO) |
| ESIC | Employees' State Insurance Corporation |
| TDS | Tax Deducted at Source |
| GST / CGST / SGST / IGST | Goods and Services Tax (Central/State/Integrated) |
| PT | Professional Tax (state-specific — TN Professional Tax, Maharashtra PT Act 1975) |
| Bonus Act | Payment of Bonus Act 1965 |
| Gratuity Act | Payment of Gratuity Act 1972 |
| CLRA | Contract Labour (Regulation and Abolition) Act 1970 |
| POSH | Prevention of Sexual Harassment Act 2013 |
| LWF | Labour Welfare Fund (state-specific) |
| ROC / MCA | Registrar of Companies / Ministry of Corporate Affairs |
| ICAI | Institute of Chartered Accountants of India |
| FEMA | Foreign Exchange Management Act |
| RBI | Reserve Bank of India |
| MSME | Micro, Small and Medium Enterprises (Development) Act |
| PAN / TAN | Permanent Account Number / Tax Deduction and Collection Account Number |
| Factories Act | Factories Act 1948 |
| S&E Act | (State) Shops and Establishments Act |

## Mexico

| Term | Full Name |
|---|---|
| IMSS | Instituto Mexicano del Seguro Social (social security institute) |
| INFONAVIT | Instituto del Fondo Nacional de la Vivienda para los Trabajadores (housing fund) |
| SAT | Servicio de Administración Tributaria (tax authority) |
| CFDI | Comprobante Fiscal Digital por Internet (digital tax invoice) |
| IVA | Impuesto al Valor Agregado (VAT) |
| IEPS | Impuesto Especial sobre Producción y Servicios (excise tax) |
| ISR | Impuesto Sobre la Renta (income tax) |
| STPS | Secretaría del Trabajo y Previsión Social (labour ministry) |
| REPSE | Registro de Prestadoras de Servicios Especializados (specialised services registry) |
| NOM | Norma Oficial Mexicana (official technical standard) |
| IMMEX | Industria Manufacturera, Maquiladora y de Servicios de Exportación (maquiladora regime) |
| BANXICO | Banco de México (central bank) |
| LFT | Ley Federal del Trabajo (Federal Labour Law) |
| CFF | Código Fiscal de la Federación (Federal Fiscal Code) |
| SEMARNAT | Secretaría de Medio Ambiente y Recursos Naturales (environment ministry) |

## Other jurisdictions

No term bank exists yet in this skill. Confirm the correct statutory body names, agency
acronyms, and filing terminology for the specific country before drafting — treat this the same
as any other zero-assumption evidence gap: verify, don't infer from a similar-sounding country.
