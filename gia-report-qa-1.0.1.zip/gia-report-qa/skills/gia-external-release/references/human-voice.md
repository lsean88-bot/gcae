# Human, Objective, Collaborative Voice — Reference

This governs *tone*, not substance. It never overrides the Golden Rule, the evidence standard,
or risk-rating accuracy in SKILL.md — a material finding is written in a warmer, more human
register, but it stays exactly as material.

## The standard

Write as an experienced, respected professional would — objective, constructive, evidence-calibrated
and collaborative — the way a trusted advisor writes, not the way software generates
text. The reader should feel they are dealing with a competent, fair-minded person who wants the
relationship and the outcome to go well, not a compliance engine listing exceptions.

- **Objective**: every claim is still evidence-based; constructive framing is a tone choice, not licence
  to soften a rating, omit a fact, or downplay severity. Balance means no reassurance the evidence does not support.
- **Constructive**: default to forward-looking, opportunity-framed language for the path
  ahead, while stating the current-state fact plainly. Pair every gap with the improvement it
  enables.
  - Instead of: "This control failed."
  - Write: "This control did not operate as designed during the period; addressing it presents
    an opportunity to strengthen [process] going forward."
  - The risk rating and root cause are unchanged either way — only the framing around them warms.
- **Collaborative**: write about Management as a partner in resolving the matter, not an
  adversary being caught out. "Management has agreed to..." / "Working with [function], the
  following action has been agreed..." rather than language that assigns blame.
- **Human**: read every paragraph aloud before releasing. If it sounds like a checklist or a
  template with blanks filled in, rewrite it in your own words while keeping every fact intact.

## Anti-AI-pattern checklist

Scan the finished document for these tells and remove them:

- **Stock openers/transitions**: "It is important to note that...", "Furthermore,",
  "Additionally,", "In today's environment...", "It should be noted that..." — cut the phrase
  and state the point directly.
- **Formulaic closers**: "In conclusion,", "Overall, it can be said that..." — end on the actual
  substance instead.
- **Symmetric triads and hedge-stacking**: "not only... but also...", "It is worth noting,
  however, that..." piled up sentence after sentence — vary structure instead.
- **Uniform paragraph rhythm**: every paragraph the same length, every sentence a similar length
  and shape — a human writer varies pace; short sentence after a long one, for emphasis.
- **Generic corporate filler**: "leverage", "utilize" (use "use"), "robust", "holistic",
  "seamless", "in order to" (use "to") — plain word beats inflated one.
- **Repetitive sentence openers**: three sentences in a row starting "The Company..." or "This
  finding..." — vary the subject and sentence shape.
- **Over-hedging**: qualifying every sentence ("may potentially", "could possibly") when the
  evidence supports a direct statement.
- **Echoing the prompt/question in the answer** — write the document as its own artefact, with no
  trace of the request that produced it.

## Quick self-test

Before releasing, ask: *would a well-regarded, experienced audit partner sign their name to this
exact wording?* If a sentence reads like a template with the nouns swapped, rewrite it.
