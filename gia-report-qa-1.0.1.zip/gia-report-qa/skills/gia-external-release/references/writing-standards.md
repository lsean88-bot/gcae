# External & Regulatory Submission — Writing Standards Reference

## Contents
- Table of Contents
- 1. Prohibited content — full list
- 2. Evidence-gap fallback phrasing
- 3. Applicable standards & framework citation table
- 4. Sentence-level red flags
- 5. No-Assumptions Policy (Stop-and-Clarify)
- 6. Control Reporting structure


Full detail behind the SKILL.md summary. Load this file when drafting an external document to
check specific wording, or when unsure whether something belongs in the deliverable.

## Table of Contents
1. Prohibited content — full list
2. Evidence-gap fallback phrasing
3. Applicable standards & framework citation table
4. Sentence-level red flags
5. No-Assumptions Policy (Stop-and-Clarify)
6. Control Reporting structure

---

## 1. Prohibited content — full list

Never include any of the following in an external deliverable, unless the user has expressly
asked for it to be included:

**Internal working papers** — working notes, draft comments, internal observations, preliminary
findings, internal discussions, brainstorming, review comments, collaboration notes, meeting
notes, discussion summaries, internal emails, Teams/Slack/WhatsApp conversations.

**Drafting information** — change logs, revision history, version comparisons, "what changed" /
"changes made" notes, editing explanations, AI reasoning or thought process, methodology used to
draft the document, prompt instructions, internal assumptions not supported by evidence.

**Internal audit process** — testing performed (unless the report specifically requires it),
audit procedures, internal checklists, sampling rationale, internal review workflow, quality
review comments.

**Administrative information** — placeholder text, TODO items, notes to reviewers, formatting
instructions, document-generation comments, hidden metadata, internal references.

**Confidentiality** — internal deliberations, legal strategy, privileged communications,
personal opinions, sensitive internal commentary, unless explicitly requested by the user.

Also avoid, as a matter of writing quality: marketing language, emotional wording, personal
opinions, speculation, defensive wording, subjective conclusions, unsupported statements,
overstatement.

## 2. Evidence-gap fallback phrasing

When evidence is insufficient to support a statement, use one of:

- "Based on the information available..."
- "Management has represented that..."
- "No supporting evidence was provided to verify..."

Never fill an evidence gap with an assumption, an inferred number, or a plausible-sounding
estimate.

## 3. Applicable standards & framework citation table

Cite only the standard(s) reasonably applicable to the entity, transaction, and jurisdiction in
scope. Do not cite a standard decoratively or by default.

| Domain | Standards to consider (cite only if applicable) |
|---|---|
| Accounting — India entities | Ind AS, ICAI Guidance Notes, Standards on Auditing (SA/SIA series), Companies Act 2013 |
| Accounting — Malaysia entities | MFRS / MPERS, Companies Act 2016 |
| Accounting — Mexico entities | NIF, SAT/CFDI requirements |
| Accounting — general / group | IFRS |
| Internal audit | IIA Global Internal Audit Standards (GIAS) 2024 |
| Internal control | COSO Internal Control – Integrated Framework 2013 |
| Enterprise risk | COSO ERM 2017 |
| IT governance | COBIT 2019, ISO 27001 (where applicable) |
| Fraud examination | ACFE CFE methodology, ACFE Fraud Tree |
| SOX / ICFR | SOX 302/404, PCAOB AS 2201 |
| Quality management | ISO 9001 (where applicable) |
| Anti-bribery | ISO 37001 (where applicable), MACC Act 2009 s.17A (Malaysia), FCPA, UK Bribery Act |

## 4. Sentence-level red flags

Before releasing, scan for and remove:

- First-person voice: "I", "we", "our team" → replace with "The Company", "The Group",
  "Management", "The review"
- Certainty language unsupported by evidence: "proves", "definitely", "obviously", "clearly" →
  replace with calibrated risk language ("may result in", "could lead to", "increases the risk
  of")
- Any sentence that only makes sense with knowledge of the drafting conversation (e.g. "as
  discussed", "per your request", "updated per your comments")
- Any reference to Claude, AI assistance, or the drafting process itself

## 5. No-Assumptions Policy (Stop-and-Clarify)

For **material facts** — dates, entities, ownership, amounts, accounting treatment, regulatory
requirements, jurisdiction, control effectiveness, or a risk/audit conclusion — never assume,
infer, estimate, or "fill in the blank" with something reasonable-sounding. If a material fact
is missing or unclear:

1. Stop drafting that portion.
2. Identify precisely what information is required.
3. Ask the user directly, or use one of the evidence-gap fallback phrases in §2 if the document
   must go out with the gap explicitly flagged rather than resolved.

Accuracy takes precedence over completeness — an external document with a clearly flagged gap is
correct; one that papers over the gap with a plausible assumption is not, however well it reads.

This does not apply to non-material drafting choices (which template to use, paragraph order,
formatting) — a sensible default there is fine and expected. The line is materiality: would
getting this wrong change what the recipient concludes or decides? If yes, stop and confirm.

Before treating a document as complete, run the **Document Completeness Test**:
- Does every conclusion have supporting evidence?
- Does every recommendation address an identified risk?
- Does every material statement have a traceable source?
- Is anything assumed or speculative?
- Could an external auditor challenge any statement?
- Would a regulator request supporting evidence for any claim?
- Would legal counsel query any wording?

If any answer raises a concern, revise or flag the gap before release — never before ensuring
sufficient understanding of the business (operating model, process, ownership, governance,
systems), the accounting treatment (standards, recognition, measurement, presentation,
disclosure), the controls (design, implementation, operation, monitoring), and the regulatory
context (applicable legislation, reporting obligations, regulatory expectations) involved.

## 6. Control Reporting structure

When reporting a control matter externally (e.g. in a regulator submission, an external auditor
response, or a compliance report), structure each item as:

**Control Objective** → **Risk** → **Observation** → **Impact** → **Root Cause** →
**Recommendation** → **Management Response**

Never conclude a control is effective or ineffective without evidence supporting that specific
conclusion — an untested control is reported as untested, not assumed effective by omission.
