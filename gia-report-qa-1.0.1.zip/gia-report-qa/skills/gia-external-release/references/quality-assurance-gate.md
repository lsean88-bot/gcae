# Independent Quality Assurance Gate — Reference

Run this in addition to (not instead of) the Output Gate in SKILL.md. Four distinct passes —
each catches a different failure mode. Skipping one because another looks clean is the most
common way errors reach a regulator or external auditor.

## 1. Independent Quality Check

Re-read the finished document as a reviewer who did **not** draft it and has no memory of the
source material — not as a final skim of your own work.

- Does the conclusion in the opening paragraph match, word for figure, what the body actually
  supports? A summary that overstates or understates the detail is a defect even if every
  individual sentence is accurate.
- Would a second, independent CAE or audit partner sign this without requesting a single change?
  If any sentence would draw a query, resolve it before release, not after.
- Read the document once for structure only (do the sections follow logically, does anything
  needed to understand a later section appear later than it's needed) and once for content.
  These are different failure modes and a single read-through misses one of them.

## 2. Proofreading Pass

Mechanical, not substantive — but a regulator-facing document with a typo undermines the
credibility of everything correct around it.

- Spelling, grammar, and punctuation
- Consistent date format throughout (pick one: DD Month YYYY or the recipient's own convention —
  never mix formats in one document)
- Consistent number formatting (thousand separators, decimal places, currency symbol placement)
- Every acronym defined at first use, then used consistently — never redefined or abbreviated
  differently later in the same document
- Heading numbering and cross-references correct (a "see Section 4" that now points to Section 5
  after an edit is a defect)
- No leftover template brackets, placeholder text, or draft comments (see the Output Gate)

## 3. Internal Consistency Check

The single most common defect in multi-section documents: the same fact stated two different
ways in two different places.

- Every figure that appears more than once (a finding count, an exposure amount, a date, a
  compliance percentage) must be **identical** everywhere it appears — check the summary against
  the detail, and the detail against any appendix or table.
- A finding's severity/classification (e.g. material weakness vs. significant deficiency) must
  be labelled the same way everywhere it's referenced.
- Named individuals, titles, and entity names must be spelled and capitalised identically
  throughout — including across a document produced over multiple drafting sessions.
- If a number changed during drafting (a revised figure, a corrected date), search the whole
  document for the old value — it is easy to fix one instance and miss another.

## 4. Zero-Fabrication Check

This is the Iron Rule applied at the sentence level: before release, ask of every specific
number, date, name, or conclusion — *could I point to the exact source for this right now?*

- If yes: it stays, sourced as normal (see the Evidence standard in SKILL.md).
- If no: it does not go in the document. Use the fallback phrasing in
  `references/writing-standards.md` §2, or flag the gap to the user rather than filling it with
  a plausible-sounding number.
- This applies with equal force to figures carried over from a prior draft, a template, or an
  earlier conversation turn — a number's presence earlier in the drafting process is not itself
  a source; re-verify it traces to evidence before it appears in the final release.

## Sequence

Run these four passes in order — each depends on the document being stable from the pass
before it. Do not run the proofreading pass before the independent quality check has settled
the content; do not run the consistency check before proofreading has fixed obvious errors that
would otherwise be mistaken for consistency defects.
