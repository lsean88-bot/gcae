# Disclosure Governance — What Belongs in an External Document

## Contents
- The caution that overrides everything below
- Core principle
- Five non-negotiable principles
- Information boundary — three tiers
- Escalation Rule — hard stop, not a judgement call
- Three tests to run before including anything
- Drafting hierarchy
- The 10 disclosure questions — final check before release
- Governing maxim


Governs *inclusion*, not wording — a companion to `writing-standards.md` (which governs voice)
and `quality-assurance-gate.md` (which governs accuracy). This file governs the separate
question: of everything that is true and evidenced, how much of it should actually appear in a
document leaving the organisation.

## The caution that overrides everything below

**Minimising disclosure is never a basis for omitting a material fact, concealing a deficiency,
or preventing a legitimate inquiry.** Every principle in this file is about cutting unnecessary
narrative and internal process detail — never about softening, hiding, or thinning out something
the recipient is legally, contractually, or professionally entitled to know. If a "less is more"
instinct and a material fact are ever in tension, the fact wins, every time.

## Core principle

An external report contains only what is: relevant to the report's purpose, factually accurate
and evidenced, sufficient to meet the applicable regulatory/contractual/audit/legal requirement,
and appropriate for external distribution. Information outside the reporting objective does not
belong in the document merely because it provides context.

## Five non-negotiable principles

1. **Truth cannot be compromised** — every statement factually accurate, objectively supportable,
   verifiable, free from speculation, assumption, and exaggeration. Never overstate, understate,
   speculate, estimate without disclosing that it's an estimate, or omit a material qualifying
   fact.
2. **Never mislead** — a report misleads not only by stating something false, but by omitting
   material information, presenting information out of context, or selectively presenting
   favourable evidence.
3. **Minimum necessary disclosure** — the recipient gets what they need, not everything that
   exists. Each disclosure should be relevant, proportionate, sufficient, necessary.
4. **Purpose determines disclosure** — every document has a defined objective (regulatory
   filing, audit evidence, certification, customer assurance, lender due diligence); only
   information that advances that objective belongs in it. Everything else stays internal unless
   a legal or contractual obligation requires disclosure.
5. **Internal deliberation is not external evidence** — internal debates, differing opinions,
   meeting conversations, brainstorming, and draft conclusions are governance process, not the
   organisation's final position. The external document represents the final, approved position
   only.

## Information boundary — three tiers

| Tier | Examples |
|---|---|
| **Always appropriate** | Approved policies and procedures, official records, signed documents, final reports, contracts, financial records, objective evidence |
| **Usually internal** | Draft reports, working papers, reviewer comments, internal emails/Teams/chat, meeting notes, brainstorming, planning documents, audit planning, risk assessments, draft findings, version history |
| **Highly protected** | Privileged legal advice, legal strategy, investigation techniques, whistleblower identities, fraud detection methodology, cybersecurity architecture, proprietary algorithms, internal audit methodology, quality review notes, reviewer annotations |

Never volunteer, from the "highly protected" tier or otherwise: internal risk scoring, internal
thresholds, investigation methodology, audit strategy, sampling rationale beyond what's
necessary, monitoring/detection logic, or fraud analytics methodology — these are internal
governance assets, not external evidence, unless disclosure is specifically required.

## Escalation Rule — hard stop, not a judgement call

If drafting touches any of the following, **stop drafting that portion and flag it to the user**
for legal or authorised management review before proceeding — do not attempt to resolve it by
choosing cautious wording:

- Legal privilege or legal strategy
- An active investigation
- A disciplinary matter
- A fraud inquiry
- Pending or threatened litigation
- M&A activity
- Pricing strategy
- Intellectual property
- Cybersecurity architecture/controls
- Confidential third-party information

This is the same category of hard stop as the No-Assumptions Policy in `writing-standards.md` —
it is not resolved by drafting more carefully, only by the right person confirming what may be
disclosed.

## Three tests to run before including anything

- **External Reader Test** — would an independent external reader need this to understand the
  finding, evaluate the conclusion, verify compliance, or exercise their statutory function? If
  not, it probably belongs in internal files.
- **Newspaper Test** — if this paragraph appeared publicly tomorrow, would it unnecessarily
  expose internal operations, strategy, or confidential methods without adding value to the
  report? If yes, reconsider whether it belongs.
- **Permanence Rule** — assume every external document may be discoverable in litigation,
  reviewed by a regulator, shared with a future auditor, or read years later without the context
  this conversation provides. Write accordingly — nothing in it should rely on shared context
  that won't travel with the document.

## Drafting hierarchy

Every paragraph follows: **Fact → Evidence → Impact → Conclusion → Required Action.**
Never: Opinion → Explanation → Internal history → Discussion → Conclusion.

## The 10 disclosure questions — final check before release

1. Is this factually accurate?
2. Is it supported by evidence?
3. Is it relevant to the report's purpose?
4. Is it required by law, regulation, contract, or professional standard?
5. Would omitting it make the report materially misleading?
6. Does it reveal confidential or proprietary information unnecessarily?
7. Does it disclose internal deliberation rather than the final conclusion?
8. Is the level of detail proportionate to the recipient's legitimate need?
9. Could the same point be made more clearly and concisely without losing material information?
10. Has it been checked for consistency with the organisation's approved position and any
    confidentiality obligations?

## Governing maxim

Disclose what is required. Protect what is entrusted. Withhold nothing material. Volunteer
nothing unnecessary. Every statement must be accurate, supportable, relevant, proportionate, and
appropriate to the recipient's lawful purpose.
