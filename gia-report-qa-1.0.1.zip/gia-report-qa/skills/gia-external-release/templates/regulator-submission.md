# Template — Regulator Submission / Statutory Filing

Use for a formal submission or response to a regulator or statutory authority. Adapt headings to
the specific authority's own required format where one is prescribed — a prescribed regulatory
format always takes precedence over this generic skeleton.

```
[Company Letterhead / Registered Name]
[Registration No. / Reference No.]

[Date]

[Name of Regulator / Authority]
[Address]

Attention: [Named officer, if known]

Subject: [Precise subject line matching the regulator's own reference, if any]
Reference: [Regulator's file/case reference number, if applicable]

Dear Sir / Madam,

1. INTRODUCTION
   [Purpose of this submission. Cite the specific regulatory requirement, notice, or request
    that this document responds to.]

2. BACKGROUND
   [Factual context only — dates, entities involved, relevant prior correspondence by reference
    number.]

3. RESPONSE / SUBMISSION
   [The substantive content, organised by the regulator's own numbered questions or requirements
    where applicable. Each point supported by evidence, data, or a labelled management
    representation.]

4. SUPPORTING DOCUMENTATION
   [List of enclosures/attachments, each with a clear reference.]

5. CONCLUSION
   [A concise closing statement. Confirmation of compliance status where applicable. Contact
    point for further queries.]

Yours faithfully,

[Name]
[Title — e.g. Group Chief Audit Executive]
[Company]
[Contact details]
```

## Notes for this template
- Match the regulator's own required structure and terminology exactly where one is prescribed
  (e.g. a specific form, portal template, or statutory notice format).
- Every factual assertion must trace to evidence or a labelled management representation — see
  `../references/writing-standards.md` §2 for fallback phrasing when evidence is incomplete.
- Do not editorialise on the regulatory requirement itself; state facts and compliance status
  only.
