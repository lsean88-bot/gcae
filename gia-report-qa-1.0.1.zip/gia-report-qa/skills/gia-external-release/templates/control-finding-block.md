# Template Block — Control Reporting

A reusable block for reporting a single control matter within any of the other templates (a
regulator submission, an external auditor response, or a statutory compliance report). Repeat
one block per control matter.

```
Control Objective: [What the control is meant to achieve]

Risk: [What could go wrong in the absence of an effective control]

Observation: [What was observed — factual, evidenced, no interpretation]

Impact: [The actual or potential effect, stated with calibrated risk language —
         "may result in...", "could lead to...", never "definitely" or "clearly" without
         evidence]

Root Cause: [Why the control gap exists — evidenced, not assumed]

Recommendation: [Specific, practical, proportionate, cost-conscious]

Management Response: [Management's own words or a clearly labelled representation —
                       never paraphrased into a stronger or weaker commitment than given]
```

## Notes for this block
- Never conclude a control is "effective" or "ineffective" without evidence supporting that
  specific conclusion for that specific control — an untested control is reported as untested.
- Root Cause must be evidenced (a process gap, a system limitation, a training gap) — never a
  plausible-sounding guess. If the root cause has not been established, say so rather than
  inventing one.
- Management Response is reported as given — do not soften a disagreement or strengthen a
  commitment when transcribing it into the document.
