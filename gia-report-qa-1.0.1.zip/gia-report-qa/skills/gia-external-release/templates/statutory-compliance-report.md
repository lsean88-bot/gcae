# Template — Statutory Compliance Report / Independent Reviewer Response

Use for a compliance attestation, certification submission, or a response to an independent
reviewer / certifying body (e.g. a licensing body, accreditation reviewer, or third-party
assurance provider).

```
[Company Letterhead]

STATUTORY COMPLIANCE REPORT / INDEPENDENT REVIEW RESPONSE

Company / Entity: [Legal name]
Reporting Period: [Period]
Prepared for: [Regulator / certifying body / independent reviewer name]
Date: [Date]
Reference: [Their reference number, if applicable]

1. EXECUTIVE SUMMARY
   [One paragraph — the compliance status or review outcome being reported, stated factually.]

2. SCOPE
   [What this report covers, and — where relevant — what it does not cover.]

3. BASIS OF PREPARATION
   [The applicable regulation, standard, or licensing condition this report responds to.]

4. FINDINGS / COMPLIANCE STATUS
   [Organised by requirement or clause. For each: the requirement, the Company's position, and
    the supporting evidence.]

   | Requirement Ref. | Requirement | Compliance Status | Evidence |
   |---|---|---|---|
   | [Ref] | [Requirement text] | [Compliant / Non-compliant / Partially compliant] | [Evidence reference] |

5. CORRECTIVE ACTIONS (where applicable)
   [Only for items reported as non-compliant or partially compliant. Action, owner, target date.]

6. CONCLUSION
   [Concise statement of overall compliance status.]

[Signed]
[Name] | [Title] | [Company]
```

## Notes for this template
- "Compliance Status" values must be evidenced, not asserted — see
  `../references/writing-standards.md` §2 for phrasing when evidence is incomplete.
- Do not use colour-coded traffic-light icons in a document destined for regulatory or
  certification file records unless the recipient's own template specifies them; use the plain
  status wording in the table instead.
