# Template — Investor / Lender Report

Use for periodic reporting or covenant-compliance reporting to investors, shareholders, or
lenders. Adapt to any prescribed format set out in the investment/loan agreement — a prescribed
format always takes precedence over this generic skeleton.

```
[Company Letterhead]

[Report Title — e.g. "Quarterly Compliance Report" / "Covenant Compliance Certificate"]

Prepared for: [Investor / Lender name]
Reporting Period: [Period]
Date: [Date]
Reference: [Facility/agreement reference, if applicable]

1. SUMMARY
   [Factual summary of the period's key financial and operational metrics relevant to the
    recipient's reporting requirements.]

2. FINANCIAL PERFORMANCE
   [Key figures, with source (e.g. "per management accounts for the period ended [date]").]

3. COVENANT COMPLIANCE (where applicable)
   | Covenant | Required Threshold | Actual | Status |
   |---|---|---|---|
   | [Covenant name] | [Threshold] | [Actual figure] | [Compliant / Breach] |

4. MATERIAL DEVELOPMENTS
   [Factual disclosure of any material events during the period, per the reporting/disclosure
    obligations in the governing agreement.]

5. CERTIFICATION
   [Where the agreement requires officer certification: "The undersigned certifies that the
    information contained in this report is true and accurate to the best of their knowledge."]

[Signed]
[Name] | [Title, e.g. CFO] | [Company]
```

## Notes for this template
- Financial figures must trace to the management accounts, GL, or audited financial statements —
  never estimated or rounded beyond what the source supports.
- A covenant breach is reported factually, without minimising or defensive language — state the
  breach, the cause (if known and evidenced), and any remediation already agreed with the
  lender/investor.
