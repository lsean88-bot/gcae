# Template — External Auditor Response / Management Representation Letter

Two common shapes are covered below. Use whichever matches the external auditor's request.

## A. Response to an external auditor query / PBC request

```
[Company Letterhead]

[Date]

[External Audit Firm]
Attention: [Engagement Partner / Manager]

Subject: Response to Query Ref. [Auditor's reference] — [Topic]

Dear [Name],

1. QUERY
   [Restate the auditor's question precisely, or reference their query letter/PBC item number.]

2. RESPONSE
   [Factual answer, supported by evidence. State the source of each figure or fact (e.g. "per
    the general ledger extract dated [date]", "per management representation").]

3. SUPPORTING EVIDENCE
   [List of documents provided in support, cross-referenced to the response above.]

4. ADDITIONAL COMMENTS
   [Only if necessary — factual, not defensive.]

Yours faithfully,
[Name] | [Title] | [Company]
```

## B. Management Representation Letter

```
[Company Letterhead]

[Date]

[External Audit Firm]

Dear [Name],

This representation letter is provided in connection with your audit of the financial statements
of [Company] for the year/period ended [date], for the purpose of expressing an opinion as to
whether the financial statements give a true and fair view in accordance with [applicable
accounting framework, e.g. Ind AS / MFRS / IFRS].

We confirm, to the best of our knowledge and belief, the following representations made to you
during your audit:

1. FINANCIAL STATEMENTS
   - We have fulfilled our responsibilities for the preparation of the financial statements in
     accordance with [framework], as set out in [engagement letter reference].
   - [Standard representations: going concern, related party transactions, fraud and error,
     laws and regulations, subsequent events, completeness of information — include only those
     applicable and evidenced.]

2. INFORMATION PROVIDED
   - We have provided you with access to all information of which we are aware that is relevant
     to the preparation of the financial statements.
   - We have provided you with unrestricted access to persons within the entity from whom you
     determined it necessary to obtain audit evidence.

3. COMPLETENESS OF TRANSACTIONS
   - All transactions have been recorded and are reflected in the financial statements.

[Signed on behalf of the Company]
[Name] | [Title, e.g. CFO / CEO] | [Date]
```

## Notes for this template
- The representation letter is signed by Management (typically CEO/CFO), not by Internal Audit —
  Internal Audit may draft it, but the final document must reflect the signing authority.
- Include only representations that are true, evidenced, and within the signer's knowledge —
  never a representation the Company cannot support.
- See `../references/writing-standards.md` §3 for the accounting/auditing framework citation
  table.
