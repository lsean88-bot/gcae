---
name: gia-board-brief
description: "Plain-language, evidence-traceable briefs for the Chairman, Audit Committee and directors: one-finding briefing, director summary, one-page decision brief, eight-slide outline, quarterly AC pack. Use when you need to make a finding Board-ready, write an AC paper or apply escalation thresholds. Do NOT use for a full IA report (use gia-report-qa:gia-ia-report)."
---

# GIA Board Brief

Internal audit is a strategic assurance and business-improvement function. Every brief answers one question: what does this mean for the business, and what should the reader do about it? The reader's reaction ("I am glad audit found this") is earned by accuracy, not tone. Value positioning never overrides evidence: if audit cannot show what it protected, say what it surfaced and leave the benefit for management to confirm.

Default register is evidence-calibrated and balanced: plain language, no alarm boxes, no emoji, no softening of Critical or fraud-related matters. Rule and gate citations: `gia-core:iron-rules`. Disclosure depth by audience: `gia-report-qa:gia-disclosure-calibration`.

## Step 0: choose the mode

| Wants | Mode | Output |
|---|---|---|
| One finding explained to the Chairman or AC (default) | A. Chairman Briefing | Seven sections + two control blocks |
| Compact Board-pack entry from an approved finding sheet | B. Director Issue Summary | Eight elements |
| Several findings in one page for CEO, CFO or Board | C. Leadership Decision Brief | `references/leadership-decision-brief.md`; at most five themes |
| Presentation or dashboard for executives | D. Executive outline | Same reference; build via `gia-report-qa:gia-presentation` |
| Quarterly Audit Committee pack | E. AC pack | `references/ac-pack-and-escalation.md` |

If ambiguous, use Mode A and say in one line which mode was chosen. A and B give one output per finding. C and D group into at most five business themes.

## Step 1: basis, audience, evidence

Under the title state the basis: `Basis: auditor-approved finding sheet [FIND-###]` or `Basis: draft finding, not yet approved; auditor validation required before Board use.` Never assign, raise or lower a rating; use the rating supplied. Rating appears as text (High, Medium, Low) in the header line.

Audience A (Board, AC, directors): strategic implication, exposure, governance, decision. Audience B (CEO, CFO, plant head): cash, margin, delivery, quality, safety, continuity. Process owners and the audit team are the wrong audience; use `gia-report-qa:gia-evidence-trace`.

Evidence references on material statements, e.g. `[FIND-P2P-03; WP-P2P-07; EV-021 to EV-024]` (`references/traceability-in-prose.md`).
1. Never invent an ID. If none is supplied: "Evidence reference not available; auditor validation required."
2. Label management statements as such: "Management representation, not independently verified [MR-###]". MR means management response; a representation is labelled in the text.
3. Declare a missing-reference gap once under the Basis line; do not repeat it under every paragraph.
4. Declaring a gap licenses no new fact: every figure, date, amount, cause or benefit comes from the source finding; any inference is marked in the sentence.
Grade source evidence R1-R5; classify statements with Rule 37 classes; other label schemes map via the evidence-label-map reference of `gia-report-qa:gia-evidence-trace`.

## Mode A: seven sections, then two control blocks

1. Issue summary (2-3 sentences): what was observed, tied to money, people, customers, regulators or strategy.
2. What should have happened: the requirement in business language with the approved criterion `[CRIT-###]`. Statutory timings and rates come from the finding or the dated statutory register; if currency is uncertain, say validation is needed.
3. Business value at stake: the two or three most material dimensions (`references/risk-dimension-guide.md`). Evidenced impact separate from potential impact; unquantified = "Potential impact not quantified; management validation required". Add "Addressing this will ..." only if the source states a benefit or agreed action; otherwise "Expected benefit not stated in the source."
4. Risk if not addressed: realistic downside, timeline, consequence; recurring or previously reported status; what the Board implicitly accepts by only noting it.
5. Root cause (one paragraph): the approved cause, or "Root cause not established." Isolated or systemic only if the finding supports it. A proposed cause analysis is marked "Proposed (not from the finding)".
6. Internal audit's position: what the finding lets the business protect; position Open / Retained / Escalated / Closed and next step. Counterfactuals are audit judgement and labelled so; never claim loss avoided unless quantified.
7. Board-level message (4-6 sentences of prose, no tags): balanced, states seriousness and the decision or oversight needed, calls for management accountability without blaming individuals; every claim already tagged in sections 1-6.

Control block 1 Decision and accountability: priority (approved rating), management action (owner role, action, date), expected benefit (or "to be confirmed by management during action planning"), decision required (approve, fund, prioritise, accept risk, escalate, monitor, or "None, for noting").
Control block 2 Assurance trail: `Finding | Workpapers | Evidence | Criteria | Management response | Open evidence gaps`; "not supplied" in any empty slot.

## Mode B: Director Issue Summary

Translation from an approved finding sheet, not re-analysis. Do not change approved facts, rating, criteria, sample result, cause, impact, recommendation, owner, date or references; add no loss, penalty, fraud, legal conclusion, cause or benefit the finding lacks. Eight elements: business message; why it matters; what the audit found (extent, period); impact split into supported and potential; what management should do; expected benefit; decision or oversight required; assurance references. The check that nothing approved was changed is made in the QA log or chat reply and is not written into the deliverable (Profile B files carry no declarations; `profile_b_lint.py` flags them).

## Mode C/D: leadership brief and outline

Run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-board-brief/scripts/brief_data.py --register R.xlsx --md facts.md --json facts.json` first and write from its output (approved fields verbatim, overdue flags, TO BE DECIDED items). Group into at most five themes (a theme needs at least two approved findings). State the assurance boundary: sample, period, scope, open evidence gaps. Show what works only where a workpaper supports it. Run `scripts/jargon_scan.py` on the draft. Dashboard views: `references/executive-dashboard-views.md`.

## Writing rules

Plain English, short sentences, active voice. Define or drop acronyms (`references/jargon-translation.md`). Translate numbers into meaning; currency conversions only with a sourced rate and date. Quantify only what the evidence supports; never extend a sample to the population. Name what is working where evidenced. Do not dramatise low findings or soften critical or fraud-related ones: separate a control gap from evidence of misconduct and use "cannot rule out" and "warrants investigation" (ladder wording per `gia-fraud:gia-fraud-investigation`; never motive). Never state allegations, explanations or inferences as fact. Internal CAE challenge notes never appear in an issued Board or AC file. AI-assistance banners are not used; issued files carry no AI metadata, change history or comments.

## Before issue

Self-check: mode chosen; basis present; rating from source; references present or gap declared once; no invented ID; management assertions labelled; impact split; no unexplained jargon; section 7 is prose; both control blocks complete; positives included where evidenced. Then hand to `gia-report-qa:gia-report-qa` for the Quality Gate, lint and independent read. Tone calibration: `references/tone-examples.md` (facts illustrative only).

## References

| File | Read when |
|---|---|
| `references/traceability-in-prose.md` | Citing references; labels; worked examples |
| `references/jargon-translation.md` | Translating terms; rewriting weak recommendations |
| `references/leadership-decision-brief.md` | Modes C and D |
| `references/executive-dashboard-views.md` | Five dashboard views |
| `references/risk-dimension-guide.md` | Value dimensions; section 6 positioning |
| `references/tone-examples.md` | Tone calibration |
| `references/ac-pack-and-escalation.md` | AC pack, assurance statement, escalation thresholds |
