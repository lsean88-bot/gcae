#!/usr/bin/env python3
"""Flag audit/finance jargon that a director would have to ask about.

Usage:
    python3 jargon_scan.py report.md|report.docx|report.txt [--json out.json] [--max-words 35]
                           [--extra "term one" "term two"]

Heuristic, by design. It reports a term as UNEXPLAINED when it appears with no explanatory cue
in the same sentence (a "means" / "that is" / "i.e." / "in plain terms" phrase, or an
immediately following parenthesis). A flagged term is a prompt for a human to rewrite or
define; an unflagged term is not proof the sentence is clear. Long sentences are reported
because the plain-language standard asks for short sentences.

Exit code is always 0 (advisory); read the output.
"""
import argparse
import json
import re
import sys

# Case-insensitive phrases (from the plain-language rules and the jargon translation guide)
PHRASES = [
    "control deficiency", "control operating effectiveness", "operating effectiveness",
    "residual risk", "inherent risk", "population completeness", "exception rate",
    "design deficiency", "key control", "segregation of duties", "material weakness",
    "non-compliance", "noncompliance", "maker-checker", "compensating control",
    "detective control", "preventive control", "walkthrough", "substantive testing",
    "scope limitation", "three-way match", "control environment", "sampling risk",
    "control gap", "control failure", "control weakness", "audit trail",
    "root cause analysis", "management override", "tone at the top",
]
# Case-sensitive acronyms (whole word)
ACRONYMS = ["ToD", "ToE", "RACM", "RCM", "COSO", "ITGC", "SoD", "CAPA", "KYC", "ABAC",
            "ICFR", "SOX", "GIAS", "IPPF", "CFE", "KRI", "KPI", "SLA", "RPA"]

CUE_RE = re.compile(
    r"\b(means|meaning|that is|i\.e\.|in plain (?:terms|english|words)|in other words|"
    r"which is|refers to|defined as|for example|put simply|simply put)\b", re.I)
SENT_SPLIT = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9\"'(\[])|\n+")


def read_text(path):
    if path.lower().endswith(".docx"):
        import docx
        d = docx.Document(path)
        parts = [p.text for p in d.paragraphs]
        for t in d.tables:
            for row in t.rows:
                parts.append(" | ".join(c.text for c in row.cells))
        return "\n".join(parts)
    with open(path, encoding="utf-8") as fh:
        return fh.read()


def scan(text, extra=(), max_words=35):
    phrases = [p.lower() for p in PHRASES] + [e.lower() for e in extra]
    sentences = [s.strip() for s in SENT_SPLIT.split(text) if s and s.strip()]
    hits, long_sents = [], []
    for s in sentences:
        low = s.lower()
        explained_cue = bool(CUE_RE.search(s))
        for term in phrases:
            for m in re.finditer(rf"(?<![\w-]){re.escape(term)}(?![\w-])", low):
                after = s[m.end(): m.end() + 3]
                paren = after.lstrip().startswith("(")
                hits.append({"term": term, "explained": explained_cue or paren, "sentence": s[:220]})
        for ac in ACRONYMS:
            for m in re.finditer(rf"(?<![\w-]){re.escape(ac)}(?![\w-])", s):
                # acronym is explained if it follows its expansion "(ToD)" or is followed by "(...)"
                before = s[max(0, m.start() - 1): m.start()]
                after = s[m.end(): m.end() + 2]
                explained = before == "(" or after.lstrip().startswith("(") or explained_cue
                hits.append({"term": ac, "explained": explained, "sentence": s[:220]})
        n = len(s.split())
        if n > max_words:
            long_sents.append({"words": n, "sentence": s[:160] + ("..." if len(s) > 160 else "")})
    return hits, long_sents


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("file")
    ap.add_argument("--json")
    ap.add_argument("--max-words", type=int, default=35)
    ap.add_argument("--extra", nargs="*", default=[])
    a = ap.parse_args()
    hits, long_sents = scan(read_text(a.file), a.extra, a.max_words)
    unexplained = [h for h in hits if not h["explained"]]
    for h in unexplained:
        print(f"UNEXPLAINED  '{h['term']}': {h['sentence']}")
    for ls in long_sents:
        print(f"LONG ({ls['words']} words): {ls['sentence']}")
    print(f"\nSummary: {len(unexplained)} unexplained term occurrence(s); "
          f"{len(hits) - len(unexplained)} term(s) with an explanation cue; {len(long_sents)} long sentence(s). "
          "Heuristic: review, do not treat as pass/fail.")
    if a.json:
        with open(a.json, "w") as fh:
            json.dump({"unexplained": unexplained, "explained": [h for h in hits if h["explained"]],
                       "long_sentences": long_sents}, fh, indent=2)


if __name__ == "__main__":
    main()
    sys.exit(0)
