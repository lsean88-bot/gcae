#!/usr/bin/env python3
"""Extract the approved facts for a Leadership Decision Brief from the register.

Usage:
    python3 brief_data.py --register Register.xlsx [--md out.md] [--json out.json] [--today YYYY-MM-DD]

Why this exists: executive reports go wrong when wording is written from memory or from a draft.
This script copies the approved fields VERBATIM from the register so the brief is written from
them. It only includes findings whose Approval status is Auditor-approved or CAE-approved, and it
lists every finding it left out with the reason. It does not group findings into themes, assign
sponsors, or write decisions: those are judgement calls for the auditor, so they are left as
explicit placeholders.
"""
import argparse
import datetime as dt
import difflib
import json
import os
import re
import sys

try:
    from openpyxl import load_workbook
except ImportError:
    sys.exit("openpyxl is not installed (pip install openpyxl)")

APPROVED = {"Auditor-approved", "CAE-approved"}
FIND_STATUSES = ("Draft", "Auditor-approved", "CAE-approved", "Withdrawn")
ACT_STATUSES = ("Not started", "In progress", "Delayed", "Closed - pending validation",
                "Closed - validated", "Closed - not effective", "Risk accepted")
# Same ID grammar as trace_check.py (tests/selftest.py asserts the two extract identically).
TYPES = ("EV", "CRIT", "PROC", "WP", "EXC", "FIND", "MR", "CE", "GAP", "ACT")
_T = "|".join(TYPES)
ID_RE = re.compile(rf"\b(?P<t>{_T})-(?:(?P<a>[A-Z][A-Z0-9]{{1,5}})-)?(?P<n>\d{{2,4}})(?P<s>[a-z]?)\b")
RANGE_RE = re.compile(
    rf"\b(?P<t>{_T})-(?:(?P<a>[A-Z][A-Z0-9]{{1,5}})-)?(?P<n1>\d{{2,4}})\s*"
    rf"(?:(?:to|–|—)\s*(?P=t)-(?:(?P=a)-)?(?P<n2>\d{{2,4}})|[–—]\s*(?P<n2b>\d{{2,4}})(?!\s+[A-Za-z]))\b")


def extract_ids(text):
    if not text:
        return []
    text = str(text)
    out, spans = [], []

    def canon(t, a, n, sfx=""):
        return f"{t}-{a + '-' if a else ''}{n}{sfx}"
    for m in RANGE_RE.finditer(text):
        n1, n2 = m.group("n1"), (m.group("n2") or m.group("n2b"))
        lo, hi = int(n1), int(n2)
        spans.append(m.span())
        if lo <= hi and hi - lo <= 200:
            out += [canon(m.group("t"), m.group("a"), str(k).zfill(len(n1))) for k in range(lo, hi + 1)]
        else:
            out += [canon(m.group("t"), m.group("a"), n1), canon(m.group("t"), m.group("a"), n2)]
    for m in ID_RE.finditer(text):
        if any(a <= m.start() < b for a, b in spans):
            continue
        out.append(canon(m.group("t"), m.group("a"), m.group("n"), m.group("s")))
    return out


def near(value, vocab):
    m = difflib.get_close_matches(value.casefold(), [v.casefold() for v in vocab], n=1, cutoff=0.7)
    return next((v for v in vocab if v.casefold() == m[0]), None) if m else None
RANK = {"Critical": 0, "High": 1, "Medium": 2, "Low": 3}

FIND_COLS = {"id": "FIND ID", "title": "Business-language title", "audit_title": "Title",
             "condition": "Condition", "crit": "CRIT IDs", "wp": "WP IDs", "ev": "EV IDs",
             "cause": "Approved cause", "evidenced": "Evidenced impact", "potential": "Potential impact",
             "rating": "Rating", "status": "Approval status", "approver": "Approved by",
             "approved_on": "Approved on", "owner": "Owner", "target": "Target date"}
ACT_COLS = {"id": "ACT ID", "find": "FIND ID", "action": "Action", "owner": "Owner",
            "target": "Target date", "status": "Status", "benefit": "Benefit measure",
            "validated": "Validated (Y/N)", "vwp": "Validation WP ID",
            "ra_by": "Risk accepted by", "ra_on": "Risk accepted on"}
GAP_COLS = {"id": "Item ID", "type": "Type", "wp": "WP ID", "desc": "Description", "status": "Status"}


def rows(wb, sheet, cols):
    if sheet not in wb.sheetnames:
        sys.exit(f"sheet '{sheet}' not found: is this an Assurance Trace Register?")
    ws = wb[sheet]
    hdr = {str(c.value).strip(): i for i, c in enumerate(ws[1]) if c.value is not None}
    missing = [h for h in cols.values() if h not in hdr]
    if missing:
        sys.exit(f"{sheet}: column(s) not found: {', '.join(missing)}")
    out = []
    for r in range(2, ws.max_row + 1):
        rec = {k: ws.cell(r, hdr[h] + 1).value for k, h in cols.items()}
        if rec["id"] in (None, ""):
            continue
        out.append(rec)
    return out


def fmt(v):
    if v is None or str(v).strip() == "":
        return None
    if isinstance(v, (dt.date, dt.datetime)):
        return v.strftime("%Y-%m-%d")
    return str(v).strip()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--register", required=True)
    ap.add_argument("--md")
    ap.add_argument("--json")
    ap.add_argument("--today", help="override today's date (YYYY-MM-DD), mainly for tests")
    a = ap.parse_args()
    today = dt.date.fromisoformat(a.today) if a.today else dt.date.today()

    if not os.path.isfile(a.register):
        print(f"cannot run: register not found: {a.register}", file=sys.stderr)
        sys.exit(2)
    try:
        wb = load_workbook(a.register)
    except Exception as e:
        print(f"cannot run: '{a.register}' could not be opened as an .xlsx register ({e.__class__.__name__}: {e})", file=sys.stderr)
        sys.exit(2)
    warnings = []
    findings = rows(wb, "Findings", FIND_COLS)
    actions = rows(wb, "Actions", ACT_COLS)
    gaps = rows(wb, "Exceptions_Gaps", GAP_COLS)

    included, excluded = [], []
    for f in findings:
        status = fmt(f["status"]) or "blank"
        if status in APPROVED:
            included.append(f)
            if not fmt(f["approver"]) or not fmt(f["approved_on"]):
                warnings.append(f"{f['id']}: approved but approver or approval date is blank: run trace_check (R06) before issuing")
            rv = fmt(f["rating"])
            if rv and rv.casefold() not in {r.casefold() for r in RANK}:
                warnings.append(f"{f['id']}: rating '{rv}' is not Critical/High/Medium/Low, so it is not counted as High/Critical")
        else:
            reason = f"status is '{status}'"
            if status not in FIND_STATUSES:
                hint = near(status, FIND_STATUSES) if status != "blank" else None
                reason += (" (not a recognised status" + (f"; did you mean '{hint}'?" if hint else "")
                           + "; NOT included: correct the register if this finding is approved)")
                warnings.append(f"{f['id']}: approval status '{status}' is not recognised, so the finding was left out")
            excluded.append({"id": f["id"], "reason": reason})
    included.sort(key=lambda f: (RANK.get((fmt(f["rating"]) or "").title(), 9), str(fmt(f["target"]) or "9999")))

    def as_date(v):
        if isinstance(v, dt.datetime):
            return v.date()
        return v if isinstance(v, dt.date) else None

    out_findings = []
    for f in included:
        fa = [x for x in actions if str(x["find"]).strip() == str(f["id"]).strip()]
        acts = []
        for x in fa:
            due = as_date(x["target"])
            st = fmt(x["status"]) or "not recorded"
            yn = (fmt(x["validated"]) or "").upper()
            if st not in ACT_STATUSES and st != "not recorded":
                hint = near(st, ACT_STATUSES)
                flag = f"Status not recognised: {st!r}" + (f" (did you mean '{hint}'?)" if hint else "") + ": do not report as closed"
                warnings.append(f"{x['id']}: action status '{st}' is not one of the seven defined statuses")
            elif st == "Closed - validated" and not extract_ids(x["vwp"]):
                flag = "Marked validated but NO validation workpaper recorded: do not report as validated"
                warnings.append(f"{x['id']}: 'Closed - validated' with no validation workpaper")
            elif st == "Closed - validated" and yn == "N":
                flag = "Status says validated but 'Validated (Y/N)' says N: resolve before reporting"
                warnings.append(f"{x['id']}: status/validated flag disagree")
            elif st == "Closed - validated":
                flag = "Closed and validated"
            elif st == "Risk accepted":
                if fmt(x["ra_by"]) and fmt(x["ra_on"]):
                    flag = f"Risk accepted by {fmt(x['ra_by'])} on {fmt(x['ra_on'])}"
                else:
                    flag = "Risk accepted but accepting authority or date is blank: do not report as accepted"
                    warnings.append(f"{x['id']}: 'Risk accepted' with no accepting authority or date")
            elif due is None and fmt(x["target"]):
                flag = f"Due date not machine-readable: '{fmt(x['target'])}'"
                warnings.append(f"{x['id']}: target date '{fmt(x['target'])}' is text, not a date")
            elif due is None:
                flag = "No due date recorded"
            elif due < today:
                flag = "OVERDUE"
            elif (due - today).days <= 30:
                flag = "Due within 30 days"
            else:
                flag = "On track by date"
            acts.append({"id": x["id"], "action": fmt(x["action"]), "owner": fmt(x["owner"]),
                         "target": fmt(x["target"]), "status": st, "flag": flag,
                         "benefit_measure": fmt(x["benefit"])})
        wp_ids = set(extract_ids(f["wp"]))
        open_gaps = [g["id"] for g in gaps
                     if str(g["type"]).strip().upper() in ("GAP", "CE") and str(g["status"]).strip().casefold() == "open"
                     and wp_ids & set(extract_ids(g["wp"]))]
        out_findings.append({
            "id": f["id"], "business_title": fmt(f["title"]), "audit_title": fmt(f["audit_title"]),
            "rating": fmt(f["rating"]), "status": fmt(f["status"]),
            "approved_by": fmt(f["approver"]), "approved_on": fmt(f["approved_on"]),
            "condition": fmt(f["condition"]), "cause": fmt(f["cause"]),
            "evidenced_impact": fmt(f["evidenced"]), "potential_impact": fmt(f["potential"]),
            "owner": fmt(f["owner"]), "target": fmt(f["target"]),
            "refs": {"crit": fmt(f["crit"]), "wp": fmt(f["wp"]), "ev": fmt(f["ev"])},
            "open_evidence_gaps": open_gaps, "actions": acts})

    all_acts = [a_ for f in out_findings for a_ in f["actions"]]
    summary = {
        "as_of": today.isoformat(),
        "approved_findings": len(out_findings),
        "high_or_critical": sum(1 for f in out_findings if (f["rating"] or "").casefold() in ("high", "critical")),
        "actions_total": len(all_acts),
        "actions_overdue": sum(1 for x in all_acts if x["flag"] == "OVERDUE"),
        "actions_due_30d": sum(1 for x in all_acts if x["flag"] == "Due within 30 days"),
        "actions_closed_validated": sum(1 for x in all_acts if x["flag"] == "Closed and validated"),
        "actions_needing_data_fix": sum(1 for x in all_acts if x["flag"].startswith(
            ("Marked validated", "Status not recognised", "Status says validated", "Due date not machine"))),
        "findings_with_open_gaps": sum(1 for f in out_findings if f["open_evidence_gaps"]),
    }
    data = {"summary": summary, "findings": out_findings, "excluded": excluded, "warnings": warnings}

    if a.json:
        with open(a.json, "w") as fh:
            json.dump(data, fh, indent=2)

    L = []
    L.append(f"# Leadership Decision Brief: approved facts (as of {summary['as_of']})\n")
    L.append("Source: register, approved findings only. Fields below are copied verbatim; "
             "write the brief from them and do not alter them. Items marked TO BE DECIDED are "
             "for the auditor, not for inference.\n")
    if warnings:
        L.append("## DATA QUALITY WARNINGS: resolve in the register before this brief is issued")
        L.extend(f"- {w}" for w in warnings)
        L.append("")
    if not out_findings:
        L.append("**NO APPROVED FINDINGS: there is nothing to brief yet. Do not write an executive brief from drafts.**\n")
    L.append("## Position")
    L.append(f"- Approved findings: {summary['approved_findings']} "
             f"(High/Critical: {summary['high_or_critical']})")
    L.append(f"- Actions: {summary['actions_total']} total; overdue {summary['actions_overdue']}; "
             f"due within 30 days {summary['actions_due_30d']}; "
             f"closed and validated {summary['actions_closed_validated']}; "
             f"needing a data fix {summary['actions_needing_data_fix']}")
    L.append(f"- Approved findings relying on a workpaper with an open evidence gap: "
             f"{summary['findings_with_open_gaps']}  (disclose in the assurance boundary)")
    L.append("- Overall assurance conclusion: TO BE DECIDED (take the approved conclusion; do not derive one)")
    L.append("- Business themes (max 5): TO BE DECIDED by the auditor\n")
    L.append("## Approved findings, ordered by rating then target date\n")
    for f in out_findings:
        L.append(f"### {f['id']}  |  {f['rating'] or 'rating not recorded'}  |  {f['status']} "
                 f"by {f['approved_by'] or 'approver not recorded'} on {f['approved_on'] or 'date not recorded'}")
        L.append(f"- Business title: {f['business_title'] or 'not recorded'}")
        L.append(f"- Condition: {f['condition'] or 'not recorded'}")
        L.append(f"- Approved cause: {f['cause'] or 'not recorded'}")
        L.append(f"- Evidenced impact: {f['evidenced_impact'] or 'not recorded'}")
        L.append(f"- Potential impact: {f['potential_impact'] or 'not recorded'}")
        L.append(f"- Owner / target: {f['owner'] or 'not recorded'} / {f['target'] or 'not recorded'}")
        L.append(f"- References: criteria {f['refs']['crit'] or 'none'}; workpapers {f['refs']['wp'] or 'none'}; "
                 f"evidence {f['refs']['ev'] or 'none'}")
        if f["open_evidence_gaps"]:
            L.append(f"- Open evidence gaps: {', '.join(f['open_evidence_gaps'])}")
        for x in f["actions"]:
            L.append(f"- Action {x['id']}: {x['action'] or 'action text not recorded'} | owner {x['owner'] or 'n/r'} | "
                     f"due {x['target'] or 'n/r'} | status {x['status']} | {x['flag']} | "
                     f"benefit measure: {x['benefit_measure'] or 'not recorded'}")
        if not f["actions"]:
            L.append("- Action: none recorded")
        L.append("- Executive sponsor: TO BE DECIDED   |   Decision required: TO BE DECIDED\n")
    L.append("## Findings NOT included\n")
    if excluded:
        for e in excluded:
            L.append(f"- {e['id']}: {e['reason']}")
    else:
        L.append("- none")
    text = "\n".join(L) + "\n"
    if a.md:
        with open(a.md, "w") as fh:
            fh.write(text)
    if not a.md and not a.json:
        print(text)
    else:
        print(f"approved findings: {summary['approved_findings']}; excluded: {len(excluded)}; "
              f"wrote {', '.join(x for x in (a.md, a.json) if x)}")
    for w in warnings:
        print(f"WARNING: {w}", file=sys.stderr)


if __name__ == "__main__":
    main()
