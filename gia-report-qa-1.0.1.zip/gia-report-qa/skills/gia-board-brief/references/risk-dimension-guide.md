# Risk Dimension Guide — WHY THIS MATTERS to the Board

## Contents
- 1. Financial Exposure
- 2. Regulatory / Legal Consequences
- 3. Reputational Impact
- 4. Fraud or Misconduct Risk
- 5. Governance Weakness
- 6. Operational Disruption
- 7. Stakeholder Confidence
- 8. Strategic Implications
- 9. Precedent / Culture
- Dimension Selection Guide (Quick Reference)
- 10. Revenue and Growth Protection
- Section 6 Value Delivery — Positioning Guide


> **Note (added Oct 2026).** Statutory penalty ranges and legal consequences quoted in the
> examples below (for instance percentage penalties or personal-liability statements) are
> illustrations of *phrasing*, not verified law. In a real brief, take legal consequences
> from the finding or a source you can name, and say when a figure needs validation. Where
> this guide says to "quantify", quantify only what the evidence supports; do not estimate.

Use this guide to select and develop the most relevant 2–3 risk dimensions for each finding.
Do not list all dimensions mechanically — choose those with the highest materiality for this
specific finding.

---

## 1. Financial Exposure

**When to use:** The finding involves quantifiable losses, overpayments, underpayments, penalties,
liability, or assets at risk.

**Questions to answer:**
- What is the total quantum at risk (past + future)?
- Is this a one-time loss or a recurring leak?
- Has the loss already occurred, or is it contingent?
- Is recovery possible, and on what evidenced basis? (Do not state a probability or amount unless the finding supplies it.)

**Language tips:**
- State amounts in the reporting currency of the source. Do not convert to another currency unless the source supplies the rate and date.
- Distinguish between actual loss, potential loss, and maximum exposure.
- Example: *"The company has already incurred MXN 1.76M in excess charges and will continue
  accumulating this liability at an estimated MXN 88,000 per payroll cycle until corrected."*

---

## 2. Regulatory / Legal Consequences

**When to use:** The finding involves a breach of law, regulation, licence condition, or mandatory
standard where non-compliance attracts penalties, criminal liability, or enforcement action.

**Questions to answer:**
- Which specific law or regulator is in play?
- What are the prescribed penalties (fine range, criminal exposure)?
- Has the regulator been notified, or is there a mandatory reporting obligation?
- Is the company currently in breach, or at risk of breach?

**Language tips:**
- Name the regulator and the consequence in plain terms.
- Avoid citing article numbers unless they add clarity; if cited, explain the relevance.
- Example: *"Mexico's tax authority (SAT) can assess penalties of up to 75% of the underpaid
  amount, plus surcharges. In a worst-case scenario, the Finance Manager responsible for
  approvals could be personally liable."*

---

## 3. Reputational Impact

**When to use:** The finding, if disclosed or discovered externally, would attract negative media
coverage, damage customer or investor confidence, or embarrass the Board.

**Questions to answer:**
- Who would care if this became public?
- Is there a whistleblower, union, or regulatory disclosure risk?
- Does the company operate in a sector where reputational damage has commercial consequences
  (e.g., healthcare, financial services, listed entities)?

**Language tips:**
- Be specific about the audience (investors, customers, regulators, employees, media).
- Example: *"If this payroll error became known to employees — particularly through union
  channels — it could trigger a labour dispute and attract press attention in a sector where
  employee relations are already sensitive."*

---

## 4. Fraud or Misconduct Risk

**When to use:** The finding indicates, or creates conditions for, fraud, corruption, kickbacks,
embezzlement, ghost transactions, or management override.

**Questions to answer:**
- Does the control gap create an opportunity for misconduct?
- Is there a specific person or role with undue access or authority?
- Are there red flags of actual misconduct (unusual transactions, override patterns,
  undisclosed relationships)?
- Has IA escalated to investigation status?

**Language tips:**
- Distinguish clearly between a control gap (creating risk) and evidence of actual misconduct.
- Use neutral language for suspected misconduct: *"cannot rule out"*, *"warrants further
  investigation"*, *"presents the conditions for..."*
- Example: *"The absence of due diligence on this supplier means the company cannot rule out
  that the vendor is connected to a company employee — a fact that, if true, would constitute
  an undisclosed conflict of interest and a potential corruption risk."*

---

## 5. Governance Weakness

**When to use:** The finding reveals a gap in Board oversight, management accountability, the
Three Lines Model, delegated authority, or the control environment.

**Questions to answer:**
- What oversight failed?
- Was this a policy failure, a process failure, or a people failure?
- Does the Board have the information it needs to govern this risk?
- Is there a single accountable owner, or is accountability diffuse?

**Language tips:**
- Frame in terms of what the Board did not know, could not see, or was not told.
- Example: *"The Board approved a CAPEX programme on the basis of management representations.
  Internal Audit has since found that the underlying contracts — worth USD 10.7M — were in a
  language that no one in management could read. The Board's approval decision was therefore
  made without an adequate factual foundation."*

---

## 6. Operational Disruption

**When to use:** The finding creates risk to production continuity, supply chain integrity,
service delivery, or business operations.

**Questions to answer:**
- What operational dependency exists on the failed control?
- What is the disruption scenario (vendor failure, regulatory suspension, equipment failure)?
- What is the recovery time if disruption occurs?

**Language tips:**
- Connect the control gap to a specific operational consequence.
- Example: *"If the vendor relationship is suspended pending due diligence, the company's
  tooling supply for three production lines would be at risk, with no qualified alternative
  supplier currently approved."*

---

## 7. Stakeholder Confidence

**When to use:** The finding affects the confidence of lenders, joint venture partners,
customers, employees, or regulators in the company's governance and management quality.

**Questions to answer:**
- Which stakeholder relationship is at risk?
- Is there a contractual or covenant requirement that could be triggered?
- Would disclosure to this stakeholder be required or advisable?

---

## 8. Strategic Implications

**When to use:** The finding affects the company's ability to execute its strategy — M&A
readiness, regulatory licence to operate, expansion plans, or ESG standing.

**Questions to answer:**
- Does this finding affect the company's licence to operate in a jurisdiction?
- Would this finding need to be disclosed in a due diligence process?
- Does it affect investor or lender confidence in management quality?

---

## 9. Precedent / Culture

**When to use:** The finding, if not addressed, signals tolerance of non-compliance and risks
embedding a poor governance culture.

**Questions to answer:**
- Has this issue been raised before without remediation?
- Is this a one-off or part of a pattern?
- What message does management's response send to other employees?

**Language tips:**
- Frame as a tone-from-the-top and precedent concern.
- Example: *"Management has disputed this finding without providing an alternative compliant
  treatment. If the Board accepts this without challenge, it risks signalling that governance
  standards are negotiable when operationally inconvenient."*

---

## Dimension Selection Guide (Quick Reference)

| Finding Type | Primary Dimensions |
|---|---|
| Payroll error / labour law breach | Financial, Legal/Regulatory, Employee Relations |
| Procurement without due diligence | Fraud/Misconduct, Governance, Legal/Regulatory |
| Anti-bribery failure | Legal/Regulatory, Fraud/Misconduct, Reputational |
| Asset / accounting error | Financial, Governance, Reputational (external audit) |
| IT access control failure | Fraud/Misconduct, Operational, Governance |
| Contract in foreign language | Legal, Financial (CAPEX at risk), Governance |
| Payroll ghost employee | Fraud/Misconduct, Financial, Governance |
| Licence / regulatory non-compliance | Legal/Regulatory, Operational, Reputational |
| Related-party undisclosed | Fraud/Misconduct, Governance, Legal/Regulatory |
| Inventory / stock loss | Financial, Operational, Fraud/Misconduct |

---

## 10. Revenue and Growth Protection

**When to use:** The finding affects the company's ability to retain customers, renew
contracts, access new markets, or execute growth plans.

**Questions to answer:**
- Does this non-compliance affect a customer relationship, OEM certification, or licence
  to operate in a market?
- Could this finding come up in a due diligence process (M&A, listing, JV)?
- Does it affect the company's ESG or sustainability standing with institutional investors
  or customers with supply chain ethics requirements?

**Language tips:**
- Connect the control gap directly to a commercial outcome the Chairman cares about.
- Example: *"IATF 16949 certification requires documented supplier compliance processes.
  If this gap were identified during an OEM quality audit, the company's approved supplier
  status with [OEM] could be suspended, placing [RM X] in annual revenue at risk."*

---

## Section 6 Value Delivery — Positioning Guide

When writing Section 6 (Internal Audit's Position — Value Delivered), choose the most
relevant framing from the table below:

| Scenario | Value Delivery Statement |
|---|---|
| Finding pre-empts regulatory inspection | "By identifying this before the scheduled inspection, audit has created a window for voluntary remediation — which regulators consistently treat more favourably than enforcement-discovered violations." |
| Finding prevents ongoing financial leak | "Had this remained undetected, the company would have continued accumulating [X per period]. Audit has identified the leak; stopping it depends on the agreed action and its validated closure." |
| Finding surfaces fraud risk before loss | "This finding surfaces the conditions that enable fraud before a loss has crystallised. Early identification is the most cost-effective form of fraud prevention." |
| Finding protects Board from governance blind spot | "Without this finding, the Board would have been approving [decision/statement] on the basis of incomplete information. Audit has restored the Board's ability to govern with accurate intelligence." |
| Finding protects strategic initiative | "This gap, if undiscovered, could have surfaced during [M&A / listing / OEM audit / regulatory review], potentially blocking or delaying the initiative. Audit has identified it at the lowest-cost point for remediation." |
| Finding protects employee / third-party rights | "The individuals affected by this gap now have a pathway to receive what they were legally entitled to. Internal Audit regards the protection of employee and third-party rights as part of its core governance mandate." |

Always close Section 6 with a clear statement of Internal Audit's current status on the
finding: **Open / Retained / Escalated / Closed** — and what the next step is.
