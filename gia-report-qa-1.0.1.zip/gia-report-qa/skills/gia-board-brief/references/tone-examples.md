# Tone Examples — Before & After Finding Translations

## Contents
- Example 1: Payroll / Labour Law
- Example 2: Procurement / Anti-Bribery
- Example 3: Asset / Accounting
- Example 4: HR Statutory Compliance — Value-Framing Approach


> **Calibration note (added Oct 2026).** The examples below teach *tone and structure only*.
> Their figures, statutory timings, penalty ranges, dates and root-cause narratives are
> illustrative and have not been verified against any engagement. Do not carry any of them
> into a real brief. Several examples also state inferences (for example "the HR checklist
> does not appear to include...", or what workers "may" claim) that a real brief would
> either source to the finding or leave out. New briefs follow the evidence-reference and
> labelling rules in `traceability-in-prose.md`, and the example structure here predates the
> two control blocks (Decision & Accountability, Assurance Trail) that now follow Section 7.

Use these calibration examples to ensure output is genuinely translated, not merely paraphrased.

---

## Example 1: Payroll / Labour Law

### RAW AUDIT FINDING (input)
> F-PAY-03 | HIGH | ISR Art.174 over-withholding identified across 19 payroll periods. Gross excess
> withholding computed at MXN 1.76M. Root cause: incorrect tax table applied post-system migration.
> No compensatory mechanism in place. STPS exposure confirmed.

### TRANSLATED OUTPUT

**HIGH | F-PAY-03**

**1. ISSUE SUMMARY**
The company has been deducting too much income tax from employees' wages across 19 consecutive pay
periods. In plain terms, employees have been receiving less take-home pay than they are legally
entitled to — by a total of approximately MXN 1.76 million (roughly USD 88,000 across the group
of affected staff).

**2. WHAT SHOULD HAVE HAPPENED**
Under Mexican tax law, employers are required to apply the correct income tax tables when
calculating payroll deductions. These tables are prescribed by the tax authority (SAT) and must be
updated whenever a payroll system changes. The company failed to update these tables following a
system migration, meaning the wrong rates were applied continuously for 19 pay periods.

**3. WHY THIS MATTERS TO THE BOARD**
This has two direct consequences: first, it is a financial liability — the company owes employees
the overpaid tax amounts, plus interest, and must correct this with the tax authority. Second, it
is a legal exposure — Mexico's labour regulator (STPS) can impose penalties on employers who
systematically underpay net wages, even where the underpayment results from a tax calculation
error rather than deliberate intent.

**4. RISK IF NOT ADDRESSED**
If uncorrected, the company accumulates a growing liability with each additional payroll run. Should
employees become aware of the underpayment — through payslip scrutiny or union intervention — the
company could face a labour dispute, regulatory complaint, or media attention. The longer the error
persists, the larger the liability and the harder it becomes to correct discreetly.

**5. ROOT CAUSE**
The incorrect tax table was introduced during a payroll system migration. No post-migration
verification was performed to confirm that tax calculations continued to produce correct outputs.
There was also no ongoing management review process to detect payroll errors between audit cycles.

**6. BOARD-LEVEL MESSAGE**
The company has been inadvertently short-paying employees their net wages for over four months due
to a tax calculation error introduced during a system change. While this appears to be an
administrative error rather than deliberate misconduct, the financial and regulatory exposure is
real and growing. The Board should expect management to correct the payroll immediately, quantify
the total repayment liability, and establish a post-payroll review process to prevent recurrence.
This is a straightforward remediation that management should be able to complete within 30 days.

---

## Example 2: Procurement / Anti-Bribery

### RAW AUDIT FINDING (input)
> TLG-CON-06 | CRITICAL | No KYC or third-party due diligence performed on DaesungRobotech prior
> to awarding USD 3.39M in tooling contracts. No ABAC declaration obtained. Conflict of interest
> register not updated. Beneficial ownership unknown.

### TRANSLATED OUTPUT

**CRITICAL | TLG-CON-06**

**1. ISSUE SUMMARY**
The company awarded contracts worth USD 3.39 million to a Korean supplier without conducting any
background checks on that supplier. The Board should understand this plainly: the company handed
over more than USD 3 million to a vendor whose ownership, business legitimacy, and connections to
company employees are entirely unknown.

**2. WHAT SHOULD HAVE HAPPENED**
Before awarding significant contracts, companies are expected — and in many jurisdictions legally
required — to verify who they are doing business with. This includes confirming the supplier's
legal registration, identifying the ultimate owners, and checking for any connections to company
employees (which could indicate a conflict of interest). Anti-bribery laws in Malaysia, the US
(FCPA), and the UK (UK Bribery Act) impose liability on companies that fail to perform these
checks and subsequently engage in, or facilitate, corrupt conduct through third parties.

**3. WHY THIS MATTERS TO THE BOARD**
The Board has a governance duty to ensure the company does not knowingly — or through negligence —
engage in corrupt or fraudulent procurement. Without knowing who owns DaesungRobotech, the company
cannot rule out that this vendor is connected to a company employee, an agent acting on behalf of
a competitor, or a party with sanctions exposure. At USD 3.39 million, this is not a minor
administrative oversight — it is a governance blind spot on a material contract. If corruption
is later found to have occurred through this relationship, the company and its directors could
face criminal liability.

**4. RISK IF NOT ADDRESSED**
If due diligence is not conducted retroactively — and proper screening is not applied going
forward — the company remains exposed to: undisclosed conflicts of interest, potential bribery
or kickback arrangements, sanctions violations (if the supplier or its owners are listed), and
regulatory investigation. Any future forensic scrutiny of this vendor relationship would reveal
the absence of due diligence as a governance failure at the highest level.

**5. ROOT CAUSE**
There is no mandatory pre-contract due diligence policy governing cross-border supplier
relationships above a defined threshold. Procurement was authorised and executed without a
governance checkpoint requiring vendor verification. The absence of a conflict-of-interest
declaration process means management had no mechanism to surface potential undisclosed relationships.

**6. BOARD-LEVEL MESSAGE**
The company awarded over USD 3 million to a foreign supplier it knows virtually nothing about.
This is not a process technicality — it is a fundamental governance gap that exposes the company
to anti-bribery liability, undisclosed conflicts of interest, and reputational risk. The Board
should direct management to conduct immediate retroactive due diligence on this supplier, suspend
further payments pending clearance, and implement a mandatory pre-contract screening policy for
all cross-border vendor relationships above a defined threshold. This finding has been retained by
Internal Audit pending satisfactory remediation.

---

## Example 3: Asset / Accounting

### RAW AUDIT FINDING (input)
> F-06 | CRITICAL | 16 fixed assets carry negative net book value in the financial records,
> violating NIF C-6. Total negative NBV: MXN 4.2M. Management disputes finding, claims assets
> are still in use. IA position retained.

### TRANSLATED OUTPUT

**CRITICAL | F-06**

**1. ISSUE SUMMARY**
The company's accounting records show that 16 physical assets have a negative book value — meaning
the records indicate the company owes money on assets that have already been fully depreciated and,
in some cases, have been in use for years beyond their accounting life. In simple terms, the
financial statements contain an accounting error that misrepresents the true state of the
company's assets.

**2. WHAT SHOULD HAVE HAPPENED**
Under the applicable accounting standard (NIF C-6, Mexico's equivalent of the international fixed
asset accounting rule), the recorded value of an asset cannot fall below zero. When an asset
reaches the end of its useful life, it should either be derecognised (removed from the books) or
have its accounting life formally extended following an asset review. Neither action was taken,
resulting in records that are technically incorrect.

**3. WHY THIS MATTERS TO THE BOARD**
The financial statements are signed off by the Board and presented to shareholders, lenders, and
regulators on the basis that they represent a true and fair view of the company's position. If
the asset register contains 16 items that violate the applicable accounting standard, the integrity
of the financial statements is in question — not just for these assets, but for the reliability
of the financial reporting process as a whole. External auditors reviewing these records would
be expected to raise the same issue.

**4. RISK IF NOT ADDRESSED**
Uncorrected negative book values will persist — and potentially multiply — in future reporting
periods. If external auditors identify these errors independently, it raises questions about the
adequacy of internal review processes and management's oversight of financial reporting. There is
also a risk that assets that have exceeded their useful life are being kept in production in a
condition that has not been formally assessed, creating both accounting and operational safety
considerations.

**5. ROOT CAUSE**
The asset register has not been subject to regular review to identify and address assets that have
reached or exceeded their accounting useful life. There is no systematic process for either
extending asset lives (where appropriate) or derecognising assets that are fully depreciated.

**6. BOARD-LEVEL MESSAGE**
The company's fixed asset records contain a technical accounting error that is inconsistent with
applicable standards and that management has disputed without providing a satisfactory alternative
accounting treatment. Internal Audit has retained this finding. The Board should note that this
issue is not about the physical condition of the assets — it is about whether the financial records
accurately reflect the company's asset position. The Board should direct management to resolve
this matter with the external auditors before the next reporting period, and to implement a
structured annual asset register review to prevent recurrence.

---

## Example 4: HR Statutory Compliance — Value-Framing Approach

### RAW AUDIT FINDING (input)
> F-HR-07 | HIGH | MKAPL Jacks Division — 38 contract workers identified as not enrolled in
> ESIC despite being eligible. Non-compliance with ESI Act 1948. Exposure period: 8 months.
> Estimated employer contribution gap: ₹4.2 lakhs. No management awareness of gap.

### TRANSLATED OUTPUT

**HIGH | F-HR-07 | People & Statutory Compliance**

**1. ISSUE SUMMARY**
For the past eight months, 38 workers at our Jacks Division have not been registered with
the government's employee health insurance scheme — despite the company being legally required
to do so. In practical terms, these employees have been working without statutory medical
coverage that the company should have been providing and funding on their behalf.

**2. WHAT SHOULD HAVE HAPPENED**
Under India's employee health insurance law, employers must register all eligible workers and
contribute to the government scheme (ESIC) within 10 days of their joining. This scheme
provides workers and their families with hospital treatment, sickness pay, and maternity
benefits at no cost to the employee. The company's obligation to enrol and contribute is
non-negotiable — it applies regardless of whether the workers are permanent staff or
contractors brought in through a manpower agency.

**3. BUSINESS VALUE AT STAKE**
Three dimensions are most material here.

First, financial exposure: the unpaid employer contributions for the 8-month period amount
to approximately ₹4.2 lakhs (roughly USD 5,000). This is money the company should have
been remitting monthly and will now need to settle as a lump sum, likely with interest and
late fees applied by the regulator.

Second, legal and regulatory risk: ESIC inspections in manufacturing facilities are
periodic and can be triggered by worker complaints. If inspectors identify this gap — as
they likely would — the company faces statutory penalties, back-payment demands, and
potential Director-level liability. Unlike many regulatory exposures, ESIC non-compliance
is difficult to dispute because the obligation is absolute.

Third, people and culture risk: if the 38 affected workers or their union representatives
become aware that they have been working without mandated health coverage, this is likely
to damage trust, invite grievances, and may trigger labour complaints or adverse press
coverage in a factory environment where worker welfare is a visible governance concern.

Addressing this will eliminate a growing financial liability, restore statutory coverage
for workers who should have been protected from day one, and demonstrate to the workforce
and regulators that the company takes its employer obligations seriously.

**4. RISK IF NOT ADDRESSED**
Every month this gap continues, the company's liability grows. An ESIC inspection — which
can occur without notice — would expose not only the back-contribution shortfall but also
the fact that management was unaware of the gap for eight months, raising questions about
the adequacy of HR oversight. Workers who suffer a health event during the period of
non-enrolment may have grounds for a personal claim against the company for failing to
provide the coverage they were entitled to.

**5. ROOT CAUSE**
The root cause is a breakdown in the onboarding compliance process for contract workers.
The company's internal HR checklist does not appear to include ESIC enrolment verification
as a mandatory step for contractor hires, and there is no monthly reconciliation between
the payroll headcount and the ESIC registered member list. This is a systemic gap, not an
isolated oversight — it affects all 38 workers enrolled during the same period, which
suggests the control failure occurred at the process level, not as individual data-entry
errors.

**6. INTERNAL AUDIT'S POSITION — VALUE DELIVERED**
By identifying this gap before an ESIC inspection or a worker complaint, Internal Audit
has created a window for management to remediate voluntarily and proactively — which
regulators routinely treat more favourably than violations discovered during enforcement
visits. Had this remained undetected for another quarter, the company's back-liability and
penalty exposure would have continued compounding. Internal Audit considers this finding
open and will track management's enrolment completion and regulatory settlement as part
of the follow-up programme.

**7. BOARD-LEVEL MESSAGE**
Thirty-eight of our Jacks Division workers have been operating without the statutory health
coverage they are legally entitled to for the past eight months — a gap that Internal Audit
has now identified and brought to the Board's attention before it became a regulatory
enforcement issue. The financial liability is manageable at this stage, but the reputational
and legal risk of this gap continuing is not. The Board should direct management to enrol
all affected workers immediately, settle the outstanding contributions with the regulator,
and implement a monthly reconciliation process so that this type of onboarding gap cannot
persist undetected in future. More broadly, this finding is a reminder that statutory
employer obligations toward contract workers require the same rigour as those for permanent
employees — and the Board should satisfy itself that management has reviewed this standard
across all divisions, not just Jacks. The Audit Committee will receive a status update at
the next quarterly meeting.
