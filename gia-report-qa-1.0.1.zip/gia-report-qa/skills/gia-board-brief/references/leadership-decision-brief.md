# Leadership Decision Brief and Executive Deck (Modes C and D)

Present audit impact as a business decision brief, not a list of findings. Lead with what the
organisation needs to protect or improve (cash, margin, continuity, delivery, regulatory
standing, safety, governance), then the evidence-supported issue, the accountable action and
the expected outcome. Executives need to know what matters now, what is at risk or being
missed, what decision or support is needed from them, who owns the fix, and how they will know
it worked.

Use only **approved** findings, ratings, actions and references. Group findings into at most
five business themes. The same no-drift and no-invention rules as Mode B apply; the check is made in the QA log or chat reply, not stated in the deliverable.

Run `scripts/brief_data.py` (this skill) to extract the approved facts from the evidence register verbatim; it is the safest starting point for this mode.

## Contents
1. Audit language to executive language
2. The one-page Leadership Decision Brief
3. Executive issue format (high and critical items)
4. Dashboard views
5. Presenting verbally
6. Eight-slide structure and presentation rules
7. The executive test

---

## 1. Audit language to executive language

| Audit language | Executive language |
|---|---|
| Control weakness | Management cannot reliably prevent, detect or explain this risk |
| Policy non-compliance | The business may not be operating in the agreed way, creating cost, legal, quality or governance exposure |
| Sample exception | In the transactions reviewed, the company could not consistently demonstrate the required control |
| Segregation-of-duties conflict | One person can start and complete a transaction without an independent check |
| Operating-effectiveness issue | The safeguard exists but did not work consistently in the period reviewed |
| Evidence gap | Management cannot currently demonstrate the required activity was completed |
| Scope limitation | Internal Audit could not complete this part because records or access were unavailable |
| Residual risk | The risk that remains after current actions and safeguards |
| Recommendation | Management action needed to protect value or improve performance |

Shift the message from "the audit found four approval exceptions" to "management cannot
consistently demonstrate that significant supplier payments received independent approval;
this weakens cash governance, and leadership support is needed to enforce a system-based
approval block and hold owners to the date."

## 2. The one-page Leadership Decision Brief

Open every executive report or presentation with this page.

```
AUDIT:               [title]
ENTITY / LOCATION:   [entity, plant or business unit]
PERIOD REVIEWED:     [period]
OVERALL ASSURANCE:   [approved conclusion, e.g. Satisfactory / Needs improvement / Unsatisfactory]
AUDIT PURPOSE:       [one plain-English sentence]

1. Executive message
   [Two or three sentences: what leadership needs to know now.]

2. Business value protected or created
   - Cash / margin / working capital:
   - Production and customer delivery:
   - Quality and safety:
   - Compliance and licence to operate:
   - Governance and management visibility:
   (Complete only the lines the findings support; write "not assessed" for the rest.)

3. Top priorities requiring management attention
   [Three to five issues, ordered by business significance.]

4. Leadership decisions or support required
   - [Decision 1]  - [Decision 2]  - [Decision 3]

5. Action accountability
   [High-risk actions: owner, target date, status, escalation needed.]

6. Assurance boundary
   [What Internal Audit tested, what it did not, material scope limitations.]
```

The overall assurance label is taken from the approved audit conclusion. Do not derive one
from the findings, and do not use a colour without stating what it rests on.

## 3. Executive issue format (high and critical items)

| Element | What leadership should see |
|---|---|
| Business message | One sentence: the issue and why it matters |
| Value at risk | Cash, margin, inventory, production, delivery, customer, safety, licence, reputation or decision quality |
| What audit found | Brief, evidence-based, with scale and period |
| Management implication | What management cannot reliably demonstrate, control or decide today |
| Priority | Critical / High / Medium, with short rationale |
| Action required | Outcome-based, practical |
| Business benefit | What improves when it is done |
| Accountability | Executive sponsor, action owner, due date, status |
| Decision required | Approve, fund, prioritise, accept risk, escalate or monitor |
| Audit trail | Finding ID, workpaper ID, evidence reference |

## 4. Dashboard views

Limit the dashboard to five decision-relevant views. Each cell must come from the approved
material; where a trend or value is not evidenced, leave it blank or write "not assessed".

1. **Overall assurance position.** Area | assurance status | main leadership message | trend. A status colour must lead to a stated message, not replace it.
2. **Value-at-risk.** Value area | exposure or opportunity | evidence basis | management action. Use quantified exposure only where evidenced; otherwise a defined qualitative category.
3. **Priority actions.** Priority | business issue | executive sponsor | action owner | due date | status | escalation required.
4. **Root themes.** Patterns across findings, for example incomplete evidence trails, manual-process dependency, weak action-closure discipline, inconsistent data ownership, cross-functional accountability gaps. State the leadership implication, and only name a theme the findings actually show.
5. **Closure and benefit.** Action | closure evidence | benefit measure | audit validation. "Closed" is not a benefit; show the measure and how Internal Audit will test it.

## 5. Presenting verbally

Begin with the conclusion, not the methodology. Opening script:

> "This audit examined whether the business can reliably control and demonstrate [process].
> The main message is that [the process operates, but management cannot consistently evidence
> some key decisions]. This creates avoidable exposure in [areas]. We are not asking
> leadership to review individual transactions; we are asking for support on three
> priorities: [1], [2], [3]. The proposed actions are practical, owned and measurable, and
> Internal Audit will validate whether they deliver."

For a high-risk issue, speak in this order: business objective; the evidence-supported
position (with sample and period); the business implication; **the limit of the conclusion**
(for example "the audit did not conclude the payments were unauthorised"); the action; the
leadership ask; the success measure. Stating the limit up front is what keeps management
from getting defensive and keeps the brief credible.

## 6. Eight-slide structure and presentation rules

Main deck, then appendices:

1. Audit purpose, scope and executive message
2. Overall assurance and business-value summary
3. Top risks and leadership decisions required
4. Priority issue theme 1
5. Priority issue theme 2
6. Priority issue theme 3
7. Management actions, owners, due dates, dependencies
8. Closure-validation approach and next steps
- Appendix A: detailed issue register
- Appendix B: scope, methodology, evidence references

**Do:** lead with the top three messages; group into 3–5 themes; use business outcomes; state the
evidence boundary (sample, period, scope, unresolved limits); show what is working; request a
clear decision, sponsor or risk-acceptance; show overdue actions and dependencies; use few
visuals (heat map, action dashboard, trend line, value-at-risk table); keep evidence
references in an appendix or drill-down.

**Do not:** open with methodology; read control failures one by one; use unexplained terms;
overstate a sample as company-wide; present allegations or management explanations as fact;
claim savings, loss or penalties without a defensible calculation; show many red/amber/green
indicators without saying what must happen; ask the Board to solve management-level
operational issues unless escalation is genuinely needed.

Every material statement on a slide keeps its finding, workpaper and evidence reference
(footnote or appendix). Build the deck with the `pptx` skill, or a Slides artifact type if the
session offers one.

## 7. The executive test

For each slide: *if the CFO, CEO or a director read only this slide, could they identify the
business risk, the decision required, the accountable owner, the completion date and the
expected outcome?* If not, simplify it.
