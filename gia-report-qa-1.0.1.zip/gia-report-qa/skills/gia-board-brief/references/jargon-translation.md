# Jargon Translation: From Control Label to Business Consequence

Translate by moving from the control label to what can go wrong, what value is exposed, what
management should decide, and what improves after action. The tables give a starting point;
adapt the wording to the finding and keep to its facts. Use a translation only when it fits
what the evidence shows (a "duplicate payment" risk is not a duplicate payment).

## Contents
1. The five-part formula
2. Financial wording
3. Risk and control wording
4. Compliance wording
5. Rewriting recommendations
6. Before-and-after examples

---

## 1. The five-part formula

**Technical issue → what happened → business consequence → action → expected benefit**

| Step | Audit-language question | Business-language question |
|---|---|---|
| 1. State the fact | What control was missing or failed? | What could the company not show, prevent or manage? |
| 2. Identify the exposure | What is the risk? | What could this mean for cash, margin, delivery, quality, safety, customers or reputation? |
| 3. Make it relevant | Which assertion or control objective is affected? | Which business decision or objective is affected? |
| 4. Recommend action | What control should be designed or fixed? | What practical change should management make? |
| 5. Explain value | What does remediation achieve? | What becomes faster, safer, cheaper, clearer or more reliable? |

*Example.* Technical: "The vendor-master change control is ineffective due to inadequate
maker-checker controls." Business: "The company does not consistently use an independent
check when supplier bank details change. That raises the risk of payments going to the wrong
account, or of changes going unnoticed. Finance should require a second authorised person to
verify every bank-detail change before it takes effect. This protects cash and makes changes
to supplier data accountable."

---

## 2. Financial wording

| Technical wording | Business impact | Plain recommendation |
|---|---|---|
| Accounts payable reconciliation differences | The company may not have a complete view of what it owes suppliers, which can lead to duplicate or missed payments, disputes, or unreliable cash forecasts | Reconcile supplier balances to the ledger monthly, investigate differences promptly, document the review |
| Unreconciled bank items | Cash records may not match the actual bank position, making errors or unusual payments harder to spot | Clear or explain old reconciling items within a set period and escalate overdue ones |
| Duplicate vendor records | One supplier may appear more than once, raising duplicate-payment risk and blurring spend visibility | Identify duplicates, keep one approved record, block the rest, review future changes |
| Unsupported journal entries | Adjustments may be posted without enough evidence or review, risking incorrect results | Require a business reason, support, preparer details and independent approval |
| Cut-off error | Income, purchases, inventory or expense may land in the wrong period, distorting performance and decisions | Define and monitor cut-off procedures using dispatch, receipt, invoice and goods-receipt evidence |
| Incomplete fixed-asset register | The company may not know what it owns, where it is, or whether depreciation is right | Reconcile the register to the ledger and physically verify significant assets on a planned cycle |
| Incorrect capitalisation | Costs treated as assets (or the reverse) distort profit, tax and investment decisions | Set clear capital-versus-revenue rules; Finance reviews significant capitalisation |
| Impairment assessment not documented | Management may lack evidence that assets are still worth the value shown | Require an annual documented review of indicators of lost value |
| Revenue-recognition control gap | Sales may be recorded before the obligation to the customer is complete, overstating results | Tie recognition to approved dispatch, acceptance, completion and contract terms |
| Working-capital leakage | Cash tied up in stock, slow collections, advances or avoidable supplier balances | Regular dashboards for stock ageing, collections, advance recovery, overdue reconciling items |
| Aged receivables | Amounts due may not be collected, cutting cash and increasing write-off risk | Assign owners, escalate ageing, document collection plans or credit holds |
| Unauthorised payment risk | Cash could leave without the right approval or support | Block release unless order, receipt, invoice and independent approval evidence exist |
| Budget variance not investigated | Management may not understand why results differ from plan, delaying correction | Owners explain material variances, agree actions, track completion monthly |

## 3. Risk and control wording

| Technical wording | Business impact | Plain recommendation |
|---|---|---|
| Segregation-of-duties conflict | One person can do too many parts of a transaction, so mistakes or misuse are harder to prevent or detect | Separate request, approval, master-data change, payment preparation and release |
| Maker-checker control absent | A transaction can go through without an independent second review | One person prepares; another authorised person verifies and approves |
| Control not operating effectively | The safeguard exists but did not work consistently in the period tested | Find out why, assign an owner, evidence completion each time |
| Control-design gap | The process was not built to prevent or detect the risk | Redesign so the check happens before the risk can affect the business |
| Manual control dependence | The process relies on people remembering steps, causing delay and inconsistency | Add reminders, mandatory fields, workflow approvals, exception reports where practical |
| Override risk | Seniority or system access may let normal checks be bypassed | Independent review and Board/AC oversight of executive exceptions |
| Key-person dependency | The process rests on one person; absence or departure could disrupt operations | Document the process, train backups, restrict single-person authority |
| Inadequate monitoring | Management lacks timely information to spot problems or confirm actions are done | Regular dashboard of exceptions, ageing, overdue actions, key risk indicators |
| Residual risk remains high | Even after current safeguards, significant exposure remains | Management decides: strengthen, formally accept, transfer, or change the activity |
| Risk appetite exceeded | The business is taking more risk than the Board agreed to accept | Escalate to the right forum; agree corrective action or formal risk acceptance |
| Root cause not established | The audit knows what happened but not yet why | Management completes a structured cause analysis before choosing a permanent fix |
| Compensating control | Another independent check may cover a missing safeguard | Document it, assign ownership, test whether it genuinely covers the gap |
| Detective control | A check that finds a problem after it has happened | Regular reviews to find errors quickly and act before impact grows |
| Preventive control | A check that stops an error or unauthorised action before it occurs | Approval blocks, mandatory fields, access limits, system validations |
| Audit trail weakness | The company cannot easily show who did what, when, with what approval | Keep system logs and approval records in a controlled, retrievable place |
| Population completeness issue | The audit cannot confirm it received the full set of records to test | Reconcile the report used for testing to the ledger, a system control total or another independent source |
| Scope limitation | Audit could not complete part of the review because access, data or records were unavailable | Management provides the missing access or records and agrees whether more work is needed |

## 4. Compliance wording

The point is to explain why adherence protects the business, not to hide the requirement.

| Technical wording | Business impact | Plain recommendation |
|---|---|---|
| Statutory non-compliance | Exposure to penalties, disputes, licence restrictions, reputational harm, management distraction | Confirm the exact requirement, assess applicability, correct the gap, set an owner and compliance calendar |
| Regulatory exposure | A regulator may challenge the company's records, processes or approvals | Keep complete records, monitor due dates, evidence management review |
| Compliance obligation not mapped | The business may not know which legal requirements apply to each process or location | Central register: requirement, owner, frequency, evidence, review date |
| Filing delay | Information not submitted on time raises penalty and follow-up risk | Filing calendar with owners, backups, alerts and filing evidence |
| Missing statutory register | The company may be unable to show compliance in an inspection or dispute | Identify required registers, assign owners, check completeness periodically |
| GST input-tax-credit mismatch | Credit claimed without matching records risks denial, interest or blocked cash | Reconcile purchase records, supplier filings and returns before claiming; track unmatched items |
| E-invoice / e-way bill gap | Invoicing or goods movement may miss documentation rules, risking tax and supply disruption | System checks so required documents exist before dispatch or invoicing |
| Labour-law documentation gap | The company may be unable to show employees and contractors received required wages, benefits, hours or protections | Keep complete attendance, wage, overtime, contractor and statutory-payment records with periodic review |
| Contractor compliance weakness | Legal, safety, wage or reputational risk from contractors on site | Verify licences, statutory payments, safety training and worker records before and during engagement |
| Environmental permit condition not evidenced | Regulatory action or operating restrictions if permit conditions cannot be shown to be met | Permit-condition tracker, accountable owners, timely monitoring and filing evidence |
| EHS corrective action overdue | Safety risks stay unresolved, raising injury, disruption or regulator intervention | Due dates, escalation triggers, independent closure checks |
| Policy non-adherence | The approved way of working was not consistently followed | Clarify the process, build it into systems, train users, monitor exceptions |
| Record-retention non-compliance | Decisions, tax position or compliance may be impossible to defend | Retention periods, owners, secure storage, periodic retrievability checks |
| Licence renewal risk | Interruption or legal exposure if a licence lapses | Central renewal tracker with alerts and management oversight before expiry |
| Related-party disclosure gap | Directors, investors or regulators may not get full information on connected-party dealings | Current related-party register, periodic declarations, approvals before transactions |
| Data-privacy compliance gap | Personal data may be exposed, misused or kept too long | Map personal-data use, restrict access, define retention, obtain required consents, test incident response |

Statutory penalty amounts, rates and deadlines are not in these tables on purpose. Take them
from the finding or a source you can name, and say when a figure needs validation.

---

## 5. Rewriting recommendations

A good recommendation says what outcome is needed and leaves sensible room on how.
"Ensure compliance" and "strengthen controls" cannot be owned, tested or closed.

**Owner + action + control/outcome + deadline + proof of completion**

| Weak | Plain, business-focused rewrite |
|---|---|
| "Strengthen approval controls." | "The Finance Controller should configure the payment workflow so payments above the approved threshold cannot be released until the required approvals are recorded. Finance should review and resolve blocked payments weekly." |
| "Ensure compliance with GST requirements." | "The Tax Manager should reconcile purchase records to supplier filings and the GST return before input tax credit is claimed. Unmatched items should be tracked, assigned and resolved within the agreed period." |
| "Improve segregation of duties." | "IT and Finance should remove the ability for one user to create a supplier, change bank details and approve the change. Any temporary exception should need documented independent review." |
| "Conduct periodic inventory reconciliation." | "The Plant Finance Manager should reconcile stock records to physical counts monthly, investigate material differences, and report unresolved items to the Plant Head." |
| "Improve vendor master-data governance." | "Procurement and Finance should require independent verification of supplier bank-account changes and run a monthly duplicate-supplier review before payments are processed." |
| "Ensure all overtime is compliant." | "HR and Plant Operations should record overtime requests, approvals, hours worked and payroll payment in one reviewable record. The Plant Head should review monthly exceptions." |
| "Implement a robust CAPA process." | "The Quality Head should assign an owner and due date to every quality issue, record the action, and independently confirm it prevented recurrence before closing it." |
| "Enhance management monitoring." | "Management should receive a monthly dashboard of overdue approvals, unreconciled balances, open quality issues and overdue audit actions, with named owners and escalation for delays." |
| "Automate the process." | "Management should assess whether the manual approval and tracking steps can be replaced by workflow controls that block incomplete transactions and create an electronic audit trail." |
| "Perform root-cause analysis." | "The process owner should identify why the issue occurred, test whether the cause affects other transactions or locations, and agree actions that fix the cause rather than only the individual cases." |

The owners, thresholds and dates above are placeholders for form. In a real brief they come
from the approved finding or action plan; if they are absent, say they are to be agreed.

## 6. Before-and-after examples

**Financial reporting.** *Technical:* "Manual journal-entry controls were not operating
effectively, creating risk of misstatement." *Business:* "Some accounting adjustments were
posted without complete support or independent review, so errors in management reports may
not be caught promptly." *Action:* "Require supporting documents and independent approval for
manual journal entries above the agreed threshold, with a monthly review of unusual, late or
unsupported entries."

**Procurement and payments.** *Technical:* "The P2P process has a three-way-match
exception-control deficiency." *Business:* "Some supplier payments were made without clear
evidence that the goods or services were ordered, received and correctly invoiced, which
raises the risk of overpayment, duplicate payment or paying for items not received." *Action:*
"Release payment only when the purchase order, goods receipt and invoice agree; approve and
log any valid exception for monthly review."

**Inventory.** *Technical:* "Cycle-count exceptions were not timely investigated." *Business:*
"Differences between physical stock and system records were not resolved quickly, which can
cause production shortages, excess purchasing, unrecorded losses and inaccurate stock values."
*Action:* "Investigate material stock differences within the agreed timeframe, correct
approved records, and report unresolved differences to the Plant Head."

**Compliance.** *Technical:* "The entity lacks a formal compliance-obligation register."
*Business:* "Management has no single view of which legal requirements apply, who owns each,
and whether they were met on time, which raises the chance of missed filings and last-minute
effort." *Action:* "Keep one central register of requirements, due dates, evidence, owners and
review status; review overdue or high-risk items monthly."

**ERP access.** *Technical:* "User-access provisioning and periodic access review controls were
not operating effectively." *Business:* "Some employees kept system access not clearly linked
to their current role, raising the risk of unauthorised changes or transactions that are hard
to trace." *Action:* "Grant access by defined role with manager approval, have managers review
access at least quarterly, and remove access no longer needed promptly."
