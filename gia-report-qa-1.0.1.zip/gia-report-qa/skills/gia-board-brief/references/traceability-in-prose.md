# Traceability in Board-Facing Prose

How to cite evidence in a plain-language brief without turning it into a workpaper, and how
to keep a director-level message honest about what the audit actually established.

## Contents
1. Reference ID types
2. The three labels
3. Two layers, one evidence base
4. Audience map
5. Business value lenses
6. Finding-to-value translation
7. Report-quality tests
8. Worked examples

---

## 1. Reference ID types

| Type | Meaning | Example |
|---|---|---|
| `EV` | Source evidence (document, system export, observation record) | `EV-021` |
| `CRIT` | Approved criterion (law, policy, delegation matrix, contract term) | `CRIT-DOA-02` |
| `PROC` | Audit procedure performed | `PROC-P2P-07` |
| `WP` | Workpaper or testing result | `WP-P2P-07` |
| `EXC` | Approved exception | `EXC-014` |
| `FIND` | Approved finding | `FIND-P2P-03` |
| `MR` | Management response | `MR-P2P-03` |
| `CE` / `GAP` | Contradictory evidence / evidence gap | `GAP-004` |

Format: `TYPE-NN`, or `TYPE-AREA-NN` where AREA is a short code (2–6 capitals/digits) and NN
is 2–4 digits. Ranges may be written `EV-021 to EV-024`. Cite at the end of the sentence;
group consecutive claims that share support rather than tagging every clause.

**You never create these IDs.** They come from the engagement's evidence register. If the
source finding has none, write: *"Evidence reference not available — auditor validation
required."* An invented `WP-P2P-07` looks like assurance and is not.

## 2. The three labels

| Situation | Wording |
|---|---|
| Management's statement, not independently tested | *Management representation — not independently verified [MR-###].* |
| Auditor's view, based on tested evidence | *Audit assessment based on [EV-###] and [WP-###].* |
| Support not available | *Evidence reference not available — auditor validation required.* Say it once (under the Basis line if the whole source has no IDs, or beside the single claim that lacks one), not after every paragraph |

Why bother: a director cannot tell from tone whether a sentence is tested fact, management's
explanation, or the writer's inference. The label tells them how much weight it will bear.
Evidence graded R5 (a verbal statement) is never cited in a finding; if the only support
for a statement is verbal, it belongs under the management-representation label or not at all.

## 3. Two layers, one evidence base

- **Layer 1, director / Audit Committee report:** plain language, business outcome, value at
  stake, decision required, concise visual summary. No testing steps, transaction lists or
  raw workpaper text. Each issue points to the detailed finding.
- **Layer 2, workpapers and finding sheets:** full evidence trail, procedures, sample
  results, criteria, limitations, management responses, review history.

Every Layer 1 claim must be supported in Layer 2; Layer 2 must support every material Layer 1
message. This skill writes Layer 1. If a claim cannot be traced down, it does not go up.

## 4. Audience map

| Audience | Focus |
|---|---|
| **A. Board / AC / directors** | Strategic implication, significant exposure, governance, accountability, priorities, assurance level. Plain English; explain each technical term once. |
| **B. CEO / CFO / business or plant head** | Cash, cost, delivery, quality, safety, compliance, continuity, the management decision needed. |
| **C. Process owner / functional management** | The exact gap, evidence, requirement, practical action, owner, timeline, how closure is verified. |
| **D. Audit team / quality reviewer** | Full trail: criteria, population, sample, steps, evidence, exceptions, limitations, judgement, review notes. |

Do not use the same wording for all four.

## 5. Business value lenses

Use whichever apply; do not invent a monetary benefit for any of them.

1. **Value protected:** cash, profit, assets, inventory, data, reputation, customer trust, licences, safety, compliance standing, production continuity, management time.
2. **Value created:** cost reduction, working-capital release, faster cycle time, better decisions, less rework, clearer accountability, simplification, automation.
3. **Risk reduced:** financial loss, fraud opportunity, wrong reporting, penalty exposure, supply disruption, inventory loss, quality failure, safety incident, loss of oversight.
4. **Decision required:** what management or the Board must approve, prioritise, resource, monitor, redesign or escalate.
5. **Benefit measurement:** how success will be visible after the action.

If a benefit cannot be supported: *"Expected benefit to be confirmed by management during
action planning."* If an impact is not quantified: *"Potential impact not quantified;
management validation required."*

## 6. Finding-to-value translation

Move through this sequence instead of reporting "non-compliance":

1. What happened, or what could not be demonstrated?
2. Which business objective, decision, asset, customer commitment or governance need is affected?
3. What is the credible risk or missed opportunity?
4. What practical improvement is recommended?
5. What should management expect after implementation?
6. How will Internal Audit validate closure and benefit?

Non-compliance is context for this chain, not the whole message.

## 7. Report-quality tests

Run these before delivery. A failure becomes a QA note to the auditor; do not silently
rewrite an approved finding to make a test pass.

1. **Traceability:** can each material statement be linked to a workpaper or source evidence?
2. **Accuracy:** does the wording match the approved finding without overstating the sample, impact, cause or risk?
3. **Clarity:** can a non-specialist director follow it without audit jargon?
4. **Relevance:** does it say why this matters to performance, governance, risk or a decision?
5. **Actionability:** does each priority issue give the decision, action, owner, date and expected outcome?
6. **Proportionality:** is it short enough for directors, with the detail left in the workpapers?
7. **Balance:** does it recognise effective practice and progress where supported?

The one-minute director test: can a director say what the issue is, why to care, what risk
or opportunity it creates, what happens next, and who owns it, by when, and how closure
will be known? If the answer is still "there is a control deficiency", the translation is
not finished.

## 8. Worked examples

The figures below are illustrative and exist only to show the form. Do not reuse them.

### Example 1: approved finding with references

**Weak (technical):** "The procurement team did not comply with the delegated-authority
matrix for four sampled payments. This is a control deficiency."

**Mode B output:**

- **Business message:** Management cannot consistently show that higher-value supplier payments received the required independent approval before release.
- **Why it matters:** Clear approval evidence protects cash, confirms spending was authorised, and gives management reliable oversight of significant commitments.
- **What the audit found:** In 4 of 25 sampled payments above the approval threshold, the required Business Head approval record was not in the payment records supplied for review. [FIND-P2P-03; WP-P2P-07; EV-021 to EV-024]
- **Impact or opportunity:** *Supported:* the audit did not identify a confirmed unauthorised payment. *Potential:* incomplete records make later review or investigation harder; amount not quantified, management validation required.
- **What management should do:** Finance should make the approval mandatory in the payment workflow and block release where it is missing. Owner: Finance Controller. Target: 31 December 2026.
- **Expected business benefit:** A complete electronic approval trail improves cash-governance visibility and speeds verification of supplier payments.
- **Decision or oversight required:** Confirm the workflow change is prioritised and whether interim independent review applies until the system block is live.
- **Assurance references:** FIND-P2P-03; WP-P2P-07; CRIT-DOA-02; EV-021 to EV-024.

Note what it does *not* say: it never calls the payments unauthorised, because the sample
showed missing records, not wrongdoing.

### Example 2: finding pasted without references

> "Contract workers at one division were not enrolled in the statutory health scheme for
> eight months; 38 workers affected."

Write the brief normally. The basis line reads `draft finding, not yet approved`, and one line
under it declares *Evidence reference not available — auditor validation required (none supplied;
the sections below are untagged and the Assurance Trail records each missing slot).* Do not repeat
that sentence in every paragraph: a brief that did so carried it nine times and the real gaps
(no exposure amount, no owner, no date, an unverified closure claim) were harder to see. The
Assurance Trail marks each slot "not supplied". State the gaps you noticed as a note rather than
supplying them.

### Example 3: management says it is fixed

> Source says: "Management states all 38 workers were enrolled in March."

Write: *Management representation — not independently verified [MR-###]: all 38 workers
were enrolled in March.* Do not write "the gap has been closed". Closure is an audit
conclusion reached by testing, and until then the finding's status stays Open.
