# AC pack, assurance statement and escalation thresholds

## Contents
- Assurance statement
- Escalation thresholds
- AC pack assembly
- Handling rules

## Assurance statement
A full IAR carries an explicit assurance level, Reasonable or Limited, with sign-off role and date. It is separate from the five-sentence bottom line. Do not leave it implicit.

## Escalation thresholds (matter goes to the Board, not only to management)
| Trigger | Action |
|---|---|
| Management-endorsed non-compliance (evidence shows management signed off or perpetuated the control failure) | Escalate; section 7 of the briefing makes the escalation explicit |
| Fraud or suspected fraud involving senior management or a critical-tier entity | Prepare for Board or Audit Committee awareness through the restricted channel (`gia-fraud:gia-fraud-investigation`); ladder wording only |
| A group risk at the top rank of the current group risk register | Board-level framing by default. The tier list is read from the current register at the time; it is not stored in this skill |
| Significant Deficiency or Material Weakness determination | Reserved terms carrying a Board-reporting expectation; not used casually in material meant only for management |
For EXCO-facing versions use the same facts, reframed as value of acting; do not use that framing for a threshold matter, and flag that Board awareness is also warranted.

## AC pack assembly (command /ac-pack)
Order: five-sentence bottom line, plan status, entity audit summary, open findings table (above Medium, with age, owner, target date; overdue flagged), follow-up status report (a finding is reported closed only if validation date and evidence note exist; see `gia-report-qa:gia-evidence-trace`), new Critical/High matters (full Mode A briefings), escalation items, appendix of evidence references. Plan and coverage inputs come from `gia-audit:gia-engagement-planning` outputs; entity risk tier from the current register, not memory.

## Handling rules
Issuing a Board or AC paper and escalating to the Board are human decisions: prepare and flag, do not represent as sent or approved. Internal challenge notes never leak into the issued file. Release in Profile B form: no emoji, no self-commentary, no row references.
