# Executive Dashboard Views

Five views, each filled only from approved register data or `brief_data.py` output. A cell
with no supporting data is left blank or written "not assessed". Never fill a cell so the
table looks complete.

## Contents
1. Overall assurance position
2. Value-at-risk
3. Priority actions
4. Root themes
5. Closure and benefit
6. Audit Value Delivered (report-level)
7. Source map

---

## 1. Overall assurance position

| Area | Assurance status | Main leadership message | Trend |
|---|---|---|---|

- *Assurance status* comes from the approved engagement conclusion for that area. Do not
  derive a status from counting findings. Define the scale used (for example Satisfactory /
  Needs improvement / Unsatisfactory) in a footnote.
- *Trend* needs a prior-period position in the register or earlier reports. No prior period:
  write "not assessed".
- A colour may accompany the status only if its basis is stated. The message is the content;
  the colour is decoration.

## 2. Value-at-risk

| Value area | Exposure or opportunity | Evidence basis | Management action |
|---|---|---|---|

Value areas: cash, margin, working capital, compliance standing, decision quality, customer
delivery, safety, inventory. Use a quantified exposure only if the approved finding
quantifies it. Otherwise use a qualitative category and the words "not quantified;
management validation required". The evidence basis column carries WP and FIND IDs.

## 3. Priority actions

| Priority | Business issue | Executive sponsor | Action owner | Due date | Status | Escalation required |
|---|---|---|---|---|---|---|

- Priority is the approved rating.
- Owner, due date and status come from the Actions sheet. Overdue means due date earlier than
  today and status not "Closed - validated"; `brief_data.py` computes this.
- *Executive sponsor* and *Escalation required* are decisions: propose, mark as proposed,
  and let the auditor or CAE confirm.

## 4. Root themes

| Theme | What it means | Leadership implication |
|---|---|---|

Two or more approved findings must show the theme; list their FIND IDs. Candidate themes seen
in practice: incomplete evidence and audit trails; manual-process dependency; weak
action-closure discipline; inconsistent data ownership; limited cross-functional
accountability. These are prompts, not a menu to fill.

## 5. Closure and benefit

| Action | Closure evidence | Benefit measure | Audit validation |
|---|---|---|---|

Status "closed" is not a benefit. Every action needs a measure the business can observe (for
example "100% of post-go-live high-value payments carry an approval trail") and the test
Internal Audit will perform. Where the register has no benefit measure, write "Expected
benefit to be confirmed by management during action planning."

## 6. Audit Value Delivered (report-level)

A short table for the front of a director report so it does not read as a compliance scorecard.

| Value dimension | What directors should see | Evidence basis |
|---|---|---|
| Value protected | Cash, inventory, assets, data, customer commitments, compliance standing, continuity protected by the proposed actions | Approved findings and impact |
| Value created | Simplification, automation, faster approvals, less rework, better visibility | Management-approved action plan or supported analysis |
| Risk reduced | Key risk reduced and what remains after the action | Approved rating and control design |
| Decision required | Funding, policy approval, ownership, priority conflict, direction | Action plan and governance discussion |
| Action progress | Open, overdue, on track, closed, closure validated | Action tracker and closure workpaper |
| Assurance coverage | What was tested, key limitations, what was not covered | Scope and workpaper summary |

"Value protected" describes what the *proposed actions* would protect; it is not a claim that a
loss was avoided unless a finding quantifies one.

## 7. Source map

| View | Register source |
|---|---|
| 1 | Approved engagement conclusion (not in the register by default; ask) |
| 2 | Findings: Evidenced impact, Potential impact; Workpapers |
| 3 | Findings and Actions |
| 4 | Findings (theme judgement by the auditor) |
| 5 | Actions: Closure evidence, Benefit measure, Validation WP ID |
| 6 | Dashboard sheet plus the above |
