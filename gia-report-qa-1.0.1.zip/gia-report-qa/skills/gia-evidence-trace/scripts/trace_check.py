#!/usr/bin/env python3
"""Cross-check an Assurance Trace Register (and optionally reports) for traceability breaks.

Usage:
    python3 trace_check.py --register Register.xlsx [--report r1.md r2.docx ...]
                           [--source finding.md] [--allow-draft] [--json out.json]

Exit code: 0 = no ERROR; 1 = at least one ERROR; 2 = could not run (file missing, unreadable,
not an .xlsx, missing dependency). A register with no data at all is an ERROR, not a pass.

What this does and does not do
  * Register checks are deterministic: dangling IDs, duplicate IDs, R5 evidence behind a
    finding, approved findings without an approver, High/Critical findings without owner/date,
    arithmetic that cannot be true (sample > population), one-way WP<->FIND links, "Closed -
    validated" actions with no validation workpaper (R12), status values outside the controlled
    list (R13), rows with content but no ID (R14), dates stored as text (R15), approved findings
    resting only on R4 evidence (R16), an empty register (R17).
  * Report checks are deterministic for IDs (cited but not in the register; cited finding not
    approved) and for "X of Y" figures that disagree with the cited workpaper.
  * "Possible untraced statement" (a paragraph with a figure but no reference) is a HEURISTIC.
    It flags for a human to look; it cannot prove a sentence is unsupported or supported.
"""
import argparse
import datetime as dt
import difflib
import json
import os
import re
import sys
from collections import defaultdict

from openpyxl import load_workbook

TYPES = ("EV", "CRIT", "PROC", "WP", "EXC", "FIND", "MR", "CE", "GAP", "ACT")
TYPE_ALT = "|".join(TYPES)
ID_RE = re.compile(rf"\b(?P<t>{TYPE_ALT})-(?:(?P<a>[A-Z][A-Z0-9]{{1,5}})-)?(?P<n>\d{{2,4}})(?P<s>[a-z]?)\b")
RANGE_RE = re.compile(
    rf"\b(?P<t>{TYPE_ALT})-(?:(?P<a>[A-Z][A-Z0-9]{{1,5}})-)?(?P<n1>\d{{2,4}})\s*"
    rf"(?:(?:to|–|—)\s*(?P=t)-(?:(?P=a)-)?(?P<n2>\d{{2,4}})|[–—]\s*(?P<n2b>\d{{2,4}})(?!\s+[A-Za-z]))\b")

BARE_TO_RE = re.compile(rf"\b(?:{TYPE_ALT})-(?:[A-Z][A-Z0-9]{{1,5}}-)?\d{{2,4}}\s+to\s+\d")

MATERIAL_RES = [
    re.compile(r"(?:₹|RM|USD|MXN|\$|€|£)\s?\d"),
    re.compile(r"\d[\d,.]*\s?(?:lakh|lakhs|crore|crores|million|billion|mn|bn)\b", re.I),
    re.compile(r"\b\d+(?:\.\d+)?\s?%"),
    re.compile(r"\b\d+\s+of\s+\d+\b", re.I),
    re.compile(r"\b\d{1,3}(?:,\d{3})+\b"),
]
XOFY_RE = re.compile(r"\b(\d+)\s+of\s+(\d+)\b", re.I)
GAP_PHRASE = "evidence reference not available"

# Controlled vocabularies. Must match the dropdowns in build_register_workbook.py
# (tests/selftest.py asserts they do, so the two cannot drift apart silently).
FIND_STATUSES = ("Draft", "Auditor-approved", "CAE-approved", "Withdrawn")
APPROVED_STATUSES = ("Auditor-approved", "CAE-approved")
RATINGS = ("Critical", "High", "Medium", "Low")
ACT_STATUSES = ("Not started", "In progress", "Delayed", "Closed - pending validation",
                "Closed - validated", "Closed - not effective", "Risk accepted")
LOOSE_REF_RE = re.compile(r"\b(?:EV|CRIT|PROC|WP|EXC|FIND|MR|CE|GAP|ACT)-[A-Za-z0-9]+(?:-[A-Za-z0-9]+)?\b", re.I)

# sheet -> {logical name: header text}
SCHEMA = {
    "Evidence": {"id": "EV ID", "grade": "Reliability (R1-R5)"},
    "Criteria": {"id": "CRIT ID"},
    "Procedures": {"id": "PROC ID", "crit": "Linked CRIT IDs"},
    "Workpapers": {"id": "WP ID", "proc": "PROC ID", "ev": "Evidence IDs", "pop": "Population size",
                   "sample": "Sample size", "exc": "Exceptions found",
                   "links": "Linked FIND IDs / reason no finding",
                   "reviewer": "Reviewed by", "reviewed_on": "Reviewed on"},
    "Exceptions_Gaps": {"id": "Item ID", "type": "Type", "wp": "WP ID", "status": "Status"},
    "Findings": {"id": "FIND ID", "crit": "CRIT IDs", "wp": "WP IDs", "ev": "EV IDs",
                 "rating": "Rating", "status": "Approval status", "approver": "Approved by",
                 "approved_on": "Approved on", "owner": "Owner", "target": "Target date"},
    "Mgmt_Responses": {"id": "MR ID", "find": "FIND ID"},
    "Actions": {"id": "ACT ID", "find": "FIND ID", "ev": "Closure evidence EV IDs",
                "wp": "Validation WP ID", "status": "Status", "validated": "Validated (Y/N)",
                "target": "Target date", "ra_by": "Risk accepted by", "ra_on": "Risk accepted on"},
}


# ----------------------------------------------------------------------------- helpers
def canon(t, a, n, s=""):
    return f"{t}-{a + '-' if a else ''}{n}{s}"


def extract_ids(text):
    """All IDs in text, with 'EV-021 to EV-024' / 'EV-021–024' ranges expanded."""
    if not text:
        return []
    text = str(text)
    out, spans = [], []
    for m in RANGE_RE.finditer(text):
        n1, n2 = m.group("n1"), (m.group("n2") or m.group("n2b"))
        lo, hi = int(n1), int(n2)
        spans.append(m.span())
        if lo <= hi and hi - lo <= 200:
            for k in range(lo, hi + 1):
                out.append(canon(m.group("t"), m.group("a"), str(k).zfill(len(n1))))
        else:
            out.append(canon(m.group("t"), m.group("a"), n1))
            out.append(canon(m.group("t"), m.group("a"), n2))
    for m in ID_RE.finditer(text):
        if any(s <= m.start() < e for s, e in spans):
            continue
        out.append(canon(m.group("t"), m.group("a"), m.group("n"), m.group("s")))
    return out


def blank(v):
    return v is None or str(v).strip() == ""


class Report:
    def __init__(self):
        self.items = []

    def add(self, sev, code, where, msg):
        self.items.append({"severity": sev, "code": code, "where": where, "message": msg})

    def count(self, sev):
        return sum(1 for i in self.items if i["severity"] == sev)


def read_sheet(wb, name, cols, rep):
    """Return list of row dicts keyed by logical name, reading columns by header text."""
    if name not in wb.sheetnames:
        rep.add("ERROR", "R00", name, f"sheet '{name}' not found in register")
        return []
    ws = wb[name]
    headers = {str(c.value).strip(): i for i, c in enumerate(ws[1]) if c.value is not None}
    idx = {}
    for key, header in cols.items():
        if header not in headers:
            rep.add("ERROR", "R00", name, f"column '{header}' not found (register template changed?)")
        else:
            idx[key] = headers[header]
    rows = []
    for r in range(2, ws.max_row + 1):
        vals = {k: ws.cell(r, i + 1).value for k, i in idx.items()}
        if blank(vals.get("id")):
            # content in any typed (non-formula) cell but no ID: would otherwise vanish silently
            if any(not blank(c.value) and not str(c.value).startswith("=") for c in ws[r]):
                rep.add("WARN", "R14", f"{name}!row {r}",
                        "row has content but no ID, so it is ignored by every check and by the brief: add an ID or clear the row")
            continue
        vals["_row"] = r
        rows.append(vals)
    return rows


# ----------------------------------------------------------------------------- register
def check_register(path, rep):
    wb = load_workbook(path)           # formulas not needed: we read typed input cells only
    data = {n: read_sheet(wb, n, cols, rep) for n, cols in SCHEMA.items()}

    prefix = {"Evidence": "EV", "Criteria": "CRIT", "Procedures": "PROC", "Workpapers": "WP",
              "Findings": "FIND", "Mgmt_Responses": "MR", "Actions": "ACT"}
    ids = defaultdict(set)
    for sheet, rows in data.items():
        seen = set()
        for row in rows:
            rid = str(row["id"]).strip()
            m = ID_RE.fullmatch(rid)
            where = f"{sheet}!row {row['_row']}"
            if not m:
                rep.add("ERROR", "R02", where, f"'{rid}' is not a valid ID (format TYPE-NN or TYPE-AREA-NN)")
                continue
            if sheet in prefix and m.group("t") != prefix[sheet]:
                rep.add("ERROR", "R02", where, f"'{rid}' is a {m.group('t')} ID on the {sheet} sheet")
            if sheet == "Exceptions_Gaps" and m.group("t") not in ("EXC", "CE", "GAP"):
                rep.add("ERROR", "R02", where, f"'{rid}' must be EXC, CE or GAP")
            if rid in seen:
                rep.add("ERROR", "R01", where, f"duplicate ID {rid}")
            seen.add(rid)
            ids[m.group("t")].add(rid)
            row["_id"] = rid

    all_ids = set().union(*ids.values()) if ids else set()
    if not any(data.values()):
        rep.add("ERROR", "R17", "register",
                "register contains no data rows (blank template?): there is nothing to check, so this is not a pass")
    elif not data["Findings"]:
        rep.add("WARN", "R17", "Findings", "register has evidence or workpapers but no findings")
    ev_grade = {str(r["id"]).strip(): str(r.get("grade") or "").strip().upper() for r in data["Evidence"]}

    for r in data["Evidence"]:
        g = str(r.get("grade") or "").strip().upper()
        if g not in {"R1", "R2", "R3", "R4", "R5"}:
            rep.add("WARN", "R05", f"Evidence!row {r['_row']}",
                    f"{r['id']} has no valid R1-R5 grade ('{g or 'blank'}')")

    def dangling(row, sheet, key, expect_types):
        if ";" in str(row.get(key) or ""):
            rep.add("WARN", "R18", f"{sheet}!row {row['_row']}",
                    f"{row['id']}: list uses ';' as a separator. The scripts read it, but the workbook's Trace_Matrix "
                    f"counts commas and will show a broken trace: use commas")
        if BARE_TO_RE.search(str(row.get(key) or "")):
            rep.add("WARN", "R18", f"{sheet}!row {row['_row']}",
                    f"{row['id']}: a range such as 'EV-021 to 024' is ambiguous and is read as ONE ID. "
                    f"Write the full end ID ('EV-021 to EV-024') or list each ID")
        for ref in extract_ids(row.get(key)):
            t = ref.split("-")[0]
            if t not in expect_types:
                rep.add("ERROR", "R04", f"{sheet}!row {row['_row']}",
                        f"{row['id']}: '{ref}' is a {t} ID but this column expects {'/'.join(expect_types)}")
            elif ref not in all_ids:
                rep.add("ERROR", "R04", f"{sheet}!row {row['_row']}",
                        f"{row['id']} cites {ref}, which is not in the register (dangling reference)")

    for r in data["Procedures"]:
        dangling(r, "Procedures", "crit", ("CRIT",))
    for r in data["Workpapers"]:
        dangling(r, "Workpapers", "ev", ("EV",))
        dangling(r, "Workpapers", "proc", ("PROC",))
        dangling(r, "Workpapers", "links", ("FIND",))
        for k in ("pop", "sample", "exc"):
            v = r.get(k)
            if not blank(v) and not isinstance(v, (int, float)):
                rep.add("WARN", "R10", f"Workpapers!row {r['_row']}", f"{r['id']}: '{k}' is not a number ({v!r})")
        pop, smp, exc = (r.get(k) for k in ("pop", "sample", "exc"))
        if all(isinstance(x, (int, float)) for x in (pop, smp)) and smp > pop:
            rep.add("ERROR", "R10", f"Workpapers!row {r['_row']}", f"{r['id']}: sample ({smp}) exceeds population ({pop})")
        if all(isinstance(x, (int, float)) for x in (smp, exc)) and exc > smp:
            rep.add("ERROR", "R10", f"Workpapers!row {r['_row']}", f"{r['id']}: exceptions ({exc}) exceed sample ({smp})")
        if isinstance(exc, (int, float)) and exc > 0 and blank(r.get("links")):
            rep.add("WARN", "R09", f"Workpapers!row {r['_row']}",
                    f"{r['id']} records {int(exc)} exception(s) but states no linked finding or reason none was raised")
    for r in data["Exceptions_Gaps"]:
        dangling(r, "Exceptions_Gaps", "wp", ("WP",))
    for r in data["Mgmt_Responses"]:
        dangling(r, "Mgmt_Responses", "find", ("FIND",))
    for r in data["Actions"]:
        dangling(r, "Actions", "find", ("FIND",))
        dangling(r, "Actions", "ev", ("EV",))
        dangling(r, "Actions", "wp", ("WP",))

    wp_links = {str(w["id"]).strip(): set(extract_ids(w.get("links"))) for w in data["Workpapers"]}
    mr_by_find = defaultdict(int)
    for m in data["Mgmt_Responses"]:
        mr_by_find[str(m.get("find") or "").strip()] += 1
    act_by_find = defaultdict(int)
    for a in data["Actions"]:
        act_by_find[str(a.get("find") or "").strip()] += 1

    def near(value, vocab):
        m = difflib.get_close_matches(value.casefold(), [v.casefold() for v in vocab], n=1, cutoff=0.7)
        return next((v for v in vocab if v.casefold() == m[0]), None) if m else None

    def is_date(v):
        return isinstance(v, (dt.date, dt.datetime))

    findings = {}
    finding_rows = {}
    for f in data["Findings"]:
        fid = str(f["id"]).strip()
        finding_rows[fid] = f
        status = str(f.get("status") or "").strip()
        approved = status in APPROVED_STATUSES
        if status not in FIND_STATUSES:
            hint = near(status, FIND_STATUSES) if status else None
            rep.add("WARN", "R13", f"Findings!row {f['_row']}",
                    f"{fid}: approval status '{status or 'blank'}' is not one of {', '.join(FIND_STATUSES)}; "
                    f"treated as NOT approved" + (f" (did you mean '{hint}'?)" if hint else ""))
        for dkey, dlabel in (("target", "Target date"), ("approved_on", "Approved on")):
            v = f.get(dkey)
            if not blank(v) and not is_date(v):
                rep.add("WARN", "R15", f"Findings!row {f['_row']}",
                        f"{fid}: {dlabel} '{v}' is text, not a date: it cannot be used for overdue checks")
        rating_raw = str(f.get("rating") or "").strip()
        rating = next((r for r in RATINGS if r.casefold() == rating_raw.casefold()), rating_raw)
        if rating_raw and rating not in RATINGS:
            rep.add("WARN", "R13", f"Findings!row {f['_row']}",
                    f"{fid}: rating '{rating_raw}' is not one of {', '.join(RATINGS)}; High/Critical checks cannot run for it")
        elif rating_raw != rating:
            rep.add("WARN", "R13", f"Findings!row {f['_row']}", f"{fid}: rating '{rating_raw}' should be written '{rating}'")
        findings[fid] = {"status": status, "approved": approved, "rating": rating}
        where = f"Findings!row {f['_row']}"
        dangling(f, "Findings", "crit", ("CRIT",))
        dangling(f, "Findings", "wp", ("WP",))
        dangling(f, "Findings", "ev", ("EV",))
        missing = [lbl for key, lbl in (("crit", "criteria"), ("wp", "workpaper"), ("ev", "evidence"))
                   if not extract_ids(f.get(key))]
        if missing:
            rep.add("ERROR" if approved else "WARN", "R03", where,
                    f"{fid} ({status or 'no status'}) cites no {', no '.join(missing)}")
        if approved and (blank(f.get("approver")) or blank(f.get("approved_on"))):
            rep.add("ERROR", "R06", where, f"{fid} is {status} but approver or approval date is blank")
        for ref in extract_ids(f.get("ev")):
            if ev_grade.get(ref) == "R5":
                rep.add("ERROR" if approved else "WARN", "R05", where,
                        f"{fid} cites {ref}, graded R5 (verbal / unverified). R5 evidence may not support a finding")
        graded = [ev_grade.get(ref) for ref in extract_ids(f.get("ev")) if ev_grade.get(ref) in {"R1", "R2", "R3", "R4"}]
        if approved and graded and all(g == "R4" for g in graded):
            rep.add("WARN", "R16", where,
                    f"{fid} rests only on R4 evidence (management-provided or not independently verified): "
                    f"confirm corroboration is on file before it is relied on")
        for ref in extract_ids(f.get("wp")):
            if ref in wp_links and fid not in wp_links[ref]:
                rep.add("WARN", "R08", where, f"{fid} cites {ref} but that workpaper does not link back to {fid}")
        if approved and rating in ("High", "Critical"):
            if blank(f.get("owner")) or blank(f.get("target")):
                rep.add("ERROR", "R07", where, f"{fid} is {rating} and approved but owner or target date is blank")
            if mr_by_find.get(fid, 0) == 0:
                rep.add("WARN", "R07", where, f"{fid} ({rating}) has no management response recorded")
            if act_by_find.get(fid, 0) == 0:
                rep.add("WARN", "R07", where, f"{fid} ({rating}) has no action in the tracker")
    # ---- S2 gate: a workpaper that supports an approved finding needs a reviewer, or must say it is unreviewed
    approved_wps = set()
    for f in data["Findings"]:
        if str(f.get("status") or "").strip() in APPROVED_STATUSES:
            approved_wps.update(extract_ids(f.get("wp")))
    for w in data["Workpapers"]:
        wid = str(w["id"]).strip()
        if wid in approved_wps and blank(w.get("reviewer")):
            rep.add("WARN", "R20", f"Workpapers!row {w['_row']}",
                    f"{wid} supports an approved finding but has no reviewer recorded: record 'Reviewed by' and date, "
                    f"or write 'UNREVIEWED' in Reviewed by so the gap is visible to the approver")
        elif wid in approved_wps and str(w.get("reviewer")).strip().upper() == "UNREVIEWED":
            rep.add("WARN", "R20", f"Workpapers!row {w['_row']}",
                    f"{wid} supports an approved finding and is marked UNREVIEWED: confirm the approver accepted this")
    # ---- action tracker: closure must be backed by a validation workpaper (Iron Rule: closure is tested)
    for a in data["Actions"]:
        aid = str(a["id"]).strip()
        where = f"Actions!row {a['_row']}"
        status = str(a.get("status") or "").strip()
        if status and status not in ACT_STATUSES:
            hint = near(status, ACT_STATUSES)
            rep.add("WARN", "R13", where,
                    f"{aid}: status '{status}' is not one of the seven defined statuses"
                    + (f" (did you mean '{hint}'?)" if hint else ""))
        if not blank(a.get("target")) and not is_date(a.get("target")):
            rep.add("WARN", "R15", where, f"{aid}: Target date '{a.get('target')}' is text, not a date: overdue status cannot be computed")
        yn = str(a.get("validated") or "").strip().upper()
        fnd0 = str(a.get("find") or "").strip()
        if fnd0 in findings and findings[fnd0]["status"] == "Withdrawn":
            rep.add("WARN", "R12", where, f"{aid}: action belongs to {fnd0}, which is Withdrawn: close or remove it")
        if status == "Risk accepted" and (blank(a.get("ra_by")) or blank(a.get("ra_on"))):
            rep.add("ERROR", "R19", where,
                    f"{aid} is 'Risk accepted' but the accepting authority or acceptance date is blank: "
                    f"an unowned risk acceptance is not a closure")
        if status == "Closed - validated":
            vwp = extract_ids(a.get("wp"))
            if not vwp:
                rep.add("ERROR", "R12", where,
                        f"{aid} is 'Closed - validated' but names no validation workpaper: closure must come from a tested workpaper, not an assertion")
            fnd = str(a.get("find") or "").strip()
            own = set(extract_ids(finding_rows[fnd].get("wp"))) if fnd in finding_rows else set()
            if vwp and set(vwp) <= own:
                rep.add("WARN", "R12", where,
                        f"{aid}: validation workpaper {', '.join(vwp)} is the finding's own original test workpaper; "
                        f"closure needs a separate re-test workpaper")
            if fnd in findings and not findings[fnd]["approved"]:
                rep.add("ERROR", "R12", where, f"{aid} is validated-closed against {fnd}, which is not an approved finding")
            cev = extract_ids(a.get("ev"))
            if not cev:
                rep.add("WARN", "R12", where, f"{aid} is 'Closed - validated' but records no closure evidence (EV ID)")
            elif any(ev_grade.get(e) == "R5" for e in cev):
                rep.add("ERROR", "R12", where, f"{aid}: closure evidence includes R5 (verbal) evidence")
            elif all(ev_grade.get(e) == "R4" for e in cev):
                rep.add("WARN", "R12", where, f"{aid}: closure evidence is R4 only (owner-supplied): confirm independent corroboration")
            if yn == "N":
                rep.add("WARN", "R12", where, f"{aid}: status is 'Closed - validated' but 'Validated (Y/N)' says N")
        elif yn == "Y":
            rep.add("WARN", "R12", where, f"{aid}: 'Validated (Y/N)' says Y but status is '{status or 'blank'}'")
    for wid, links in wp_links.items():
        for fid in links:
            if fid in finding_rows:
                if wid not in set(extract_ids(finding_rows[fid].get("wp"))):
                    rep.add("WARN", "R08", f"Workpapers/{wid}", f"{wid} links to {fid} but {fid} does not cite {wid}")
    for g in data["Exceptions_Gaps"]:
        gtype = str(g.get("type") or "").strip().upper()
        if gtype in ("GAP", "CE") and str(g.get("status") or "").strip().casefold() == "open":
            gwps = set(extract_ids(g.get("wp")))
            hit = [fid for fid, info in findings.items()
                   if info["approved"] and gwps & set(extract_ids(finding_rows[fid].get("wp")))]
            if hit:
                kind = "evidence gap" if gtype == "GAP" else "contradictory-evidence item"
                rep.add("INFO", "R11", f"Exceptions_Gaps!row {g['_row']}",
                        f"open {kind} {g['id']} on {', '.join(sorted(gwps))} affects approved finding(s): {', '.join(hit)}")
    return data, all_ids, findings


# ----------------------------------------------------------------------------- reports
class ReadError(Exception):
    pass


def read_text(path):
    if not os.path.isfile(path):
        raise ReadError("file not found")
    low = path.lower()
    if low.endswith(".docx"):
        try:
            import docx
        except ImportError:
            raise ReadError("python-docx is not installed (pip install python-docx), or export the report to .md/.txt")
        try:
            d = docx.Document(path)
        except Exception as e:  # corrupt or not really a docx
            raise ReadError(f"cannot open as .docx ({e.__class__.__name__})")
        from docx.table import Table
        from docx.text.paragraph import Paragraph
        parts = []
        for child in d.element.body.iterchildren():      # document order: tables stay where they are
            if child.tag.endswith("}p"):
                para = Paragraph(child, d)
                sname = (para.style.name if para.style is not None else "") or ""
                # Word heading styles become markdown headings so section rules (e.g. the Board
                # message exemption) end where the next heading starts.
                parts.append(("# " + para.text) if sname.lower().startswith(("heading", "title")) and para.text.strip() else para.text)
            elif child.tag.endswith("}tbl"):
                for row in Table(child, d).rows:
                    parts.append(" | ".join(c.text for c in row.cells))
        return "\n\n".join(parts)
    if low.endswith((".pdf", ".xlsx", ".pptx", ".doc")):
        raise ReadError("unsupported format: export the report to .docx, .md or .txt and check that")
    try:
        with open(path, encoding="utf-8") as fh:
            return fh.read()
    except UnicodeDecodeError:
        raise ReadError("not UTF-8 text (binary file?): export the report to .docx, .md or .txt")


NUM_RE = re.compile(r"\d[\d,]*(?:\.\d+)?")


def numbers_in(text):
    text = LOOSE_REF_RE.sub(" ", ID_RE.sub(" ", text))
    out = set()
    for m in NUM_RE.finditer(text):
        tok = m.group(0).rstrip(",").replace(",", "")
        if len(tok) >= 2 or "." in tok:
            out.add(tok)
    return out


def check_report(path, rep, all_ids, findings, data, allow_draft, source_nums=None):
    name = os.path.basename(path)
    try:
        text = read_text(path)
    except ReadError as e:
        rep.add("ERROR", "P00", name, f"report could not be checked: {e}")
        return
    cited = set(extract_ids(text))
    loose = {m.group(0) for m in LOOSE_REF_RE.finditer(text)
             if re.search(r"\d", m.group(0)) and not ID_RE.fullmatch(m.group(0))}
    for tok in sorted(loose):
        rep.add("WARN", "P07", name,
                f"'{tok}' looks like a reference but is not a valid ID (IDs are upper case, TYPE-NN or TYPE-AREA-NN, "
                f"e.g. FIND-P2P-03): it was NOT matched against the register")
    for ref in sorted(cited):
        if ref not in all_ids:
            rep.add("ERROR", "P01", name, f"cites {ref}, which is not in the register")
    for ref in sorted(cited):
        if ref.startswith("FIND-") and ref in findings:
            info = findings[ref]
            if info["status"] == "Withdrawn":
                rep.add("ERROR", "P03", name, f"cites {ref}, which is Withdrawn")
            elif not info["approved"]:
                rep.add("WARN" if allow_draft else "ERROR", "P02", name,
                        f"cites {ref}, status '{info['status'] or 'blank'}': not approved for reporting")

    # A document that cites no register ID at all AND says so near the top is declared untraced
    # (typical for a draft brief built from a raw finding). That is reported once (P08) instead of
    # as a P04 warning on every figure; any document that cites even one ID is checked paragraph by
    # paragraph as before.
    if source_nums is not None:
        extra = sorted(numbers_in(text) - source_nums)
        if extra:
            rep.add("WARN", "P10", name,
                    f"{len(extra)} figure(s) appear in the report but not in the source finding: "
                    f"{', '.join(extra[:10])}{' ...' if len(extra) > 10 else ''}. "
                    f"Each must be traced to the source or removed (invented or derived figure?)")
    declared_untraced = (not cited) and GAP_PHRASE in text.lower()[:2500]
    if declared_untraced:
        rep.add("WARN", "P08", name,
                "document cites no register ID and declares that evidence references are not available: "
                "acceptable for a draft, but it must not be issued until references are added")
    wp_nums = {str(w["id"]).strip(): (w.get("exc"), w.get("sample")) for w in data.get("Workpapers", [])}
    paras = [p for p in re.split(r"\n\s*\n", text) if p.strip()]
    prev_heading = ""
    acknowledged = 0
    for p in paras:
        stripped = p.strip()
        lines = stripped.splitlines()
        first = lines[0]
        is_heading = first.lstrip().startswith("#") or (
            len(lines) == 1 and re.match(r"^\W*\d?\.?\s*[A-Z][A-Z &:'\-]{6,}$", first))
        if is_heading:
            prev_heading = first.upper()
            if len(lines) == 1 and not any(rx.search(first) for rx in MATERIAL_RES):
                continue
        ids_here = set(extract_ids(p))
        if "BOARD-LEVEL MESSAGE" in prev_heading:
            continue                    # read-aloud paragraph: tags live in sections 1-6 by design
        material = any(rx.search(p) for rx in MATERIAL_RES)
        if declared_untraced:
            continue
        if GAP_PHRASE in p.lower():
            acknowledged += 1
            continue
        if material and not ids_here:
            snippet = " ".join(stripped.split())[:110]
            rep.add("WARN", "P04", name, f"possible untraced statement (figure, no reference): \"{snippet}...\"")
        cited_wps = [i for i in ids_here if i.startswith("WP-") and i in wp_nums]
        if cited_wps:
            pairs = {(int(x), int(y)) for x, y in XOFY_RE.findall(p)}
            if pairs:
                reg = {(int(e), int(s)) for e, s in (wp_nums[w] for w in cited_wps)
                       if isinstance(e, (int, float)) and isinstance(s, (int, float))}
                for pr in pairs:
                    if reg and pr not in reg:
                        rep.add("WARN", "P05", name,
                                f"'{pr[0]} of {pr[1]}' does not match cited workpaper(s) "
                                f"{', '.join(sorted(cited_wps))} (register says "
                                f"{', '.join(f'{a} of {b}' for a, b in sorted(reg))})")
    if acknowledged:
        rep.add("INFO", "P06", name, f"{acknowledged} paragraph(s) carry the 'evidence reference not available' wording: auditor validation still open")
    for fid, info in findings.items():
        if info["approved"] and info["rating"] in ("High", "Critical") and fid not in cited:
            rep.add("INFO", "P09", name, f"approved {info['rating']} finding {fid} is not mentioned in this report")


# ----------------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--register", required=True)
    ap.add_argument("--report", nargs="*", default=[])
    ap.add_argument("--source", help="the source finding text (.md/.txt/.docx): any figure in a report that is not in it is flagged (P10)")
    ap.add_argument("--allow-draft", action="store_true", help="downgrade 'cites unapproved finding' to a warning")
    ap.add_argument("--json", help="write full results to this file")
    a = ap.parse_args()

    rep = Report()
    if not os.path.isfile(a.register):
        print(f"cannot run: register not found: {a.register}", file=sys.stderr); sys.exit(2)
    try:
        data, all_ids, findings = check_register(a.register, rep)
    except Exception as e:  # BadZipFile, InvalidFileException, PermissionError ...
        print(f"cannot run: '{a.register}' could not be opened as an .xlsx register ({e.__class__.__name__}: {e})", file=sys.stderr)
        sys.exit(2)
    source_nums = None
    if a.source:
        try:
            source_nums = numbers_in(read_text(a.source))
        except ReadError as e:
            print(f"cannot run: --source {a.source}: {e}", file=sys.stderr)
            sys.exit(2)
    for path in a.report:
        check_report(path, rep, all_ids, findings, data, a.allow_draft, source_nums)

    order = {"ERROR": 0, "WARN": 1, "INFO": 2}
    for i in sorted(rep.items, key=lambda x: (order[x["severity"]], x["code"], x["where"])):
        print(f"{i['severity']:5} {i['code']} {i['where']}: {i['message']}")
    e, w, n = rep.count("ERROR"), rep.count("WARN"), rep.count("INFO")
    print(f"\nSummary: {e} error(s), {w} warning(s), {n} info. Findings checked: {len(findings)}; reports: {len(a.report)}")
    if a.report or any(i["code"] == "P04" for i in rep.items):
        print("Note: P04 is a heuristic. It flags sentences with a figure and no reference ID; it cannot tell whether the "
              "statement is true, and a flagged sentence may be correctly sourced elsewhere in the report.")
    if a.json:
        with open(a.json, "w") as fh:
            json.dump({"summary": {"errors": e, "warnings": w, "info": n}, "items": rep.items}, fh, indent=2)
    sys.exit(1 if e else 0)


if __name__ == "__main__":
    main()
