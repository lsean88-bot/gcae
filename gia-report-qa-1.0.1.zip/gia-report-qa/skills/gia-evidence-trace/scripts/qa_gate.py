#!/usr/bin/env python3
"""Pre-issue QA gate record, tied to the exact bytes of the report and register.

  qa_gate.py record --register R.xlsx --report REPORT --reviewer reviewed|not-run [--source SRC] [--allow-draft]
      Runs trace_check (and jargon_scan if present), then writes REPORT.qa.json holding the
      SHA-256 of the report and the register, both exit codes, and the reviewer declaration.
  qa_gate.py verify --register R.xlsx --report REPORT
      Exit 0 only if the record exists, the files are byte-identical to what was checked,
      trace_check exited 0, the reviewer step is declared 'reviewed', and nothing is stale.

The reviewer value is an attestation made by whoever runs the command; this script cannot
prove that an independent read happened. It does prove that the report was not changed after
the checks and that the checks themselves passed. Exit codes: 0 pass, 1 gate not passed,
2 could not run.
"""
import argparse, datetime as dt, hashlib, json, os, subprocess, sys

HERE = os.path.dirname(os.path.abspath(__file__))
TRACE = os.path.join(HERE, "trace_check.py")
JARGON = os.path.join(HERE, "..", "..", "gia-board-brief", "scripts", "jargon_scan.py")


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("mode", choices=["record", "verify"])
    ap.add_argument("--register", required=True)
    ap.add_argument("--report", required=True)
    ap.add_argument("--reviewer", choices=["reviewed", "not-run"], default="not-run")
    ap.add_argument("--source")
    ap.add_argument("--allow-draft", action="store_true")
    a = ap.parse_args()
    for p in (a.register, a.report):
        if not os.path.exists(p):
            print(f"cannot run: not found: {p}", file=sys.stderr); sys.exit(2)
    rec_path = a.report + ".qa.json"

    if a.mode == "record":
        cmd = [sys.executable, TRACE, "--register", a.register, "--report", a.report]
        if a.source: cmd += ["--source", a.source]
        if a.allow_draft: cmd += ["--allow-draft"]
        t = subprocess.run(cmd, capture_output=True, text=True)
        j = None
        if os.path.exists(JARGON):
            j = subprocess.run([sys.executable, JARGON, a.report], capture_output=True, text=True)
        rec = {"checked_at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
               "report_sha256": sha(a.report), "register_sha256": sha(a.register),
               "trace_check_exit": t.returncode, "allow_draft": bool(a.allow_draft),
               "jargon_scan_ran": j is not None, "reviewer": a.reviewer,
               "reviewer_note": "attestation by the person running this command; not machine-verified"}
        with open(rec_path, "w") as fh:
            json.dump(rec, fh, indent=2)
        print(t.stdout.strip()[-1500:])
        print(f"record written: {rec_path}")
        print("run 'qa_gate.py verify' to learn whether the gate is passed")
        sys.exit(2 if t.returncode == 2 else 0)

    if not os.path.exists(rec_path):
        print("GATE NOT PASSED: no QA record. Run 'record' first.", file=sys.stderr); sys.exit(1)
    try:
        rec = json.load(open(rec_path))
    except Exception:
        print("GATE NOT PASSED: QA record unreadable.", file=sys.stderr); sys.exit(1)
    problems = []
    if sha(a.report) != rec.get("report_sha256"):
        problems.append("report changed after the checks: re-run record")
    if sha(a.register) != rec.get("register_sha256"):
        problems.append("register changed after the checks: re-run record")
    if rec.get("trace_check_exit") != 0:
        problems.append(f"trace_check exit was {rec.get('trace_check_exit')}, not 0")
    if rec.get("allow_draft"):
        problems.append("checked with --allow-draft: a draft check cannot clear a report for issue")
    if rec.get("reviewer") != "reviewed":
        problems.append("independent reviewer step not declared as done")
    if not rec.get("jargon_scan_ran"):
        problems.append("jargon scan was not run")
    if problems:
        print("GATE NOT PASSED:\n  - " + "\n  - ".join(problems), file=sys.stderr); sys.exit(1)
    print("GATE PASSED: checks passed on these exact files; reviewer step declared done "
          "(attestation). Human approval to issue is still required.")
    sys.exit(0)


if __name__ == "__main__":
    main()
