#!/usr/bin/env python3
"""Import rows from a CSV into a register workbook sheet, mapping the user's column names.

  import_rows.py --workbook R.xlsx --sheet Findings --csv in.csv --map "Their col=Our col" ...  [--out R2.xlsx]

Rules: writes to a COPY unless --out equals --workbook; only input columns are written (never
formula columns); unmapped CSV columns and unknown target headers are reported; rows are appended
below existing data; on the Findings sheet any imported 'Approval status' other than Draft (or
blank) is forced to Draft and reported, because approval is a human act. Exit 0 ok, 2 could not run.
"""
import argparse, csv, sys
from openpyxl import load_workbook

CALC = {"Workpapers": {"Exception rate"}, "Actions": {"Days to due", "Flag", "Closure check"}}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--workbook", required=True)
    ap.add_argument("--sheet", required=True)
    ap.add_argument("--csv", required=True)
    ap.add_argument("--map", nargs="+", action="extend", default=[])  # repeat the flag or list several pairs
    ap.add_argument("--out")
    a = ap.parse_args()
    try:
        wb = load_workbook(a.workbook)
        rows = list(csv.DictReader(open(a.csv, encoding="utf-8-sig")))
    except Exception as e:
        print(f"cannot run: {e.__class__.__name__}: {e}", file=sys.stderr); sys.exit(2)
    if a.sheet not in wb.sheetnames:
        print(f"cannot run: sheet '{a.sheet}' not in workbook ({', '.join(wb.sheetnames)})", file=sys.stderr); sys.exit(2)
    ws = wb[a.sheet]
    headers = [c.value for c in ws[1]]
    mapping = {}
    for m in a.map:
        if "=" not in m:
            print(f"cannot run: bad --map '{m}' (use 'Their col=Our col')", file=sys.stderr); sys.exit(2)
        k, v = m.split("=", 1); mapping[k.strip()] = v.strip()
    src_cols = list(rows[0].keys()) if rows else []
    target = {c: mapping.get(c, c) for c in src_cols}
    unknown = sorted({t for t in target.values() if t not in headers})
    calc = CALC.get(a.sheet, set())
    refused = sorted({t for t in target.values() if t in calc})
    unmapped = sorted(c for c, t in target.items() if t in unknown or t in refused)
    id_col = headers.index(headers[0]) + 1
    first_blank = next((r for r in range(2, ws.max_row + 2) if ws.cell(r, 1).value in (None, "") and not str(ws.cell(r, 1).value or "").startswith("=")), ws.max_row + 1)
    # example rows (grey italic) live in row 2 of a fresh workbook: start after real data
    r = first_blank
    forced = 0
    for row in rows:
        for c, t in target.items():
            if t in unknown or t in refused:
                continue
            v = row[c].strip() if row[c] is not None else ""
            if v == "":
                continue
            if a.sheet == "Findings" and t == "Approval status" and v != "Draft":
                v = "Draft"; forced += 1
            ws.cell(r, headers.index(t) + 1, v)
        r += 1
    out = a.out or a.workbook.replace(".xlsx", "_imported.xlsx")
    wb.save(out)
    print(f"imported {len(rows)} row(s) into {a.sheet} starting at row {first_blank}; saved {out}")
    if unmapped:
        print(f"NOT IMPORTED (unmapped or calculated columns): {', '.join(unmapped)}")
    if forced:
        print(f"{forced} imported approval status value(s) reset to Draft: approval is a human act")
    print("Next: run trace_check on the saved workbook and review every flag before relying on it.")


if __name__ == "__main__":
    main()
