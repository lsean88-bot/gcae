#!/usr/bin/env python3
"""Build the Assurance Trace Register workbook (formula-driven).

Usage:
    python3 build_register_workbook.py --out Register.xlsx --engagement "Name" [--blank]

Sheets: README, Dashboard, Evidence, Criteria, Procedures, Workpapers, Exceptions_Gaps,
Findings, Mgmt_Responses, Actions, Trace_Matrix.

Column headers are part of the contract with trace_check.py and brief_data.py (they read
columns by header name, not position), so change a header in all three places or none.
"""
import argparse
import datetime as dt

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation

FONT = "Arial"
LAST = 500            # input rows prepared on every sheet
TM_LAST = 201         # findings carried into Trace_Matrix (200 findings)

HEAD_FILL = PatternFill("solid", fgColor="1F3864")
HEAD_FONT = Font(name=FONT, bold=True, color="FFFFFF", size=10)
CALC_FILL = PatternFill("solid", fgColor="EDEDED")
INPUT_FONT = Font(name=FONT, color="0000FF", size=10)       # blue = typed input
EXAMPLE_FONT = Font(name=FONT, color="7F7F7F", italic=True, size=10)
CALC_FONT = Font(name=FONT, color="000000", size=10)
THIN = Side(style="thin", color="BFBFBF")
BOX = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

SHEETS = {
    "Evidence": ["EV ID", "Description", "Source", "Evidence date", "Obtained by",
                 "Reliability (R1-R5)", "Limitation", "File / location"],
    "Criteria": ["CRIT ID", "Criterion (plain language)", "Authority / source", "Effective date",
                 "Applies to", "Verified by", "Verified on"],
    "Procedures": ["PROC ID", "Audit objective", "Risk addressed", "Procedure", "Population",
                   "Sample basis", "Linked CRIT IDs", "Performed by"],
    "Workpapers": ["WP ID", "Title", "PROC ID", "Evidence IDs", "Population size", "Sample size",
                   "Exceptions found", "Exception rate", "Result", "Conclusion boundary",
                   "Prepared by", "Prepared on", "Reviewed by", "Reviewed on",
                   "Linked FIND IDs / reason no finding"],
    "Exceptions_Gaps": ["Item ID", "Type", "WP ID", "Description", "Status", "Resolution"],
    "Findings": ["FIND ID", "Title", "Business-language title", "Condition", "CRIT IDs", "WP IDs",
                 "EV IDs", "Approved cause", "Evidenced impact", "Potential impact", "Rating",
                 "Approval status", "Approved by", "Approved on", "Owner", "Target date"],
    "Mgmt_Responses": ["MR ID", "FIND ID", "Response", "Verification status", "Agreed action",
                       "Owner", "Target date"],
    "Actions": ["ACT ID", "FIND ID", "Action", "Owner", "Target date", "Status",
                "Closure evidence EV IDs", "Benefit measure", "Validation WP ID",
                "Validated (Y/N)", "Days to due", "Flag", "Closure check",
                "Risk accepted by", "Risk accepted on"],
}
WIDTHS = {"Description": 40, "Condition": 50, "Criterion (plain language)": 45, "Procedure": 45,
          "Response": 40, "Action": 40, "Title": 32, "Business-language title": 36,
          "Approved cause": 30, "Evidenced impact": 32, "Potential impact": 32,
          "Conclusion boundary": 36, "Result": 28, "Limitation": 30, "Resolution": 30,
          "Benefit measure": 32, "Agreed action": 36, "Linked FIND IDs / reason no finding": 30}

# calculated (formula) columns per sheet, 1-based
CALC_COLS = {"Workpapers": [8], "Actions": [11, 12, 13]}
DATE_HEADERS = {"Evidence date", "Effective date", "Verified on", "Prepared on", "Reviewed on",
                "Approved on", "Target date", "Risk accepted on"}

D = dt.date
# ILLUSTRATIVE ONLY: one internally consistent row per sheet. Delete before real use.
EXAMPLES = {
    "Evidence": ["EV-021", "Payment voucher file, supplier payments above threshold (illustrative)",
                 "ERP payment export", D(2026, 9, 14), "Audit team", "R2",
                 "Approval records held only in the workflow module", "Evidence/EV-021.xlsx"],
    "Criteria": ["CRIT-DOA-02", "Payments above the threshold need Business Head approval before release",
                 "Delegation of authority matrix v3", D(2026, 1, 1), "Supplier payments",
                 "Audit lead", D(2026, 9, 10)],
    "Procedures": ["PROC-P2P-07", "Confirm approval before release", "Unauthorised payment",
                   "Inspect the approval record for each sampled payment",
                   "All payments above threshold, Jul-Aug", "25 selected by value",
                   "CRIT-DOA-02", "Audit team"],
    "Workpapers": ["WP-P2P-07", "Approval testing, payments above threshold", "PROC-P2P-07",
                   "EV-021", 120, 25, 4, None, "4 of 25 without approval record",
                   "Missing records only; no conclusion that payments were unauthorised",
                   "Preparer A", D(2026, 9, 20), "Reviewer B", D(2026, 9, 22), "FIND-P2P-03"],
    "Exceptions_Gaps": ["GAP-001", "GAP", "WP-P2P-07",
                        "Workflow audit log for 2 payments not provided", "Open", ""],
    "Findings": ["FIND-P2P-03", "Approval evidence missing",
                 "Higher-value payments not consistently evidenced as approved",
                 "4 of 25 sampled payments lacked a Business Head approval record",
                 "CRIT-DOA-02", "WP-P2P-07", "EV-021", "Not established",
                 "No confirmed unauthorised payment",
                 "Harder to review or investigate payments later; not quantified",
                 "High", "Draft", "", "", "Finance Controller",
                 D(2026, 12, 31)],
    "Mgmt_Responses": ["MR-P2P-03", "FIND-P2P-03", "Will configure a workflow block",
                       "Management representation - not independently verified",
                       "Mandatory approval field in payment workflow", "Finance Controller",
                       D(2026, 12, 31)],
    "Actions": ["ACT-P2P-03a", "FIND-P2P-03", "Configure workflow block on missing approval",
                "Finance Controller", D(2026, 12, 31), "In progress", "",
                "100% of post-go-live high-value payments carry an approval trail", "", "N",
                None, None, None, None, None],
}

LISTS = {
    "Evidence": {"F": "R1,R2,R3,R4,R5"},
    "Exceptions_Gaps": {"B": "EXC,CE,GAP", "E": "Open,Resolved,Accepted"},
    "Findings": {"K": "Critical,High,Medium,Low",
                 "L": "Draft,Auditor-approved,CAE-approved,Withdrawn"},
    "Mgmt_Responses": {"D": "Management representation - not independently verified,"
                            "Verified by Internal Audit"},
    "Actions": {"F": "Not started,In progress,Delayed,Closed - pending validation,Closed - validated,"
                     "Closed - not effective,Risk accepted",
                "J": "Y,N"},
}


def style_header(ws, headers):
    for c, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=c, value=h)
        cell.fill, cell.font, cell.border = HEAD_FILL, HEAD_FONT, BOX
        cell.alignment = Alignment(wrap_text=True, vertical="center")
        ws.column_dimensions[get_column_letter(c)].width = WIDTHS.get(h, 18)
    ws.row_dimensions[1].height = 32
    ws.freeze_panes = "B2"


def build_input_sheet(wb, name, headers, blank):
    ws = wb.create_sheet(name)
    style_header(ws, headers)
    calc = CALC_COLS.get(name, [])
    for r in range(2, LAST + 1):
        for c, h in enumerate(headers, 1):
            cell = ws.cell(row=r, column=c)
            cell.font = CALC_FONT if c in calc else INPUT_FONT
            cell.alignment = Alignment(wrap_text=True, vertical="top")
            if c in calc:
                cell.fill = CALC_FILL
            if h in DATE_HEADERS:
                cell.number_format = "yyyy-mm-dd"
        if name == "Workpapers":
            ws.cell(r, 8, f'=IF(OR(F{r}="",F{r}=0),"",G{r}/F{r})').number_format = "0.0%"
            ws.cell(r, 5).number_format = "#,##0"
        if name == "Actions":
            ws.cell(r, 11, f'=IF(OR(E{r}="",F{r}="Closed - validated",F{r}="Risk accepted"),"",E{r}-TODAY())')
            ws.cell(r, 13, f'=IF(F{r}="Closed - validated",IF(TRIM(I{r})="","NO VALIDATION WP","OK"),"")')
            ws.cell(r, 12, f'=IF(E{r}="","",IF(F{r}="Closed - validated","Closed",IF(F{r}="Risk accepted","Risk accepted",'
                           f'IF(E{r}<TODAY(),"OVERDUE",'
                           f'IF(E{r}-TODAY()<=30,"Due within 30 days","On track")))))')
    for col, opts in LISTS.get(name, {}).items():
        dv = DataValidation(type="list", formula1=f'"{opts}"', allow_blank=True)
        ws.add_data_validation(dv)
        dv.add(f"{col}2:{col}{LAST}")
    if not blank:
        for c, v in enumerate(EXAMPLES[name], 1):
            if v is None or c in calc:
                continue
            cell = ws.cell(row=2, column=c)
            cell.value = v
            cell.font = EXAMPLE_FONT
    return ws


def build_trace_matrix(wb):
    tm = wb.create_sheet("Trace_Matrix")
    th = ["FIND ID", "Rating", "Status", "# EV cited", "# CRIT cited", "# WP cited",
          "# WPs linking back", "# Mgmt responses", "# Actions", "Trace status", "Approval check"]
    style_header(tm, th)
    for i, w in enumerate([16, 10, 18, 11, 12, 11, 17, 16, 10, 48, 18], 1):
        tm.column_dimensions[get_column_letter(i)].width = w
    for r in range(2, TM_LAST + 1):
        def f(col):
            return f"Findings!{col}{r}"
        tm.cell(r, 1, f'=IF({f("A")}="","",{f("A")})')
        tm.cell(r, 2, f'=IF(A{r}="","",{f("K")})')
        tm.cell(r, 3, f'=IF(A{r}="","",{f("L")})')
        for col, src in ((4, "G"), (5, "E"), (6, "F")):
            tm.cell(r, col, f'=IF(A{r}="","",IF({f(src)}="",0,'
                            f'LEN({f(src)})-LEN(SUBSTITUTE({f(src)},",",""))+1))')
        tm.cell(r, 7, f'=IF(A{r}="","",SUMPRODUCT(--ISNUMBER(SEARCH(","&A{r}&",",'
                      f'","&SUBSTITUTE(Workpapers!$O$2:$O${LAST}," ","")&","))))')
        tm.cell(r, 8, f'=IF(A{r}="","",COUNTIF(Mgmt_Responses!$B$2:$B${LAST},A{r}))')
        tm.cell(r, 9, f'=IF(A{r}="","",COUNTIF(Actions!$B$2:$B${LAST},A{r}))')
        tm.cell(r, 10, f'=IF(A{r}="","",IF(OR(D{r}=0,E{r}=0,F{r}=0,G{r}=0),"BROKEN TRACE",'
                       f'IF(AND(OR(B{r}="High",B{r}="Critical"),'
                       f'OR(H{r}=0,I{r}=0,{f("O")}="",{f("P")}="")),'
                       f'"INCOMPLETE: response, action, owner or date missing","TRACEABLE")))')
        tm.cell(r, 11, f'=IF(A{r}="","",IF(AND(OR(C{r}="Auditor-approved",C{r}="CAE-approved"),'
                       f'{f("M")}=""),"Approver missing","OK"))')
        for c in range(1, 12):
            tm.cell(r, c).font = CALC_FONT
    tm.freeze_panes = "B2"


def build_dashboard(wb, engagement, blank=False):
    db = wb.create_sheet("Dashboard")
    db["A1"] = f"Assurance dashboard: {engagement}"
    db["A1"].font = Font(name=FONT, bold=True, size=13)
    rows = [
        ("Findings registered", f'=COUNTA(Findings!A2:A{LAST})'),
        ("Findings approved (auditor or CAE)",
         f'=COUNTIF(Findings!L2:L{LAST},"Auditor-approved")+COUNTIF(Findings!L2:L{LAST},"CAE-approved")'),
        ("High or Critical findings",
         f'=COUNTIF(Findings!K2:K{LAST},"High")+COUNTIF(Findings!K2:K{LAST},"Critical")'),
        ("Findings fully traceable", f'=COUNTIF(Trace_Matrix!J2:J{TM_LAST},"TRACEABLE")'),
        ("Findings with a broken trace", f'=COUNTIF(Trace_Matrix!J2:J{TM_LAST},"BROKEN TRACE")'),
        ("Findings incomplete (response / action / owner / date)",
         f'=SUMPRODUCT(--(LEFT(Trace_Matrix!J2:J{TM_LAST},10)="INCOMPLETE"))'),
        ("Approved findings missing approver",
         f'=COUNTIF(Trace_Matrix!K2:K{TM_LAST},"Approver missing")'),
        ("Open evidence gaps",
         f'=COUNTIFS(Exceptions_Gaps!B2:B{LAST},"GAP",Exceptions_Gaps!E2:E{LAST},"Open")'),
        ("Open contradictory-evidence items",
         f'=COUNTIFS(Exceptions_Gaps!B2:B{LAST},"CE",Exceptions_Gaps!E2:E{LAST},"Open")'),
        ("Evidence items registered", f'=COUNTA(Evidence!A2:A{LAST})'),
        ("   of which graded R5 (must not support any finding)",
         f'=COUNTIF(Evidence!F2:F{LAST},"R5")'),
        ("   of which not yet graded", f'=COUNTA(Evidence!A2:A{LAST})-COUNTA(Evidence!F2:F{LAST})'),
        ("Actions open (not validated closed or risk-accepted)",
         f'=COUNTA(Actions!A2:A{LAST})-COUNTIF(Actions!F2:F{LAST},"Closed - validated")'
         f'-COUNTIF(Actions!F2:F{LAST},"Risk accepted")'),
        ("Actions overdue", f'=COUNTIF(Actions!L2:L{LAST},"OVERDUE")'),
        ("Actions due within 30 days", f'=COUNTIF(Actions!L2:L{LAST},"Due within 30 days")'),
        ("Actions closed and validated (with a validation workpaper)",
         f'=COUNTIFS(Actions!F2:F{LAST},"Closed - validated",Actions!M2:M{LAST},"OK")'),
        ("Marked 'Closed - validated' but NO validation workpaper (must be 0)",
         f'=COUNTIF(Actions!M2:M{LAST},"NO VALIDATION WP")'),
    ]
    db["A3"], db["B3"] = "Measure", "Value"
    for c in ("A3", "B3"):
        db[c].fill, db[c].font = HEAD_FILL, HEAD_FONT
    for i, (label, formula) in enumerate(rows, 4):
        db.cell(i, 1, label).font = CALC_FONT
        db.cell(i, 2, formula).font = CALC_FONT
    db.column_dimensions["A"].width = 58
    db.column_dimensions["B"].width = 12
    db.cell(len(rows) + 6, 1,
            ("Counts reflect the rows you have entered." if blank else
             "Counts include the illustrative example row (row 2 of each sheet) until you delete it.")
            ).font = EXAMPLE_FONT


def build_readme(ws0, engagement, blank):
    lines = [
        (f"Assurance Trace Register: {engagement}", True),
        ("Purpose: one controlled evidence base behind every director-level message. "
         "Every material statement in a report must trace to an ID recorded here.", False),
        ("", False),
        ("HOW TO USE", True),
        ("1. Fill the sheets left to right: Evidence and Criteria, then Procedures, Workpapers, "
         "Exceptions_Gaps, Findings, Mgmt_Responses, Actions.", False),
        ("2. Blue text = cells you type into. Grey cells (Exception rate, Days to due, Flag, Closure check) and the "
         "Trace_Matrix and Dashboard sheets are formulas: do not overwrite them.", False),
        ("3. Row 2 on each input sheet is an ILLUSTRATIVE example; clear it before real use."
         + ("  [This copy was built blank: no examples.]" if blank else ""), False),
        ("4. In list cells (CRIT IDs, WP IDs, EV IDs, FIND IDs) separate IDs with commas or semicolons. Ranges such as "
         "EV-021 to EV-024 are understood by trace_check.py; the Trace_Matrix counts commas, so list "
         "IDs individually where the count matters.", False),
        ("5. ID format: TYPE-NN or TYPE-AREA-NN, for example EV-021, WP-P2P-07, FIND-P2P-03. "
         "Types: EV, CRIT, PROC, WP, EXC, CE, GAP, FIND, MR, ACT.", False),
        ("6. Evidence reliability follows the portfolio's R1-R5 hierarchy (gia-core:iron-rules). "
         "R5 (verbal) evidence must never support a finding.", False),
        ("7. Approval status gates reporting: only Auditor-approved or CAE-approved findings may be cited "
         "in a director report.", False),
        ("8. Cross-check a report: python3 trace_check.py --register <this file> --report <report.md|.docx>",
         False),
        ("", False),
        ("TRACE STATUS", True),
        ("TRACEABLE = the finding cites criteria, workpapers and evidence, a workpaper links back to it, and "
         "(High/Critical) a management response, action, owner and date exist.", False),
        ("BROKEN TRACE = criteria, workpaper, evidence or the back-link from a workpaper is missing.", False),
        ("INCOMPLETE = traced, but a High/Critical finding lacks a response, action, owner or date.", False),
    ]
    for i, (text, bold) in enumerate(lines, 1):
        c = ws0.cell(i, 1, text)
        c.font = Font(name=FONT, bold=bold, size=12 if i == 1 else 10)
        c.alignment = Alignment(wrap_text=True, vertical="top")
    ws0.column_dimensions["A"].width = 130


def build(out, engagement, blank):
    wb = Workbook()
    ws0 = wb.active
    ws0.title = "README"
    build_readme(ws0, engagement, blank)
    build_dashboard(wb, engagement, blank)
    for name, headers in SHEETS.items():
        build_input_sheet(wb, name, headers, blank)
    build_trace_matrix(wb)
    wb.save(out)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True)
    ap.add_argument("--engagement", default="Engagement name")
    ap.add_argument("--blank", action="store_true", help="omit the illustrative example rows")
    a = ap.parse_args()
    build(a.out, a.engagement, a.blank)
    print(f"wrote {a.out}")
