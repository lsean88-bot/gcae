# Workpaper Template

Copy this layout. Every field either holds content or says why it cannot.

```
WORKPAPER                                    WP ID: WP-[AREA]-[NN]
Title:
Engagement / entity / period:
Prepared by / date:                           Reviewed by / date:

1. AUDIT OBJECTIVE AND RISK ADDRESSED
   Objective:
   Risk:                                      [link to risk/RCM item if one exists]

2. APPLICABLE CRITERION
   [CRIT-###]  Plain-language statement of the requirement
   Source and version / effective date:
   Verified by / on:

3. POPULATION AND SAMPLE
   Population definition and size:
   How completeness of the population was confirmed:   [e.g. reconciled to ledger total]
   Sample size and basis (random / value / judgemental / all items):
   Why the basis is appropriate, and whether results can be projected:

4. PROCEDURE PERFORMED                        [PROC-###]
   What was done, step by step, in enough detail to reperform:

5. EVIDENCE REVIEWED
   [EV-###]  description, source, date, reliability grade (R1-R5), limitation

6. TEST RESULT
   Items tested:      Exceptions:      Exception rate (exceptions / items tested):
   Result in words:

7. EXCEPTIONS, CONTRADICTORY EVIDENCE, EVIDENCE GAPS
   [EXC-###]  confirmed exceptions, each with the item reference
   [CE-###]   evidence that conflicts, and how it was resolved or not
   [GAP-###]  support not available, who was asked, when, status

8. CONCLUSION BOUNDARY
   The result supports:
   The result does not support:               [e.g. intent, cause, company-wide rate]

9. LINK TO FINDING
   [FIND-###]   or   Reason no finding was raised:
```

## Review notes (reviewer completes)

- Can another auditor reperform the test from section 4 alone?
- Does the population reconcile to an independent source?
- Do the counts in section 6 agree to the item list?
- Is every statement in section 8 supported by sections 3 to 7?
- Are open GAP items carried into the finding or the report?
