# Finding Sheet Template

```
FINDING SHEET                                FIND ID: FIND-[AREA]-[NN]
Title (audit):                               Title (business language):
Engagement / entity / period:
Rating: [from approved scale]                Approval status: Draft / Auditor-approved / CAE-approved
Approved by / date:

CONDITION   What was found, with extent and period. Fact only.
CRITERIA    [CRIT-###]  The requirement, in plain words, with its source.
CAUSE       Established cause, or "Not established".  Basis: [WP/EV]
IMPACT
   Evidenced:   What the work shows.                   [WP/EV]
   Potential:   What could follow. Label as potential. Not quantified unless a calculation exists.
RECOMMENDATION
   Owner + action + outcome + proof of completion.     SMART.
   Target date:    Owner:   Executive sponsor (High/Critical):
EVIDENCE TRAIL
   Workpapers: WP-...    Evidence: EV-...    Procedures: PROC-...
   Open gaps / contradictory evidence: GAP-... / CE-...  (or none)
MANAGEMENT RESPONSE   [MR-###]  verbatim or faithful summary
   Verification status: Management representation, not independently verified / Verified by Internal Audit
   Audit position if different:
AGREED ACTION   [ACT-###]  owner, date, closure evidence expected, benefit measure
```

## Condition, criteria, cause, effect: quick test

| Element | Passes if | Fails if |
|---|---|---|
| Condition | A reviewer could find the items again | It states an opinion ("weak", "inadequate") |
| Criteria | Tied to a source with a date | It is "best practice" with no source |
| Cause | Established by evidence, or "Not established" | It is a likely explanation presented as the cause |
| Effect | Evidenced and potential are separate | A number appears with no calculation behind it |

## Rating

Use the rating scale approved for the engagement. Record the scale name and version in the
register's README or notes. Do not infer a rating from the size of an amount alone. If the
scale is not available, leave Rating blank and flag it; the Trace_Matrix and trace_check treat
a blank rating as lower scrutiny, so the gap should be resolved before approval.
