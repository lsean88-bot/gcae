# Evidence label map

## Contents
- Two axes
- Mapping table
- Source tags
- ID table

## Two axes (one scheme each)
1. **Source reliability** is graded R1 to R5 (`gia-core:iron-rules`; strict R3 test: a signed original is R3 only if also independently verified by someone outside the audited party, otherwise R4).
2. **Report statement class** uses the Rule 37 classes: Verified / Supplied by others / Inference / Proposal. A class table sits in the report appendix.
All other label schemes found in older material are mapped here and not used in new deliverables.

## Mapping table
| Older label | Scheme | Maps to |
|---|---|---|
| [INS] inspection of a document or record | CAE verification tags | Source: R2 if system export, R3 if independently verified, otherwise R4. Statement: Verified |
| [PHY] physical observation by audit | tags | Source: R2 (auditor-executed). Statement: Verified |
| [CON] external confirmation | tags | Source: R1 or R3 (external to the audited party). Statement: Verified |
| [REP] management representation | tags | Source: R4 (R5 if verbal). Statement: Supplied by others |
| [REC] auditor re-performance or reconciliation | tags | Source: R2. Statement: Verified |
| [OBS] observation of a process | tags | Source: R2 for audit-observed facts; statement: Verified for what was observed |
| [ANA] analytical result | tags | Source: grade of the input data. Statement: Verified if recomputed; Inference if interpretive |
| Confirmed | Plain-language pack label | Verified (source R1-R3) |
| Confirmed by management | Plain-language pack label | Supplied by others (R4) |
| Indicator | Plain-language pack label | Inference (state basis and limits) |
| Evidence not provided | Plain-language pack label | Open dependency (GAP); no class |
| Management assertion | Board brief label | Supplied by others |
| Audit assessment | Board brief label | Inference or Verified depending on the basis stated |
| Potential impact | impact label | Inference |
| Recommendation, proposed owner, proposed date | any | Proposal |
| Evidence-discipline eight labels (older set) | evidence-discipline | Map each to the nearest row above; if none fits, raise as a gap and use Inference |

The corroboration cap from the verification tags applies in any scheme: a finding resting on inspection or representation alone, without independent corroboration, is capped at High priority.

## Four-lane classification (use before any sentence enters a finding)
Fact (traceable to a cited source) / Assumption (label "ASSUMED, NOT EVIDENCED" or carry as open dependency) / Risk (forward-looking, labelled) / Opinion (professional judgement, kept visibly separate). Only Fact lane statements may appear as unqualified fact.

## ID table
| Prefix | Meaning |
|---|---|
| EV | Evidence item |
| CRIT | Criterion |
| PROC | Procedure |
| WP | Workpaper |
| EXC | Exception |
| CE | Contradictory evidence |
| GAP | Evidence gap |
| FIND | Finding |
| MR | Management response (a management representation is labelled in text, not given this prefix) |
| ACT | Agreed action |
