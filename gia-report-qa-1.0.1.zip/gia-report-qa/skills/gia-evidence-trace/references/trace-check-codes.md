# trace_check.py Codes

Severity: ERROR blocks issue (exit code 1). WARN needs a disposition. INFO is for awareness.
Exit code 2 means the check could not run at all (file missing, corrupt, wrong format), which is
never to be read as a pass.

## Register checks

| Code | Severity | Meaning | Fix |
|---|---|---|---|
| R00 | ERROR | Expected sheet or column not found | Register template was changed; restore the header or rebuild |
| R01 | ERROR | Duplicate ID on a sheet | Renumber the later row only if no report has cited it; otherwise investigate which is right |
| R02 | ERROR | Invalid ID, or wrong type on a sheet | Correct to TYPE-NN / TYPE-AREA-NN |
| R03 | ERROR (approved) / WARN (draft) | Finding cites no criteria, workpaper or evidence | Add the links, or the finding is not ready for approval |
| R04 | ERROR | Dangling reference: cited ID not in register, or wrong type in a column | Add the missing record or correct the citation |
| R05 | WARN / ERROR | Evidence has no valid grade; or a finding cites R5 evidence | Grade it; remove R5 support (a finding cannot rest on it) |
| R06 | ERROR | Approved finding without approver or approval date | Record who approved and when |
| R07 | ERROR / WARN | High/Critical approved finding without owner and date (ERROR); without management response or action (WARN) | Obtain owner/date; record response and action |
| R08 | WARN | Finding and workpaper do not link to each other both ways | Make the links consistent |
| R09 | WARN | Workpaper records exceptions but no linked finding or reason none was raised | State the finding or the reason |
| R10 | ERROR / WARN | Sample larger than population, exceptions larger than sample (ERROR); non-numeric count (WARN) | Correct the counts from the workpaper |
| R11 | INFO | Open evidence gap affects an approved finding | Resolve, or disclose the limitation in the report |
| R12 | ERROR / WARN | Action is "Closed - validated" with no validation workpaper, against an unapproved finding, or on R5 closure evidence (ERROR); no or R4-only closure evidence, or Validated (Y/N) disagrees with status (WARN) | Name the validation workpaper from `action-closure-validation`, or set the status to "Closed - pending validation" |
| R13 | WARN | Approval status or action status is not in the controlled list (typo, wrong case). The finding is treated as NOT approved | Correct the value; the message suggests the nearest valid one |
| R14 | WARN | Row has content but no ID, so every check and the brief ignore it | Add an ID or clear the row |
| R15 | WARN | A date field holds text, so overdue logic cannot use it | Re-enter as a real date |
| R16 | WARN | Approved finding rests only on R4 evidence | Confirm independent corroboration is on file (R3), or add stronger evidence |
| R18 | WARN | List cell uses ";" as separator; the scripts read it but the workbook Trace_Matrix counts commas; also warns on `EV-021 to 024` (bare end number, read as one ID) | Use commas; write the full end ID |
| R20 | WARN | Workpaper behind an approved finding has no reviewer, or is marked UNREVIEWED | Record the reviewer and date, or get the approver to accept the gap |
| R19 | ERROR | Action is 'Risk accepted' but 'Risk accepted by' or 'Risk accepted on' is blank | Record the accepting authority and date, or change the status |
| R17 | ERROR / WARN | Register has no data at all (ERROR); evidence but no findings (WARN) | Fill the register; an empty register is not a pass |

## Report checks

| Code | Severity | Meaning | Fix |
|---|---|---|---|
| P01 | ERROR | Report cites an ID not in the register | Remove it or add the record. Never invent |
| P02 | ERROR (WARN with --allow-draft) | Report cites a finding that is not approved | Wait for approval, or mark the report a draft and use --allow-draft |
| P03 | ERROR | Report cites a Withdrawn finding | Remove the content |
| P04 | WARN | Paragraph (in a document that does cite IDs) has a figure (amount, percentage, "X of Y") and no reference. Heuristic | Add the reference, or the "Evidence reference not available" wording, or remove the claim |
| P05 | WARN | "X of Y" in a paragraph citing a workpaper disagrees with the workpaper's exceptions-of-sample | Correct the report from the workpaper |
| P00 | ERROR | Report could not be read (missing, PDF/binary, corrupt .docx, no python-docx) | Export to .docx, .md or .txt and re-run |
| P06 | INFO | Paragraph carries the "evidence reference not available" wording | Auditor validation still open; do not issue as final until cleared |
| P10 | WARN | With `--source`: a figure in the report is not in the source finding | Trace it to the source or remove it; do not derive or estimate figures |
| P07 | WARN | Text looks like a reference but is not a valid ID (lower case, wrong digits), so it was NOT matched to the register | Correct it to TYPE-NN / TYPE-AREA-NN |
| P08 | WARN | Document cites no register ID and declares evidence references unavailable (stated once near the top) | Acceptable for a draft; add references before issuing |
| P09 | INFO | An approved High/Critical finding is not mentioned in the report | Confirm the omission is intended |

The BOARD-LEVEL MESSAGE paragraph is exempt from P04 and P05 by design: it is read aloud without tags,
and its content is tagged in the sections above it.
