# Benefit Measure Examples

A benefit measure is something observable with a baseline, a target and a date. These show
the form; the numbers are placeholders and must come from the engagement.

| Action | Closure evidence | Benefit measure (form) | How Internal Audit validates |
|---|---|---|---|
| Workflow block on payments without approval | Configuration record and test log | Share of post-go-live high-value payments carrying an approval record: baseline [x]%, target 100% | Test a post-go-live sample; confirm the block cannot be bypassed |
| Duplicate-supplier review | Monthly duplicate report and resolution log | Unresolved duplicate supplier records: baseline [n], target below [n] by [date] | Review reports; trace selected resolutions to the supplier master |
| Monthly stock reconciliation | Signed reconciliation and ageing report | Stock differences older than [30] days: baseline [n lines], target below [n] by [date] | Re-perform selected reconciliations |
| Compliance obligation register | Register, ownership matrix, filing evidence, review minutes | On-time completion of high-risk obligations: baseline [x]%, target [y]% | Inspect tracker and selected filings against external confirmation |
| Corrective-action discipline in quality | Action dashboard and independent closure evidence | Overdue corrective actions and repeat non-conformances: baseline [n], target [n] | Validate selected closures and the trend data |
| Quarterly user-access review | Signed review and removal log | Users with access not linked to a current role: baseline [n], target 0 | Compare a fresh user list to the HR listing |

## Tips

- Agree the measure when the action is agreed. If it is chosen afterwards, it tends to fit.
- Prefer measures a system can report over measures a person must remember to count.
- A measure that cannot move, or has no baseline, is a status, not a measure.
- "Closed" and "implemented" are statuses. Use them in the tracker, never as the benefit.
- Do not translate a measure into money unless a calculation is documented in a workpaper.
