# ID Conventions

## Format

`TYPE-NN` or `TYPE-AREA-NN`
- TYPE: EV, CRIT, PROC, WP, EXC, FIND, MR, CE, GAP, ACT
- AREA (optional): 2–6 capital letters or digits, such as P2P, INV, HR, DOA
- NN: 2–4 digits, zero-padded within an engagement (EV-021, WP-P2P-07)
- An optional trailing lowercase letter marks a sub-item (ACT-P2P-03a)

Ranges in prose are written `EV-021 to EV-024` (or `EV-021–024`) and read as four IDs. `EV-021 to 024` (a bare end number after "to") and a dash range followed by a word, such as `WP-01–15 samples`, are read as ONE ID so that counts of samples are never mistaken for IDs; write the full end ID. In register cells list IDs
separated by commas; the Trace_Matrix counts commas. (The scripts also read semicolons, but trace_check reports them as R18 because the workbook will show a broken trace.)

## Who issues what

| Type | Meaning | Issued when | By |
|---|---|---|---|
| EV | Source document, export or observation record | Logged in the register with a grade | Auditor who obtained it |
| CRIT | Approved criterion (law, policy, delegation matrix, contract term) | Verified against its source | Audit lead; "Verified by/on" filled |
| PROC | Audit procedure performed | Planned or performed | Auditor |
| WP | Workpaper or test result | Prepared | Preparer; reviewer recorded |
| EXC | Approved exception | Confirmed exception from a test | Reviewer |
| CE | Contradictory evidence | When evidence conflicts | Auditor |
| GAP | Evidence gap | When needed support is unavailable | Auditor |
| FIND | Finding | Drafted; status governs use | Auditor; approval by auditor or CAE |
| MR | Management response | Received | Auditor records, never edits |
| ACT | Agreed action | Agreed | Auditor with owner |

## Rules

1. **Check before issuing.** Take the next unused number for that type (and area).
2. **Never reuse or renumber** an ID that a report has cited. Withdraw a finding by setting its
   status to Withdrawn; the ID stays.
3. **Split, don't overload.** If a workpaper tests two things with different results, make two WPs.
4. **One criterion, one CRIT.** Cite the source and its version/effective date; a criterion that
   cannot be tied to a source is not yet approved and should not be cited in a finding.
5. **Statutory content needs a verified source.** Take it from the entity skill or the primary
   document; record the date verified. If you cannot verify it, log a GAP.
6. **Management statements are MR items,** not EV, unless independently verified.
7. **An ID that appears in a report but not in the register is a fabrication until proven
   otherwise.** Treat it as an ERROR (P01).
