# Closure-Validation Workpaper Template

Copy this structure. Every line is filled or marked "not applicable" with a reason.

```
WP ID / title:           WP-[AREA]-[NN]  Closure validation of ACT-[...]
Original finding:        FIND-[...]  (rating, approval date, original condition in one sentence)
Original WP / evidence:  WP-[...]; EV-[...]
Action under validation: ACT-[...]  (what management said it would do, owner, due date)
Reported complete on:    [date]  by [name]   ← Management representation, not independently verified [MR-...]
Implementation (go-live) date: [date]

1. Designed
   Does the implemented action address the approved cause or risk?
   Evidence reviewed: EV-[...] (grade R_)
   Conclusion on design: [Addresses / Partly addresses / Does not address] because [reason]

2. Operating
   Period tested:         [after go-live date] to [date]
   Population:            [description, size, source, how completeness was confirmed]
   Sample:                [size, how selected]
   Procedure:             PROC-[...]  (original test re-performed, plus tests of the new control)
   Results:               [n] exceptions in [n] items
   Exceptions / gaps:     EXC / CE / GAP-[...]

3. Result against benefit measure
   Measure agreed:        [measure, baseline, target, date]
   Observed:              [value, source EV-[...]]
   Conclusion:            [Achieved / Partly achieved / Not achieved / Too early to assess]

Conclusion:              [Validated / Partly effective / Not effective]
Conclusion boundary:     [what this supports and what it does not; e.g. only period X; only location Y]
Status change:           ACT-[...] moves to [Closed - validated / Closed - not effective / remains open]
Follow-up needed:        [new action, owner, date, or none]
Prepared by / date:      [name, date]
Reviewed by / date:      [name, date]
```

## Notes

- A management statement of completion is recorded as a Management response item, labelled
  as not independently verified. It is the trigger for validation, not part of the conclusion.
- "Too early to assess" is a legitimate benefit conclusion when too little time has passed.
  The action can still be validated on design and operation; the benefit review is scheduled.
- Evidence provided by the action owner is R4 until independently corroborated (system
  export obtained by Internal Audit, for example, is R2).
- If the result is "Not effective", say what was observed, not why management failed. The
  recommendation for what happens next belongs in the follow-up line.
