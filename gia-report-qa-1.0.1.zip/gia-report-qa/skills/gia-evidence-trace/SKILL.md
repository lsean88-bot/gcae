---
name: gia-evidence-trace
description: "Controlled evidence register (EV, WP, FIND IDs, R1-R5 grading, Excel trace matrix), script cross-check of a report against it, workpaper and finding sheets, action-closure validation. Use when asked for an evidence register, traceability matrix, finding write-up, or when management says an action is complete. Do NOT use for pre-issue review (use gia-report-qa:gia-report-qa)."
---

# GIA Evidence Trace

The register is the one place where an audit says what it has: evidence, criteria, procedures, workpapers, findings, management responses, actions. Reports are checked against it. If a fact is not here, it has not been established. Evidence grading and the Quality Gate are in `gia-core:iron-rules`; they are cited, not restated.

## 1. Build the register

```bash
python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-evidence-trace/scripts/build_register_workbook.py --out <Engagement>_Register.xlsx --engagement "<Entity, audit, period>" [--blank]
python3 /mnt/skills/public/xlsx/scripts/recalc.py <file> 120      # confirm zero formula errors; path depends on the xlsx skill install
```
`--blank` omits example rows. Sheets: README, Dashboard, Evidence, Criteria, Procedures, Workpapers, Exceptions_Gaps, Findings, Mgmt_Responses, Actions, Trace_Matrix. Blue text is input; grey cells, Trace_Matrix and Dashboard are formulas. To import an existing list: export to CSV and run `scripts/import_rows.py --workbook R.xlsx --sheet Findings --csv in.csv --map "Their col=Our col"`; it writes a copy, never touches formula columns, forces imported approval status to Draft and reports unmapped columns. Then run trace_check.

## 2. Issue IDs and grade evidence

Read `references/id-conventions.md`. Next free number per type from the register; an ID cited in a report is never reused or renumbered (withdraw instead); IDs come only from the register. MR means management response; a management representation is labelled in text.

Grade each evidence item R1 to R5 when logging, record the limitation in its own column, re-grade on corroboration. A management representation letter is a signed original and still R4. Classify report statements with the Rule 37 classes. Other label schemes map through `references/evidence-label-map.md`.

## 3. Check a report against the register

```bash
python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-evidence-trace/scripts/trace_check.py --register R.xlsx --report report.md|.docx [--allow-draft] [--json out.json]
```
Exit 1 = at least one ERROR; exit 2 = the check could not run (never a pass). Codes and fixes: `references/trace-check-codes.md`. ID, status and "X of Y" checks are exact; P04 (possible untraced statement) is a heuristic prompting a human look. Never fix an ERROR by editing the register to match the report; find out from the evidence which is right and record the change.

## 4. Workpaper (11 elements)

Template `references/workpaper-template.md`: WP ID and title; objective and risk; criterion `[CRIT]`; population and sample with selection method; procedure `[PROC]`; evidence `[EV]`; results (counts, exception rate from counts); exceptions, contradictions, gaps `[EXC/CE/GAP]`; **conclusion boundary** (what the result supports and does not); link to finding or reason none was raised; prepared / reviewed by and dates. State the boundary in words at the time of the work ("4 of 25 sampled payments had no approval record; this does not show they were unauthorised, and a value-selected sample does not estimate the population rate"). An unavailable record is a GAP item, never a silent omission.

## 5. Finding sheet and approval gate

Template `references/finding-sheet-template.md`. Condition is a fact with extent and period; cause is established or "Not established"; impact split evidenced / potential ("not quantified; management validation required"); rating from the approved scale (never assigned by the drafter); recommendation = owner + action + outcome + deadline + proof of completion. Fraud or misconduct indicators: neutral wording, control gap and facts only, ladder terms per `gia-fraud:gia-fraud-investigation`, no motive.

A finding is **Draft** until a named auditor or the CAE sets Auditor-approved or CAE-approved and the register records who and when. Never set status yourself; if told "it is approved", ask for approver and date. Readiness check before asking for approval: at least one CRIT, WP and EV that exist in the register; no R5 behind it and R4 flagged; workpapers link back; fact separated from inference, sample not extrapolated; cause established or not established; impacts separated; rating from the approved scale; open GAP / CE disclosed; recommendation complete.

Management response: record as an MR item (verbatim or faithfully summarised) as "Management representation, not independently verified" until tested. Record disagreement as disagreement with the audit position retained; never soften a finding to secure agreement. The agreed action becomes an ACT item with owner, date, closure-evidence expectation and benefit measure.

## 6. Action closure

Seven statuses and no others: Not started; In progress; Delayed; Closed - pending validation; Closed - validated; Closed - not effective; Risk accepted (named authority, date; trace_check R19 errors if blank). The Actions dropdown in `build_register_workbook.py` carries exactly these; change both together. Only a validation workpaper moves an action to Closed - validated.

Validate closure with `references/closure-workpaper-template.md`: **designed** (addresses the approved cause), **operating** (sample from after go-live, population and selection stated), **result** (benefit measure moved). Conclusions: validated / partly effective (record Closed - not effective or Delayed with a revised action for the failed part) / not effective, with the conclusion boundary. Every action gets a benefit measure when agreed (`references/benefit-measure-examples.md`); if none, record "Expected benefit to be confirmed by management during action planning". No savings or avoided-loss claims without a written calculation. Overdue is arithmetic (due date earlier than today and not Closed - validated); the register and `brief_data.py` compute it. Escalation triggers come from engagement governance; a proposal (marked as such): first miss to the executive sponsor, second miss or any overdue High/Critical to the AC action report.

Follow-up audits: treat each original finding as a mini-engagement, pull its FIND / WP / EV IDs, define the re-test, link the validation workpaper back to the original finding.

## 7. State of the audit

Recalculate, read Dashboard and Trace_Matrix, report counts, name High/Critical findings that are not TRACEABLE, and state whether example rows still count.

## References

| File | Read when |
|---|---|
| `references/id-conventions.md` | Issuing, splitting, retiring IDs |
| `references/trace-check-codes.md` | Interpreting trace_check output |
| `references/evidence-label-map.md` | Mapping other label schemes to R1-R5 and Rule 37 |
| `references/workpaper-template.md` | Writing a workpaper |
| `references/finding-sheet-template.md` | Writing a finding sheet |
| `references/closure-workpaper-template.md` | Validating closure |
| `references/benefit-measure-examples.md` | Agreeing a benefit measure |
