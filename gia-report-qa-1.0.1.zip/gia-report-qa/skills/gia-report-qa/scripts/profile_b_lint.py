#!/usr/bin/env python3
"""profile_b_lint.py - deterministic lint for Profile B (Board / Audit Committee / Chairman /
external-grade) files.

Flags, per file (.docx .html .htm .md .txt .xlsx):
  E01 emoji or pictograph (including status symbols such as check marks and warning signs)
  S01 self-commentary / methodology narration / drafting-history phrases
  R01 worksheet, sheet, row, cell or tab references in the text
  N01 no-drift or verification declarations written into the file
Profile A (auditee / EXCO pack) may carry one "how to check" reference line, so --profile A
downgrades R01 to WARN and skips E01 for traffic-light colour words only (emoji still flagged).

Exit code: 0 = no ERROR; 1 = at least one ERROR; 2 = a file could not be read (never a pass).
A clean run proves only that these patterns are absent; it is not a quality review.

Usage:
  python3 profile_b_lint.py FILE [FILE ...] [--profile A|B] [--allow REGEX ...] [--json out.json]
"""
import argparse
import json
import re
import sys
import zipfile
from html.parser import HTMLParser
from xml.etree import ElementTree as ET

EMOJI = re.compile(
    "[\U0001F300-\U0001FAFF\U0001F000-\U0001F2FF☀-➿⬀-⯿←-⇿"
    "⌀-⏿️‍✅❌⛔⭐]"
)
# Characters in the arrows/misc ranges that are ordinary typography are not flagged.
TYPO_OK = set("→←↑↓•–—…×≤≥≠≈−")

SELF_COMMENTARY = [
    r"this audit found", r"independently (confirmed|verified|re-?performed)", r"\bwe (re-?)?(tested|performed|verified|re-?performed|checked)\b",
    r"\bre-?performed\b", r"checked against", r"\bdocuments? (were )?read\b", r"\b\d+\s+documents?\s+(read|reviewed)\b",
    r"verification (process|pass|round)", r"qa (pass|round|panel|log)", r"change log", r"this version (replaces|supersedes)",
    r"\bversion history\b", r"previous(ly)? (draft|version)", r"earlier (draft|version|report)", r"as (previously )?(agreed|instructed) with the (gcae|cae)",
    r"retest(ed)? note", r"withdrawn (item|finding)", r"grouping decision", r"for gcae only", r"\bcae note\b",
    r"\bworkpaper(s)?\b", r"as an ai\b", r"\bai[- ](generated|assisted|drafted)\b", r"\bclaude\b",
    r"\bopus\b", r"\bsonnet\b", r"\bhaiku\b", r"\bsubagent", r"\btrace[- ]?check\b", r"\bround \d+ (fix|review)",
]
DECLARATIONS = [
    r"i have not changed (approved )?(audit )?facts", r"not changed approved audit facts", r"no[- ]drift declaration",
    r"without (changing|altering) (the )?approved (facts|ratings)", r"nothing (has been )?(added|invented) beyond the source",
]
ROW_REFS = [
    r"\b(work)?sheets?\s+['\"“]?[A-Za-z_][\w ]{1,30}['\"”]?\s*,?\s*rows?\s*\d+", r"\brows?\s+\d+(\s*(-|–|to)\s*\d+)?\b",
    r"\bcells?\s+[A-Z]{1,3}\d{1,5}\b", r"\b[A-Z]{1,3}\d{1,5}:[A-Z]{1,3}\d{1,5}\b", r"\b[A-Za-z_]+!\$?[A-Z]{1,3}\$?\d{1,5}\b",
    r"\b(see|refer to|in) (the )?(tab|sheet|worksheet)\s+['\"“]?[A-Za-z_]", r"\bFinding_Cards?\b", r"\bExecutive_Summary\b",
]


class _Strip(HTMLParser):
    def __init__(self):
        super().__init__()
        self.out, self.skip = [], 0

    def handle_starttag(self, tag, attrs):
        if tag in ("style", "script"):
            self.skip += 1
        if tag in ("p", "br", "tr", "li", "h1", "h2", "h3", "h4", "div"):
            self.out.append("\n")

    def handle_endtag(self, tag):
        if tag in ("style", "script") and self.skip:
            self.skip -= 1

    def handle_data(self, d):
        if not self.skip:
            self.out.append(d)


def read_text(path):
    pl = path.lower()
    if pl.endswith(".docx"):
        with zipfile.ZipFile(path) as z:
            parts = [n for n in z.namelist() if re.match(r"word/(document|header\d*|footer\d*|footnotes)\.xml", n)]
            out = []
            for n in parts:
                root = ET.fromstring(z.read(n))
                for p in root.iter("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}p"):
                    out.append("".join(t.text or "" for t in p.iter("{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t")))
            return "\n".join(out)
    if pl.endswith(".xlsx"):
        import openpyxl
        wb = openpyxl.load_workbook(path, data_only=False)
        out = []
        for ws in wb.worksheets:
            for row in ws.iter_rows():
                for c in row:
                    if isinstance(c.value, str) and not c.value.startswith("="):
                        out.append(c.value)
        return "\n".join(out)
    raw = open(path, encoding="utf-8", errors="replace").read()
    if pl.endswith((".html", ".htm")):
        raw = re.sub(r"data:[a-z/+-]+;base64,[A-Za-z0-9+/=]+", "", raw)
        s = _Strip()
        s.feed(raw)
        return "".join(s.out)
    return raw


def scan(text, profile, allow):
    items = []
    lines = text.split("\n")
    for ln, line in enumerate(lines, 1):
        if any(re.search(a, line, re.I) for a in allow):
            continue
        for m in EMOJI.finditer(line):
            if m.group() in TYPO_OK:
                continue
            items.append(("E01", "ERROR", ln, f"emoji/pictograph U+{ord(m.group()):04X}", line.strip()[:120]))
            break
        for pat in SELF_COMMENTARY:
            m = re.search(pat, line, re.I)
            if m:
                items.append(("S01", "ERROR", ln, f"self-commentary/process phrase: '{m.group()}'", line.strip()[:120]))
        for pat in DECLARATIONS:
            m = re.search(pat, line, re.I)
            if m:
                items.append(("N01", "ERROR", ln, f"declaration in file: '{m.group()}' (belongs in QA log/chat)", line.strip()[:120]))
        for pat in ROW_REFS:
            m = re.search(pat, line)
            if m:
                sev = "ERROR" if profile == "B" else "WARN"
                items.append(("R01", sev, ln, f"sheet/row/cell reference: '{m.group()}'", line.strip()[:120]))
    return items


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("files", nargs="+")
    ap.add_argument("--profile", choices=["A", "B"], default="B")
    ap.add_argument("--allow", nargs="*", default=[], help="regex; any line matching is skipped (documented false positives)")
    ap.add_argument("--json")
    a = ap.parse_args()
    result, rc = {}, 0
    for f in a.files:
        try:
            text = read_text(f)
        except Exception as e:  # unreadable is never a pass
            print(f"CANNOT READ {f}: {e}")
            result[f] = {"error": str(e)}
            rc = max(rc, 2)
            continue
        its = scan(text, a.profile, a.allow)
        result[f] = [dict(code=c, severity=s, line=l, message=m, text=t) for c, s, l, m, t in its]
        for c, s, l, m, t in its:
            print(f"{s:5} {c} {f}:{l}: {m} | {t}")
        if any(s == "ERROR" for _, s, *_ in its):
            rc = max(rc, 1)
        if not its:
            print(f"CLEAN {f} (Profile {a.profile}; absence of these patterns is not a quality review)")
    if a.json:
        json.dump(result, open(a.json, "w"), indent=1)
    sys.exit(rc)


if __name__ == "__main__":
    main()
