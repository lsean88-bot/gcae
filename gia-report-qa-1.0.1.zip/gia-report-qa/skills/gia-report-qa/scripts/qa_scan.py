#!/usr/bin/env python3
"""
qa_scan.py - deterministic wording and traceability scan for audit drafts.

Checks a draft (.md, .txt, .docx) for patterns that commonly signal report drift:
  UNREF     factual-looking sentence with no evidence/workpaper reference
  TERM      restricted allegation/conclusion term not approved by the auditor
  ABSENCE   wording that treats missing evidence as proof an event did not occur
  OVERREACH sample result stretched to a population, or sweeping generalisation
  EXAGG     intensifier / dramatic wording
  JARGON    audit jargon in director-level material (--audience director)
  UNKNOWN_REF  reference ID cited in the draft but absent from the register (--register)
  DECLARATION  required no-drift declaration missing (--require-declaration)

It checks wording patterns, not truth. A clean scan is necessary, not sufficient:
still run Mode 8 QA against the finding register and workpapers.

Examples
  python qa_scan.py draft.docx
  python qa_scan.py draft.md --audience director --register registers/evidence.xlsx
  python qa_scan.py draft.md --approved "material,non-compliant" --out qa_report.md
"""
import argparse
import json
import re
import sys
from collections import OrderedDict, defaultdict
from pathlib import Path

PREFIXES = ["CRIT", "RISK", "CTRL", "PROC", "POP", "SAMP", "EV", "MR", "WP",
            "EXC", "CE", "GAP", "FIND", "QA", "POL", "SOP"]
_P = "|".join(PREFIXES)
REF_BRACKET = re.compile(r"\[(?:%s)-[^\]]+\]" % _P)
REF_TOKEN = re.compile(r"\b(?:%s)-[A-Za-z0-9]+(?:-[A-Za-z0-9]+)*\b" % _P)

SEVERITY = {"TERM": "HIGH", "UNKNOWN_REF": "HIGH", "DECLARATION": "HIGH", "TERM_NEG": "LOW", "HIDDENCHAR": "MED",
            "INTERNALVOICE": "MED", "AIARTEFACT": "LOW", "SPECULATE": "LOW", "FIGURE_VARIANTS": "INFO",
            "ABSENCE": "MED", "OVERREACH": "MED", "UNREF": "MED",
            "EXAGG": "LOW", "JARGON": "LOW"}

# (regex, label). "material" handled separately because of "raw material" etc.
RESTRICTED = [
    (r"\bfraud(?:ulent(?:ly)?)?\b", "fraud"),
    (r"\bdeliberate(?:ly)?\b", "deliberate"),
    (r"\bmisconduct\b", "misconduct"),
    (r"\bcollu(?:sion|de[sd]?|ding)\b", "collusion"),
    (r"\bmanipulat(?:e[sd]?|ion|ing)\b", "manipulation"),
    (r"\bviolat(?:e[sd]?|ion|ions|ing)\b", "violation"),
    (r"\bbreach(?:es|ed|ing)?\b", "breach"),
    (r"\b(?:illegal(?:ly)?|unlawful(?:ly)?)\b", "illegal/unlawful"),
    (r"\bmisstat(?:ement|ed|ing)s?\b", "misstatement"),
    (r"\bnegligen(?:ce|t|tly)\b", "negligence"),
    (r"\bsystemic(?:ally)?\b", "systemic"),
    (r"\bineffective(?:ly)?\b", "ineffective"),
    (r"\bnon-?\s?complian(?:ce|t)\b", "non-compliance"),
    (r"\b(?:failed|failure|ignored)\b", "failed/failure/ignored"),
    (r"\bcaused a loss\b", "caused a loss"),
    (r"\blosses\b|\bloss\b", "loss"),
    (r"\b(?:fictitious|ghost|kickbacks?|embezzl\w+|theft|stole[n]?|bribe\w*|corrupt\w*)\b",
     "allegation term"),
]
MATERIAL_RE = re.compile(r"\bmaterial(?:ly)?\b", re.I)
MATERIAL_PREV_OK = {"raw", "packing", "packaging", "direct", "indirect", "bill", "source",
                    "reference", "training", "marketing", "input", "scrap", "consumable",
                    "building", "construction", "safety", "hazardous", "returned"}

ABSENCE = [
    r"\bdid not occur\b", r"\bnever (?:approved|performed|reviewed|obtained|done)\b",
    r"\b(?:was|were) not obtained\b", r"\bno approval (?:was|has been) obtained\b",
    r"\bdid not (?:obtain|perform|review|approve)\b", r"\b(?:was|were) not performed\b",
    r"\bwithout (?:any )?approval\b", r"\bno evidence of (?:approval|review|control)\b",
    r"\bnot done\b",
]

OVERREACH_QUANT = re.compile(
    r"\b(?:all|every|entire|whole)\s+(?:of\s+)?(?:the\s+)?(?:transactions?|payments?|"
    r"invoices?|employees?|items?|records?|population|vendors?|suppliers?|centres?|"
    r"centers?|plants?|entities|purchases|orders)\b", re.I)
OVERREACH_WORDS = re.compile(
    r"\b(?:pervasive(?:ly)?|widespread|endemic|(?<!not )(?<!cannot )consistently|routinely|habitually|always|"
    r"never|across the (?:organi[sz]ation|group|company)|control environment|"
    r"culture of|tone at the top)\b", re.I)
SAMPLE_WORDS = re.compile(r"\b(?:sample[ds]?|sampled|selected items?|judgemental|judgmental|"
                          r"of the \d+|\d+ of \d+)\b", re.I)

EXAGG = re.compile(
    r"\b(?:significant(?:ly)?|severe(?:ly)?|serious(?:ly)?|critical(?:ly)?|major|alarming(?:ly)?|"
    r"egregious(?:ly)?|clearly|obvious(?:ly)?|undoubted(?:ly)?|blatant(?:ly)?|rampant|massive(?:ly)?|"
    r"gross(?:ly)?|glaring|shocking(?:ly)?|dramatic(?:ally)?|extreme(?:ly)?|grave(?:ly)?|"
    r"substantial(?:ly)?|highly concerning|of great concern|unacceptable|"
    r"disturbing(?:ly)?)\b", re.I)

JARGON = [
    "control deficiency", "design deficiency", "operating effectiveness",
    "operational effectiveness", "residual risk", "population completeness",
    "exception rate", "key control", "segregation of duties", "material weakness",
    "management override", "inherent risk", "compensating control", "substantive testing",
    "test of design", "test of operating", "walkthrough", "attribute sampling",
    "non-compliance", "control gap",
]

NEG_CONTEXT = re.compile(r"(?:cannot|can not|could not|unable to|has not|have not|did not|does not|do not|no|not)[\s,]+(?:by itself[\s,]+)?(?:yet\s+)?(?:been\s+)?(?:conclude|concluded|determine|determined|establish|established|confirm|confirmed|decide|decided|assess|assessed|draw|drawn)\b|no conclusion|reserved to|not (?:a|an)\s+\w+\s+conclusion", re.I)
NEG_AFTER = re.compile(r"^[^.]{0,50}?(?:(?:has|have|had|is|are|was|were) not (?:yet )?(?:been )?(?:quantified|established|determined|concluded|projected|assessed|confirmed)|not (?:been )?(?:quantified|established|determined|concluded|projected)|unquantified)", re.I)
AIARTEFACT = re.compile(r"\b(?:delve[sd]?|delving|it is important to note|it is worth noting|comprehensive|robust|leverag(?:e|ed|ing)|in conclusion|in summary|tapestry|testament|seamless(?:ly)?|navigate the|i hope this|as an ai|certainly!|holistic|synerg\w+|landscape of|rich tapestry)\b", re.I)
SPECULATE = re.compile(r"\b(?:appears? to|appeared to|seems?\b|seemed\b|likely|probably|presumably|we believe|we think|we feel|in our view|possibly|perhaps|it would seem)\b", re.I)
INTERNALVOICE = re.compile(r"\b(?:our internal audit|internal audit (?:team )?(?:found|believes?|noted|feels?)|we suspect|careless|sloppy|incompetent|lazy|negligent)\b", re.I)
ZW = re.compile("[\u200b-\u200f\u202a-\u202e\u2060-\u2064\ufeff]")
MIXED = re.compile(r"[A-Za-z]+[\u0400-\u04ff\u0370-\u03ff]+[A-Za-z]*|[\u0400-\u04ff\u0370-\u03ff]+[A-Za-z]+")
RATIO_RE = re.compile(r"\b(\d+)\s+of\s+(\d+)\b")


FACT_HINT = re.compile(
    r"\d|\b(?:one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|several|many|most|none|half|dozen|hundred)\b|\b(?:lacked|had|made|held|paid|sent|sold|bought|found|took|gave|were|was|did)\b|\b\w+ed\b|\b(?:was|were|did not|noted|found|identified|observed|showed|shows|indicates?|"
    r"resulted|exceeded|missing|not available|not evidenced|confirmed|recorded|stated|"
    r"revealed|detected|approved|paid|posted|issued|failed|failure|demonstrat\w+|indicat\w+|"
    r"processed|obtained|performed|complied|exist\w*|operat\w+|demonstrate[sd]?)\b", re.I)
NON_FACT_START = re.compile(
    r"^(?:recommend|action|management (?:should|will|to)|finance should|we recommend|"
    r"internal audit will|owner|target|decision|why it matters|expected)", re.I)
LABELS = re.compile(r"\b(?:management representation|auditor hypothesis|inference|unverified|"
                    r"evidence gap|scope limitation|contradiction)\b", re.I)

DECLARATION = ("I have not added facts, inferred intent, expanded scope, changed the approved "
               "perspective, changed the population or sample, assigned an unapproved rating, "
               "or converted an evidence gap into an audit conclusion.")

CURRENCY = r"(?:RM|INR|Rs\.?|USD|MXN|MYR|EUR|GBP|\$|₹)\s?[\d,]+(?:\.\d+)?(?:\s?(?:million|mn|m|billion|bn|crore|lakh|k)\b)?"
FIGURE_RES = [("ratio", re.compile(r"\b\d+\s+of\s+\d+\b")),
              ("percent", re.compile(r"\b\d+(?:\.\d+)?\s?%")),
              ("amount", re.compile(CURRENCY, re.I))]


# ----------------------------------------------------------------- loading
def load_units(path: Path):
    """Return list of (location, text, is_heading)."""
    suffix = path.suffix.lower()
    units = []
    if suffix == ".docx":
        try:
            import docx  # python-docx
        except ImportError:
            sys.exit("python-docx is needed for .docx files (pip install python-docx).")
        try:
            d = docx.Document(str(path))
        except Exception as e:
            sys.exit(f"Could not read {path.name} as a Word document ({type(e).__name__}). Is the file corrupt or not a .docx?")
        for i, p in enumerate(d.paragraphs, 1):
            t = p.text.strip()
            if t:
                heading = (p.style.name or "").lower().startswith(("heading", "title"))
                units.append((f"para {i}", t, heading))
        for ti, table in enumerate(d.tables, 1):
            for ri, row in enumerate(table.rows, 1):
                for ci, cell in enumerate(row.cells, 1):
                    t = cell.text.strip()
                    if t:
                        units.append((f"table {ti} r{ri}c{ci}", t, False))
    else:
        in_code = False
        for n, line in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            s = line.strip()
            if s.startswith("```"):
                in_code = not in_code
                continue
            if in_code or not s:
                continue
            if re.fullmatch(r"\|?[\s:\-|]+\|?", s):
                continue  # table separator row
            heading = s.startswith("#") or bool(re.fullmatch(r"\*\*[^*]{1,80}\*\*:?", s)) or bool(re.fullmatch(r"\d+\.\s*\*\*[^*]{1,80}\*\*", s))
            s = re.sub(r"^#+\s*", "", s)
            s = re.sub(r"^[-*+]\s+|^\d+[.)]\s+", "", s)
            if s.startswith("|"):
                s = " ; ".join(c.strip() for c in s.strip("|").split("|") if c.strip())
            s = s.replace("**", "").replace("__", "").replace("`", "")
            if s:
                units.append((f"line {n}", s, heading))
    return units


def split_sentences(text):
    parts = re.split(r"(?<=[.!?])\s+(?=[A-Z\[“\"(])", text)
    return [p.strip() for p in parts if p.strip()]


def load_register_ids(path: Path):
    ids = set()
    suffix = path.suffix.lower()
    if suffix in (".xlsx", ".xlsm"):
        import openpyxl
        wb = openpyxl.load_workbook(str(path), read_only=True, data_only=True)
        for ws in wb.worksheets:
            for row in ws.iter_rows(values_only=True):
                for v in row:
                    if isinstance(v, str):
                        ids.update(REF_TOKEN.findall(v))
    else:
        ids.update(REF_TOKEN.findall(path.read_text(encoding="utf-8", errors="replace")))
    return ids


# ------------------------------------------------------------------ checks
def scan(units, approved, audience, register_ids, lenient, require_decl, full_text):
    import unicodedata
    findings = []  # (category, loc, excerpt, note)

    def add(cat, loc, text, note):
        findings.append((cat, loc, text[:220] + ("…" if len(text) > 220 else ""), note))

    approved = {a.strip().lower() for a in approved if a.strip()}
    cited_ids = set()
    figures = defaultdict(list)
    ratios = defaultdict(set)

    for loc, text_raw, is_heading in units:
        # hidden / look-alike characters are reported, then removed so the wording checks cannot be evaded
        if ZW.search(text_raw):
            add("HIDDENCHAR", loc, text_raw, "contains zero-width or bidirectional control characters: possible evasion or tampering")
        if MIXED.search(text_raw):
            add("HIDDENCHAR", loc, text_raw, "a word mixes Latin letters with Cyrillic/Greek look-alikes: possible evasion or tampering")
        text = unicodedata.normalize("NFKC", ZW.sub("", text_raw))
        text = text.translate(str.maketrans({"\u0430": "a", "\u0435": "e", "\u043e": "o", "\u0440": "p", "\u0441": "c", "\u0443": "y", "\u0445": "x", "\u0456": "i"})) if MIXED.search(text_raw) else text
        for m in REF_TOKEN.findall(" ".join(REF_BRACKET.findall(text))):
            cited_ids.add(m)
        for label, rx in FIGURE_RES:
            for m in rx.finditer(text):
                figures[(label, re.sub(r"\s+", " ", m.group(0)))].append(loc)
        for m in RATIO_RE.finditer(text):
            ratios[int(m.group(2))].add(int(m.group(1)))

        sentences = split_sentences(text) or ([text] if text.strip() else [])
        merged = []
        for sx in sentences:
            if merged and not re.sub(REF_BRACKET, "", sx).strip(" .;,"):
                merged[-1] += " " + sx
            else:
                merged.append(sx)
        para_has_ref = bool(REF_BRACKET.search(text))

        for sx in merged:
            low = sx.lower()
            for rx, label in RESTRICTED:
                if label.lower() in approved:
                    continue
                for m in re.finditer(rx, sx, re.I):
                    if m.group(0).lower() in approved:
                        continue
                    nb = NEG_CONTEXT.search(sx[: m.start()] + " ")
                    neg = bool(nb and m.start() - nb.end() < 60) or bool(NEG_AFTER.search(sx[m.end():])) or bool(
                        re.search(r"\bno\s+$", sx[: m.start()], re.I) and re.match(r"\s*(?:has|have|had) been (?:quantified|established|determined|concluded|projected)", sx[m.end():], re.I))
                    if neg:
                        add("TERM_NEG", loc, sx, f"'{m.group(0)}' appears in a no-conclusion context; fine if it states that no conclusion has been drawn")
                    else:
                        add("TERM", loc, sx, f"restricted term '{m.group(0)}' needs your explicit approval plus evidence and criteria")
                    break
            if "material" not in approved:
                for m in MATERIAL_RE.finditer(sx):
                    prev = re.findall(r"[A-Za-z]+", sx[:m.start()])
                    prev_word = prev[-1].lower() if prev else ""
                    nxt = re.findall(r"[A-Za-z]+", sx[m.end():m.end() + 25])
                    next_word = nxt[0].lower() if nxt else ""
                    if prev_word in MATERIAL_PREV_OK or next_word in {
                            "cost", "costs", "handling", "master", "requisition", "movement",
                            "consumption", "code", "issue", "issues", "receipt", "receipts"}:
                        continue
                    add("TERM", loc, sx, "'material' is a conclusion about significance; use only if approved (ignore if it means physical material)")
                    break
            for rx in ABSENCE:
                if re.search(rx, sx, re.I):
                    add("ABSENCE", loc, sx, "treats a missing record as proof the event did not occur; prefer 'was not evidenced in the records made available'")
                    break
            has_sample = bool(SAMPLE_WORDS.search(sx))
            if OVERREACH_WORDS.search(sx):
                add("OVERREACH", loc, sx, "sweeping generalisation: is it supported beyond the tested sample?")
            elif OVERREACH_QUANT.search(sx) and not has_sample:
                add("OVERREACH", loc, sx, "universal claim with no sample context stated")
            if EXAGG.search(sx):
                add("EXAGG", loc, sx, "intensifier: keep the wording no stronger than the evidence (fine if it is an approved rating label)")
            if audience == "director":
                for j in JARGON:
                    if j in low:
                        add("JARGON", loc, sx, f"jargon '{j}': use plain wording or explain once")
                        break
            if audience in ("external", "director") and SPECULATE.search(sx) and not LABELS.search(sx):
                add("SPECULATE", loc, sx, "speculative wording in a document for readers outside the audit team: state only what is evidenced, or label it")
            if audience == "external":
                if AIARTEFACT.search(sx):
                    add("AIARTEFACT", loc, sx, "stock phrasing that reads as machine-generated; external documents must read as a person wrote them")
                if INTERNALVOICE.search(sx):
                    add("INTERNALVOICE", loc, sx, "internal-audit voice or judgemental wording in an external document")
            if is_heading:
                continue
            words = len(sx.split())
            if (words >= 4 and FACT_HINT.search(sx) and not sx.endswith("?")
                    and not NON_FACT_START.match(sx) and not re.search(r"\b(?:should|will|may increase)\b", low)
                    and not LABELS.search(sx) and not re.fullmatch(r"(?:\s*\[[^\]]+\])+\s*[.]?", sx)):
                covered = bool(REF_BRACKET.search(sx)) or (lenient and para_has_ref)
                if not covered:
                    add("UNREF", loc, sx, "no [EV-/WP-/CRIT-…] reference; add one or mark 'Evidence reference not available. Auditor validation required.'")

    for den, nums_ in sorted(ratios.items()):
        if len(nums_) > 1:
            findings.append(("FIGURE_VARIANTS", "document", f"x of {den}: {sorted(nums_)}", "different counts quoted out of the same sample size: check each against the workpaper"))

    if register_ids is not None:
        for rid in sorted(cited_ids - register_ids):
            findings.append(("UNKNOWN_REF", "document", rid, "cited in draft but not found in register"))

    if require_decl:
        norm = lambda t: re.sub(r"[\s“”\"']+", " ", t).strip().lower()
        if norm(DECLARATION) not in norm(full_text):
            findings.append(("DECLARATION", "document", "", "required no-drift declaration not found (exact wording)"))
    return findings, cited_ids, figures


# ------------------------------------------------------------------ output
def render(findings, cited_ids, figures, register_ids, show_uncited, fmt):
    order = ["TERM", "UNKNOWN_REF", "DECLARATION", "HIDDENCHAR", "INTERNALVOICE", "ABSENCE", "OVERREACH", "UNREF", "TERM_NEG", "EXAGG", "SPECULATE", "AIARTEFACT", "JARGON", "FIGURE_VARIANTS"]
    grouped = OrderedDict((c, [f for f in findings if f[0] == c]) for c in order)
    counts = {c: len(v) for c, v in grouped.items() if v}
    uncited = []
    if register_ids is not None and show_uncited:
        uncited = sorted(i for i in register_ids - cited_ids if i.startswith(("EV-", "FIND-")))

    if fmt == "json":
        return json.dumps({
            "counts": counts,
            "findings": [dict(category=c, severity=SEVERITY[c], location=l, excerpt=e, note=n)
                         for c, l, e, n in findings],
            "figure_inventory": {f"{k[0]}: {k[1]}": v for k, v in figures.items()},
            "uncited_register_ids": uncited,
        }, indent=2, ensure_ascii=False)

    out = ["# QA scan report", ""]
    if not findings:
        out.append("No pattern flags raised. This does not prove the draft is accurate; run Mode 8 QA "
                   "against the finding register and workpapers.")
    else:
        out.append("Summary: " + ", ".join(f"{c} {n} ({SEVERITY[c]})" for c, n in counts.items()))
    for cat, items in grouped.items():
        if not items:
            continue
        out += ["", f"## {cat} ({SEVERITY[cat]}) - {len(items)}"]
        for _, loc, excerpt, note in items:
            out.append(f"- [{loc}] {note}")
            if excerpt:
                out.append(f"    > {excerpt}")
    if figures:
        out += ["", "## Figure inventory (cross-check each against the workpaper)"]
        for (label, val), locs in sorted(figures.items()):
            out.append(f"- {label}: {val}  (x{len(locs)}; {', '.join(locs[:4])}{'…' if len(locs) > 4 else ''})")
    if uncited:
        out += ["", "## Register IDs never cited in the draft (INFO)"] + [f"- {u}" for u in uncited]
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser(description="Wording and traceability scan for audit drafts.")
    ap.add_argument("file", help=".md, .txt or .docx draft")
    ap.add_argument("--approved", default="", help="comma-separated restricted terms you have approved")
    ap.add_argument("--audience", choices=["director", "management", "audit", "external"], default="audit",
                    help="'director' flags jargon and speculation; 'external' also flags AI-sounding phrasing, internal voice and speculation")
    ap.add_argument("--register", help="register file (.xlsx/.csv/.txt) listing valid IDs")
    ap.add_argument("--uncited", action="store_true", help="list EV-/FIND- register IDs never cited")
    ap.add_argument("--lenient", action="store_true",
                    help="treat a sentence as referenced if its paragraph contains any reference")
    ap.add_argument("--require-declaration", action="store_true",
                    help="require the exact no-drift declaration")
    ap.add_argument("--format", choices=["md", "json"], default="md")
    ap.add_argument("--out", help="write the report to this file")
    a = ap.parse_args()

    path = Path(a.file)
    if not path.exists():
        sys.exit(f"File not found: {path}")
    units = load_units(path)
    full_text = "\n".join(t for _, t, _ in units)
    reg = load_register_ids(Path(a.register)) if a.register else None
    findings, cited, figs = scan(units, a.approved.split(","), a.audience, reg, a.lenient,
                                 a.require_declaration, full_text)
    report = render(findings, cited, figs, reg, a.uncited, a.format)
    if a.out:
        Path(a.out).write_text(report, encoding="utf-8")
        print(f"Report written to {a.out}")
    else:
        print(report)
    sys.exit(1 if any(SEVERITY[f[0]] in ("HIGH", "MED") for f in findings) else 0)


if __name__ == "__main__":
    main()
