---
name: gia-report-qa
description: "Pre-issue quality pipeline: deterministic scans, the 12-item Quality Gate, independent QA passes, read-only reviewer panel, Four-Lane and devil's-advocate tests, adversarial critique, hash-bound sign-off. Use when about to issuing any report, Board paper or skill, or to QA, critique or second-opinion a deliverable. Do NOT use for drafting (use gia-report-qa:gia-ia-report)."
---

# GIA Report QA

Two different mechanisms, named exactly so that "the quality gate" is never ambiguous:
- **Quality Gate (12)**: the pass/fail checklist of end-states for a report going FINAL (Rule 09 in `gia-core:iron-rules`). Rules 33 to 39 are drafting discipline, not extra gate items.
- **Independent QA passes**: sequential review passes before release (independent read, proofread, internal consistency, zero-fabrication, humanised voice; the external copy runs four).
Other lists (conversion checklist, external Output Gate, presentation Judge) are add-ons for their own artefact and never called "the quality gate".

## Pipeline

| Stage | What | Who | Blocks issue? |
|---|---|---|---|
| 1. Deterministic scans | `trace_check.py`, `qa_scan.py`, `jargon_scan.py`, `profile_b_lint.py`, `consolidated_iar_check.py`, `tieout_check.py` | Script, run by a Haiku or Sonnet agent | ERROR yes; WARN needs a disposition |
| 2. Quality Gate (12) | `references/quality-gate-checks.md` | `agents/report-qa-reviewer.md` (read-only) | Any fail |
| 3. Independent QA passes | `references/independent-qa-passes.md` | Reviewer, different agent from the preparer | Any defect |
| 4. Read-only panel | accuracy (Sonnet), clarity (Haiku), objectivity (Haiku) in parallel | `agents/accuracy-advisor.md`, `clarity-advisor.md`, `objectivity-advisor.md` | Blocks as rated |
| 5. Four-Lane and devil's advocate | `references/four-lane-and-devils-advocate.md` | Reviewer | Qualify or close the gap |
| 6. Human sign-off | `gia-evidence-trace/scripts/qa_gate.py record` then `verify` | A named human; hash-bound | Required for FINAL |

The planner rules on disputes only and never marks the gate passed. QA is always a different agent from the preparer (Rule 32 in `gia-core:iron-rules`). The reviewers never edit; they return a table of Issue / Where / Severity (Blocks issue, Fix before issue, Consider) / Why it matters, then a one-line overall view.

## Stage 1 commands

```bash
python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-evidence-trace/scripts/trace_check.py --register R.xlsx --report report.docx
python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-report-qa/scripts/qa_scan.py report.docx --audience director --register R.xlsx     # director|management|audit|external
python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-board-brief/scripts/jargon_scan.py report.docx
python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-report-qa/scripts/profile_b_lint.py report.docx report.html wp.xlsx --profile B    # A for auditee packs
python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-ia-report/scripts/consolidated_iar_check.py --docx ... --html ... --xlsx ... --deleted deleted.txt --figures figures.csv
```
Limits to state when presenting results: scans test patterns, not truth; P04 and qa_scan wording flags are heuristics; a clean run is necessary, not sufficient; exit code 2 means the check did not run and is never a pass. `qa_scan.py --require-declaration` is for the QA log or chat reply only; a Board or external file must not contain the declaration (`profile_b_lint.py` flags it).

## Quality Gate scripted add-ons

Finding-count consistency: every count, rating and exposure figure identical wherever it appears (`consolidated_iar_check.py`, `references/independent-qa-passes.md` pass 3). Deficiency type check: design vs operating conclusion matches the test type (test of design vs test of effectiveness). Correction log: kept outside the report.

## Profile checks

Profile B (Board, AC, Chairman, external-grade): no emoji, no alert boxes, no self-commentary or process narration, no sheet, row or cell references in the body, no declarations, tables over narrative, rating as text. Profile A may carry one "how to check" line per finding. Tone check: evidence-calibrated and balanced; no softening of a rating, no alarm words that the rating does not carry.

## Mode B and Mode A critique

- Deliverable critique (report, RACM, register): `references/deliverable-critique-standard.md`. Write each critique finding like an audit finding (condition, criteria, cause, effect, recommendation) with a citation. Five-point discipline: re-read the actual file fresh; start from empirical script output; cite evidence for every finding; never soften to avoid friction with prior work; state what was not checked. A critique that claims total coverage is itself a finding.
- Skill critique: `python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-report-qa/scripts/run_critique.py --skill DIR --out report.md` produces the empirical frame; reasoning sections marked FILL IN must be completed (`references/skill-critique-standard.md`).
- Independence here is discipline plus a separate agent, not a guarantee of a separate process; say so in the critique.
- A generalisable error found goes to `gia-core:self-learning` for logging so the next build checks for it first.

## Verified, confirmed, reconciled

Before using any of these words, point to the tool call, document or computation that supports it. "Should be fine" and "appears to" are unlabelled opinion. If not verified, say "Not independently verified". Recompute source totals; a reconciliation tab that reconciles to itself is untested. Detail: `references/four-lane-and-devils-advocate.md`.

## Sign-off

`qa_gate.py record --reviewer reviewed` only if the reviewer agent really ran (otherwise `not-run`), then `verify`; quote its verdict. Any edit to the report or register after `record` voids the sign-off. Claude never sets approval status; a human does.

## References

| File | Read when |
|---|---|
| `references/quality-gate-checks.md` | Applying the Quality Gate (12) |
| `references/independent-qa-passes.md` | Running the review passes |
| `references/four-lane-and-devils-advocate.md` | Grounding claims; final adversarial pass |
| `references/deliverable-critique-standard.md` | Critiquing a report or register |
| `references/skill-critique-standard.md` | Critiquing a skill |
| `references/writing-quality.md` | Plain-language and sentence-level tests |
| `references/stakeholder-influence.md` | Internal engagement and buy-in (internal only) |
| `references/independent-qa-passes-internal.md` | Source text of the internal passes, including the humanised-voice pass |

Stage sequence from intake to closure, intake questions and standing chain rules: `references/assurance-chain.md`.
