# Independent QA passes

## Contents
- Sequence
- Pass 1 Independent read
- Pass 2 Proofread
- Pass 3 Internal consistency
- Pass 4 Zero-fabrication
- Pass 5 Humanised voice (internal papers)
- External variant

Sequence: independent read (settles content), proofread (mechanical), internal consistency (against a now-stable document), zero-fabrication, then humanised voice for internal papers. The external copy runs passes 1 to 4 (see `gia-report-qa:gia-external-release`). The reviewer is a different agent from the preparer.

## Pass 1 Independent read
Read as the Board member seeing it for the first time. Does the summary match what the findings support? Would a second senior reviewer sign off without a change? Read once for structure and once for content.

## Pass 2 Proofread
Spelling, grammar, consistent date and number formats; acronyms defined once; heading numbers and cross-references; consistent rating labels in every table.

## Pass 3 Internal consistency
A finding count, rating, exposure or date that appears in the summary, the finding and any appendix is identical everywhere. Owners and dates in text match the action tracker. If a figure changed during drafting, search for the old value everywhere. Use `consolidated_iar_check.py` for count and figure checks across DOCX, HTML and XLSX.

## Pass 4 Zero-fabrication
For every number, date, name or conclusion, point to its exact source now (workpaper, evidence reference, labelled representation, named standard). If not, it does not go in; state the limitation instead. Applies to material facts; non-material drafting choices take sensible defaults.

## Pass 5 Humanised voice (internal papers)
Remove stock openers and formulaic closers, symmetric triads and stacked hedges, uniform paragraph rhythm, corporate filler, three sentences in a row with the same opening, and over-hedging where evidence supports a direct statement. Tone only: never changes a rating or fact. Full list: `references/independent-qa-passes-internal.md` section 5.
