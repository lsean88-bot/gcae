# Assurance chain (S0 to S7)

Sequence and gates from intake to closure. Ported from the retired assurance orchestrator. This chain sequences work; each stage is done by the skill named.

## Contents
1. The chain
2. S0 intake questions
3. Rules enforced across the chain
4. Reading state

## 1. The chain
| Stage | What happens | Skill | Gate to leave the stage |
|---|---|---|---|
| S0 Intake | Engagement, audience, deliverable set, register created | `gia-report-qa:gia-evidence-trace` | Audience and deliverables agreed |
| S1 Evidence and criteria | EV and CRIT IDs issued, graded R1 to R5 | `gia-report-qa:gia-evidence-trace` | No evidence ungraded; no R5 relied on |
| S2 Procedures and workpapers | PROC and WP recorded with population, sample, result, conclusion boundary | `gia-report-qa:gia-evidence-trace` | Every WP has a reviewer or is marked UNREVIEWED (trace check R20 warns) |
| S3 Findings | Finding sheets drafted | `gia-report-qa:gia-evidence-trace` | Human approval: auditor or CAE sets approval status |
| S4 Management response | Response recorded; actions agreed | `gia-report-qa:gia-evidence-trace` | Owner and date for each High or Critical finding |
| S5 Reporting | Director summaries, leadership decision brief, deck | `gia-report-qa:gia-board-brief`, `gia-report-qa:gia-presentation` | Only approved findings enter |
| S6 QA gate | Trace check, jargon scan, independent read | `gia-report-qa:gia-report-qa` | Zero ERRORs; WARNs dispositioned; sign-off verify passes (void if report or register changes afterwards) |
| S7 Closure | Action tracking, closure validation, benefit check | `gia-report-qa:gia-evidence-trace` | Validated by testing, not by assertion |

Stages are not strictly linear: findings can arrive while evidence is still being gathered and reporting can start on the approved subset. The gates stay fixed.

## 2. S0 intake questions
Ask only what is missing, in one message:
1. Engagement name, entity, period, and the approving auditor (the person who may set Auditor-approved).
2. Audience for each deliverable: A Board or AC, B CEO, CFO or plant head, C process owner, D audit team.
3. Is there an existing register, finding list or workpaper set? If so, import rather than restart.
4. Does anything leave the Group (regulator, external auditor, lender)? If so use `gia-report-qa:gia-external-release`.

Pick the deliverable set; a short engagement does not need every item, a Board pack needs at least the register, approved finding sheets and the director report. The register is the single source of truth: a fact not in the register is not yet in the audit.

## 3. Rules enforced across the chain
- Approval is human. A draft finding never enters a director summary, decision brief or deck. Never set a finding to approved on a passing remark; record the approver and date.
- No drift. Reporting may reword, never alter, approved facts, rating, criteria, sample result, cause, impact, recommendation, owner or date. A needed change is a change request to the finding, with the register updated first.
- Unknowns stay unknown: write them as gaps ("evidence reference not available, auditor validation required"; "not quantified, management validation required").
- One QA gate before issue: scans, then a separate read by a different agent. A report with ERROR items is not issued.
- Closure is tested: status goes to closed only through closure validation.
- Two-attempt limit: a failing step is retried once at most, then skipped and reported as not completed.

## 4. Reading state
When asked where things stand, read the register (dashboard and trace matrix) and report findings by status, High and Critical items not yet traceable, open evidence gaps, overdue actions and actions awaiting validation. Do not estimate progress from memory of the conversation.
