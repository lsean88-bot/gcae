# Quality Gate (12): how each item is checked

The gate itself is defined in `gia-core:iron-rules` (Rule 09). This table maps each item to how it is checked and by whom; if the two disagree, `gia-core:iron-rules` wins and this table is corrected.

## Contents
- Mapping
- Profile notes
- Conversion and external add-ons

| # | Gate item (short) | Check | Tool |
|---|---|---|---|
| 1 | Named evidence R1-R4 or validated portal URL on every finding; no R5 | Register lookup | `trace_check.py` (R5 codes) |
| 2 | Every rate, section, threshold validated with source URL | Compare with the dated statutory register; unverified = [UNVERIFIED] | Reviewer; no inline rates in the text |
| 3 | Correct Act, effective date and jurisdiction | All three verified against the register | Reviewer |
| 4 | No duplicate findings | Compare titles and evidence; merge | `consolidated_iar_check.py` count; reviewer |
| 5 | No retracted, draft or internal CAE note text | Grep deleted terms and note markers | `consolidated_iar_check.py --deleted`; `profile_b_lint.py` |
| 6 | Every finding rated | Rating present from the approved scale; text rating in Profile B, colour allowed in Profile A | Reviewer |
| 7 | Deficiency classification CD / SD / MW documented | Present and defensible; design vs operating type matches the test | Reviewer |
| 8 | Aggregation assessment done | Related deficiencies reviewed together | Reviewer |
| 9 | All recommendations SMART with owner and date | Owner role and date present | `trace_check.py`; reviewer |
| 10 | Version control: version, date, classification, CAE sign-off | Cover fields; sign-off recorded by a human | `qa_gate.py` |
| 11 | Document reference appendix lists all evidence reviewed | Appendix vs register | `trace_check.py` |
| 12 | Disclaimer present: professional IA report, not a statutory audit, CA certificate or legal opinion | Text present | Reviewer |

## Profile notes
Profile B files satisfy item 6 with a text rating. Item 5 includes self-commentary and declarations, which `profile_b_lint.py` flags.

## Conversion and external add-ons
The conversion checklist (legacy 13-section mode) and the external Output Gate (`gia-report-qa:gia-external-release`) run in addition to, never in place of, this gate. A presentation also passes the Judge (`gia-report-qa:gia-presentation`).
