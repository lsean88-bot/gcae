# Independent Quality Assurance & Humanised-Voice Gate — Reference

Run this alongside the Quality Gate in SKILL.md. It covers what audience-design and plain
language don't: whether the document is internally consistent, error-free, and actually reads
as though a skilled human leader wrote it — not a template with the blanks filled in. This is
also how Standard 11.2's requirement for "accurate, objective, clear, concise, constructive,
complete and timely" communication gets tested before release, not assumed.

## 1. Independent Quality Check

Re-read the finished document as a Board member seeing it for the first time, not as a final
skim of your own drafting.

- Does the BLUF/Executive Summary conclusion match what the detailed findings actually support?
- Would a second reviewer — another senior audit professional — sign off without a single
  requested change? If any sentence would draw a query, resolve it now.
- Read once for structure (does the story flow logically, is anything referenced before it's
  introduced) and once for content — these catch different defects.

## 2. Proofreading Pass

- Spelling, grammar, punctuation
- Consistent date and number formatting throughout
- Every acronym defined once at first use, then used consistently (or replaced with the plain
  English term per the Plain Language table — never both, inconsistently)
- Heading numbering and cross-references correct
- Table formatting and risk-rating symbols used consistently across every table in the document

## 3. Internal Consistency Check

- A finding count, risk rating, dollar exposure, or date that appears in the BLUF, the Executive
  Summary, the detailed finding, and any appendix must be **identical** in every one of those
  places.
- A finding's risk rating (Critical/High/Medium/Low) must match wherever it's referenced,
  including in any heat map or summary table.
- Named owners and target dates in narrative text must match the action tracker exactly.
- If a figure changed during drafting, search the whole document for the old value — fixing one
  instance and missing another is the most common defect in multi-section reports.

## 4. Zero-Fabrication & No-Assumptions Check

Apply the Iron Rule at the sentence level: for every specific number, date, name, or conclusion,
confirm you could point to its exact source — a workpaper, an evidence reference, a management
representation, or a named standard — right now.

- If yes: it stays, sourced as normal.
- If no: it does not go in the document. State the limitation plainly ("based on the information
  available...", "management has represented that...") rather than filling the gap with a
  plausible-sounding figure.

This applies to material facts specifically — dates, figures, entities, ownership, control
effectiveness, or a risk/audit conclusion. If one of these is missing or unclear, stop and ask
rather than inferring or estimating; a report with a clearly flagged gap is correct, one that
papers over it with a reasonable-sounding guess is not. This does not apply to non-material
drafting choices (structure, template selection, phrasing) — a sensible default there is normal
and expected.

## 5. Humanised, Non-AI Voice Check

Plain language and the non-expert test (see `references/writing-quality.md`) get the content
right; this catches the *pattern* that makes writing sound machine-generated even when every
sentence is individually correct.

Scan for and remove:

- Stock openers/transitions: "It is important to note that...", "Furthermore,",
  "Additionally," — cut and state the point directly.
- Formulaic closers: "In conclusion,", "Overall, it can be said that..."
- Symmetric triads and hedge-stacking piled up sentence after sentence
- Uniform paragraph rhythm — every paragraph the same length and shape
- Generic corporate filler: "leverage", "utilize", "robust", "holistic", "seamless"
- Three sentences in a row with the same subject or opening word
- Over-hedging where the evidence supports a direct statement

Self-test: would an experienced, respected CAE sign their name to this exact sentence, or does
it read like a template with the nouns swapped? If the latter, rewrite it in your own words
while keeping every fact intact — this governs tone only, never a risk rating or a fact.

## Sequence

Independent quality check first (settles content), then proofread (fixes mechanical errors),
then internal consistency (checked against a now-stable, clean document), then the
zero-fabrication and humanised-voice checks as a final pass before release.
