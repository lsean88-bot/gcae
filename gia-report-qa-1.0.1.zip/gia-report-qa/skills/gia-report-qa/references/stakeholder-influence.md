# Stakeholder Influence, Relationship-Building & Positive Presence — Reference

## Contents
- 1. The mandate
- 2. Stakeholder mapping — Power/Interest Matrix
- 3. Winning genuine buy-in — the ethical influence toolkit
- 4. Positive, amicable professional mindset
- 5. Presentation craft — in the room, not just on the page
- 6. Turning findings into buy-in-ready recommendations (WIIFM)
- 7. Additional checklist items for the Quality Gate


Governs how the CAE builds relationships, earns trust, and wins genuine buy-in for audit
findings and recommendations — in writing and in the room. This is an INTERNAL-facing
capability: it applies to Board/AC/Management engagement under `gia-report-qa:gia-ia-report`. It does
not apply to `gia-report-qa:gia-external-release` — regulator and external-auditor documents stay
strictly evidence-only with no persuasive framing (see that skill's Golden Rule).

## 1. The mandate

This isn't a soft add-on — it's a standards requirement. IIA Global Internal Audit Standards
2024, Domain IV (Managing the Internal Audit Function), Principle 11 "Communicate Effectively":

- **Standard 11.1 — Building Relationships and Communicating with Stakeholders**: the CAE must
  develop an approach to build relationships and trust with key stakeholders (Board, senior
  management, operational management, regulators, assurance providers) and foster mutual
  understanding of organisational interests, risk approaches, roles, and regulatory context.
- **Standard 11.2 — Effective Communication**: the CAE must implement methodologies that make
  communications accurate, objective, clear, concise, constructive, complete, and timely.

Relationship-building and communication quality are conformance requirements, not personality
traits — treat this reference with the same rigor as any other Standard.

## 2. Stakeholder mapping — Power/Interest Matrix

Before drafting or presenting, map the stakeholders in play using the classic power–interest
grid (Mendelow), then tailor engagement to the quadrant:

| | Low Interest | High Interest |
|---|---|---|
| **High Power** | **Keep Satisfied** — brief, high-level, decision-focused. Don't over-inform; respect their time. (e.g. a Board member outside the AC, a group shareholder) | **Manage Closely** — full transparency, frequent touchpoints, involve early. (e.g. AC Chair, CEO, CFO on a material finding) |
| **Low Power** | **Monitor** — light-touch, periodic updates only. (e.g. a peripheral function unaffected by the finding) | **Keep Informed** — clear, complete detail; they can't decide but they can advocate or resist. (e.g. the process owner who will implement the fix) |

Use this alongside the Audience Communication Map above — the map tells you *how* to write for
each audience; this tells you *how much attention and access* each one needs before you write.

## 3. Winning genuine buy-in — the ethical influence toolkit

Adapted from Cialdini's principles of influence for CAE use. Every technique below stays inside
the IIA Code of Ethics (Integrity, Objectivity) — the goal is legitimate influence through
value and trust, never pressure toward a conclusion the evidence doesn't support.

| Principle | Audit-appropriate application |
|---|---|
| **Reciprocity** | Lead with value before asking for anything — share a useful risk insight, offer to help think through a fix, flag something proactively. Goodwill invested early is returned as openness later. |
| **Commitment & Consistency** | Validate facts with the process owner *as you go*, not just at the final report ("Does this match what you're seeing?"). Agreement to the facts early makes the final recommendation a natural next step, not an ambush. |
| **Social Proof** | Reference how a peer business unit, another Group entity, or common industry practice already handles this well — reduces "why us" resistance without needing to argue the point in the abstract. |
| **Authority** | Ground every recommendation in the named standard or framework (COSO, IIA GIAS, the applicable statute) and in the evidence itself — credibility from rigor, never from title alone. |
| **Liking** | Invest in the relationship before you need it. Genuine curiosity about a stakeholder's operational constraints builds more trust than any amount of polish in the final report. |
| **Unity** | Frame Internal Audit and Management as protecting the same organisation, not as opposing sides. "We're both accountable for this working" lands better than "you got this wrong." |
| ~~Scarcity~~ | **Do not use.** Manufacturing false urgency to force agreement is manipulation, not influence, and breaches objectivity. Where real urgency exists (a live control failure, a regulatory deadline), state it as a fact with its evidence — the urgency should come from the situation, not from framing. |

### The hard boundary

These are tools for building trust and communicating persuasively — never tools for talking a
stakeholder into accepting a conclusion the evidence doesn't support, and never a reason to
soften a rating, a root cause, or a recommendation to keep the relationship comfortable.
Independence and objectivity always come first; influence skill serves the message, it doesn't
replace the evidence behind it.

## 4. Positive, amicable professional mindset

Draws on the emotional-intelligence competencies most associated with strong audit judgment
(self-awareness, self-regulation, motivation, empathy, social skill):

- **Self-awareness**: notice your own reaction before a difficult conversation — walking in
  irritated or anxious changes how a finding lands, regardless of the words used.
- **Empathy before delivery**: understand the operational pressure the stakeholder is under
  *before* presenting the finding — it changes tone, not substance.
- **Active listening protocol**: before recommending, restate the stakeholder's position back to
  them in your own words and confirm you've understood it correctly. This alone resolves a large
  share of what would otherwise become pushback.
- **Shared-problem framing**: "Here's what we're both trying to protect, and here's the gap
  between where we are and where we want to be" lands as partnership. "Here's what you did
  wrong" lands as an attack — even when the underlying fact is identical.
- **Composure under challenge**: a calm, curious response to pushback ("Help me understand your
  concern") reads as confidence; a defensive one reads as uncertainty about the finding itself.

This governs interpersonal conduct and framing — it never means softening a risk rating,
omitting a fact, or letting rapport substitute for evidence. Professional skepticism and
objectivity are not in tension with a positive mindset; research on auditor judgment
consistently finds the two work together, not against each other.

## 5. Presentation craft — in the room, not just on the page

- **Lead with the conclusion, always.** Board/AC attention is front-loaded — the Pyramid
  Principle applies to spoken delivery as much as written BLUF.
- **Rule of Three.** Cluster supporting points into three, not five or seven — retention drops
  sharply beyond three clusters in a live meeting.
- **Have the one-sentence version ready.** If asked "what's the bottom line?" mid-presentation,
  you should be able to answer in one sentence without flipping back to a slide.
- **Use "and," not "yes, but."** Responding to pushback with "and" ("and here's what the data
  shows...") keeps the stakeholder's point valid while adding yours; "but" discards it.
- **Let silence work.** After delivering a hard message, pause. Rushing to fill the silence
  reads as discomfort with your own conclusion.

## 6. Turning findings into buy-in-ready recommendations (WIIFM)

Pair every recommendation with the stakeholder's own stated priority, not just the audit
rationale — show how closing the gap serves what they already care about:

> Instead of: "Implement three-way matching to close this control gap."
>
> Write: "Implementing three-way matching closes this control gap and directly supports the
> [CFO's stated Q3 priority of reducing duplicate payments] — the same control fixes both."

Where no stated stakeholder priority is known, don't invent one — ask, or fall back to
organisational objectives already on record (strategic plan, risk appetite statement).

## 7. Additional checklist items for the Quality Gate

- [ ] Key stakeholders mapped by power/interest before drafting or presenting
- [ ] Findings validated with the process owner before the report is finalised — no ambush
- [ ] Where a stated stakeholder priority exists, the recommendation is tied to it
- [ ] Tone reads as a partner solving a shared problem, not an adversary assigning blame
- [ ] No manufactured urgency — any urgency stated is factual and evidenced
- [ ] Independence and objectivity intact — rapport never substituted for evidence
