# Skill Critique Standard (Mode A)

The bar is four real findings from an earlier critique of this library (July 2026). This file extracts what made each one useful so the pattern transfers to the next skill. The original critique file is not part of this plugin; the table below is the retained evidence.

## What a real finding looks like vs what doesn't count

| Real finding (earlier critique) | Why it counts |
|---|---|
| "Charter" collision between an engagement-charter skill (per-engagement terms of engagement) and a function-charter skill (Board-level Audit Charter) — a specific query, *"What does GIA's Audit Charter say about our access rights?"*, could trigger the wrong one | Names the specific ambiguous term, the two specific skills, and a concrete query that exposes it — not "these might overlap" |
| An orchestrator skill's body had a whole section handling "subagents disagree," but the frontmatter description (what's actually matched pre-read) didn't contain that phrase | Distinguishes *description* coverage from *body* coverage — the single most common false-confidence trap in skill authoring |
| "Is this new mandate even within our approved scope of work?" doesn't share explicit trigger words with the intended skill — flagged, explicitly **not** fixed, with the reasoning for not fixing it stated | A finding doesn't have to result in a change; it has to result in an honest, evidenced judgement call, stated as such |
| "run Benford's Law on this CSV" not triggering the orchestrator — verified as intended behaviour, not a bug | Distinguishes a real gap from a correct design choice — not everything that doesn't trigger a skill is a defect |

**Doesn't count as a finding:** "the description could be clearer," "consider adding more
examples," "looks good overall" — none of these cite a specific query, a specific skill,
or a specific piece of text. If you can't point at the exact phrase or the exact missing
word, you haven't found anything yet — keep reading.

## The five things every completed Mode A critique states

1. **What ran empirically vs what's reasoned.** a header table ("Could run and did" / "Could not run") — do this every time, don't assume the
   reader remembers the sandbox's limitations from a previous critique.
2. **At least one structural result**, even if it's "passed cleanly, no change needed" —
   silence on this isn't the same as a pass; state it.
3. **Every trigger-ambiguity finding cites the exact query and the exact gap** — the
   table above is the template.
4. **A redundancy/consistency check across the library**, not just the artifact in
   isolation — a grep-based orphan check and a duplicate-map are the model: don't just check the new thing against itself, check it
   against everything else that already exists.
5. **A self-aware limitations section** — a "What I would flag if grading this" section, naming an actual coverage gap in the critique itself (in
   that case: no eval case tested a query that maps to two skills at once). A critique
   that doesn't name its own blind spot is claiming more certainty than it has.

## Using `run_critique.py`'s skeleton

The script fills in section 1 (empirical) and structures sections 2–5 as `FILL IN`
prompts. Do not submit a critique that leaves those as the placeholder text — that is
the entire reasoning content of the critique; the script only ever produces the frame.
