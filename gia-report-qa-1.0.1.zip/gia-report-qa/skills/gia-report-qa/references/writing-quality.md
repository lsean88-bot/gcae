# Writing Quality & Plain Language Reference

## Contents
- The Three-Question Test
- Plain Language Substitution — Extended Table
- Sentence-Level Rewrites — Before and After
- Narrative Sentence Starters — Avoid vs Use
- Structure Patterns for Common Sections
- Visual Selection Guide
- The "Non-Expert Test" — Self-Check Protocol


## The Three-Question Test
Before releasing any document, every paragraph must answer:
1. **So what?** — Does this sentence tell the reader why it matters?
2. **Who and when?** — Is there a named owner and a date on every action?
3. **Prove it?** — Is every claim supported by evidence or a source?

---

## Plain Language Substitution — Extended Table

| Audit / Finance Jargon | Plain English Alternative |
|---|---|
| Control deficiency | A gap in the process that allowed an error or risk |
| Operating effectiveness | Whether the control actually works in practice |
| Design effectiveness | Whether the control was set up correctly in the first place |
| Inherent risk | The risk that exists before any controls are in place |
| Residual risk | The risk that remains after controls have been applied |
| Material weakness | A serious control gap that could lead to significant loss or error |
| Significant deficiency | A notable control gap that needs prompt attention |
| Management override | When a manager bypasses the normal approval or control process |
| Three Lines Model | How responsibility for managing risk is shared across the organisation |
| Audit universe | The full list of processes and areas that Internal Audit can review |
| Scope limitation | Something that restricted what we were able to review |
| COSO | The international framework we use to assess internal controls |
| IIA Standards | The professional rules that govern how internal audit must operate |
| Substantive testing | Checking actual transactions to verify they are correct |
| Walkthrough | Tracing a transaction from start to finish to understand how a process works |
| Segregation of duties | No one person should have full control over a process start to finish |
| Compensating control | An alternative safeguard that reduces risk when the primary control is absent |
| Risk appetite | How much risk the organisation is willing to accept in pursuit of its goals |
| Key control | The most important safeguard in a process — if this fails, the risk is exposed |
| Tone at the top | The attitude and behaviour of senior leaders toward ethics and controls |
| Sample | A selection of transactions tested — not the entire population |
| Population | The full set of transactions or items that could have been tested |
| Audit opinion | Internal Audit's overall conclusion on the health of the controls reviewed |
| Finding | Something Internal Audit identified that needs attention or improvement |
| Observation | A lower-priority note for management's awareness |
| Root cause | The underlying reason why the problem occurred |
| Corrective action | The specific step taken to fix the problem |
| Remediation | The process of fixing a control gap or resolving a finding |

---

## Sentence-Level Rewrites — Before and After

**Before (jargon-heavy):**
> "The audit identified a control deficiency in the procure-to-pay process whereby
> the operating effectiveness of the three-way matching control was found to be
> insufficient, resulting in a residual risk exposure in excess of materiality."

**After (plain language):**
> "We found that the system check designed to match purchase orders, delivery receipts,
> and invoices before payment is not working reliably. As a result, the company is at risk
> of paying for goods or services it did not receive. This risk is significant enough to
> require immediate attention."

---

**Before (passive and vague):**
> "It was noted that certain approval authorities were not being consistently adhered to
> by relevant personnel in the applicable business units during the review period."

**After (active and specific):**
> "In 14 of 40 transactions we reviewed (35%), payments were approved by staff who did
> not have the authority to do so under the company's approval policy. This means purchases
> were made without proper oversight, increasing the risk of error or misuse."

---

## Narrative Sentence Starters — Avoid vs Use

| Avoid | Use Instead |
|---|---|
| "It was noted that..." | "We found that..." |
| "There exists a concern regarding..." | "There is a risk that..." |
| "Management has been advised to..." | "We recommend that [Name] should..." |
| "The control environment was found to be..." | "Controls in this area are [strong/weak] because..." |
| "Notwithstanding the above..." | "However..." |
| "In accordance with best practice..." | "Good practice requires that..." |
| "It is recommended that consideration be given to..." | "[Name] should [specific action] by [date]." |
| "Going forward..." | "From [date] onwards..." |

---

## Structure Patterns for Common Sections

### For "What We Found" — Use the FAR Pattern
- **Fact:** State what was observed
- **Amount:** Quantify it (number, percentage, dollar value)
- **Reference:** Name the evidence source

> "Purchase orders were missing for 18 of 50 payments reviewed (36%), totalling
> RM 240,000, based on the accounts payable listing for Q1 2025."

### For "Why It Matters" — Use the RACE Pattern
- **Risk:** What could go wrong
- **Amount:** How much is at stake
- **Consequence:** What the result would be
- **Example:** If possible, a real or illustrative example

> "Without purchase order controls, payments may be made for goods never received.
> The 18 transactions without POs total RM 240,000. If even a fraction of these
> represent fictitious purchases, the financial and reputational damage could be
> significant. Similar gaps have led to vendor fraud in comparable organisations."

### For "What We Recommend" — Use the SMART Pattern
> "[Owner / Role] to [specific action] by [date], measured by [evidence of completion].
> This will [expected improvement / risk reduction]."

---

## Visual Selection Guide

| Situation | Best Visual |
|---|---|
| Show overall risk portfolio | 5×5 Risk Heat Map |
| Show status of multiple findings/audits | Status table with a text rating column (colour words only in Profile A) |
| Show trend over time | Line chart or arrow indicators (↑→↓) |
| Compare this period vs. prior | Side-by-side table with variance column |
| Highlight one critical message | Callout / BLUF box |
| Show process flow or control gap | Simple flowchart (→ decision → outcome) |
| Summarise complex data quickly | Dashboard-style scorecard table |
| Show who owns what and by when | Action tracker table |

---

## The "Non-Expert Test" — Self-Check Protocol

Read your document as if you are:
- A Board member who has never worked in audit
- Smart and senior, but unfamiliar with your specific findings
- Reading this on a tablet between two other meetings

Ask:
1. Do I know within 10 seconds what this document is about?
2. Do I know what the biggest risk is?
3. Do I know what I am being asked to do?
4. Is there any sentence I had to read twice to understand?
5. Are there any words I would need to look up?

If the answer to 4 or 5 is yes — rewrite those parts.
