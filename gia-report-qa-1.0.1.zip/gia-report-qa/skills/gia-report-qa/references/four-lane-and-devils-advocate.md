# Four-Lane test, grounding words, devil's advocate

## Contents
- Four-Lane test
- Grounding "done", "verified", "confirmed"
- Self-verification checklist
- Devil's-advocate pass

## Four-Lane test
Classify every sentence before it enters a finding, report or status update.
1. **Fact**: traceable to a cited source (document, system export, interview note, tool output, recomputation performed). Tag with R1-R5 and the Rule 37 class (map in `gia-report-qa:gia-evidence-trace` `references/evidence-label-map.md`).
2. **Assumption**: fills a gap; label "ASSUMED, NOT EVIDENCED" or carry it as an open dependency; never presented as fact.
3. **Risk**: forward-looking exposure; labelled as risk.
4. **Opinion**: professional judgement or recommendation; kept visibly separate.
Only Fact-lane statements appear as unqualified fact.

## Grounding the words "done", "verified", "confirmed", "reconciled"
1. Point to the specific tool call, document or computation. "Typically", "generally", "appears to" are not verification.
2. If verification was not performed, say so: "Not independently verified; management representation only."
3. Corroboration cap: a finding resting on inspection or management representation alone, with no independent confirmation or physical observation, cannot be rated above High.
4. Reconciliations: recompute the source totals yourself before accepting a management summary tab.

## Self-verification checklist (against session evidence, not memory)
- Each root cause follows condition-criteria-cause-effect-recommendation logic.
- Each "reconciled" or "tied out" claim names the totals compared and who or what computed them.
- Each finding carries an evidence grade and the corroboration cap has been applied.
- Source-document gaps are labelled; limits on time, access and scope are stated in the deliverable.
- The devil's-advocate pass was actually run.

## Devil's-advocate pass
Mandatory before finalising any finding, root cause or fraud-ladder conclusion (`gia-fraud:gia-fraud-investigation` for ladder wording).
- What is the weakest premise; would it survive "how do you know that" from a sceptical Committee member?
- Is the corroboration independent, or two representations repeating the same assertion?
- Does the recommendation address the root cause or patch the symptom as management frames it?
- Is there a more benign explanation for the same evidence pattern that the conclusion does not rule out?
If a real gap appears, qualify the deliverable or close the gap before calling it final.
