---
name: gia-disclosure-calibration
description: "Decides what to disclose, at what depth and where, by audience, using a three-layer model, the item-naming rule (name all up to 15, appendix above) and a seven-question disclosure test. Use when asked for body versus appendix, whether a fact is safe to disclose, or partial lists and repeated figures. Do NOT use for writing the report (use gia-report-qa:gia-ia-report)."
---

# GIA Disclosure Calibration

Principle: disclose to the level of the decision; evidence to the level of verification. The reader understands the issue, decides and acts without drowning, and every number stays traceable. The binding drafting rules are in `gia-core:iron-rules` (Rules 33 to 39); this skill is the working method and does not restate their text.

## 1. Three layers

| Layer | Reader | Question | Depth | Where |
|---|---|---|---|---|
| L1 Decision | Chairman, Board, Audit Committee | What happened, how big, what do you need from me? | Key message of 25 words or fewer per finding; size, why it matters, what works, decision or ask; no jargon | Bottom line and findings at a glance |
| L2 Action | CEO, CFO, GM, plant heads | What exactly is to be fixed, by whom, by when? | Cause, control gap, action, owner, date; full item identity where individual action is needed | Finding blocks |
| L3 Verification | Process owners, auditors | Prove it; let me re-perform | Full population schedules, formulas, source references, recompute logs | Appendix schedules and the Excel working paper |

## 2. Item-naming rule (population N behind a finding)

| N | Body | Appendix |
|---|---|---|
| 15 or fewer | Name every item in a table in the finding block | Same list again for completeness |
| More than 15 | Summary only: count, value, distribution (ageing, plant, value band, type), cause, action. No excerpt table | Complete schedule of every item, tied to the workpaper |

No partial lists: the body never carries "top 10", "largest" or "oldest" excerpts. Flags (oldest, largest, disputed) are columns in the appendix schedule. Always show named + remainder = total. A single item may be named in body text only if it is at least 5 percent of the finding's value or a decision point.

## 3. Disclosure test (apply to every fact)

1 Decision-relevant? 2 Material (value, frequency, risk, regulatory)? 3 Actionable by this audience? 4 Evidenced (R1-R5; confirmed vs unconfirmed)? 5 Needed to understand the issue? 6 Safe to disclose (confidentiality, privilege, active investigation, personal data, not accusatory)? 7 Already said elsewhere?

Outcome, one of four: **Disclose in body / Summarise and reference / Schedule only / Withhold.**

Always disclose: key message and so-what; quantified exposure with basis (confirmed vs potential, gross vs net); population and scope; typed root cause (design gap, operating failure, override, unknown); evidenced positives; limitations and open dependencies; action, owner, date; management-response status; Critical, High and fraud-indicative matters through the right channel.

Never in the body: methodology narration or verification commentary; unconfirmed inference stated as fact; motive or blame; the same figure in more than three places; raw data dumps; immaterial exceptions (unless a pattern); drafting history; retracted findings (removed entirely, not softened).

Handle with care: fraud-indicative items go by the restricted channel (`gia-fraud:gia-fraud-investigation`); legal or regulatory matters to counsel; individuals by role; customer and third-party data at minimum necessary.

## 4. Focus and balance

One key message per finding that passes the five-second test; at most three numbers in a headline sentence; every paragraph earns its place by test 1, 3 or 5. Include evidenced positives; calibrate language to evidence; separate fact, audit judgement, management assertion and open item; severity words follow the rating, not emotion.

## 5. Audience calibration

| Audience | Layer | Calibrate to |
|---|---|---|
| Chairman, Board | L1 | Two-line key message, decision or ask, appendix pointer (`gia-report-qa:gia-board-brief`) |
| Audit Committee | L1 plus selected L2 | Rating, exposure basis, management-response status, overdue actions, sensitive matters through the restricted channel |
| CEO, CFO, GM, plant head | L2 | Cause, gap, action, owner, date, named-item table |
| Process owner, auditor | L3 | Full schedules, formulas, re-performance trail |
| Regulator, external auditor, investor, lender | not this skill | `gia-report-qa:gia-external-release` (apply this skill's tests as inputs only) |

## 6. Release checklist (judgement; separate from the 12-item Quality Gate and from the QA passes)

1 Can the Chairman state the decision needed in 60 seconds? 2 Can a manager find every item behind every number? 3 Does every sentence change a decision or understanding? 4 Is anything missing that a reader would need to challenge us? 5 Is the story balanced? 6 Is every list complete (named + remainder = total), no top-N excerpt, and a full appendix schedule behind every finding over 15 items? 7 Is any sensitive item in the wrong channel? 8 Is any fact repeated more than three times? 9 Are confirmed and unconfirmed amounts separated? 10 Would the audited team recognise the facts as fair? 11 Is each statement classed by basis (Verified / Supplied by others / Inference / Proposal), and are cut-off dates, populations and estimates labelled?

`scripts/tieout_check.py` tests items 6 and the tie-out arithmetic for a schedule file (CSV).

## 7. Conversions and edits

Calibration may move detail to schedules and appendices but never deletes valid source content and never touches ratings, responses or actions. Log each move (what, from, to) in the change log kept outside the report. When a supplied client or auditor report is the source of truth, reconcile first and keep its facts and ratings (`gia-core:iron-rules`).

## 8. Worked example (synthetic)

Finding: 14 supplier invoices with no receipt confirmation, 77 to 111 days after invoice date, total value INR 3.50 million (illustrative).
- Bad: "Some invoices have no receipt note." No size, no owner, no date; fails the item-naming rule at N=14.
- L1 (two lines): "Fourteen invoices (INR 3.50 million) remain unconfirmed by the supplier after 77 to 111 days; two have been chased. Management will send the full list; no Board decision needed."
- L2: full finding block with a table naming all 14 (invoice no., date, plant, value, age at cut-off date), tie-out "named 14 + remainder 0 = 14; total agrees to the schedule", open near-matches stated as unconfirmed, action, owner role, date.
- L3: schedule in the working paper with source file, formulas and recompute log.
All figures in this example are synthetic; real invoice data never goes into a method skill.

## Reference

| File | Read when |
|---|---|
| `scripts/tieout_check.py` | Testing a schedule for completeness and named-plus-remainder arithmetic |
