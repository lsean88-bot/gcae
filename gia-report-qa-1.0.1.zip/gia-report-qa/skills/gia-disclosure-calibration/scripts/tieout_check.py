#!/usr/bin/env python3
"""tieout_check.py - checks an item schedule against the item-naming rule.

Input CSV with a header. Required columns: item, value. Optional: in_body (yes/no).
Usage: python3 tieout_check.py schedule.csv --population N --total V [--tolerance 0.01]
Checks:
  T01 count: rows == --population
  T02 value: sum(value) == --total within tolerance
  T03 naming rule: population <= 15 -> every row in_body=yes; population > 15 -> no row in_body=yes
      (the body never carries a partial list; flag columns belong in the appendix schedule)
  T04 duplicate item identifiers
Exit 0 = pass, 1 = at least one ERROR, 2 = could not run (never a pass).
"""
import argparse
import csv
import sys


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv")
    ap.add_argument("--population", type=int, required=True)
    ap.add_argument("--total", type=float, required=True)
    ap.add_argument("--tolerance", type=float, default=0.01)
    a = ap.parse_args()
    try:
        rows = list(csv.DictReader(open(a.csv, encoding="utf-8")))
        if not rows or "item" not in rows[0] or "value" not in rows[0]:
            raise ValueError("CSV needs a header with 'item' and 'value' columns")
        vals = [float(r["value"].replace(",", "")) for r in rows]
    except Exception as e:
        print(f"CANNOT RUN: {e}")
        sys.exit(2)
    errs = []
    if len(rows) != a.population:
        errs.append(f"T01 schedule has {len(rows)} rows, population is {a.population}")
    if abs(sum(vals) - a.total) > a.tolerance:
        errs.append(f"T02 schedule sums to {sum(vals):.2f}, stated total {a.total:.2f}")
    inbody = [r for r in rows if (r.get("in_body") or "").strip().lower() == "yes"]
    if a.population <= 15 and len(inbody) != len(rows):
        errs.append(f"T03 population {a.population} <= 15: {len(rows) - len(inbody)} item(s) not named in the body")
    if a.population > 15 and inbody:
        errs.append(f"T03 population {a.population} > 15: {len(inbody)} item(s) named in the body (partial list)")
    ids = [r["item"].strip() for r in rows]
    dup = sorted({i for i in ids if ids.count(i) > 1})
    if dup:
        errs.append(f"T04 duplicate items: {', '.join(dup[:10])}")
    for e in errs:
        print("ERROR " + e)
    print("PASS" if not errs else f"FAIL ({len(errs)} error(s))")
    sys.exit(1 if errs else 0)


if __name__ == "__main__":
    main()
