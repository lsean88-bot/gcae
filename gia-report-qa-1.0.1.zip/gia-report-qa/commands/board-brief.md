---
description: "Brief the Chairman, Audit Committee or directors on a finding: Mode A seven sections (default), Mode B director issue summary, or Mode C/D leadership brief."
argument-hint: "<FIND ID or pasted finding> [mode A|B|C|D]"
---
Use the gia-board-brief skill for: $ARGUMENTS

Show the basis line. Take approved facts unchanged from the register or the pasted finding; if the finding is not approved, say so on the output. Never invent a reference ID or assign a rating. The no-drift check is reported in your reply, not written into the deliverable. Profile B hygiene applies.
