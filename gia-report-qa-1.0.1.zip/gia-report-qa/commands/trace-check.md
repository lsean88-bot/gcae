---
description: "Cross-check the register, and optionally a report, for broken traces."
argument-hint: "<register.xlsx> [report.md|report.docx]"
---
Use the gia-evidence-trace skill. Run ${CLAUDE_PLUGIN_ROOT}/skills/gia-evidence-trace/scripts/trace_check.py on: $ARGUMENTS

Report errors first, then warnings, then info, using references/trace-check-codes.md for fixes. State that P04 is a heuristic and that exit code 2 means the check could not run (never a pass). Do not edit the register to make a report pass; tell me which of the two the evidence says is wrong.
