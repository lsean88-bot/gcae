---
description: "Draft a finding sheet and run the approval-readiness check. Never sets approval status."
argument-hint: "[paste the observation, or a FIND ID]"
---
Use the gia-evidence-trace skill (finding sheet section). Draft a finding sheet from: $ARGUMENTS

Use only facts given or in the register. Mark cause "Not established" unless one is given. Keep evidenced and potential impact apart. Leave rating blank unless supplied on the engagement scale. Run the approval-readiness checklist and list what is missing. Status stays Draft; if I say it is approved, ask for the approver name and date and record those.
