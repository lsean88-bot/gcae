---
description: "Create, review, revise or quality-assure a Board, AC or executive presentation."
argument-hint: "[create|review|revise|qa|board|investigation] [audience] [topic] [period] [objective]"
---
Use the gia-presentation skill for: $ARGUMENTS

Follow the workflow: intake, evidence register, planner, draft deck spec, validate_deck.py, build and render, parallel independent review, Judge, final comprehension test. Return storyboard, slide plan, evidence register, QA result, appendix plan and the PPTX when tooling exists. Do not represent the deck as approved.
