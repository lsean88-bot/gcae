---
description: "Final quality assurance of a deck: evidence, numbers, consistency, comprehension, visual, accessibility; critical failures block release."
argument-hint: "<deck spec or file>"
---
Use the gia-presentation skill (QA mode) for: $ARGUMENTS

Run validate_deck.py, then the specialists in parallel (accuracy-advisor, audience-comprehension, objectivity-advisor, plus executive-decision, visual-design, semantic-reconciliation as triggered), then presentation-judge. Critical failures block release.
