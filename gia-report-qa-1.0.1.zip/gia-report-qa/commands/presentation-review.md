---
description: "Review an existing presentation without silently rewriting its facts."
argument-hint: "<deck file>"
---
Use the gia-presentation skill (review mode) for: $ARGUMENTS

Assess comprehension, accuracy, evidence, Board relevance, logic, visual design, accessibility and decision usefulness. Return a defect register with severity and recommended action. Do not change facts.
