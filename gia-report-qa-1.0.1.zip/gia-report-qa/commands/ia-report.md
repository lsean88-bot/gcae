---
description: "Build or finalise the standard concise IA report plus Excel working paper (Profile A or B), or consolidate several reports."
argument-hint: "<profile A|B> <sources or folder> [output set]"
---
Use the gia-ia-report skill for: $ARGUMENTS

Start with Step 0: confirm profile, report type and output set, then lock the findings baseline and show me the finding list for approval before building. Draft directly to final form. Run consolidated_iar_check.py and profile_b_lint.py, then hand to /report-qa. Carry missing entity facts as open dependencies; never assume them.
