---
description: "Plan or write a closure-validation workpaper for an action management reports as complete."
argument-hint: "<ACT ID or FIND ID>"
---
Use the gia-evidence-trace skill (action closure section) for: $ARGUMENTS

Record management completion statement as an unverified representation. Draft the validation workpaper (designed, operating, result against the benefit measure). Propose the re-test but do not change the action status to Closed - validated; that follows only from completed testing.
