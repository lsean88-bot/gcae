---
description: "Pre-issue pipeline: deterministic scans, Quality Gate (12), independent QA passes, read-only panel, then hash-bound human sign-off."
argument-hint: "<register.xlsx> <report file(s)> [profile A|B]"
---
Use the gia-report-qa skill for: $ARGUMENTS

1. Run the stage 1 scans (trace_check, qa_scan, jargon_scan, profile_b_lint; consolidated_iar_check for consolidated sets).
2. Dispatch report-qa-reviewer with the report, the register text export (brief_data.py --md) and all scan outputs; in parallel dispatch accuracy-advisor, clarity-advisor and objectivity-advisor. Tell reviewers plainly if the report is a single-finding draft built from a raw finding with no IDs.
3. Run qa_gate.py record with --reviewer reviewed only if the reviewer really ran (otherwise not-run), then verify; quote its verdict. Any edit after record voids the sign-off.
4. Give me one list: ERRORs (block issue), WARNs (need a disposition), reviewer judgement points. Do not alter the report or the register. This pipeline sits beside, and never replaces, the Quality Gate (12) in gia-core:iron-rules; a human signs off.
