---
description: "Assemble the quarterly Audit Committee pack for human review and sign-off."
argument-hint: "[quarter]"
---
Use the gia-board-brief skill (Mode E, references/ac-pack-and-escalation.md) and the board-pack-coordinator agent for: $ARGUMENTS

Assemble from approved, QA-passed components only. Apply the escalation thresholds and flag anything that meets one. Report closed only if validation date and evidence note exist. The pack is prepared for the human CAE; do not represent it as sent, approved or submitted.
