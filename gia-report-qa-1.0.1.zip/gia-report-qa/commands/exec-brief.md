---
description: "Roll approved findings into a Leadership Decision Brief, dashboard data and deck outline."
argument-hint: "<register.xlsx> [audience]"
---
Use the gia-board-brief skill (Mode C/D) with: $ARGUMENTS

Run ${CLAUDE_PLUGIN_ROOT}/skills/gia-board-brief/scripts/brief_data.py first and write from its output. Group into at most five themes (a theme needs at least two approved findings). Mark sponsors, decisions and the overall assurance conclusion as proposals unless I have given them. Include the assurance boundary and any open evidence gaps.
