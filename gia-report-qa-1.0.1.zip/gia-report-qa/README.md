# gia-report-qa (S5)

Reporting and QA suite for Group Internal Audit. Seven skills, twelve agents, eleven commands.

## Skills
| Skill | Use for |
|---|---|
| `gia-ia-report` | Standard concise IA report + Excel working paper; Profile A (auditee/EXCO) and Profile B (Board/AC/Chairman/external-grade); consolidation; templates (flash, advisory memo, management letter, annual plan, investigation summary) |
| `gia-board-brief` | Chairman briefing, director issue summary, leadership decision brief, AC pack, escalation thresholds |
| `gia-disclosure-calibration` | What to disclose, where, at what depth; no partial lists |
| `gia-external-release` | Documents leaving the Group; institutional voice; Escalation Rule |
| `gia-evidence-trace` | Evidence register, trace check, workpaper, finding sheet, action closure |
| `gia-report-qa` | Quality Gate (12), independent QA passes, panel, critique, sign-off |
| `gia-presentation` | Board and executive decks with a Judge gate |

## Conventions
- Report = standard concise IA report + Excel WP. The 13-section layout is legacy conversion only (`gia-ia-report/references/legacy-13-section-conversion.md`).
- Evidence: R1-R5 for sources, Rule 37 classes for report statements; other labels map via `gia-evidence-trace/references/evidence-label-map.md`.
- Iron rules, Quality Gate and statutory registers are referenced from `gia-core` and `gia-audit`; this plugin restates none of them.
- Profile B files: no emoji, no self-commentary, no sheet or row references, no declarations.

## Commands
`/ia-report` `/board-brief` `/exec-brief` `/finding-sheet` `/trace-check` `/report-qa` `/closure-validate` `/ac-pack` `/presentation` `/presentation-review` `/presentation-qa`

## Scripts (python3 -I)
`trace_check`, `qa_gate`, `build_register_workbook`, `import_rows` (evidence-trace); `brief_data`, `jargon_scan` (board-brief); `qa_scan`, `profile_b_lint`, `run_critique` (report-qa); `consolidated_iar_check` (ia-report); `tieout_check` (disclosure); `validate_deck`, `build_pptx`, `render_pptx` (presentation).

## Tests
`python3 -I tests/selftest.py` (evidence-trace and brief scripts), `tests/test_new_checks.py` (new checks), `tests/check_structure.py` (plugin structure). Results: `tests/RESULTS.md`.

## Limits
Trigger evals in `evals/` are reasoned cases, not live runs. Scans test patterns, not truth. Human sign-off is required before FINAL.
