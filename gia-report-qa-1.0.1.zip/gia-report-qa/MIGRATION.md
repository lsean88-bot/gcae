# Migration map: old component to new location (S5 gia-report-qa)

Status: PORTED = unique strength carried into this plugin; MERGED = content folded into the named place; DROPPED = intentionally not carried (reason); MOVED = belongs to another suite.

## Skills
| Old | New | Strengths | Status |
|---|---|---|---|
| mktron-consolidated-iar | gia-ia-report (SKILL.md, references/consolidation-workflow.md) | Baseline lock; edited-draft diff and 7 trace verdicts; theme synthesis with banned phrases; deleted-finding purge; Opus plans / Sonnet builds / Haiku QA; responsive HTML check | PORTED. Entity hard-codes (plant dates, PF figures) DROPPED to entity packs (gia-audit). "Four rebuilds" anecdote DROPPED |
| plain-language-audit-report-excel-referenced | gia-ia-report (Profile A, references/finding-blocks.md, excel-wp-spec.md) | Rank ALL findings; ten-element finding; workbook sheets; proposal dates | PORTED. Row references confined to Profile A; Docs-artifact delivery assumption DROPPED |
| cae-report-conversion | gia-ia-report/references/legacy-13-section-conversion.md | Change Log, Exception Log, Editorial Authority, six deliverables, naming, Constraints 1-6 | PORTED as legacy reference; 13-section mandate and stale counts neutralised by banner; embedded changelog DROPPED |
| group-cae-reporting | gia-ia-report (audience map, reader test, templates), gia-report-qa (passes, writing quality, stakeholder influence) | Audience map; Stage 1-3 co-drafting; plain-language table; AC paper and comms templates; 5-pass QA | PORTED. Missing templates written new. Emoji traffic lights and 14-bullet list DROPPED |
| board-chairman-briefing | gia-board-brief | Mode A (7 sections + 2 blocks), Mode B, Modes C/D; ID rules; evidenced vs potential; 5 references | PORTED. Mode B closing declaration and emoji banner DROPPED (declaration to QA log) |
| cae-board-reporting (ai-cae-mktron) | gia-board-brief/references/ac-pack-and-escalation.md | Escalation thresholds; AC pack; assurance statement; CAE-note leak rule | PORTED. Risk-forward default, AI-provenance tag and hard-coded risk-tier data DROPPED |
| executive-decision-brief | gia-board-brief (Mode C/D, scripts) | brief_data.py, jargon_scan.py, five themes, assurance boundary | PORTED. No-drift declaration moved out of the deliverable |
| strategic-reporting-framework | gia-disclosure-calibration | L1-L3; item-naming; 7-question test; 4 outcomes; release checklist | PORTED. Real invoice example replaced; Rules 33-39 text no longer restated. tieout_check.py NEW |
| group-cae-external-reporting | gia-external-release | Zero-artefact output; voice table; Escalation Rule; Newspaper and Permanence tests; term banks; 5 templates; Output Gate | PORTED. Stop-and-ask reconciled with open dependencies; "optimistic" mandate replaced by constructive, evidence-calibrated |
| evidence-trace-register | gia-evidence-trace | 4 scripts, ID conventions, trace codes, 121-check selftest | PORTED as-is plus path fixes |
| workpaper-finding-sheet | gia-evidence-trace (sections 4-5) | 11-element workpaper; finding sheet; approval gate; readiness check | PORTED; overlap with gia-audit fieldwork to be reconciled by that suite |
| action-closure-validation | gia-evidence-trace (section 6) | 7 statuses; designed/operating/result; benefit measures; R19 | PORTED |
| independent-critique | gia-report-qa (Mode A script, Mode B standard) | 5-point discipline; run_critique.py; two standards | PORTED. Missing-file and uninstalled-skill references DROPPED |
| cae-verification-discipline | gia-report-qa/references/four-lane-and-devils-advocate.md | Four-Lane test; word grounding; corroboration cap; devil's advocate | PORTED; tags mapped to R1-R5 |
| gia-evidence-discipline (Mode 8, qa_scan.py) | gia-report-qa/scripts/qa_scan.py | Unreferenced facts, absence-as-proof, sample-to-population | PORTED; other modes MOVED to gia-core |
| mktron-presentation | gia-presentation | Comprehension gate; Judge and hard-fail list; 16-dimension scoring; templates; scripts; evals | PORTED, split. Runtime, UAT, continuation-guard sections DROPPED (meta layer) |
| internal-comms | none | Generic formats | DROPPED (obsolete) |
| board-assurance (GCAE v14.5 stub), gcae-assurance-qa-release | none | none | DROPPED; GCAE disposition owned by gia-core |
| gia-lean-comms | gia-core | zone and meaning-guard idea | MOVED |
| gia-statutory-freshness | gia-audit | dated register and check_rates.py | MOVED |
| audit-engagement-relations | gia-audit | kickoff and closing templates | MOVED |
| Quality-gate variants of 10, 14, 27, 30, 38 items | gia-report-qa/references/quality-gate-checks.md | 14-item add-ons: finding-count consistency, design-vs-operating type | PORTED as scripted add-ons; counts retired. 12 stands |

## Agents
| Old | New |
|---|---|
| report-qa-reviewer (assurance-value-chain) | agents/report-qa-reviewer.md (pinned sonnet) |
| qa-reviewer (akos), delta-validator, iota-kaizen | MERGED into report-qa-reviewer; KG-integrity checks MOVED to gia-core; retrospective to gia-core self-learning |
| report-writer (ai-cae-mktron), epsilon-strategist, assurance-improvement-reporting-lead | MERGED into agents/report-builder.md (external mode) |
| board-reporting-coordinator | agents/board-pack-coordinator.md |
| zeta-remediator | MERGED into gia-evidence-trace section 6 |
| 29 presentation agents | 8 in agents/: presentation-planner, presentation-judge, accuracy-advisor, audience-comprehension, objectivity-advisor, executive-decision, visual-design, semantic-reconciliation; compliance and operations-process roles MOVED to gia-audit |
| GCAE agents 21-27 | DROPPED as agents (boilerplate); challenge list and report architecture folded into reviewer checks |
New: clarity-advisor (haiku) from the parallel QA panel in consolidated-iar.

## Commands
| Old | New |
|---|---|
| report-qa, trace-check, exec-brief, finding-sheet, closure-validate | same names |
| director-brief | /board-brief (Mode B) |
| assure-start | MOVED to the router in gia-core |
| log-pattern | MOVED to gia-core self-learning |
| cae-quality-gate (14-item) | /report-qa with quality-gate-checks.md |
| cae-ac-pack | /ac-pack |
| gia-qa | /report-qa |
| presentation, presentation-review, presentation-qa | same; create, revise, challenge are modes. Other presentation-* commands folded into review modes |
| cae-monthly-cycle | MOVED to gia-audit |

## Port check additions (1.0.1)

| Source | Status |
|---|---|
| assurance-orchestrator (chain S0 to S7, intake questions, standing rules) | PORTED: `skills/gia-report-qa/references/assurance-chain.md` |
