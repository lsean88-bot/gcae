---
name: cae-cowork-ai-plugin
description: "Retired 30-Oct-2026 — superseded by gia-core:gcgo-router. Use gia-core:gcgo-router instead."
---
# cae-cowork-ai-plugin — retired

This skill was consolidated into `gia-core:gcgo-router` on 30-Oct-2026. Invoke that skill instead. Nothing else is maintained here.
