---
name: gias-standards-navigator
description: "Retired 30-Oct-2026 — superseded by gia-audit:gias-navigator. Use gia-audit:gias-navigator instead."
---
# gias-standards-navigator — retired

This skill was consolidated into `gia-audit:gias-navigator` on 30-Oct-2026. Invoke that skill instead. Nothing else is maintained here.
