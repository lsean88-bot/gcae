---
name: super-grc-audit-plugin-l99
description: "Retired 30-Oct-2026 — superseded by gia-audit:gia-audit-lifecycle. Use gia-audit:gia-audit-lifecycle instead."
---
# super-grc-audit-plugin-l99 — retired

This skill was consolidated into `gia-audit:gia-audit-lifecycle` on 30-Oct-2026. Invoke that skill instead. Nothing else is maintained here.
