---
name: gia-file-catalog-2
description: "Retired 30-Oct-2026 — superseded by gia-core:project-memory. Use gia-core:project-memory instead."
---
# gia-file-catalog-2 — retired

This skill was consolidated into `gia-core:project-memory` on 30-Oct-2026. Invoke that skill instead. Nothing else is maintained here.
