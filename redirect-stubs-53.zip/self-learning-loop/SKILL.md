---
name: self-learning-loop
description: "Retired 30-Oct-2026 — superseded by gia-core:self-learning. Use gia-core:self-learning instead."
---
# self-learning-loop — retired

This skill was consolidated into `gia-core:self-learning` on 30-Oct-2026. Invoke that skill instead. Nothing else is maintained here.
