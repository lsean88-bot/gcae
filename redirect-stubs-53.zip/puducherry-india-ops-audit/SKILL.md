---
name: puducherry-india-ops-audit
description: "Retired 30-Oct-2026 — superseded by gia-audit:gia-pack-india. Use gia-audit:gia-pack-india instead."
---
# puducherry-india-ops-audit — retired

This skill was consolidated into `gia-audit:gia-pack-india` on 30-Oct-2026. Invoke that skill instead. Nothing else is maintained here.
