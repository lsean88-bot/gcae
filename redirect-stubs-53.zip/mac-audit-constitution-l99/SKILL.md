---
name: mac-audit-constitution-l99
description: "Retired 30-Oct-2026 — superseded by gia-core:iron-rules. Use gia-core:iron-rules instead."
---
# mac-audit-constitution-l99 — retired

This skill was consolidated into `gia-core:iron-rules` on 30-Oct-2026. Invoke that skill instead. Nothing else is maintained here.
