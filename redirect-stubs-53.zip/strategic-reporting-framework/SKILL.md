---
name: strategic-reporting-framework
description: "Retired 30-Oct-2026 — superseded by gia-report-qa:gia-disclosure-calibration. Use gia-report-qa:gia-disclosure-calibration instead."
---
# strategic-reporting-framework — retired

This skill was consolidated into `gia-report-qa:gia-disclosure-calibration` on 30-Oct-2026. Invoke that skill instead. Nothing else is maintained here.
