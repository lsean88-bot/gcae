---
name: board-chairman-briefing
description: "Retired 30-Oct-2026 — superseded by gia-report-qa:gia-board-brief. Use gia-report-qa:gia-board-brief instead."
---
# board-chairman-briefing — retired

This skill was consolidated into `gia-report-qa:gia-board-brief` on 30-Oct-2026. Invoke that skill instead. Nothing else is maintained here.
