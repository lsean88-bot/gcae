---
name: cae-verification-discipline
description: "Retired 30-Oct-2026 — superseded by gia-report-qa:gia-report-qa. Use gia-report-qa:gia-report-qa instead."
---
# cae-verification-discipline — retired

This skill was consolidated into `gia-report-qa:gia-report-qa` on 30-Oct-2026. Invoke that skill instead. Nothing else is maintained here.
