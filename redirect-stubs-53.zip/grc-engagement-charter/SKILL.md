---
name: grc-engagement-charter
description: "Retired 30-Oct-2026 — superseded by gia-audit:gia-engagement-planning. Use gia-audit:gia-engagement-planning instead."
---
# grc-engagement-charter — retired

This skill was consolidated into `gia-audit:gia-engagement-planning` on 30-Oct-2026. Invoke that skill instead. Nothing else is maintained here.
