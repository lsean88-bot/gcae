---
name: internal-comms
description: "Retired 30-Oct-2026 — superseded by gia-report-qa:gia-external-release. Use gia-report-qa:gia-external-release instead."
---
# internal-comms — retired

This skill was consolidated into `gia-report-qa:gia-external-release` on 30-Oct-2026. Invoke that skill instead. Nothing else is maintained here.
