---
name: gia-lean-comms
description: "Retired 30-Oct-2026 — superseded by gia-core:safeguard-lint. Use gia-core:safeguard-lint instead."
---
# gia-lean-comms — retired

This skill was consolidated into `gia-core:safeguard-lint` on 30-Oct-2026. Invoke that skill instead. Nothing else is maintained here.
