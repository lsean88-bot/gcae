---
name: mx-manufacturing-audit
description: "Retired 30-Oct-2026 — superseded by gia-audit:gia-pack-mexico. Use gia-audit:gia-pack-mexico instead."
---
# mx-manufacturing-audit — retired

This skill was consolidated into `gia-audit:gia-pack-mexico` on 30-Oct-2026. Invoke that skill instead. Nothing else is maintained here.
