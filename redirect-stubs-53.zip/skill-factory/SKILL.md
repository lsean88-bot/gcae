---
name: skill-factory
description: "Retired 30-Oct-2026 — superseded by gia-core:skill-hygiene. Use gia-core:skill-hygiene instead."
---
# skill-factory — retired

This skill was consolidated into `gia-core:skill-hygiene` on 30-Oct-2026. Invoke that skill instead. Nothing else is maintained here.
