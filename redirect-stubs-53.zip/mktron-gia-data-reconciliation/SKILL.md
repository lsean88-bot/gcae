---
name: mktron-gia-data-reconciliation
description: "Retired 30-Oct-2026 — superseded by gia-analytics:gia-data-reconciliation. Use gia-analytics:gia-data-reconciliation instead."
---
# mktron-gia-data-reconciliation — retired

This skill was consolidated into `gia-analytics:gia-data-reconciliation` on 30-Oct-2026. Invoke that skill instead. Nothing else is maintained here.
