---
name: group-cae-fraud-v2
description: "Retired 30-Oct-2026 — superseded by gia-fraud:gia-fraud-investigation. Use gia-fraud:gia-fraud-investigation instead."
---
# group-cae-fraud-v2 — retired

This skill was consolidated into `gia-fraud:gia-fraud-investigation` on 30-Oct-2026. Invoke that skill instead. Nothing else is maintained here.
