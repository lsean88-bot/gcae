---
name: gcae-assurance-qa-release
description: "Retired 30-Oct-2026 — superseded by gia-core:runtime-guard. Use gia-core:runtime-guard instead."
---
# gcae-assurance-qa-release — retired

This skill was consolidated into `gia-core:runtime-guard` on 30-Oct-2026. Invoke that skill instead. Nothing else is maintained here.
