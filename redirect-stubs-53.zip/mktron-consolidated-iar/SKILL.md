---
name: mktron-consolidated-iar
description: "Retired 30-Oct-2026 — superseded by gia-report-qa:gia-ia-report. Use gia-report-qa:gia-ia-report instead."
---
# mktron-consolidated-iar — retired

This skill was consolidated into `gia-report-qa:gia-ia-report` on 30-Oct-2026. Invoke that skill instead. Nothing else is maintained here.
