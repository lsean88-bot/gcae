---
name: my-malaysia-hr-audit
description: "Retired 30-Oct-2026 — superseded by gia-audit:gia-pack-malaysia. Use gia-audit:gia-pack-malaysia instead."
---
# my-malaysia-hr-audit — retired

This skill was consolidated into `gia-audit:gia-pack-malaysia` on 30-Oct-2026. Invoke that skill instead. Nothing else is maintained here.
