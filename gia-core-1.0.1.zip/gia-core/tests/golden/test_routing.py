from pathlib import Path
import sys, yaml
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from runtime.router import Router
cases = yaml.safe_load((ROOT / 'tests/golden/routing_cases.yaml').read_text())['cases']


def test_golden_routes():
    r = Router(ROOT)
    for c in cases:
        if c.get('known_miss'):
            continue
        out = r.classify(c['request'], task_id=c['id'], authorized_scope=c['request'])
        assert out.intent == c['expected_intent'], (c['id'], out.intent, out.reason_codes)
        assert out.dependency_closure_status == 'COMPLETE', (c['id'], out.missing_dependencies)


def test_known_misses_are_still_misses():
    """A known miss that starts to pass should be promoted to a gated case, so the list never goes stale."""
    r = Router(ROOT)
    for c in cases:
        if c.get('known_miss'):
            out = r.classify(c['request'], task_id=c['id'], authorized_scope=c['request'])
            assert out.intent != c['expected_intent'], ('now passes; remove known_miss', c['id'])
