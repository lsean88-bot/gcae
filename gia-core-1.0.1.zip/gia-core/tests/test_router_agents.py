#!/usr/bin/env python3
"""Every agent or skill the router selects must exist in this plugin. python3 -I tests/test_router_agents.py"""
import os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
agents = {f[:-3] for f in os.listdir(os.path.join(ROOT, "agents")) if f.endswith(".md")}
skills = set(os.listdir(os.path.join(ROOT, "skills")))
bad = []
src = open(os.path.join(ROOT, "runtime", "router.py")).read()
for m in re.finditer(r"gia-core:([a-z0-9-]+)", src):
    n = m.group(1)
    if n not in agents and n not in skills:
        bad.append("router.py -> gia-core:" + n)
print("checked router.py selections:", "FAIL " + ", ".join(bad) if bad else "all selected names exist")
sys.exit(1 if bad else 0)
