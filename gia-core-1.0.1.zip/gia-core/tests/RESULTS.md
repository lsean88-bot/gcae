# gia-core 1.0.0: test results

Recorded 30-Oct-2026 from runs on the build machine. Every number below came from a command that was run and exited as stated. Re-run with `python3 -I tests/run_all.py` (quick set) or `python3 -I tests/run_all.py --full` (adds mutation, fuzz and the slow wrappers).

## Quick set (`tests/run_all.py`, 20 steps)

| Step | Result |
|---|---|
| Guard suite, v14.5 groups retargeted to this layout (`tests/guard/suite.py`) | 170 assertions, 0 failed (168 at first run, 2 added for the survivors listed below) |
| Runtime controls GR-16..19 hook tests (`tests/test_gr_controls.py`) | 349/349 |
| safeguard-lint tests | 72/72 |
| safeguard-lint canonical-code tests | 25/25 |
| iron-rules consistency tests | 20/20 |
| iron-rules render check, runtime controls render check, matrix render check | current |
| Governance drift check on this plugin | no findings across 8 checks |
| model-effort selector tests | 20/20 |
| Agent frontmatter against the Rule 32 matrix | 12 agents, 0 violations |
| Router registry is current | pass |
| Router selftest regression gate | core 94/94, natural 50/50 |
| Router tests (plan, brief, bypass stop, adapter) | 16/16 |
| verify_install | 13 PASS, 0 WARN, 0 FAIL |
| self-learning tests | 14/14 |
| skill-hygiene tests | 27/27 |
| project-memory kg_tools tests | 14/14 |
| project-memory brain tests (pytest) | 273 passed, 68 skipped |
| Guard consistency, controls, routing, golden (pytest) | 32 passed |

## Full set additions

| Step | Result |
|---|---|
| Guard pytest wrappers, economy, grader, fuzz | economy, grader and fuzz: 21 passed |
| Guard mutation testing (`tests/guard/mutate_guard.py`) | First run: 72 valid, 70 killed, 2 survived, 1 invalid anchor. Survivors were `route_closure_stop` and `protect_state_dir_tools`; two assertions were added to the suite and a targeted re-run killed both (2/2). The invalid-anchor mutant (`protect_state_dir_bash`) targeted code that no longer exists, because Bash is now judged by GR-19; it was removed and GR-04 now cites the GR-19 mutants `guard data dir off` and `symlink resolve off`. One mutant (`preflight_policy`) is declared equivalent with a stated reason. Net: 71 valid, 71 killed. The full run was not repeated end to end after the fix. |
| Grader mutation testing | 23 valid, 23 killed, 0 survived |
| GR controls mutation testing (`tests/mutate_gr_controls.py`) | 45 mutants, 45 killed, 0 survived, 0 pattern-not-found |

## Structure and drift

- `validate_structure.py gia-core`: 219 passed, 0 failures (re-run after the last edits: 219 passed, 0 failures).
- `check-governance-drift.sh --suite build`: gia-core clean. Check 2 flags three files owned by other suites (gia-audit `nmsb-finance.md` and `nmsb-ops.md`, gia-report-qa `legacy-13-section-conversion.md`) for Iron Rules style headers. Not changed here.

## What these results do not show

- No live UAT was run. GCAE production status stays NOT_ACCEPTED, and no one has certified this build; the builder cannot self-certify.
- graphify is not installed and installing it was refused, so the 68 brain tests that need it are skipped. The skip list is inferred from the failures, not proven.
- Always-loaded token estimate is about 1627 tokens against the library-wide target of 700. The target is not met.
- Router accuracy on unseen natural requests is lower than the bundled regression numbers (see the gcgo-router SKILL.md). Three golden routing cases are recorded as known misses and are checked to stay misses.
- Thresholds marked ASSUMED in `core/policy/execution-thresholds.json` (tool limits 60/40/200, repeat cap 12, restart cap 3, reference budgets 8 and 16) have no measured basis yet.
- Most canonical rules have no runtime counterpart; `skills/iron-rules/rules.json` lists which are enforced by a GR control, a lint code or a script, and the rest are behavioural.
- Open for decision by Legal or Group: the standard of proof, entity code MKSDL against MKSLD, and router entity codes against the graph entity codes.

## 1.0.1 defect-fix pass (30-Oct-2026)

| Item | Result |
|---|---|
| Test entry point re-run | 21 quick steps run, 21 passed at version 1.0.1 (adds router-selection test); router registry rebuilt; BUILD_HASHES regenerated (202 files). `--full` set not run in this pass. |
| `build/xref_check.py` (colon refs, in-skill links, router selections, description length, relative script paths, YAML frontmatter) | PASS: 0 findings |
| Economy: always-loaded name plus description tokens (chars/4) | skills 781, agents 999, commands 225, total 2005; longest skill or agent description 400 chars or fewer (target of 700 total still not met; each description is capped at 400) |
| D5 cross-references, D7 links, D13 script paths | Fixed and checked by xref_check.py |
