"""Context-token budgets (estimates: chars/4). Economy is a tested property, not an aspiration."""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(os.path.dirname(HERE)); sys.path.insert(0, os.path.join(ROOT, "skills", "runtime-guard", "scripts")); sys.path.insert(0, HERE)
import token_budget as T
# Ceilings for this 8-skill plugin, set just above the measured values (estimates, chars/4). The library-wide always-loaded target of 700 tokens
# is NOT met by this plugin alone (see tests/RESULTS.md); these ceilings stop it growing.
BUDGET = {"always_loaded": 1800, "router": 2000, "other_skill": 1700, "route_message": 120}

def test_always_loaded_cost_is_small():
    assert T.measure()["always_loaded"] <= BUDGET["always_loaded"], T.measure()["always_loaded"]

def test_router_skill_within_budget():
    assert T.measure()["router"] <= BUDGET["router"], T.measure()["router"]

def test_no_other_skill_exceeds_budget():
    m = T.measure(); over = {k: v["total"] for k, v in m["skills"].items() if k != "gcgo-router" and v["total"] > BUDGET["other_skill"]}
    assert not over, over

def test_every_description_fits_the_limit_and_no_skill_body_is_long():
    import re
    for k in T.measure()["skills"]:
        t = open(os.path.join(ROOT, "skills", k, "SKILL.md"), encoding="utf-8").read()
        fm = re.match(r"^---\n(.*?)\n---\n", t, re.S).group(1)
        d = re.search(r"^description:\s*(.*)$", fm, re.M).group(1)
        assert len(d) <= 1024 and len(t.splitlines()) < 500, k

def test_hook_context_per_prompt_is_small():
    from harness import Env, context
    e = Env().start(); out = e.prompt("Review the inventory reconciliation workpaper and report findings.")
    assert T.est(context(out)) <= BUDGET["route_message"], T.est(context(out))

def test_guard_adds_no_context_for_ordinary_tool_calls():
    from harness import Env
    e = Env().start(); e.prompt("Review the inventory reconciliation workpaper and report findings.")
    rc, out, _ = e.pre("Read", file_path="a.txt"); assert out.strip() == ""
