"""Runtime-control traceability: a GR control that loses its proof fails the build."""
import os, re, sys, json, glob
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(os.path.dirname(HERE)); sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(ROOT, "skills", "runtime-guard", "scripts"))
import suite as S, mutate_guard as M
RULES = json.load(open(os.path.join(ROOT, "core/policy/runtime-controls.json")))["rules"]
GUARD = open(os.path.join(ROOT, "hooks/gia_guard.py"), encoding="utf-8").read()
GR_SRC = open(os.path.join(ROOT, "hooks/gr_controls.py"), encoding="utf-8").read()
GR_MUT = open(os.path.join(ROOT, "tests/mutate_gr_controls.py"), encoding="utf-8").read()
TYPES = ("MECHANICAL", "BEHAVIOURAL", "PROCESS", "ADVISORY")


def test_controls_are_well_formed_and_unique():
    ids = [r["id"] for r in RULES]
    assert len(ids) == len(set(ids))
    assert ids == ["GR-%02d" % (i + 1) for i in range(len(ids))], ids
    for r in RULES:
        assert r["type"] in TYPES and r["rule"] and r["enforcement"], r["id"]
        assert all(re.fullmatch(r"T(?:[0-9]|1[0-6])", u) for u in r["uat"]), r["id"]
        assert all(isinstance(n, int) and 1 <= n <= 99 for n in r.get("maps_to_rules", [])), r["id"]


def test_no_retired_ir_prefix_remains_in_the_policy():
    blob = json.dumps(RULES)
    assert not re.search(r"\bIR-\d\d\b", blob)


def test_mechanical_controls_have_tests_and_mutants_that_exist():
    groups = {n for n, _ in S.SUITE}
    mutants = {m[0] for m in M.M}
    for r in RULES:
        for t in r["tests"]:
            assert t in groups, (r["id"], t)
        for m in r["mutants"]:
            assert m in mutants, (r["id"], m)
        for f in r.get("tests_ext", []):
            assert os.path.isfile(os.path.join(ROOT, f)), (r["id"], f)
        for m in r.get("mutants_ext", []):
            assert ('"%s"' % m) in GR_MUT or ("'%s'" % m) in GR_MUT, (r["id"], m)
        if r["type"] in ("MECHANICAL", "ADVISORY"):
            assert (r["tests"] or r.get("tests_ext")) and (r["mutants"] or r.get("mutants_ext")), r["id"]


def test_behavioural_controls_name_a_uat_stage_and_template():
    tpl = open(os.path.join(ROOT, "core/output-templates.md"), encoding="utf-8").read()
    for r in RULES:
        if r["type"] == "BEHAVIOURAL":
            assert r["uat"] and r.get("template"), r["id"]
            assert re.search(r"^## %s\." % r["template"], tpl, re.M), (r["id"], r["template"])


def test_every_stop_reason_in_the_guard_is_covered_by_a_control():
    found = set(re.findall(r'set_stop\(d, st, pol, data, "([A-Z_]{5,})', GUARD)) | set(re.findall(r'reason = "([A-Z_]{5,})"', GUARD)) | set(re.findall(r'fail_closed\((?:ev|""), "([A-Z_]{5,})', GUARD))
    found |= set(re.findall(r'"(STATUS_STATE_CORRUPT|PRIOR_STOP_LOCK|STATE_RESET|LOG_TAMPER)"', GUARD))
    found |= set(json.load(open(os.path.join(ROOT, "core/policy/execution-thresholds.json")))["guard"]["model_stop_reasons"])
    covered = {s for r in RULES for s in r["stop_reasons"]}
    covered |= {"MODEL_INITIATED", "INTEGRITY_CONCERN", "SCOPE_BREACH", "INVALID_EVIDENCE"}
    found = {f for f in found if f not in ("NATIVE_STOP_FAILURE",)} | {"NATIVE_STOP_FAILURE"}
    missing = sorted(f for f in found if f not in covered and not any(f.startswith(c) for c in covered))
    assert not missing, missing


def test_every_control_stop_reason_exists_in_the_guard():
    allowed = set(json.load(open(os.path.join(ROOT, "core/policy/execution-thresholds.json")))["guard"]["model_stop_reasons"])
    for r in RULES:
        for s in r["stop_reasons"]:
            assert s in GUARD or s in allowed, (r["id"], s)


def test_rendered_markdown_matches_the_data():
    import render_runtime_controls as R
    assert open(os.path.join(ROOT, "core/RUNTIME_CONTROLS.md"), encoding="utf-8").read() == R.render()


def test_the_four_added_controls_are_wired_into_the_guard_adapter():
    for gid in ("GR-16", "GR-17", "GR-18", "GR-19"):
        assert gid in GR_SRC, gid
    for needle in ("gr_run", "protected_write"):
        assert needle in GUARD, needle


def test_runtime_guard_skill_lists_every_control_and_the_mapping_covers_them():
    sk = open(os.path.join(ROOT, "skills/runtime-guard/SKILL.md"), encoding="utf-8").read()
    mp = open(os.path.join(ROOT, "skills/runtime-guard/references/gr-mapping.md"), encoding="utf-8").read()
    for r in RULES:
        assert r["id"] in mp, r["id"]
    assert "gr-mapping.md" in sk and "RUNTIME_CONTROLS.md" in sk


def test_mapped_canonical_rules_exist_in_the_rules_data():
    ids = {r["id"] for r in json.load(open(os.path.join(ROOT, "skills/iron-rules/rules.json")))["rules"]}
    for r in RULES:
        for n in r.get("maps_to_rules", []):
            assert n in ids, (r["id"], n)
