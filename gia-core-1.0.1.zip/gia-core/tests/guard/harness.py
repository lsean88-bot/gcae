"""Shared fixture for guard tests: copies the FULL consolidated plugin tree so preflight, release identity and routing run on real files."""
import os, sys, json, subprocess, tempfile, shutil, hashlib
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
GUARD = os.path.join(ROOT, "hooks", "gia_guard.py")
RESTART = "/gia-core:restart"
RESTART_PHRASE = "Explicitly restart the GIA controlled runtime and begin a new controlled session."
SCOPE_APPROVE = "/gia-core:scope approve"
SCOPE_DECLINE = "/gia-core:scope decline"
_IGN = shutil.ignore_patterns("history", "tests", "independent_counsel", "docs", "__pycache__", ".git", ".gia", "BUILD_HASHES*", "*.pyc")
_CACHE = {}


def _template():
    if "t" not in _CACHE:
        d = tempfile.mkdtemp(prefix="giaTPL_"); t = os.path.join(d, "plugin")
        shutil.copytree(ROOT, t, ignore=_IGN); _CACHE["t"] = t
    return _CACHE["t"]


class Env:
    def __init__(self, guard_src=GUARD, drop=(), policy=None, extra_env=None, edit=None):
        self.tmp = tempfile.mkdtemp(prefix="giaT_")
        self.root, self.proj = os.path.join(self.tmp, "plugin"), os.path.join(self.tmp, "proj")
        os.makedirs(self.proj)
        shutil.copytree(_template(), self.root)
        shutil.copy(guard_src, os.path.join(self.root, "hooks", "gia_guard.py"))
        if policy:
            p = os.path.join(self.root, "core", "policy", "execution-thresholds.json")
            pol = json.load(open(p)); pol["guard"].update(policy); json.dump(pol, open(p, "w"), indent=2)
        for rel, fn in (edit or {}).items():
            p = os.path.join(self.root, rel); s = open(p, encoding="utf-8").read(); open(p, "w", encoding="utf-8").write(fn(s))
        for d in drop:
            p = os.path.join(self.root, d)
            if os.path.isdir(p): shutil.rmtree(p)
            elif os.path.exists(p): os.remove(p)
        self.extra = extra_env or {}

    def make_manifest(self):
        lines = []
        for dp, dn, fn in os.walk(self.root):
            dn[:] = sorted(x for x in dn if x not in ("__pycache__", ".gia"))
            for f in sorted(fn):
                p = os.path.join(dp, f)
                if f.endswith(".pyc") or f.startswith("BUILD_HASHES"): continue
                lines.append("%s  %s" % (hashlib.sha256(open(p, "rb").read()).hexdigest(), os.path.relpath(p, self.root).replace(os.sep, "/")))
        open(os.path.join(self.root, "BUILD_HASHES.sha256"), "w").write("\n".join(lines) + "\n")

    def _env(self):
        e = dict(os.environ)
        for k in ("GIA_MODE", "GIA_STATE_DIR", "GIA_RUNTIME_DIR", "GIA_CAPTURE_RAW", "GIA_DENY_MODE", "GIA_PROFILE"): e.pop(k, None)
        e.update(CLAUDE_PLUGIN_ROOT=self.root, CLAUDE_PROJECT_DIR=self.proj, PYTHONDONTWRITEBYTECODE="1", GIA_PROFILE="uat")
        e.update(self.extra); return e

    def raw(self, text, event="PreToolUse"):
        p = subprocess.run([sys.executable, os.path.join(self.root, "hooks", "gia_guard.py"), "hook"], input=text, capture_output=True, text=True, env=self._env(), timeout=60)
        return p.returncode, p.stdout, p.stderr

    def hook(self, event, sid="S1", **kw):
        payload = {"hook_event_name": event, "session_id": sid, "cwd": self.proj}; payload.update(kw)
        return self.raw(json.dumps(payload), event)

    def start(self, sid="S1"): self.hook("SessionStart", sid=sid); return self
    def pre(self, tool, sid="S1", **tin): return self.hook("PreToolUse", sid=sid, tool_name=tool, tool_input=tin)
    def pre_kw(self, tool, tin, sid="S1", **kw): return self.hook("PreToolUse", sid=sid, tool_name=tool, tool_input=tin, **kw)
    def post(self, tool, resp, sid="S1", **tin): return self.hook("PostToolUse", sid=sid, tool_name=tool, tool_input=tin, tool_response=resp)
    def prompt(self, text, sid="S1", **kw): return self.hook("UserPromptSubmit", sid=sid, prompt=text, **kw)

    def cli(self, *args, raw=False):
        p = subprocess.run([sys.executable, os.path.join(self.root, "hooks", "gia_guard.py")] + list(args), capture_output=True, text=True, env=self._env(), cwd=self.proj, timeout=60)
        if raw: return p.returncode, p.stdout
        try: return json.loads(p.stdout)
        except Exception: return {"_raw": p.stdout, "_rc": p.returncode}

    def status(self): return self.cli("status")
    def sdir(self, sid="S1"): return os.path.join(self.proj, ".gia", "sessions", sid)
    def log(self, sid="S1"): return [json.loads(l) for l in open(os.path.join(self.sdir(sid), "events.jsonl"))]
    def events(self, name, sid="S1"): return [r for r in self.log(sid) if r["event"] == name]


def denied(r):
    rc, out, _ = r
    if rc == 2: return True
    try: return json.loads(out)["hookSpecificOutput"]["permissionDecision"] == "deny"
    except Exception: return False


def stopped(r):
    rc, out, _ = r
    if rc == 2: return True
    try: return json.loads(out).get("continue") is False
    except Exception: return False


def blocked(r):
    try: return json.loads(r[1]).get("decision") == "block" or json.loads(r[1]).get("continue") is False
    except Exception: return False


def context(r):
    try: return json.loads(r[1]).get("hookSpecificOutput", {}).get("additionalContext", "")
    except Exception: return r[1]
