"""Deterministic fuzz subset (seeds 0-39). The full campaign is a release gate: python3 tests/guard/fuzz_guard.py --seeds 1500 --steps 70"""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import fuzz_guard as F

def test_fuzz_invariants_hold_on_40_adversarial_sequences():
    assert F.main(["--seeds", "40", "--steps", "60", "--start", "0"]) == 0
