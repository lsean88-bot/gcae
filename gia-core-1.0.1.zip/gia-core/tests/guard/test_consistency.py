"""Package invariants for gia-core: one version authority, policy JSON as the single source, hooks wiring, skills and references consistent."""
import os, re, sys, json, glob, yaml
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(os.path.dirname(HERE)); sys.path.insert(0, ROOT)
def J(rel): return json.load(open(os.path.join(ROOT, rel), encoding="utf-8"))
def Y(rel): return yaml.safe_load(open(os.path.join(ROOT, rel), encoding="utf-8"))
def T(rel): return open(os.path.join(ROOT, rel), encoding="utf-8", errors="ignore").read()
V = lambda: J(".claude-plugin/plugin.json")["version"]
SKILLS = sorted(os.listdir(os.path.join(ROOT, "skills")))


def test_single_version_authority():
    v = V(); src = T("hooks/gia_guard.py"); rel = T("runtime/release.py")
    bad = []
    for name, got in [("manifest", J("RELEASE_MANIFEST.json")["version"]), ("policy", J("core/policy/execution-thresholds.json")["version"]),
                      ("guard", re.search(r'GUARD_VERSION = "([^"]+)"', src).group(1)), ("release.py", re.search(r"VERSION='([^']+)'", rel).group(1)),
                      ("controls", J("core/policy/runtime-controls.json")["version"]), ("rules", J("skills/iron-rules/rules.json")["version"])]:
        if str(got) != v:
            bad.append((name, got))
    for p in glob.glob(os.path.join(ROOT, "core/policy/*.yaml")):
        if str(yaml.safe_load(open(p)).get("version")) != v:
            bad.append((os.path.basename(p), "version"))
    assert not bad, bad


def test_no_stale_gcae_versions_in_skill_files():
    bad = []
    for p in glob.glob(os.path.join(ROOT, "skills/*/SKILL.md")) + [os.path.join(ROOT, "README.md")]:
        if os.path.exists(p):
            for m in re.findall(r"\b14\.\d+\.\d+(?:-rc\d+)?\b", open(p, encoding="utf-8").read()):
                bad.append((os.path.relpath(p, ROOT), m))
    assert not bad, bad[:10]


def test_policy_json_is_single_authority_and_yaml_is_a_faithful_view():
    assert Y("core/policy/execution-thresholds.yaml") == J("core/policy/execution-thresholds.json")
    p = J("core/policy/execution-thresholds.json"); sp = Y("core/policy/execution-safety-policy.yaml"); x = p["execution"]
    t = sp.get("thresholds") or {}
    for k, want in [("tool_call_warning", x["tool_call_warning"]), ("tool_call_hard_limit", x["tool_call_hard_limit"])]:
        if k in t:
            assert t[k] == want, (k, t[k], want)


def test_guard_policy_block_is_sane_and_assumed_values_are_declared():
    g = J("core/policy/execution-thresholds.json")["guard"]; x = J("core/policy/execution-thresholds.json")["execution"]
    assert g["max_restarts"] >= 1 and g["lifetime_identical_cap"] > x["repeated_call"]["exact_threshold"]
    assert g["per_agent_tool_hard"] <= g["global_tool_hard"] and x["tool_call_hard_limit"] <= g["global_tool_hard"]
    assert g["stop_lock_scope"] in ("session", "project") and x["agent"]["delegation_depth"] == 1
    assert "ASSUMED" in g["status"] and all(k in g for k in g["assumed"]) or all(k in g or k in x.get("references", {}) for k in g["assumed"])


def test_economy_policy_points_at_the_rule_32_matrix_and_does_not_restate_it():
    ep = Y("core/policy/economy-policy.yaml")
    assert ep["model_routing"]["authority"] == "skills/model-effort-routing/data/matrix.json" and os.path.exists(os.path.join(ROOT, ep["model_routing"]["authority"]))
    m = J("skills/model-effort-routing/data/matrix.json")
    assert set(ep["model_routing"]["never_downgrade"]) == set(m["never_downgrade"])


def test_expected_skills_match_directory_and_every_skill_is_well_formed():
    exp = set(J("core/policy/execution-thresholds.json")["guard"]["expected_skills"])
    assert exp == set(SKILLS), (exp ^ set(SKILLS))
    for s in SKILLS:
        t = T("skills/%s/SKILL.md" % s)
        fm = re.match(r"^---\n(.*?)\n---\n", t, re.S).group(1)
        name = re.search(r"^name:\s*(\S+)", fm, re.M).group(1); desc = re.search(r"^description:\s*(.*)$", fm, re.M).group(1)
        assert name == s and 0 < len(desc) <= 1024, (s, name, len(desc))
        assert len(t.splitlines()) < 500, s


def test_hooks_json_has_one_guard_dispatcher_per_event_plus_the_retirement_gate_only():
    h = J("hooks/hooks.json")["hooks"]; known = {"SessionStart", "UserPromptSubmit", "UserPromptExpansion", "PreToolUse", "PostToolUse", "PostToolUseFailure", "PostToolBatch", "SubagentStart", "SubagentStop", "TaskCreated", "TaskCompleted", "Stop", "StopFailure", "SessionEnd"}
    assert set(h) <= known and {"SessionStart", "UserPromptSubmit", "PreToolUse", "PostToolUse", "PostToolUseFailure", "SubagentStop", "Stop", "StopFailure"} <= set(h)
    for ev, arr in h.items():
        guard = [e for e in arr if "run_guard.sh" in json.dumps(e)]
        other = [e for e in arr if "run_guard.sh" not in json.dumps(e)]
        assert len(guard) == 1 and len(guard[0]["hooks"]) == 1, ev   # exactly one guard handler per event: hooks run in parallel and would race on state
        c = guard[0]["hooks"][0]; assert c.get("timeout"), ev
        for o in other:
            assert ev == "PreToolUse" and "retirement-gate.sh" in json.dumps(o), (ev, o)
    assert not os.path.exists(os.path.join(ROOT, "hooks/telemetry_hook.py"))


def test_launcher_is_fail_closed_and_not_python_only():
    t = T("hooks/run_guard.sh")
    assert "exit 2" in t and "python3" in t and "py -3" in t


def test_every_reference_file_is_named_by_its_skill():
    orphan = []
    for s in SKILLS:
        rd = os.path.join(ROOT, "skills", s, "references")
        if os.path.isdir(rd):
            body = T("skills/%s/SKILL.md" % s)
            orphan += [(s, f) for f in os.listdir(rd) if f not in body and not f.startswith("history-")]
    assert not orphan, orphan


def test_no_dangling_documentation_paths():
    pat = re.compile(r"`((?:tests|core|runtime|hooks|docs|references|agents|scripts|commands|monitors|data|config|skills)/[A-Za-z0-9_./\-]+\.[a-z0-9]+)`"); bad = []
    files = ["README.md"] + [os.path.relpath(p, ROOT) for p in glob.glob(os.path.join(ROOT, "skills/*/SKILL.md")) + glob.glob(os.path.join(ROOT, "skills/*/references/*.md")) + glob.glob(os.path.join(ROOT, "agents/*.md")) + glob.glob(os.path.join(ROOT, "commands/*.md"))]
    for f in files:
        if not os.path.exists(os.path.join(ROOT, f)):
            continue
        skill_dir = os.path.join(ROOT, *f.split("/")[:2]) if f.startswith("skills/") else ROOT
        for m in pat.findall(T(f)):
            if "${" in m or "<" in m or "*" in m:
                continue
            if not (os.path.exists(os.path.join(ROOT, m)) or os.path.exists(os.path.join(skill_dir, m))):
                bad.append((f, m))
    assert not bad, bad[:20]


def test_guard_and_scope_authority_share_one_destructive_set():
    from runtime.scope import DESTRUCTIVE; src = T("hooks/gia_guard.py")
    toks = set(re.findall(r'"(\w+)"', re.search(r"DESTRUCTIVE_TOKENS = \{(.*?)\}", src, re.S).group(1)))
    assert toks == DESTRUCTIVE


def test_no_stale_hash_manifests():
    names = [os.path.basename(p) for p in glob.glob(os.path.join(ROOT, "BUILD_HASHES*.sha256"))]
    assert all(n == "BUILD_HASHES.sha256" for n in names), names


def test_telemetry_policy_matches_what_hooks_can_observe():
    sp = Y("core/policy/execution-safety-policy.yaml")["controlled_run"]
    assert sp["invalid_telemetry"] == "fail_closed" and "NOT_OBSERVED" in sp["absent_telemetry"]


def test_agents_pin_a_model_and_an_effort_note():
    for p in glob.glob(os.path.join(ROOT, "agents/*.md")):
        t = open(p, encoding="utf-8").read()
        fm = re.match(r"^---\n(.*?)\n---\n", t, re.S).group(1)
        assert re.search(r"^model:\s*(sonnet|haiku)\s*$", fm, re.M), p
        assert re.search(r"^Effort: (low|medium|high)", t, re.M), p  # body line; the frontmatter parser merges comments into the previous key
        if re.search(r"qa|review|validator|kaizen|cyber", os.path.basename(p)):
            assert not re.search(r"Write|Edit|Bash", re.search(r"^tools:\s*(.*)$", fm, re.M).group(1)), p


def test_release_identity_sources_declared_and_equal():
    ident = Y("core/authority/release-identity.yaml"); v = V()
    assert str(ident["version"]) == v and str(ident["baseline"]).startswith("GCAE 14.5.0")
    assert ident["production_status"] == "NOT_ACCEPTED" and ident["builder_self_certification"] == "FORBIDDEN"
    for rel in ident["release_identity_sources"]:
        assert os.path.exists(os.path.join(ROOT, rel)), rel
