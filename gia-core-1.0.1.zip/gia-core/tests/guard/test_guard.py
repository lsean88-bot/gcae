"""pytest/mini-runner wrappers: one test per guard suite group (see suite.py)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from suite import SUITE, GUARD

def _mk(fn):
    def t():
        bad = [n for n, ok in fn(GUARD) if not ok]
        assert not bad, bad
    return t
for _name, _fn in SUITE:
    globals()["test_guard_" + _name] = _mk(_fn)
