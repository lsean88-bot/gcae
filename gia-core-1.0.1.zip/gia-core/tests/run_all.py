#!/usr/bin/env python3
"""Run every gia-core test and print one honest summary.   python3 -I tests/run_all.py [--full] [--json out.json]

Default: unit suites, lint, router, selector, memory, learning, hygiene, drift and render checks.
--full adds the slow suites: guard mutation testing, grader mutation testing, fuzzing and the guard pytest wrappers.
A step is PASS only when its command exited 0. Nothing is counted as passed without having run.
Exit 0 only when every step that ran passed.
"""
import json
import os
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PY = [sys.executable, "-I", "-B"]
S = lambda *p: os.path.join(ROOT, "skills", *p)

QUICK = [
    ("guard suite (v14.5 groups, retargeted)", PY + ["tests/guard/suite.py"]),
    ("runtime controls GR-16..19 (hook tests)", PY + ["tests/test_gr_controls.py"]),
    ("safeguard-lint tests", PY + [S("safeguard-lint", "tests", "test_safeguard_lint.py")]),
    ("safeguard-lint canonical-code tests", PY + [S("safeguard-lint", "tests", "test_canonical_codes.py")]),
    ("iron-rules consistency tests", PY + [S("iron-rules", "scripts", "test_rules.py")]),
    ("iron-rules render check", PY + [S("iron-rules", "scripts", "render_rules.py"), "--check"]),
    ("governance drift check (this plugin)", ["bash", S("iron-rules", "scripts", "check-governance-drift.sh")]),
    ("runtime controls render check", PY + [S("runtime-guard", "scripts", "render_runtime_controls.py"), "--check"]),
    ("model-effort selector tests", PY + [S("model-effort-routing", "tests", "test_selector.py")]),
    ("model-effort matrix render check", PY + [S("model-effort-routing", "scripts", "render_matrix.py"), "--check"]),
    ("agent frontmatter vs Rule 32 matrix", PY + [S("model-effort-routing", "scripts", "select_model_effort.py"), "check-agents", os.path.join(ROOT, "agents")]),
    ("router registry is current", PY + [S("gcgo-router", "scripts", "build_registry.py"), "--check"]),
    ("router selftest (regression gate)", PY + [S("gcgo-router", "scripts", "gcgo_route.py"), "selftest"]),
    ("router selections exist (agents and skills)", PY + ["tests/test_router_agents.py"]),
    ("router tests (plan, brief, bypass stop, adapter)", PY + [S("gcgo-router", "tests", "test_gcgo.py")]),
    ("verify_install", PY + [S("gcgo-router", "scripts", "verify_install.py")]),
    ("self-learning tests", PY + [S("self-learning", "tests", "test_log_lesson.py")]),
    ("skill-hygiene tests", PY + [S("skill-hygiene", "tests", "test_skill_hygiene.py")]),
    ("project-memory kg_tools tests", PY + [S("project-memory", "tests", "test_kg_tools.py")]),
    ("project-memory brain tests (pytest; graphify tests skip)", [sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", S("project-memory", "tests")]),
    ("guard consistency, controls, routing, golden (pytest)", [sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "tests/guard/test_consistency.py", "tests/guard/test_runtime_controls.py",
                                                                "tests/guard/test_routing_uat.py", "tests/golden"]),
]
FULL = [
    ("guard pytest wrappers, economy, grader, fuzz (pytest)", [sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "tests/guard/test_guard.py", "tests/guard/test_economy.py",
                                                               "tests/guard/test_grader.py", "tests/guard/test_fuzz.py"]),
    ("guard mutation testing", PY + ["tests/guard/mutate_guard.py"]),
    ("grader mutation testing", PY + ["tests/guard/mutate_grader.py"]),
    ("GR controls mutation testing", PY + ["tests/mutate_gr_controls.py"]),
]


def main():
    full = "--full" in sys.argv
    steps = QUICK + (FULL if full else [])
    rows = []
    for name, cmd in steps:
        t0 = time.time()
        try:
            p = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=3000)
            rc, out = p.returncode, (p.stdout + p.stderr).strip().splitlines()
        except subprocess.TimeoutExpired:
            rc, out = 124, ["timed out"]
        last = out[-1][:110] if out else ""
        rows.append({"step": name, "rc": rc, "seconds": round(time.time() - t0, 1), "last_line": last})
        print("%-4s %-62s %6.1fs  %s" % ("PASS" if rc == 0 else "FAIL", name, time.time() - t0, last), flush=True)
    bad = [r for r in rows if r["rc"] != 0]
    print("\n%d steps run, %d passed, %d failed%s" % (len(rows), len(rows) - len(bad), len(bad), "" if full else " (quick set; pass --full for mutation, fuzz and grader suites)"))
    if "--json" in sys.argv:
        open(sys.argv[sys.argv.index("--json") + 1], "w").write(json.dumps(rows, indent=1))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
