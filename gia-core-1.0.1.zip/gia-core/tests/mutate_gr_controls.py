#!/usr/bin/env python3
"""Mutation test: each mutant of hooks/gr_controls.py must make tests/test_gr_controls.py fail."""
import os, shutil, subprocess, sys, tempfile
HERE=os.path.dirname(os.path.abspath(__file__)); PLUG=os.path.dirname(HERE)
M=[("notice codes shrink",'NOTICE_CODES = {"LNT-FRAUD-CONCLUSIVE", "LNT-TR-STATUS", "LNT-STD-CITE", "LNT-PII"}','NOTICE_CODES = {"LNT-TR-STATUS"}'),
("pre-write notice off","    if errs:\n        audit(\"lint-notice\", {\"event\": \"pre-write\"","    if False:\n        audit(\"lint-notice\", {\"event\": \"pre-write\""),
("post-write notice off","        if new:\n            st[\"warned\"]","        if False:\n            st[\"warned\"]"),
("stop empty-message guard off","    if len(msg) < 150 or MAINTAINER:\n        return","    if MAINTAINER:\n        return"),
("guarded plugin tree off","            if under(p, ROOT):\n                parts =","            if False:\n                parts ="),
("guarded plugin root off","            if p == os.path.realpath(ROOT) or os.path.realpath(ROOT).startswith(p + os.sep):\n                return True","            if False:\n                return True"),
("maintainer lifts state dir","    if MAINTAINER:\n        return False\n    for p in resolve(path, cwd):\n        try:\n            if under(p, data_dir()):","    if False:\n        return False\n    for p in resolve(path, cwd):\n        try:\n            if under(p, data_dir()):"),
("fail-closed events shrink",'FAIL_CLOSED_EVENTS = ("pre-write", "pre-bash")','FAIL_CLOSED_EVENTS = ("pre-write",)'),
("stdin parse failure fails open",'        if event in FAIL_CLOSED_EVENTS:\n            sys.stdout.write(json.dumps({"hookSpecificOutput": {"hookEventName": "PreToolUse", "permissionDecision": "deny",','        if False:\n            sys.stdout.write(json.dumps({"hookSpecificOutput": {"hookEventName": "PreToolUse", "permissionDecision": "deny",'),
("internal error fails open in run",'        if event in FAIL_CLOSED_EVENTS:\n            raise GRError','        if False:\n            raise GRError'),
("plugin root skip bypass","def in_plugin(path):\n    try:","def in_plugin(path):\n    return False\n    try:"),
("warn dedup off","if key not in seen:","if True:"),
("stop quote strip off","run_lint(QUOTED.sub(\" \", msg))","run_lint(msg)"),
("stop gating off",'if not state_get(sid).get("audit_active") and','if False and'),
("chain prev constant","e[\"prev\"] = prev","e[\"prev\"] = \"0\" * 64"),
("no flock","fcntl.flock(f, fcntl.LOCK_EX)","pass"),
("injection notice off",'    if flags:\n        rules','    if False:\n        rules'),
("read scan off","    if flags:\n        audit(\"injection-flag\", {\"flags\": flags, \"source\"","    if False:\n        audit(\"injection-flag\", {\"flags\": flags, \"source\""),
("read plugin skip off","    if path and in_plugin(path):\n        return\n    resp","    resp"),
("multiedit ignored",'    if name == "MultiEdit":','    if name == "MultiEditX":'),
("evidence extra dirs off",'for extra in filter(None, os.environ.get("GIA_EVIDENCE_DIRS", "").split(":")):','for extra in []:'),
('evidence regex dropped', 'NAMES = r"(?:evidence|', 'NAMES = r"(?:evidenceX|'),
('rm not destructive', '"ex", "rm", "rmdir"', '"ex", "rmX", "rmdir"'),
('redirect check off', 'if (protected_evidence(x, cur) and os.path.exists(resolve(x, cur)[1])) or guarded_path(x, cur):', 'if False:'),
('cd tracking off', 'cur = resolve(subst(targets[0], env), cur)[0]', 'pass'),
('cp dest check off', 'elif len(paths) >= 2:\n                d = dest_exists_deny(paths[-1], paths[:-1], cwd)', 'elif False:\n                d = None'),
('exfil ask->allow', 'out.append(("ask", "GR-17", "Outbound upload', 'pass; (("ask", "GR-17", "Outbound upload'),
('remote tools off', 'elif verb in REMOTE_TOOLS and (paths', 'elif False and (paths'),
('existing-file check off', 'if protected_evidence(path, cwd) and os.path.exists(resolve(path, cwd)[1]):', 'if False:'),
('verify skips hash', 'if _h(prev + _canon(e)) != h:', 'if False:'),
('session digest off', 'ctx("SessionStart", GR_DIGEST + note)', 'pass'),
('narrative ext widened', 'NARRATIVE_EXT = (".md",', 'NARRATIVE_EXT = (".py", ".csv", ".md",'),
('short-content skip off', 'if len(text) >= 12 else []', 'if True else []'),
('guard data dir off', 'if under(p, data_dir()):\n                return True', 'if False:\n                return True'),
('symlink resolve off', 'r = os.path.realpath(n)', 'r = n'),
('shell -c unwrap off', 'if script and depth >= 3:', 'if False:'),
('xargs rule off', 'if via_xargs and (verb in DESTRUCTIVE_ALWAYS or verb == "mv"):', 'if False:'),
('loop rule off', 'loop_protected = any(', 'loop_protected = False and any('),
('start log verify off', 'ok, msg = verify_log()', 'ok, msg = True, ""'),
('bash lint off', 'if lint_targets and not MAINTAINER:', 'if False:'),
('dev/tcp off', 'if tgt.startswith("/dev/tcp/"):', 'if False:'),
('nc rule off', 'elif verb in NC_TOOLS:', 'elif False:'),
('cloud copy off', 'elif verb in ("aws", "gsutil",', 'elif False and verb in ("aws", "gsutil",'),
('rsync remote ask off', 'if any(re.match(r"^(?:[\\w.-]+@)', 'if False and any(re.match(r"^(?:[\\w.-]+@)'),
('shell wrapper skipped', 'if verb in SHELLS or verb == "eval":', 'if False:')]
src=open(os.path.join(PLUG,"hooks","gr_controls.py")).read(); surv=[]; skipped=[]
for name,a,b in M:
    if a not in src: skipped.append(name); continue
    d=tempfile.mkdtemp(); shutil.copytree(PLUG,os.path.join(d,"p"),ignore=shutil.ignore_patterns("__pycache__"))
    open(os.path.join(d,"p","hooks","gr_controls.py"),"w").write(src.replace(a,b,1))
    r=subprocess.run([sys.executable,"-I","-B",os.path.join(d,"p","tests","test_gr_controls.py")],capture_output=True,text=True,timeout=110)
    shutil.rmtree(d,ignore_errors=True)
    print(("KILLED " if r.returncode else "SURVIVED"),name,flush=True)
    if not r.returncode: surv.append(name)
print("mutants: %d, killed: %d, survived: %s, pattern-not-found: %s"%(len(M)-len(skipped),len(M)-len(skipped)-len(surv),surv,skipped))
sys.exit(1 if surv or skipped else 0)
