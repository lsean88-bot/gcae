# Changelog

## 1.0.1 (30-Oct-2026), QA defect fixes (D5, D7, D9 to D15)

Version bumped consistently across plugin.json, RELEASE_MANIFEST, guard, release.py, policy files, rules, matrix, registry and schemas.

- Cross-references: every `gia-*:<name>` now resolves to a built skill, agent or command (short blueprint names replaced with built names).
- Descriptions of all skills and agents are 400 characters or fewer, trigger words first, with the Do NOT use clause kept (one redirect where space was short); all quoted so frontmatter parses as YAML.
- Script paths in skills, commands and agents use `${CLAUDE_PLUGIN_ROOT}/skills/<skill>/scripts/...`.
- Dangling in-skill links fixed or removed; empty directories and caches deleted.
- Router no longer selects the non-existent `gia-core:fleet`: it selects `gia-core:alpha-scout`, `beta-analyst`, `delta-validator` and `portfolio-qa-challenger`; the conductor label is `gia-core-agents`. New test `tests/test_router_agents.py` (21st quick step) checks every router selection exists.
- Added `skills/project-memory/references/source-intake-and-data-discipline.md` (data-layer discipline, extraction method, document-grounded mode, file-catalog rules) from the port check.
- Port disposition (QA R2 N2): every element of the eight PARTIAL port-check sources is recorded PORTED or DROPPED in MIGRATION.md; ported content added as `gcgo-router/references/cae-role-and-style.md`, `project-memory/references/document-grounded-rules.md` and `file-catalog-taxonomy.md`, and a session debrief section in `self-learning/references/kaizen-and-lessons.md`.
- Wording: beta-analyst states MAD primary, chi-square supplementary; lexicon line says substantiated findings.
- Always-loaded name plus description tokens (chars/4): skills 781, agents 999, commands 225, total 2005.

## 1.0.0 (29-Oct-2026), release candidate

First consolidated release. Merges the governance, router, runtime guard, lint, memory, learning and skill-hygiene pieces of the earlier library into one plugin with eight skills. Production status: NOT_ACCEPTED pending live UAT.

### Approved amendment

- 29-Oct-2026, approved by the CAE: the standard concise IA report plus an Excel working paper is the canonical report format (Profile A for the auditee and EXCO, Profile B for the Board, Audit Committee and Chairman). The 13-section structure is a legacy conversion reference only. This replaces the earlier statement that the 13-section structure stayed canonical. Recorded in `skills/iron-rules/references/history-provenance.md` and `skills/iron-rules/SKILL.md`.

### Added

- `iron-rules`: rules as `rules.json`, generated rules file, fraud ladder, Charlie Hills cycle defined once, drift script, `render_rules.py`, `test_rules.py`.
- `runtime-guard`: four controls the guard lacked (GR-16 evidence immutability, GR-17 PII and exfiltration gate, GR-18 fraud-wording lint, GR-19 self-protection), a mapping of GR controls to the Iron Rules, mutation tests for the added controls.
- `gcgo-router`: Rule 31 and 32 team and model brief step; registry built from a hand-edited source and validated; `verify_install.py`.
- `model-effort-routing`: matrix as data, selector, agent-frontmatter lint.
- `self-learning`: promotion needs a go-ahead; store outside the plugin folder; recurrence finder.
- `skill-hygiene`: `skill_lint.py` so preflight needs no external validator; both monitors have a `--once` mode.
- `project-memory`: confidential shelf rules, session start protocol, improvement boundary.
- Evals for every skill with should-trigger and should-not-trigger prompts.

### Fixed

- Read-only commands that were denied by the earlier 12.1.1 hook (heredocs, redirects to file descriptors, words such as "evidence" inside quoted text). The shell analyser is now command-position based; regression tests pin the cases.
- Unbounded reference budget logic now covers references inside each skill folder; the standard budget is 8 and the high-consequence budget 16 (ASSUMED).
- `delegation depth` is 1 in both policy and guard.
- Stale and broken references: retired skill names, missing files, sibling skill names without the `gia-` prefix.

### Removed

- Personal names and case facts in method files, retired orchestrator and plugin names, the 27, 14 and 10 item gate variants, a second router, the `import-sentinel` command.

### Known gaps

See "Open items" in `MIGRATION.md`.
