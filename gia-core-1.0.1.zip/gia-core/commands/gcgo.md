---
description: "Route a work request: profile it, pick conductor and engine, assign skills, tools and gates"
argument-hint: "<what you need done>"
---

Use the gia-core:gcgo-router skill for: $ARGUMENTS

1. Build the Work Requirement Profile (outcome, audience, entity, jurisdiction, period, stage, evidence in hand versus conclusion requested, risk flags). State what you inferred and ask only the one question that would change the route.
2. Run `python3 -I ${CLAUDE_PLUGIN_ROOT}/skills/gcgo-router/scripts/gcgo_route.py list-intents` from the skill folder, classify the request yourself, then run `${CLAUDE_PLUGIN_ROOT}/skills/gcgo-router/scripts/gcgo_route.py route "<request>" --intents ... --entities ... --jurisdictions ... --flags ...` so the plan is built from your classification, not keyword guesses.
3. Present the plan: conductor and why, the one methodology engine, governors, specialists, subagents where available, tools, the Rule 31/32 team and model brief, and every gate that needs the CAE decision.
4. Do not start work until the CAE confirms the plan. Do not send, publish, file, archive or rename anything."
