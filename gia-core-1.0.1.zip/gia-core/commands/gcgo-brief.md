---
description: Write the end-of-session handoff note and propose CLAUDE.md or registry updates
argument-hint: <engagement or topic>
---

Use the gia-core:gcgo-router skill for: $ARGUMENTS

Write the handoff note from references/operating-protocol.md (done, decisions made with dates, waiting on the CAE, blocked, next actions and owners, open conflicts, proposed registry or CLAUDE.md changes). One screen. Log any correction with gia-core:self-learning and propose, never apply, changes to core rules.
