---
description: Report project memory and knowledge graph status for this engagement and run a retrospective
---

Use the gia-core:project-memory skill.

1. Read the engagement memory files in the current folder. If any is missing, say so and suggest /gia-core:akos-init.
2. Report briefly: confirmed facts (added or changed since last review), open questions by priority with owner, assumptions near expiry, recent decisions, graph size and orphan nodes (`${CLAUDE_PLUGIN_ROOT}/skills/project-memory/scripts/kg_tools.py check-integrity`), and any Medium or Low confidence items still being relied on.
3. Run the retrospective questions from gia-core:self-learning against this session and propose any lesson worth logging; ask the CAE to confirm before writing it.
4. Change no confirmed fact, policy, control design or audit conclusion while reporting; only report and ask.
