---
description: "Status board for an engagement folder: what is done, waiting on the CAE, blocked, next"
argument-hint: "<engagement folder path>"
---

Use the gia-core:gcgo-router skill. Run the router script `engagement_status.py` on: $ARGUMENTS

Report in one screen: counts, items waiting on the CAE (exceptions, contradictions, gaps, draft findings, QA points, overdue actions), which gates look ready for confirmation, and the next actions with owners. State that registers show what was recorded, not whether it is right. End with a handoff note (references/operating-protocol.md).
