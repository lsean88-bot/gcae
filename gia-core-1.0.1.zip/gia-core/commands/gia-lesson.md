---
description: Log a correction as a lesson and propose a standing rule if it recurs
argument-hint: <what went wrong>
---

Use the gia-core:self-learning skill for: $ARGUMENTS

1. Log it: `python3 -I ${CLAUDE_PLUGIN_ROOT}/skills/self-learning/scripts/log_lesson.py log --category ... --trigger "..." --correction "..." --context "..."` (run `init` first if needed).
2. Run `log_lesson.py candidates` and `check --query` to see whether the same pattern was logged before.
3. If it recurred, propose the exact wording of a standing rule to the CAE and wait for the go-ahead (Rule 20) before running `promote`. Never edit core rules without approval.
4. Do not record anything that reduces honesty, evidence checking or disagreement.
