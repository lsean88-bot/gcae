---
description: Regression check on the routing registry before shipping a change
---

Use the gia-core:gcgo-router skill. Run `python3 -I ${CLAUDE_PLUGIN_ROOT}/skills/gcgo-router/scripts/gcgo_route.py selftest`.

Report the pass counts for each bundled scenario set. The core and natural sets must pass 100 percent; the info sets are tracked, not gated. State plainly that the selftest is a regression check, not a measure of accuracy on new phrasing. If anything fails, show the failing scenario and the signal or exemplar that should change, and propose the registry edit for the CAE approval.
