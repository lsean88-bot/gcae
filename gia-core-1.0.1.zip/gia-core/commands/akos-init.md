---
description: Initialize project memory and knowledge graph files for a new engagement
argument-hint: [engagement name]
---

Use the gia-core:project-memory skill. Read its references/protocols.md and references/project-memory-schema.md first.

Engagement: $ARGUMENTS

1. Check whether PROJECT_MEMORY.md, project-memory.json, knowledge-graph.json and a lessons log already exist in the current folder. If they do, report what they hold instead of recreating them.
2. If not, run `python3 -I ${CLAUDE_PLUGIN_ROOT}/skills/project-memory/scripts/kg_tools.py init` and create the Markdown register skeleton from the schema, empty and ready to fill, with no placeholder example data.
3. Ask one focused question: the scope boundary (entities, countries, period). Record the answer as the first Confirmed Fact.
4. Say where each file was created and that every future session on this engagement starts by reading them.
