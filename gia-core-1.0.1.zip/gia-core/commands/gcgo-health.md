---
description: "Library health check: duplicates, dangling references, overlap, registry drift"
---

Use the gia-core:gcgo-router skill. Run `python3 -I ${CLAUDE_PLUGIN_ROOT}/skills/gcgo-router/scripts/verify_install.py` and `${CLAUDE_PLUGIN_ROOT}/skills/gcgo-router/scripts/library_inventory.py --registry ${CLAUDE_PLUGIN_ROOT}/skills/gcgo-router/data/capability-registry.json --plugins-dir <plugins folder>`.

Summarise for the CAE: new or removed skills, duplicates, references to skills that are not installed, trigger overlaps that could cause mis-routing, registry drift, and any description over 1024 characters. Propose registry edits and archiving decisions, but change nothing: archiving, renaming and editing other skills need the CAE approval. Offer to log lessons with gia-core:self-learning.
