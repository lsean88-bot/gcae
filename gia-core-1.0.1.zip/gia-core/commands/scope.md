---
description: Approve or decline an additional-scope request held by the guard
argument-hint: approve|decline
---

Argument: $ARGUMENTS

Only the CAE can decide a scope hold. The guard reads this command as a standalone prompt: approve adds the held request to the authorised scope and releases the hold; decline clears the hold and leaves the scope unchanged. Do not decide it yourself. If no scope request is held, say so.
