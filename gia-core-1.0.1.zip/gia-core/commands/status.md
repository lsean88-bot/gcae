---
description: Show the runtime guard state, counters and last route
---

Use the gia-core:runtime-guard skill.

Run `python3 "${CLAUDE_PLUGIN_ROOT}/hooks/gia_guard.py" status` and show the result: state (RUNNING or STOP), stop reason if any, restart count, tool and agent counters, the last route and whether the evidence log verifies. Change nothing.
