# gia-core 1.0.1

Governance core for Group Internal Audit work in Claude Code and Cowork. It holds the rules, the router, the runtime guard and the housekeeping the other gia plugins rely on. Status: RELEASE_CANDIDATE. Production is NOT_ACCEPTED until live runtime UAT (T0 to T16) has run in a Claude Code session.

## Skills

| Skill | Does |
|---|---|
| `iron-rules` | The Iron Rules as data, the Golden Rule, R1-R5 evidence, the 12-item Quality Gate, the fraud ladder, Rule 32 summary, drift check |
| `gcgo-router` | The one front door: classify, pick conductor and engine, sequence skills, write briefs with the Rule 31 and 32 team and model brief |
| `runtime-guard` | Fail-closed hooks: evidence immutability, destructive and scope holds, exfiltration ask, loop and agent caps, hash-chained log, lint and injection notices |
| `safeguard-lint` | Text lint for unsupported fraud wording, unverified rates, personal data, placeholders, process narration |
| `model-effort-routing` | Rule 32 matrix as data and a selector for model tier and effort |
| `project-memory` | Registers and knowledge graph for multi-session engagements; library brain with confidential shelves |
| `self-learning` | Capture corrections, check lessons, promote only with the CAE go-ahead |
| `skill-hygiene` | Skill lint, overlap scan, retirement gate, drift and unverified-claim monitors |

Also: 12 agents in `agents/` (eleven fleet roles and `portfolio-qa-challenger`, each pinned to sonnet with an effort note), 11 commands in `commands/`, hooks in `hooks/`, monitors in `monitors/`.

## Using it

- Start work with `/gcgo "<request>"`. Single clear tasks go straight to the specialist skill.
- After a guard STOP, only the CAE restarts it with `/gia-core:restart`. `/gia-core:status` shows state. `/gia-core:scope approve|decline` decides a scope hold.
- Log corrections with `/gia-lesson`. Initialise engagement memory with `/akos-init`.
- Cite rules as `gia-core:iron-rules` plus the rule number.

## Install and check

Place the folder with its sibling gia plugins in one plugins directory. Then run, from the plugin root:

    python3 -I skills/gcgo-router/scripts/verify_install.py
    python3 -I tests/run_all.py

`tests/RESULTS.md` records what was run and what passed. Sibling plugins: gia-audit, gia-fraud, gia-analytics, gia-report-qa.

## Honest limits

- Hooks, subagents and model selection work only in Claude Code and Cowork; in plain chat the rules apply as instructions.
- The guard is a guardrail, not a sandbox. Lint and injection patterns are weak signals and only warn.
- Keyword routing is weak on unseen phrasing; the regression sets pass because they define expected behaviour.
- Thresholds marked ASSUMED in `core/policy/execution-thresholds.json` need the CAE's approval.
- Graph indexing in `project-memory` needs the external `graphify` package, which is not bundled.

## More

`CHANGELOG.md`, `MIGRATION.md` (old to new), `core/RUNTIME_CONTROLS.md` (GR controls), `tests/RESULTS.md`.
