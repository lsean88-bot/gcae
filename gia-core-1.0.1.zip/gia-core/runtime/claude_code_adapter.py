"""Provider-neutral event normalisation for Claude Code.
Only explicit structured fields are trusted. Business/content text is never scanned for failure tokens.
"""
from dataclasses import dataclass
from typing import Any
KNOWN_FAILURE_CODES={
 'rate_limit':'RATE_LIMIT','rate_limit_error':'RATE_LIMIT','too_many_requests':'RATE_LIMIT','429':'RATE_LIMIT',
 'authentication_failed':'AUTH_FAILURE','authentication_error':'AUTH_FAILURE','auth_failure':'AUTH_FAILURE','authorization_failed':'AUTH_FAILURE','401':'AUTH_FAILURE','403':'AUTH_FAILURE',
 'billing_error':'BILLING_FAILURE','account_on_hold':'BILLING_FAILURE','oauth_org_not_allowed':'AUTH_FAILURE','max_output_tokens':'OUTPUT_LIMIT','unknown':'UNCLASSIFIED','billing_failure':'BILLING_FAILURE',
 'invalid_request':'INVALID_REQUEST','400':'INVALID_REQUEST','model_not_found':'MODEL_NOT_FOUND','404':'MODEL_NOT_FOUND',
 'timeout':'TIMEOUT','request_timeout':'TIMEOUT','408':'TIMEOUT','504':'TIMEOUT',
 'server_error':'TRANSIENT_SERVER_ERROR','server_failure':'TRANSIENT_SERVER_ERROR','overloaded':'TRANSIENT_SERVER_ERROR','500':'TRANSIENT_SERVER_ERROR','502':'TRANSIENT_SERVER_ERROR','503':'TRANSIENT_SERVER_ERROR'}
@dataclass(frozen=True)
class ProviderEvent:
 event_type:str; failure_code:str|None=None; failure_type:str|None=None; model:str|None=None; effort:str|None=None
 input_tokens:int|None=None; output_tokens:int|None=None; cache_read_tokens:int|None=None; cache_creation_tokens:int|None=None
 latency_ms:float|None=None; cost_usd:float|None=None; cost_basis:str|None=None

def _norm_code(v):
 if v is None:return None
 if isinstance(v,(int,float)) and float(v).is_integer(): v=str(int(v))
 return str(v).strip().lower()
def _structured_error(data):
 if not isinstance(data,dict): return None,None,None
 candidates=[]
 for key in ('provider_error','error','provider_failure'):
  if key in data: candidates.append(data[key])
 code=data.get('provider_error_code') or data.get('error_code') or data.get('status_code') or data.get('status')
 typ=data.get('provider_error_type') or data.get('error_type') or data.get('type') or data.get('name')
 for err in candidates:
  if isinstance(err,dict):
   code=err.get('code') or err.get('status_code') or err.get('status') or code
   typ=err.get('type') or err.get('name') or typ
   # Some provider envelopes use error.error_type / error.code.
   nested=err.get('error')
   if isinstance(nested,dict):
    code=nested.get('code') or nested.get('status_code') or code
    typ=nested.get('type') or nested.get('name') or typ
  elif isinstance(err,str):
   exact=_norm_code(err)
   if exact in KNOWN_FAILURE_CODES:return exact, _norm_code(typ), KNOWN_FAILURE_CODES[exact]
 code=_norm_code(code); typ=_norm_code(typ)
 if code in KNOWN_FAILURE_CODES:return code,typ,KNOWN_FAILURE_CODES[code]
 if typ in KNOWN_FAILURE_CODES:return typ,typ,KNOWN_FAILURE_CODES[typ]
 return None,typ,None

def _usage(data):
 u=data.get('usage') if isinstance(data.get('usage'),dict) else {}
 return {k:data.get(k,u.get(k,u.get(alias))) for k,alias in {
  'input_tokens':'inputTokens','output_tokens':'outputTokens','cache_read_tokens':'cacheReadInputTokens','cache_creation_tokens':'cacheCreationInputTokens'}.items()}

def normalize(data:dict)->ProviderEvent:
 code,typ,failure=_structured_error(data)
 u=_usage(data)
 cost=data.get('cost_usd',data.get('cost'))
 return ProviderEvent(str(data.get('hook_event_name') or data.get('event') or 'UNKNOWN'),failure,typ,data.get('model'),data.get('effort'),u['input_tokens'],u['output_tokens'],u['cache_read_tokens'],u['cache_creation_tokens'],data.get('latency_ms'),cost,data.get('cost_basis'))
