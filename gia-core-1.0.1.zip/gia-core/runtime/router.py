"""Guard adapter over the gcgo router (skills/gcgo-router): one registry, one set of playbooks.

The guard executes and logs a route for every task prompt. Classification is the gcgo keyword classifier
applied to the request after two protections ported from the earlier GCAE router:
  * a negated instruction ("Do not investigate ...") is not a request;
  * quoted or instructional evidence ("the text says: fraud ...") cannot create or escalate a route, and a
    communication-only task (rewrite, proofread, translate) is exclusive and always risk L0.
Dependency closure covers this plugin only: a missing gia-core skill is an INVALID control plane (guard STOP).
Skills of the other plugins are recorded as unverified when they are not found beside this plugin, never a stop.
The router proposes; it never authorizes execution.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
import importlib.util
import json
import re


@dataclass
class Route:
    task_id: str
    intent: str
    task_class: str
    risk_tier: str
    selected_capabilities: list = field(default_factory=list)
    selected_agents: list = field(default_factory=list)
    selected_references: list = field(default_factory=list)
    dependency_closure_status: str = "INCOMPLETE"
    missing_dependencies: list = field(default_factory=list)
    authorized_scope: str = ""
    reason_codes: list = field(default_factory=list)
    state_trace: list = field(default_factory=list)
    escalation: str = "none"
    workstreams: list = field(default_factory=list)


def _terms(text, terms):
    return any(re.search(r"(?<!\w)" + re.escape(t) + r"(?!\w)", text, re.I) for t in terms)


def _leading_communication(low):
    return bool(re.match(r"^\s*(please\s+)?(rewrite|rephrase|proofread|polish|edit|improve|draft|write|compose|translate|shorten|humani[sz]e)\b", low))


def _strip_negations(low):
    return re.sub(r"\b(do not|don't|dont|without|never|avoid|must not|should not|shall not|no need to|not to)\b[^.;\n]*", " ", low)


def _quarantine(low):
    return bool(re.search(r"\b(quoted|quote|contains the words|background only|mentioned only|as background|verbatim)\b", low)
                or re.search(r'"[^"]*(fraud|investigat|audit|nominee|regulat|risk)[^"]*"', low))


def _strip_quotes(text):
    return re.sub(r'"[^"\n]*"|“[^”\n]*”', " ", text)


class Router:
    def __init__(self, root):
        self.root = Path(root)
        sk = self.root / "skills" / "gcgo-router"
        spec = importlib.util.spec_from_file_location("gcgo_route_rt", str(sk / "scripts" / "gcgo_route.py"))
        self.g = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.g)
        self.reg = json.loads((sk / "data" / "capability-registry.json").read_text(encoding="utf-8"))

    def _closure(self, skills):
        own = [s for s in skills if s.startswith("gia-core:")]
        missing = ["FILE:" + s for s in own if not (self.root / "skills" / s.split(":", 1)[1] / "SKILL.md").exists()]
        external = [s for s in skills if s.startswith("gia-") and not s.startswith("gia-core:")]
        return missing, external

    def _skills(self, intents, entities, juris):
        pol = self.reg["policy"]
        primary, support, _ = self.g.resolve_entity_skills(entities, juris, self.reg)
        out = []
        for i in intents:
            for st in self.reg["playbooks"][i["playbook"]]["steps"]:
                s = st["skill"]
                if s == "{engine}":
                    cand = [pol["default_methodology_engine"]]
                elif s in ("{entity_skills}", "{juris_hr_skills}"):
                    cand = primary
                else:
                    cand = [s]
                for c in cand:
                    if c.startswith("gia-") and c not in out:
                        out.append(c)
        return out

    def _risk(self, intent, flags, text):
        if intent == "communication":
            return "L0"
        if set(flags) & {"confidential_investigation", "rating_or_conclusion", "external_distribution"} or \
                _terms(text, ["production acceptance", "chairman", "board assurance", "nominee account", "nominee", "fraud", "forensic", "material exposure"]):
            return "L4"
        if intent in ("investigation", "regulatory_change", "external_submission"):
            return "L3"
        if intent in ("fieldwork", "icfr_racm", "data_analytics", "findings_report", "payroll_hr", "it_cyber", "vendor_check", "contradiction"):
            return "L2"
        return "L1"

    def classify(self, request, task_id="TASK-UNSET", authorized_scope=None):
        raw = request if isinstance(request, str) else str(request)
        low = _strip_negations(raw.lower())
        if _leading_communication(low):
            second = bool(re.search(r"\b(and|then|also|plus)\b.*\b(investigate|audit|assess|analyse|analyze|reconcile|test|verify|research|determine|forensic)\b", low))
            if _quarantine(raw.lower()) or not second:
                r = Route(task_id, "communication", "communication", "L0", ["gia-report-qa:gia-ia-report"], [], [], "INCOMPLETE", [],
                          authorized_scope or raw, ["COMMUNICATION_ONLY"], ["classified"])
                self._finish(r, [])
                return r
        text = _strip_quotes(_strip_negations(raw))
        intents, _scored, entities, juris, flags, multi, parallel, _unk, _rq = self.g.classify(text, self.reg)
        if not intents:
            r = Route(task_id, "analysis", "none", self._risk("analysis", flags, text.lower()), ["gia-core:gcgo-router"], [], [], "INCOMPLETE", [],
                      authorized_scope or raw, ["NO_INTENT_RECOGNISED"], ["classified"])
            self._finish(r, ["gia-core:gcgo-router"])
            return r
        # Safety precedence: a confidential investigation outranks other intents for the primary route and its risk tier.
        intents = sorted(intents, key=lambda i: 0 if i["intent"] == "investigation" else 1)
        primary = intents[0]["intent"]
        skills = self._skills(intents, entities, juris)
        r = Route(task_id, primary, "+".join(i["playbook"] for i in intents), self._risk(primary, flags, text.lower()), skills, [], [], "INCOMPLETE", [],
                  authorized_scope or raw, ["INTENT:" + i["intent"] for i in intents], ["classified"])
        if multi:
            r.reason_codes.append("CONDUCTOR:gia-core:project-memory")
        elif parallel or len(intents) >= 3:
            r.selected_agents = ["gia-core:alpha-scout", "gia-core:beta-analyst", "gia-core:delta-validator", "gia-core:portfolio-qa-challenger"]
            r.reason_codes.append("CONDUCTOR:gia-core-agents")
        if any(st.get("gate") for i in intents for st in self.reg["playbooks"][i["playbook"]]["steps"]):
            r.escalation = "human_gate"
        self._finish(r, skills)
        return r

    def _finish(self, r, skills):
        missing, external = self._closure(skills + ["gia-core:gcgo-router"])
        r.missing_dependencies = missing
        if external:
            r.reason_codes.append("OTHER_PLUGINS_UNVERIFIED")
        r.dependency_closure_status = "COMPLETE" if not missing else "INVALID"
        r.state_trace.append(r.dependency_closure_status)
