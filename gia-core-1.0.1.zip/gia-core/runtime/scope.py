"""Tool-class authority (token based). Classification is informational except DESTRUCTIVE, which requires explicit human approval.
v14.5.0: substring matching and an UNKNOWN->stop default caused 40% false stops on ordinary Claude Code tools (Skill, TodoWrite, Bash...).
Unknown tools are now allowed and logged; only destructive tool names require approval."""
import re
DESTRUCTIVE={"delete","remove","destroy","drop","reset","overwrite","truncate","wipe","purge","trash","unlink","rmdir"}
READ={"read","glob","grep","search","fetch","list","get","view","web","notebookread"}
WRITE={"edit","write","create","patch","save","append","mkdir","update","insert","batch","todo"}
EXEC={"bash","shell","python","terminal","command","exec","powershell"}
AGENT_NAMES={"task","agent","spawn_agent"}
def tokens(name): return [t.lower() for t in re.findall(r"[A-Z]?[a-z]+|[A-Z]+(?![a-z])|\d+", str(name or ""))]
def tool_class(name):
    n=str(name or "").lower()
    if n in AGENT_NAMES or n.endswith(("__task","__agent")): return "AGENT"
    t=set(tokens(name))
    if t & DESTRUCTIVE: return "DESTRUCTIVE"
    if t & EXEC: return "EXEC"
    if t & WRITE: return "WRITE"
    if t & READ: return "READ"
    return "UNKNOWN"
