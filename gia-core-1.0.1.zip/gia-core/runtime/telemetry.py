"""Provider-neutral telemetry. Unknown values remain unknown; no fabrication."""
from dataclasses import dataclass,asdict
@dataclass
class Usage:
    run_id:str; model:str|None=None; effort:str|None=None; input_tokens:int|None=None; output_tokens:int|None=None; cache_read_tokens:int|None=None; cache_creation_tokens:int|None=None; latency_ms:float|None=None; cost_usd:float|None=None; cost_basis:str="not_available"; tool_count:int=0; agent_count:int=0
    def valid(self):
        nums=[self.input_tokens,self.output_tokens,self.cache_read_tokens,self.cache_creation_tokens,self.latency_ms,self.cost_usd,self.tool_count,self.agent_count]
        return all(x is None or (isinstance(x,(int,float)) and x>=0) for x in nums) and self.cost_basis in {"provider_reported","provider_rate_card","not_available","not_applicable"}
    def as_dict(self): return asdict(self)
