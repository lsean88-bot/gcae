#!/usr/bin/env python3
"""unverified_claims_census.py - census of EXISTING supersession, merge or retirement claims that lack a verification note.

Complements hooks/retirement_gate.py, which only stops NEW unverified claims from being written. This monitor surfaces the ones
that already exist, on startup and then as they appear or resolve. It is a heuristic text census, not proof that a claim is false.

  python3 -I unverified_claims_census.py [--roots DIR ...] [--once] [--interval SECONDS]

Roots: --roots, else $GIA_SKILL_ROOTS (path-separator list), else the folder holding the sibling plugins of this one.
With the default root only plugins whose folder name starts with "gia-" are in scope, so unrelated marketplace plugins whose text
says "merged into" for other reasons do not add noise. Explicit roots are scanned in full.
--once prints the census and exits (exit 1 when any claim is found); otherwise the monitor loops.
"""
import argparse
import os
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "skills" / "skill-hygiene" / "scripts"))
from claim_patterns import CLAIM_PATTERN, has_unverified_claim  # noqa: E402

SKIP = {"node_modules", "__pycache__", "tests", "fixtures"}


def default_roots():
    env = os.environ.get("GIA_SKILL_ROOTS")
    if env:
        return [r for r in env.split(os.pathsep) if r], False
    return [str(HERE.parent.parent)], True


def scan(roots, gia_only):
    """Return {skill_md_path: first offending line}."""
    out = {}
    for root in roots:
        rp = Path(root)
        if not rp.is_dir():
            continue
        for sm in rp.rglob("SKILL.md"):
            rel = sm.relative_to(rp).parts
            if SKIP & set(rel):
                continue
            if gia_only and not rel[0].startswith("gia-"):
                continue
            try:
                text = sm.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            if has_unverified_claim(text):
                for line in text.splitlines():
                    if CLAIM_PATTERN.search(line):
                        out[str(sm)] = line.strip()[:200]
                        break
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--roots", nargs="+")
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--interval", type=int, default=int(os.environ.get("CENSUS_INTERVAL_SECONDS", "1800")))
    a = ap.parse_args()
    if a.roots:
        roots, gia_only = a.roots, False
    else:
        roots, gia_only = default_roots()
    known = None
    while True:
        cur = scan(roots, gia_only)
        if known is None:
            if cur:
                print("[unverified-claims-census] %d skill(s) with an unverified supersession claim:" % len(cur))
                for p, line in sorted(cur.items()):
                    print('[unverified-claims-census]   %s: "%s"' % (p, line))
            else:
                print("[unverified-claims-census] No unverified supersession claims found.")
        else:
            for p in sorted(set(cur) - set(known)):
                print('[unverified-claims-census] NEW unverified claim: %s: "%s"' % (p, cur[p]))
            for p in sorted(set(known) - set(cur)):
                print("[unverified-claims-census] RESOLVED: %s" % p)
        known = cur
        if a.once:
            return 1 if cur else 0
        sys.stdout.flush()
        time.sleep(a.interval)


if __name__ == "__main__":
    sys.exit(main())
