#!/usr/bin/env python3
"""portfolio_drift_scan.py - find a skill installed in more than one place and watch the copies for content drift.

  python3 -I portfolio_drift_scan.py [--roots DIR ...] [--once] [--interval SECONDS] [--rescan-every N]

A skill is identified by its folder name. Any folder name that holds a SKILL.md at more than one path is a group to watch; every
copy is compared with the first by SHA-256. No hand-kept list is needed, so groups that appear later are found on the next rescan.
Roots: --roots, else $GIA_SKILL_ROOTS (path-separator list), else the folder holding the sibling plugins of this one plus ~/.claude/skills.
--once prints the groups and their state and exits (exit 1 when any group has drifted); otherwise the monitor loops.
Detective only: it never changes a file and never decides which copy is right.
"""
import argparse
import hashlib
import os
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
SKIP = {"node_modules", "__pycache__", "tests", "fixtures"}


def default_roots():
    env = os.environ.get("GIA_SKILL_ROOTS")
    if env:
        return [r for r in env.split(os.pathsep) if r]
    return [str(HERE.parent.parent), str(Path.home() / ".claude" / "skills")]


def discover(roots):
    found = {}
    for root in roots:
        rp = Path(root)
        if not rp.is_dir():
            continue
        for sm in rp.rglob("SKILL.md"):
            if SKIP & set(sm.relative_to(rp).parts):
                continue
            found.setdefault(sm.parent.name.split(":")[-1], []).append(str(sm))
    return {k: sorted(set(v)) for k, v in found.items() if len(set(v)) > 1}


def digest(path):
    try:
        return hashlib.sha256(Path(path).read_bytes()).hexdigest()
    except OSError:
        return ""


def states(groups):
    out = {}
    for name, paths in groups.items():
        ref = digest(paths[0])
        for other in paths[1:]:
            out[(name, paths[0], other)] = "aligned" if ref and ref == digest(other) else "drifted"
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--roots", nargs="+")
    ap.add_argument("--once", action="store_true")
    ap.add_argument("--interval", type=int, default=int(os.environ.get("DRIFT_CHECK_INTERVAL_SECONDS", "300")))
    ap.add_argument("--rescan-every", type=int, default=10)
    a = ap.parse_args()
    roots = a.roots or default_roots()
    groups, last, cycle = {}, {}, 0
    while True:
        if cycle % a.rescan_every == 0:
            new = discover(roots)
            for n in sorted(set(new) - set(groups)):
                print("[portfolio-drift-scan] multiple copies of '%s': %s" % (n, ", ".join(new[n])))
            for n in sorted(set(groups) - set(new)):
                print("[portfolio-drift-scan] '%s' no longer has multiple copies" % n)
            groups = new
        cur = states(groups)
        for key, st in cur.items():
            if st != last.get(key, "unknown"):
                name, ref, other = key
                if st == "drifted":
                    print("[portfolio-drift-scan] DRIFT (%s): '%s' and '%s' differ" % (name, ref, other))
                elif last.get(key) == "drifted":
                    print("[portfolio-drift-scan] RESOLVED (%s): '%s' and '%s' match again" % (name, ref, other))
                elif a.once:
                    print("[portfolio-drift-scan] aligned (%s): '%s' and '%s'" % (name, ref, other))
        last = cur
        if a.once:
            if not groups:
                print("[portfolio-drift-scan] no skill is installed in more than one place")
            return 1 if "drifted" in cur.values() else 0
        cycle += 1
        sys.stdout.flush()
        time.sleep(a.interval)


if __name__ == "__main__":
    sys.exit(main())
