# Migration to gia-core 1.0.1

Old item to new location. PORTED means the unique strength now exists in the destination; the build ran its tests (see `tests/RESULTS.md`). Items owned by another suite are listed so nothing is orphaned; that suite's MIGRATION.md records the port.

Contents: Skills - Agents - Commands - Hooks and monitors - Dropped on purpose - Open items

## Skills

| Old | Disposition | New location and strength |
|---|---|---|
| iron-rules-governance (canonical) | PORTED | `gia-core:iron-rules`: rules as `rules.json`, rendered `references/rules.md`, 12-item gate, R1-R5 with strict R3, Model and Effort Routing, drift script `check-governance-drift.sh`, new `render_rules.py` and `test_rules.py`; history moved to `references/history-*.md` |
| iron-rules-governance-old (25-rule copy) | RETIRED | no unique content; same name as the canonical skill |
| charlie-hills-code | PORTED | Plan, Verify, Execute, Check, Log defined once in `iron-rules/references/charlie-hills.md`; coding habits in `self-learning/references/coding-workflow.md`; CLAUDE.md edits now need the CAE go-ahead |
| ai-cae-orchestrator (human gates only) | PORTED | `iron-rules/references/human-gates.md` (report issuance, AC or Board escalation, fraud notification); the rest retired |
| gcgo-orchestrator | PORTED | `gia-core:gcgo-router`: registry, `gcgo_route.py` with route, list-intents, explain, graph and selftest; registry now built from `registry-source.json` by `build_registry.py`; new Rule 31 and 32 team and model brief step |
| gia-fleet-roster, fleet-orchestrator | PORTED | `gcgo-router/references/fleet-and-roster.md`; the eleven agents live in `agents/` |
| cae-master-router | PORTED | "say so when more than one layer applies" rule in `gcgo-router` SKILL.md; router otherwise redirected |
| ai-cae-orchestrator, akos routing table (Module 13) | RETIRED | second routers; one router remains |
| gcae 14.5 (master, restart, scope, status, plugin-admin) | PORTED | `gia-core:runtime-guard`: `hooks/gia_guard.py`, `hooks/run_guard.sh`, `hooks/hooks.json` (14 events), `core/`, `runtime/`, `scripts/grade_uat.py`, `collect_evidence.sh`, `build_hashes.py`, `token_budget.py`; commands `status`, `restart`, `scope`; IR-01 to IR-15 renamed GR-01 to GR-15 |
| gcae-assurance 12.1.1 hooks and lint | PORTED | `hooks/gr_controls.py` (GR-16 evidence immutability, GR-17 PII and exfiltration gate, GR-18 fraud-wording lint, GR-19 self-protection, injection notices); `gia-core:safeguard-lint` carries the lint with canonical-rule codes |
| gcae v13 quarantine, root gcae copy | RETIRED | superseded duplicates |
| communication, research, risk (GCAE stubs) | other suite | communication-only exclusivity is kept in `runtime/router.py` (always risk L0); research and risk go to gia-audit and gia-report-qa |
| akos-enterprise-orchestrator-2, akos plugin skill | PORTED | `gia-core:project-memory` (registers, session start, intake, improvement boundary, file handling, gaps: `references/protocols.md`); Module 7 promotion rules into `self-learning`; Module 13 routing and Module 17 session diary dropped |
| epm-knowledge-graph | PORTED | `project-memory/scripts/kg_tools.py` (sentinel import removed), `references/kg-schema.md`, `node-relationship-catalogue.md` |
| akos-graphify-bridge | PORTED | `project-memory/scripts/` (brain, graph, audit, doctor, interop), `config/entities.json`, `references/library-brain.md`, `mapping-spec.md`, `graphify-environment.md`; the 12 akos-graph slash commands are not carried, the CLI is documented in the skill |
| self-learning-loop | PORTED | `gia-core:self-learning`: `log_lesson.py` (store moved outside the plugin, init, check, candidates, promote with go-ahead), seed lessons, worked example |
| akos Module 7 Kaizen, Module 16 lexicon | PORTED | `self-learning/references/kaizen-and-lessons.md`, `constructive-communication-lexicon.md` |
| skill-factory | PORTED | `gia-core:skill-hygiene`: `run_preflight.py` now calls the bundled `skill_lint.py` (no external validator needed) |
| skill-sprawl-watch | PORTED | `skill-hygiene/scripts/scan_overlap.py` (two scores), baseline in `references/scan-baseline.md` |
| cae-data-guardian, cae-command-centre, cae-rag, file-catalog, grc-function, cae-cowork-ai-plugin, group-cae family, cae-persona | other suite | S2 to S5; see their MIGRATION.md |

## Agents

| Old | New |
|---|---|
| portfolio-qa-challenger | PORTED: `agents/portfolio-qa-challenger.md`, Read/Grep/Glob only, sonnet, effort high; incident names removed |
| the eleven fleet agents (alpha-scout to zeta-remediator) | PORTED: `agents/`, each pinned `model: sonnet` with an effort note from the Rule 32 matrix; delta-validator, iota-kaizen and lambda-cyber stay read-only; dangling reference to a missing dependency map replaced by the router registry |
| akos plugin agents (14, `model: inherit`) | merged into the roles above; `inherit` is forbidden by the matrix |

## Commands

`/gcgo`, `/gcgo-status`, `/gcgo-health`, `/gcgo-selftest`, `/gcgo-brief`, `/gia-lesson`, `/akos-init`, `/akos-status` PORTED to `commands/` with new skill names. `/gcae-status`, `/gcae-restart`, `/gcae-scope` PORTED as `/gia-core:status`, `restart`, `scope`. `gia-route`: retired, folded into `/gcgo`.

## Hooks and monitors

Guard hooks: PORTED (`hooks/hooks.json`). Retirement gate: PORTED to `hooks/retirement-gate.sh` and `retirement_gate.py`, now sharing patterns with the census through `skill-hygiene/scripts/claim_patterns.py`. Monitors `portfolio-drift-scan` and `unverified-claims-census`: PORTED to `monitors/`, rewritten for the gia plugin layout with a `--once` mode.

## Dropped on purpose

The Fable orchestrator and `mktron-sentinel` references, personal names and case facts in method files, the 27, 14 and 10 item gate variants, "sequence, do not parallelise" and "do the specialist work yourself" (conflict with Rules 31 and 32), the 13-section report as canonical (amended 29-Oct-2026; legacy conversion reference only).

## Open items

- Production acceptance: live UAT stages T0 to T16 have not run in a Claude Code session.
- The brain's graph indexing needs the external `graphify` package; its tests are skipped here.
- Entity codes: router codes (NEPHRO, MKAPL, MKPC, ERAWAN, MKSDL, MKTRON) versus the older graph codes. MKSDL versus MKSLD spelling needs the CAE's confirmation.
- ASSUMED thresholds (tool limits 60, 40, 200; repeat cap 12; restart cap 3; reference budgets 8 and 16) need the CAE's approval.
- Standard of proof for corroborated and substantiated: a Legal or Group decision.
- No Windows launcher for the hooks beyond `py -3` detection.

## Port check additions (1.0.1)

| Source | Status |
|---|---|
| cae-data-guardian, cae-command-centre, group-cae-second-brain, gia-file-catalog (both copies), cae-rag-document-intelligence | PORTED: `skills/project-memory/references/source-intake-and-data-discipline.md`. Scripts `catalog_engine.py` and `completeness_report.py` are NOT ported (method only); rebuild only if the CAE asks |
| mktron-grc-function, mac-audit-constitution-l99 (retired stub) | Charter and QAIP routing already in `gcgo-router/references/playbooks.md`; stub carries no content |

## Port disposition (1.0.1, closes the PARTIAL port-check rows)

Every distinctive element of the eight PARTIAL sources is recorded. Paths are under `gia-core/skills/`.

| Source | Element | Disposition |
|---|---|---|
| cae-persona (composed-layers, hybrid), group-cae, group-cae-core | Role identity, reporting lines | PORTED→gcgo-router/references/cae-role-and-style.md (section 1) |
| same | Professional capabilities table | PORTED→cae-role-and-style.md (section 2); fraud discipline row routes to gia-fraud |
| same | Core persona and leadership style | PORTED→cae-role-and-style.md (section 3), including the fair-treatment line for subjects of an inquiry |
| same | Thinking and response protocol; workflow | PORTED→cae-role-and-style.md (section 4); overlaps Rules on evidence and uncertainty, kept as working style |
| same | Frameworks applied | PORTED→cae-role-and-style.md (section 5); currency check stays in gia-audit:gias-navigator |
| same | SMART standard | PORTED→cae-role-and-style.md (section 6) |
| same | Communication by audience | PORTED→cae-role-and-style.md (section 7) |
| same | Tone guardrails; core principles | PORTED→cae-role-and-style.md (sections 9, 10) |
| same | Output formats table | PORTED→cae-role-and-style.md (section 8), without the 13-section row |
| same | 13-section standard report structure | DROPPED (superseded by the report format policy in gia-core:iron-rules (standard concise IA report; legacy reference at gia-report-qa:gia-ia-report/references/legacy-13-section-conversion.md)) |
| same | Risk rating matrix with remediation day counts | DROPPED (rating scale held in gia-report-qa:gia-ia-report glossary and rating-scale tab; the day counts are unsourced and are set per engagement) |
| same | Reference-file table (exec-brief, risk-register, iia-standards, control-matrix) | DROPPED (files not in the sources; covered by gia-report-qa:gia-board-brief, gia-audit:gia-engagement-planning, gias-navigator, gia-racm-icfr-testing) |
| same | Fraud Investigation discipline, Investigation Report format (group-cae only) | DROPPED (duplicate of gia-fraud:gia-fraud-investigation) |
| cae-persona (both copies) | Composed-layers architecture note (sibling-layer roles) | DROPPED (meta-layer; one router remains) |
| cae-rag-document-intelligence | Constitutional pre-check; Current design / Recommendation / Gap labels | PORTED→project-memory/references/source-intake-and-data-discipline.md (section 7) |
| same | Library record format, four answer labels, citation, query types | PORTED→project-memory/references/document-grounded-rules.md (sections 1 to 3) |
| same | RAG-01 to RAG-05, RAG-06 to RAG-09 | PORTED→document-grounded-rules.md (DG-01 to DG-09) |
| same | RAG-10 (validate export JSON before import) | DROPPED (obsolete; the dashboard and its JSON hand-off are retired) |
| same | Response protocol (7 steps) | PORTED→document-grounded-rules.md (section 5) |
| same | RCM builder, work program builder | DROPPED (duplicate of gia-audit:gia-racm-icfr-testing/references/racm-standard.md and gia-fieldwork-workpapers/references/test-programs-T001-T015.md) |
| same | SOX and ICFR assessment tracker | DROPPED (duplicate of gia-audit:gia-racm-icfr-testing/references/coso-sox-testing.md and coso-ic-map.md) |
| same | Policy gap, minutes analyser, evidence mapper record formats | PORTED→gia-audit:gia-fieldwork-workpapers/references/document-grounded-outputs.md |
| same | Integration hub, configuration tab, dashboard launch, companion tools, constitutional article references | DROPPED (obsolete or meta-layer: retired HTML app; articles superseded by gia-core:iron-rules) |
| gia-file-catalog, gia-file-catalog-2 | Scope-first rule, alert types, no guessed owner, no move or delete | PORTED→source-intake-and-data-discipline.md (section 8) |
| same | Workstream, document type, status, priority tables; engagement ID and catalog row conventions | PORTED→project-memory/references/file-catalog-taxonomy.md |
| same | Entity code table | DROPPED (duplicate of project-memory/config/entities.json and the router registry) |
| same | `catalog_engine.py`, `completeness_report.py` | DROPPED (scripts not shipped: keyword dictionaries tied to retired entity codes and no tests; method is preserved, rebuild only if the CAE asks) |
| same | Deployment guide (chat, Claude Code, Cowork surfaces, plugin wrapper) | DROPPED (obsolete; replaced by this plugin's install; surface limits kept in section 8) |
| same | Executive summary framing and message-draft tool | DROPPED (superseded by gia-report-qa:gia-board-brief) |
| cae-cowork-ai-plugin | Activation and routing (Part A) | DROPPED (superseded by gcgo-router; one router) |
| same | Charlie Hills protocol (Part B) | PORTED→iron-rules/references/charlie-hills.md |
| same | 20 iron rules; 10-item gate; report conversion constraints A to F | DROPPED (superseded by the canonical rule set and 12-item gate; conversion constraints live in gia-report-qa:gia-ia-report/references/legacy-13-section-conversion.md) |
| same | Finding classification tree; CD, SD, MW aggregation; findings pipeline | PORTED→gia-audit:gia-audit-lifecycle/references/lifecycle-evidence-chain.md; gia-racm-icfr-testing/references/deficiency-aggregation.md |
| same | Evidence hierarchy R1 to R5, document register, PBC gaps | PORTED→iron-rules; gia-fieldwork-workpapers/references/pbc-presets.md |
| same | Test programs, reconciliation tests R1 to R12 | PORTED→gia-fieldwork-workpapers/references/test-programs-T001-T015.md, reconciliation-tests.md |
| same | Management response and follow-up trackers (GIAS 14.4, 15.2) | PORTED→gia-audit:gia-audit-lifecycle/references/follow-up-std15.md |
| same | Error pattern library E1 to E12 | PORTED→self-learning/references/kaizen-and-lessons.md (starter library) |
| same | Session debrief A to G | PORTED→self-learning/references/kaizen-and-lessons.md (Session debrief section) |
| same | Version control panel | PORTED→gia-audit:gia-racm-icfr-testing/references/version-control.md |
| same | Panel architecture (15 tabs), send and API functions, in-app AI analysis, dynamic system prompt generator, cowork prompts and scheduled-task list | DROPPED (obsolete: retired app; tab map kept at gia-audit:gia-fieldwork-workpapers/references/workbench-apps.md; scheduling is done by monitors) |
| same | 14-section report structure | DROPPED (superseded by the report format policy in gia-core:iron-rules) |
| same | Jurisdiction quick reference (Part G), regulatory matrix | DROPPED (duplicate of the three statutory registers; embedded rates were stale) |
| same | 30-item conversion QA (Part E) | PORTED→gia-report-qa:gia-ia-report/references/legacy-13-section-conversion.md |
| same | Version history (Part H) | DROPPED (history only) |
