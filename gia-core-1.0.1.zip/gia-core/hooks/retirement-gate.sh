#!/bin/bash
# retirement-gate.sh - PreToolUse hook (Write|Edit|MultiEdit) of gia-core:skill-hygiene.
# Denies an edit to a SKILL.md that asserts a supersession, merge or retirement claim with no "Verification method:" note.
# A heuristic text gate that raises the bar; it does not know whether a claim is true. Run the portfolio-qa-challenger agent for that.
# Deliberately fail-open on unreadable input: this is a content check, not a safety control (the safety controls are in gia_guard.py).
set -u
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PY="$(command -v python3 || command -v python || true)"
[ -n "$PY" ] || exit 0
exec "$PY" -I "$SCRIPT_DIR/retirement_gate.py"
