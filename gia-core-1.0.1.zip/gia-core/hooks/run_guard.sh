#!/usr/bin/env bash
# Portable launcher (Windows Git Bash / macOS / Linux). Fail-closed if no usable Python.
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for PY in python3 python "py -3"; do
  if command -v "${PY%% *}" >/dev/null 2>&1; then
    if ${PY} -c "import sys; sys.exit(0 if sys.version_info>=(3,8) else 1)" >/dev/null 2>&1; then
      exec ${PY} "$HERE/gia_guard.py" "$@"
    fi
  fi
done
echo "GIA guard cannot run: Python >= 3.8 not found. Failing closed." >&2
exit 2
