#!/usr/bin/env python3
"""
retirement_gate.py — the actual gating logic for retirement-gate.sh.

Reads the hook's JSON payload on stdin, decides whether to block, and either:
  - exits 0 (allow), printing nothing, or
  - exits 2 (block) after printing a hookSpecificOutput JSON object explaining why.

Kept as a separate, directly-testable module rather than inline in the bash script so
this logic can actually be unit-tested (see the bottom of this file / the plugin's
test notes) instead of only syntax-checked.
"""
import json
import os
import re
import sys

# Shared claim and evidence patterns live in the skill-hygiene scripts (one definition for this hook and the census monitor).
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "skills", "skill-hygiene", "scripts"))

from claim_patterns import CLAIM_PATTERN, EVIDENCE_PATTERN  # noqa: E402


def extract_content(tool_input: dict) -> str:
    """Try the plausible field names for new content across Write / Edit / MultiEdit."""
    for key in ("content", "new_string", "new_text"):
        if key in tool_input and isinstance(tool_input[key], str):
            return tool_input[key]
    edits = tool_input.get("edits")
    if isinstance(edits, list):
        parts = [e.get("new_string", "") for e in edits if isinstance(e, dict)]
        return "\n".join(p for p in parts if p)
    return ""


def main() -> int:
    raw = sys.stdin.read()
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        # Malformed input isn't this hook's problem to solve -- fail open.
        return 0

    tool_input = payload.get("tool_input", {}) or {}
    file_path = tool_input.get("file_path", "") or ""

    if not file_path.endswith("SKILL.md"):
        return 0

    content = extract_content(tool_input)
    if not content:
        # Couldn't find the new-content field under any known name -- fail open rather
        # than block on a parsing gap, but this is worth investigating if it recurs.
        return 0

    if not CLAIM_PATTERN.search(content):
        return 0

    if EVIDENCE_PATTERN.search(content):
        return 0

    reason = (
        f"This edit to {file_path} asserts a supersession/retirement/merge claim but "
        "includes no 'Verification method:' (or equivalent verified-evidence) note. "
        "Run the portfolio-qa-challenger agent (gia-core) against the target file first -- "
        "checking the claim against the destination file's actual content, not against "
        "another document that repeats the claim -- then include what it found before "
        "this edit is allowed. This gate exists because an unverified merge claim once stood unchallenged for weeks "
        "before a review found the merge had never happened."
    )
    print(json.dumps({
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "deny",
            "permissionDecisionReason": reason,
        }
    }))
    return 2


if __name__ == "__main__":
    sys.exit(main())
