---
name: safeguard-lint
description: "Mechanical lint of draft deliverable text against the Iron Rules: conclusive fraud wording, motive wording, personal identifiers, unverified statutory rates, process narration, partial lists, placeholders. Use when about to releasing any report, finding, workpaper narrative or Board paper, or to check wording. Do NOT use for hook enforcement (use gia-core:runtime-guard)."
---

# Safeguard lint

A deterministic text check, not a judge of evidence quality or professional judgement. A clean result means no mechanical violation was found; it never means the report is correct or releasable.

## Run it

```
python3 -I ${CLAUDE_PLUGIN_ROOT}/skills/safeguard-lint/scripts/safeguard_lint.py FILE [--json] [--strict] [--retracted LIST.txt]
python3 -I ${CLAUDE_PLUGIN_ROOT}/skills/safeguard-lint/scripts/safeguard_lint.py --list-codes
```

Use `-` for FILE to read stdin. Exit 0 = no ERROR; exit 1 = at least one ERROR (or any finding with `--strict`); exit 2 = unreadable input. `--retracted` takes a file with one retracted finding title or phrase per line (Rule 04).

## How to act on results

| Level | Action |
|---|---|
| ERROR | Fix before release. Re-run until clean. |
| WARN | A person reviews each one. Resolve it in the text, or record why it stands (for example a quoted policy). |

Fixing rule for fraud wording: restate at the ladder rung the evidence supports (see `gia-core:iron-rules`), never by deleting the hedge to make the lint pass and never by adding a hedge the evidence does not support. Motive is removed, not softened (Rule 25). A PII finding is masked or removed unless the user has explicitly authorised it.

## Where it is used

- `gia-core:runtime-guard` runs it on text written to narrative files (`.md .txt .html` and similar) and on the final reply. In hooks it is WARN-ONLY: findings become notices, nothing is blocked by wording alone.
- `gia-report-qa:gia-report-qa` runs it as a release check and treats ERROR as blocking.
- Run it by hand on any text that will leave the workspace.

## Codes and the rules they support

`references/codes.md` lists every code, its default level and the Iron Rule it supports. The registry is `CODES` in `scripts/safeguard_lint.py`; `gia-core:iron-rules` tests that every code it names exists there.

## Limits

- Pattern based: it can miss a violation phrased in unusual words and can flag a legitimate quotation. Treat both as expected.
- It cannot see tables rendered from spreadsheets, text inside images, or content that is only in an attached workbook.
- Rules about substance (evidence grade, aggregation, SMART recommendations, population tie-outs) are not lintable here; they are checked at the Quality Gate and by independent QA.
- `scripts/injection_flags.py` flags instruction-like text in prompts and retrieved content (used for the guard's injection notice). It flags; it never decides what to do with the content.
