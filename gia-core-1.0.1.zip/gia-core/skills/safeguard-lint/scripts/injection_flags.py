#!/usr/bin/env python3
"""Injection-pattern flags (ported from GCAE v12.1.1 select_context.safeguard_flags).

Flags instruction-like text that tries to waive safeguards, claim authority, dictate a conclusion,
name a culprit, expose a whistleblower or exfiltrate the prompt. Used by gia-core:runtime-guard to
add a factual notice; the text is treated as data and never obeyed (GR-08).
Usage: python3 -I injection_flags.py TEXT_FILE|-   -> prints flag labels, one per line
"""
import re
import sys

INJECTION_PATTERNS=(
 (r'\b(?:ignore|disregard|forget|override|bypass|skip|disable|suspend|waive|drop|turn\s+off|switch\s+off|do\s*n.?t\s+apply|do\s+not\s+apply)\s+(?:\w+\s+){0,3}?(?:safeguards?|instructions?|rules|guardrails?|polic(?:y|ies)|restrictions?|independence|(?:evidence\s+)?hierarchy|integrity\s+checks?|evidence\s+(?:rules|checks?|standards?)|checks)\b','instruction-override-attempt'),
 (r'<\s*/?\s*system\s*>|\[\s*system\s*\]|\bdeveloper\s+mode\b|\b(?:system|developer|admin)\s+(?:message|override|prompt)\s+from\b|\bsystem\s+message\s+from\b|\bsafeguards?\s+(?:are|is|have\s+been)\s+(?:disabled|off|suspended|waived)|\bpretend\s+(?:the\s+)?(?:safeguards?|rules)\b','fake-system-authority'),
 (r'\b(?:instructions?|notes?|text)\s+in\s+the\s+(?:evidence|file|document|attachment)\b.{0,60}\b(?:skip|ignore|follow|disable)|\bdo\s+not\s+log\s+this\b|\bmark\s+all\s+findings\s+as\s+resolved','embedded-instruction-in-evidence'),
 (r'\bconclude\s+(?:that\s+.{0,60}\b)?(?:committed|guilty|fraud|stole|stolen|embezzled|misappropriated)|\bwithout\s+corroboration\b','conclusion-dictation'),
 (r'\b(?:name|say|state|declare|label|write|confirm)\b.{0,60}\b(?:is|as|was)\s+(?:the\s+)?(?:thief|guilty|culprit|fraudster)\b|\bname\s+the\s+(?:person|individual|employee|culprit)\s+responsible\b|\bwe\s+are\s+sure\s+it\s+is\b','named-guilt-dictation'),
 (r'\b(?:reveal|disclose|identify|tell|share)\b.{0,50}\b(?:who\s+(?:made|filed|raised|submitted|reported|sent)|the\s+(?:reporter|whistle-?blower|informant|complainant))\b','whistleblower-identity-disclosure'),
 (r'\b(?:i\s+am|as)\s+(?:the\s+)?(?:group\s+)?(?:chairman|ceo|cfo|cae)\b.{0,40}\b(?:authori[sz]e|approve|override)','authority-claim-in-task'),
 (r'\b(?:reveal|print|show)\s+(?:your\s+)?(?:system\s+prompt|hidden\s+instructions)\b','prompt-exfiltration'),
 (r'\b(?:you\s+are\s+now|act\s+as\s+if)\b.{0,40}\b(?:no\s+rules|unrestricted|without\s+restrictions)','persona-override'),
)
def safeguard_flags(raw):
    return [lab for pat,lab in INJECTION_PATTERNS if re.search(pat,raw or '',re.I)]

if __name__ == "__main__":
    t = sys.stdin.read() if len(sys.argv) < 2 or sys.argv[1] == "-" else open(sys.argv[1], encoding="utf-8").read()
    for f in safeguard_flags(t):
        print(f)
