#!/usr/bin/env python3
"""GIA deliverable lint (gia-core:safeguard-lint) - makes selected Iron Rules machine-checkable.

Ported from the GCAE v12.1.1 lint (fraud wording, PII, statutory-rate, Topical Requirement status,
GIAS citation, assertion-as-evidence, placeholders) and extended with canonical-rule patterns
(Rule 06 verbal evidence, Rule 25 motive, Rule 29 process narration, Rule 33 partial lists,
Rule 04 retracted items).

This is a LINT, not full enforcement: it catches common, mechanical violations in a draft
deliverable (markdown/text) before release. It cannot judge evidence quality or professional
judgement. Exit code 1 if any ERROR; WARN items need human review.
Usage: python3 -I safeguard_lint.py FILE [--json] [--strict] [--retracted FILE] [--list-codes]
       (FILE '-' reads stdin; --strict also fails on WARN; exit 2 = unreadable input)
Hook use (gia-core:runtime-guard) is warn-only; the release gate (gia-report-qa:gia-report-qa) treats ERROR as blocking.
"""
import re,sys,json,unicodedata

# Registry of every code this lint can emit: default level, Iron Rules supported. Used by
# gia-core:iron-rules tests to prove that every lint code named in rules.json exists.
CODES={
 'LNT-FRAUD-CONCLUSIVE':{'level':'ERROR','rules':[25,36],'summary':'Conclusive fraud wording without ladder hedging'},
 'LNT-FRAUD-CONCLUSIVE-EVIDENCED':{'level':'WARN','rules':[25],'summary':'Conclusive wording with cited evidence: confirm R1-R3 and rung'},
 'LNT-FRAUD-CONCLUSIVE-QUOTED':{'level':'WARN','rules':[25],'summary':'Conclusive wording that appears to quote a policy'},
 'LNT-THEFT-PASSIVE':{'level':'WARN','rules':[25],'summary':'Theft or misappropriation stated as fact without an actor'},
 'LNT-MOTIVE':{'level':'WARN','rules':[25],'summary':'Motive or intent wording'},
 'LNT-TR-STATUS':{'level':'ERROR','rules':[16],'summary':'Topical Requirement described as mandatory before it is effective'},
 'LNT-STD-CITE':{'level':'ERROR','rules':[16],'summary':'Incorrect GIAS 2024 citation'},
 'LNT-BARE-GIAS':{'level':'WARN','rules':[16],'summary':'Standards cited without a sub-clause'},
 'LNT-ASSERTION':{'level':'WARN','rules':[13],'summary':'Management assertion used as evidence'},
 'LNT-UNVERIFIED-RATE':{'level':'WARN','rules':[2,3],'summary':'Statutory rate or threshold without verification source or date'},
 'LNT-DESIGN-OPERATING':{'level':'WARN','rules':[10],'summary':'Findings without design vs operating label'},
 'LNT-R5-CITED':{'level':'WARN','rules':[6],'summary':'Verbal or R5 material cited as evidence'},
 'LNT-PROCESS-NARRATION':{'level':'WARN','rules':[29],'summary':'Process narration or self-commentary in a deliverable'},
 'LNT-PARTIAL-LIST':{'level':'WARN','rules':[33],'summary':'Excerpt list (top N, largest, oldest) in a report body'},
 'LNT-RETRACTED':{'level':'ERROR','rules':[4],'summary':'Text of a retracted finding appears (needs --retracted list)'},
 'LNT-PII':{'level':'ERROR','rules':[36],'summary':'Personal identifier (NRIC, PAN, Aadhaar, CURP, card number)'},
 'LNT-PII-POSSIBLE':{'level':'WARN','rules':[36],'summary':'Number resembles a personal identifier'},
 'LNT-CONTACT':{'level':'WARN','rules':[36],'summary':'Email address in deliverable'},
 'LNT-PLACEHOLDER':{'level':'WARN','rules':[9,29],'summary':'Unfilled placeholder text'},
}

HEDGE=re.compile(r'\b(alleg\w*|suspect\w*|indicat\w*|potential\w*|possib\w*|(?-i:may)|might|could|if|whether|unless|would|reportedly|claim\w*|not (?:a )?conclusion|no conclusion|no (?:evidence|indication|proof|sign|suggestion)\b|not proven|unproven)\b',re.I)
CONCLUSIVE=re.compile(r'\b(committed fraud|is guilty|are guilty|was guilty|embezzled|embezzling|stole|(?:has|have|had)\s+stolen|stolen\s+by|steals|(?:was|is)\s+stealing|diverted\s+(?:\w+\s+){0,3}(?:funds?|cash|money|proceeds)|fabricated\s+(?:the\s+)?(?:invoices?|records?|documents?|receipts?|signatures?)|(?:signatures?|documents?|invoices?|records?|receipts?|vouchers?)\s+(?:was|were)\s+(?:forged|falsified|fabricated)|defrauded|misappropriated|siphoned|pilfered|forged (?:(?:the|a|an|his|her|their|our) (?:\w+ )?)?(?:signatures?|documents?|records?|invoices?|approvals?|certificates?|receipts?|accounts?|books|entries|quotes?|quotations?|bids?|timesheets?|statements?|contracts?|vouchers?|cheques?|checks?|licen[sc]es?)|falsified (?:the )?(?:records?|accounts?|invoices?|documents?|books|inventory|counts?|figures|numbers|reports?|timesheets?|attendance|stock)|is (?:a|the) (?:thief|fraudster|crook)|proved? (?:the )?fraud|fraud (?:was|has been) (?:committed|proven|established))\b',re.I)
NEG_END=re.compile(r"(?:\bnot|\bnever|n't|\bno\s+one|\bnobody)\s+(?:\w+\s+){0,1}$",re.I)
STRONG_LEAD=re.compile(r"\b(alleg\w*|suspect\w*|reportedly|claim\w*|if|whether|unless)\b",re.I)
PASSIVE_THEFT=re.compile(r"\b(?:stolen|misappropriated)\b",re.I)
QUOTED_POLICY=re.compile(r'\b(?:policy|code of conduct|handbook|procedure|regulation|law|act)\b.{0,40}\b(?:states?|says?|provides?|requires?|prohibits?)\b',re.I)
GENERIC_RULE=re.compile(r'\b(?:employees?|staff|anyone|persons?|those)\s+who\s+(?:steal|stole|embezzle\w*|defraud\w*)\b.{0,40}\bwill\b',re.I)
STAT_WORDS=r'(?:EPF|KWSP|SOCSO|PERKESO|EIS|PCB|HRD ?Corp|ESIC|GST|TDS|IMSS|INFONAVIT|SST|minimum wage|professional tax|withholding|VAT|IVA)'
RATE=re.compile(r'(?:\b\d{1,3}(?:\.\d+)?\s?%|\b(?:RM|INR|Rs\.?|MXN|\$)\s?\d[\d,]*(?:\.\d+)?)')
VERIFIED=re.compile(r'(verified (?:on|against|at)\s+\S+|as (?:at|of) \d|per (?:the )?(?:official|primary)\b|source:\s*[^\n]*(?:\d{4}|gazette|\bact\b|regulation|lhdn|kwsp|epf|socso|official)|not verified|unverified|to be verified|\bgazette\b)',re.I)
TR_NAMES=re.compile(r'\b(Anti-?Corruption|Talent Management)\b',re.I)
TR_CONTEXT=re.compile(r'topical requirement|\bTRs?\b|IIA',re.I)
TR_STATUS_OK=re.compile(r'\b(not (?:yet )?(?:mandatory|effective|issued|compulsory|required)|pending|consultation|to be issued|will become|becomes|once issued)\b',re.I)
ACTORS=r'(?:management|client|auditee|they|the\s+(?:cfo|ceo|coo|cae|controller|manager|director|owner|finance\s+(?:team|head|director)|process\s+owner)|cfo|ceo|controller)'
ASSERT=re.compile(r'\b'+ACTORS+r'\s+(?:confirmed|stated|assured|explained|said|told\s+us|represented|assert\w*)\b',re.I)
CORROB=re.compile(r'corroborat|evidence|document|record|re-?perform|inspect|vouch',re.I)
CONCL=re.compile(r'\b(therefore|so|hence|accordingly|conclude|concluded|no (?:issue|exception|finding)|we accept)\b',re.I)
MOTIVE=re.compile(r"\b(motiv(?:e|ated|ation)\w*|(?:with|had|has|have) (?:the )?intent(?:ion)?\b|intentionally|deliberate(?:ly)?\b(?!\s+(?:designed|configured|built|structured|set|chosen|segregated))|wil+ful(?:ly)?|knowingly|out of greed|\bgreed\b|to (?:personally )?(?:benefit|enrich)\b|to (?:conceal|cover up|hide) (?:the|his|her|their|it)\b)",re.I)
MOTIVE_NEG=re.compile(r"\b(no|not|neither|nor|cannot|can't|never|n't|does not state|is not assessed)\b",re.I)
R5_VERBAL=re.compile(r"\b(verbally|orally|verbal (?:confirmation|assurance|statement|representation)|told us|word of mouth)\b",re.I)
R5_SUPPORT=re.compile(r"\b(evidence|evidenced|support(?:s|ed|ing)?|basis|confirm(?:s|ed|ation)?|establish(?:es|ed)?|demonstrat\w+)\b",re.I)
R5_NEG=re.compile(r"\b(not|never|cannot|no|excluded|exclude|insufficient|without)\b",re.I)
NARRATION=re.compile(r"(\bthis audit (?:found|confirmed|verified|re-?verified)\b|\bindependently (?:confirmed|verified|re-?verified)\b|\b(?:confirmed|verified|checked) (?:a )?(?:second|third|fourth) time\b|\bhere'?s what (?:i|we) (?:fixed|changed|corrected)\b|\b(?:i|we) (?:have )?(?:re-?verified|re-?checked|re-?performed) (?:the|this|all)\b|\bverification (?:process|pass|round)\b|\b(?:previous|earlier|prior) draft (?:stated|said|had)\b|\bchange ?log\b|\bquality gate (?:passed|was run)\b)",re.I)
PARTIAL=re.compile(r"(\b(?:the )?(?:\d+|five|ten|three|twenty) (?:largest|oldest|biggest|highest[- ]value|most significant)\b|\btop[- ](?:\d+|five|ten|three|twenty)\b|\b(?:largest|oldest|biggest) (?:\d+|five|ten|three|twenty)\b|\bselected examples?\b)",re.I)
def luhn(d):
    d=[int(c) for c in d][::-1]; t=sum(d[0::2])+sum(sum(divmod(2*x,10)) for x in d[1::2]); return t%10==0
def valid_date6(s):
    mm,dd=int(s[2:4]),int(s[4:6]); return 1<=mm<=12 and 1<=dd<=31
PLACEHOLDER=re.compile(r'\{\{|<<[^>]*>>|<\s*INSERT[^>]*>|\[(?:TBD|TBC|TODO|INSERT|XXX)[^\]]*\]|\b(?:TBD|TBC)\b|XX/XX/\d{2,4}|lorem ipsum',re.I)

def sentences(t):
    t=re.sub(r'(?<!\n)\n(?!\n)',' ',t)   # single newline is not a sentence break
    return [x for x in re.split(r'(?<=[.!?])\s+|\n\s*\n',t) if x.strip()]

def conclusive_unhedged(s):
    lead=' '.join(s.split()[:5])
    for m in CONCLUSIVE.finditer(s):
        if GENERIC_RULE.search(s): continue
        before=s[max(0,m.start()-70):m.start()]
        before=re.split(r'[:;\u2014]|\bbut\b|\bhowever\b',before)[-1]   # a colon/semicolon/'but' ends the hedge's reach
        if HEDGE.search(before) or STRONG_LEAD.search(lead) or NEG_END.search(s[max(0,m.start()-30):m.start()]): continue
        return True
    return False

DASHES=dict.fromkeys(map(ord,'\u2010\u2011\u2012\u2013\u2014\u2015\u2212\u00ad'),'-')
CONFUSABLE=str.maketrans({'\u043e':'o','\u0430':'a','\u0435':'e','\u0440':'p','\u0441':'c','\u0445':'x','\u0443':'y','\u0456':'i','\u03bf':'o','\u03b1':'a'})
def normalise(t):
    t=unicodedata.normalize('NFKC',t or '').translate(DASHES)
    t=''.join(c for c in t if unicodedata.category(c)!='Cf')
    return t.translate(CONFUSABLE)

def lint(text,retracted=None):
    text=normalise(text)
    out=[]
    def add(level,code,msg,ctx): out.append({'level':level,'code':code,'message':msg,'context':ctx.strip()[:160]})
    paras=[p for p in re.split(r'\n\s*\n',text) if p.strip()]
    sents=sentences(text)
    for i,s in enumerate(sents):
        win=s+' '+(sents[i+1] if i+1<len(sents) else '')
        prev=(sents[i-1]+' ' if i>0 else '')+s
        if CONCLUSIVE.search(s) and conclusive_unhedged(s) and not s.strip().endswith('?'):
            if re.search(r'\bR[123]\b|corroborat|confession|court|judgment|substantiat',s,re.I):
                add('WARN','LNT-FRAUD-CONCLUSIVE-EVIDENCED','Conclusive fraud language with cited evidence: confirm the evidence is corroborated (R1-R3), legal conclusions are for counsel, and the rung is substantiated.',s)
            elif QUOTED_POLICY.search(s):
                add('WARN','LNT-FRAUD-CONCLUSIVE-QUOTED','Conclusive wording appears to quote a policy or rule: confirm it is not describing a person or case.',s)
            else:
                add('ERROR','LNT-FRAUD-CONCLUSIVE','Conclusive fraud language without evidence-ladder hedging. Report at the rung the evidence supports (indicator / suspicion / allegation) unless corroborated evidence is cited.',s)
        if PASSIVE_THEFT.search(s) and not CONCLUSIVE.search(s) and not s.strip().endswith('?') and not HEDGE.search(s):
            add('WARN','LNT-THEFT-PASSIVE','Theft/misappropriation stated as fact without an actor: confirm it is a reported or substantiated incident and cite the source (report, count, police report).',s)
        if re.search(r'\b(?:mandatory|compulsory|required)\b',win,re.I) and TR_NAMES.search(win) and TR_CONTEXT.search(win) and not TR_STATUS_OK.search(win):
            add('ERROR','LNT-TR-STATUS','Anti-Corruption / Talent Management Topical Requirements are not yet effective; do not describe them as mandatory. Verify at theiia.org.',win)
        if (re.search(r'(Standards? 26\s?[–-]\s?30)',s,re.I) or (re.search(r'Standard\s+11\.1',s,re.I) and re.search(r'fraud',s,re.I))) and not re.search(r'\b(earlier|previously|incorrect|wrong|erroneous|do(?:es)? not exist|old|former|corrected|correction)\b',s,re.I):
            add('ERROR','LNT-STD-CITE','Incorrect GIAS 2024 citation. Fraud consideration is in 13.2; engagement documentation is 14.6.',s)
        if re.search(r'\bGIAS\b|Global Internal Audit Standards',s) and not re.search(r'\b1?\d\.\d\b|\bPrinciple \d|\bDomain [IVX]+\b|\bStandard \d',s) and re.search(r'\b(requires?|states?|mandates?|complies?|conforms?|per|under|in line with)\b',s,re.I):
            add('WARN','LNT-BARE-GIAS','Standards cited without a sub-clause. Cite the exact standard (e.g. 14.6).',s)
        if ASSERT.search(prev) and not CORROB.search(prev) and CONCL.search(win):
            add('WARN','LNT-ASSERTION','Management assertion appears to support a conclusion without corroboration (assertion is not evidence).',win)
        if MOTIVE.search(s) and not MOTIVE_NEG.search(s) and not s.strip().endswith('?') and not QUOTED_POLICY.search(s):
            add('WARN','LNT-MOTIVE','Motive or intent wording. A finding describes the pattern of what happened, not why (Rule 25); reports never state motive.',s)
        if (re.search(r'\bR5\b',s) or (R5_VERBAL.search(s) and R5_SUPPORT.search(s))) and not R5_NEG.search(s):
            add('WARN','LNT-R5-CITED','Verbal or R5 material appears to be cited as evidence. R5 is never cited in a finding (Rule 06); obtain R1-R4 evidence.',s)
        if NARRATION.search(s):
            add('WARN','LNT-PROCESS-NARRATION','Process narration or self-commentary in the deliverable. A final report contains only the work product (Rule 29).',s)
        if PARTIAL.search(s):
            add('WARN','LNT-PARTIAL-LIST','Excerpt list (top N / largest / oldest) in the report body. Name the full population (15 or fewer) or summarise it and schedule the complete list in an appendix (Rule 33).',s)
    for p in paras:
        if re.search(STAT_WORDS,p,re.I) and RATE.search(p) and re.search(r'%|\b(rate|ceiling|threshold|limit|cap|minimum|maximum|wage floor)\b',p,re.I) and not VERIFIED.search(p):
            add('WARN','LNT-UNVERIFIED-RATE','Statutory rate/threshold/amount stated without a verification source or date. Verify against the primary authority and record it.',p)
    if re.search(r'^\s*(?:#+\s*)?(?:finding|observation)\b',text,re.I|re.M):
        if not re.search(r'\b(design|operating)\b',text,re.I):
            add('WARN','LNT-DESIGN-OPERATING','Findings present but no Design vs Operating failure label.',text[:80])
    def near(m,words,w=40): return re.search(words,text[max(0,m.start()-w):m.end()+w],re.I)
    VALID_PB=set(range(1,17))|set(range(21,60))|{82}
    for m in re.finditer(r'\b\d{6}[- ]?\d{2}[- ]?\d{4}\b',text):
        d=re.sub(r'\D','',m.group(0))
        if not valid_date6(d): continue
        hy='-' in m.group(0)
        if (hy and int(d[6:8]) in VALID_PB) or near(m,r'NRIC|\bIC\b|identity|MyKad'): add('ERROR','LNT-PII','Possible Malaysian NRIC in deliverable. Remove or mask unless explicitly authorised.',m.group(0)[:4]+'…')
        else: add('WARN','LNT-PII-POSSIBLE','Number pattern resembles a Malaysian NRIC (date prefix); check and mask if it is.',m.group(0)[:4]+'…')
    for m in re.finditer(r'\b[A-Za-z]{5}\d{4}[A-Za-z]\b',text):
        if near(m,r'\bPAN\b|permanent account|tax id|income tax'): add('ERROR','LNT-PII','Possible Indian PAN in deliverable. Remove or mask unless explicitly authorised.',m.group(0)[:4]+'…')
        elif m.group(0).isupper() and not near(m,r'asset|tag|serial|part|sku|item|model|voucher|\bPV\b|invoice|order|ref'): add('WARN','LNT-PII-POSSIBLE','Code resembles an Indian PAN; confirm it is not a taxpayer ID.',m.group(0)[:4]+'…')
    for m in re.finditer(r'\b\d{4}[\s-]?\d{4}[\s-]?\d{4}\b',text):
        if near(m,r'aadhaar|aadhar|\bUID\b|\bUIDAI\b'): add('ERROR','LNT-PII','Possible Aadhaar number in deliverable. Remove or mask unless explicitly authorised.',m.group(0)[:4]+'…')
        elif ' ' in m.group(0) and not re.fullmatch(r'(?:19|20)\d\d \d{4} \d{4}|(?:19|20)\d\d (?:19|20)\d\d (?:19|20)\d\d',m.group(0)): add('WARN','LNT-PII-POSSIBLE','12-digit grouped number; confirm it is not an Aadhaar number.',m.group(0)[:4]+'…')
    for m in re.finditer(r'\b[A-Za-z]{4}\d{6}[HMhm][A-Za-z]{5}[A-Za-z0-9]\d\b',text):
        add('ERROR','LNT-PII','Possible Mexican CURP in deliverable. Remove or mask unless explicitly authorised.',m.group(0)[:4]+'…')
    for m in re.finditer(r'\b(?:\d[ -]?){13,18}\d\b',text):
        d=re.sub(r'\D','',m.group(0))
        if 14<=len(d)<=19 and luhn(d):
            if near(m,r'card|visa|master|amex|credit|debit|\bPAN\b|cvv|expiry'): add('ERROR','LNT-PII','Possible payment-card number (passes Luhn check). Remove or mask.',d[:4]+'…')
            else: add('WARN','LNT-PII-POSSIBLE','Long number passes the card Luhn check; confirm it is not a payment card.',d[:4]+'…')
    for m in re.finditer(r'\b[\w.+-]+@[\w-]+\.[\w.-]+\b',text):
        add('WARN','LNT-CONTACT','Email address in deliverable; confirm it is necessary and authorised (personal data).',m.group(0)[:3]+'…')
    for m in PLACEHOLDER.finditer(text):
        add('WARN','LNT-PLACEHOLDER','Unfilled placeholder text.',m.group(0)); break
    for item in (retracted or []):
        item=normalise(item).strip()
        if len(item)>=4 and re.search(re.escape(item),text,re.I):
            add('ERROR','LNT-RETRACTED','Text of a retracted finding appears in the deliverable. Retracted findings never appear, even partially (Rule 04).',item)
    return out

def main():
    argv=sys.argv[1:]
    if '--list-codes' in argv:
        for c,v in sorted(CODES.items()): print(f"{c:34} {v['level']:5} rules {v['rules']}  {v['summary']}")
        sys.exit(0)
    retracted=None
    if '--retracted' in argv:
        i=argv.index('--retracted')
        try:
            retracted=[l.strip() for l in open(argv[i+1],encoding='utf-8') if l.strip()]
            del argv[i:i+2]
        except (IndexError,OSError) as e:
            print(f"ERROR cannot read --retracted list: {e}",file=sys.stderr); sys.exit(2)
    args=[a for a in argv if not a.startswith('--')]
    src=args[0] if args else '-'
    try: text=sys.stdin.read() if src=='-' else open(src,encoding='utf-8').read()
    except OSError as e:
        print(f"ERROR cannot read input: {e}",file=sys.stderr); sys.exit(2)
    res=lint(text,retracted)
    if '--json' in sys.argv: print(json.dumps(res,indent=2,ensure_ascii=False))
    else:
        for r in res: print(f"{r['level']:5} {r['code']}: {r['message']}\n      > {r['context']}")
        print(f"\n{sum(r['level']=='ERROR' for r in res)} error(s), {sum(r['level']=='WARN' for r in res)} warning(s)")
    bad=any(r['level']=='ERROR' for r in res) or ('--strict' in sys.argv and res)
    sys.exit(1 if bad else 0)
if __name__=='__main__':main()
