# Lint codes

Generated view of `CODES` in `scripts/safeguard_lint.py` (run `--list-codes` for the live list). Levels are defaults; a few codes change level with context (for example `LNT-PII` is ERROR when an identifier label is nearby, `LNT-PII-POSSIBLE` otherwise).

| Code | Default | Rule | What it catches | Typical fix |
|---|---|---|---|---|
| LNT-FRAUD-CONCLUSIVE | ERROR | 25, 36 | Conclusive fraud wording (stole, embezzled, forged, committed fraud) without ladder hedging | Restate at the supported rung; remove the actor's name |
| LNT-FRAUD-CONCLUSIVE-EVIDENCED | WARN | 25 | Conclusive wording with cited evidence | Confirm R1-R3 corroboration and that the rung is substantiated; legal conclusions go to counsel |
| LNT-FRAUD-CONCLUSIVE-QUOTED | WARN | 25 | Conclusive wording that quotes a policy | Confirm it describes a rule, not a person |
| LNT-THEFT-PASSIVE | WARN | 25 | Theft stated as fact without an actor | Cite the incident source (police report, count) or hedge |
| LNT-MOTIVE | WARN | 25 | Motive or intent wording (greed, deliberately, knowingly, to cover up) | Describe the pattern only |
| LNT-TR-STATUS | ERROR | 16 | Topical Requirement described as mandatory before it is effective | Verify status at the primary source |
| LNT-STD-CITE | ERROR | 16 | Wrong GIAS 2024 citation | Use the correct clause (fraud consideration 13.2; engagement documentation 14.6) |
| LNT-BARE-GIAS | WARN | 16 | Standards cited without a sub-clause | Cite the exact standard |
| LNT-ASSERTION | WARN | 13 | Management assertion supporting a conclusion without corroboration | Add re-performance or inspection evidence |
| LNT-UNVERIFIED-RATE | WARN | 2, 3 | Statutory rate or threshold with no source or verification date | Add source and date from the statutory register; mark [UNVERIFIED] if not verified |
| LNT-DESIGN-OPERATING | WARN | 10 | Findings with no design vs operating label | Label each finding |
| LNT-R5-CITED | WARN | 6 | Verbal or R5 material cited as evidence | Replace with R1-R4 evidence or drop the claim |
| LNT-PROCESS-NARRATION | WARN | 29 | "This audit found", "independently confirmed a third time", "here is what I fixed" | Remove; verification narration belongs in the QA log, not the deliverable |
| LNT-PARTIAL-LIST | WARN | 33 | "Top 10", "five largest", "oldest" excerpts in a body | Name the full population (15 or fewer) or summarise and schedule the complete list |
| LNT-RETRACTED | ERROR | 4 | Text of a retracted finding (needs `--retracted`) | Remove entirely |
| LNT-PII | ERROR | 36 | NRIC, PAN, Aadhaar, CURP, payment card number | Mask or remove unless authorised |
| LNT-PII-POSSIBLE | WARN | 36 | Number resembling an identifier | Confirm it is not one |
| LNT-CONTACT | WARN | 36 | Email address | Confirm it is necessary and authorised |
| LNT-PLACEHOLDER | WARN | 9, 29 | TBD, TBC, lorem ipsum, unfilled template tokens | Fill or remove |

Jurisdiction-specific identifier formats (Malaysian NRIC, Indian PAN and Aadhaar, Mexican CURP) are formats, not statutory rates; they carry no dated values and need no statutory register.
