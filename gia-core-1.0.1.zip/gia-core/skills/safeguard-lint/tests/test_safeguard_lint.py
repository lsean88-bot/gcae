import sys,importlib.util
from pathlib import Path
spec=importlib.util.spec_from_file_location('lint',Path(__file__).resolve().parents[1]/'scripts/safeguard_lint.py'); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
BAD=[
 ("LNT-FRAUD-CONCLUSIVE","The clerk st\u043ele the cash from the till."),
 ("LNT-FRAUD-CONCLUSIVE","The clerk sto\u200ble the cash from the till."),
 ("LNT-FRAUD-CONCLUSIVE","The clerk diverted company funds to his personal account."),
 ("LNT-FRAUD-CONCLUSIVE","The storekeeper steals inventory every month."),
 ("LNT-FRAUD-CONCLUSIVE","The approver signature was forged on the voucher."),
 ("LNT-FRAUD-CONCLUSIVE","Could not be clearer: Ali stole the money."),
 ("LNT-FRAUD-CONCLUSIVE","In May the cashier stole the cash."),
 ("LNT-THEFT-PASSIVE","The scrap metal was stolen from the yard; a police report was lodged."),
 ("LNT-PII-POSSIBLE","Bank reference 4111111111111111 was cited."),
 ("LNT-PII","NRIC 850101\u201014\u20105678 was used."),
 ("LNT-PII","pan abcde1234f was on the form."),
 ("LNT-PII","Aadhaar 234567890123 was attached."),
 ("LNT-FRAUD-CONCLUSIVE","The purchasing manager committed fraud by splitting orders."),
 ("LNT-FRAUD-CONCLUSIVE","Investigation shows the storekeeper stole the scrap proceeds."),
 ("LNT-TR-STATUS","The Anti-Corruption Topical Requirement is mandatory for this assurance engagement."),
 ("LNT-STD-CITE","Fraud risk must be considered under GIAS Standard 11.1."),
 ("LNT-STD-CITE","Workpapers follow Standards 26–30."),
 ("LNT-PII","Employee NRIC 850101-14-5678 was used."),
 ("LNT-PII","PAN ABCDE1234F appears on the voucher."),
 ("LNT-UNVERIFIED-RATE","Employer EPF contribution is 13% of wages for these staff."),
 ("LNT-PLACEHOLDER","Recommendation: [TBD] by management."),
 ("LNT-FRAUD-CONCLUSIVE-EVIDENCED","The vendor committed fraud, as confirmed by the signed confession (R3) and the bank trail."),
 ("LNT-ASSERTION","Management confirmed the approvals, therefore no exception exists."),
 ("LNT-BARE-GIAS","GIAS requires the CAE to document this conclusion."),
 ("LNT-FRAUD-CONCLUSIVE","The cashier stole RM9,000; she may appeal."),
 ("LNT-FRAUD-CONCLUSIVE","The director embezzled funds, which would be reported to MACC."),
 ("LNT-FRAUD-CONCLUSIVE","The clerk misappropriated the refunds."),
 ("LNT-FRAUD-CONCLUSIVE","He siphoned cash from the till."),
 ("LNT-FRAUD-CONCLUSIVE","The storeman is a thief."),
 ("LNT-FRAUD-CONCLUSIVE","The clerk forged the approver signature on the voucher."),
 ("LNT-FRAUD-CONCLUSIVE","He took the cash and falsified the records."),
 ("LNT-TR-STATUS","The anti-corruption topical requirement is mandatory this year."),
 ("LNT-TR-STATUS","The Talent Management topical requirement is now compulsory."),
 ("LNT-TR-STATUS","The Anti-Corruption Topical Requirement applies.\nIt is mandatory."),
 ("LNT-STD-CITE","STANDARD 11.1 covers fraud."),
 ("LNT-STD-CITE","Standard 11.1\nrequires fraud risk assessment."),
 ("LNT-PII","NRIC 850101145678 on file."),
 ("LNT-PII","IC 850101 14 5678 recorded."),
 ("LNT-PII","Card 4111 1111 1111 1111 was used."),
 ("LNT-PII","Aadhaar 2345 6789 0123 was attached."),
 ("LNT-ASSERTION","The CFO said the entry was proper, and hence we accept it."),
 ("LNT-ASSERTION","Management confirmed the controls work.\nTherefore no exception was raised."),
 ("LNT-PLACEHOLDER","Amount: <INSERT AMOUNT>."),
 ("LNT-PLACEHOLDER","Date: XX/XX/2026."),
 ("LNT-PLACEHOLDER","Owner: TBC."),
 ("LNT-DESIGN-OPERATING","Observation: approvals were missing for four items."),
 ("LNT-UNVERIFIED-RATE","Employer EPF 13% per internal memo, source: memo."),
 ("LNT-UNVERIFIED-RATE","EPF at 13% - verify later is not done."),
]
GOOD=[
 "There is no evidence he committed fraud; the matter remains an open question.",
 "Connecting rods are forged by the vendor on a 2500T press.",
 "The auditee has not committed fraud.",
 "Voucher VOUCH2026X and PV PVOUC1234Q were reviewed.",
 "The forged parts certificate was issued by the die shop and reviewed.",
 "The forged crankshafts and forged flanges were inspected and passed.",
 "Die-forged components from the forging line met the hardness specification.",
 "Invoice batch 2026 2027 2028 was posted.",
 "Total 1234567890123456 units shipped.",
 "Internal asset tag ABCDE1234F was scanned.",
 "Anti-Corruption training is mandatory for all staff.",
 "Employees who stole property will be dismissed under HR rules.",
 "The cashier allegedly stole RM9,000; this is an allegation only.",
 "If proven, the manager would have embezzled funds, which we have not established.",
 "Preliminary analytics identify indicators consistent with the allegation. These are indicators only and not a conclusion that fraud has occurred.",
 "Fraud risk is considered in the engagement risk assessment (Standard 13.2).",
 "The Anti-Corruption Topical Requirement is to be issued in Q4 2026 and is not yet mandatory.",
 "EPF employer rate of 13% (verified on 2026-10-05 against the official EPF portal).",
 "Management stated that approvals were performed; we re-performed a sample and inspected the signed records.",
 "Finding 1 (Operating failure): approvals were not evidenced for 4 of 25 items.",
 "Engagement documentation is retained under Standard 14.6.",
 "Fraud was committed? We do not know.",
 "SOCSO contributions were RM 1,250 for the month per the payroll register.",
 "Earlier tooling incorrectly cited Standard 11.1 for fraud consideration; the correct clause is 13.2.",
]
def codes(t): return {r['code'] for r in m.lint(t)}
ERROR_CODES={'LNT-FRAUD-CONCLUSIVE','LNT-TR-STATUS','LNT-STD-CITE','LNT-PII'}
def levels(t,code): return {r['level'] for r in m.lint(t) if r['code']==code}
fails=[]
for code,t in BAD:
    if code not in codes(t): fails.append(('missed',code,t))
    elif code in ERROR_CODES and 'ERROR' not in levels(t,code): fails.append(('wrong-severity',code,t))
for t in GOOD:
    c=codes(t)
    if c: fails.append(('false-positive',sorted(c),t))
for f in fails: print("FAIL",f)
print(f"lint tests: {len(BAD)+len(GOOD)-len(fails)}/{len(BAD)+len(GOOD)} pass")
sys.exit(1 if fails else 0)
