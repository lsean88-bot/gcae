"""Tests for the lint codes added in gia-core (canonical Iron Rule patterns). Run: python3 -I test_canonical_codes.py"""
import sys
import importlib.util
from pathlib import Path

spec = importlib.util.spec_from_file_location('lint', Path(__file__).resolve().parents[1] / 'scripts/safeguard_lint.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

BAD = [
    ("LNT-MOTIVE", "The purchasing officer split the orders out of greed."),
    ("LNT-MOTIVE", "The approver acted deliberately to avoid the tender threshold."),
    ("LNT-MOTIVE", "Management knowingly released the payment without a second approval."),
    ("LNT-MOTIVE", "The clerk altered the entry to cover up the shortfall."),
    ("LNT-R5-CITED", "The finding is supported by R5 verbal statements from the store team."),
    ("LNT-R5-CITED", "The storekeeper verbally confirmed the count, which establishes the balance."),
    ("LNT-R5-CITED", "Evidence for the control operating is the verbal assurance of the plant head."),
    ("LNT-PROCESS-NARRATION", "This audit independently confirmed the figures a third time."),
    ("LNT-PROCESS-NARRATION", "Here's what I fixed: the totals now agree."),
    ("LNT-PROCESS-NARRATION", "The previous draft stated a lower balance."),
    ("LNT-PROCESS-NARRATION", "The verification process re-performed all tie-outs."),
    ("LNT-PARTIAL-LIST", "The ten largest overdue invoices are listed below."),
    ("LNT-PARTIAL-LIST", "Top 10 exceptions by value follow."),
    ("LNT-PARTIAL-LIST", "The five oldest open items are shown."),
]
GOOD = [
    "There is no evidence of motive; the report describes the pattern only.",
    "Motive is not assessed in this report.",
    "The control was deliberately designed to require two approvals (Design: effective).",
    "R5 material is never cited; all findings rest on R1 to R4 evidence.",
    "Verbal statements were not relied on and are excluded from the evidence base.",
    "All 12 exceptions are named in the table below.",
    "The population of 240 invoices is summarised by count, value and age; the complete list is in Appendix B.",
    "The recommendation is owned by the plant controller with a target date of 31 March.",
]


def codes(t, retracted=None):
    return {r['code'] for r in m.lint(t, retracted)}


fails = []
n = 0
for code, t in BAD:
    n += 1
    if code not in codes(t):
        fails.append(('missed', code, t))
for t in GOOD:
    n += 1
    c = codes(t)
    if c:
        fails.append(('false-positive', sorted(c), t))
# retracted list (Rule 04)
n += 1
if 'LNT-RETRACTED' not in codes("Item 3 concerns the Oragadam stock variance.", ["Oragadam stock variance"]):
    fails.append(('missed', 'LNT-RETRACTED', 'retracted'))
n += 1
if codes("Item 3 concerns the dispatch note.", ["Oragadam stock variance"]):
    fails.append(('false-positive', 'retracted', 'retracted'))
# every emitted code must be registered in CODES
emitted = set()
for _, t in BAD:
    emitted |= codes(t)
n += 1
if not emitted <= set(m.CODES):
    fails.append(('unregistered', sorted(emitted - set(m.CODES)), ''))
for f in fails:
    print("FAIL", f)
print("canonical-code tests: %d/%d pass" % (n - len(fails), n))
sys.exit(1 if fails else 0)
