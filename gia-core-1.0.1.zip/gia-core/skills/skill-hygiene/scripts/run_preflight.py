#!/usr/bin/env python3
"""
run_preflight.py - the automatable checks to run on a skill draft before it goes to independent review.

Runs, in order:
  1. skill_lint.py (structure: frontmatter, name, description rules, line caps, reference links and contents lists)
  2. scan_overlap.py targeted at the draft (overlap against the portfolio; advisory, never an automatic fail)

It does not replace the independent QA pass (a different agent, Read/Grep/Glob only) and it does not run live trigger evals.

Usage:
    python3 -I run_preflight.py --skill /path/to/draft-skill [--roots DIR ...] [--threshold 0.30]
"""
import argparse
import json
import subprocess
import sys
from pathlib import Path


def default_scan_roots():
    import os
    env = os.environ.get("GIA_SKILL_ROOTS")
    if env:
        return [r for r in env.split(os.pathsep) if r]
    return [str(Path(__file__).resolve().parents[4])]


def run(cmd):
    result = subprocess.run(cmd, capture_output=True, text=True)
    return result.returncode, result.stdout.strip(), result.stderr.strip()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--skill", required=True, help="Path to the draft skill folder")
    parser.add_argument("--roots", nargs="+", default=None, help="Directories to search for SKILL.md files (default: scan_overlap's default roots)")
    parser.add_argument("--threshold", type=float, default=0.30)
    args = parser.parse_args()

    skill_path = Path(args.skill).resolve()
    skill_md = skill_path / "SKILL.md"

    report = {"skill": str(skill_path), "checks": {}}
    overall_pass = True

    # --- Check 1: structural validity ---
    lint = Path(__file__).resolve().parent / "skill_lint.py"
    rc, out, err = run([sys.executable, "-I", str(lint), str(skill_path)])
    report["checks"]["structural_validity"] = {"pass": rc == 0, "message": out or err}
    if rc != 0:
        overall_pass = False

    # --- Check 2: portfolio overlap ---
    scan_script = Path(__file__).resolve().parent / "scan_overlap.py"
    if not scan_script.exists():
        report["checks"]["portfolio_overlap"] = {
            "pass": None,
            "message": f"SKIPPED -- skill-sprawl-watch's scan_overlap.py not found at "
                       f"{scan_script}. This skill isn't co-located with skill-factory "
                       f"(expected on claude.ai, where skills upload independently with "
                       f"no guaranteed shared path). Pass --sprawl-watch-path explicitly "
                       f"if skill-sprawl-watch is installed elsewhere.",
        }
    elif skill_md.exists():
        rc, out, err = run([
            sys.executable, "-I", str(scan_script),
            *(["--roots", *args.roots, str(skill_path)] if args.roots else ["--roots", *default_scan_roots(), str(skill_path)]),
            "--target", str(skill_md),
            "--threshold", str(args.threshold),
            "--json",
        ])
        if rc == 3:
            # scan_overlap.py's own crash-detection wrapper (added the same day as this
            # check, for the same reason) -- rc 3 is unique to a genuine unhandled crash,
            # never a graceful exit. rc 0 = success (with or without flags). rc 1 = a
            # graceful guarded exit (e.g. fewer than 2 valid skills found) -- also fine.
            report["checks"]["portfolio_overlap"] = {
                "pass": None,
                "message": f"scan_overlap.py CRASHED (exit {rc}) -- overlap check did NOT run. "
                           f"Treat this the same as a FAIL, not a clean pass.",
                "stderr": err[-2000:] if err else "(no stderr captured)",
            }
            overall_pass = False
        else:
            if rc == 1 and not out.strip():
                # A graceful exit 1 with nothing on stdout means the check genuinely didn't
                # run (e.g. the target's own description couldn't be loaded at all) -- not
                # the same as running cleanly and finding zero flags. Found via UAT
                # 2026-08-08 as a smaller residual case of the same reporting-accuracy
                # family as the rc==3 crash fix above.
                report["checks"]["portfolio_overlap"] = {
                    "pass": None,
                    "message": "Overlap check did not run — target's own description could "
                               "not be loaded (see structural_validity for why).",
                    "stderr": err.strip() if err else "(no stderr captured)",
                }
            else:
                try:
                    overlap_data = json.loads(out) if out else {"flags": []}
                except json.JSONDecodeError:
                    overlap_data = {"flags": [], "raw_error": err or out}
                flags = overlap_data.get("flags", [])
                report["checks"]["portfolio_overlap"] = {
                    "pass": len(flags) == 0,
                    "flags": flags,
                    "message": f"{len(flags)} overlap flag(s) at threshold {args.threshold}" if flags
                               else "No overlap flags",
                }
            # Overlap flags are advisory (a human judgement call, per skill-sprawl-watch's own
            # SKILL.md), not an automatic fail — don't set overall_pass=False here.
    else:
        report["checks"]["portfolio_overlap"] = {
            "pass": None,
            "message": f"scan_overlap.py or {skill_md} not found — SKIPPED",
        }

    report["overall_structural_pass"] = overall_pass
    report["note"] = (
        "This is the automatable preflight only. It does not replace the independent QA pass, nor a live trigger-eval loop "
        "(which needs Claude Code). Overlap flags are advisory: read them, do not auto-fail on them."
    )

    print(json.dumps(report, indent=2))
    sys.exit(0 if overall_pass else 1)


if __name__ == "__main__":
    main()
