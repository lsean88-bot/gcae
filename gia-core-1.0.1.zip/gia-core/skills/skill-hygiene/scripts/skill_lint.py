#!/usr/bin/env python3
"""skill_lint.py - structural check of one skill folder (no external validator needed).

  python3 -I skill_lint.py <skill folder> [--json]

Checks: SKILL.md exists with YAML frontmatter that parses; name is kebab-case, 64 characters or fewer, equals the folder name and holds no
reserved word; description is 1024 characters or fewer and contains "Use when" and "Do NOT use"; body is under 500 lines; every
`references/...` and `scripts/...` path named in the body exists; every reference over 100 lines opens with a Contents list.
Exit 0 = pass, 1 = at least one failure. Warnings never fail.
"""
import json
import re
import sys
from pathlib import Path

try:
    import yaml
except ImportError:  # the checks still run; frontmatter is read with a minimal parser
    yaml = None


def parse_frontmatter(text):
    m = re.match(r"---\n(.*?)\n---\n", text, re.S)
    if not m:
        return None, "no frontmatter block"
    raw = m.group(1)
    if yaml is not None:
        try:
            d = yaml.safe_load(raw)
        except yaml.YAMLError as e:
            return None, "frontmatter is not valid YAML: %s" % str(e).splitlines()[0]
        return (d if isinstance(d, dict) else None), ("" if isinstance(d, dict) else "frontmatter is not a mapping")
    d, cur = {}, None
    for line in raw.splitlines():
        mm = re.match(r"^([A-Za-z_-]+):\s*(.*)$", line)
        if mm:
            cur = mm.group(1)
            d[cur] = mm.group(2).strip("\"'")
        elif cur:
            d[cur] += " " + line.strip()
    return d, ""


def lint(folder):
    folder = Path(folder).resolve()
    fails, warns = [], []
    sm = folder / "SKILL.md"
    if not sm.exists():
        return ["SKILL.md missing"], warns
    text = sm.read_text(encoding="utf-8")
    fm, err = parse_frontmatter(text)
    if fm is None:
        return [err], warns
    name = str(fm.get("name", ""))
    desc = " ".join(str(fm.get("description", "")).split())
    if not re.fullmatch(r"[a-z0-9]+(-[a-z0-9]+)*", name) or len(name) > 64:
        fails.append("name %r is not kebab-case of 64 characters or fewer" % name)
    if name != folder.name:
        fails.append("name %r does not match the folder %r" % (name, folder.name))
    if re.search(r"anthropic|claude", name):
        fails.append("name contains a reserved word")
    if not desc:
        fails.append("description missing")
    else:
        if len(desc) > 1024:
            fails.append("description is %d characters (limit 1024)" % len(desc))
        if "Use when" not in desc:
            fails.append('description lacks "Use when"')
        if "Do NOT use" not in desc:
            fails.append('description lacks "Do NOT use"')
    n = len(text.splitlines())
    if n >= 500:
        fails.append("SKILL.md is %d lines (limit under 500)" % n)
    for ref in sorted(set(re.findall(r"`(references/[A-Za-z0-9_.\-/]+)`", text)) | set(re.findall(r"`(scripts/[A-Za-z0-9_.\-/]+)`", text))):
        if not (folder / ref).exists():
            fails.append("named path does not exist: %s" % ref)
    rd = folder / "references"
    if rd.is_dir():
        for rf in sorted(rd.glob("*.md")):
            body = rf.read_text(encoding="utf-8")
            if len(body.splitlines()) > 100 and "Contents" not in body[:1500] and "Table of Contents" not in body[:1500]:
                fails.append("reference %s is over 100 lines without a contents list" % rf.name)
            if (rd / rf.name).is_dir():
                continue
        for sub in rd.iterdir():
            if sub.is_dir():
                warns.append("references/%s is nested; keep references one level deep" % sub.name)
    return fails, warns


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 2
    fails, warns = lint(sys.argv[1])
    if "--json" in sys.argv:
        print(json.dumps({"fails": fails, "warnings": warns}, indent=1))
    else:
        for f in fails:
            print("FAIL: " + f)
        for w in warns:
            print("WARN: " + w)
        print("skill_lint: %d failure(s), %d warning(s)" % (len(fails), len(warns)))
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
