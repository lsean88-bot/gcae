"""
claim_patterns.py — the single source of truth for what counts as a supersession
claim and what counts as verification evidence, shared by retirement_gate.py (the
PreToolUse hook) and unverified_claims_census.py (the portfolio-wide monitor).

Deliberately factored out rather than duplicated in both places: duplicating this
regex in two files is exactly the dual-install-drift problem (Pattern A) applied to
code instead of skills. Change it here once; both consumers pick it up.
"""
import re

CLAIM_PATTERN = re.compile(
    r"superseded by|supersedes\s|merged into|consolidated onto|no content (was|is) lost|"
    r"reduced to a (redirect )?stub|retired on",
    re.IGNORECASE,
)

EVIDENCE_PATTERN = re.compile(
    r"verification method|verified,? \(?content \)?migrated|verified-retired|"
    r"verified[\s(\-]{0,4}(2026|not superseded|false|not merely claimed)",
    re.IGNORECASE,
)


def has_unverified_claim(text: str) -> bool:
    """True if text asserts a supersession-shaped claim with no evidence marker."""
    return bool(CLAIM_PATTERN.search(text)) and not bool(EVIDENCE_PATTERN.search(text))
