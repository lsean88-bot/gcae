#!/usr/bin/env python3
"""
scan_overlap.py - skill and plugin portfolio overlap scanner.

Indexes each skill's OWN frontmatter `description:` field (never commentary written about it), parsed properly (narrow frontmatter
match feeding yaml.safe_load, not one greedy regex). Two scores per pair, either of which can flag: Jaccard (symmetric) and containment
(shared / min size, robust when one description is much longer). Lexical heuristics only; a flag means "read both and decide".

Usage:
    python3 -I scan_overlap.py [--roots DIR ...] [--target PATH] [--threshold 0.30] [--json]

Roots: --roots, else $GIA_SKILL_ROOTS (path-separator list), else the folder holding the sibling plugins of this one.
With --target only that skill is compared against every other; otherwise every pair is compared (portfolio sweep).
"""
import argparse
import json
import re
import sys
from pathlib import Path

import yaml

FRONTMATTER_RE = re.compile(r"^---\n(.*?)\n---", re.DOTALL)  # narrow, non-greedy — see Lesson 3

# Domain terms common enough across this entire GIA library that they carry no
# discriminating signal on their own (per tooling-qaip-checklist.md: "'audit' alone will
# match nearly everything and isn't a useful overlap signal on its own"). Excluded from
# scoring; a skill that only shares these with another isn't actually a collision.
STOPWORDS = {
    "audit", "audits", "auditor", "auditing", "risk", "risks", "compliance", "governance",
    "control", "controls", "finding", "findings", "gia", "mktron", "iia", "gias", "coso",
    "erm", "sox", "cae", "board", "committee", "report", "reporting", "assurance",
    "advisory", "internal", "group", "the", "and", "for", "with", "use", "trigger",
    "always", "when", "or", "any", "a", "an", "to", "of", "in", "on", "this", "that",
    "skill", "related", "topic", "context", "engagement", "management", "framework",
    "standard", "standards", "process", "review",
}

TOKEN_RE = re.compile(r"[a-z0-9]+(?:-[a-z0-9]+)?")


def tokenize(text: str) -> set:
    """Lowercase, tokenize, strip stopwords. Keeps hyphenated terms (e.g. 'key-control')
    as single tokens since splitting them loses the discriminating signal."""
    tokens = TOKEN_RE.findall(text.lower())
    return {t for t in tokens if t not in STOPWORDS and len(t) > 2}


def load_description(skill_md_path: Path):
    """Extract the frontmatter `description:` field from a skill's own SKILL.md.
    Returns (name, description) or None if this isn't a valid skill file."""
    try:
        content = skill_md_path.read_text(encoding="utf-8", errors="ignore")
    except OSError:
        return None
    match = FRONTMATTER_RE.match(content)
    if not match:
        return None
    try:
        frontmatter = yaml.safe_load(match.group(1))
    except yaml.YAMLError:
        return None
    if not isinstance(frontmatter, dict):
        return None
    description = frontmatter.get("description", "")
    name = frontmatter.get("name", skill_md_path.parent.name)
    if not description:
        return None
    if not isinstance(description, str):
        # A YAML frontmatter description can parse as a list, dict, number, etc. if the
        # author made a syntax mistake (e.g. an unindented list under `description:`).
        # Treat exactly like a YAML parse failure -- invalid, not a crash. Found via UAT
        # 2026-08-08: this previously crashed tokenize() with an unhandled AttributeError,
        # taking down an entire portfolio sweep because of one malformed file elsewhere.
        return None
    return name, description


def default_roots():
    import os
    env = os.environ.get("GIA_SKILL_ROOTS")
    if env:
        return [r for r in env.split(os.pathsep) if r]
    return [str(Path(__file__).resolve().parents[4])]


def discover_skills(roots):
    """Find every SKILL.md under the given roots and load (name, description, path)."""
    found = []
    seen_paths = set()
    for root in roots:
        root_path = Path(root)
        if not root_path.exists():
            continue
        for skill_md in root_path.rglob("SKILL.md"):
            if "__pycache__" in skill_md.parts or "node_modules" in skill_md.parts:
                continue
            resolved = skill_md.resolve()
            if resolved in seen_paths:
                continue
            seen_paths.add(resolved)
            result = load_description(skill_md)
            if result:
                name, description = result
                found.append({"name": name, "description": description, "path": str(skill_md)})
    return found


def overlap_score(desc_a: str, desc_b: str):
    """Two complementary scores, not one, per UAT finding 2026-08-08: Jaccard similarity
    alone missed a real, substantial duplicate (73% of one description's distinctive
    vocabulary contained in the other) because the two descriptions were very different
    lengths -- a long, padded description dilutes the union and deflates Jaccard even when
    the shorter description is almost entirely contained within it.

    - Jaccard = |A∩B| / |A∪B|  -- symmetric similarity, good when both descriptions are
      similar length.
    - Containment = |A∩B| / min(|A|,|B|)  -- "how much of the SMALLER description's
      vocabulary already exists in the other" -- robust to length asymmetry, and exactly
      the question that matters when checking whether a new (usually shorter, less-padded)
      draft duplicates an existing (often longer, more elaborated) skill.

    Returns (jaccard, containment, shared_terms)."""
    tokens_a, tokens_b = tokenize(desc_a), tokenize(desc_b)
    if not tokens_a or not tokens_b:
        return 0.0, 0.0, set()
    shared = tokens_a & tokens_b
    union = tokens_a | tokens_b
    jaccard = len(shared) / len(union) if union else 0.0
    containment = len(shared) / min(len(tokens_a), len(tokens_b))
    return jaccard, containment, shared


def main():
    parser = argparse.ArgumentParser(description="Scan GIA skill portfolio for description/trigger overlap.")
    parser.add_argument("--roots", nargs="+", default=default_roots(), help="Directories to search for SKILL.md files")
    parser.add_argument("--target", help="Path to a single skill's SKILL.md to check against the rest")
    parser.add_argument("--threshold", type=float, default=0.30, help="Minimum Jaccard score to flag (default 0.30)")
    parser.add_argument("--containment-threshold", type=float, default=0.50,
                         help="Minimum containment score to flag (default 0.50) -- catches "
                              "real duplicates Jaccard misses when description lengths differ "
                              "substantially; see overlap_score()'s docstring")
    parser.add_argument("--json", action="store_true", help="Emit JSON instead of a text report")
    args = parser.parse_args()

    skills = discover_skills(args.roots)
    if len(skills) < 2:
        print(f"Only found {len(skills)} valid skill(s) under {args.roots} — nothing to compare.", file=sys.stderr)
        sys.exit(1)

    flags = []
    if args.target:
        target_result = load_description(Path(args.target))
        if not target_result:
            print(f"Could not load a valid description from {args.target}", file=sys.stderr)
            sys.exit(1)
        target_name, target_desc = target_result
        for other in skills:
            if Path(other["path"]).resolve() == Path(args.target).resolve():
                continue
            jaccard, containment, shared = overlap_score(target_desc, other["description"])
            if jaccard >= args.threshold or containment >= args.containment_threshold:
                flags.append({
                    "skill_a": target_name, "skill_b": other["name"],
                    "path_a": str(args.target), "path_b": other["path"],
                    "score": round(jaccard, 3), "containment": round(containment, 3),
                    "flagged_by": "jaccard" if jaccard >= args.threshold else "containment",
                    "shared_terms": sorted(shared),
                })
    else:
        for i in range(len(skills)):
            for j in range(i + 1, len(skills)):
                jaccard, containment, shared = overlap_score(skills[i]["description"], skills[j]["description"])
                if jaccard >= args.threshold or containment >= args.containment_threshold:
                    flags.append({
                        "skill_a": skills[i]["name"], "skill_b": skills[j]["name"],
                        "path_a": skills[i]["path"], "path_b": skills[j]["path"],
                        "score": round(jaccard, 3), "containment": round(containment, 3),
                        "flagged_by": "jaccard" if jaccard >= args.threshold else "containment",
                        "shared_terms": sorted(shared),
                    })

    flags.sort(key=lambda f: -max(f["score"], f["containment"]))

    if args.json:
        print(json.dumps({"skills_scanned": len(skills), "flags": flags}, indent=2))
    else:
        print(f"Scanned {len(skills)} skills across {args.roots}")
        print(f"Thresholds: Jaccard >= {args.threshold} OR Containment >= {args.containment_threshold}")
        print(f"Flags: {len(flags)}\n")
        for f in flags:
            print(f"  [jaccard {f['score']:.2f} | containment {f['containment']:.2f}, flagged by {f['flagged_by']}] {f['skill_a']}  <->  {f['skill_b']}")
            print(f"        {f['path_a']}")
            print(f"        {f['path_b']}")
            print(f"        shared: {', '.join(f['shared_terms'])}\n")

    sys.exit(0)


if __name__ == "__main__":
    try:
        main()
    except SystemExit:
        raise  # deliberate sys.exit(0)/sys.exit(1) calls inside main() pass through unchanged
    except Exception as e:
        # An unhandled exception here previously exited with code 1 -- identical to main()'s
        # own graceful "not enough valid skills" exit code, making the two indistinguishable
        # to any caller. Found via UAT 2026-08-08: run_preflight.py silently treated a crash
        # here as a clean pass because it couldn't tell "crashed" from "ran fine, zero
        # results" apart. Exit 3 is unique to a genuine unhandled crash.
        print(f"CRASHED: {type(e).__name__}: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(3)
