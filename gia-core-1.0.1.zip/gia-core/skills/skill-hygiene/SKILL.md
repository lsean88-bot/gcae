---
name: skill-hygiene
description: "Skill creation and portfolio hygiene: structure lint and trigger-overlap scan on a skill draft, blocks unverified retirement claims, watches for duplicate installs. Use when building, improving, retiring, merging or renaming a skill or agent, fixing a description that mis-triggers, or auditing the portfolio. Do NOT use for choosing a skill for a task (use gia-core:gcgo-router)."
---

# Skill Hygiene

Keeps the skill library small, accurate and unambiguous. It combines the skill-building workflow, the overlap scanner, the retirement gate and the portfolio monitors.

## Building or changing a skill

1. **Check lessons first.** `python3 -I ${CLAUDE_PLUGIN_ROOT}/skills/self-learning/scripts/log_lesson.py check --query "skill description"` (path from this folder). Known repeat mistakes: a plain YAML description containing a bare colon, indexing commentary instead of the skill's own text, a greedy multi-line regex over structured text, an edit that breaks a length limit already met.
2. **Capture intent.** What the skill does, when it should trigger, the output, whether it needs tests.
3. **Draft.** Frontmatter `name` (kebab-case, 64 characters or fewer, equals the folder) and a `description` of 1024 characters or fewer in the form "Does X. Use when Y. Do NOT use for Z (use <plugin>:<skill>)", trigger words first. Body under 500 lines. Detail goes in `references/` one level deep, with a contents list on any reference over 100 lines. Prefer a block scalar for a long description.
4. **Preflight.** `python3 -I ${CLAUDE_PLUGIN_ROOT}/skills/skill-hygiene/scripts/run_preflight.py --skill <folder>` runs `scripts/skill_lint.py` (structure) then `scripts/scan_overlap.py` (overlap against the portfolio). Fix every structural failure first. Overlap flags are advisory: read both descriptions and decide; never merge or retire on a score alone.
5. **Independent review.** Hand the draft to a different agent with Read, Grep and Glob only (`gia-core:portfolio-qa-challenger` for any retirement, merge or supersession claim). The preparer never reviews its own draft.
6. **Re-run preflight after every edit.** An edit can break a limit already met.
7. **Add evals** in `evals/<skill>.yaml`: at least three prompts that should trigger and three that should not.
8. **Log** anything likely to recur through `gia-core:self-learning`.

## Retiring, merging or superseding

Any claim that one skill is superseded by, merged into or consolidated onto another needs a verification note ("Verification method: ...") saying what was checked in the destination file. The hook `hooks/retirement-gate.sh` denies a SKILL.md edit that makes such a claim without one. It is a text gate: it raises the bar, it does not know whether the claim is true. Run `gia-core:portfolio-qa-challenger` for that. Reading an overlap score does not replace checking the destination.

## Monitors

- `monitors/portfolio_drift_scan.py`: finds a skill installed at more than one path and reports when the copies differ.
- `monitors/unverified_claims_census.py`: lists existing supersession claims with no verification note.
Both are detective; neither changes a file. Run once with `--once` for an on-demand check.

## Reading the overlap scan

Two lexical scores, Jaccard and containment; either can flag. A flag means read both and decide. Identical names at two paths is a duplicate install, a different problem from two different skills sharing vocabulary. Never resolve a flagged pair unilaterally; the CAE decides what is archived, renamed or merged. Lexical scores miss overlap in meaning that uses different words; independent review catches those.

## Honest limits

No live trigger-eval loop is bundled; that needs Claude Code and should still be run for a skill many people rely on. The always-loaded token budget is estimated by `gia-core:runtime-guard` (script token_budget.py). The scan baseline in `references/scan-baseline.md` is a dated snapshot, not a standing result.

## References

- `references/scan-baseline.md`: dated overlap scan of the gia plugins as built.
