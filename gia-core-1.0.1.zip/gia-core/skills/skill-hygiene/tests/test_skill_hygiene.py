#!/usr/bin/env python3
"""Tests for gia-core:skill-hygiene scripts, the retirement gate hook and the two monitors.  Run: python3 -I tests/test_skill_hygiene.py"""
import json
import subprocess
import sys
import tempfile
from pathlib import Path

SK = Path(__file__).resolve().parent.parent
PL = SK.parent.parent
S = SK / "scripts"
res = []


def t(name, ok):
    res.append(bool(ok))
    print(("PASS  " if ok else "FAIL  ") + name)


def run(script, *a, stdin=None):
    p = subprocess.run([sys.executable, "-I", str(script)] + [str(x) for x in a], input=stdin, capture_output=True, text=True, timeout=120)
    return p.returncode, p.stdout + p.stderr


def mk(root, plugin, name, desc, body="body\n"):
    d = Path(root) / plugin / "skills" / name
    d.mkdir(parents=True)
    (d / "SKILL.md").write_text("---\nname: %s\ndescription: %s\n---\n\n# %s\n%s" % (name, desc, name, body), encoding="utf-8")
    return d


GOOD = "Does a thing for testing. Use when a test needs a thing. Do NOT use for other things (use gia-core:iron-rules)."
gate = PL / "hooks" / "retirement_gate.py"
sh = PL / "hooks" / "retirement-gate.sh"


def payload(path, content, tool="Write"):
    return json.dumps({"tool_name": tool, "tool_input": {"file_path": path, "content": content}})


# --- retirement gate
rc, out = run(gate, stdin=payload("/x/SKILL.md", "This skill is superseded by gia-x:y."))
t("gate denies an unverified supersession claim in a SKILL.md", rc == 2 and "deny" in out)
rc, out = run(gate, stdin=payload("/x/SKILL.md", "Merged into gia-x:y. Verification method: compared section by section."))
t("gate allows a claim that carries a verification note", rc == 0)
rc, out = run(gate, stdin=payload("/x/notes.md", "superseded by something"))
t("gate ignores files other than SKILL.md", rc == 0)
rc, out = run(gate, stdin=payload("/x/SKILL.md", "Ordinary text with no claim."))
t("gate allows ordinary SKILL.md edits", rc == 0)
rc, out = run(gate, stdin="not json")
t("gate does not crash on malformed input (content check, fail open by design)", rc == 0)
rc, out = run(gate, stdin=json.dumps({"tool_name": "MultiEdit", "tool_input": {"file_path": "/a/SKILL.md", "edits": [{"new_string": "no content was lost"}]}}))
t("gate reads MultiEdit edits", rc == 2)
p = subprocess.run(["bash", str(sh)], input=payload("/x/SKILL.md", "retired on 2026-01-01"), capture_output=True, text=True, timeout=60)
t("launcher script runs the gate", p.returncode == 2)
# --- skill_lint
with tempfile.TemporaryDirectory() as d:
    g = mk(d, "p", "good-skill", GOOD)
    rc, out = run(S / "skill_lint.py", g)
    t("lint passes a good skill", rc == 0)
    b = mk(d, "p", "bad-skill", "Does a thing.")
    rc, out = run(S / "skill_lint.py", b)
    t("lint fails a description without Use when / Do NOT use", rc == 1 and "Use when" in out and "Do NOT use" in out)
    n = mk(d, "p", "Wrong_Name", GOOD)
    rc, out = run(S / "skill_lint.py", n)
    t("lint fails a non-kebab name", rc == 1)
    long = mk(d, "p", "long-desc", GOOD + " x" * 600)
    rc, out = run(S / "skill_lint.py", long)
    t("lint fails a description over 1024 characters", rc == 1 and "1024" in out)
    big = mk(d, "p", "big-body", GOOD, "line\n" * 520)
    rc, out = run(S / "skill_lint.py", big)
    t("lint fails a body of 500 lines or more", rc == 1 and "500" in out)
    miss = mk(d, "p", "miss-ref", GOOD, "See `references/nothing.md` and `scripts/none.py`.\n")
    rc, out = run(S / "skill_lint.py", miss)
    t("lint fails a reference that does not exist", rc == 1 and "references/nothing.md" in out)
    toc = mk(d, "p", "no-toc", GOOD)
    (toc / "references").mkdir()
    (toc / "references" / "long.md").write_text("# Long\n" + "text\n" * 120)
    rc, out = run(S / "skill_lint.py", toc)
    t("lint fails a long reference without a contents list", rc == 1 and "contents" in out)
    (toc / "references" / "long.md").write_text("# Long\n\nContents: A, B\n" + "text\n" * 120)
    rc, out = run(S / "skill_lint.py", toc)
    t("lint passes once the contents list is present", rc == 0)
    # --- overlap
    a1 = mk(d, "q", "alpha-payroll", "Reconciles payroll registers against bank transfers, overtime claims and statutory deductions. Use when payroll data must be reconciled. Do NOT use for stock.")
    a2 = mk(d, "r", "beta-payroll", "Reconciles payroll registers against bank transfers, overtime claims and statutory deductions each month. Use when payroll data must be reconciled. Do NOT use for stock.")
    a3 = mk(d, "r", "gamma-stock", "Counts warehouse inventory, valuation of raw material and slow-moving items at year end. Use when stock is counted. Do NOT use for payroll.")
    rc, out = run(S / "scan_overlap.py", "--roots", Path(d) / "q", Path(d) / "r", "--json")
    flags = json.loads(out).get("flags", []) if out.strip().startswith("{") else []
    names = json.dumps(flags)
    t("overlap scan flags the near-duplicate pair", "alpha-payroll" in names and "beta-payroll" in names)
    t("overlap scan does not flag the unrelated skill", "gamma-stock" not in names)
    rc, out = run(S / "scan_overlap.py", "--roots", Path(d) / "q", Path(d) / "r", "--target", a3 / "SKILL.md", "--json")
    t("target mode on an unrelated skill finds no flag", rc == 0 and not json.loads(out).get("flags"))
    # --- preflight
    rc, out = run(S / "run_preflight.py", "--skill", g, "--roots", Path(d) / "q", Path(d) / "r")
    t("preflight passes a good skill", rc == 0 and json.loads(out)["overall_structural_pass"])
    rc, out = run(S / "run_preflight.py", "--skill", b, "--roots", Path(d) / "q")
    t("preflight fails a structurally bad skill", rc == 1)
    # --- census
    c = mk(d, "gia-test", "claimant", GOOD, "This skill is superseded by gia-x:y.\n")
    rc, out = run(PL / "monitors" / "unverified_claims_census.py", "--roots", Path(d) / "gia-test", "--once")
    t("census reports an unverified claim and exits 1", rc == 1 and "claimant" in out)
    (c / "SKILL.md").write_text("---\nname: claimant\ndescription: %s\n---\nMerged into gia-x:y. Verification method: read the destination.\n" % GOOD)
    rc, out = run(PL / "monitors" / "unverified_claims_census.py", "--roots", Path(d) / "gia-test", "--once")
    t("census is clean once a verification note is present", rc == 0)
    # --- drift
    d1 = mk(d, "m1", "dup-skill", GOOD)
    d2 = mk(d, "m2", "dup-skill", GOOD)
    rc, out = run(PL / "monitors" / "portfolio_drift_scan.py", "--roots", Path(d) / "m1", Path(d) / "m2", "--once")
    t("drift scan: identical copies are aligned", rc == 0 and "aligned" in out)
    (d2 / "SKILL.md").write_text((d2 / "SKILL.md").read_text() + "\nchanged\n")
    rc, out = run(PL / "monitors" / "portfolio_drift_scan.py", "--roots", Path(d) / "m1", Path(d) / "m2", "--once")
    t("drift scan: a changed copy is reported as drift and exits 1", rc == 1 and "DRIFT" in out)
    rc, out = run(PL / "monitors" / "portfolio_drift_scan.py", "--roots", Path(d) / "q", "--once")
    t("drift scan: no multi-install skills, exit 0", rc == 0)
mj = json.loads((PL / "monitors" / "monitors.json").read_text())
t("monitors.json names two monitors with existing scripts", len(mj) == 2 and all((PL / "monitors" / Path(m["command"].split("}/")[1].split()[0]).name).exists() for m in mj))
hj = json.loads((PL / "hooks" / "hooks.json").read_text())
t("hooks.json wires the retirement gate to Write|Edit|MultiEdit", any(e.get("matcher") == "Write|Edit|MultiEdit" and "retirement-gate.sh" in json.dumps(e) for e in hj["hooks"]["PreToolUse"]))
print("\n%d tests, %d failed" % (len(res), res.count(False)))
sys.exit(0 if all(res) else 1)
