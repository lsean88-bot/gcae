# Overlap scan baseline (30-Oct-2026)

Dated snapshot so a later scan can show whether sprawl is growing or shrinking. It is not a standing result.

Command: `python3 -I ${CLAUDE_PLUGIN_ROOT}/skills/skill-hygiene/scripts/scan_overlap.py --roots <folder holding the five gia plugins> --threshold 0.30 --json`

| Measure | Value |
|---|---|
| Skills scanned | 35 (gia-core, gia-audit, gia-fraud, gia-analytics, gia-report-qa, as built on this date) |
| Thresholds | Jaccard 0.30 or containment 0.50 |
| Flags | 0 |

Reading: no pair of skill descriptions in the five plugins crossed either threshold. This says the descriptions use different vocabulary; it does not prove the skills do not overlap in meaning (lexical scores miss that). The independent QA pass covers meaning.

Re-run after any description edit or new skill, and record the flag count here with the date.
