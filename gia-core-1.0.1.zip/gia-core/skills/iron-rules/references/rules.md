# Iron Rules (rendered)

Generated from `rules.json` by `scripts/render_rules.py`. Do not edit by hand. Cite as `gia-core:iron-rules` + rule number.

Contents: Golden Rule - Iron Rules - Enforcement map - Evidence Hierarchy - Quality Gate - Fraud ladder - Model & Effort Routing - Namespaces

## The Golden Rule

> **Ground truth outranks narrative - always re-derive, never re-trust. Every claim in a deliverable must trace to verifiable ground truth (named evidence, a web-validated primary source, or the user's own explicit correction) at the moment of output - not to what an earlier draft, an earlier session, or Claude's own prior reasoning already concluded. Discard drifted content on sight rather than patching around it.**

**Operating corollary.** Every engagement is run by a specialist agent team led by a Chief Specialist - the strategic mastermind who plans, decomposes and delegates, and does not do the execution itself. Team members are chosen for professional depth in the specific work, industry, company, function and process. Independent QA re-performs key numbers before anything is drafted. Token economy and model routing apply always: the planner-tier model (currently Opus) is the master strategic planner/brain only; full execution is delegated to Sonnet and Haiku at the lowest effort that still meets professional quality (Rules 31-32; matrix in gia-core:model-effort-routing).

## Iron Rules 01-39

```
RULE 01: No finding without named evidence (R1-R4) or web-validated government portal URL
RULE 02: No rate, section, threshold, or effective date from memory — web-validate every time
RULE 03: Correct Act + correct effective date + correct jurisdiction — verify all three always
RULE 04: Retracted findings NEVER appear in any report — not even partially
RULE 05: Duplicate findings MUST be merged — never counted or reported separately
RULE 06: R5 (verbal) evidence is NEVER cited in a finding under any circumstances
RULE 07: Every finding title is self-explanatory (WHO | WHAT breach | WHICH law/standard)
RULE 08: Every recommendation is SMART — Specific, Measurable, Achievable, Relevant, Time-bound
RULE 09: Quality gate must fully pass (all 12 items — see below) before any report is FINAL
RULE 10: Design deficiency vs operating effectiveness failure — always explicitly distinguished
RULE 11: Fraud risk must be formally considered and documented in every engagement scope
RULE 12: No assumption passed as fact — ever; label all assumptions explicitly
RULE 13: Professional skepticism maintained under all stakeholder pressure — always
RULE 14: Population, sample, test procedure, result, and conclusion documented for every test
RULE 15: All deficiencies aggregated before final classification (CD → SD → MW)
RULE 16: IPPF Topical Requirements (Cyber, 3P, Resilience) applied where scope warrants
RULE 17: AI/ML analytics outputs are INDICATORS only — never cited as finding evidence
RULE 18: Before raising any finding, cross-check against all active workstreams for duplicates
RULE 19: Management response and action plan required before report is FINAL
RULE 20: A portfolio-wide rule/lesson gets written here (not invented as a local fix) whenever a pattern recurs twice or a new rule is confirmed — see Self-Learning Loop
RULE 21: ToD (test of design) must PASS before ToE (test of operating effectiveness) commences
RULE 22: A single walkthrough transaction trace is NOT a ToE sample — never conflate the two
RULE 23: ITGC must be confirmed effective before any reliance is placed on automated controls
RULE 24: Escalation triggers require immediate action — deferral is never acceptable
RULE 25: A finding describes the pattern of what happened — it does NOT state motive
RULE 26: Follow-up audit must be planned and tracked for every engagement with Critical or High/Medium findings — risk-based timing, per GIAS Standard 15.2
RULE 27: Never rely on Claude's own previously generated narrative as if it were evidence — re-verify it against the underlying source every time it's reused, and discard it on sight if it doesn't hold up (the Golden Rule, applied to Claude's own drift)
RULE 28: User-supplied ground truth — an explicit correction, a highlighted annotation, a raw source file — outranks any prior AI narrative, draft, or assumption in a conflict
RULE 29: A final deliverable contains only the polished work product — no process narration or "here's what I fixed" commentary inside the document itself (this does not apply to Self-Learning Loop logging, which is a different document for a different reader, and it never licenses omitting anything Rule 04 or Rule 19 requires to be shown)
RULE 30: Any count this file (or any skill) asserts about itself — a rule count, an item count, a phase count — must match what's actually enumerated. Verify with `scripts/check-governance-drift.sh`'s self-consistency check before citing a number; never carry one forward from memory or from what a prior version said
RULE 31: Every audit or work task is run by a specialist agent team with professional depth in the specific work, industry, company, function and process, led by a Chief Specialist (strategic planner/orchestrator who delegates, not executes), with independent QA re-performing key numbers before drafting — all projects, always
RULE 32: Token economy and model routing always — the planner-tier model (currently Opus) is the master strategic planner/brain ONLY: it scopes, plans, decomposes, briefs agents, reviews and owns final conclusions; it does no execution without the user's approval. Full execution is delegated to Sonnet (analysis, fieldwork, drafting, statutory validation, QA) and Haiku (inventory, extraction, formatting, search, checklist population), each at the lowest effort that still meets professional quality. Economy never compromises quality: quality-critical steps (statutory rates, fraud wording, audit opinion, independent QA) are never downgraded to save tokens. Plan once, never re-read what is already known, no filler or restated content; save all work to disk before any limit or timeout. Matrix: "Model & Effort Routing" below
RULE 33: Disclosure is calibrated to audience and decision, and the body is never a partial list — no "top 10", "largest", "oldest" or other excerpt tables. A population of ≤15 items is named in full in the body; a larger one is summarised (count, value, distribution) and its COMPLETE list sits in an appendix referenced from the finding. Full evidence always exists, in the appendix, never omitted
RULE 34: Every figure and named item in a report ties to a workpaper schedule that lists the items behind it; named items + remainder = total
RULE 35: Focus and balance — one key message per finding, evidenced positives included, confirmed and potential amounts kept separate; content failing the disclosure test is scheduled or removed, never softened
RULE 36: Sensitive matters (fraud-indicative, legal, personal data, active investigations) are routed by the right channel and described by role not name; the report body never states motive
RULE 37: Basis of statements — every material statement in a report is classed Verified from source file / Supplied by others, not independently verified / Audit inference or assumption (with rationale and limits stated) / Proposal. No inference, absence of evidence or unsourced premise is presented as fact; "not evidenced" is never written as "did not happen". The class table sits in an appendix
RULE 38: A client's or auditor's own report supplied as source of truth is reconciled to the data first (every claim re-performed, differences logged). Its facts, structure and ratings are kept; wording is changed only where the evidence does not support it, each change logged with reason in a SEPARATE change log (never inside the report), and issues found in the draft are offered back to its author
RULE 39: Analytical comparisons and dates are made safe before they are cited — control for confounders (part, launch, invoice-date mix) before citing lags or multiples and state the like-for-like base; label every cut-off date and population (register vs tracker vs reconciliation date; counts that differ by scope are footnoted); state sign conventions; estimated values are disclosed wherever the headline figure appears
```

## Enforcement map

| Rule | Category | Mechanical check |
|---|---|---|
| 01 | evidence | runtime: `GR-16` |
| 02 | statutory | lint: `LNT-UNVERIFIED-RATE` |
| 03 | statutory | lint: `LNT-UNVERIFIED-RATE` |
| 04 | finding-integrity | behavioural (Quality Gate / independent QA) |
| 05 | finding-integrity | behavioural (Quality Gate / independent QA) |
| 06 | evidence | lint: `LNT-R5-CITED` |
| 07 | finding-quality | behavioural (Quality Gate / independent QA) |
| 08 | finding-quality | behavioural (Quality Gate / independent QA) |
| 09 | quality-gate | behavioural (Quality Gate / independent QA) |
| 10 | deficiency | lint: `LNT-DESIGN-OPERATING` |
| 11 | fraud-risk | behavioural (Quality Gate / independent QA) |
| 12 | ground-truth | runtime: `GR-09` |
| 13 | independence | lint: `LNT-ASSERTION`; runtime: `GR-13` |
| 14 | testing | behavioural (Quality Gate / independent QA) |
| 15 | deficiency | behavioural (Quality Gate / independent QA) |
| 16 | standards | lint: `LNT-TR-STATUS`, `LNT-STD-CITE`, `LNT-BARE-GIAS` |
| 17 | analytics | runtime: `GR-12` |
| 18 | finding-integrity | behavioural (Quality Gate / independent QA) |
| 19 | management-response | behavioural (Quality Gate / independent QA) |
| 20 | governance | behavioural (Quality Gate / independent QA) |
| 21 | testing | behavioural (Quality Gate / independent QA) |
| 22 | testing | behavioural (Quality Gate / independent QA) |
| 23 | testing | behavioural (Quality Gate / independent QA) |
| 24 | escalation | behavioural (Quality Gate / independent QA) |
| 25 | fraud-wording | lint: `LNT-FRAUD-CONCLUSIVE`, `LNT-THEFT-PASSIVE`, `LNT-MOTIVE`; runtime: `GR-12`, `GR-18` |
| 26 | follow-up | behavioural (Quality Gate / independent QA) |
| 27 | ground-truth | behavioural (Quality Gate / independent QA) |
| 28 | ground-truth | behavioural (Quality Gate / independent QA) |
| 29 | report-hygiene | lint: `LNT-PROCESS-NARRATION`, `LNT-PLACEHOLDER` |
| 30 | governance | script: `skills/iron-rules/scripts/check-governance-drift.sh`, `skills/iron-rules/scripts/test_rules.py` |
| 31 | orchestration | runtime: `GR-05` |
| 32 | orchestration | runtime: `GR-05`, `GR-14`; script: `skills/model-effort-routing/scripts/select_model_effort.py` |
| 33 | disclosure | lint: `LNT-PARTIAL-LIST` |
| 34 | disclosure | behavioural (Quality Gate / independent QA) |
| 35 | disclosure | behavioural (Quality Gate / independent QA) |
| 36 | sensitive-matters | lint: `LNT-PII`, `LNT-PII-POSSIBLE`, `LNT-CONTACT`; runtime: `GR-17` |
| 37 | disclosure | behavioural (Quality Gate / independent QA) |
| 38 | source-report | behavioural (Quality Gate / independent QA) |
| 39 | analytics | behavioural (Quality Gate / independent QA) |

`lint` = code emitted by `gia-core:safeguard-lint`; `runtime` = control enforced by `gia-core:runtime-guard` (mapping in its gr-mapping reference); `script` = deterministic script. Behavioural rules are checked at the Quality Gate and by independent QA.

## Evidence Hierarchy (R1-R5)

| Rank | Definition | Citable in a finding? |
|---|---|---|
| **R1** | Government portal, gazette, or regulator's official download/certificate - external source, entity had no hand in producing it | Yes - strongest |
| **R2** | System-of-record export (ERP/HRMS/banking-generated report) or an auditor-prepared, independently executed reconciliation | Yes - strong |
| **R3** | A signed original document or physical record that has also been independently verified or corroborated by someone outside the audited party | Yes - conditional |
| **R4** | Management-provided copy/scan; a signed/original document not independently verified (rep letter, internally-drafted board paper, MIS report); or informal-but-documented items (email, minutes, chat log) | Corroborate before relying on it |
| **R5** | Verbal statement or unverified claim | Never cite, under any circumstances |

**The R3 test:** Signed + original is necessary but not sufficient. If it was not also independently verified, it is R4, not R3 - a management representation letter is a signed original document and still does not qualify for R3.

## Quality Gate - 12 items (Rule 09)

- [ ] Every finding has named evidence file (R1-R4) or web-validated portal URL - no R5
- [ ] Every rate / section / threshold web-validated - source URL recorded in finding
- [ ] Correct Act + correct effective date + correct jurisdiction - all three verified
- [ ] No duplicate findings (merged where same issue; all evidence consolidated)
- [ ] No retracted, draft, or internal CAE note text in the final report
- [ ] All findings rated with risk colour (red / amber / green)
- [ ] Deficiency classification (CD / SD / MW) documented and defensible
- [ ] Aggregation assessment completed - all related deficiencies reviewed together
- [ ] All recommendations are SMART - named owner and target date present
- [ ] Report is version-controlled - version number, date, classification, CAE sign-off
- [ ] Document reference appendix lists all evidence reviewed
- [ ] Disclaimer present: professional IA report - not a statutory audit, CA certificate, or legal opinion

Rules 33-39 are a drafting discipline, not additional gate items. The Independent QA Gate (multi-pass review in gia-report-qa) is a separate process from this end-state checklist.

## Fraud ladder

Order: weakness > indicator > suspicion > allegation > corroborated > substantiated. Never: motive (Rule 25); no person is named in the report body (Rule 36); legal conclusions (fraud, guilt, liability, disciplinary outcome) belong to counsel and the authorised body, not Internal Audit.

| Rung | Meaning | Minimum evidence | Permitted wording | Forbidden |
|---|---|---|---|---|
| **weakness** | A design or operating gap that would permit misstatement or misappropriation. No evidence that anything occurred. | Control description and the gap (Rule 10 label). | The control gap would permit ... | Any statement that an irregularity happened. |
| **indicator** | An anomaly or red flag consistent with, but not specific to, an irregularity. Innocent explanations are not yet excluded. | Data or document pattern with source (R1-R4); analytics output counts as an indicator only (Rule 17). | The pattern is an indicator that may warrant inquiry ... | Naming a cause, an actor or intent. |
| **suspicion** | Several indicators, or one unexplained pattern, that justify a bounded inquiry. Innocent explanations are still open and being tested. | Documented indicators plus the explanations considered. | The combination of indicators gives reasonable grounds to inquire ... | Conclusive verbs (stole, forged, embezzled) about any person. |
| **allegation** | A claim by a named or anonymous source that a specific irregularity occurred. Unverified; recorded as the source's claim. | Record of the claim, its source channel and date (a protected source is not cited in the report body). | It has been alleged that ... ; this is an allegation only. | Adopting the claim as a finding; citing the claim as evidence (R5). |
| **corroborated** | An allegation or suspicion supported by independent evidence from at least one source outside the originator, with innocent explanations tested and documented. | R1-R3 evidence independent of the originator; the alternative explanations tested. | Independent evidence (ref) corroborates the allegation that ... ; no conclusion on intent is drawn. | Intent, motive, or a legal characterisation. |
| **substantiated** | Facts established through a completed, documented investigation reviewed by counsel and decided by the authorised body. Internal Audit reports substantiated findings of fact; it does not make the legal determination. | Completed investigation file, R1-R3 evidence, counsel review. Standard of proof: [OPEN - owner: Legal/Group; interim: ladder vocabulary only]. | The investigation substantiated that (facts); the legal characterisation rests with (body). | Motive; sanctions; any statement beyond the established facts. |

## Model & Effort Routing (Rule 32)

Rendered from `skills/model-effort-routing/data/matrix.json`. Selector: `skills/model-effort-routing/scripts/select_model_effort.py`.

| Tier | Role | Typical work | Default effort |
|---|---|---|---|
| **Planner (currently Opus)** | Master strategic planner / brain | Scope, risk-based plan, work breakdown, agent briefs, routing, conflict resolution, final judgement on opinion/ratings, sign-off of conclusions | plans only; executes nothing without user approval |
| **Sonnet** | Professional executor | Fieldwork, ToD/ToE, reconciliations, analytics, statutory/regulatory web-validation, fraud analytics, root cause, finding drafting, report drafting, independent QA/critique | medium (high for: statutory validation, fraud wording, reconciliations, Board/AC-grade drafting, independent QA) |
| **Haiku** | Volume executor | File inventory, document extraction, data cleaning, search/lookup, checklist and template population, formatting, tie-out of simple counts | low |

Operating rules:

1. Planner writes one plan and one complete brief per agent (objective, inputs/paths, output file, acceptance test) so no agent re-reads or re-derives context.
2. Independent subtasks are dispatched in parallel; the planner keeps planning while they run and intervenes only on drift, hallucination, overrun or missing context.
3. Escalate, don't gamble: Haiku output that fails its acceptance test is re-run on Sonnet; a Sonnet output on a judgement-heavy point goes to planner review.
4. Never downgrade model or effort on: statutory rates/dates (Rules 02-03), fraud-ladder wording, the audit opinion and ratings, or independent QA (QA always on a different agent from the preparer).
5. Every agent writes its output to disk; the planner reads results, not raw evidence already summarised.
6. Planner may set agent `model` and `effort` explicitly - Rule 32 is the standing user instruction that authorises it.

## Namespaces

- **RACM**: RACM-01..RACM-12 control-matrix work (see references/namespaces.md)
- **RC**: RC-01..RC-12 report conversion work (see references/namespaces.md)
- **GR**: GR-01.. runtime controls enforced by gia-core:runtime-guard; mapped to rules in the gr-mapping reference of gia-core:runtime-guard
- **LNT**: Lint codes emitted by gia-core:safeguard-lint
