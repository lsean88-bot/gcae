# Scheduled governance drift check

A ready-to-use task definition. It is not running until a scheduled task is created from it; this file does not register a schedule.

## Cadence

Weekly. Drift accumulates over roughly two weeks of active skill development; weekly catches it before another independent QA pass is needed, without noise.

## Task prompt

```
Run the governance drift check and report it:

  bash <plugin-root>/skills/iron-rules/scripts/check-governance-drift.sh --suite <directory holding the installed GIA plugins>

Report the exit code and full output.
- Non-zero exit: list each finding in plain language, one line each, with the file and the mismatch. Do not fix anything automatically; this is report-only. Say whether a finding is new content or a regression of something already reconciled.
- Exit 0: report one line, clean.
```

## Verify the path before relying on it

A scheduled task may not see the same filesystem as an interactive session. Run the command manually once in the target environment and confirm the plugin root and `--suite` directory resolve. If they do not, point the task at the directory where the plugins are actually installed. Do not assume either location.

## What it catches

Colliding or restated rule lists, gate sizes other than 12, parallel evidence tables, asserted rule totals, retired references, missing Charlie Hills phases, and Rule 30 self-consistency of `rules.json`, `references/rules.md` and `SKILL.md`.

## What it does not catch

Semantic duplication where a skill restates the same principle in different words without colliding on a number. That needs a reader. Do not treat a clean run as a complete governance review.

## Extending

New numbered namespace: add its skill to `NAMESPACED_HOLDERS` in the script. A new enumerated gate size is not expected: Rule 09 fixes the gate at 12.
