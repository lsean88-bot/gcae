# Reconciliation History

Condensed record of how this skill's content was established. Full detail (per-file diffs,
decision rationale, residual risk discussion) is in `reconciliation-closure-memo.md` and
`iron-rules-reconciliation-report.md`, produced alongside this skill on 27-28 July 2026.

## What was found

1. Two numbering lineages had diverged around Rules 10–12, never merged back.
2. Four unrelated statements were simultaneously rule number 12 in different skills.
3. A skill claimed "20 Iron Rules" while only 8 were ever written down anywhere in it.
4. The evidence hierarchy (R1–R5) had three incompatible definitions across three skills.
5. A "quality gate" was asserted at three sizes (10/12/14 items); two were never enumerated.
6. A portfolio record claimed `mac-audit-constitution-l99` had already been retired to a
   stub. It hadn't.
7. A separate package's documentation claimed a different, more thorough reconciliation
   had already happened weeks earlier. It hadn't been applied to the live files.
8. `charlie-hills-code`, cited by 11 skills as defining a 5-phase protocol, didn't define it.
9. `racm-ecosystem` had its own complete 12-rule list, missed by the first sweep because
   it used "IRON RULES" as an all-caps header rather than the exact phrase being searched.
10. An earlier fix, already committed and reported complete, turned out to be incomplete —
    `cae-cowork-plugin-v5`'s own primary rule table, duplicated across four of its own
    files, was untouched by the commit that claimed to fix it.
11. `cae-report-conversion` had a fourth independently-numbered 12-rule list, found only
    on a second independent QA pass.

Findings 6, 7, and 10 share a root cause: written records repeatedly described
reconciliation as complete without the live source reflecting it. The only fix that
actually worked was re-verifying against source every time, with a different search
strategy each pass — not trusting the previous pass's own conclusion.

## Decisions made

- Kept Lineage 1's numbering (Rules 1–20) as the backbone; added Lineage 2's four unique
  rules as 21–24, plus one further rule (25, "no motive in a finding") found separately.
- Merged the evidence hierarchy: kept the original R1/R2/R4/R5 definitions, adopted the
  sharper R2/R3 independence test from a competing version rather than either wholesale.
- Did not retire `mac-audit-constitution-l99` — de-framed its competing "MASTER" claim,
  left retirement pending a full Article-by-Article check that was never run.
- Standardized the quality gate on the only version that was actually enumerated (12
  items), rather than the two that were only ever asserted by count.
- Gave `racm-ecosystem` and `cae-report-conversion` their own namespaces (`RACM-`, `RC-`)
  rather than forcing genuinely domain-specific content into the general numbering.
- Rewrote `charlie-hills-code` around the 5-phase cycle everyone else already assumed it
  meant, preserving all of its original content.

## Commit history (`/mnt/skills/user`, chronological)

```
ff9cadc Add canonical Iron Rules + Evidence Hierarchy + Quality Gate reference doc
312b740 (retired L99 plugin): add Rules 21-25, merge Evidence Hierarchy R3 test
f79090c mac-audit-constitution-l99: de-frame from competing MASTER status
0a52b0f cae-audit-cowork-plugin: pointer note to canonical doc
d0eefcf cae-audit-cowork-plugin-v4: renumber Lineage-2 rules to canonical
2c0feac cae-cowork-plugin-v5: merge Evidence Grading table (incomplete — see 6a0ac8c)
c049ce6 cae-cowork-ai-plugin: fix Rule 11/Rule 02 duplication, Panel 15 pointer
f4fd714 audit-risk-ecosystem: renumber to canonical, fix quality gate count
2c8264d group-cae-fraud-v2: renumber no-motive rule to canonical Rule 25
509900c charlie-hills-code realign; racm-ecosystem RACM-01-12 namespace
6a0ac8c cae-cowork-plugin-v5 complete fix; cae-report-conversion RC-01-12 namespace
2f18e45 cae-audit-cowork-plugin-v4: pointer note on redundant Finding Iron Rules restatement
```

## Explicitly not done

- `mac-audit-constitution-l99`'s full ~27-Article cross-check (only the 15 shared Iron
  Rules were verified word-for-word against the retired L99 plugin).
- Confirming whether the unenumerated 10-item and 14-item quality gates were actually
  equivalent to, weaker than, or stronger than the 12-item version adopted as canonical.
- Resolving the retired sentinel plugin's documentation discrepancy (finding 7) — flagged, not
  investigated further.

## Correction — 27 September 2026

The "Decisions made" section above states: *"Rewrote `charlie-hills-code` around the
5-phase cycle everyone else already assumed it meant, preserving all of its original
content."* Re-verified against the live file this session (per Rule 27, added the same day
— don't carry forward a prior conclusion without re-checking it against source): this is
not what the live file contains. `charlie-hills-code` currently defines its own 6-item
"Workflow Orchestration" list and 6-step "Task Management Protocol," not a bare
Plan/Verify/Execute/Check/Log structure. This is left in place above rather than edited, so
the record shows what was originally concluded and what the correction actually was — see
the matching correction in the retired charlie-hills summary and the Open Findings Register for the recommended next step. This is itself another instance of the pattern
"Findings 6, 7, and 10" above already named: a written record describing something as fixed
that the live source doesn't reflect. Re-verifying against source, not against the previous
pass's conclusion, is what caught it this time too.

## Residual risk

Two independent QA passes each found real problems the pass before missed. The
methodology improved each round; the final pass found only one minor, non-colliding
duplication. That's a reasonable basis for confidence in this document — not a claim that
it's provably exhaustive. Anyone extending this skill later should re-verify against the
actual live skill files rather than trusting this document's account of them, consistent
with Rule 12.
