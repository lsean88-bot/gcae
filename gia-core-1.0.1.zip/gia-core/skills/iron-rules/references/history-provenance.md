# Provenance, amendment log and open findings

A record, not live guidance. Contents: Provenance - Amendment log - Disposition of the master-skill draft - Open findings register (state at consolidation) - Commit lineage.

## Provenance

`gia-core:iron-rules` is the single successor to the standalone `iron-rules-governance` skill, which packaged a reconciliation completed 27-28 July 2026 against nine skills that each carried a drifting copy of the same governance content (the L99 engine, the MAC constitution, three cowork plugin generations, the audit-risk ecosystem, the fraud v2 skill). Findings and decisions of that reconciliation: `history-reconciliation-2026-07.md`. Drift-check evidence: `history-drift-check-2026-09-27.md`.

## Amendment log

| Date | Change | Authority |
|---|---|---|
| 8 Aug 2026 | Deterministic drift script added; residual 10/14-item gate claims and a 20-rule block found and fixed; Rule 26 added | user request |
| 27 Sep 2026 | Rules 27-29 and the Golden Rule added from a user-supplied draft; Self-Learning Loop pointer added | user request |
| 27 Sep 2026 | Rule 30 (self-consistency) added; Check 6 and lesson template added | user request |
| 27 Sep 2026 | Golden Rule corollary and Rules 31-32 (specialist team; token economy) added | user mandate |
| 12-14 Oct 2026 | Rules 33-39 added (disclosure calibration; item naming; tie-out; balance; sensitive-matter routing; basis of statements; source-report reconciliation; confounders and cut-offs) | user request |
| 20 Oct 2026 | Rule 32 expanded (planner-tier model plans only; Sonnet/Haiku execute); Model & Effort Routing matrix added | user request |
| 29 Oct 2026 | Packaged as `gia-core:iron-rules` with rules as data (`rules.json`) and rendered text; fraud ladder defined; Charlie Hills protocol defined here; history and open findings moved to references | consolidation build |
| 29 Oct 2026 | AMENDMENT: the standard concise IA report plus Excel working paper is canonical (Profile A auditee/EXCO; Profile B Board/AC/Chairman). The 13-section structure is a legacy conversion reference only. This replaces the earlier statement that the 13-section structure stays canonical | approved by the user, 29 Oct 2026 (Rule 20 go-ahead); also logged in the plugin CHANGELOG |

## Disposition of the master-skill draft (27 Sep 2026)

| Draft item | Disposition |
|---|---|
| Zero hallucination - never trust prior AI text | Added as Rule 27 (adjacent Rules 02 and 12 do not cover trusting the model's own drift) |
| Ground-truth supremacy - user annotations outrank AI narrative | Added as Rule 28 |
| Absolute token economy | Initially not added; superseded 27 and 20 Oct by Rule 32 |
| No meta-commentary in outputs | Added as Rule 29, narrowed to final deliverables |
| Value-addition over fault-finding | Not a numbered rule; a standing reporting-style preference |
| Agentic orchestration protocol | Not merged; superseded in part by Rule 32 and the routing matrix |
| `/independent-qa` command | Confirmed not to exist at the time; the Quality Gate plus human review performs the function. `gia-report-qa:gia-report-qa` now provides independent QA |
| Four-section standard output structure | Not adopted at the time. Superseded 29 Oct 2026 by the approved amendment above |

## Open findings register (state at consolidation, 29 Oct 2026)

| # | Finding at 27 Sep 2026 | Disposition in this build |
|---|---|---|
| 1 | `charlie-hills-code` did not implement the five-phase cycle cited by ten skills | Resolved: the five-phase protocol is defined in `references/charlie-hills.md`; the drift script (Check 4) guards it; coding checklist moved to `gia-core:self-learning` |
| 2 | `charlie-hills-code` carried a second self-update rule duplicating the Kaizen promotion rules | Resolved: one promotion path, `gia-core:self-learning` (promotion needs the user's go-ahead, Rule 20) |
| 3 | Gate-size claims other than 12 live in four cowork-plugin generations and one registry | Retired with those skills; the drift script (Check 3) flags any recurrence. Build-time scan of the five new plugins is recorded in `tests/RESULTS.md` |
| 4 | Bare `RULE N` lists live in three skills | Drift Check 1 flags any recurrence outside this skill |
| 5 | R1-R5-shaped tables in two skills (informational) | Drift Check 5 flags any table outside this skill |
| 6 | Drift scan covered one install path only | Script now takes any number of skills directories or `--suite <dir>` |

Rule 30 recurrence note: the gate-count pattern recurred after being fixed once (8 Aug, again 27 Sep). Under Rule 20's own trigger this is a standing pattern, now covered by a scheduled check (`references/scheduled-drift-check.md`) instead of repeat one-off cleanups.

## Commit lineage of the predecessor skill

Canonical doc added (ff9cadc); L99 Rules 21-25 and R3 test merged (312b740); MAC constitution de-framed (f79090c); cowork generations pointed or renumbered (0a52b0f, d0eefcf, 2c0feac, c049ce6, 6a0ac8c, 2f18e45); audit-risk ecosystem and fraud v2 renumbered (f4fd714, 2c8264d); coding skill realign and RACM namespace (509900c).
