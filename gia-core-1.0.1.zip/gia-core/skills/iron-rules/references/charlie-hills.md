# Charlie Hills protocol (Plan - Verify - Execute - Check - Log)

The standing workflow requirement cited across the GIA skills. This file is the single definition. It replaces the retired `charlie-hills-code` skill as the owner of the five-phase name; that skill's coding-specific checklist is carried in `gia-core:self-learning` (`skills/self-learning/references/coding-workflow.md`).

Resolution of the earlier conflict: the old coding skill defined a different six-item workflow while ten other skills cited a five-phase cycle. The five-phase cycle below is canonical for all GIA work; the coding checklist is a specialisation, not a rival definition.

## Phase 1 - Plan

Enter plan mode for anything non-trivial (three or more steps, or an architectural decision). Write the plan down before acting. If something goes sideways mid-task, stop and re-plan; do not push through.

## Phase 2 - Verify

Verify the plan itself with whoever signs it off, not merely that a plan exists. Before committing to an approach, ask whether a simpler or more robust way exists. Do this before executing, not only before presenting.

## Phase 3 - Execute

Do the work. Delegate research and parallel exploration (Rules 31-32). Track progress as items complete. Simplicity first: touch the minimum necessary, find root causes rather than patching symptoms, avoid side effects.

## Phase 4 - Check

Never mark work complete without proving it: run the test, check the log, re-perform the number, demonstrate the behaviour. Ask honestly whether a senior reviewer would approve it. Deliverables go through the Quality Gate (Rule 09) and independent QA (Rule 31).

## Phase 5 - Log

Record what was actually done, not only that it is done. If a correction arrived during the work, capture the lesson through `gia-core:self-learning`. If a pattern recurred, propose the standing-rule change there; it takes effect only with the user's explicit go-ahead (Rule 20).

## Status

The Log phase now has a concrete destination and a runnable script (`gia-core:self-learning`, script log_lesson.py). Whether it is exercised reliably every time it should be is observed over sessions, not assumed.
