# Engagement-specific rule namespaces

These lists are separate from the general Iron Rules because the content is engagement-specific. Each owns a prefix so numbers never collide with `gia-core:iron-rules`.

Contents: RACM-01..12 (control-matrix work) - RC-01..12 (legacy report conversion) - GR (runtime controls) - LNT (lint codes).

## RACM-01 to RACM-12 (control-matrix work)

```
RACM-01  Every key control must have a named owner - no anonymous controls
RACM-02  Every control description must state WHAT, WHEN, WHO, and HOW
RACM-03  Risk rating must reflect inherent risk - not residual (record both)
RACM-04  COSO component must be assigned - "Unknown" is not acceptable
RACM-05  ToD must precede ToE - never test operating effectiveness of a poorly designed control
RACM-06  Deficiency classification must follow the CD/SD/MW framework - no "management judgement" overrides without documented rationale
RACM-07  All deficiencies must have a management response before report issuance
RACM-08  Red flags must be investigated and closed or accepted - never ignored
RACM-09  Version snapshot before any bulk change or AC presentation
RACM-10  The four ICAI Guidance Note areas (ELC, SoD, Physical Verification, Cross-Division) must be explicitly addressed in any ICFR opinion [UNVERIFIED against the current Guidance Note edition]
RACM-11  Automated controls cannot be relied upon if ITGC is ineffective (same substance as Rule 23 - cite either)
RACM-12  Follow the Charlie Hills protocol (references/charlie-hills.md) for every RACM action
```

Owner of the full RACM method: `gia-audit:gia-racm-icfr-testing`. The deficiency scale is CD / SD / MW (the former "MN" label maps to CD).

## RC-01 to RC-12 (legacy report conversion)

Applies only when converting a supplied legacy report into the current format. The current report standard is the concise IA report plus Excel working paper (owner: `gia-report-qa:gia-ia-report`).

```
RC-01  No finding without named source reference - traceable to the source report
RC-02  No content creation - every element must exist in the source
RC-03  Risk ratings preserved exactly - no upgrades or downgrades
RC-04  Management responses verbatim - no paraphrasing
RC-05  Missing content goes to the Exception Log - never reconstruct
RC-06  Editorial changes only are logged in the Migration Change Log
RC-07  File naming: underscores only - no asterisks, spaces, or special characters
RC-08  The conversion QA checklist must fully pass before Final status
RC-09  Exception Log must be empty of unresolved Critical items before Final
RC-10  BLUF no longer than five sentences; Executive Summary no longer than one page
RC-11  Follow the Charlie Hills protocol every time
RC-12  Disclaimer on every page footer - professional IA report, not a CA or legal opinion
```

RC-11 and RACM-12 point to `references/charlie-hills.md`. RACM-11 is the only line in either list that maps onto a general rule (Rule 23).

## GR (runtime controls)

`GR-01`..`GR-19` are runtime controls enforced by hooks in `gia-core:runtime-guard`. They are not rules a model can interpret; each is mapped to the Iron Rules it serves in that skill's gr-mapping reference.

## LNT (lint codes)

`LNT-*` codes are findings emitted by `gia-core:safeguard-lint`. Each code names the Iron Rule it supports in that skill's codes reference.
