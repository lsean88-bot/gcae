---
name: iron-rules
description: "Single source of truth for the Golden Rule, Iron Rules, Evidence Hierarchy R1-R5, the 12-item Quality Gate, the fraud ladder and the Rule 32 model policy. Use when citing, applying or checking an iron rule, grading evidence, running the Quality Gate, choosing fraud wording or proposing a rule. Do NOT use for hook enforcement (use gia-core:runtime-guard) or linting (use gia-core:safeguard-lint)."
---

# Iron rules

Canonical governance for every GIA skill. If another skill's text disagrees with this one, this one wins and the other copy is stale: point it here, do not restate rules.

## Golden Rule

Ground truth outranks narrative: re-derive, never re-trust. Every claim in a deliverable traces to named evidence, a web-validated primary source, or the user's own explicit correction at the moment of output, never to an earlier draft, an earlier session or the model's own prior reasoning. Where no numbered rule covers a situation, apply the Golden Rule directly, then propose a rule (procedure 5).

Operating corollary (Rules 31-32): every engagement is run by a specialist team led by a Chief Specialist who plans and delegates; independent QA re-performs key numbers before drafting; the planner-tier model plans only and Sonnet or Haiku execute. Matrix and selector: `gia-core:model-effort-routing`.

## Where things live

| Need | Read |
|---|---|
| Rule text, enforcement map, evidence hierarchy, Quality Gate, fraud ladder, Rule 32 matrix | `references/rules.md` (rendered from `rules.json`, the authority) |
| Plan-Verify-Execute-Check-Log | `references/charlie-hills.md` |
| Human decision gates (report issuance, AC/Board escalation, fraud notification) | `references/human-gates.md` |
| RACM-, RC-, GR-, LNT- namespaces | `references/namespaces.md` |
| Weekly drift check set-up | `references/scheduled-drift-check.md` |
| Provenance, amendment log, open findings, 2026 reconciliation | `references/history-provenance.md`, `references/history-*.md` |

## Procedures

1. **Cite a rule.** Write `gia-core:iron-rules Rule 25`. Never state a total count of rules or gate items in prose; counts drift (Rule 30). The only enumerated gate is the 12-item Quality Gate (Rule 09).
2. **Grade evidence.** Assign R1-R5 from `references/rules.md`. Cite only R1-R4 in a finding; R5 never (Rule 06). R3 needs independent verification beyond a signature: a signed management representation letter is R4. Analytics output is an indicator, never evidence (Rule 17).
3. **Run the Quality Gate.** All 12 items must pass before a report is FINAL (Rule 09). The gate checks the finished artifact; the Independent QA Gate in `gia-report-qa:gia-report-qa` is a separate multi-pass review. Do not merge the two or say "the gate" without naming which.
4. **Place a fraud statement on the ladder.** Order: weakness, indicator, suspicion, allegation, corroborated, substantiated. State the rung the evidence supports and no higher; never motive (Rule 25); roles not names (Rule 36). Rung definitions, minimum evidence and wording are in `references/rules.md`. Internal Audit reports facts at a rung; legal characterisation, sanctions and standard of proof belong to counsel and the authorised body. The standard of proof is an open dependency owned by Legal/Group; until set, use ladder vocabulary only.
5. **Propose a standing rule or change (Rule 20).** A portfolio-wide rule is written here, not invented as a local fix. Draft it with `gia-core:self-learning` (rule-proposal template), show the exact text, and obtain the user's explicit go-ahead before editing. Then edit `rules.json`, run `scripts/render_rules.py`, run `scripts/test_rules.py` and the drift check. A rule changed without the go-ahead is a Rule 12 breach.
6. **Report format policy (amended 29 Oct 2026, approved).** The standard concise IA report plus an Excel working paper is canonical. Profile A is for the auditee and EXCO. Profile B is for the Board, Audit Committee and Chairman: tables over narrative, no workpaper row references, no methodology self-commentary. The 13-section structure is a legacy conversion reference only (see `gia-report-qa:gia-ia-report`). Disclosure follows Rules 33-39 via `gia-report-qa:gia-disclosure-calibration`.
7. **Stop at the human gates.** Report issuance, AC/Board escalation and fraud notification are the user's decision, always (`references/human-gates.md`).
8. **Planner discipline (Rule 32).** The planner plans, briefs and signs off; it does no execution without the user's approval. Economy never downgrades statutory validation, fraud wording, the audit opinion or independent QA.

## Scripts

| Script | Use |
|---|---|
| `scripts/render_rules.py [--check]` | Render `references/rules.md` from `rules.json`; `--check` fails if out of date |
| `scripts/test_rules.py` | Self-consistency tests: contiguous rule ids, 12-item gate, R1-R5, six-rung ladder, rendered text in sync, no asserted totals, amendment present, lint codes exist |
| `scripts/check-governance-drift.sh [dirs] \| --suite DIR` | Cross-skill drift: restated rule lists, gate sizes, evidence tables, asserted totals, retired references, protocol phases, Rule 30 self-consistency. Exit 1 on findings |

## Limits

The drift check finds mechanical drift only; semantic restatement needs a reader. Behavioural rules are enforced by independent QA, not by code. Rule 30 applies to this skill itself: after any edit, run the render check and the tests before citing a number from it.
