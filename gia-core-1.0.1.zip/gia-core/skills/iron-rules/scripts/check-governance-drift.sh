#!/usr/bin/env bash
#
# check-governance-drift.sh - GIA governance drift check (gia-core:iron-rules)
#
# Deterministic, dependency-light (bash + grep + find; python3 only for the optional render check)
# detection of cross-skill governance drift: colliding rule lists, unenumerated item counts, stale
# phase names, parallel evidence tables, asserted rule totals, and retired references.
# It does NOT replace human judgement or independent QA: it catches mechanical, pattern-level
# regressions cheaply and repeatably.
#
# Usage:   check-governance-drift.sh [skills-dir ...]
#          check-governance-drift.sh --suite <dir-containing-plugins>   # scans <dir>/*/skills
# Default: the skills directory of the plugin that contains this script.
# Exit:    0 = clean, 1 = findings present, 2 = bad arguments (safe as a CI / scheduled-task gate)

set -uo pipefail
# Deliberately NOT `set -e`: grep returning 1 (no match) is a normal outcome throughout.

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OWN_SKILL="$(dirname "$HERE")"                 # .../skills/iron-rules
OWN_SKILLS_DIR="$(dirname "$OWN_SKILL")"       # .../skills

DIRS=()
while [ $# -gt 0 ]; do
  case "$1" in
    --suite) shift; for p in "$1"/*/skills; do [ -d "$p" ] && DIRS+=("$p"); done ;;
    -h|--help) sed -n 2,18p "$0"; exit 0 ;;
    *) DIRS+=("$1") ;;
  esac
  shift
done
[ ${#DIRS[@]} -eq 0 ] && DIRS=("$OWN_SKILLS_DIR")
for d in "${DIRS[@]}"; do
  [ -d "$d" ] || { echo "ERROR: '$d' is not a directory." >&2; exit 2; }
done

FINDINGS=0
SECTION=0
fail()    { FINDINGS=$((FINDINGS+1)); echo "  FINDING:"; }
pass()    { echo "  clean"; }
section() { SECTION=$((SECTION+1)); echo "--- Check ${SECTION}: $1 ---"; }

# Files scanned: every SKILL.md and references/*.md under each skills dir (history-*.md are records, not live guidance, and are skipped).
FILES=()
for d in "${DIRS[@]}"; do
  while IFS= read -r f; do FILES+=("$f"); done < <(find "$d" -maxdepth 3 \( -name SKILL.md -o -path '*/references/*.md' \) -type f ! -name 'history-*' 2>/dev/null | sort)
done

echo "=== GIA Governance Drift Check - $(date -u +%Y-%m-%dT%H:%M:%SZ) ==="
printf 'Scanning: %s\n' "${DIRS[@]}"
echo "Files in scope: ${#FILES[@]}"
echo

# --------------------------------------------------------------------------------------------
# Allowlists - the ONE place drift-check maintenance happens.
#   CANONICAL_RULE_HOLDERS: skills that may carry the numbered rule list and the R1-R5 table.
#   NAMESPACED_HOLDERS:     skills with their own deliberate namespace (RACM-/RC-/GR-/LNT-).
#   KNOWN_QUALITY_GATE_COUNTS: the only enumerated gate size (Rule 09).
# --------------------------------------------------------------------------------------------
CANONICAL_RULE_HOLDERS="/iron-rules/"
NAMESPACED_HOLDERS="/runtime-guard/|/safeguard-lint/"
KNOWN_QUALITY_GATE_COUNTS="12"

scan() { # scan <grep-args...> : run grep over FILES, print matching lines/files
  [ ${#FILES[@]} -eq 0 ] && return 0
  grep "$@" "${FILES[@]}" 2>/dev/null
}

# --------------------------------------------------------------------------------------------
section "unnamespaced numbered rule lists outside the canonical holder"
HITS=$(scan -lE "^RULE [0-9]+:|^RULE [0-9]+ " | grep -Ev "$CANONICAL_RULE_HOLDERS" || true)
if [ -n "$HITS" ]; then
  fail; echo "$HITS" | sed 's/^/    /'
  echo "  -> Give the list a namespace (RACM-/RC-/GR-) or cite gia-core:iron-rules instead of restating rules."
else pass; fi
echo

# --------------------------------------------------------------------------------------------
section "IRON RULES headers outside the canonical holder"
HITS=$(scan -liE "^#+.*iron rules" | grep -Ev "${CANONICAL_RULE_HOLDERS}|${NAMESPACED_HOLDERS}" || true)
if [ -n "$HITS" ]; then
  fail; echo "$HITS" | sed 's/^/    /'
  echo "  -> Replace with a one-line pointer to gia-core:iron-rules plus rule numbers."
else pass; fi
echo

# --------------------------------------------------------------------------------------------
section "quality-gate item counts other than the enumerated 12"
HITS=$(scan -noiE "[0-9]+-item[a-z ]*gate|gate[a-z ]*\([0-9]+ item|[0-9]+ items? (quality )?gate" \
       | grep -Eiv "(${KNOWN_QUALITY_GATE_COUNTS})-item|\((${KNOWN_QUALITY_GATE_COUNTS}) item|(^|[: ])(${KNOWN_QUALITY_GATE_COUNTS}) items? (quality )?gate" || true)
if [ -n "$HITS" ]; then
  fail; echo "$HITS" | sed 's/^/    /'
  echo "  -> Only the 12-item Quality Gate (Rule 09) is enumerated. Other counts are unenumerated assertions."
else pass; fi
echo

# --------------------------------------------------------------------------------------------
section "Charlie Hills protocol: all five phases defined in gia-core:iron-rules"
CH_FILE="$OWN_SKILL/references/charlie-hills.md"
if [ -f "$CH_FILE" ]; then
  MISSING=""
  for PHASE in Plan Verify Execute Check Log; do
    grep -qiE "^## Phase [0-9]+ - ${PHASE}" "$CH_FILE" || MISSING="$MISSING $PHASE"
  done
  if [ -n "$MISSING" ]; then fail; echo "    charlie-hills.md is missing phase header(s):$MISSING"; else pass; fi
else
  fail; echo "    $CH_FILE not found"
fi
echo

# --------------------------------------------------------------------------------------------
section "R1-R5 evidence tables outside the canonical holder"
HITS=$(scan -lE "^\| ?\**R1\**:? ?\|" | grep -Ev "$CANONICAL_RULE_HOLDERS" || true)
if [ -n "$HITS" ]; then
  fail; echo "$HITS" | sed 's/^/    /'
  echo "  -> Evidence grades are defined once, in gia-core:iron-rules. Point to it."
else pass; fi
echo

# --------------------------------------------------------------------------------------------
section "asserted rule totals outside the canonical holder (cite rule numbers, never a total)"
HITS=$(scan -noiE "[0-9]+ (canonical |master |numbered )?iron rules|iron rules \([0-9]+ rules\)|all [0-9]+ (iron )?rules" | grep -Ev "$CANONICAL_RULE_HOLDERS" || true)
if [ -n "$HITS" ]; then
  fail; echo "$HITS" | sed 's/^/    /'
  echo "  -> A total drifts the moment a rule is added (Rule 30). Cite 'gia-core:iron-rules Rule NN'."
else pass; fi
echo

# --------------------------------------------------------------------------------------------
section "retired references (the old orchestrator name, the retired sentinel plugin name)"
HITS=$(scan -noE "\bF[a]ble\b|f[a]ble-orchestrator|mktron-sentine[l]" | grep -Ev "/MIGRATION|CHANGELOG" || true)
if [ -n "$HITS" ]; then
  fail; echo "$HITS" | sed 's/^/    /'
  echo "  -> Both are retired. Orchestrator = the planner tier in gia-core:model-effort-routing; sentinel skills were not shipped."
else pass; fi
echo

# --------------------------------------------------------------------------------------------
section "self-consistency of gia-core:iron-rules (Rule 30)"
RULES_JSON="$OWN_SKILL/rules.json"
RULES_MD="$OWN_SKILL/references/rules.md"
SKILL_MD="$OWN_SKILL/SKILL.md"
if [ -f "$RULES_MD" ] && [ -f "$RULES_JSON" ]; then
  SELF=0
  ACTUAL_RULES=$(grep -cE "^RULE [0-9]+:" "$RULES_MD")
  JSON_IDS=$(grep -oE '^   *"id": [0-9]+' "$RULES_JSON" | wc -l | tr -d ' ')
  if [ "$ACTUAL_RULES" != "$JSON_IDS" ] && [ "$JSON_IDS" != "0" ]; then
    [ "$SELF" -eq 0 ] && fail; SELF=1
    echo "    rules.md enumerates $ACTUAL_RULES rules; rules.json has $JSON_IDS rule ids"
  fi
  GATE_ASSERT=$(grep -oE "^## Quality Gate - [0-9]+ items" "$RULES_MD" | grep -oE "[0-9]+" | head -1)
  GATE_ACTUAL=$(grep -cE "^- \[ \]" "$RULES_MD")
  if [ -n "$GATE_ASSERT" ] && [ "$GATE_ASSERT" != "$GATE_ACTUAL" ]; then
    [ "$SELF" -eq 0 ] && fail; SELF=1
    echo "    rules.md heading asserts $GATE_ASSERT gate items; $GATE_ACTUAL checkbox lines found"
  fi
  if [ -f "$SKILL_MD" ]; then
    ASSERTED=$(grep -oiE "iron rules \(([0-9]+) rules\)|([0-9]+) iron rules" "$SKILL_MD" | grep -oE "[0-9]+" | head -1)
    if [ -n "$ASSERTED" ] && [ "$ASSERTED" != "$ACTUAL_RULES" ]; then
      [ "$SELF" -eq 0 ] && fail; SELF=1
      echo "    SKILL.md asserts $ASSERTED rules; $ACTUAL_RULES are enumerated"
    fi
  fi
  if command -v python3 >/dev/null 2>&1 && [ -f "$HERE/render_rules.py" ]; then
    if ! python3 -I "$HERE/render_rules.py" --check >/dev/null 2>&1; then
      [ "$SELF" -eq 0 ] && fail; SELF=1
      echo "    references/rules.md is out of date with rules.json (run scripts/render_rules.py)"
    fi
  fi
  if [ "$SELF" -eq 1 ]; then
    echo "  -> Rule 30 violation inside the canonical skill - fix here first."
  else pass; fi
else
  fail; echo "    rules.json or references/rules.md missing under $OWN_SKILL"
fi
echo

echo "=== Summary ==="
if [ "$FINDINGS" -eq 0 ]; then
  echo "No findings across $SECTION checks."
  exit 0
else
  echo "$FINDINGS of $SECTION checks raised a finding - review above before relying on the flagged files."
  exit 1
fi
