#!/usr/bin/env python3
"""Render references/rules.md from rules.json (+ the Rule 32 matrix in gia-core:model-effort-routing).

rules.json is the single source of truth; rules.md is generated and must never be edited by hand.
Usage:
  python3 -I render_rules.py            # write references/rules.md
  python3 -I render_rules.py --check    # exit 1 if rules.md differs from what rules.json renders
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)
RULES = os.path.join(SKILL, "rules.json")
MATRIX = os.path.join(os.path.dirname(SKILL), "model-effort-routing", "data", "matrix.json")
OUT = os.path.join(SKILL, "references", "rules.md")


def load():
    with open(RULES, encoding="utf-8") as f:
        d = json.load(f)
    try:
        with open(MATRIX, encoding="utf-8") as f:
            m = json.load(f)
    except OSError:
        m = None
    return d, m


def enforcement_text(e):
    parts = []
    for k in ("lint", "runtime", "script"):
        if e.get(k):
            parts.append("%s: %s" % (k, ", ".join("`%s`" % x for x in e[k])))
    return "; ".join(parts) if parts else "behavioural (Quality Gate / independent QA)"


def render():
    d, m = load()
    ids = [r["id"] for r in d["rules"]]
    o = []
    o.append("# Iron Rules (rendered)")
    o.append("")
    o.append("Generated from `rules.json` by `scripts/render_rules.py`. Do not edit by hand. Cite as `gia-core:iron-rules` + rule number.")
    o.append("")
    o.append("Contents: Golden Rule - Iron Rules - Enforcement map - Evidence Hierarchy - Quality Gate - Fraud ladder - Model & Effort Routing - Namespaces")
    o.append("")
    o.append("## The Golden Rule")
    o.append("")
    o.append("> **%s**" % d["golden_rule"])
    o.append("")
    o.append("**Operating corollary.** " + d["golden_rule_corollary"])
    o.append("")
    o.append("## Iron Rules %02d-%02d" % (min(ids), max(ids)))
    o.append("")
    o.append("```")
    for r in d["rules"]:
        o.append("RULE %02d: %s" % (r["id"], r["text"]))
    o.append("```")
    o.append("")
    o.append("## Enforcement map")
    o.append("")
    o.append("| Rule | Category | Mechanical check |")
    o.append("|---|---|---|")
    for r in d["rules"]:
        o.append("| %02d | %s | %s |" % (r["id"], r["category"], enforcement_text(r["enforcement"])))
    o.append("")
    o.append("`lint` = code emitted by `gia-core:safeguard-lint`; `runtime` = control enforced by `gia-core:runtime-guard` (mapping in its gr-mapping reference); `script` = deterministic script. Behavioural rules are checked at the Quality Gate and by independent QA.")
    o.append("")
    o.append("## Evidence Hierarchy (R1-R5)")
    o.append("")
    o.append("| Rank | Definition | Citable in a finding? |")
    o.append("|---|---|---|")
    for e in d["evidence_hierarchy"]["ranks"]:
        o.append("| **%s** | %s | %s |" % (e["rank"], e["definition"], e["citable"]))
    o.append("")
    o.append("**The R3 test:** " + d["evidence_hierarchy"]["r3_test"])
    o.append("")
    q = d["quality_gate"]
    o.append("## Quality Gate - %d items (Rule %02d)" % (len(q["items"]), q["rule"]))
    o.append("")
    for it in q["items"]:
        o.append("- [ ] " + it)
    o.append("")
    o.append(q["note"])
    o.append("")
    fl = d["fraud_ladder"]
    o.append("## Fraud ladder")
    o.append("")
    o.append("Order: " + " > ".join(fl["order"]) + ". Never: " + fl["never"] + ".")
    o.append("")
    o.append("| Rung | Meaning | Minimum evidence | Permitted wording | Forbidden |")
    o.append("|---|---|---|---|---|")
    for r in fl["rungs"]:
        o.append("| **%s** | %s | %s | %s | %s |" % (r["rung"], r["meaning"], r["minimum_evidence"], r["wording"], r["forbidden"]))
    o.append("")
    if m:
        o.append("## Model & Effort Routing (Rule 32)")
        o.append("")
        o.append("Rendered from `skills/model-effort-routing/data/matrix.json`. Selector: `skills/model-effort-routing/scripts/select_model_effort.py`.")
        o.append("")
        o.append("| Tier | Role | Typical work | Default effort |")
        o.append("|---|---|---|---|")
        for k in ("planner", "sonnet", "haiku"):
            t = m["tiers"][k]
            eff = "plans only; executes nothing without user approval" if t["default_effort"] is None else t["default_effort"] + (" (high for: %s)" % t["high_effort_for"] if t.get("high_effort_for") else "")
            o.append("| **%s** | %s | %s | %s |" % (t["label"], t["role"], t["typical_work"], eff))
        o.append("")
        o.append("Operating rules:")
        o.append("")
        for i, r in enumerate(m["operating_rules"], 1):
            o.append("%d. %s" % (i, r))
        o.append("")
    o.append("## Namespaces")
    o.append("")
    for k, v in d["namespaces"].items():
        o.append("- **%s**: %s" % (k, v))
    o.append("")
    return "\n".join(o)


def main(argv):
    text = render()
    if "--check" in argv:
        try:
            cur = open(OUT, encoding="utf-8").read()
        except OSError:
            print("FAIL rules.md missing")
            return 1
        if cur != text:
            print("FAIL rules.md is out of date with rules.json (run render_rules.py)")
            return 1
        print("PASS rules.md matches rules.json")
        return 0
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        f.write(text)
    print("wrote", OUT)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
