#!/usr/bin/env python3
"""Consistency tests for gia-core:iron-rules.  Run: python3 -I scripts/test_rules.py   (exit 0 = all pass)

Checks the data, the rendered file, every enforcement reference, the fraud ladder, the quality gate, the evidence hierarchy,
and that no skill file asserts a total rule count (Rule 30). Never asserts how many rules there are.
"""
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)
PLUGIN = os.path.dirname(os.path.dirname(SKILL))
D = json.load(open(os.path.join(SKILL, "rules.json"), encoding="utf-8"))
RULES = D["rules"]
res = []


def t(name, ok, detail=""):
    res.append(bool(ok))
    print(("PASS  " if ok else "FAIL  ") + name + ((": " + str(detail)) if (detail and not ok) else ""))


def read(rel):
    return open(os.path.join(PLUGIN, rel), encoding="utf-8", errors="ignore").read()


ids = [r["id"] for r in RULES]
t("rule ids are unique and contiguous from 1", ids == list(range(1, len(ids) + 1)), ids)
t("every rule has text, category and an enforcement entry", all(r.get("text") and r.get("category") and isinstance(r.get("enforcement"), dict) for r in RULES))
t("every rule is either behavioural or names a lint, runtime or script check", all(r["enforcement"].get("behavioural") or any(r["enforcement"].get(k) for k in ("lint", "runtime", "script")) for r in RULES))
# enforcement references resolve
sys.path.insert(0, os.path.join(PLUGIN, "skills", "safeguard-lint", "scripts"))
try:
    import safeguard_lint as SL
    codes = set(SL.CODES)
except Exception as e:  # pragma: no cover
    codes, _err = set(), e
lint_refs = {c for r in RULES for c in r["enforcement"].get("lint", [])}
t("every lint code named in the enforcement map exists in safeguard-lint", lint_refs <= codes, sorted(lint_refs - codes))
gr_ids = {c["id"] for c in json.load(open(os.path.join(PLUGIN, "core", "policy", "runtime-controls.json")))["rules"]}
rt_refs = {c for r in RULES for c in r["enforcement"].get("runtime", [])}
t("every GR control named in the enforcement map exists in runtime-controls.json", rt_refs <= gr_ids, sorted(rt_refs - gr_ids))
scripts = {s for r in RULES for s in r["enforcement"].get("script", [])}
t("every script named in the enforcement map exists", all(os.path.exists(os.path.join(PLUGIN, s)) for s in scripts), sorted(s for s in scripts if not os.path.exists(os.path.join(PLUGIN, s))))
# quality gate, evidence, ladder, deficiency
qg = D["quality_gate"]
t("quality gate lists exactly 12 items", len(qg["items"]) == 12, len(qg["items"]))
t("quality gate is tied to the rule that names it", qg["rule"] == 9 and "12" in next(r["text"] for r in RULES if r["id"] == 9))
eh = json.dumps(D["evidence_hierarchy"])
t("evidence hierarchy covers R1 to R5 and keeps the strict R3 test", all(("R%d" % i) in eh for i in range(1, 6)) and "R3" in eh)
t("R5 is never citable as finding evidence (Rule 6)", "R5" in next(r["text"] for r in RULES if r["id"] == 6) and "NEVER" in next(r["text"] for r in RULES if r["id"] == 6))
t("fraud ladder is in the canonical order", D["fraud_ladder"]["order"] == ["weakness", "indicator", "suspicion", "allegation", "corroborated", "substantiated"])
t("fraud ladder rules out motive", "motive" in D["fraud_ladder"]["never"])
t("deficiency scale CD, SD, MW appears in the rules", "CD" in next(r["text"] for r in RULES if r["id"] == 15) and "MW" in next(r["text"] for r in RULES if r["id"] == 15))
# rendered output
p = subprocess.run([sys.executable, "-I", os.path.join(HERE, "render_rules.py"), "--check"], capture_output=True, text=True, timeout=60)
t("references/rules.md is current with rules.json", p.returncode == 0, p.stdout + p.stderr)
md = read("skills/iron-rules/references/rules.md")
t("rendered file has a contents line", "Contents:" in md[:1200])
t("rendered file carries every rule", all("RULE %02d:" % i in md for i in ids))
# Rule 30: no asserted totals outside the data, no retired names
bad = []
for dp, dn, fn in os.walk(os.path.join(PLUGIN, "skills")):
    dn[:] = [d for d in dn if d not in ("__pycache__", "tests", "fixtures")]
    for f in fn:
        if not f.endswith(".md") or f.startswith("history-"):
            continue
        txt = open(os.path.join(dp, f), encoding="utf-8", errors="ignore").read()
        for m in re.finditer(r"\b(\d+|thirty[- ]\w+|forty)\s+(?:iron\s+)?rules\b", txt, re.I):
            bad.append((os.path.relpath(os.path.join(dp, f), PLUGIN), m.group(0)))
t("no skill file asserts a total number of rules", not bad, bad[:5])
retired = [p for p in ("skills/iron-rules/SKILL.md", "skills/iron-rules/references/rules.md") if re.search(r"F[a]ble|mktron-sentine[l]", read(p))]
t("no retired names in the canonical files", not retired, retired)
prov = read("skills/iron-rules/references/history-provenance.md")
t("the 29-Oct-2026 report-format amendment is recorded", re.search(r"29[- ]Oct[- ]2026", prov) is not None and "13-section" in prov)
t("the iron-rules SKILL.md states the concise report plus Excel working paper as canonical", re.search(r"concise", read("skills/iron-rules/SKILL.md") + md, re.I) is not None)
print("\n%d tests, %d failed" % (len(res), res.count(False)))
sys.exit(0 if all(res) else 1)
