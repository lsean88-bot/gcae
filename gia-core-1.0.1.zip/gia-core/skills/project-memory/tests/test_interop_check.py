"""Tests for interop_check.py using synthetic skill trees (portable, no live catalog needed)."""
import sys
from pathlib import Path
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))
import interop_check as ic  # noqa: E402


def mk(root: Path, folder: str, name=None, desc="d", version=None, extra=None, body="body"):
    d = root / folder
    d.mkdir(parents=True, exist_ok=True)
    fm = ["---"]
    if name:
        fm.append(f"name: {name}")
    if desc:
        fm.append(f"description: {desc}")
    if version:
        fm += ["metadata:", f'  version: "{version}"']
    fm.append("---")
    (d / "SKILL.md").write_text("\n".join(fm) + "\n" + body + "\n")
    for rel, txt in (extra or {}).items():
        (d / rel).parent.mkdir(parents=True, exist_ok=True)
        (d / rel).write_text(txt)
    return d


@pytest.fixture
def eco(tmp_path):
    user, plugins = tmp_path / "user", tmp_path / "plugins"
    akos = mk(user, "akos", "akos", extra={
        "references/plugin-coordination-registry.md":
            "Uses `alpha-skill` and `beta-skill`, role `data-quality-specialist`, "
            "tool `ghost-skill`; `old-constitution` is retired and intentionally absent.\n",
        "references/agent-specifications.md": "- **Subagent file:** `agents/data-quality-specialist.md`.\n"})
    mk(plugins, "alpha-skill", "alpha-skill")
    mk(plugins, "beta-skill", "beta-skill")
    reg = akos / "references" / "plugin-coordination-registry.md"
    return tmp_path, reg


def codes(issues, code):
    return [i for i in issues if i["code"] == code]


def test_clean_ecosystem_flags_only_the_real_dead_reference(eco):
    tmp, reg = eco
    summary, issues = ic.run([str(tmp / "user"), str(tmp / "plugins")], reg, set())
    unresolved = {i["ref"] for i in codes(issues, "REF_UNRESOLVED")}
    assert unresolved == {"ghost-skill"}            # agent role + retired name exempted
    assert [i["ref"] for i in codes(issues, "REF_RETIRED")] == ["old-constitution"]
    assert summary["errors"] == 0


def test_non_skills_flag_exempts(eco):
    tmp, reg = eco
    _, issues = ic.run([str(tmp / "user"), str(tmp / "plugins")], reg, {"ghost-skill"})
    assert not codes(issues, "REF_UNRESOLVED")


def test_unregistered_only_for_user_and_plugins_roots(eco):
    tmp, reg = eco
    mk(tmp / "plugins", "orphan-audit", "orphan-audit")
    mk(tmp / "examples", "consumer-thing", "consumer-thing")
    _, issues = ic.run([str(tmp / "user"), str(tmp / "plugins"), str(tmp / "examples")], reg, set())
    refs = {i["ref"] for i in codes(issues, "UNREGISTERED")}
    assert "orphan-audit" in refs and "consumer-thing" not in refs


def test_duplicate_drift_reports_newer_copy_and_files(eco):
    tmp, reg = eco
    mk(tmp / "user", "dup", "dup", version="2.2", extra={"references/only_user.md": "x"})
    mk(tmp / "plugins", "dup-copy", "dup", version="2.1", extra={"evals/e.json": "{}"})
    _, issues = ic.run([str(tmp / "user"), str(tmp / "plugins")], reg, set())
    msg = codes(issues, "DUPLICATE_DRIFT")[0]["message"]
    assert "only_user.md" in msg and "e.json" in msg
    assert "NEWER: user/dup v2.2" in msg and "plugins/dup-copy v2.1" in msg


def test_identical_duplicate_is_info_not_warning(eco):
    tmp, reg = eco
    mk(tmp / "user", "same", "same", body="X")
    mk(tmp / "plugins", "same", "same", body="X")
    _, issues = ic.run([str(tmp / "user"), str(tmp / "plugins")], reg, set())
    assert codes(issues, "DUPLICATE_SAME") and not codes(issues, "DUPLICATE_DRIFT")


def test_frontmatter_errors_fail_the_run(eco):
    tmp, reg = eco
    mk(tmp / "plugins", "nodesc", "nodesc", desc=None)
    bad = tmp / "plugins" / "nofm"
    bad.mkdir()
    (bad / "SKILL.md").write_text("no frontmatter here\n")
    summary, issues = ic.run([str(tmp / "user"), str(tmp / "plugins")], reg, set())
    assert summary["errors"] >= 2 and codes(issues, "FM_MISSING")


def test_command_folder_alias_resolves(eco):
    tmp, reg = eco
    mk(tmp / "plugins", "data:build-dashboard", "build-dashboard")
    reg.write_text(reg.read_text() + "Use `data:build-dashboard` for heat maps.\n")
    _, issues = ic.run([str(tmp / "user"), str(tmp / "plugins")], reg, set())
    assert "data:build-dashboard" not in {i["ref"] for i in codes(issues, "REF_UNRESOLVED")}


def test_name_dir_mismatch_warns(eco):
    tmp, reg = eco
    mk(tmp / "plugins", "folder-a", "different-name")
    _, issues = ic.run([str(tmp / "user"), str(tmp / "plugins")], reg, set())
    assert codes(issues, "NAME_DIR_MISMATCH")


def test_missing_registry_is_error(eco):
    tmp, _ = eco
    summary, issues = ic.run([str(tmp / "user")], tmp / "nope.md", set())
    assert codes(issues, "REGISTRY_MISSING") and summary["errors"] == 1


# ---- v1.1: status semantics + supersession routing -----------------------------------
def test_unconfirmed_status_is_never_reported_as_retired(eco):
    tmp, reg = eco
    reg.write_text("Routes via `lost-skill`. Not established whether `lost-skill`'s absence is an intentional "
                   "retirement or an accidental drop - worth confirming.\n")
    _, issues = ic.run([str(tmp / "user"), str(tmp / "plugins")], reg, set())
    assert [i["severity"] for i in codes(issues, "REF_UNCONFIRMED")] == ["WARN"]
    assert not codes(issues, "REF_RETIRED")


def test_negated_retirement_is_not_retired(eco):
    tmp, reg = eco
    reg.write_text("History: we did not retire `kept-skill` - only de-framed it.\n")
    _, issues = ic.run([str(tmp / "user"), str(tmp / "plugins")], reg, set())
    assert not codes(issues, "REF_RETIRED")


def test_documented_retirement_is_info(eco):
    tmp, reg = eco
    reg.write_text("The `gone-skill` was retired in July and is superseded.\n")
    _, issues = ic.run([str(tmp / "user"), str(tmp / "plugins")], reg, set())
    assert codes(issues, "REF_RETIRED")[0]["severity"] == "INFO"


def _fm_skill(root, folder, name, supersedes):
    d = root / folder
    d.mkdir(parents=True, exist_ok=True)
    sup = "\n".join(f"    - {x}" for x in supersedes)
    (d / "SKILL.md").write_text(f"---\nname: {name}\ndescription: d\nmetadata:\n  supersedes:\n{sup}\n---\nbody\n")


def test_superseded_but_still_routed_is_flagged(eco):
    tmp, reg = eco
    mk(tmp / "plugins", "tool-v4", "tool-v4")
    _fm_skill(tmp / "plugins", "tool-v6", "tool-v6", ["tool v4.0", "tool-v6 v5.01"])
    reg.write_text(reg.read_text() + "Fieldwork goes to `tool-v4` and `tool-v6`.\n")
    _, issues = ic.run([str(tmp / "user"), str(tmp / "plugins")], reg, set())
    routed = [i for i in codes(issues, "SUPERSEDED_ROUTED")]
    assert routed and routed[0]["ref"] == "tool-v4"
    assert not any(i["ref"] == "tool-v6" for i in codes(issues, "SUPERSEDED_ROUTED"))  # self-reference ignored


def test_superseded_marked_legacy_in_registry_is_ok(eco):
    tmp, reg = eco
    mk(tmp / "plugins", "tool-v4", "tool-v4")
    _fm_skill(tmp / "plugins", "tool-v6", "tool-v6", ["tool v4.0"])
    reg.write_text(reg.read_text() + "`tool-v4` is legacy: superseded by `tool-v6`.\n")
    _, issues = ic.run([str(tmp / "user"), str(tmp / "plugins")], reg, set())
    assert not codes(issues, "SUPERSEDED_ROUTED") and codes(issues, "SUPERSEDED_INSTALLED")


def test_normalise_skill_ref_variants():
    known = {"cae-audit-cowork-plugin-v4", "cae-audit-cowork-plugin-v5", "cae-audit-cowork-plugin", "x"}
    f = lambda r: ic.normalise_skill_ref(r, known)  # noqa: E731
    assert f("cae-audit-cowork-plugin v4.0") == "cae-audit-cowork-plugin-v4"
    assert f("CAE-Audit-Cowork-Plugin-v5_0") == "cae-audit-cowork-plugin-v5"
    assert f("cae-audit-cowork-plugin (v2.0)") == "cae-audit-cowork-plugin"
    assert f("x") == "x" and f("nonexistent v1") is None


# ---- v1.2: table rows / bullets are separate judgement units -------------------------
def test_one_legacy_table_row_does_not_taint_other_rows(eco):
    tmp, reg = eco
    reg.write_text(
        "| Need | Invoke |\n|---|---|\n"
        "| Fieldwork | `new-tool` (v6; old is superseded legacy) |\n"
        "| Visuals | `canvas-thing` |\n"
        "| Reports | `report-tool` |\n")
    _, issues = ic.run([str(tmp / "user"), str(tmp / "plugins")], reg, set())
    status = {i["ref"]: i["code"] for i in issues if i["code"] in ("REF_RETIRED", "REF_UNRESOLVED", "REF_UNCONFIRMED")}
    assert status.get("canvas-thing") == "REF_UNRESOLVED" and status.get("report-tool") == "REF_UNRESOLVED"
    assert status.get("new-tool") == "REF_RETIRED"      # only its own row is judged


def test_bullets_and_bold_headers_are_separate_blocks():
    text = ("**`alpha-skill`**\n- *Reads:* a.\n- *Coordination note:* this is legacy, retired.\n"
            "**`beta-skill`**\n- *Reads:* b.\n")
    units = ic.sentences(text)
    assert any("legacy" in u for u in units)
    assert not any("legacy" in u and "beta-skill" in u for u in units)


def test_wrapped_prose_sentence_is_still_one_unit():
    text = "Not established whether `lost-skill`'s absence\nis an intentional retirement or an\naccidental drop.\n"
    assert len(ic.sentences(text)) == 1
    retired, unconfirmed = ic.classify_status([text])
    assert unconfirmed == {"lost-skill"} and not retired
