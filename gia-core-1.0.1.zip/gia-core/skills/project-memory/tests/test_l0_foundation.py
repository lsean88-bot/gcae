"""L0 foundation: errors, textsafe, strictjson, fsutil, schema, textnorm. Properties, fuzz, races, fault injection."""
import json, os, random, subprocess, sys, time, multiprocessing as mp
from pathlib import Path
import pytest

SCRIPTS = Path(__file__).resolve().parent.parent / "scripts"
sys.path.insert(0, str(SCRIPTS))
import errors, fsutil, schema, strictjson, textnorm, textsafe  # noqa: E402
from errors import InputError, RefusedError, LockTimeout  # noqa: E402


# ================================================================ errors.run_cli: the exit-code contract
@pytest.mark.parametrize("exc,code", [(InputError("x"), 2), (RefusedError("x"), 2), (LockTimeout("x"), 2),
                                      (FileNotFoundError("x"), 2), (PermissionError("x"), 2), (ValueError("x"), 2),
                                      (json.JSONDecodeError("m", "d", 0), 2), (OSError("disk full"), 2),
                                      (KeyboardInterrupt(), 130), (RuntimeError("bug"), 3), (KeyError("k"), 3)])
def test_run_cli_maps_every_outcome_to_the_contract(exc, code, capsys):
    def main(argv=None): raise exc
    assert errors.run_cli(main) == code
    err = capsys.readouterr().err
    assert "Traceback" not in err and len(err.strip().splitlines()) <= 1


def test_run_cli_passes_through_return_codes_and_hides_nothing_in_debug(monkeypatch):
    assert errors.run_cli(lambda argv=None: 0) == 0 and errors.run_cli(lambda argv=None: 1) == 1 and errors.run_cli(lambda a=None: None) == 0
    monkeypatch.setenv("GIA_DEBUG", "1")
    with pytest.raises(RuntimeError):
        errors.run_cli(lambda argv=None: (_ for _ in ()).throw(RuntimeError("bug")))


def test_error_messages_are_sanitised(capsys):
    errors.run_cli(lambda a=None: (_ for _ in ()).throw(InputError("bad \x1b[2J id\nnext")))
    err = capsys.readouterr().err
    assert "\x1b" not in err and err.count("\n") == 1


# ================================================================ textsafe
def test_display_escapes_every_dangerous_class():
    s = textsafe.display("a\x1b[31m\x00\x07\n\r\t\x7f\x9b\u202e\u2066\u200b\ufeffz")
    assert all(ch not in s for ch in ("\x1b", "\x00", "\x07", "\n", "\r", "\t", "\x7f", "\x9b", "\u202e", "\u2066", "\u200b", "\ufeff"))
    assert s.startswith("a\\x1b[31m") and s.endswith("z")


def test_display_truncates_and_never_raises():
    assert len(textsafe.display("x" * 10000, 50)) == 50
    class Bad:
        def __str__(self): raise RuntimeError("no")
    assert textsafe.display(Bad()) == "<unprintable>"


def test_property_display_output_is_always_safe():
    rnd = random.Random(7)
    for _ in range(2000):
        s = "".join(chr(rnd.choice([rnd.randrange(0, 0x100), rnd.randrange(0x2000, 0x2070), rnd.randrange(0xD800, 0xE000),
                                    rnd.randrange(0x20, 0x7F), rnd.randrange(0x4E00, 0x4F00), rnd.randrange(0x0B80, 0x0BFF)]))
                    for _ in range(rnd.randrange(0, 40)))
        out = textsafe.display(s, 10_000)
        assert not textsafe._UNSAFE.search(out)


def test_xlsx_text_rules():
    assert textsafe.xlsx_text("=1+1").startswith("'=") and textsafe.xlsx_text("@x").startswith("'@")
    assert textsafe.xlsx_text("a\x00\x07b") == "a\ufffd\ufffdb"
    assert len(textsafe.xlsx_text("y" * 40000)) < 32767 and textsafe.xlsx_text("y" * 40000).endswith("[truncated]")
    assert textsafe.xlsx_text(5) == 5 and textsafe.xlsx_text(None) is None and textsafe.xlsx_text(True) is True
    assert textsafe.xlsx_text({"a": 1}) == "{'a': 1}"
    assert textsafe.xlsx_text("\ud800 lone") == "\ufffd lone"


def test_property_xlsx_text_is_accepted_by_a_real_workbook(tmp_path):
    from openpyxl import Workbook, load_workbook
    rnd = random.Random(11)
    wb = Workbook(); ws = wb.active
    cases = []
    for _ in range(400):
        s = "".join(chr(rnd.choice([rnd.randrange(0, 0x30), rnd.randrange(0xD800, 0xE000), rnd.randrange(0x20, 0x7F), rnd.randrange(0x4E00, 0x4E40)]))
                    for _ in range(rnd.randrange(0, 30)))
        s = rnd.choice(["", "=", "+", "-", "@", "\t"]) + s
        ws.append([textsafe.xlsx_text(s)]); cases.append(s)
    f = tmp_path / "t.xlsx"; wb.save(f)                       # IllegalCharacterError would be raised here
    ws2 = load_workbook(f).active
    for row in ws2.iter_rows():
        v = row[0].value
        assert not (isinstance(v, str) and v.startswith("=")), "a live formula escaped"


# ================================================================ strictjson
def test_bom_is_accepted():
    assert strictjson.loads(b"\xef\xbb\xbf" + json.dumps({"a": 1}).encode(), "t") == {"a": 1}


@pytest.mark.parametrize("raw,fragment", [(b'{"a":1,"a":2}', "duplicate key 'a'"), (b'{"x":{"k":1,"k":2}}', "duplicate key 'k'"),
                                          (b"[NaN]", "NaN"), (b"[Infinity]", "Infinity"), (b"[-Infinity]", "Infinity"),
                                          (b'{"a":1}\x00', "NUL"), (b"\xff\xfe{}", "UTF-8"), (b"", "not valid JSON"),
                                          (b"{", "not valid JSON"), (b"[" * 200000 + b"]" * 200000, "nested too deeply")])
def test_strictjson_rejects_with_a_clear_message(raw, fragment):
    with pytest.raises(InputError, match=fragment):
        strictjson.loads(raw, "t.json")


def test_size_limit_and_missing_file(tmp_path):
    f = tmp_path / "big.json"; f.write_text('{"a": "' + "x" * 5000 + '"}')
    with pytest.raises(InputError, match="exceeds"):
        strictjson.load(f, max_bytes=1000)
    with pytest.raises(InputError, match="not found"):
        strictjson.load(tmp_path / "nope.json")
    assert strictjson.load(f)["a"].startswith("x")


def test_fuzz_mutated_json_never_raises_anything_but_inputerror():
    rnd = random.Random(3)
    base = json.dumps({"nodes": [{"id": "A", "label": "Nómina ஊதிய", "n": [1, 2.5, None, True]}], "edges": []}, ensure_ascii=False).encode()
    for _ in range(4000):
        b = bytearray(base)
        for _ in range(rnd.randrange(1, 6)):
            op = rnd.randrange(4); i = rnd.randrange(len(b))
            if op == 0: b[i] = rnd.randrange(256)
            elif op == 1: del b[i:i + rnd.randrange(1, 8)]
            elif op == 2: b[i:i] = bytes(rnd.randrange(256) for _ in range(rnd.randrange(1, 6)))
            else: b = b[:i]
            if not b: b = bytearray(b"x")
        try:
            strictjson.loads(bytes(b), "fuzz")
        except InputError:
            pass


def test_large_file_parses_in_reasonable_time(tmp_path):
    f = tmp_path / "l.json"
    f.write_text(json.dumps({"nodes": [{"id": f"N{i}", "label": "x " * 5} for i in range(150000)], "edges": []}))
    t = time.time(); strictjson.load(f); assert time.time() - t < 8


# ================================================================ fsutil: atomic writes
def test_atomic_write_content_mode_and_no_temp_left(tmp_path):
    p = tmp_path / "d" / "f.json"
    fsutil.atomic_write_json(p, {"é": 1}, 0o600)
    assert json.loads(p.read_text(encoding="utf-8")) == {"é": 1}
    if os.name == "posix": assert (p.stat().st_mode & 0o777) == 0o600
    assert [x.name for x in p.parent.iterdir()] == ["f.json"]


def test_atomic_write_failure_leaves_old_file_and_no_temp(tmp_path, monkeypatch):
    p = tmp_path / "f.txt"; p.write_text("OLD")
    monkeypatch.setattr(os, "replace", lambda *a: (_ for _ in ()).throw(OSError("injected")))
    with pytest.raises(OSError):
        fsutil.atomic_write_text(p, "NEW")
    monkeypatch.undo()
    assert p.read_text() == "OLD" and [x.name for x in tmp_path.iterdir()] == ["f.txt"]


def test_readers_never_see_a_partial_file_while_a_writer_loops(tmp_path):
    p = tmp_path / "f.json"; fsutil.atomic_write_json(p, {"v": 0, "pad": "x" * 200000})
    stop = mp.Event()
    def writer():
        i = 0
        while not stop.is_set():
            i += 1; fsutil.atomic_write_json(p, {"v": i, "pad": "x" * 200000}, fsync=False)
    w = mp.Process(target=writer); w.start()
    try:
        for _ in range(300):
            json.loads(p.read_text())                      # JSONDecodeError would mean a torn read
    finally:
        stop.set(); w.join()


def test_nan_is_refused_on_write(tmp_path):
    with pytest.raises(InputError):
        fsutil.atomic_write_json(tmp_path / "f.json", {"x": float("nan")})
    assert not (tmp_path / "f.json").exists()


# ================================================================ fsutil: locks
def _rmw(args):
    path, lockpath, n, use_lock = args
    for _ in range(n):
        if use_lock:
            with fsutil.FileLock(lockpath, timeout=60):
                v = int(Path(path).read_text()); time.sleep(0.0004); Path(path).write_text(str(v + 1))
        else:                                              # the unlocked race may even read a half-written (empty) file
            try:
                v = int(Path(path).read_text())
            except ValueError:
                v = 0
            time.sleep(0.0004); Path(path).write_text(str(v + 1))
    return True


def _run_race(tmp_path, use_lock, procs=8, n=25):
    c = tmp_path / f"c{use_lock}.txt"; c.write_text("0")
    with mp.Pool(procs) as pool:
        pool.map(_rmw, [(str(c), str(tmp_path / "x.lock"), n, use_lock)] * procs)
    return int(c.read_text()), procs * n


def test_control_experiment_the_race_is_real_without_a_lock(tmp_path):
    for _ in range(3):                                      # probabilistic: retry to avoid a flaky control
        got, want = _run_race(tmp_path, False)
        if got < want: break
    assert got < want, "control failed: the unlocked race did not lose updates, so the lock test below proves nothing"


def test_lock_prevents_lost_updates_across_processes(tmp_path):
    got, want = _run_race(tmp_path, True, procs=8, n=25)
    assert got == want


def test_lock_timeout_and_reentrancy(tmp_path):
    lp = tmp_path / "l.lock"
    with fsutil.FileLock(lp, timeout=1):
        with fsutil.FileLock(lp, timeout=1):                # same process: re-entrant, no deadlock
            pass
        p = subprocess.run([sys.executable, "-c", f"import sys; sys.path.insert(0,{str(SCRIPTS)!r}); import fsutil\n"
                            f"fsutil.FileLock({str(lp)!r}, timeout=0.3).__enter__()"], capture_output=True, text=True)
        assert p.returncode != 0 and "LockTimeout" in p.stderr
    with fsutil.FileLock(lp, timeout=1):                    # released after the with-block
        pass


def test_lock_is_released_on_exception(tmp_path):
    lp = tmp_path / "l.lock"
    with pytest.raises(RuntimeError):
        with fsutil.FileLock(lp):
            raise RuntimeError("boom")
    with fsutil.FileLock(lp, timeout=0.5):
        pass


# ================================================================ fsutil: containment and symlinks
def test_ensure_within(tmp_path):
    root = tmp_path / "lib"; (root / "a").mkdir(parents=True); (root / "a/f").write_text("x")
    assert fsutil.ensure_within(root, "a/f") == (root / "a/f").resolve()
    for bad in ("../outside", "a/../../outside", str(tmp_path / "other"), "/etc/passwd"):
        with pytest.raises(RefusedError):
            fsutil.ensure_within(root, bad)


def test_ensure_within_refuses_symlinks_even_if_they_stay_inside(tmp_path):
    root = tmp_path / "lib"; (root / "real").mkdir(parents=True); os.symlink(root / "real", root / "alias")
    with pytest.raises(RefusedError, match="symbolic link"):
        fsutil.ensure_within(root, "alias")
    outside = tmp_path / "outside"; outside.mkdir(); os.symlink(outside, root / "escape")
    with pytest.raises(RefusedError):
        fsutil.ensure_within(root, "escape/secret")


@pytest.mark.skipif(os.name != "posix", reason="POSIX modes")
def test_tree_chmod_never_touches_a_symlink_target(tmp_path):
    victim = tmp_path / "victim.txt"; victim.write_text("x"); os.chmod(victim, 0o644)
    vdir = tmp_path / "vdir"; vdir.mkdir(); os.chmod(vdir, 0o755); (vdir / "inner").write_text("y"); os.chmod(vdir / "inner", 0o644)
    shelf = tmp_path / "shelf"; shelf.mkdir(); (shelf / "f").write_text("z")
    os.symlink(victim, shelf / "flink"); os.symlink(vdir, shelf / "dlink")
    skipped = fsutil.tree_chmod(shelf, 0o700, 0o600)
    assert (victim.stat().st_mode & 0o777) == 0o644 and (vdir.stat().st_mode & 0o777) == 0o755 and ((vdir / "inner").stat().st_mode & 0o777) == 0o644
    assert (shelf / "f").stat().st_mode & 0o777 == 0o600 and sorted(Path(s).name for s in skipped) == ["dlink", "flink"]
    assert sorted(Path(s).name for s in fsutil.find_symlinks(shelf)) == ["dlink", "flink"]
    assert fsutil.loose_files(shelf) == []


# ================================================================ fsutil: crash-safe replacement
def _mk(d, files):
    d.mkdir(parents=True, exist_ok=True)
    for n, t in files.items(): (d / n).write_text(t)


def test_replace_dir_swaps_and_cleans_up(tmp_path):
    dst, stg = tmp_path / "global", tmp_path / "staging"
    _mk(dst, {"a": "old"}); _mk(stg, {"a": "new", "b": "x"})
    fsutil.replace_dir(stg, dst)
    assert (dst / "a").read_text() == "new" and (dst / "b").exists() and not stg.exists()
    assert [p.name for p in tmp_path.iterdir()] == ["global"]


def test_replace_dir_rolls_back_when_the_second_rename_fails(tmp_path, monkeypatch):
    dst, stg = tmp_path / "global", tmp_path / "staging"; _mk(dst, {"a": "old"}); _mk(stg, {"a": "new"})
    real = os.rename; calls = []
    def flaky(a, b):
        calls.append(1)
        if len(calls) == 2: raise OSError("injected on swap-in")
        return real(a, b)
    monkeypatch.setattr(os, "rename", flaky)
    with pytest.raises(OSError):
        fsutil.replace_dir(stg, dst)
    monkeypatch.undo()
    assert (dst / "a").read_text() == "old"                  # the live directory is back


def test_recover_pending_restores_after_a_simulated_kill(tmp_path):
    _mk(tmp_path / f"global.old-4242", {"a": "old"})           # state after kill -9 between the two renames
    assert fsutil.recover_pending(tmp_path) == [str(tmp_path / "global")]
    assert (tmp_path / "global/a").read_text() == "old" and fsutil.recover_pending(tmp_path) == []


def test_recover_pending_does_not_clobber_a_live_directory(tmp_path):
    _mk(tmp_path / "global", {"a": "live"}); _mk(tmp_path / "global.old-1", {"a": "stale"})
    assert fsutil.recover_pending(tmp_path) == [] and (tmp_path / "global/a").read_text() == "live"


@pytest.mark.parametrize("fail_at", [0, 1, 2])
def test_multi_replace_is_all_or_nothing_wherever_it_fails(tmp_path, monkeypatch, fail_at):
    files = {tmp_path / n: f"new-{n}" for n in ("a", "b", "c")}
    for n in "ab": (tmp_path / n).write_text(f"old-{n}")                # c does not exist yet
    real = fsutil.atomic_write_bytes; calls = []
    def flaky(path, data, mode=0o644, fsync=True):
        calls.append(path)
        if len(calls) == fail_at + 1: raise OSError("injected")
        return real(path, data, mode, fsync)
    monkeypatch.setattr(fsutil, "atomic_write_bytes", flaky)
    with pytest.raises(OSError):
        fsutil.multi_replace(files)
    monkeypatch.undo()
    assert (tmp_path / "a").read_text() == "old-a" and (tmp_path / "b").read_text() == "old-b" and not (tmp_path / "c").exists()


def test_multi_replace_success(tmp_path):
    files = {tmp_path / "a": "1", tmp_path / "b": b"2"}
    fsutil.multi_replace(files)
    assert (tmp_path / "a").read_text() == "1" and (tmp_path / "b").read_bytes() == b"2"


# ================================================================ fsutil: time
def _today_in(tz):
    return subprocess.run([sys.executable, "-c", f"import sys; sys.path.insert(0,{str(SCRIPTS)!r}); import fsutil; print(fsutil.today_local())"],
                          capture_output=True, text=True, env={**os.environ, "TZ": tz}).stdout.strip()


@pytest.mark.skipif(os.name != "posix", reason="TZ semantics")
def test_today_follows_the_local_timezone_not_utc():
    for tz in ("UTC", "Asia/Kolkata", "Pacific/Kiritimati", "Pacific/Pago_Pago", "America/Mexico_City", "Asia/Kuala_Lumpur"):
        want = subprocess.run(["date", "+%F"], capture_output=True, text=True, env={**os.environ, "TZ": tz}).stdout.strip()
        assert _today_in(tz) == want, tz
    assert _today_in("Pacific/Kiritimati") > _today_in("Pacific/Pago_Pago")      # 25 hours apart: always different days


def test_gia_today_override_and_validation(monkeypatch):
    monkeypatch.setenv("GIA_TODAY", "2026-01-31"); assert fsutil.today_local() == "2026-01-31"
    monkeypatch.setenv("GIA_TODAY", "31/01/2026")
    with pytest.raises(InputError, match="GIA_TODAY"):
        fsutil.today_local()


# ================================================================ schema
@pytest.mark.parametrize("bad,frag", [([], "top level"), ("x", "top level"), (5, "top level"), ({"nodes": 5}, "'nodes' must be a list"),
                                       ({"nodes": None}, "'nodes' must be a list"), ({"edges": "x"}, "'edges' must be a list"),
                                       ({"nodes": ["x"]}, "nodes[0] must be an object"), ({"edges": [[]]}, "edges[0] must be an object"),
                                       ({"nodes": [{"id": ["a"]}]}, "id must be text"), ({"schema_version": "1"}, "schema_version must be an integer")])
def test_schema_rejects_wrong_shapes_with_a_clear_message(bad, frag):
    with pytest.raises(InputError, match=frag.replace("[", r"\[").replace("]", r"\]")):
        schema.require_kg(bad)


def test_schema_accepts_valid_and_missing_sections():
    for ok in ({}, {"nodes": []}, {"nodes": [{"id": "A"}], "edges": [{"from": "A", "to": "A"}]}, {"nodes": [{"id": 3}]}):
        assert schema.require_kg(ok) is ok


def test_schema_strict_edges_and_newer_version():
    with pytest.raises(InputError, match="needs a text 'from'"):
        schema.require_kg({"edges": [{"to": "A"}]}, strict_edges=True)
    schema.require_kg({"edges": [{"to": "A"}]})                                  # lenient mode allows it (validate reports it)
    with pytest.raises(RefusedError, match="newer|understands up to"):
        schema.require_kg({"schema_version": 99})


def test_schema_problem_list_is_bounded():
    probs = schema.kg_problems({"nodes": ["x"] * 5000})
    assert 0 < len(probs) <= 30


def test_graph_shape():
    for bad in ([], {"nodes": 5}, {"nodes": [{"label": "x"}]}, {"links": 5}, {"links": ["x"]}):
        with pytest.raises(InputError):
            schema.require_graph(bad)
    assert schema.require_graph({"nodes": [{"id": "a"}], "links": [{"source": "a", "target": "a"}]})


# ================================================================ textnorm
def test_ascii_fast_path_equals_the_general_path():
    rnd = random.Random(5)
    for _ in range(3000):
        s = "".join(rnd.choice("abcXYZ019 _-.,;:/\\|()[]{}'\"!?\t\n") for _ in range(rnd.randrange(0, 50)))
        general = []
        cur = []
        import unicodedata
        for ch in textnorm.fold(s):
            if ch.isalnum() or unicodedata.category(ch).startswith("M"): cur.append(ch)
            elif cur: general.append("".join(cur)); cur = []
        if cur: general.append("".join(cur))
        assert textnorm.words(s) == general


def test_tokenising_100k_ascii_labels_is_fast():
    t = time.time(); [textnorm.tokens(f"payroll vendor item {i}") for i in range(100000)]
    assert time.time() - t < 1.0


def test_slug_is_stable_unique_and_ascii():
    ids = ["CTRL-CLD-01", "ஊதிய-01", "வரி-01", "NÓM-01", "薪资-01", "a b", "a/b", "../x", "x\x00y", ""]
    slugs = [textnorm.slug(i) for i in ids]
    assert all(s.isascii() and s.replace("_", "").isalnum() for s in slugs)
    assert len({slugs[1], slugs[2], slugs[4]}) == 3 and textnorm.slug("ஊதிய-01") == textnorm.slug("ஊதிய-01")


def test_recover_pending_ignores_lookalike_and_unlisted_folders(tmp_path):
    _mk(tmp_path / "foo.old-2025-backup", {"a": "user's own folder"})      # not '.old-<digits>'
    _mk(tmp_path / "bar.old-123", {"a": "x"})                              # right shape, but not on the allow-list
    _mk(tmp_path / "global.old-77", {"a": "x"})
    assert fsutil.recover_pending(tmp_path, names={"global"}) == [str(tmp_path / "global")]
    assert not (tmp_path / "foo").exists() and not (tmp_path / "bar").exists()
    assert fsutil.recover_pending(tmp_path) == [str(tmp_path / "bar")]      # with no allow-list the digit-only shape still applies


def test_display_tail_keeps_the_end_of_a_long_path():
    p = "/very/long/path/" * 10 + "my-skill-name"
    out = textsafe.display_tail(p, 30)
    assert len(out) == 30 and out.endswith("my-skill-name") and out.startswith("\u2026")
    assert textsafe.display_tail("short", 30) == "short"
    esc = textsafe.display_tail("a" + chr(27) + "b", 30)
    assert chr(27) not in esc and "\\x1b" in esc               # the ESC byte is shown as visible text
