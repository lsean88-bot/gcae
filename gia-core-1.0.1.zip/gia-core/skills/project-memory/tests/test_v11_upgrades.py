"""v1.1 upgrades: script-aware text, strict dates, file modes, evidence ranks, synonyms."""
import json, os, stat, sys
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import akos_graph as ag  # noqa: E402
import brain  # noqa: E402
import textnorm  # noqa: E402

ENV = ["GEMINI_API_KEY", "GOOGLE_API_KEY", "MOONSHOT_API_KEY", "ANTHROPIC_API_KEY", "OPENAI_API_KEY", "DEEPSEEK_API_KEY",
       "AZURE_OPENAI_API_KEY", "AZURE_OPENAI_ENDPOINT", "AWS_PROFILE", "AWS_REGION", "AWS_DEFAULT_REGION",
       "OLLAMA_BASE_URL", "OLLAMA_HOST", "GRAPHIFY_QUERY_LOG", "GRAPHIFY_QUERY_LOG_ENABLE"]


@pytest.fixture(autouse=True)
def clean_env(monkeypatch):
    for k in ENV:
        monkeypatch.delenv(k, raising=False)


def node(i, typ, label, conf="100%", ent="Group", **kw):
    return {"id": i, "type": typ, "label": label, "entity": ent, "created_date": "2026-10-01",
            "confidence": conf, "source_location": "https://portal.example/x", **kw}


def edge(a, b, rel="relates_to", conf="High"):
    return {"from": a, "to": b, "relationship": rel, "evidence": "ev", "confidence": conf}


def put(lib, shelf, nodes, edges=(), confidential=False):
    ag.atomic_write_json(lib / "shelves" / shelf / "KNOWLEDGE_GRAPH.json",
                         {"engagement": shelf, "confidential": confidential, "last_updated": "2026-10-01",
                          "nodes": nodes, "edges": list(edges)})


@pytest.fixture
def lib(tmp_path):
    L = tmp_path / "lib"
    brain.init_library(L)
    brain.add_shelf(L, "mx-nomina", "engagement", "Group")
    brain.add_shelf(L, "stat", "statutory", "Group", review_days=90)
    brain.add_shelf(L, "inv-x", "investigation", "MKSDL")
    return L


# ---- script-aware text ----------------------------------------------------------------------
def test_accent_folding_and_whole_words():
    assert textnorm.tokens("Nómina") == textnorm.tokens("NOMINA") == ["nomina"]
    assert textnorm.words("CAFÉ-Ñandú 01") == ["cafe", "nandu", "01"]


def test_tamil_words_survive_intact_and_chinese_gets_bigrams():
    assert textnorm.words("ஊதிய பதிவேடு") == ["ஊதிய", "பதிவேடு"]
    assert textnorm.tokens("薪资审计") == ["薪资", "资审", "审计"]


def test_non_ascii_ids_do_not_collapse():
    a, b = textnorm.slug("ஊதிய-01"), textnorm.slug("வரி-01")
    assert a != b and a.endswith(textnorm.slug("ஊதிய-01")[-6:])
    assert textnorm.slug("CTRL-CLD-01") == "ctrl_cld_01"            # plain ASCII stays readable


def test_recall_finds_accented_and_non_latin_labels(lib):
    put(lib, "mx-nomina", [node("MX-01", "Process", "Nómina de contratistas", ent="Group"),
                           node("TA-01", "Process", "ஊதிய பதிவேடு தணிக்கை"),
                           node("ZH-01", "Process", "薪资审计程序")])
    assert brain.recall(lib, "nomina contratistas")["results"][0]["id"] == "MX-01"
    assert brain.recall(lib, "NÓMINA")["results"][0]["id"] == "MX-01"
    assert brain.recall(lib, "ஊதிய பதிவேடு")["results"][0]["id"] == "TA-01"
    assert brain.recall(lib, "审计")["results"][0]["id"] == "ZH-01"
    assert not brain.recall(lib, "mina")["results"]                  # the old bug: "Nómina" matched "mina"


def test_near_duplicate_detection_is_accent_and_script_aware():
    kg = {"engagement": "e", "nodes": [node("A", "Risk", "Riesgo de nómina"), node("B", "Risk", "RIESGO DE NOMINA!"),
                                         node("C", "Risk", "ஊதிய இடர்"), node("D", "Risk", "ஊதிய இடர்.")],
          "edges": [edge("A", "B"), edge("C", "D")]}
    dup = [i for i in ag.validate_kg(kg) if i["code"] == "NEAR_DUPLICATE"]
    assert len(dup) == 2


# ---- strict dates ---------------------------------------------------------------------------
@pytest.mark.parametrize("val,state", [("2026-04-01", "STALE"), ("2027-04-01", None), ("April 2026", "BAD_DATE"),
                                       ("2026-4-1", "BAD_DATE"), ("01/04/2026", "BAD_DATE"), ("", "UNDATED"), (None, "UNDATED")])
def test_unreadable_dates_are_never_fresh(val, state):
    assert brain.staleness({"type": "Regulation", "review_by": val}, {"kind": "statutory"}, "2026-10-03") == state


def test_bad_date_surfaces_in_recall_and_stale_report(lib):
    put(lib, "stat", [node("R1", "Regulation", "Minimum wage notification", review_by="April 2026")])
    assert brain.recall(lib, "minimum wage")["results"][0]["stale"] == "BAD_DATE"
    assert {i["state"] for i in brain.stale_report(lib, "2026-10-03")["items"]} >= {"BAD_DATE"}


def test_bad_today_is_rejected(lib):
    with pytest.raises(brain.BrainError, match="YYYY-MM-DD"):
        brain.recall(lib, "x", today="03/10/2026")
    with pytest.raises(brain.BrainError, match="YYYY-MM-DD"):
        brain.stale_report(lib, "yesterday")


def test_validate_warns_on_unreadable_node_date():
    kg = {"engagement": "e", "nodes": [node("A", "Regulation", "x", review_by="soon"), node("B", "Risk", "y")],
          "edges": [edge("A", "B")]}
    assert any(i["code"] == "DATE_FORMAT" for i in ag.validate_kg(kg))


# ---- file modes -------------------------------------------------------------------------------
def mode(p):
    return stat.S_IMODE(os.stat(p).st_mode)


@pytest.mark.skipif(os.name != "posix", reason="POSIX permissions")
def test_modes_shared_readable_vs_confidential_locked(lib):
    put(lib, "mx-nomina", [node("A", "Risk", "x"), node("B", "Risk", "y")], [edge("A", "B")])
    put(lib, "inv-x", [node("A", "Issue", "secret", conf="Medium", ent="MKSDL", status="ALLEGED"), node("B", "Vendor", "v", ent="MKSDL")],
        [edge("A", "B", "affects", "Medium")], confidential=True)
    brain.index_library(lib)
    brain.remember(lib, "inv-x", "q?", "a", "useful")
    assert mode(lib / "shelves/mx-nomina/KNOWLEDGE_GRAPH.json") == 0o644
    assert mode(lib / "shelves/inv-x/KNOWLEDGE_GRAPH.json") == 0o600
    assert mode(lib / "shelves/inv-x") == 0o700
    assert mode(lib / "shelves/inv-x/graphify-out/graph.json") == 0o600
    assert brain.guard(lib) == []


@pytest.mark.skipif(os.name != "posix", reason="POSIX permissions")
def test_guard_flags_world_readable_confidential_file(lib):
    put(lib, "inv-x", [node("A", "Issue", "s", conf="Medium", ent="MKSDL"), node("B", "Vendor", "v", ent="MKSDL")],
        [edge("A", "B", "affects", "Medium")], confidential=True)
    brain.index_library(lib)
    os.chmod(lib / "shelves/inv-x/KNOWLEDGE_GRAPH.json", 0o644)
    assert {i["code"] for i in brain.guard(lib)} == {"CONFIDENTIAL_WORLD_READABLE"}


def test_atomic_write_mode_param(tmp_path):
    ag.atomic_write_json(tmp_path / "a.json", {}, 0o600)
    ag.atomic_write_json(tmp_path / "b.json", {})
    if os.name == "posix":
        assert mode(tmp_path / "a.json") == 0o600 and mode(tmp_path / "b.json") == 0o644


# ---- evidence ranks -----------------------------------------------------------------------------
def test_validate_rank_rules():
    kg = {"engagement": "e", "nodes": [node("A", "Risk", "a", evidence_rank="R9"), node("B", "Risk", "b", evidence_rank="R5"),
                                         node("C", "Risk", "c", evidence_rank="R1")], "edges": [edge("A", "B"), edge("B", "C")]}
    codes = {(i["code"], i["severity"]) for i in ag.validate_kg(kg)}
    assert ("RANK_INVALID", "ERROR") in codes and ("CONF_VS_RANK", "WARN") in codes
    assert sum(1 for i in ag.validate_kg(kg) if i["code"] == "CONF_VS_RANK") == 1      # only the R5 node at 100%


def test_trust_demotion_follows_the_evidence_hierarchy():
    assert brain.trust_label(node("A", "Risk", "a", evidence_rank="R1")) == "CONFIRMED"
    assert brain.trust_label(node("A", "Risk", "a", evidence_rank="R4")) == "PROVISIONAL"
    assert brain.trust_label(node("A", "Risk", "a", evidence_rank="R5")) == "INDICATOR"
    assert brain.trust_label(node("A", "Risk", "a")) == "CONFIRMED"                   # unranked keeps legacy behaviour


def test_recall_shows_rank_and_max_rank_filters_and_counts_unranked(lib):
    put(lib, "stat", [node("R1", "Regulation", "wage rule portal", evidence_rank="R1", review_by="2027-01-01"),
                      node("R2", "Regulation", "wage rule memo", evidence_rank="R4", review_by="2027-01-01"),
                      node("R3", "Regulation", "wage rule unranked", review_by="2027-01-01")])
    allr = {r["id"]: r["evidence_rank"] for r in brain.recall(lib, "wage rule")["results"]}
    assert allr == {"R1": "R1", "R2": "R4", "R3": "UNRANKED"}
    r = brain.recall(lib, "wage rule", max_rank="R3")
    assert [x["id"] for x in r["results"]] == ["R1"] and r["excluded_unranked"] == 1
    with pytest.raises(brain.BrainError):
        brain.recall(lib, "x", max_rank="R9")


def test_deliverable_max_rank_never_admits_unranked(tmp_path):
    kg = {"engagement": "e", "nodes": [node("A", "Risk", "a", evidence_rank="R2"), node("B", "Risk", "b", evidence_rank="R4"),
                                         node("C", "Risk", "c")], "edges": [edge("A", "B"), edge("A", "C")]}
    out, rep = ag.deliverable_subset(kg, max_rank="R3")
    assert [n["id"] for n in out["nodes"]] == ["A"] and rep["excluded_unranked"] == 1


# ---- synonyms --------------------------------------------------------------------------------------
def test_synonyms_bridge_languages_and_are_reported(lib):
    put(lib, "mx-nomina", [node("MX-01", "Process", "Nómina de contratistas")])
    r = brain.recall(lib, "payroll process")
    assert r["results"][0]["id"] == "MX-01"
    assert "nomina" in r["expanded_terms"]          # transparency: what was added is visible


def test_direct_match_outranks_synonym_match(lib):
    put(lib, "mx-nomina", [node("A", "Process", "Payroll controls"), node("B", "Process", "Nómina controls")])
    assert [x["id"] for x in brain.recall(lib, "payroll controls")["results"]][:2] == ["A", "B"]


def test_no_synonyms_file_means_no_expansion(lib):
    (lib / "synonyms.json").unlink()
    put(lib, "mx-nomina", [node("MX-01", "Process", "Nómina de contratistas")])
    r = brain.recall(lib, "payroll")
    assert r["results"] == [] and r["expanded_terms"] == []


def test_user_can_extend_synonyms(lib):
    syn = json.loads((lib / "synonyms.json").read_text())
    syn["groups"].append(["clra licence", "contractor registration"])
    (lib / "synonyms.json").write_text(json.dumps(syn))
    put(lib, "mx-nomina", [node("L-01", "Regulation", "Contractor registration certificate")])
    assert brain.recall(lib, "clra licence")["results"][0]["id"] == "L-01"
