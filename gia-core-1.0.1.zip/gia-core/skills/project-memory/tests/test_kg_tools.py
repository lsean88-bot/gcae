#!/usr/bin/env python3
"""Tests for scripts/kg_tools.py (stdlib only).  Run: python3 -I tests/test_kg_tools.py   (also collected by pytest)"""
import json
import subprocess
import sys
import tempfile
from pathlib import Path

KG = str(Path(__file__).resolve().parent.parent / "scripts" / "kg_tools.py")


def run(d, *a):
    p = subprocess.run([sys.executable, "-I", KG, "--dir", d] + list(a), capture_output=True, text=True, timeout=60)
    return p.returncode, p.stdout + p.stderr


def test_kg_tools():
    res = []

    def t(name, ok):
        res.append(bool(ok))
        print(("PASS  " if ok else "FAIL  ") + name)
        assert ok, name

    with tempfile.TemporaryDirectory() as d:
        rc, _ = run(d, "init")
        t("init creates both state files", rc == 0 and (Path(d) / "project-memory.json").exists() and (Path(d) / "knowledge-graph.json").exists())
        rc, out = run(d, "add-fact", "--text", "Plant A has 40 staff", "--evidence", "R2: HR export", "--confidence", "High")
        t("add-fact", rc == 0)
        rc, out = run(d, "add-fact", "--text", "x", "--evidence", "R2: y", "--confidence", "Certain")
        t("bad confidence refused", rc != 0)
        rc, out = run(d, "add-evidence", "--description", "verbal claim", "--rank", "R9")
        t("bad evidence rank refused", rc != 0)
        rc, out = run(d, "add-evidence", "--description", "GL export", "--rank", "R2", "--source", "SAP")
        t("add-evidence", rc == 0)
        rc, out = run(d, "add-assumption", "--text", "scope stays", "--risk", "rework", "--expiry", "on signed charter")
        t("add-assumption", rc == 0)
        rc, out = run(d, "add-decision", "--text", "sample 25", "--rationale", "risk based", "--alternatives", "10; 40")
        t("add-decision", rc == 0)
        run(d, "add-node", "--type", "Entity", "--name", "E1")
        rc, out = run(d, "add-node", "--type", "Entity", "--name", "E1")
        t("duplicate node not added", "Duplicate" in out)
        run(d, "add-node", "--type", "Risk", "--name", "R1")
        rc, out = run(d, "add-edge", "--from", "N-0001", "--rel", "owns", "--to", "N-0002")
        t("add-edge between existing nodes", rc == 0)
        rc, out = run(d, "add-edge", "--from", "N-0001", "--rel", "owns", "--to", "N-9999")
        t("edge to a missing node refused", rc != 0)
        rc, out = run(d, "check-integrity")
        t("integrity clean after linking", rc == 0 and "0 hard issue" in out)
        pm = json.loads((Path(d) / "project-memory.json").read_text())
        t("facts, evidence, assumptions and decisions recorded", all(pm.get(k) for k in ("confirmed_facts", "evidence", "assumptions", "decisions")))
        rc, out = run(d, "snapshot")
        t("snapshot prints markdown", rc == 0 and out.lstrip().startswith("#"))
        rc, out = run(d, "import-sentinel", "--sentinel-dir", d)
        t("retired import-sentinel command is gone", rc != 0)
    print("\n%d tests, %d failed" % (len(res), res.count(False)))


if __name__ == "__main__":
    try:
        test_kg_tools()
    except AssertionError:
        sys.exit(1)
