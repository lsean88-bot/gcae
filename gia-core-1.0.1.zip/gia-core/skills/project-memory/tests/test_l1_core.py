"""L1 core: akos_graph on the L0 foundation. Fuzz, hostile text, file edges, atomic outputs, compatibility of exceptions."""
import contextlib, io, json, os, random, sys
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import akos_graph as ag  # noqa: E402
import errors  # noqa: E402

FIX = json.loads((Path(__file__).parent / "fixtures/cld_kg.json").read_text())
CONTROL = "".join(map(chr, range(0, 32))) + "\x7f\x9b\u202e\u2066\u200b\ufeff"


@pytest.fixture(autouse=True)
def env(monkeypatch):
    monkeypatch.setenv("GIA_NO_FSYNC", "1")


def run(*argv):
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        code = ag.main([str(a) for a in argv])
    return code, out.getvalue(), err.getvalue()


def write(tmp, name, obj, raw=None):
    p = tmp / name
    p.write_bytes(raw if raw is not None else json.dumps(obj).encode())
    return p


def all_commands(tmp, f, light=False):
    """Every command that reads a KG, pointed at file f. Yields (label, argv)."""
    yield "validate", ["validate", f]
    yield "validate-final-json", ["validate", f, "--gate", "final", "--json"]
    yield "stats", ["stats", f]
    yield "deliverable", ["deliverable", f, "--out", tmp / "d.json"]
    yield "merge", ["merge", f, f, "--out", tmp / "m.json"]
    yield "from-graphify-as-kg", ["from-graphify", write(tmp, "g.json", {"nodes": [{"id": "a", "label": "A"}], "links": []}), "--kg", f, "--out", tmp / "s.json"]
    yield "from-graphify-as-graph", ["from-graphify", f, "--out", tmp / "s2.json"]
    if not light:
        yield "to-graphify", ["to-graphify", f, "--out", tmp / "o", "--no-html"]
        yield "export-xlsx", ["export-xlsx", f, "--out", tmp / "x.xlsx"]


def assert_contract(label, code, out, err):
    assert code in (0, 1, 2), f"{label}: exit {code} violates the contract\n{err[-300:]}"
    assert "Traceback" not in err and "Traceback" not in out, f"{label}: raw traceback"
    assert "\x1b" not in out + err and "\x00" not in out + err, f"{label}: control characters reached the terminal"
    if code == 2:
        assert err.startswith("error:") and len(err.strip().splitlines()) == 1, f"{label}: message not one clear line: {err[:200]!r}"


# ================================================================ structural attacks
SHAPES = {
    "top-level list": [], "top-level string": "x", "top-level number": 5, "top-level null": None, "top-level bool": True,
    "nodes int": {"nodes": 5}, "nodes null": {"nodes": None}, "nodes dict": {"nodes": {}}, "nodes string": {"nodes": "abc"},
    "edges int": {"edges": 7}, "edges null": {"edges": None}, "node string": {"nodes": ["x"]}, "node list": {"nodes": [[]]},
    "node null": {"nodes": [None]}, "edge string": {"edges": ["x"]}, "edge empty": {"edges": [{}]}, "edge no to": {"edges": [{"from": "A"}]},
    "id list": {"nodes": [{"id": ["a"]}]}, "id dict": {"nodes": [{"id": {"a": 1}}]}, "id null": {"nodes": [{"id": None}]},
    "id bool": {"nodes": [{"id": True}]}, "id float": {"nodes": [{"id": 1.5}]}, "label dict": {"nodes": [{"id": "A", "label": {"x": 1}}]},
    "confidence list": {"nodes": [{"id": "A", "confidence": ["High"]}]}, "schema_version str": {"schema_version": "1"},
    "schema_version future": {"schema_version": 99}, "empty object": {}, "huge string": {"nodes": [{"id": "A", "label": "x" * 2_000_000}]},
    "edge from list": {"nodes": [{"id": "A"}], "edges": [{"from": ["A"], "to": "A"}]},
}


@pytest.mark.parametrize("name", list(SHAPES))
def test_every_command_survives_every_malformed_shape(name, tmp_path):
    f = write(tmp_path, "k.json", SHAPES[name])
    for label, argv in all_commands(tmp_path, f):
        assert_contract(f"{name} / {label}", *run(*argv))


def _mutate(rnd, obj):
    pool = [None, 5, -1, 3.14, True, False, "", "x" * 5000, [], {}, "\x1b[31m", {"a": [1]}, [[]], "Nómina ஊதிய 薪资", 10 ** 30]
    paths = []
    def walk(o, path):
        if isinstance(o, dict):
            for k, v in o.items(): paths.append(path + [k]); walk(v, path + [k])
        elif isinstance(o, list):
            for i, v in enumerate(o): paths.append(path + [i]); walk(v, path + [i])
    walk(obj, [])
    for _ in range(rnd.randrange(1, 5)):
        p = rnd.choice(paths); cur = obj
        for k in p[:-1]: cur = cur[k]
        if rnd.random() < 0.15:
            if isinstance(cur, dict):
                del cur[p[-1]]
            else:
                cur.pop(p[-1])
        else:
            cur[p[-1]] = json.loads(json.dumps(rnd.choice(pool)))     # a COPY: sharing pool objects creates cycles
        paths = []; walk(obj, [])
        if not paths: break
    return obj


def test_randomised_type_mutation_fuzz(tmp_path):
    rnd = random.Random(2026)
    for i in range(220):
        kg = _mutate(rnd, json.loads(json.dumps(FIX)))
        try:
            raw = json.dumps(kg).encode()
        except (TypeError, ValueError):
            continue
        f = write(tmp_path, "k.json", None, raw)
        for label, argv in all_commands(tmp_path, f, light=(i % 4 != 0)):
            assert_contract(f"mutation#{i} / {label}", *run(*argv))


# ================================================================ hostile text everywhere
def test_hostile_characters_in_every_field_are_safe_in_every_sink(tmp_path):
    from openpyxl import load_workbook
    bad = "evil" + CONTROL + "[31mRED"
    kg = {"engagement": bad, "nodes": [
        {"id": "A" + CONTROL, "type": "Risk", "label": bad, "entity": "Group", "created_date": "2026-01-01", "confidence": "High", "source_location": bad, "evidence_rank": "R1"},
        {"id": "B", "type": "Risk", "label": "ok", "entity": bad, "created_date": "2026-01-01", "confidence": "Medium", "source_location": "x"}],
        "edges": [{"from": "A" + CONTROL, "to": "B", "relationship": "relates_to", "evidence": "=HYPERLINK(\"http://evil\")" + CONTROL, "confidence": "High"}]}
    f = write(tmp_path, "k.json", kg)
    for label, argv in all_commands(tmp_path, f):
        code, out, err = run(*argv)
        assert_contract(label, code, out, err)
    wb = load_workbook(tmp_path / "x.xlsx")
    for sheet in wb:
        for row in sheet.iter_rows():
            for c in row:
                if isinstance(c.value, str):
                    assert not c.value.startswith("=") or sheet.title == "Summary", f"live formula {sheet.title}!{c.coordinate}"
                    assert not any(ord(ch) < 32 and ch not in "\n\t\r" for ch in c.value)


def test_terminal_output_of_findings_is_escaped():
    kg = {"nodes": [{"id": "A\x1b[2J\x1b[31mX", "type": "Risk", "label": "a", "entity": "Group", "created_date": "2026-01-01", "confidence": "High", "source_location": "s"}]}
    out, err = io.StringIO(), io.StringIO()
    ag._print_issues(ag.validate_kg(kg, "final"), False)
    # printing goes to stdout: capture again properly
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        ag._print_issues(ag.validate_kg(kg, "final"), False)
    assert "\x1b" not in buf.getvalue() and "\\x1b" in buf.getvalue()


# ================================================================ file edge cases through the CLI
def test_bom_file_is_accepted(tmp_path):
    f = write(tmp_path, "k.json", None, b"\xef\xbb\xbf" + json.dumps(FIX).encode())
    code, out, err = run("validate", f, "--gate", "final")
    assert code == 0, err


@pytest.mark.parametrize("raw,frag", [(b'{"nodes":[{"id":"A"}],"nodes":[],"edges":[]}', "duplicate key"), (b'{"nodes":[],"edges":[],"x":NaN}', "NaN"),
                                      (b"", "not valid JSON"), (b"\xff\xfe\xfd", "UTF-8"), (b"[" * 200000 + b"]" * 200000, "nested too deeply"),
                                      (b'{"nodes":[]}\x00', "NUL")])
def test_file_edges_give_one_clear_line_and_exit_2(raw, frag, tmp_path):
    code, out, err = run("validate", write(tmp_path, "k.json", None, raw))
    assert code == 2 and frag in err and err.count("\n") == 1


def test_missing_directory_and_oversize_inputs(tmp_path, monkeypatch):
    assert run("validate", tmp_path / "nope.json")[0] == 2
    assert run("validate", tmp_path)[0] == 2                                     # a directory
    f = write(tmp_path, "k.json", FIX)
    import strictjson
    monkeypatch.setattr(strictjson, "MAX_BYTES", 100)
    code, _, err = run("validate", f)
    assert code == 2 and "exceeds" in err


def test_future_schema_version_is_refused_not_misread(tmp_path):
    code, _, err = run("validate", write(tmp_path, "k.json", {**FIX, "schema_version": 99}))
    assert code == 2 and "schema_version" in err


def test_older_files_without_a_schema_version_still_work(tmp_path):
    assert "schema_version" not in FIX and run("validate", write(tmp_path, "k.json", FIX), "--gate", "final")[0] == 0


# ================================================================ argument validation
def test_bad_arguments_exit_2(tmp_path):
    f = write(tmp_path, "k.json", FIX)
    em = write(tmp_path, "em.json", ["not", "an", "object"])
    g = write(tmp_path, "g.json", {"nodes": [], "links": []})
    assert run("from-graphify", g, "--out", tmp_path / "o.json", "--entity-map", em)[0] == 2
    assert run("from-graphify", g, "--out", tmp_path / "o.json", "--today", "03/10/2026")[0] == 2
    with pytest.raises(SystemExit):                                              # argparse's own usage error
        run("validate", f, "--gate", "bogus")


# ================================================================ exceptions stay compatible with v1.x callers
def test_new_errors_are_still_the_old_exception_types():
    assert issubclass(errors.InputError, ValueError) and issubclass(errors.RefusedError, PermissionError)
    conf = {**FIX, "engagement": "INV", "confidential": True}
    with pytest.raises(PermissionError):
        ag.merge_kgs(FIX, conf)
    with pytest.raises(ValueError):
        ag.kg_to_extraction({"nodes": [{**FIX["nodes"][0]}, {**FIX["nodes"][0], "id": "doc.mkapl.0142"}], "edges": []})


# ================================================================ atomic graphify outputs
def test_graph_json_is_never_torn_when_the_build_fails(tmp_path, monkeypatch):
    import graphify.export as gx
    ag.build_graphify_outputs(FIX, tmp_path, html=False)
    good = (tmp_path / "graphify-out/graph.json").read_bytes()
    def broken(G, com, path, force=False):
        Path(path).write_text('{"nodes": [ PARTIAL'); raise OSError("disk full")
    monkeypatch.setattr(gx, "to_json", broken)
    with pytest.raises(OSError):
        ag.build_graphify_outputs(FIX, tmp_path, html=False)
    monkeypatch.undo()
    assert (tmp_path / "graphify-out/graph.json").read_bytes() == good
    assert not [p for p in (tmp_path / "graphify-out").iterdir() if p.name.endswith(".tmp")]


def test_nothing_is_left_behind_after_a_normal_build(tmp_path):
    ag.build_graphify_outputs(FIX, tmp_path, html=True)
    names = sorted(p.name for p in (tmp_path / "graphify-out").iterdir())
    assert names == ["akos_meta.json", "graph.html", "graph.json"], names


def test_roundtrip_is_idempotent_and_never_duplicates(tmp_path):
    ag.build_graphify_outputs(FIX, tmp_path, html=False)
    graph = ag.load_json(tmp_path / "graphify-out/graph.json")
    once, _ = ag.graphify_to_staged(graph, json.loads(json.dumps(FIX)))
    twice, rep = ag.graphify_to_staged(graph, once)
    assert once == twice and rep["added_nodes"] == 0 and rep["added_edges"] == 0
