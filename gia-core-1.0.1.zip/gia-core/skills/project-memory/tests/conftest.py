"""Report tests that need the external `graphify` package as SKIPPED (not passed, not failed) when it is not installed.

A skip here means NOT VERIFIED in this environment. Install graphify (see references/graphify-environment.md) and re-run to verify.
"""
import importlib.util

import pytest

# Fail only because the shelf index step cannot run without graphify (the index reports failed_shelves). Inferred from the failure output, not proven.
DOWNSTREAM = {"test_global_graph_excludes_confidential_and_namespaces_ids", "test_id_collisions_across_shelves_do_not_merge", "test_guard_clean_library",
              "test_cli_end_to_end", "test_index_with_no_failures_exits_zero", "test_doctor_environment_and_library"}
HAVE_GRAPHIFY = importlib.util.find_spec("graphify") is not None


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    out = yield
    rep = out.get_result()
    if HAVE_GRAPHIFY or rep.passed or call.excinfo is None:
        return
    text = str(call.excinfo.getrepr()) if call.excinfo else ""
    if "No module named 'graphify'" in text or "EXTRACT_BACKEND_NOT_ALLOWED" in text or "graphify-out" in text or "to-graphify: exit 3" in text \
            or ("ERROR' == 'INDEXED" in text) or item.name in DOWNSTREAM:
        rep.outcome = "skipped"
        rep.longrepr = (str(item.fspath), item.location[1], "SKIPPED_NO_GRAPHIFY: needs the external graphify package")
