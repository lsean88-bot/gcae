"""L3 tools: register_entity atomicity, interop_check robustness against hostile skill folders."""
import json, os, subprocess, sys, time
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import fsutil, interop_check as ic, register_entity as re_  # noqa: E402

SCHEMA = '{ "entity": "string (AAA|BBB|Group)" }\n'
TAXO = "## 1. Entity Code Standard\n\nnine entities\n\n| Code | Entity | Country | Sector |\n|---|---|---|---|\n| AAA | a | b | c |\n\n## 2. x\n"


@pytest.fixture(autouse=True)
def env(monkeypatch):
    monkeypatch.setenv("GIA_NO_FSYNC", "1")


@pytest.fixture
def akos(tmp_path):
    d = tmp_path / "akos"; (d / "references").mkdir(parents=True)
    (d / "references/knowledge-graph-schema.md").write_text(SCHEMA)
    (d / "references/taxonomy-and-metadata-standards.md").write_text(TAXO)
    cfg = tmp_path / "entities.json"; cfg.write_text(json.dumps({"entities": ["AAA", "BBB", "Group"]}))
    return d, cfg


def snap(*paths):
    return {str(p): p.read_text() for p in paths}


def run_re(akos, cfg, *extra):
    d, _ = akos
    return subprocess.run([sys.executable, str(ROOT / "scripts/register_entity.py"), "--akos-dir", str(d), "--config", str(cfg), "--code", "CCC",
                           "--name", "Gamma", "--country", "Malaysia", "--sector", "Services", *extra], capture_output=True, text=True)


# ===================================================== register_entity: all three files change, or none
@pytest.mark.parametrize("fail_at", [0, 1, 2])
def test_register_entity_is_all_or_nothing_under_a_failure_at_any_file(akos, monkeypatch, fail_at):
    d, cfg = akos
    files = [d / "references/knowledge-graph-schema.md", d / "references/taxonomy-and-metadata-standards.md", cfg]
    before = snap(*files)
    real = fsutil.atomic_write_bytes; n = []
    def flaky(path, data, mode=0o644, fsync=None):
        n.append(path)
        if len(n) == fail_at + 1:
            raise OSError("injected failure")
        return real(path, data, mode, fsync)
    monkeypatch.setattr(fsutil, "atomic_write_bytes", flaky)
    with pytest.raises(OSError):
        re_._main(["--akos-dir", str(d), "--config", str(cfg), "--code", "CCC", "--name", "n", "--country", "c", "--sector", "s", "--apply"])
    monkeypatch.undo()
    assert snap(*files) == before                                    # the three lists still agree
    assert not list(d.rglob("*.bak")) and not list(cfg.parent.glob("*.bak")), "no litter after a failed run"


def test_register_entity_success_changes_all_three_and_keeps_backups(akos):
    d, cfg = akos
    r = run_re(akos, cfg, "--apply")
    assert r.returncode == 0
    assert "(AAA|BBB|CCC|Group)" in (d / "references/knowledge-graph-schema.md").read_text()
    assert "| CCC | Gamma | Malaysia | Services |" in (d / "references/taxonomy-and-metadata-standards.md").read_text()
    assert "CCC" in json.loads(cfg.read_text())["entities"] and (d / "references/knowledge-graph-schema.md.bak").read_text() == SCHEMA


@pytest.mark.parametrize("field,value", [("--name", "a|b"), ("--name", "line\nbreak"), ("--country", " "), ("--sector", "x\ry")])
def test_register_entity_rejects_values_that_would_corrupt_the_markdown_table(akos, field, value):
    d, cfg = akos
    args = ["--akos-dir", str(d), "--config", str(cfg), "--code", "CCC", "--name", "n", "--country", "c", "--sector", "s"]
    args[args.index(field) + 1] = value
    r = subprocess.run([sys.executable, str(ROOT / "scripts/register_entity.py"), *args, "--apply"], capture_output=True, text=True)
    assert r.returncode == 2 and "Traceback" not in r.stderr
    assert (d / "references/taxonomy-and-metadata-standards.md").read_text() == TAXO


def test_register_entity_bad_files_are_clear_errors(tmp_path):
    r = subprocess.run([sys.executable, str(ROOT / "scripts/register_entity.py"), "--akos-dir", str(tmp_path), "--config", str(tmp_path / "nope.json"),
                        "--code", "CCC", "--name", "n", "--country", "c", "--sector", "s"], capture_output=True, text=True)
    assert r.returncode == 2 and "Traceback" not in r.stderr


# ===================================================== interop_check vs hostile skill folders
def mk(root, name, text=None, raw=None):
    d = root / name; d.mkdir(parents=True, exist_ok=True)
    (d / "SKILL.md").write_bytes(raw if raw is not None else (text or f"---\nname: {name}\ndescription: d\n---\nbody\n").encode())
    return d


def run_ic(*roots, extra=()):
    return subprocess.run([sys.executable, str(ROOT / "scripts/interop_check.py"), "--roots", *map(str, roots), *extra], capture_output=True, text=True)


def test_binary_malformed_oversized_and_unreadable_skill_files_never_crash_it(tmp_path):
    root = tmp_path / "plugins"
    mk(root, "ok")
    mk(root, "binary", raw=b"\x00\x01\x02 garbage \xff\xfe" * 100)
    mk(root, "unclosed", "---\nname: unclosed\ndescription: [oops\n---\n")
    mk(root, "huge-fm", "---\nname: huge-fm\ndescription: d\nx: " + "a" * 200000 + "\n---\n")
    mk(root, "huge-file", raw=b"---\nname: huge-file\ndescription: d\n---\n" + b"z" * 3_000_000)
    (root / "dangling").mkdir(); os.symlink("/nonexistent/SKILL.md", root / "dangling/SKILL.md")
    os.symlink(root, root / "loop")                                  # directory loop
    r = run_ic(root)
    assert r.returncode in (0, 1) and "Traceback" not in r.stderr
    assert "huge-fm" in r.stdout and "FM_UNREADABLE" in r.stdout      # the oversized frontmatter is reported, not parsed


def test_yaml_alias_bomb_within_the_size_limit_finishes_quickly(tmp_path):
    bomb = "---\nname: bomb\ndescription: d\n" + "a: &a [x,x,x,x,x,x,x,x,x]\n" + "".join(f"{c}: &{c} [*{p},*{p},*{p},*{p},*{p},*{p},*{p},*{p},*{p}]\n" for p, c in zip("abcdefgh", "bcdefghi")) + "---\n"
    root = tmp_path / "p"; mk(root, "bomb", bomb)
    t = time.time(); r = run_ic(root)
    assert time.time() - t < 20 and "Traceback" not in r.stderr and r.returncode in (0, 1)


def test_output_is_terminal_safe(tmp_path):
    root = tmp_path / "p"; mk(root, "evil", "---\nname: evil\ndescription: d\n---\n")
    d = mk(root, "x\x1b[2Jfolder"); (d / "SKILL.md").write_text("no frontmatter at all")
    r = run_ic(root)
    assert "\x1b" not in r.stdout + r.stderr and "FM_MISSING" in r.stdout


def test_symlinks_are_hashed_by_target_not_followed(tmp_path):
    a, b = tmp_path / "a", tmp_path / "b"
    for d, target in ((a, "/etc/hostname"), (b, "/etc/passwd")):
        d.mkdir(); (d / "SKILL.md").write_text("x"); os.symlink(target, d / "link")
    assert ic.tree_hashes(a)["link"] != ic.tree_hashes(b)["link"]


def test_exit_contract_for_bad_arguments_and_missing_roots(tmp_path):
    assert run_ic(tmp_path / "does-not-exist").returncode == 0       # nothing found is not an error
    assert subprocess.run([sys.executable, str(ROOT / "scripts/interop_check.py"), "--bogus"], capture_output=True).returncode == 2
