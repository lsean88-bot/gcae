"""Entity-list consistency check + register_entity tool (synthetic AKOS tree)."""
import json, subprocess, sys
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import interop_check as ic  # noqa: E402
import register_entity as re_  # noqa: E402

SCHEMA = '''```json
{ "entity": "string (AAA|BBB|Group)", "x": 1 }
```
'''
TAXO = '''# Taxonomy

## 1. Entity Code Standard

MKTRON Group's nine entities, with their standard codes:

| Code | Entity | Country | Sector |
|---|---|---|---|
| AAA | Alpha | India | Mfg |
| BBB | Beta | Malaysia | Health |

Use `Group` when a document applies across all nine entities.

## 2. Next section
'''


@pytest.fixture
def akos(tmp_path):
    d = tmp_path / "akos"
    (d / "references").mkdir(parents=True)
    (d / "references/knowledge-graph-schema.md").write_text(SCHEMA)
    (d / "references/taxonomy-and-metadata-standards.md").write_text(TAXO)
    cfg = tmp_path / "entities.json"
    cfg.write_text(json.dumps({"entities": ["AAA", "BBB", "Group"]}))
    return d, cfg


def test_lists_agree(akos):
    d, cfg = akos
    lists = ic.entity_lists(d, cfg)
    assert set(lists) == {"AKOS schema enum", "AKOS taxonomy table", "bridge config/entities.json"}
    assert all(v == {"AAA", "BBB"} for v in lists.values())


def test_disagreement_is_detected_with_where(akos):
    d, cfg = akos
    cfg.write_text(json.dumps({"entities": ["AAA", "BBB", "CCC", "Group"]}))
    reg = d / "references/plugin-coordination-registry.md"
    reg.write_text("x\n")
    (d / "SKILL.md").write_text("---\nname: akos\ndescription: d\n---\n")
    summary, issues = ic.run([str(d.parent)], reg, set(), cfg)
    hit = [i for i in issues if i["code"] == "ENTITY_LISTS_DISAGREE"]
    assert hit and "AKOS schema enum: ['CCC']" in hit[0]["message"] and "taxonomy table: ['CCC']" in hit[0]["message"]


def test_register_dry_run_writes_nothing(akos, capsys):
    d, cfg = akos
    before = (d / "references/knowledge-graph-schema.md").read_text()
    assert re_.main(["--akos-dir", str(d), "--config", str(cfg), "--code", "CCC", "--name", "Gamma",
                     "--country", "Malaysia", "--sector", "Mfg"]) == 0
    assert (d / "references/knowledge-graph-schema.md").read_text() == before
    assert "dry run" in capsys.readouterr().out


def test_register_apply_updates_all_three_consistently(akos):
    d, cfg = akos
    assert re_.main(["--akos-dir", str(d), "--config", str(cfg), "--code", "CCC", "--name", "Gamma Sdn Bhd",
                     "--country", "Malaysia", "--sector", "Services", "--apply"]) == 0
    assert "(AAA|BBB|CCC|Group)" in (d / "references/knowledge-graph-schema.md").read_text()
    tax = (d / "references/taxonomy-and-metadata-standards.md").read_text()
    assert "| CCC | Gamma Sdn Bhd | Malaysia | Services |" in tax
    assert json.loads(cfg.read_text())["entities"] == ["AAA", "BBB", "CCC", "Group"]
    assert all(v == {"AAA", "BBB", "CCC"} for v in ic.entity_lists(d, cfg).values())
    assert (d / "references/knowledge-graph-schema.md.bak").exists()


def test_register_updates_count_wording(akos):
    d, cfg = akos
    t = d / "references/taxonomy-and-metadata-standards.md"
    t.write_text(t.read_text().replace("| AAA | Alpha | India | Mfg |\n| BBB | Beta | Malaysia | Health |",
                 "\n".join(f"| C{i} | n | c | s |" for i in range(9))).replace("AAA|BBB", "C0|C1|C2|C3|C4|C5|C6|C7|C8"))
    (d / "references/knowledge-graph-schema.md").write_text(
        SCHEMA.replace("AAA|BBB", "|".join(f"C{i}" for i in range(9))))
    cfg.write_text(json.dumps({"entities": [f"C{i}" for i in range(9)] + ["Group"]}))
    assert re_.main(["--akos-dir", str(d), "--config", str(cfg), "--code", "NEW", "--name", "n", "--country", "c",
                     "--sector", "s", "--apply"]) == 0
    assert "ten entities" in t.read_text()


@pytest.mark.parametrize("code", ["AAA", "Group", "bad/code", "", "x" * 40])
def test_register_refuses_duplicates_and_bad_codes(akos, code):
    d, cfg = akos
    assert re_.main(["--akos-dir", str(d), "--config", str(cfg), "--code", code, "--name", "n", "--country", "c",
                     "--sector", "s", "--apply"]) == 2
    assert json.loads(cfg.read_text())["entities"] == ["AAA", "BBB", "Group"]


def test_register_refuses_when_only_one_list_has_it(akos):
    d, cfg = akos
    cfg.write_text(json.dumps({"entities": ["AAA", "BBB", "CCC", "Group"]}))
    assert re_.main(["--akos-dir", str(d), "--config", str(cfg), "--code", "CCC", "--name", "n", "--country", "c",
                     "--sector", "s", "--apply"]) == 2
