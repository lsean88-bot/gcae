"""Dual-format reports: HTML dashboard + XLSX. Injection safety and confidentiality are the point."""
import json, subprocess, sys
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import akos_graph as ag  # noqa: E402
import brain  # noqa: E402
import report  # noqa: E402
from openpyxl import load_workbook  # noqa: E402

FIX = Path(__file__).parent / "fixtures" / "cld_kg.json"
ENV = ["GEMINI_API_KEY", "GOOGLE_API_KEY", "MOONSHOT_API_KEY", "ANTHROPIC_API_KEY", "OPENAI_API_KEY", "DEEPSEEK_API_KEY",
       "AZURE_OPENAI_API_KEY", "AZURE_OPENAI_ENDPOINT", "AWS_PROFILE", "AWS_REGION", "AWS_DEFAULT_REGION",
       "OLLAMA_BASE_URL", "OLLAMA_HOST", "GRAPHIFY_QUERY_LOG", "GRAPHIFY_QUERY_LOG_ENABLE"]


@pytest.fixture(autouse=True)
def clean_env(monkeypatch):
    for k in ENV:
        monkeypatch.delenv(k, raising=False)


def node(i, typ, label, conf="100%", ent="Group", **kw):
    return {"id": i, "type": typ, "label": label, "entity": ent, "created_date": "2026-10-01",
            "confidence": conf, "source_location": "https://x", **kw}


@pytest.fixture
def lib(tmp_path):
    L = tmp_path / "lib"
    brain.init_library(L)
    brain.add_shelf(L, "stat", "statutory", "Group", review_days=90)
    brain.add_shelf(L, "inv-x", "investigation", "MKSDL")
    e = lambda a, b: {"from": a, "to": b, "relationship": "relates_to", "evidence": "ev", "confidence": "High"}  # noqa: E731
    ag.atomic_write_json(L / "shelves/stat/KNOWLEDGE_GRAPH.json", {"engagement": "stat", "last_updated": "2026-10-01", "nodes": [
        node("R1", "Regulation", "<script>alert(1)</script> Minimum wage", review_by="2026-04-01"),
        node("R2", "Regulation", "=HYPERLINK(\"http://evil\",\"x\") rate", review_by="2027-01-01"),
        node("R3", "Regulation", "Provident fund rule")], "edges": [e("R1", "R2"), e("R2", "R3")]})
    ag.atomic_write_json(L / "shelves/inv-x/KNOWLEDGE_GRAPH.json", {"engagement": "inv-x", "confidential": True,
        "last_updated": "2026-10-01", "nodes": [node("ALG-SECRET-01", "Issue", "Kickback by vendor ACME", "Medium", "MKSDL", status="ALLEGED"),
                                                 node("V-1", "Vendor", "ACME Tooling", "High", "MKSDL")],
        "edges": [{**e("ALG-SECRET-01", "V-1"), "confidence": "Medium"}]})
    brain.index_library(L)
    brain.remember(L, "stat", "q?", "a", "useful")
    return L


def test_safe_neutralises_formula_injection():
    for bad in ("=1+1", "+cmd", "-2+3", "@SUM(A1)", "\t=x"):
        assert report.safe(bad).startswith("'")
    assert report.safe("plain") == "plain" and report.safe(5) == 5 and report.safe(None) is None


def test_html_escapes_labels_and_withholds_confidential_content(lib):
    out = report.build_dashboard(lib, lib.parent / "out", "2026-10-03")
    h = Path(out["html"]).read_text()
    assert "<script>alert(1)</script>" not in h and "&lt;script&gt;alert(1)&lt;/script&gt;" in h
    for secret in ("ALG-SECRET-01", "Kickback", "ACME"):
        assert secret not in h
    assert "confidential shelves are shown as counts only" in h and "inv-x" in h    # the shelf itself is listed, with counts


def test_html_is_self_contained_and_themed(lib):
    h = Path(report.build_dashboard(lib, lib.parent / "o", "2026-10-03")["html"]).read_text()
    assert "<script" not in h.lower().replace("&lt;script", "")                     # no scripts at all
    assert "src=" not in h and "href=" not in h and "prefers-color-scheme:dark" in h


def test_xlsx_structure_formulas_and_no_executable_cells(lib):
    out = report.build_dashboard(lib, lib.parent / "o2", "2026-10-03")
    wb = load_workbook(out["xlsx"])
    assert wb.sheetnames == ["Shelves", "Guard", "Stale", "Memory"]
    ws = wb["Shelves"]
    assert ws.cell(row=ws.max_row, column=5).value == "=SUM(E2:E3)"              # formula-driven totals
    stale = wb["Stale"]
    labels = [c.value for c in stale["C"]][1:]
    assert any(str(v).startswith("'=HYPERLINK") or "HYPERLINK" not in str(v) for v in labels)
    for sheet in wb:                                                              # nothing user-derived is a live formula
        for row in sheet.iter_rows():
            for c in row:
                if isinstance(c.value, str) and c.value.startswith("=") and sheet.title != "Shelves":
                    pytest.fail(f"live formula from data in {sheet.title}!{c.coordinate}: {c.value[:40]}")
    wb2 = load_workbook(out["xlsx"])
    assert "ALG-SECRET-01" not in json.dumps([[c.value for c in r] for s in wb2 for r in s.iter_rows()], default=str)


def test_stale_state_and_counts_in_dashboard(lib):
    d = report.collect(lib, "2026-10-03")
    assert any(i["id"] == "R1" and i["state"] == "STALE" for i in d["stale"])
    assert {m["outcome"] for m in d["memory"]} == {"useful"}
    row = {r["shelf"]: r for r in d["shelves"]}["inv-x"]
    assert row["confidential"] and row["nodes"] == 2


def test_kg_workbook_summary_formulas_and_validation_sheet(tmp_path):
    kg = json.loads(FIX.read_text())
    kg["nodes"][0]["label"] = "=cmd|' /C calc'!A0"
    out = report.write_kg_xlsx(kg, tmp_path / "kg.xlsx", "final")
    wb = load_workbook(out)
    assert wb.sheetnames == ["Summary", "Nodes", "Edges", "Validation"]
    s = {r[0].value: r[1].value for r in wb["Summary"].iter_rows(min_row=2)}
    assert s["Nodes"] == "=COUNTA(Nodes!A:A)-1" and s["Nodes at 100%"] == '=COUNTIF(Nodes!E:E,"100%")'
    assert wb["Nodes"]["C2"].value.startswith("'=")                              # injected label neutralised
    assert wb["Validation"]["A2"].value in ("OK", "ERROR", "WARN")


def run(*a):
    return subprocess.run([sys.executable, *map(str, a)], capture_output=True, text=True)


def test_cli_dashboard_and_export(lib, tmp_path):
    r = run(ROOT / "scripts/brain.py", "dashboard", lib, "--out", tmp_path / "d", "--today", "2026-10-03")
    assert r.returncode == 0 and (tmp_path / "d/brain-dashboard.html").exists() and (tmp_path / "d/brain-dashboard.xlsx").exists()
    r = run(ROOT / "scripts/akos_graph.py", "export-xlsx", FIX, "--out", tmp_path / "kg.xlsx", "--gate", "final")
    assert r.returncode == 0 and (tmp_path / "kg.xlsx").exists()
    assert run(ROOT / "scripts/brain.py", "dashboard", tmp_path / "nope", "--out", tmp_path / "x").returncode == 2
