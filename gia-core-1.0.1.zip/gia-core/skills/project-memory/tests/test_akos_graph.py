"""UAT/unit tests for the AKOS<->graphify bridge. Run: pytest tests/ -q"""
import copy, json, subprocess, sys
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import akos_graph as ag  # noqa: E402

FIX = Path(__file__).parent / "fixtures" / "cld_kg.json"


@pytest.fixture
def kg():
    return json.loads(FIX.read_text())


def codes(issues, sev=None):
    return {i["code"] for i in issues if sev is None or i["severity"] == sev}


# ---- validation -------------------------------------------------------------
def test_fixture_is_clean_at_final_gate(kg):
    assert ag.summarize(ag.validate_kg(kg, "final")) == {"errors": 0, "warnings": 0}


def test_dangling_edge_and_orphan_detected(kg):
    kg["edges"].append({"from": "CTRL-CLD-01", "to": "NOPE", "relationship": "supports", "evidence": "x", "confidence": "High"})
    kg["nodes"].append({**kg["nodes"][0], "id": "DOC-LONELY", "label": "Lonely"})
    c = codes(ag.validate_kg(kg, "final"), "ERROR")
    assert {"DANGLING_EDGE", "ORPHAN_NODE"} <= c


def test_orphan_is_warning_in_draft_error_in_final(kg):
    kg["nodes"].append({**kg["nodes"][0], "id": "DOC-LONELY", "label": "Lonely"})
    assert "ORPHAN_NODE" in codes(ag.validate_kg(kg, "draft"), "WARN")
    assert "ORPHAN_NODE" in codes(ag.validate_kg(kg, "final"), "ERROR")


def test_invalid_vocab(kg):
    kg["nodes"][0]["type"] = "Banana"
    kg["edges"][0]["relationship"] = "befriends"
    kg["edges"][1]["confidence"] = "Certain"
    c = codes(ag.validate_kg(kg), "ERROR")
    assert {"TYPE_INVALID", "REL_INVALID", "CONF_INVALID"} <= c


def test_100pct_edge_needs_evidence(kg):
    kg["edges"][0]["evidence"] = ""
    assert "EVIDENCE_REQUIRED" in codes(ag.validate_kg(kg), "ERROR") or \
           "EDGE_FIELD_MISSING" in codes(ag.validate_kg(kg), "ERROR")


def test_missing_source_location_is_error(kg):
    kg["nodes"][1]["source_location"] = ""
    assert "NODE_FIELD_MISSING" in codes(ag.validate_kg(kg), "ERROR")


def test_alleged_cannot_be_100pct(kg):
    kg["nodes"][3]["status"] = "ALLEGED"
    assert "ALLEGED_AS_CONFIRMED" in codes(ag.validate_kg(kg), "ERROR")


def test_indicator_only_cannot_be_high(kg):
    kg["edges"][1]["indicator_only"] = True
    assert "INDICATOR_AS_EVIDENCE" in codes(ag.validate_kg(kg), "ERROR")


def test_low_and_proposed_blocked_in_final_only(kg):
    kg["nodes"][2]["confidence"] = "Low"
    kg["nodes"][1]["status"] = "PROPOSED"
    assert not (codes(ag.validate_kg(kg, "draft"), "ERROR") & {"LOW_IN_FINAL", "STATUS_NOT_FINAL"})
    assert {"LOW_IN_FINAL", "STATUS_NOT_FINAL"} <= codes(ag.validate_kg(kg, "final"), "ERROR")


def test_unknown_entity_warn_draft_error_final(kg):
    kg["nodes"][0]["entity"] = "Perfect Longevity"
    assert "ENTITY_UNKNOWN" in codes(ag.validate_kg(kg, "draft"), "WARN")
    assert "ENTITY_UNKNOWN" in codes(ag.validate_kg(kg, "final"), "ERROR")


def test_near_duplicates_flagged(kg):
    kg["nodes"].append({**kg["nodes"][2], "id": "RISK-CLD-99", "label": "CLRA 1970  Non-Compliance!"})
    assert "NEAR_DUPLICATE" in codes(ag.validate_kg(kg), "WARN")


def test_duplicate_id_is_error(kg):
    kg["nodes"].append(copy.deepcopy(kg["nodes"][0]))
    assert "DUPLICATE_ID" in codes(ag.validate_kg(kg), "ERROR")


def test_confidential_leak(kg):
    kg["confidential"] = True
    kg["engagement"] = "INV-1"
    kg["nodes"][0]["engagement"] = "OTHER"
    assert "CONFIDENTIAL_LEAK" in codes(ag.validate_kg(kg), "ERROR")


# ---- to-graphify ------------------------------------------------------------
def test_extraction_is_graphify_valid(kg):
    from graphify.validate import validate_extraction
    assert validate_extraction(ag.kg_to_extraction(kg)) == []


def test_slug_collision_refused(kg):
    kg["nodes"].append({**kg["nodes"][0], "id": "doc.mkapl.0142"})
    with pytest.raises(ValueError, match="collision"):
        ag.kg_to_extraction(kg)


def test_confidence_mapping_never_inflates(kg):
    ext = ag.kg_to_extraction(kg)
    for e in ext["edges"]:
        if e["akos_confidence"] in ("Medium", "Low"):
            assert e["confidence"] != "EXTRACTED"


def test_build_outputs_and_attrs_survive(kg, tmp_path):
    meta = ag.build_graphify_outputs(kg, tmp_path, html=False)
    assert meta["nodes"] == 5 and meta["edges"] == 4
    g = json.loads((tmp_path / "graphify-out" / "graph.json").read_text())
    n = {x["akos_id"]: x for x in g["nodes"]}
    assert n["CTRL-CLD-01"]["akos_type"] == "Control" and n["CTRL-CLD-01"]["entity"] == "MKAPL-DC"
    assert n["DOC-MKAPL-0142"]["source_file"] == "/HR/Policies/CLD-Policy-v2.pdf"


# ---- round trip & direction ---------------------------------------------------
def test_round_trip_is_lossless_and_keeps_direction(kg, tmp_path):
    ag.build_graphify_outputs(kg, tmp_path, html=False)
    graph = json.loads((tmp_path / "graphify-out" / "graph.json").read_text())
    merged, rep = ag.graphify_to_staged(graph, copy.deepcopy(kg))
    assert rep["added_nodes"] == 0 and rep["added_edges"] == 0 and rep["conflicts"] == []
    # direction: FIND -> CTRL (tested_by) must not flip even though graphify is undirected
    keys = {(e["from"], e["to"], e["relationship"]) for e in merged["edges"]}
    assert ("FIND-CLD-14", "CTRL-CLD-01", "tested_by") in keys
    assert ("CTRL-CLD-01", "FIND-CLD-14", "tested_by") not in keys


def test_reverse_direction_edge_survives_standalone(kg, tmp_path):
    ag.build_graphify_outputs(kg, tmp_path, html=False)
    graph = json.loads((tmp_path / "graphify-out" / "graph.json").read_text())
    merged, _ = ag.graphify_to_staged(graph, None)  # no existing KG: rebuild purely from graph.json
    keys = {(e["from"], e["to"], e["relationship"]) for e in merged["edges"]}
    assert ("FIND-CLD-14", "CTRL-CLD-01", "tested_by") in keys


# ---- graphify-native input (AST/semantic, no AKOS attrs) ----------------------
NATIVE = {
    "nodes": [
        {"id": "a_policy", "label": "Policy doc", "file_type": "document", "source_file": "corpus/MKAPL-DC/policy.md"},
        {"id": "b_concept", "label": "Some concept", "file_type": "concept", "source_file": "corpus/x.md"},
        {"id": "c_code", "label": "duplicates()", "file_type": "code", "source_file": "corpus/p.py"}],
    "links": [
        {"source": "a_policy", "target": "b_concept", "relation": "semantically_similar_to", "confidence": "INFERRED", "confidence_score": 0.65, "source_file": "corpus/x.md"},
        {"source": "c_code", "target": "a_policy", "relation": "references", "confidence": "EXTRACTED", "confidence_score": 1.0, "source_file": "corpus/p.py", "source_location": "L4"},
        {"source": "b_concept", "target": "c_code", "relation": "conceptually_related_to", "confidence": "AMBIGUOUS", "confidence_score": 0.2, "source_file": "corpus/x.md"}],
}


def test_native_nodes_staged_never_guessed():
    kg, rep = ag.graphify_to_staged(NATIVE, None, {"MKAPL-DC": ["mkapl-dc"]}, "2026-10-03")
    by = {n["label"]: n for n in kg["nodes"]}
    assert by["Policy doc"]["type"] == "Document" and by["Policy doc"]["entity"] == "MKAPL-DC"
    assert by["Some concept"]["type"] == ag.UNCLASSIFIED and by["Some concept"]["entity"] == ag.UNCLASSIFIED
    assert all(n["status"] == "PROPOSED" and n["confidence"] != "100%" for n in kg["nodes"])
    assert len(rep["unclassified"]) == 2


def test_native_edges_capped_and_flagged():
    kg, rep = ag.graphify_to_staged(NATIVE, None, {}, "2026-10-03")
    by_rel = {e["original_relation"] if "original_relation" in e else e["relationship"]: e for e in kg["edges"]}
    assert by_rel["semantically_similar_to"]["confidence"] == "Low" and by_rel["semantically_similar_to"]["indicator_only"]
    assert by_rel["conceptually_related_to"]["confidence"] == "Low"
    ex = by_rel["references"]
    assert ex["confidence"] == "High" and "indicator_only" not in ex  # EXTRACTED never becomes 100%
    assert all(e["confidence"] != "100%" for e in kg["edges"])
    assert rep["indicator_edges"] == 2


def test_staged_output_cannot_pass_final_gate():
    kg, _ = ag.graphify_to_staged(NATIVE, None, {}, "2026-10-03")
    assert ag.summarize(ag.validate_kg(kg, "final"))["errors"] > 0


def test_existing_kg_is_authoritative(kg, tmp_path):
    ag.build_graphify_outputs(kg, tmp_path, html=False)
    graph = json.loads((tmp_path / "graphify-out" / "graph.json").read_text())
    for n in graph["nodes"]:
        if n["akos_id"] == "CTRL-CLD-01":
            n["label"] = "TAMPERED LABEL"
    merged, rep = ag.graphify_to_staged(graph, copy.deepcopy(kg))
    assert any(c["node"] == "CTRL-CLD-01" and c["field"] == "label" for c in rep["conflicts"])
    assert next(n for n in merged["nodes"] if n["id"] == "CTRL-CLD-01")["label"] == kg["nodes"][1]["label"]


# ---- merge / deliverable ------------------------------------------------------
def test_merge_refuses_confidential(kg):
    other = copy.deepcopy(kg)
    other["engagement"] = "INV-1"
    other["confidential"] = True
    with pytest.raises(PermissionError):
        ag.merge_kgs(kg, other)


def test_merge_conflict_and_union(kg):
    b = copy.deepcopy(kg)
    b["nodes"].append({**kg["nodes"][0], "id": "DOC-NEW", "label": "New doc"})
    b["edges"].append({"from": "DOC-NEW", "to": "CTRL-CLD-01", "relationship": "references", "evidence": "x", "confidence": "High"})
    m = ag.merge_kgs(kg, b)
    assert len(m["nodes"]) == 6 and len(m["edges"]) == 5
    b["nodes"][0]["label"] = "different"
    with pytest.raises(ValueError):
        ag.merge_kgs(kg, b)


def test_deliverable_filters(kg):
    staged, _ = ag.graphify_to_staged(NATIVE, copy.deepcopy(kg), {}, "2026-10-03")
    out, rep = ag.deliverable_subset(staged)
    assert rep["nodes_kept"] == 5 and rep["nodes_excluded"] == 3
    assert all(n.get("status") != "PROPOSED" for n in out["nodes"])
    assert ag.summarize(ag.validate_kg(out, "final"))["errors"] == 0


# ---- CLI ----------------------------------------------------------------------
def run(*args):
    return subprocess.run([sys.executable, str(ROOT / "scripts" / "akos_graph.py"), *map(str, args)],
                          capture_output=True, text=True)


def test_cli_validate_exit_codes(kg, tmp_path):
    ok = run("validate", FIX, "--gate", "final")
    assert ok.returncode == 0, ok.stdout + ok.stderr
    kg["edges"].append({"from": "X", "to": "Y", "relationship": "supports", "evidence": "e", "confidence": "High"})
    bad = tmp_path / "bad.json"; bad.write_text(json.dumps(kg))
    assert run("validate", bad).returncode == 1


def test_cli_missing_file_exit_2(tmp_path):
    assert run("validate", tmp_path / "nope.json").returncode == 2


def test_cli_end_to_end(tmp_path):
    r = run("to-graphify", FIX, "--out", tmp_path / "o", "--no-html")
    assert r.returncode == 0, r.stderr
    r = run("from-graphify", tmp_path / "o" / "graphify-out" / "graph.json", "--kg", FIX, "--out", tmp_path / "s.json")
    assert r.returncode == 0 and json.loads(r.stdout)["added_nodes"] == 0
    assert run("stats", tmp_path / "s.json").returncode == 0


def test_graphify_cli_can_query_bridge_output(tmp_path):
    run("to-graphify", FIX, "--out", tmp_path / "o", "--no-html")
    g = tmp_path / "o" / "graphify-out" / "graph.json"
    r = subprocess.run(["graphify", "path", "FIND-CLD-14", "RISK-CLD-03", "--graph", str(g)], capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr


# ---- graphify work-memory guard (saved Q&A must never become evidence) -------------
MEM_GRAPH = {
    "nodes": [
        {"id": "doc_a", "label": "Real policy", "file_type": "document", "source_file": "corpus/policy.md"},
        {"id": "mem_q", "label": "query_20261003_what_is_clrr", "file_type": "document",
         "source_file": "/proj/graphify-out/memory/query_20261003_120000_what_is_clrr.md"}],
    "links": [{"source": "mem_q", "target": "doc_a", "relation": "references", "confidence": "EXTRACTED",
               "confidence_score": 1.0, "source_file": "/proj/graphify-out/memory/query_20261003_120000_what_is_clrr.md"}],
}


def test_memory_path_detection():
    assert ag.is_memory_origin("/p/graphify-out/memory/query_x.md")
    assert ag.is_memory_origin("C:\\p\\graphify-out\\memory\\query_x.md")
    assert not ag.is_memory_origin("/HR/memory-policy.md")
    assert not ag.is_memory_origin("")


def test_memory_nodes_and_edges_are_capped_low_even_if_extracted():
    kg, rep = ag.graphify_to_staged(MEM_GRAPH, None, {}, "2026-10-03")
    mem = next(n for n in kg["nodes"] if n["label"].startswith("query_"))
    assert mem["origin"] == "graphify-memory" and mem["confidence"] == "Low" and mem["indicator_only"]
    edge = kg["edges"][0]
    assert edge["confidence"] == "Low" and edge["origin"] == "graphify-memory" and edge["indicator_only"]
    assert rep["memory_nodes"] == 1


def test_validate_blocks_memory_elevated_above_low():
    kg, _ = ag.graphify_to_staged(MEM_GRAPH, None, {}, "2026-10-03")
    for n in kg["nodes"]:
        if n.get("origin") == "graphify-memory":
            n["confidence"] = "High"
    assert "MEMORY_AS_EVIDENCE" in codes(ag.validate_kg(kg), "ERROR")
    kg["edges"][0]["confidence"] = "High"
    assert sum(1 for i in ag.validate_kg(kg) if i["code"] == "MEMORY_AS_EVIDENCE") == 2


def test_deliverable_never_includes_memory_origin(kg):
    staged, _ = ag.graphify_to_staged(MEM_GRAPH, copy.deepcopy(kg), {}, "2026-10-03")
    for n in staged["nodes"]:
        n.pop("status", None)          # even if someone 'confirms' it by deleting the PROPOSED flag...
    for e in staged["edges"]:
        e.pop("status", None)
    for n in staged["nodes"]:
        if n.get("origin") == "graphify-memory":
            n["confidence"] = "100%"   # ...and inflates confidence, the deliverable still excludes it
    out, _ = ag.deliverable_subset(staged)
    assert not [n for n in out["nodes"] if n.get("origin") == "graphify-memory"]
    assert not [e for e in out["edges"] if e.get("origin") == "graphify-memory"]
