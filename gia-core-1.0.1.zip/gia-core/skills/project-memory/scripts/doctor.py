"""doctor.py - self-check of the environment and (optionally) a library (layer L2).

Each check returns {name, status: OK|WARN|FAIL, detail, remedy}. FAIL means a required capability is missing;
WARN means something works but is risky or optional; the exit code is 1 only for FAIL.
"""
from __future__ import annotations

import importlib
import importlib.metadata
import os
import shutil
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import fsutil


def _c(name, status, detail, remedy=""):
    return {"name": name, "status": status, "detail": detail, "remedy": remedy}


def _version(pkg):
    try:
        return importlib.metadata.version(pkg)
    except importlib.metadata.PackageNotFoundError:
        return None


def run_checks(lib=None, env=None) -> list[dict]:
    env = os.environ if env is None else env
    out = []
    v = sys.version_info
    out.append(_c("python", "OK" if v >= (3, 10) else "FAIL", f"{v.major}.{v.minor}.{v.micro}",
                  "" if v >= (3, 10) else "Python 3.10 or newer is required"))

    try:
        importlib.import_module("graphify")
        out.append(_c("graphify", "OK", f"importable (distribution {_version('graphifyy') or _version('graphify') or 'version unknown'})"))
    except Exception as exc:
        out.append(_c("graphify", "FAIL", f"cannot import graphify: {exc}", "pip install -e <graphify checkout>"))
    out.append(_c("graphify CLI", "OK" if shutil.which("graphify") else "WARN",
                  shutil.which("graphify") or "not on PATH (needed for `reflect`)", "" if shutil.which("graphify") else "pip install -e <graphify checkout>"))
    for mod, needed_for, level in (("openpyxl", "Excel output (dashboard, export-xlsx)", "FAIL"), ("yaml", "interop frontmatter parsing (falls back to a simple parser)", "WARN"),
                                   ("mcp", "graphify MCP server", "WARN")):
        try:
            importlib.import_module(mod)
            out.append(_c(mod, "OK", f"available ({_version({'yaml': 'PyYAML'}.get(mod, mod)) or 'ok'})"))
        except Exception:
            out.append(_c(mod, level, f"missing: needed for {needed_for}",
                          f"pip install {({'yaml': 'pyyaml'}).get(mod, mod)}" + (" --ignore-installed PyJWT" if mod == "mcp" else "")))

    # file-system guarantees actually work HERE (a network share or odd file system can break locks)
    tmp = Path(tempfile.mkdtemp(prefix="gia-doctor-"))
    try:
        fsutil.atomic_write_json(tmp / "a.json", {"ok": True})
        with fsutil.FileLock(tmp / "l.lock", timeout=2):
            pass
        out.append(_c("atomic write + lock", "OK", "work on the temporary directory"))
    except Exception as exc:
        out.append(_c("atomic write + lock", "FAIL", f"{type(exc).__name__}: {exc}", "use a local disk for the library"))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)

    if lib is not None:
        lib = Path(lib)
        try:
            probe = lib / ".doctor-probe"
            fsutil.atomic_write_text(probe, "x")
            probe.unlink()
            with fsutil.FileLock(lib / ".doctor.lock", timeout=2):
                pass
            (lib / ".doctor.lock").unlink(missing_ok=True)
            out.append(_c("library writable and lockable", "OK", str(lib)))
        except Exception as exc:
            out.append(_c("library writable and lockable", "FAIL", f"{type(exc).__name__}: {exc}",
                          "check permissions, and that the library is not on a network share without lock support"))
        free = shutil.disk_usage(lib if lib.exists() else lib.parent).free // (1024 * 1024)
        out.append(_c("disk space", "OK" if free >= 500 else "WARN", f"{free} MB free", "" if free >= 500 else "free some space before indexing large libraries"))
        links = fsutil.find_symlinks(lib) if lib.exists() else []
        out.append(_c("symbolic links in library", "OK" if not links else "FAIL",
                      "none" if not links else f"{len(links)} found, e.g. {links[0]}", "" if not links else "remove them; links inside a library are refused"))
        pend = [p for p in (lib / "index").glob("*.old-*")] if (lib / "index").exists() else []
        out.append(_c("interrupted index swap", "OK" if not pend else "WARN", "none" if not pend else f"{len(pend)} leftover(s)",
                      "" if not pend else "run `brain.py index <lib>`: it restores them first"))

    local = datetime.now().astimezone()
    utc = datetime.now(timezone.utc)
    note = "same calendar date as UTC" if local.date() == utc.date() else f"local date {local.date()} differs from UTC {utc.date()} right now (the tool uses LOCAL)"
    out.append(_c("time zone", "OK", f"{local.tzname()} UTC{local.strftime('%z')}; {note}"))
    um = os.umask(0)
    os.umask(um)
    out.append(_c("umask", "OK" if (um & 0o022) == 0o022 or os.name != "posix" else "WARN", f"{um:04o}",
                  "" if (um & 0o022) == 0o022 or os.name != "posix" else "a permissive umask can leave new files group-writable"))
    try:
        from graphify import llm
        picked = llm.detect_backend()
        cloud = picked not in (None, "claude", "claude-cli", "ollama")
        out.append(_c("extraction backend (auto-detect)", "WARN" if cloud else "OK", f"graphify would pick: {picked!r}",
                      "pass --backend explicitly for confidential material; unset unneeded API keys" if cloud else ""))
    except Exception as exc:
        out.append(_c("extraction backend (auto-detect)", "WARN", f"cannot determine: {exc}"))
    for k in ("GIA_DEBUG", "GIA_TODAY", "GIA_NO_FSYNC", "GIA_MAX_JSON_BYTES"):
        if env.get(k):
            out.append(_c(f"env {k}", "WARN", f"set to {env.get(k)!r}", "intended for tests and debugging; unset for production"))
    return out
