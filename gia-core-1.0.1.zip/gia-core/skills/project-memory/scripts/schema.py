"""schema.py - structural checks that must pass BEFORE any other code touches a document (layer L0).

validate_kg() in akos_graph reports *content* problems (missing fields, bad vocabulary). This module answers the
earlier question: is the thing even the right SHAPE? Wrong shape -> a clear InputError, never a traceback.
"""
from __future__ import annotations

from errors import InputError, RefusedError

KG_SCHEMA_VERSION = 1          # written into new Knowledge Graphs
KG_MAX_SUPPORTED = 1           # newest version this build understands
LIBRARY_SCHEMA_VERSION = 1


def _scalar(v) -> bool:
    return isinstance(v, (str, int)) and not isinstance(v, bool)


def kg_problems(obj, strict_edges: bool = False) -> list[str]:
    if not isinstance(obj, dict):
        return [f"the top level must be a JSON object, not {type(obj).__name__}"]
    out = []
    ver = obj.get("schema_version")
    if ver is not None and not (isinstance(ver, int) and not isinstance(ver, bool)):
        out.append("schema_version must be an integer")
    for key in ("nodes", "edges"):
        v = obj.get(key, [])
        if not isinstance(v, list):
            out.append(f"'{key}' must be a list, not {type(v).__name__}")
            continue
        for i, item in enumerate(v):                                  # ONE pass per list: this runs on every command
            if not isinstance(item, dict):
                out.append(f"{key}[{i}] must be an object, not {type(item).__name__}")
            elif key == "nodes":
                if "id" in item:
                    if not _scalar(item["id"]):
                        out.append(f"nodes[{i}].id must be text or a number, not {type(item['id']).__name__}")
                elif strict_edges:
                    out.append(f"nodes[{i}] has no usable 'id' (run `validate` to see every field problem)")
            elif strict_edges:
                for end in ("from", "to"):
                    if not _scalar(item.get(end)):
                        out.append(f"edges[{i}] needs a text '{end}' (run `validate` to see every field problem)")
            if len(out) > 25:
                return out
    return out


def require_kg(obj, where: str = "knowledge graph", strict_edges: bool = False) -> dict:
    probs = kg_problems(obj, strict_edges)
    if probs:
        more = f" (+{len(probs) - 5} more)" if len(probs) > 5 else ""
        raise InputError(f"{where} is not a valid Knowledge Graph: " + "; ".join(probs[:5]) + more)
    ver = obj.get("schema_version")
    if isinstance(ver, int) and ver > KG_MAX_SUPPORTED:
        raise RefusedError(f"{where} has schema_version {ver}, but this tool understands up to {KG_MAX_SUPPORTED}. "
                           f"Upgrade the tool; do not edit around it")
    return obj


def graph_problems(obj) -> list[str]:
    """Shape of a graphify graph.json (node-link)."""
    if not isinstance(obj, dict):
        return [f"the top level must be a JSON object, not {type(obj).__name__}"]
    out = []
    nodes = obj.get("nodes", [])
    if not isinstance(nodes, list):
        out.append(f"'nodes' must be a list, not {type(nodes).__name__}")
    else:
        for i, n in enumerate(nodes[:100000]):
            if not isinstance(n, dict) or "id" not in n or not _scalar(n.get("id")):
                out.append(f"nodes[{i}] must be an object with a text 'id'")
                if len(out) > 25:
                    break
    for key in ("links", "edges"):
        if key in obj:
            v = obj[key]
            if not isinstance(v, list):
                out.append(f"'{key}' must be a list, not {type(v).__name__}")
            elif any(not isinstance(e, dict) for e in v):
                out.append(f"every entry of '{key}' must be an object")
    return out


def require_graph(obj, where: str = "graph") -> dict:
    probs = graph_problems(obj)
    if probs:
        raise InputError(f"{where} is not a valid graphify graph: " + "; ".join(probs[:5]))
    return obj
