#!/usr/bin/env python3
"""brain.py - the "library brain": a shelved, confidentiality-aware knowledge base (layer L2).

Layers (each has ONE job, and none may impersonate another):

  shelf KNOWLEDGE_GRAPH.json   confirmed + proposed facts (AKOS owns integrity)
  graphify-out/graph.json      analysis view of the shelf (clustering, path, query, MCP)
  graphify-out/memory/*.md     WORK MEMORY: which answers helped / dead-ended / were corrected.
                               An *indicator* of usefulness - never evidence (Iron Rule 17)
  index/global                 derived, rebuildable graph over NON-confidential shelves only
  lessons/PROPOSED_LESSONS.md  Kaizen candidates (non-confidential shelves only). The owner promotes (Module 7)
  audit.log                    hash-chained, append-only record of every change made through this tool
  shelves/<s>/.seals/          snapshots taken by `seal`, the baseline for `changes`

Commands: init, shelf-add, index, recall, remember, reflect, stale, status, guard, mcp-config, dashboard,
          seal, changes, verify, doctor.
Exit codes: 0 ok, 1 findings that need action, 2 bad input / refused / lock timeout, 3 internal error.
Writers take a per-shelf (or library) lock, so concurrent runs cannot lose each other's updates.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import akos_graph as ag  # noqa: E402
import audit  # noqa: E402
import fsutil  # noqa: E402
import schema  # noqa: E402
import strictjson  # noqa: E402
import textnorm  # noqa: E402
import textsafe  # noqa: E402
from errors import GiaError, InputError, LockTimeout, RefusedError, run_cli  # noqa: E402

BRAIN_VERSION = "2.0.0"
KINDS = ("engagement", "statutory", "policy", "investigation", "reference")
OUTCOMES = ("useful", "dead_end", "corrected")
DEFAULT_ALLOWED_BACKENDS = ["claude", "claude-cli", "ollama"]
SHELF_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,60}$")
READ_ERRORS = (OSError, ValueError)            # ValueError covers InputError, RefusedError-free JSON problems
MAX_QUESTION, MAX_ANSWER, MAX_CORRECTION, MAX_NODES = 2_000, 200_000, 20_000, 200
STOP = set(("the a an of and or to in on for with by is are was be it as at from that this what which who how why "
            "do does did we our your their there any all into than then "          # English
            "de la el los las y en para por con del un una "                        # Spanish
            "dan yang di untuk dengan atau dalam").split())                         # Malay
STARTER_SYNONYMS = {
    "_comment": "EDITABLE. Groups of phrases treated as equivalent when recalling. Wrong entries degrade retrieval, "
                "so every expansion is returned in 'expanded_terms' for audit. Add your own jurisdiction terms.",
    "groups": [
        ["epf", "employees provident fund", "provident fund"],
        ["esic", "esi", "employees state insurance"],
        ["gst", "goods and services tax"],
        ["tds", "tax deducted at source"],
        ["clra", "contract labour act", "contract labour regulation and abolition act"],
        ["socso", "perkeso"],
        ["pcb", "mtd", "monthly tax deduction"],
        ["min wage", "minimum wage", "minimum wages"],
        ["payroll", "nomina", "gaji", "salary register"],
    ],
}
TRUST_ORDER = {"CONFIRMED": 0, "PROVISIONAL": 1, "INDICATOR": 2}


class BrainError(GiaError):
    """A user-fixable problem with a library, shelf or argument (exit code 2)."""


# ---- paths, locks & io -------------------------------------------------------------------
def now_iso() -> str:
    return fsutil.now_utc_iso()


def _today_local() -> str:
    return fsutil.today_local()


def paths(lib: Path):
    return {"manifest": lib / "brain.json", "shelves": lib / "shelves", "index": lib / "index",
            "lessons": lib / "lessons"}


def lib_lock(lib, timeout: float = 120.0):
    return fsutil.FileLock(Path(lib) / ".lock", timeout=timeout)


def shelf_lock(lib, name, timeout: float = 120.0):
    return fsutil.FileLock(shelf_dir(Path(lib), name) / ".lock", timeout=timeout)


def load_manifest(lib: Path) -> dict:
    lib = Path(lib)
    mf = paths(lib)["manifest"]
    if not mf.is_file():
        raise BrainError(f"{lib} is not a brain library (no brain.json). Run: brain.py init {lib}")
    data = ag.load_json(mf)
    if not isinstance(data, dict) or not isinstance(data.get("shelves"), list) or not all(isinstance(s, str) for s in data["shelves"]) \
            or not isinstance(data.get("policy", {}), dict):
        raise InputError(f"{mf} is not a valid library manifest")
    data.setdefault("policy", {})
    ver = data.get("schema_version", 1)
    if isinstance(ver, int) and ver > schema.LIBRARY_SCHEMA_VERSION:
        raise RefusedError(f"{lib} was written by a newer version (schema {ver}; this tool understands "
                           f"{schema.LIBRARY_SCHEMA_VERSION}). Upgrade the tool; do not edit around it")
    return data


def lock_down(path: Path) -> None:
    """Confidential shelf: owner-only (dirs 0700, files 0600). Never follows or touches a symlink."""
    fsutil.tree_chmod(path, 0o700, 0o600)


def world_readable_files(path: Path) -> list[str]:
    return fsutil.loose_files(path)


def shelf_mode(meta: dict) -> int:
    return 0o600 if meta.get("confidential") else 0o644


def shelf_dir(lib: Path, name: str) -> Path:
    lib = Path(lib)
    if not isinstance(name, str) or not SHELF_RE.match(name):
        raise BrainError(f"unknown shelf {name!r}")
    d = fsutil.ensure_within(lib, f"shelves/{name}")           # refuses traversal and symlinks
    if not d.is_dir():
        raise BrainError(f"unknown shelf {name!r}")
    return d


def shelf_meta(lib: Path, name: str) -> dict:
    meta = ag.load_json(shelf_dir(lib, name) / "shelf.json")
    if not isinstance(meta, dict) or not isinstance(meta.get("kind"), str) or "confidential" not in meta:
        raise InputError(f"shelf {name!r}: shelf.json is not valid")
    return meta


def shelf_kg(lib: Path, name: str) -> dict:
    kg = ag.load_json(shelf_dir(lib, name) / "KNOWLEDGE_GRAPH.json")
    return schema.require_kg(kg, f"shelf {name!r}", strict_edges=True)


def tokens(text: str) -> list[str]:
    """Script-aware search tokens (see textnorm). Single ASCII characters are noise; single non-ASCII ones are words."""
    return [t for t in textnorm.tokens(text) if (len(t) > 1 or not t.isascii()) and t not in STOP]


def _bounded(lo: int, hi: int):
    def conv(s):
        try:
            v = int(s)
        except ValueError:
            raise argparse.ArgumentTypeError(f"{s!r} is not a whole number")
        if not lo <= v <= hi:
            raise argparse.ArgumentTypeError(f"{v} is outside the allowed range {lo}..{hi}")
        return v
    return conv


# ---- init / shelf-add ---------------------------------------------------------------------
def init_library(lib: Path, allowed_backends=None) -> dict:
    lib = Path(lib)
    if (lib / "brain.json").exists():
        raise BrainError(f"{lib} already contains a brain library")
    for p in ("shelves", "index", "lessons"):
        (lib / p).mkdir(parents=True, exist_ok=True)
    mf = {"version": BRAIN_VERSION, "schema_version": schema.LIBRARY_SCHEMA_VERSION, "created": now_iso(), "shelves": [],
          "policy": {"allowed_backends": allowed_backends or DEFAULT_ALLOWED_BACKENDS,
                     "confidential_never_in_global": True, "query_log": "off"}}
    ag.atomic_write_json(lib / "brain.json", mf)
    ag.atomic_write_json(lib / "synonyms.json", STARTER_SYNONYMS)
    audit.append(lib, "init", detail={"version": BRAIN_VERSION})
    return mf


def add_shelf(lib: Path, name: str, kind: str, entity: str, confidential=False,
              review_days: int | None = None, jurisdiction: str | None = None) -> dict:
    lib = Path(lib)
    if not isinstance(name, str) or not SHELF_RE.match(name):
        raise BrainError("shelf name must be lowercase letters, digits, hyphens (max 61 chars)")
    if kind not in KINDS:
        raise BrainError(f"kind must be one of {KINDS}")
    if entity not in ag.known_entities():
        raise BrainError(f"entity {entity!r} is not in config/entities.json - add it there (and in the AKOS "
                         f"schema) first; the brain will not invent entity codes")
    with lib_lock(lib):                                         # the manifest is read-modify-write: serialise it
        mf = load_manifest(lib)
        if name in mf["shelves"]:
            raise BrainError(f"shelf {name!r} already exists")
        confidential = bool(confidential) or kind == "investigation"  # investigations are always isolated
        meta = {"name": name, "kind": kind, "entity": entity, "confidential": confidential,
                "jurisdiction": jurisdiction, "review_days": review_days, "created": now_iso()}
        d = paths(lib)["shelves"] / name
        if d.exists():
            raise BrainError(f"shelf folder {name!r} already exists on disk but is not in the manifest; "
                             f"move it aside or remove it first")
        d.mkdir(parents=True)
        ag.atomic_write_json(d / "shelf.json", meta, shelf_mode(meta))
        ag.atomic_write_json(d / "KNOWLEDGE_GRAPH.json", {
            "schema_version": schema.KG_SCHEMA_VERSION, "engagement": name, "confidential": confidential,
            "last_updated": _today_local(), "nodes": [], "edges": []}, shelf_mode(meta))
        if confidential:
            lock_down(d)
        mf["shelves"].append(name)
        ag.atomic_write_json(paths(lib)["manifest"], mf)
    audit.append(lib, "shelf-add", name, {"kind": kind, "entity": entity, "confidential": confidential})
    return meta


# ---- index ---------------------------------------------------------------------------------
def namespaced_global_kg(lib: Path, mf: dict, skip=()) -> tuple[dict, dict]:
    """Union of NON-confidential, healthy shelves; ids namespaced 'shelf::ID' so group-wide id clashes can't merge.
    A shelf that failed indexing (`skip`), is unreadable, or would collide with an earlier shelf after id
    normalisation is EXCLUDED and reported: one bad shelf must never stop the others' global graph."""
    per_shelf, included, excluded = {}, [], []
    for name in mf["shelves"]:
        if name in skip:
            excluded.append({"shelf": name, "reason": "failed-indexing"})
            continue
        try:
            meta, kg = shelf_meta(lib, name), shelf_kg(lib, name)
        except (GiaError,) + READ_ERRORS:
            excluded.append({"shelf": name, "reason": "unreadable"})  # one bad file must not sink the library
            continue
        if meta["confidential"] or kg.get("confidential"):
            excluded.append({"shelf": name, "reason": "confidential"})
            continue
        nodes, edges = [], []
        for n in kg.get("nodes", []):
            m = dict(n)
            m.update({"id": f"{name}::{n['id']}", "shelf": name, "shelf_kind": meta["kind"]})
            nodes.append(m)
        for e in kg.get("edges", []):
            m = dict(e)
            m.update({"from": f"{name}::{e['from']}", "to": f"{name}::{e['to']}"})
            edges.append(m)
        per_shelf[name] = (nodes, edges)
    seen: dict[str, str] = {}
    all_nodes, all_edges = [], []
    for name in mf["shelves"]:
        if name not in per_shelf:
            continue
        nodes, edges = per_shelf[name]
        slugs = [ag.slug(n["id"]) for n in nodes]
        clash = next((sl for sl in slugs if sl in seen and seen[sl] != name), None)
        if clash:
            excluded.append({"shelf": name, "reason": "id-collision-across-shelves"})
            continue
        for sl in slugs:
            seen[sl] = name
        included.append(name)
        all_nodes += nodes
        all_edges += edges
    gkg = {"engagement": "LIBRARY-GLOBAL", "last_updated": _today_local(), "nodes": all_nodes, "edges": all_edges}
    return gkg, {"included": included, "excluded": excluded}


def _index_shelf(lib: Path, name: str, html: bool) -> dict:
    sd = shelf_dir(lib, name)
    kg = shelf_kg(lib, name)
    issues = ag.validate_kg(kg, "draft")
    entry = {"nodes": len(kg.get("nodes", [])), "edges": len(kg.get("edges", [])), **ag.summarize(issues)}
    if not kg.get("nodes"):
        entry["status"] = "EMPTY"
    else:
        entry["graphify"] = ag.build_graphify_outputs(kg, sd, html=html)
        entry["status"] = "INDEXED"
        if shelf_meta(lib, name)["confidential"]:
            lock_down(sd)
    return entry


def index_library(lib: Path, html=False) -> dict:
    """Build every shelf's graph and the global graph. Each shelf is isolated: one failure is reported, never fatal.
    The global graph is built in a staging directory and swapped in by rename, so it is always old-or-new."""
    lib = Path(lib)
    load_manifest(lib)
    with lib_lock(lib, timeout=600):
        fsutil.recover_pending(paths(lib)["index"], names={"global"})
        fsutil.clean_temp(lib)                                  # debris from writes that were killed mid-flight
        mf = load_manifest(lib)
        report = {"built_at": now_iso(), "shelves": {}, "global": None, "failed_shelves": []}
        for name in mf["shelves"]:
            try:
                with shelf_lock(lib, name, timeout=120):
                    report["shelves"][name] = _index_shelf(lib, name, html)
            except Exception as exc:                            # isolation: report and continue
                report["shelves"][name] = {"status": "ERROR", "detail": textsafe.display(f"{type(exc).__name__}: {exc}", 300)}
                report["failed_shelves"].append(name)
        gkg, split = namespaced_global_kg(lib, mf, skip=set(report["failed_shelves"]))
        for x in split["excluded"]:
            if x["reason"] == "id-collision-across-shelves":
                report["shelves"][x["shelf"]] = {"status": "ERROR", "detail": "ids collide with an earlier shelf after normalisation"}
                report["failed_shelves"].append(x["shelf"])
        excluded_names = {x["shelf"] for x in split["excluded"]}
        leaked = [n["id"] for n in gkg["nodes"] if n["shelf"] in excluded_names]
        if leaked:  # defence in depth; cannot happen unless namespacing is broken
            raise BrainError(f"confidential content reached the global graph: {leaked[:3]}")
        index_dir = paths(lib)["index"]
        staging = index_dir / f".staging-{os.getpid()}"
        shutil.rmtree(staging, ignore_errors=True)
        try:
            staging.mkdir(parents=True)
            ag.atomic_write_json(staging / "global_kg.json", gkg)
            if gkg["nodes"]:
                meta = ag.build_graphify_outputs(gkg, staging, html=html)
                report["global"] = {**split, **meta}
            else:
                report["global"] = {**split, "nodes": 0, "edges": 0}
            fsutil.replace_dir(staging, index_dir / "global")
        except Exception as exc:
            report["global"] = {**split, "status": "ERROR", "detail": textsafe.display(f"{type(exc).__name__}: {exc}", 300)}
            report["failed_shelves"].append("(global)")
            shutil.rmtree(staging, ignore_errors=True)
        ag.atomic_write_json(index_dir / "index_report.json", report)
    audit.append(lib, "index", detail={"shelves": {k: v.get("status") for k, v in report["shelves"].items()},
                                        "failed": report["failed_shelves"]})
    return report


# ---- recall ------------------------------------------------------------------------------------
def trust_label(node: dict, shelf_confidential=False) -> str:
    rk = node.get("evidence_rank")
    if node.get("origin") == "graphify-memory" or node.get("indicator_only") or node.get("status") in (
            "PROPOSED", "ALLEGED", "RETRACTED") or node.get("confidence") == "Low" or rk == "R5":
        return "INDICATOR"                      # R5 (verbal / unverified) can never be relied on
    if rk == "R4":
        return "PROVISIONAL"                    # management-prepared or unverified: needs corroboration
    if node.get("confidence") in ("100%", "High"):
        return "CONFIRMED"
    return "PROVISIONAL"


def staleness(node: dict, meta: dict, today: str) -> str | None:
    """STALE / UNDATED / BAD_DATE for statutory Regulation nodes. An unreadable date is never treated as fresh."""
    if meta["kind"] != "statutory" or node.get("type") != "Regulation":
        return None
    rb = node.get("review_by")
    if rb in (None, ""):
        return "UNDATED"
    d = ag.parse_iso_date(rb)
    if d is None:
        return "BAD_DATE"
    t = ag.parse_iso_date(today)
    if t is None:
        raise BrainError(f"--today {today!r} is not YYYY-MM-DD")
    return "STALE" if d < t else None


def load_synonyms(lib: Path) -> list[list[tuple[str, ...]]]:
    f = Path(lib) / "synonyms.json"
    if not f.exists():
        return []
    data = ag.load_json(f)
    groups = data.get("groups", []) if isinstance(data, dict) else []
    out = []
    for g in groups if isinstance(groups, list) else []:
        if isinstance(g, list):
            out.append([tuple(tokens(ph)) for ph in g if isinstance(ph, str) and tokens(ph)])
    return out


def expand_query(lib: Path, qset: set[str]) -> dict[str, float]:
    """token -> weight. Original tokens weigh 1.0; synonym-derived tokens 0.5 and are reported for audit."""
    w = {t: 1.0 for t in qset}
    for group in load_synonyms(lib):
        if any(set(ph) <= qset for ph in group):
            for ph in group:
                for t in ph:
                    w.setdefault(t, 0.5)
    return w


def _hay(text) -> str:
    """Lower-cased, accent-folded text for a cheap 'could any query token be in here' pre-check."""
    t = text if isinstance(text, str) else str(text)
    return t.lower() if t.isascii() else textnorm.fold(t)


def _matches(weights: dict, n: dict) -> list[tuple[float, str]]:
    """(field multiplier, token) for every query token found in the node. A field is only tokenised when a query token
    appears in it as a substring (a necessary condition), which skips most nodes cheaply."""
    out: list[tuple[float, str]] = []
    label = n.get("label", "")
    label = label if isinstance(label, str) else str(label)
    if any(t in _hay(label) for t in weights):
        out += [(2.0, t) for t in set(tokens(label)) if t in weights]
    ident = str(n["id"])
    if any(t in _hay(ident) for t in weights):
        out += [(3.0, t) for t in set(tokens(ident)) if t in weights]
    meta = f"{n.get('type', '')} {n.get('entity', '')}"
    if any(t in _hay(meta) for t in weights):
        out += [(0.5, t) for t in set(tokens(meta)) if t in weights]
    return out


RANKINGS = ("score", "idf")


def recall(lib: Path, question: str, shelves=None, min_conf="Low", limit=8, today=None, max_rank=None, ranking="score") -> dict:
    today = today or _today_local()
    lib = Path(lib)
    mf = load_manifest(lib)
    if ag.parse_iso_date(today) is None:
        raise BrainError(f"--today {today!r} is not YYYY-MM-DD")
    if not isinstance(limit, int) or not 1 <= limit <= 1000:
        raise BrainError("limit must be a whole number from 1 to 1000")
    shelves = list(shelves or [])
    for s_ in shelves:
        if s_ not in mf["shelves"]:
            raise BrainError(f"unknown shelf {s_!r}")
    named_conf = [s_ for s_ in shelves if shelf_meta(lib, s_)["confidential"]]
    if named_conf and len(shelves) > 1:
        raise BrainError(f"{named_conf[0]!r} is confidential: recall it on its own (one shelf), "
                         f"never combined with other shelves")
    if max_rank is not None and max_rank not in ag.EVIDENCE_RANKS:
        raise BrainError(f"max_rank must be one of {ag.EVIDENCE_RANKS}")
    if ranking not in RANKINGS:
        raise BrainError(f"ranking must be one of {RANKINGS}")
    if min_conf not in ag.CONF_RANK:
        raise BrainError(f"min_confidence must be one of {tuple(ag.CONF_RANK)}")
    names = shelves if shelves else [s_ for s_ in mf["shelves"] if not shelf_meta(lib, s_)["confidential"]]
    pool = [(s_, shelf_meta(lib, s_), shelf_kg(lib, s_)) for s_ in names]
    qset = set(tokens(question))
    weights = expand_query(lib, qset)
    expanded = sorted(t for t in weights if t not in qset)
    floor = ag.CONF_RANK[min_conf]
    lim = ag.EVIDENCE_RANKS.index(max_rank) if max_rank else None
    excluded_unranked = 0
    raw, examined = [], 0
    for sname, meta, kg in pool:
        for n in kg.get("nodes", []):
            if ag.CONF_RANK.get(ag._hs(n.get("confidence")), 0) < floor:
                continue
            rk = n.get("evidence_rank")
            if lim is not None:
                if rk not in ag.EVIDENCE_RANKS:
                    excluded_unranked += 1
                    continue
                if ag.EVIDENCE_RANKS.index(rk) > lim:
                    continue
            examined += 1
            m = _matches(weights, n)
            if m:
                raw.append((sname, n, meta, m))
    idf = {}
    if ranking == "idf":      # rare tokens count for more: ln(1 + N/df), df = nodes (in this search) containing the token
        df: dict[str, int] = {}
        for _, _, _, m in raw:
            for t in {t for _, t in m}:
                df[t] = df.get(t, 0) + 1
        idf = {t: math.log(1 + examined / c) for t, c in df.items()}
    cands = []
    for sname, n, meta, m in raw:
        score = sum(mult * weights[t] * idf.get(t, 1.0) for mult, t in m)
        if score <= 0:
            continue
        cands.append((-round(score, 3), TRUST_ORDER[trust_label(n)], sname, str(n["id"]), n, meta))
    cands.sort(key=lambda c: c[:4])
    scored = []
    for negscore, _, sname, _, n, meta in cands[:limit]:                   # full result rows for the top `limit` only
        scored.append({"score": -negscore, "shelf": sname, "shelf_kind": meta["kind"],
                       "id": n["id"], "type": n.get("type"), "entity": n.get("entity"),
                       "label": n.get("label"), "confidence": n.get("confidence"),
                       "evidence_rank": n.get("evidence_rank") or "UNRANKED",
                       "status": n.get("status", "CONFIRMED"), "trust": trust_label(n),
                       "source_location": n.get("source_location"),
                       "stale": staleness(n, meta, today), "neighbors": []})
    top = scored
    # neighbours are computed ONLY for the results we return: one pass over each needed shelf's edges
    for sname, meta, kg in pool:
        want = {str(r["id"]): r for r in top if r["shelf"] == sname}
        if not want:
            continue
        by_id = {str(n["id"]): n for n in kg.get("nodes", [])}
        for e in kg.get("edges", []):
            f, t = str(e.get("from")), str(e.get("to"))
            if f in want and len(want[f]["neighbors"]) < 5:
                o = by_id.get(t, {})
                want[f]["neighbors"].append({"direction": "out", "relationship": e.get("relationship"), "id": e.get("to"),
                                             "label": o.get("label"), "edge_confidence": e.get("confidence"),
                                             "edge_indicator_only": bool(e.get("indicator_only"))})
            if t in want and len(want[t]["neighbors"]) < 5:
                o = by_id.get(f, {})
                want[t]["neighbors"].append({"direction": "in", "relationship": e.get("relationship"), "id": e.get("from"),
                                             "label": o.get("label"), "edge_confidence": e.get("confidence"),
                                             "edge_indicator_only": bool(e.get("indicator_only"))})
    out = {"question": question, "shelves_searched": [p[0] for p in pool], "expanded_terms": expanded, "ranking": ranking,
           "results": top,
           "note": "Navigation aid. Trust labels, not retrieval rank, say what may be relied on. "
                   "INDICATOR items must be tested before use; STALE/UNDATED/BAD_DATE statutory items must be re-validated."}
    if lim is not None:
        out["excluded_unranked"] = excluded_unranked
    return out


# ---- work memory: remember / reflect ----------------------------------------------------------------
_FM = re.compile(r"^---\n(.*?)\n---\n", re.S)


def _parse_memory_file(p: Path) -> dict | None:
    """Rebuild one index entry from a graphify memory file's frontmatter. None if it cannot be read."""
    try:
        m = _FM.match(p.read_text(encoding="utf-8"))
        if not m:
            return None
        fm = {}
        for line in m.group(1).splitlines():
            if ": " in line:
                k, v = line.split(": ", 1)
                try:
                    fm[k.strip()] = json.loads(v)
                except ValueError:
                    fm[k.strip()] = v.strip()
        if fm.get("outcome") not in OUTCOMES or not isinstance(fm.get("question"), str):
            return None
        return {"file": p.name, "date": fm.get("date") or "", "outcome": fm["outcome"], "question": fm["question"],
                "correction": fm.get("correction"), "nodes": [x for x in fm.get("source_nodes", []) if isinstance(x, str)],
                "unknown_nodes": [], "trust": "indicator", "recovered": True}
    except (OSError, UnicodeDecodeError):
        return None


def _load_memory_index(lib: Path, shelf: str, sd: Path, meta: dict) -> list[dict]:
    """The shelf's memory index. If it is corrupt it is quarantined (kept, renamed) and rebuilt from the saved files,
    and the recovery is audited. Caller must hold the shelf lock."""
    idx_path = sd / "memory_index.json"
    if not idx_path.exists():
        return []
    try:
        idx = strictjson.load(idx_path)
        if isinstance(idx, list) and all(isinstance(x, dict) for x in idx):
            mem = sd / "graphify-out" / "memory"
            listed = {e.get("file") for e in idx}
            orphans = [p for p in sorted(mem.glob("query_*.md")) if p.name not in listed] if mem.exists() else []
            added = [e for e in (_parse_memory_file(p) for p in orphans) if e]
            if added:                                      # a crash saved the answer but not its index entry: adopt it
                idx = idx + added
                ag.atomic_write_json(idx_path, idx, shelf_mode(meta))
                audit.append(lib, "memory-index-reconciled", shelf, {"adopted_entries": len(added)})
            return idx
    except (GiaError, OSError, ValueError):
        pass
    stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
    quarantined = sd / f"memory_index.json.corrupt-{stamp}"
    os.replace(idx_path, quarantined)
    rebuilt = [e for e in (_parse_memory_file(p) for p in sorted((sd / "graphify-out" / "memory").glob("query_*.md"))) if e]
    ag.atomic_write_json(idx_path, rebuilt, shelf_mode(meta))
    audit.append(lib, "memory-index-recovered", shelf, {"quarantined": quarantined.name, "rebuilt_entries": len(rebuilt)})
    return rebuilt


def remember(lib: Path, shelf: str, question: str, answer: str, outcome: str, correction=None,
             nodes=None, qtype="query") -> dict:
    from graphify.ingest import save_query_result
    lib = Path(lib)
    if outcome not in OUTCOMES:
        raise BrainError(f"outcome must be one of {OUTCOMES}")
    if not isinstance(question, str) or not isinstance(answer, str) or not question.strip() or not answer.strip():
        raise BrainError("question and answer must be non-empty")
    if outcome == "corrected" and not (correction or "").strip():
        raise BrainError("outcome 'corrected' requires --correction (what the right answer was)")
    if len(question) > MAX_QUESTION or len(answer) > MAX_ANSWER or len(correction or "") > MAX_CORRECTION or len(nodes or []) > MAX_NODES:
        raise BrainError(f"input too large (question {MAX_QUESTION}, answer {MAX_ANSWER}, correction {MAX_CORRECTION} characters; "
                         f"{MAX_NODES} nodes at most)")
    for label, v in (("question", question), ("answer", answer), ("correction", correction or ""), ("nodes", " ".join(nodes or []))):
        if "\x00" in v:
            raise BrainError(f"{label} contains NUL bytes")
    sd = shelf_dir(lib, shelf)
    meta = shelf_meta(lib, shelf)
    with shelf_lock(lib, shelf):
        kg = shelf_kg(lib, shelf)
        idx = _load_memory_index(lib, shelf, sd, meta)
        labels = {n["id"]: ag.gfy_label(n["id"], ag._s(n.get("label"), str(n["id"]))) for n in kg.get("nodes", [])}
        resolved, unknown = [], []
        for ref in nodes or []:
            if ref in labels:
                resolved.append(labels[ref])
            else:
                unknown.append(ref)
                resolved.append(ref)
        mem_dir = sd / "graphify-out" / "memory"
        # graphify names files <type>_<UTC second>_<slug>.md: two saves of one question in one second would overwrite.
        # We hold the lock, so wait for the next second instead of losing an answer.
        for _ in range(60):
            stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
            if not (mem_dir.exists() and any(mem_dir.glob(f"query_{stamp}_*"))):
                break
            time.sleep(0.05)
        before = set(os.listdir(mem_dir)) if mem_dir.exists() else set()
        saved = save_query_result(question, answer, mem_dir, query_type=qtype, source_nodes=resolved or None,
                                  outcome=outcome, correction=correction)
        if saved.name in before:
            raise BrainError(f"memory file name collision on {saved.name}: another writer outside this tool wrote in the "
                             f"same second. One saved answer was overwritten; re-save it")
        idx.append({"file": saved.name, "date": now_iso(), "outcome": outcome, "question": question,
                    "correction": correction, "nodes": nodes or [], "unknown_nodes": unknown, "trust": "indicator"})
        ag.atomic_write_json(sd / "memory_index.json", idx, shelf_mode(meta))
        if meta["confidential"]:
            lock_down(sd)
    # the file name is a slug of the QUESTION: for a confidential shelf it must not enter the shared, library-level log
    audit.append(lib, "remember", shelf, {"file": "withheld (confidential)" if meta["confidential"] else saved.name, "outcome": outcome},
                 {"memory_index.json": fsutil.sha256_file(sd / "memory_index.json")})
    return {"saved": str(saved), "unknown_nodes": unknown, "trust": "indicator"}


def _lesson_lines(cands) -> list[str]:
    lines = []
    for name, rec in cands:
        lines += [f"## [{textsafe.display(rec['outcome'], 20)}] {textsafe.display(rec['question'], 400)}",
                  f"- shelf: `{name}` · {textsafe.display(rec.get('date', ''), 40)}"]
        if rec.get("correction"):
            lines.append(f"- Correct answer given: {textsafe.display(rec['correction'], 600)}")
        if rec.get("nodes"):
            lines.append(f"- Nodes involved: {textsafe.display(', '.join(str(x) for x in rec['nodes']), 400)}")
        lines.append("")
    return lines


HEADER = ["# Proposed lessons (NOT standing rules)", "",
          "Generated deterministically from saved work-memory. Each item is a **candidate** for the owner to",
          "accept, edit or discard (AKOS Module 7). Engagement-level items go to that engagement's",
          "LESSONS_LEARNED.md; a portfolio-wide rule needs explicit approval via iron-rules-governance.", ""]


def reflect(lib: Path, shelf_names=None) -> dict:
    lib = Path(lib)
    mf = load_manifest(lib)
    out = {"shelves": {}, "proposed_lessons": None}
    open_cands, conf_cands = [], {}
    for name in shelf_names or mf["shelves"]:
        sd = shelf_dir(lib, name)
        meta = shelf_meta(lib, name)
        with shelf_lock(lib, name):
            idx_path = sd / "memory_index.json"
            mem = sd / "graphify-out" / "memory"
            if not idx_path.exists() or not mem.is_dir():
                out["shelves"][name] = {"status": "NO_MEMORY"}
                continue
            idx = _load_memory_index(lib, name, sd, meta)
            target = sd / "graphify-out" / "reflections" / "LESSONS.md"
            cmd = ["graphify", "reflect", "--memory-dir", str(mem), "--out", str(target)]
            g = sd / "graphify-out" / "graph.json"
            if g.exists():
                cmd += ["--graph", str(g)]
            try:
                r = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
                ok, err = r.returncode == 0, r.stderr.strip()[:300] if r.returncode else ""
            except FileNotFoundError:
                ok, err = False, "the `graphify` command was not found on PATH (pip install -e <graphify checkout>)"
            except subprocess.TimeoutExpired:
                ok, err = False, "graphify reflect timed out after 300s"
            out["shelves"][name] = {"status": "OK" if ok else "FAILED", "lessons": str(target) if ok else None, "stderr": err}
            if meta["confidential"]:
                lock_down(sd)
            for rec in idx:
                if rec.get("outcome") in ("corrected", "dead_end"):
                    (conf_cands.setdefault(name, []) if meta["confidential"] else open_cands).append((name, rec))
    # Non-confidential candidates go to the SHARED file. Confidential ones NEVER do: each stays inside its own shelf.
    shared = list(HEADER)
    if open_cands:
        shared += _lesson_lines(open_cands)
    if conf_cands:
        shared += [f"> {sum(len(v) for v in conf_cands.values())} candidate(s) from confidential shelf/shelves are withheld "
                   f"from this shared file. They are in each shelf's own PROPOSED_LESSONS.md (owner-only).", ""]
    if open_cands or conf_cands:
        p = paths(lib)["lessons"] / "PROPOSED_LESSONS.md"
        fsutil.atomic_write_text(p, "\n".join(shared) + "\n")
        out["proposed_lessons"] = str(p)
    for name, cands in conf_cands.items():
        sd = shelf_dir(lib, name)
        fsutil.atomic_write_text(sd / "PROPOSED_LESSONS.md", "\n".join(HEADER + ["**CONFIDENTIAL: do not circulate.**", ""] + _lesson_lines(cands)) + "\n", 0o600)
        out["shelves"][name]["confidential_lessons"] = str(sd / "PROPOSED_LESSONS.md")
    audit.append(lib, "reflect", detail={"shelves": {k: v.get("status") for k, v in out["shelves"].items()}})
    return out


def meta_conf(lib, name):
    return shelf_meta(lib, name)["confidential"]


# ---- seal / changes / verify ---------------------------------------------------------------------------
def seal(lib: Path, shelf: str, reason: str, who: str | None = None) -> dict:
    """A human attests that the shelf's CURRENT content is reviewed. Records its hash, keeps a snapshot, and
    becomes the baseline that `changes` and `verify` compare against."""
    lib = Path(lib)
    if not isinstance(reason, str) or not reason.strip():
        raise BrainError("a seal needs a reason (what was reviewed, and why it can be relied on)")
    if len(reason) > 500 or "\x00" in reason:
        raise BrainError("the reason must be at most 500 characters")
    sd = shelf_dir(lib, shelf)
    meta = shelf_meta(lib, shelf)
    with shelf_lock(lib, shelf):
        raw = (sd / "KNOWLEDGE_GRAPH.json").read_bytes()
        kg = schema.require_kg(strictjson.loads(raw, f"shelf {shelf!r}"), f"shelf {shelf!r}", strict_edges=True)
        sha = fsutil.sha256_bytes(raw)
        issues = ag.summarize(ag.validate_kg(kg, "draft"))
        snap = sd / ".seals" / f"{sha[:16]}.json"
        fsutil.atomic_write_bytes(snap, raw, shelf_mode(meta))
        reason_sha = fsutil.sha256_bytes(reason.strip().encode("utf-8"))
        if meta["confidential"]:                               # the reason may name people or facts: keep it inside the shelf
            fsutil.atomic_write_text(sd / ".seals" / f"{sha[:16]}.reason.txt", reason.strip() + "\n", 0o600)
        if meta["confidential"]:
            lock_down(sd)
    shown_reason = "withheld (confidential): see the shelf's .seals folder" if meta["confidential"] else reason.strip()
    e = audit.append(lib, "seal", shelf, {"reason": shown_reason, "reason_sha256": reason_sha, "sha256": sha, "snapshot": f".seals/{snap.name}",
                                          "nodes": len(kg.get("nodes", [])), "edges": len(kg.get("edges", [])), **issues},
                     {"KNOWLEDGE_GRAPH.json": sha}, who)
    return {"sealed": True, "shelf": shelf, "sha256": sha, "seq": e["seq"], "audit_head": e["hash"],
            "note": "Record audit_head somewhere you control (email, ticket) and pass it to `verify --anchor` later."}


_COMPARED = ("label", "type", "entity", "confidence", "status", "evidence_rank", "source_location", "review_by", "origin")


def diff_kg(old: dict, new: dict) -> dict:
    on = {str(n["id"]): n for n in old.get("nodes", []) if isinstance(n, dict) and "id" in n}
    nn = {str(n["id"]): n for n in new.get("nodes", []) if isinstance(n, dict) and "id" in n}
    key = lambda e: (str(e.get("from")), str(e.get("to")), str(e.get("relationship")))  # noqa: E731
    oe = {key(e): e for e in old.get("edges", []) if isinstance(e, dict)}
    ne = {key(e): e for e in new.get("edges", []) if isinstance(e, dict)}
    flags, changed = [], []
    for i in sorted(set(on) & set(nn)):
        fields = {f: [on[i].get(f), nn[i].get(f)] for f in _COMPARED if on[i].get(f) != nn[i].get(f)}
        if not fields:
            continue
        changed.append({"id": i, "fields": fields})
        if "confidence" in fields:
            a, b = ag.CONF_RANK.get(ag._hs(fields["confidence"][0]), 0), ag.CONF_RANK.get(ag._hs(fields["confidence"][1]), 0)
            if b > a:
                flags.append({"code": "CONFIDENCE_RAISED", "id": i, "from": fields["confidence"][0], "to": fields["confidence"][1],
                              "evidence_rank_now": nn[i].get("evidence_rank")})
        if "status" in fields:
            flags.append({"code": "STATUS_CHANGED", "id": i, "from": fields["status"][0], "to": fields["status"][1]})
        if "evidence_rank" in fields:
            flags.append({"code": "EVIDENCE_RANK_CHANGED", "id": i, "from": fields["evidence_rank"][0], "to": fields["evidence_rank"][1]})
    for i in sorted(set(on) - set(nn)):
        flags.append({"code": "NODE_REMOVED", "id": i, "label": on[i].get("label")})
    for k in sorted(set(oe) - set(ne)):
        flags.append({"code": "EDGE_REMOVED", "id": "->".join(k[:2]), "relationship": k[2]})
    return {"nodes_added": sorted(set(nn) - set(on)), "nodes_removed": sorted(set(on) - set(nn)), "nodes_changed": changed,
            "edges_added": ["->".join(k[:2]) + f" ({k[2]})" for k in sorted(set(ne) - set(oe))],
            "edges_removed": ["->".join(k[:2]) + f" ({k[2]})" for k in sorted(set(oe) - set(ne))], "flags": flags}


def changes(lib: Path, shelf: str) -> dict:
    """What changed in a shelf since its last seal, with risk flags (confidence raised, status changed, removals)."""
    lib = Path(lib)
    sd = shelf_dir(lib, shelf)
    entries, _ = audit.read(lib)
    last = audit.seals(entries).get(shelf)
    if not last:
        return {"shelf": shelf, "sealed": False, "note": "this shelf has never been sealed; run `seal` to set a baseline", "flags": []}
    snap = sd / last["detail"]["snapshot"]
    flags = []
    try:
        raw = snap.read_bytes()
        if fsutil.sha256_bytes(raw) != last["detail"]["sha256"]:
            flags.append({"code": "SEAL_SNAPSHOT_TAMPERED", "id": snap.name})
        old = strictjson.loads(raw, str(snap))
    except (OSError, ValueError):
        return {"shelf": shelf, "sealed": True, "sealed_at": last["ts"], "sealed_by": last["actor"],
                "flags": [{"code": "SEAL_SNAPSHOT_MISSING", "id": last["detail"].get("snapshot")}]}
    new = shelf_kg(lib, shelf)
    d = diff_kg(old, new)
    d["flags"] = flags + d["flags"]
    cur = fsutil.sha256_file(sd / "KNOWLEDGE_GRAPH.json")
    reason = last["detail"].get("reason")
    rf = sd / ".seals" / (Path(last["detail"]["snapshot"]).stem + ".reason.txt")
    if rf.exists():                                            # confidential shelf: the real reason lives beside the snapshot
        try:
            reason = rf.read_text(encoding="utf-8").strip()
        except OSError:
            pass
    return {"shelf": shelf, "sealed": True, "sealed_at": last["ts"], "sealed_by": last["actor"], "reason": reason,
            "unchanged": cur == last["detail"]["sha256"], **d}


def verify(lib: Path, anchor: str | None = None) -> list[dict]:
    lib = Path(lib)
    out = audit.verify(lib, anchor)
    entries, _ = audit.read(lib)
    mf = load_manifest(lib)
    for name, e in audit.seals(entries).items():
        if name not in mf["shelves"]:
            continue
        sd = lib / "shelves" / name
        kgp = sd / "KNOWLEDGE_GRAPH.json"
        snap = sd / e["detail"].get("snapshot", "")
        if not kgp.exists():
            out.append(audit.issue("ERROR", "SEALED_FILE_MISSING", "a sealed Knowledge Graph file no longer exists", name))
            continue
        if not snap.exists() or fsutil.sha256_file(snap) != e["detail"].get("sha256"):
            out.append(audit.issue("ERROR", "SEAL_SNAPSHOT_TAMPERED", "the sealed snapshot is missing or does not match its recorded hash", name))
        if fsutil.sha256_file(kgp) != e["detail"].get("sha256"):
            out.append(audit.issue("WARN", "UNSEALED_CHANGES",
                                   f"changed since the seal at seq {e['seq']} ({e['ts']}, by {e['actor']}); run `changes` to see what", name))
    return out


# ---- stale / status / guard ----------------------------------------------------------------------
def stale_report(lib: Path, today=None) -> dict:
    lib = Path(lib)
    mf = load_manifest(lib)
    today = today or _today_local()
    if ag.parse_iso_date(today) is None:
        raise BrainError(f"--today {today!r} is not YYYY-MM-DD")
    items = []
    for name in mf["shelves"]:
        try:
            meta, kg = shelf_meta(lib, name), shelf_kg(lib, name)
        except (GiaError,) + READ_ERRORS:
            items.append({"shelf": name, "id": "(shelf)", "label": "shelf files unreadable", "state": "STALE",
                          "review_by": None})
            continue
        if meta["kind"] != "statutory":
            continue
        for n in kg.get("nodes", []):
            st = staleness(n, meta, today)
            if st:
                items.append({"shelf": name, "id": n["id"], "label": n.get("label"), "state": st,
                              "review_by": n.get("review_by")})
        rd = meta.get("review_days")
        lu = ag.parse_iso_date(kg.get("last_updated"))
        if rd and kg.get("last_updated") and lu is None:
            items.append({"shelf": name, "id": "(shelf)", "label": f"last_updated {kg.get('last_updated')!r} unreadable",
                          "state": "BAD_DATE", "review_by": None})
        elif rd and lu is not None:
            age = (ag.parse_iso_date(today) - lu).days
            if age > rd:
                items.append({"shelf": name, "id": "(shelf)", "label": f"shelf not refreshed for {age} days",
                              "state": "STALE", "review_by": None})
    return {"today": today, "items": items,
            "note": "Statutory content must be re-validated against the portal before reliance (R1 evidence)."}


def _memory_index_problems(lib: Path, name: str) -> list[str]:
    sd = Path(lib) / "shelves" / name
    idx_path, mem = sd / "memory_index.json", sd / "graphify-out" / "memory"
    if not idx_path.exists() and not mem.exists():
        return []
    try:
        idx = strictjson.load(idx_path) if idx_path.exists() else []
    except (GiaError, OSError, ValueError):
        return ["memory_index.json is unreadable"]
    if not isinstance(idx, list):
        return ["memory_index.json is not a list"]
    listed = {e.get("file") for e in idx if isinstance(e, dict)}
    on_disk = {p.name for p in mem.glob("query_*.md")} if mem.exists() else set()
    out = []
    if listed - on_disk:
        out.append(f"{len(listed - on_disk)} indexed answer file(s) are missing from disk")
    if on_disk - listed:
        out.append(f"{len(on_disk - listed)} saved answer file(s) are not in the index (run `remember` or `reflect` to repair)")
    return out


def guard(lib: Path, env=None) -> list[dict]:
    env = os.environ if env is None else env
    lib = Path(lib)
    mf = load_manifest(lib)
    out = []
    add = lambda sev, code, msg, ref="": out.append({"severity": sev, "code": code, "message": msg, "ref": ref})  # noqa: E731
    links = fsutil.find_symlinks(lib)
    if links:
        add("ERROR", "SYMLINK_IN_LIBRARY", f"{len(links)} symbolic link(s) inside the library (e.g. {textsafe.display(links[0], 120)}); "
            f"links are refused because they can point outside it", links[0] and Path(links[0]).name)
    conf = []
    for s_ in mf["shelves"]:
        try:
            if shelf_meta(lib, s_)["confidential"]:
                conf.append(s_)
        except (GiaError,) + READ_ERRORS:
            conf.append(s_)  # unreadable => treat as confidential (fail closed)
    for name in mf["shelves"]:
        try:
            meta, kg = shelf_meta(lib, name), shelf_kg(lib, name)
        except (GiaError,) + READ_ERRORS as exc:
            add("ERROR", "SHELF_UNREADABLE", f"cannot read shelf files: {textsafe.display(exc, 200)}", name)
            continue
        if meta["kind"] == "investigation" and not meta["confidential"]:
            add("ERROR", "INVESTIGATION_NOT_ISOLATED", "investigation shelf is not confidential", name)
        for i in ag.validate_kg(kg, "draft"):
            if i["code"] in ("MEMORY_AS_EVIDENCE", "CONFIDENTIAL_LEAK", "INDICATOR_AS_EVIDENCE",
                             "ALLEGED_AS_CONFIRMED", "CONF_ELEVATED"):
                add("ERROR", i["code"], i["message"], f"{name}:{i['ref']}")
        for prob in _memory_index_problems(lib, name):
            add("WARN", "MEMORY_INDEX_MISMATCH", prob, name)
    for name in conf:
        bad = world_readable_files(paths(lib)["shelves"] / name)
        if bad:
            add("WARN", "CONFIDENTIAL_WORLD_READABLE",
                f"{len(bad)} file(s) in a confidential shelf are readable by group/other (e.g. {Path(bad[0]).name}); "
                f"run index or remember again, or chmod 600", name)
    gk = paths(lib)["index"] / "global" / "global_kg.json"
    if gk.exists():
        try:
            leaked = sorted({n.get("shelf") for n in ag.load_json(gk).get("nodes", []) if isinstance(n, dict)} & set(conf))
        except (GiaError,) + READ_ERRORS:
            leaked = []
            add("ERROR", "GLOBAL_GRAPH_UNREADABLE", "the global graph file cannot be read; run index")
        if leaked:
            add("ERROR", "CONFIDENTIAL_IN_GLOBAL", f"global graph contains confidential shelf content: {leaked}")
    pend = list(paths(lib)["index"].glob("*.old-*")) if paths(lib)["index"].exists() else []
    if pend:
        add("WARN", "PENDING_SWAP", "an index swap was interrupted; run `index` to restore it")
    for f in audit.verify(lib):
        if f["severity"] == "ERROR":
            add("ERROR", f["code"], f["message"], f.get("ref", ""))
    allowed = set(mf["policy"].get("allowed_backends", DEFAULT_ALLOWED_BACKENDS))
    if conf:
        try:
            from graphify import llm
            picked = llm.detect_backend()  # exactly what `graphify extract` would choose from os.environ
        except Exception:  # graphify absent/unusable: fall back to key inspection only
            picked = None
        cloud_keys = [k for k in ("GEMINI_API_KEY", "GOOGLE_API_KEY", "MOONSHOT_API_KEY", "OPENAI_API_KEY",
                                  "DEEPSEEK_API_KEY", "AZURE_OPENAI_API_KEY") if env.get(k)]
        if picked and picked not in allowed:
            add("ERROR", "EXTRACT_BACKEND_NOT_ALLOWED",
                f"`graphify extract` would auto-select backend {picked!r}, which is not in the allowed list "
                f"{sorted(allowed)}. Document content would leave the approved boundary. Pass --backend explicitly "
                f"or unset the key.")
        elif cloud_keys:
            add("WARN", "CLOUD_BACKEND_KEYS_SET",
                f"cloud backend keys present ({', '.join(cloud_keys)}); graphify's auto-detect order is "
                f"gemini > kimi > claude > openai > deepseek. Always pass --backend explicitly for confidential shelves.")
        if env.get("GRAPHIFY_QUERY_LOG") or str(env.get("GRAPHIFY_QUERY_LOG_ENABLE", "")).lower() in ("1", "true", "yes"):
            add("WARN", "QUERY_LOG_ENABLED",
                "graphify query logging is on: questions and corpus paths are written to a plaintext log outside "
                "the library. Disable it while working with confidential shelves.")
    return out


def status(lib: Path, today=None) -> dict:
    lib = Path(lib)
    mf = load_manifest(lib)
    try:
        rep = ag.load_json(paths(lib)["index"] / "index_report.json") if (paths(lib)["index"] / "index_report.json").exists() else {}
    except (GiaError,) + READ_ERRORS:
        rep = {}
    rows = []
    stale = stale_report(lib, today)
    for name in mf["shelves"]:
        try:
            meta, kg = shelf_meta(lib, name), shelf_kg(lib, name)
        except (GiaError,) + READ_ERRORS:
            rows.append({"shelf": name, "kind": "?", "entity": "?", "confidential": True, "nodes": 0, "edges": 0,
                         "proposed": 0, "memory_entries": 0, "stale_items": 0, "status": "UNREADABLE"})
            continue
        idx = lib / "shelves" / name / "memory_index.json"
        try:
            mem_n = len(ag.load_json(idx)) if idx.exists() else 0
        except (GiaError,) + READ_ERRORS:
            mem_n = 0
        rows.append({"shelf": name, "kind": meta["kind"], "entity": meta["entity"],
                     "confidential": meta["confidential"], "nodes": len(kg.get("nodes", [])),
                     "edges": len(kg.get("edges", [])),
                     "proposed": sum(1 for n in kg.get("nodes", []) if n.get("status") == "PROPOSED"),
                     "trust_mix": {k: sum(1 for n in kg.get("nodes", []) if trust_label(n) == k)
                                   for k in ("CONFIRMED", "PROVISIONAL", "INDICATOR")},
                     "memory_entries": mem_n,
                     "stale_items": sum(1 for i in stale["items"] if i["shelf"] == name)})
    h = audit.head(lib)
    return {"library": str(lib), "policy": mf["policy"], "shelves": rows,
            "last_index": rep.get("built_at"), "global": rep.get("global"),
            "audit": {"entries": h["seq"], "head": h["hash"]}}


def mcp_config(lib: Path) -> dict:
    g = paths(Path(lib))["index"] / "global" / "graphify-out" / "graph.json"
    if not g.exists():
        raise BrainError("no global graph yet - run: brain.py index <library>")
    return {"mcpServers": {"mktron-library-brain": {"command": sys.executable,
            "args": ["-m", "graphify.serve", str(g.resolve())]}},
            "note": "Requires the graphify MCP extra: pip install 'graphifyy[mcp]'. Serves NON-confidential shelves only. "
                    "Keep graphify query logging off."}


# ---- CLI -------------------------------------------------------------------------------------------------
def _print_findings(findings):
    for i in findings:
        print(f"[{i['severity']:<5}] {i['code']:<28} {textsafe.display(i.get('ref') or '-', 40):<24} {textsafe.display(i['message'], 400)}")
    errs = sum(i["severity"] == "ERROR" for i in findings)
    print(f"\n{errs} error(s), {len(findings) - errs} warning(s)")
    return errs


def _main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="brain", description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("init"); p.add_argument("lib"); p.add_argument("--allowed-backends", nargs="*")
    p = sub.add_parser("shelf-add"); p.add_argument("lib"); p.add_argument("name")
    p.add_argument("--kind", required=True, choices=KINDS); p.add_argument("--entity", required=True)
    p.add_argument("--confidential", action="store_true"); p.add_argument("--review-days", type=_bounded(1, 3650))
    p.add_argument("--jurisdiction")
    p = sub.add_parser("index"); p.add_argument("lib"); p.add_argument("--html", action="store_true")
    p = sub.add_parser("recall"); p.add_argument("lib"); p.add_argument("question")
    p.add_argument("--shelf", action="append"); p.add_argument("--min-confidence", default="Low",
                   choices=["Low", "Medium", "High", "100%"]); p.add_argument("--limit", type=_bounded(1, 1000), default=8)
    p.add_argument("--today"); p.add_argument("--max-rank", choices=list(ag.EVIDENCE_RANKS))
    p.add_argument("--ranking", choices=list(RANKINGS), default="score",
                   help="score (default, v1.x compatible) or idf (rare words count more: better in large libraries)")
    p = sub.add_parser("remember"); p.add_argument("lib"); p.add_argument("--shelf", required=True)
    p.add_argument("--question", required=True); p.add_argument("--answer", required=True)
    p.add_argument("--outcome", required=True, choices=OUTCOMES); p.add_argument("--correction")
    p.add_argument("--nodes", nargs="*"); p.add_argument("--type", default="query")
    p = sub.add_parser("reflect"); p.add_argument("lib"); p.add_argument("--shelf", action="append")
    p = sub.add_parser("stale"); p.add_argument("lib"); p.add_argument("--today"); p.add_argument("--strict", action="store_true")
    p = sub.add_parser("status"); p.add_argument("lib"); p.add_argument("--today")
    p = sub.add_parser("guard"); p.add_argument("lib")
    p = sub.add_parser("mcp-config"); p.add_argument("lib")
    p = sub.add_parser("dashboard"); p.add_argument("lib"); p.add_argument("--out", required=True); p.add_argument("--today")
    p = sub.add_parser("seal", help="attest a shelf's current content; becomes the baseline for `changes`")
    p.add_argument("lib"); p.add_argument("--shelf", required=True); p.add_argument("--reason", required=True)
    p = sub.add_parser("changes", help="what changed in a shelf since its last seal, with risk flags")
    p.add_argument("lib"); p.add_argument("--shelf", required=True)
    p = sub.add_parser("verify", help="check the audit chain, an optional external anchor, and every seal")
    p.add_argument("lib"); p.add_argument("--anchor", help="a head hash you recorded earlier"); p.add_argument("--strict", action="store_true")
    p = sub.add_parser("doctor", help="check the environment (and optionally a library)")
    p.add_argument("lib", nargs="?")
    a = ap.parse_args(argv)
    if getattr(a, "lib", None) is not None and not str(a.lib).strip():
        raise BrainError("the library path must not be empty")
    lib = Path(a.lib) if getattr(a, "lib", None) else None
    if a.cmd == "init":
        print(json.dumps(init_library(lib, a.allowed_backends), indent=2))
    elif a.cmd == "shelf-add":
        print(json.dumps(add_shelf(lib, a.name, a.kind, a.entity, a.confidential, a.review_days, a.jurisdiction), indent=2))
    elif a.cmd == "index":
        rep = index_library(lib, a.html)
        print(json.dumps(rep, indent=2))
        return 1 if rep["failed_shelves"] else 0
    elif a.cmd == "recall":
        print(json.dumps(recall(lib, a.question, a.shelf, a.min_confidence, a.limit, a.today, a.max_rank, a.ranking), indent=2))
    elif a.cmd == "remember":
        print(json.dumps(remember(lib, a.shelf, a.question, a.answer, a.outcome, a.correction, a.nodes, a.type), indent=2))
    elif a.cmd == "reflect":
        print(json.dumps(reflect(lib, a.shelf), indent=2))
    elif a.cmd == "stale":
        rep = stale_report(lib, a.today)
        print(json.dumps(rep, indent=2))
        return 1 if (a.strict and rep["items"]) else 0
    elif a.cmd == "status":
        print(json.dumps(status(lib, a.today), indent=2))
    elif a.cmd == "guard":
        return 1 if _print_findings(guard(lib)) else 0
    elif a.cmd == "mcp-config":
        print(json.dumps(mcp_config(lib), indent=2))
    elif a.cmd == "dashboard":
        # When run as a script this module is "__main__"; without this alias report.py's `import brain` would load a
        # SECOND copy with its own BrainError class and user errors would escape the handler as crashes.
        sys.modules.setdefault("brain", sys.modules[__name__])
        import report  # lazy: needs openpyxl only for this command
        print(json.dumps(report.build_dashboard(lib, Path(a.out), a.today), indent=2))
    elif a.cmd == "seal":
        print(json.dumps(seal(lib, a.shelf, a.reason), indent=2))
    elif a.cmd == "changes":
        rep = changes(lib, a.shelf)
        print(json.dumps(rep, indent=2, ensure_ascii=True))
        return 1 if rep.get("flags") else 0
    elif a.cmd == "verify":
        findings = verify(lib, a.anchor)
        errs = _print_findings(findings)
        return 1 if errs or (a.strict and findings) else 0
    elif a.cmd == "doctor":
        import doctor
        checks = doctor.run_checks(lib)
        for c in checks:
            print(f"[{c['status']:<4}] {c['name']:<34} {textsafe.display(c['detail'], 200)}" + (f"\n         -> {c['remedy']}" if c["remedy"] else ""))
        fails = sum(c["status"] == "FAIL" for c in checks)
        print(f"\n{fails} failure(s), {sum(c['status'] == 'WARN' for c in checks)} warning(s)")
        return 1 if fails else 0
    return 0


def main(argv=None) -> int:
    """Public entry point: every outcome mapped to the exit-code contract (0 ok, 1 findings, 2 bad input, 3 bug)."""
    return run_cli(_main, argv)


if __name__ == "__main__":
    sys.exit(main())
