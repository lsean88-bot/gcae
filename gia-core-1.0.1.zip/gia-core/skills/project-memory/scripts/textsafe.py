"""textsafe.py - make untrusted text safe for each place it is shown (layer L0).

Labels, ids and evidence come from documents nobody here controls. Each sink needs its own treatment:
  display()   terminal / logs : control characters, escapes and bidi overrides become visible \\xNN / \\uNNNN text
  xlsx_text() Excel           : XML-illegal characters removed, over-long text truncated, formula prefixes neutralised
  (HTML is handled with html.escape at the point of use)
"""
from __future__ import annotations

import re

# C0 (except none), DEL, C1, line/paragraph separators, bidi embeddings/overrides/isolates, zero-width and BOM
_UNSAFE = re.compile("[\x00-\x1f\x7f-\x9f\u2028\u2029\u202a-\u202e\u2066-\u2069\u200b-\u200f\ufeff\ud800-\udfff]")
_XML_ILLEGAL = re.compile("[\x00-\x08\x0b\x0c\x0e-\x1f\ud800-\udfff\ufffe\uffff]")
_FORMULA = ("=", "+", "-", "@", "\t", "\r")
XLSX_MAX = 32000


def _esc(m) -> str:
    c = ord(m.group())
    return f"\\x{c:02x}" if c <= 0xFF else f"\\u{c:04x}"


def display(value, max_len: int = 300) -> str:
    """Single-line, terminal-safe rendering. Never raises."""
    try:
        s = str(value)
    except Exception:
        s = "<unprintable>"
    s = _UNSAFE.sub(_esc, s)
    return s if len(s) <= max_len else s[: max_len - 1] + "…"


def display_tail(value, max_len: int = 60) -> str:
    """Like display(), but when it must cut it keeps the END (a path's last part, the skill name, is what matters)."""
    s = display(value, 10_000)
    return s if len(s) <= max_len else "…" + s[-(max_len - 1):]


def xlsx_text(value):
    """Excel-safe value. Numbers, None and bools pass through; strings are cleaned."""
    if not isinstance(value, str):
        if isinstance(value, (int, float, bool)) or value is None:
            return value
        value = str(value)
    s = _XML_ILLEGAL.sub("\ufffd", value)
    if len(s) > XLSX_MAX:
        s = s[:XLSX_MAX] + "…[truncated]"
    if s.startswith(_FORMULA):
        s = "'" + s
    return s
