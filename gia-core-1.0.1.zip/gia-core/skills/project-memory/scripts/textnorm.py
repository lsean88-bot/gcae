"""textnorm.py - script-aware text normalisation shared by the bridge and the library brain.

Why this exists: an ASCII-only tokenizer turns "Nómina" into "mina" (a different word: "mine") and returns
NOTHING for Tamil, Chinese or other non-Latin text, so those items can never be recalled or de-duplicated.
Rules:
  * Latin diacritics are folded (nómina == nomina, Ñ == n) by removing only U+0300-U+036F combining marks.
  * Marks used by other scripts (e.g. Tamil vowel signs) are KEPT, so those words stay intact.
  * A word is a maximal run of letters/digits plus their marks; case-folded.
  * CJK runs also emit overlapping character bigrams, because those scripts have no spaces between words.
"""
from __future__ import annotations

import hashlib
import re
import unicodedata

_LATIN_MARKS = re.compile("[\u0300-\u036f]")


def fold(text: str) -> str:
    """NFKD, drop Latin combining marks only, recompose, casefold."""
    t = unicodedata.normalize("NFKD", str(text))
    t = _LATIN_MARKS.sub("", t)
    return unicodedata.normalize("NFC", t).casefold()


def _is_cjk(ch: str) -> bool:
    o = ord(ch)
    return (0x4E00 <= o <= 0x9FFF or 0x3400 <= o <= 0x4DBF or 0x3040 <= o <= 0x30FF or 0xAC00 <= o <= 0xD7AF)


_ASCII_WORD = re.compile(r"[a-z0-9]+")


def words(text: str) -> list[str]:
    """Whole words (no CJK bigrams): letters/digits and their combining marks, case/diacritic folded."""
    t = text if isinstance(text, str) else str(text)
    if t.isascii():                      # fast path: identical result to the general path below, ~15x faster
        return _ASCII_WORD.findall(t.lower())
    out, cur = [], []
    for ch in fold(text):
        if ch.isalnum() or unicodedata.category(ch).startswith("M"):
            cur.append(ch)
        elif cur:
            out.append("".join(cur))
            cur = []
    if cur:
        out.append("".join(cur))
    return out


def tokens(text: str) -> list[str]:
    """Search tokens: words, plus overlapping bigrams for CJK runs."""
    out: list[str] = []
    ws = words(text)
    if str(text).isascii():
        return ws
    for w in ws:
        if any(_is_cjk(c) for c in w):
            run = [c for c in w if _is_cjk(c)]
            out += ["".join(run[i:i + 2]) for i in range(max(1, len(run) - 1))] if len(run) > 1 else run
            rest = "".join(c for c in w if not _is_cjk(c))
            if rest:
                out.append(rest)
        else:
            out.append(w)
    return out


def norm_label(text: str) -> str:
    """Stable key for near-duplicate detection."""
    return " ".join(words(text))


def slug(value: str) -> str:
    """graphify-safe id: lowercase [a-z0-9_]. Non-ASCII characters that cannot be folded get a short hash suffix so
    two different non-ASCII ids never collapse to the same slug (e.g. two Tamil ids that both reduce to '01')."""
    raw = str(value)
    ascii_part = re.sub(r"[^a-z0-9]+", "_", fold(raw).encode("ascii", "ignore").decode()).strip("_") or "node"
    if raw.encode("ascii", "ignore").decode() == raw or fold(raw).encode("ascii", "ignore").decode() == fold(raw):
        # pure ASCII after folding accents: keep readable slug
        return ascii_part
    return f"{ascii_part}_{hashlib.sha1(raw.encode('utf-8')).hexdigest()[:6]}"
