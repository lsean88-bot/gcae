"""strictjson.py - read JSON the way an audit tool must (layer L0).

Accepts: UTF-8 with or without BOM (Windows tools add one).
Rejects, with a clear InputError: duplicate keys (the later one would silently discard the earlier data),
NaN/Infinity (not JSON), invalid UTF-8, NUL bytes, absurd nesting, and files above a size limit.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

from errors import InputError

MAX_BYTES = int(os.environ.get("GIA_MAX_JSON_BYTES", 512 * 1024 * 1024))


def _no_constants(name):
    raise InputError(f"{name} is not valid JSON (NaN/Infinity are not allowed)")


def _no_duplicates(pairs):
    d = {}
    for k, v in pairs:
        if k in d:
            raise InputError(f"duplicate key {k!r}: the earlier value would be silently discarded")
        d[k] = v
    return d


def loads(raw, source: str = "input"):
    if isinstance(raw, str):
        raw = raw.encode("utf-8", "surrogatepass")
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError as exc:
        raise InputError(f"{source}: not valid UTF-8 ({exc.reason} at byte {exc.start})") from None
    if "\x00" in text:
        raise InputError(f"{source}: contains NUL bytes")
    try:
        return json.loads(text, object_pairs_hook=_no_duplicates, parse_constant=_no_constants)
    except InputError as exc:
        raise InputError(f"{source}: {exc}") from None
    except json.JSONDecodeError as exc:
        raise InputError(f"{source}: not valid JSON ({exc.msg} at line {exc.lineno} column {exc.colno})") from None
    except RecursionError:
        raise InputError(f"{source}: nested too deeply") from None


def load(path, max_bytes: int | None = None):
    p = Path(path)
    limit = MAX_BYTES if max_bytes is None else max_bytes
    try:
        size = p.stat().st_size
    except FileNotFoundError:
        raise InputError(f"{p}: file not found") from None
    if size > limit:
        raise InputError(f"{p}: {size // (1024 * 1024)} MB exceeds the {limit // (1024 * 1024)} MB limit "
                         f"(raise GIA_MAX_JSON_BYTES if this is intended)")
    return loads(p.read_bytes(), str(p))
