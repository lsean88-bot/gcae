#!/usr/bin/env bash
# bootstrap_env.sh - make a fresh machine able to run graphify AND its full test suite.
# Idempotent. Usage: bootstrap_env.sh [--repo PATH] [--no-git] [--run-tests]
#
# Closes the four gaps found when the graphify-8 suite first ran (22 failures, 0 source defects):
#   1. optional extras missing          -> tree-sitter-hcl (terraform), openai + tiktoken (ollama tests)
#   2. build tooling missing            -> build, wheel, setuptools>=77 (wheel-payload tests)
#   3. skillgen needs pinned git blobs  -> fetch each baseline SHA from upstream into the repo
#   4. (informational) /bin/sh in some sandboxes lacks brace expansion, `time`, <( ) - use bash
set -euo pipefail
REPO="."; DO_GIT=1; RUN=0; MCP=0
while [ $# -gt 0 ]; do
  case "$1" in
    --repo) REPO="$2"; shift 2;;
    --no-git) DO_GIT=0; shift;;
    --with-mcp) MCP=1; shift;;
    --run-tests) RUN=1; shift;;
    *) echo "unknown arg: $1" >&2; exit 2;;
  esac
done
cd "$REPO"
[ -f pyproject.toml ] || { echo "no pyproject.toml in $(pwd) - pass --repo <graphify checkout>" >&2; exit 2; }

PIP="python3 -m pip install -q --break-system-packages"
echo "[1/4] installing graphify (editable) + test extras"
$PIP -e . pytest "tree-sitter-hcl>=1.2.0" openai tiktoken
echo "[2/4] installing build tooling"
$PIP build wheel "setuptools>=77"

if [ "$DO_GIT" = 1 ]; then
  echo "[3/4] fetching skillgen baseline commits from upstream"
  UPSTREAM="${GRAPHIFY_UPSTREAM:-https://github.com/Graphify-Labs/graphify.git}"
  [ -d .git ] || git init -q .
  git remote get-url origin >/dev/null 2>&1 || git remote add origin "$UPSTREAM"
  for sha in $(grep -ohE '\b[0-9a-f]{40}\b' tools/skillgen/gen.py tests/test_skillgen.py 2>/dev/null | sort -u); do
    if git cat-file -e "$sha^{commit}" 2>/dev/null; then echo "    have $sha"; else
      git fetch -q --depth=1 origin "$sha" && echo "    fetched $sha" || echo "    WARN could not fetch $sha (offline? skillgen tests will fail)" >&2
    fi
  done
else
  echo "[3/4] skipped (--no-git): tests/test_skillgen.py needs the pinned baseline commits"
fi

if [ "$MCP" = 1 ]; then
  echo "[+] installing the MCP extra (needed for 'graphify serve' / brain.py mcp-config)"
  # Debian/Ubuntu own PyJWT, so a plain pip install can fail with "Cannot uninstall PyJWT ... RECORD file not found"
  $PIP "mcp>=1,<3" "starlette>=1.3.1,<2" 2>/dev/null || $PIP --ignore-installed PyJWT "mcp>=1,<3" "starlette>=1.3.1,<2"
  python3 -c "import mcp; print('    mcp import ok')"
fi
echo "[4/4] smoke check"
python3 -c "import graphify; print('    graphify import ok')"
command -v graphify >/dev/null && echo "    graphify CLI on PATH" || echo "    WARN graphify CLI not on PATH"
if [ "$RUN" = 1 ]; then
  python3 -m pytest tests/ -q -p no:cacheprovider --ignore=tests/bench_extract.py --ignore=tests/bench_query_scoring.py
fi
echo "done"
