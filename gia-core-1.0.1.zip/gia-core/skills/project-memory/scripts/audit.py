"""audit.py - tamper-evident, append-only audit trail for a library (layer L2).

Each entry carries the SHA-256 of the previous entry, so editing, deleting or reordering any past line breaks the
chain from that point on. `verify` re-computes it.

What this does and does NOT promise (stated so nobody over-trusts it):
  * Detects: edits, deletions, reordering or insertion in the MIDDLE of the log; a seal whose snapshot was altered;
    shelf content that changed after it was sealed.
  * Does NOT detect, on its own: someone with write access who rewrites the WHOLE log consistently from the start,
    or truncates it at the end. Defence: record the head hash somewhere you control (an email to the CAE, a ticket,
    a printed page) and pass it back with `verify --anchor <hash>`; a rewritten log cannot reproduce an old head.
  * A crash during an append can leave one torn final line: reported as a warning, never as tampering.
"""
from __future__ import annotations

import getpass
import hashlib
import json
import os
from pathlib import Path

import fsutil
from errors import InputError

LOG_NAME = "audit.log"
ZERO = "0" * 64
MAX_DETAIL_BYTES = 8000


def _canon(d: dict) -> bytes:
    return json.dumps(d, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def entry_hash(e: dict) -> str:
    return hashlib.sha256(_canon({k: v for k, v in e.items() if k != "hash"})).hexdigest()


def actor() -> str:
    try:
        return getpass.getuser()
    except Exception:
        return os.environ.get("USER") or os.environ.get("USERNAME") or "unknown"


def log_path(lib) -> Path:
    return Path(lib) / LOG_NAME


def read(lib) -> tuple[list[dict], dict]:
    """Return (entries, problems). problems: {'torn_tail': bool, 'unreadable_lines': [line numbers]}."""
    p = log_path(lib)
    problems = {"torn_tail": False, "unreadable_lines": []}
    if not p.exists():
        return [], problems
    raw = p.read_bytes()
    lines = raw.split(b"\n")
    ended = raw.endswith(b"\n")
    if lines and lines[-1] == b"":
        lines.pop()
    entries = []
    for i, line in enumerate(lines, 1):
        if not line.strip():
            continue
        try:
            e = json.loads(line.decode("utf-8"))
            if not isinstance(e, dict):
                raise ValueError("not an object")
            entries.append(e)
        except (ValueError, UnicodeDecodeError):
            if i == len(lines) and not ended:
                problems["torn_tail"] = True            # a crash mid-append
            else:
                problems["unreadable_lines"].append(i)
    return entries, problems


def head(lib) -> dict:
    entries, _ = read(lib)
    if not entries:
        return {"seq": 0, "hash": ZERO}
    return {"seq": entries[-1].get("seq", len(entries)), "hash": entries[-1].get("hash", ZERO)}


def _repair_torn_tail(lib) -> bool:
    p = log_path(lib)
    if not p.exists() or p.stat().st_size == 0:
        return False
    data = p.read_bytes()
    if data.endswith(b"\n"):
        return False
    cut = data.rfind(b"\n") + 1
    stamp = fsutil.now_utc_iso().replace(":", "")
    fsutil.atomic_write_bytes(Path(lib) / f"audit.log.torn-{stamp}", data[cut:], 0o600)
    with open(p, "r+b") as fh:
        fh.truncate(cut)
    return True


def append(lib, cmd: str, shelf: str | None = None, detail: dict | None = None, artifacts: dict | None = None,
           who: str | None = None) -> dict:
    lib = Path(lib)
    detail = detail or {}
    if len(json.dumps(detail, default=str)) > MAX_DETAIL_BYTES:
        detail = {"truncated": True, "keys": sorted(detail)[:20]}
    with fsutil.FileLock(lib / ".audit.lock", timeout=60):
        _repair_torn_tail(lib)
        entries, problems = read(lib)
        prev = entries[-1]["hash"] if entries else ZERO
        e = {"seq": (entries[-1]["seq"] + 1) if entries else 1, "ts": fsutil.now_utc_iso(), "actor": who or actor(),
             "cmd": cmd, "shelf": shelf, "detail": detail, "artifacts": artifacts or {}, "prev": prev}
        e["hash"] = entry_hash(e)
        p = log_path(lib)
        with open(p, "ab") as fh:
            fh.write(json.dumps(e, ensure_ascii=False, separators=(",", ":")).encode("utf-8") + b"\n")
            fh.flush()
            if fsutil._default_fsync():
                os.fsync(fh.fileno())
        try:
            os.chmod(p, 0o600)
        except OSError:
            pass
    return e


def issue(sev, code, msg, ref=""):
    return {"severity": sev, "code": code, "message": msg, "ref": ref}


def verify(lib, anchor: str | None = None) -> list[dict]:
    """Check the chain, the optional external anchor, and every seal. Returns findings (ERROR/WARN)."""
    entries, problems = read(lib)
    out: list[dict] = []
    if not entries and not log_path(lib).exists():
        return [issue("WARN", "AUDIT_ABSENT", "no audit log: this library predates auditing, or the log was deleted")]
    if problems["unreadable_lines"]:
        out.append(issue("ERROR", "AUDIT_CHAIN_BROKEN", f"unreadable line(s) {problems['unreadable_lines'][:5]} inside the log"))
    if problems["torn_tail"]:
        out.append(issue("WARN", "AUDIT_TORN_TAIL", "the last line is incomplete (a crash during a write); the next entry repairs it"))
    prev = ZERO
    for i, e in enumerate(entries, 1):
        if e.get("seq") != i:
            out.append(issue("ERROR", "AUDIT_CHAIN_BROKEN", f"sequence gap or reorder: expected {i}, found {e.get('seq')}", f"seq {i}"))
            break
        if e.get("prev") != prev:
            out.append(issue("ERROR", "AUDIT_CHAIN_BROKEN", "the link to the previous entry does not match (an earlier entry was altered, removed or inserted)", f"seq {i}"))
            break
        if e.get("hash") != entry_hash(e):
            out.append(issue("ERROR", "AUDIT_CHAIN_BROKEN", "this entry's content does not match its hash (edited after it was written)", f"seq {i}"))
            break
        prev = e["hash"]
    if anchor:
        a = anchor.strip().lower().split(":")[-1]
        if a != ZERO and not any(e.get("hash") == a for e in entries):
            out.append(issue("ERROR", "AUDIT_ANCHOR_MISMATCH",
                             "the recorded anchor hash is not in this log: the log was rewritten or replaced after the anchor was taken"))
    return out


def seals(entries: list[dict]) -> dict[str, dict]:
    """Latest seal per shelf."""
    out = {}
    for e in entries:
        if e.get("cmd") == "seal" and e.get("shelf"):
            out[e["shelf"]] = e
    return out
