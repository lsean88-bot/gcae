#!/usr/bin/env python3
"""interop_check.py - UAT of the skill/plugin ecosystem against the AKOS registry.

Answers: do the skills and plugins that are supposed to hand off to each other
actually exist, agree with each other, and appear in the registry?

Checks
  FM_MISSING        SKILL.md without parseable frontmatter / name / description
  NAME_DIR_MISMATCH frontmatter name differs from its folder name
  DUPLICATE_DRIFT   same skill name installed in >1 place with DIFFERENT content
                    (reports which files differ - catches e.g. a reference file
                    present in one copy and missing from the other)
  DUPLICATE_SAME    same skill name installed twice, identical content (INFO)
  REF_UNRESOLVED    a skill named in the registry / a SKILL.md does not exist
                    (names in --non-skills, e.g. AKOS agent roles, are exempt)
  REF_UNCONFIRMED   registry says a missing skill's status is unconfirmed (WARN - owner decision)
  SUPERSEDED_ROUTED registry still routes to a skill a newer installed skill supersedes (WARN)
  UNREGISTERED      installed skill never mentioned in the registry (INFO)

Exit code 1 if any ERROR. WARN/INFO never fail the run.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sys
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import textsafe  # noqa: E402
from errors import run_cli  # noqa: E402

MAX_FRONTMATTER = 65536          # descriptions are <= 1024 chars; anything bigger is malformed or hostile (YAML alias bombs)
MAX_SKILL_BYTES = 2_000_000

DEFAULT_ROOTS = ["/mnt/skills/user", "/mnt/skills/plugins", "/mnt/skills/public", "/mnt/skills/examples"]
REG_REL = "references/plugin-coordination-registry.md"
TOKEN = re.compile(r"`([a-z][a-z0-9]*(?:[-:][a-z0-9]+)+)`")


def parse_frontmatter(text: str) -> dict:
    m = re.match(r"^---\s*\n(.*?)\n---\s*(\n|$)", text, re.S)
    if not m:
        return {}
    if len(m.group(1)) > MAX_FRONTMATTER:
        raise ValueError(f"frontmatter is {len(m.group(1))} characters (limit {MAX_FRONTMATTER})")
    try:
        import yaml  # type: ignore
        data = yaml.safe_load(m.group(1))
        return data if isinstance(data, dict) else {}
    except Exception:
        out = {}
        for line in m.group(1).splitlines():
            if ":" in line and not line.startswith((" ", "\t")):
                k, v = line.split(":", 1)
                out[k.strip()] = v.strip().strip("\"'")
        return out


def detect_version(folder: Path) -> str | None:
    """Best-effort version from frontmatter metadata or a '**Version:** x.y' line."""
    try:
        text = (folder / "SKILL.md").read_text(encoding="utf-8", errors="replace")
    except OSError:
        return None
    m = re.search(r"^\s*version:\s*[\"']?([0-9]+(?:\.[0-9]+)*)", text, re.M | re.I) or \
        re.search(r"\*\*Version:\*\*\s*v?([0-9]+(?:\.[0-9]+)*)", text, re.I)
    return m.group(1) if m else None


def vkey(v: str):
    return tuple(int(x) for x in v.split("."))


RETIRED_WORDS = re.compile(r"\bretired\b|\bsuperseded\b|\blegacy\b|not currently installed", re.I)
UNCERTAIN_WORDS = re.compile(
    r"\bwhether\b|accidental|accident\b|not established|unconfirmed|worth confirming|"
    r"\bor missing\b|\bmissing by\b|\?", re.I)
NEGATED_RETIRED = re.compile(r"\b(?:not|never|wasn.t|was not|did not)\s+(?:been\s+)?(?:retire|retired)\b", re.I)


def agent_roles(registry: Path | None) -> set[str]:
    """Names that are AKOS agent roles (agents/<name>.md or named in agent-specifications.md)."""
    roles: set[str] = set()
    if not registry:
        return roles
    skill_dir = registry.parent.parent
    agents = skill_dir / "agents"
    if agents.is_dir():
        roles |= {p.stem for p in agents.glob("*.md")}
    spec = skill_dir / "references" / "agent-specifications.md"
    if spec.is_file():
        roles |= set(re.findall(r"agents/([a-z0-9-]+)\.md", spec.read_text(encoding="utf-8", errors="replace")))
    return roles


def sentences(text: str) -> list[str]:
    """Split markdown into judgement units: each table row, bullet, heading and bold entry header is its own
    block (they carry no full stops, so a period-only splitter fuses a whole table into one 'sentence' and a
    single 'legacy' in one row taints every other row). Prose lines inside a block are re-joined, then split
    into sentences so a sentence wrapped over several lines is still judged as one."""
    blocks: list[list[str]] = []
    for line in text.splitlines():
        stripped = line.strip()
        starts = (not line.startswith((" ", "\t"))) and re.match(r"^(\||#{1,6}\s|[-*]\s|\d+\.\s|\*\*)", stripped)
        if not stripped:
            blocks.append([])
        elif starts or not blocks:
            blocks.append([stripped])
        else:
            blocks[-1].append(stripped)
    out: list[str] = []
    for b in blocks:
        if not b:
            continue
        joined = " ".join(b)
        # a table row is ONE unit: '.' and ';' inside its cells are not sentence ends
        out += [joined] if joined.startswith("|") else re.split(r"(?<=[.;])\s+", joined)
    return out


def classify_status(texts: list[str]) -> tuple[set[str], set[str]]:
    """Return (retired, unconfirmed) backticked names, judged sentence by sentence.

    * retired      - a sentence with a retired/superseded/legacy marker and NO uncertainty or negation
    * unconfirmed  - any sentence that raises doubt about the name's status ('whether ... or accidental',
                     'not established', 'worth confirming'); doubt always wins over a retired marker,
                     because a registry that says 'not established' must not be reported as 'consistent'.
    """
    retired: set[str] = set()
    unconfirmed: set[str] = set()
    for text in texts:
        for sentence in sentences(text):
            toks = set(TOKEN.findall(sentence))
            if not toks:
                continue
            if UNCERTAIN_WORDS.search(sentence):
                unconfirmed |= toks
            elif RETIRED_WORDS.search(sentence) and not NEGATED_RETIRED.search(sentence):
                retired |= toks
    return retired - unconfirmed, unconfirmed


def parse_supersedes(fm: dict) -> list[str]:
    """Raw 'supersedes' entries from top-level or metadata frontmatter (list or string)."""
    val = fm.get("supersedes")
    if val is None and isinstance(fm.get("metadata"), dict):
        val = fm["metadata"].get("supersedes")
    if val is None:
        return []
    return [str(v) for v in val] if isinstance(val, list) else [str(val)]


def normalise_skill_ref(raw: str, known: set[str]) -> str | None:
    """'cae-audit-cowork-plugin v4.0' / 'CAE-Audit-Cowork-Plugin-v5_0' -> installed name, else None."""
    t = raw.strip().lower().replace("_", ".")
    m = re.match(r"^([a-z0-9][a-z0-9-]*?)[\s-]+v?(\d+)(?:\.\d+)*\s*(?:\(.*\))?$", t)
    cands = [t.split()[0]]
    if m:
        cands = [f"{m.group(1)}-v{m.group(2)}", m.group(1)] + cands
    for c in cands:
        if c in known:
            return c
    return None


SCHEMA_ENUM = re.compile(r'"entity":\s*"string \(([^)]*)\)"')


def entity_lists(akos_dir: Path, config_file: Path | None) -> dict[str, set[str]]:
    """Entity codes as declared in the three places that must agree."""
    out: dict[str, set[str]] = {}
    schema = akos_dir / "references" / "knowledge-graph-schema.md"
    if schema.is_file():
        m = SCHEMA_ENUM.search(schema.read_text(encoding="utf-8", errors="replace"))
        if m:
            out["AKOS schema enum"] = {c.strip() for c in m.group(1).split("|") if c.strip()} - {"Group"}
    tax = akos_dir / "references" / "taxonomy-and-metadata-standards.md"
    if tax.is_file():
        text = tax.read_text(encoding="utf-8", errors="replace")
        sec = text.split("## 1. Entity Code Standard", 1)
        if len(sec) == 2:
            table = sec[1].split("\n## ", 1)[0]
            codes = set()
            for line in table.splitlines():
                cells = [c.strip() for c in line.strip().strip("|").split("|")]
                if len(cells) >= 2 and line.startswith("|") and cells[0] not in ("Code", "") and not set(cells[0]) <= set("-: "):
                    codes.add(cells[0])
            out["AKOS taxonomy table"] = codes - {"Group"}
    if config_file and config_file.is_file():
        out["bridge config/entities.json"] = set(json.loads(config_file.read_text()).get("entities", [])) - {"Group"}
    return out


def tree_hashes(folder: Path) -> dict:
    res = {}
    for p in sorted(folder.rglob("*")):
        if "__pycache__" in p.parts or p.name.endswith(".pyc"):
            continue
        if p.is_symlink():                                    # never follow a link: hash where it points
            res[str(p.relative_to(folder))] = hashlib.sha256(("symlink:" + os.readlink(p)).encode()).hexdigest()
        elif p.is_file():
            res[str(p.relative_to(folder))] = hashlib.sha256(p.read_bytes()).hexdigest()
    return res


def discover(roots):
    found = []
    for root in roots:
        r = Path(root)
        if not r.is_dir():
            continue
        for d in sorted(r.iterdir()):
            sk = d / "SKILL.md"
            if d.is_dir() and sk.is_file():
                found.append((str(r), d))
    return found


def run(roots, registry: Path | None, non_skills: set[str], entities_config: Path | None = None):
    issues = []

    def add(sev, code, msg, ref=""):
        issues.append({"severity": sev, "code": code, "message": msg, "ref": ref})

    catalog = defaultdict(list)  # name -> [(root, dir)]
    supersedes_raw = {}  # skill name -> raw 'supersedes' entries
    aliases = {}  # folder name -> catalog name (e.g. 'data:build-dashboard' -> 'build-dashboard')
    is_command = {}
    for root, d in discover(roots):
        dirname = d.name
        try:
            with open(d / "SKILL.md", "rb") as fh:
                raw = fh.read(MAX_SKILL_BYTES + 1)                 # bounded read: a multi-GB SKILL.md cannot exhaust memory
            fm = parse_frontmatter(raw[:MAX_SKILL_BYTES].decode("utf-8", errors="replace"))
        except (OSError, ValueError) as exc:
            add("ERROR", "FM_UNREADABLE", f"cannot read or parse SKILL.md: {textsafe.display(exc, 160)}", f"{root}/{dirname}")
            continue
        # plugin commands live in "<plugin>:<command>" folders and legitimately carry no `name`
        cmd = ":" in dirname
        name = fm.get("name") or (dirname if cmd else None)
        if not fm:
            add("ERROR", "FM_MISSING", "no parseable YAML frontmatter", f"{root}/{dirname}")
        if not name:
            add("ERROR", "FM_MISSING", "frontmatter has no 'name'", f"{root}/{dirname}")
            continue
        if not fm.get("description"):
            add("ERROR", "FM_MISSING", "frontmatter has no 'description' (skill can never trigger)", f"{root}/{dirname}")
        if not cmd and name != dirname:
            add("WARN", "NAME_DIR_MISMATCH", f"name {name!r} != folder {dirname!r}", f"{root}/{dirname}")
        catalog[name].append((root, d))
        is_command[name] = cmd
        aliases[dirname] = name
        sup = parse_supersedes(fm)
        if sup:
            supersedes_raw[name] = sup

    for name, locs in catalog.items():
        if len(locs) < 2:
            continue
        base_root, base_dir = locs[0]
        lbl = lambda r, d: f"{Path(r).name}/{d.name}"  # noqa: E731  e.g. plugins/mktron-pune-vda-compliance:pune-india-ops-audit
        base = tree_hashes(base_dir)
        for root, d in locs[1:]:
            other = tree_hashes(d)
            if base == other:
                add("INFO", "DUPLICATE_SAME", f"installed twice, identical: {lbl(base_root, base_dir)} and {lbl(root, d)}", name)
                continue
            only_a = sorted(set(base) - set(other))
            only_b = sorted(set(other) - set(base))
            changed = sorted(f for f in set(base) & set(other) if base[f] != other[f])
            parts = []
            if only_a:
                parts.append(f"only in {lbl(base_root, base_dir)}: {only_a}")
            if only_b:
                parts.append(f"only in {lbl(root, d)}: {only_b}")
            if changed:
                parts.append(f"content differs: {changed}")
            v_a, v_b = detect_version(base_dir), detect_version(d)
            hint = ""
            if v_a and v_b and v_a != v_b:
                (nl, nv), (ol, ov) = ((lbl(base_root, base_dir), v_a), (lbl(root, d), v_b)) \
                    if vkey(v_a) > vkey(v_b) else ((lbl(root, d), v_b), (lbl(base_root, base_dir), v_a))
                hint = f" | NEWER: {nl} v{nv}; looks stale: {ol} v{ov}"
            elif v_a or v_b:
                hint = f" | versions: {lbl(base_root, base_dir)}={v_a or '?'}, {lbl(root, d)}={v_b or '?'}"
            add("WARN", "DUPLICATE_DRIFT", f"two installed copies disagree - {'; '.join(parts)}{hint}", name)

    registry_text = ""
    if registry and registry.is_file():
        registry_text = registry.read_text(encoding="utf-8", errors="replace")
    elif registry:
        add("ERROR", "REGISTRY_MISSING", f"registry not found at {registry}", str(registry))

    names = set(catalog)
    base_names = names | {n.split(":", 1)[-1] for n in names if ":" in n} | set(aliases)
    roles = agent_roles(registry)
    skill_dir_texts = [registry_text]
    if registry and registry.parent.parent.joinpath("SKILL.md").is_file():
        skill_dir_texts.append(registry.parent.parent.joinpath("SKILL.md").read_text(encoding="utf-8", errors="replace"))
    retired, unconfirmed = classify_status(skill_dir_texts)
    mentioned = set()
    for tok in set(TOKEN.findall(registry_text)):
        if tok in names or tok in base_names:
            mentioned.add(tok)
            mentioned.add(aliases.get(tok, tok))
        elif tok in non_skills or tok in roles:
            continue
        elif tok in unconfirmed:
            add("WARN", "REF_UNCONFIRMED",
                "not installed, and the registry itself says its status is unconfirmed (retired on purpose or lost?). "
                "Owner must decide; do not treat as retired", tok)
        elif tok in retired:
            add("INFO", "REF_RETIRED", "not installed, and the registry documents it as retired/superseded", tok)
        else:
            add("WARN", "REF_UNRESOLVED",
                "named in registry but no installed skill/command of that name "
                "(add to --non-skills if it is a tool)", tok)

    # the three entity lists must agree (a code added in one place only is silent drift)
    if registry:
        lists = entity_lists(registry.parent.parent, entities_config)
        if len(lists) >= 2:
            union = set().union(*lists.values())
            gaps = {k: sorted(union - v) for k, v in lists.items() if union - v}
            if gaps:
                add("WARN", "ENTITY_LISTS_DISAGREE",
                    "entity codes differ between lists - missing from: " +
                    "; ".join(f"{k}: {v}" for k, v in gaps.items()), "entities")
            else:
                add("INFO", "ENTITY_LISTS_AGREE", f"{len(union)} entity codes agree across {len(lists)} lists", "entities")

    # a newer installed skill declares it supersedes an older installed one
    reg_sentences = sentences(registry_text) if registry_text else []
    for newer, raws in sorted(supersedes_raw.items()):
        for raw in raws:
            old = normalise_skill_ref(raw, set(catalog))
            if not old or old == newer:
                continue
            add("INFO", "SUPERSEDED_INSTALLED", f"{old} is still installed but {newer} declares it supersedes it", old)
            live = [x for x in reg_sentences if f"`{old}`" in x and not RETIRED_WORDS.search(x)]
            if live:
                add("WARN", "SUPERSEDED_ROUTED",
                    f"registry still routes to {old} ({len(live)} live mention(s)) although installed {newer} "
                    f"declares it supersedes it", old)

    for name, locs in sorted(catalog.items()):
        if is_command.get(name):
            continue
        if not any(Path(r).name in ("user", "plugins") for r, _ in locs):
            continue  # consumer/example/public skills are out of scope for audit-ecosystem registration
        short = name.split(":", 1)[-1]
        if name not in mentioned and short not in mentioned and name not in registry_text:
            roots_ = sorted({r for r, _ in locs})
            add("INFO", "UNREGISTERED", f"installed ({', '.join(roots_)}) but not in the registry", name)

    summary = {"skills_found": len(catalog), "locations": sum(len(v) for v in catalog.values()),
               "errors": sum(i["severity"] == "ERROR" for i in issues),
               "warnings": sum(i["severity"] == "WARN" for i in issues),
               "info": sum(i["severity"] == "INFO" for i in issues)}
    return summary, issues


def _main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--roots", nargs="*", default=DEFAULT_ROOTS)
    ap.add_argument("--registry", help="path to plugin-coordination-registry.md "
                                       "(default: auto-detect in the AKOS skill under --roots)")
    ap.add_argument("--non-skills", nargs="*", default=[],
                    help="backticked names that are not skills (agent roles, tools)")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)

    reg = Path(a.registry) if a.registry else None
    if reg is None:
        for root in a.roots:
            cand = Path(root) / "akos-enterprise-orchestrator" / REG_REL
            if cand.is_file():
                reg = cand
                break
    cfg = Path(__file__).resolve().parent.parent / "config" / "entities.json"
    summary, issues = run(a.roots, reg, set(a.non_skills), cfg)
    if a.json:
        print(json.dumps({"registry": str(reg) if reg else None, "summary": summary, "issues": issues}, indent=2))
    else:
        print(f"registry: {textsafe.display(reg or 'NOT FOUND', 200)}")
        order = {"ERROR": 0, "WARN": 1, "INFO": 2}
        for i in sorted(issues, key=lambda x: (order[x["severity"]], x["code"], x["ref"])):
            print(f"[{i['severity']:<5}] {i['code']:<18} {textsafe.display_tail(i['ref'], 60):<42} {textsafe.display(i['message'], 500)}")
        print(f"\n{summary['skills_found']} skills ({summary['locations']} installed locations): "
              f"{summary['errors']} error(s), {summary['warnings']} warning(s), {summary['info']} info")
    return 1 if summary["errors"] else 0


def main(argv=None):
    """Exit contract: 0 clean, 1 errors found, 2 bad input, 3 internal error."""
    return run_cli(_main, argv)


if __name__ == "__main__":
    sys.exit(main())
