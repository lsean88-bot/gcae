#!/usr/bin/env python3
"""
kg_tools.py — Enterprise Project Memory & Knowledge Graph maintenance CLI.

Stdlib-only (json, argparse, datetime, pathlib, uuid) so it runs identically in
Claude Cowork sandboxes and in a Claude Code repo checkout with no dependencies.

State files (created in the current working directory unless --dir is given):
  project-memory.json   — confirmed_facts, assumptions, decisions, evidence,
                           prompt_evolution, template_evolution
  knowledge-graph.json   — nodes, edges

Schema reference: ../references/kg-schema.md
"""
import argparse
import json
import sys
from datetime import date
from pathlib import Path

PM_FILE = "project-memory.json"
KG_FILE = "knowledge-graph.json"

CONFIDENCE_LEVELS = ["Very High", "High", "Moderate", "Low"]


def today():
    return date.today().isoformat()


def load(path, default):
    p = Path(path)
    if not p.exists():
        return default
    with open(p) as f:
        return json.load(f)


def save(path, data):
    with open(path, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        f.write("\n")


def empty_pm(engagement=""):
    return {
        "schema_version": "1.0",
        "engagement": engagement,
        "confirmed_facts": [],
        "assumptions": [],
        "decisions": [],
        "evidence": [],
        "prompt_evolution": [],
        "template_evolution": [],
    }


def empty_kg():
    return {"schema_version": "1.0", "nodes": [], "edges": []}


def next_id(items, prefix):
    n = len(items) + 1
    return f"{prefix}-{n:04d}"


def resolve_dir(args):
    d = Path(args.dir) if getattr(args, "dir", None) else Path(".")
    d.mkdir(parents=True, exist_ok=True)
    return d


def cmd_init(args):
    d = resolve_dir(args)
    pm_path, kg_path = d / PM_FILE, d / KG_FILE
    if pm_path.exists() or kg_path.exists():
        print(f"Already initialized in {d} — nothing done. Delete the files first if you really want to reset.")
        return
    save(pm_path, empty_pm(args.engagement or ""))
    save(kg_path, empty_kg())
    print(f"Initialized {pm_path} and {kg_path}")


def cmd_add_fact(args):
    d = resolve_dir(args)
    pm = load(d / PM_FILE, empty_pm())
    if args.confidence not in CONFIDENCE_LEVELS:
        sys.exit(f"--confidence must be one of {CONFIDENCE_LEVELS}")
    entry = {
        "id": next_id(pm["confirmed_facts"], "F"),
        "text": args.text,
        "evidence_id": args.evidence or None,
        "confidence": args.confidence,
        "confidence_basis": args.basis or "",
        "date_confirmed": today(),
        "superseded_by": None,
        "status": "active",
    }
    pm["confirmed_facts"].append(entry)
    save(d / PM_FILE, pm)
    print(f"Added {entry['id']}")


def cmd_add_assumption(args):
    d = resolve_dir(args)
    pm = load(d / PM_FILE, empty_pm())
    entry = {
        "id": next_id(pm["assumptions"], "A"),
        "text": args.text,
        "risk_if_wrong": args.risk or "",
        "confidence": args.confidence or "Moderate",
        "expiry_condition": args.expiry or "",
        "validation_required": args.validation or "",
        "date_logged": today(),
        "status": "open",
    }
    pm["assumptions"].append(entry)
    save(d / PM_FILE, pm)
    print(f"Added {entry['id']}")


def cmd_add_decision(args):
    d = resolve_dir(args)
    pm = load(d / PM_FILE, empty_pm())
    entry = {
        "id": next_id(pm["decisions"], "D"),
        "text": args.text,
        "rationale": args.rationale or "",
        "alternatives_considered": args.alternatives or "",
        "affects": args.affects.split(";") if args.affects else [],
        "date": today(),
        "decided_by": args.decided_by or "",
    }
    pm["decisions"].append(entry)
    save(d / PM_FILE, pm)
    print(f"Added {entry['id']}")


def cmd_add_evidence(args):
    d = resolve_dir(args)
    pm = load(d / PM_FILE, empty_pm())
    if args.rank not in ["R1", "R2", "R3", "R4", "R5"]:
        sys.exit("--rank must be one of R1 R2 R3 R4 R5")
    entry = {
        "id": next_id(pm["evidence"], "E"),
        "description": args.description,
        "rank": args.rank,
        "source": args.source or "",
        "linked_nodes": args.linked_nodes.split(";") if args.linked_nodes else [],
        "date_obtained": today(),
    }
    pm["evidence"].append(entry)
    save(d / PM_FILE, pm)
    print(f"Added {entry['id']}")


def cmd_add_node(args):
    d = resolve_dir(args)
    kg = load(d / KG_FILE, empty_kg())
    dup = [n for n in kg["nodes"] if n["type"] == args.type and n["name"].strip().lower() == args.name.strip().lower()]
    if dup:
        print(f"Duplicate node exists: {dup[0]['id']} ({dup[0]['type']}: {dup[0]['name']}) — not adding a second one.")
        return
    attrs = {}
    if args.attrs:
        for pair in args.attrs.split(";"):
            if "=" in pair:
                k, v = pair.split("=", 1)
                attrs[k.strip()] = v.strip()
    entry = {
        "id": next_id(kg["nodes"], "N"),
        "type": args.type,
        "name": args.name,
        "attributes": attrs,
        "date_added": today(),
    }
    kg["nodes"].append(entry)
    save(d / KG_FILE, kg)
    print(f"Added {entry['id']} ({entry['type']}: {entry['name']})")


def cmd_add_edge(args):
    d = resolve_dir(args)
    kg = load(d / KG_FILE, empty_kg())
    ids = {n["id"] for n in kg["nodes"]}
    if args.from_id not in ids or args.to_id not in ids:
        sys.exit(f"Both --from and --to must be existing node ids. Known ids: {sorted(ids)}")
    entry = {
        "id": next_id(kg["edges"], "R"),
        "from": args.from_id,
        "relationship": args.rel,
        "to": args.to_id,
        "confidence": args.confidence or "Moderate",
        "source": args.source or "",
        "date_added": today(),
    }
    kg["edges"].append(entry)
    save(d / KG_FILE, kg)
    print(f"Added {entry['id']}: {args.from_id} -{args.rel}-> {args.to_id}")


def cmd_check_integrity(args):
    d = resolve_dir(args)
    kg = load(d / KG_FILE, empty_kg())
    pm = load(d / PM_FILE, empty_pm())
    node_ids = {n["id"] for n in kg["nodes"]}
    problems = []

    # broken references
    for e in kg["edges"]:
        if e["from"] not in node_ids:
            problems.append(f"BROKEN EDGE {e['id']}: 'from' {e['from']} does not exist")
        if e["to"] not in node_ids:
            problems.append(f"BROKEN EDGE {e['id']}: 'to' {e['to']} does not exist")

    # duplicates
    seen = {}
    for n in kg["nodes"]:
        key = (n["type"], n["name"].strip().lower())
        if key in seen:
            problems.append(f"DUPLICATE NODE: {n['id']} duplicates {seen[key]} ({n['type']}: {n['name']})")
        else:
            seen[key] = n["id"]

    # orphans (informational)
    linked = set()
    for e in kg["edges"]:
        linked.add(e["from"])
        linked.add(e["to"])
    orphans = [n["id"] for n in kg["nodes"] if n["id"] not in linked]
    if orphans:
        problems.append(f"INFO — orphan nodes (no edges yet): {orphans}")

    # stale-looking open assumptions
    open_assumptions = [a for a in pm["assumptions"] if a["status"] == "open"]
    if open_assumptions:
        problems.append(f"INFO — {len(open_assumptions)} open assumption(s); review expiry conditions: " +
                         "; ".join(f"{a['id']} (expires: {a['expiry_condition'] or 'not stated'})" for a in open_assumptions))

    if not problems:
        print("Integrity check: PASS — no broken references, no duplicate nodes.")
    else:
        print(f"Integrity check: {len([p for p in problems if not p.startswith('INFO')])} hard issue(s), "
              f"{len([p for p in problems if p.startswith('INFO')])} info item(s):")
        for p in problems:
            print(f" - {p}")


def cmd_snapshot(args):
    d = resolve_dir(args)
    pm = load(d / PM_FILE, empty_pm())
    kg = load(d / KG_FILE, empty_kg())

    lines = []
    lines.append(f"# Project Memory & Knowledge Graph Snapshot — {today()}")
    if pm.get("engagement"):
        lines.append(f"**Engagement:** {pm['engagement']}\n")

    lines.append(f"## Knowledge Graph — {len(kg['nodes'])} nodes, {len(kg['edges'])} edges\n")
    by_type = {}
    for n in kg["nodes"]:
        by_type.setdefault(n["type"], []).append(n["name"])
    for t, names in sorted(by_type.items()):
        lines.append(f"- **{t}** ({len(names)}): {', '.join(names)}")

    lines.append(f"\n## Confirmed Facts ({len(pm['confirmed_facts'])})")
    for f in pm["confirmed_facts"]:
        if f["status"] == "active":
            lines.append(f"- [{f['id']}] {f['text']} — *{f['confidence']}* (evidence: {f['evidence_id'] or 'n/a'})")

    lines.append(f"\n## Open Assumptions ({sum(1 for a in pm['assumptions'] if a['status']=='open')})")
    for a in pm["assumptions"]:
        if a["status"] == "open":
            lines.append(f"- [{a['id']}] {a['text']} — risk if wrong: {a['risk_if_wrong']} — expires: {a['expiry_condition'] or 'not stated'}")

    lines.append(f"\n## Decisions Log ({len(pm['decisions'])})")
    for dcn in pm["decisions"]:
        lines.append(f"- [{dcn['id']}] {dcn['date']}: {dcn['text']} — rationale: {dcn['rationale']}")

    if pm["prompt_evolution"]:
        lines.append(f"\n## Prompt Evolution Log ({len(pm['prompt_evolution'])})")
        for p in pm["prompt_evolution"]:
            status = "RETIRED" if p.get("retired") else p.get("validation_status", "pending")
            lines.append(f"- [{p['id']}] {p['date']} — {p['target']}: {p['problem_addressed']} ({status})")

    if pm["template_evolution"]:
        lines.append(f"\n## Template Evolution Log ({len(pm['template_evolution'])})")
        for t in pm["template_evolution"]:
            lines.append(f"- [{t['id']}] {t['date']} — {t['target']}: {t['change']}")

    print("\n".join(lines))


def build_parser():
    p = argparse.ArgumentParser(description="Maintain project-memory.json and knowledge-graph.json")
    p.add_argument("--dir", help="Directory holding the state files (default: current directory)")
    sub = p.add_subparsers(dest="command", required=True)

    s = sub.add_parser("init", help="Create empty state files")
    s.add_argument("--engagement", help="Engagement/entity name")
    s.set_defaults(func=cmd_init)

    s = sub.add_parser("add-fact")
    s.add_argument("--text", required=True)
    s.add_argument("--evidence", help="Evidence id, e.g. E-0001")
    s.add_argument("--confidence", required=True, choices=CONFIDENCE_LEVELS)
    s.add_argument("--basis", help="One line — why this confidence level (Article 23)")
    s.set_defaults(func=cmd_add_fact)

    s = sub.add_parser("add-assumption")
    s.add_argument("--text", required=True)
    s.add_argument("--risk", help="Risk if this assumption is wrong")
    s.add_argument("--confidence", choices=CONFIDENCE_LEVELS)
    s.add_argument("--expiry", help="Condition under which this expires/must be revalidated")
    s.add_argument("--validation", help="What would validate or invalidate this")
    s.set_defaults(func=cmd_add_assumption)

    s = sub.add_parser("add-decision")
    s.add_argument("--text", required=True)
    s.add_argument("--rationale")
    s.add_argument("--alternatives", help="Semicolon-separated alternatives considered")
    s.add_argument("--affects", help="Semicolon-separated node ids or free text")
    s.add_argument("--decided-by", dest="decided_by")
    s.set_defaults(func=cmd_add_decision)

    s = sub.add_parser("add-evidence")
    s.add_argument("--description", required=True)
    s.add_argument("--rank", required=True, choices=["R1", "R2", "R3", "R4", "R5"])
    s.add_argument("--source")
    s.add_argument("--linked-nodes", dest="linked_nodes", help="Semicolon-separated node ids")
    s.set_defaults(func=cmd_add_evidence)

    s = sub.add_parser("add-node")
    s.add_argument("--type", required=True)
    s.add_argument("--name", required=True)
    s.add_argument("--attrs", help="Semicolon-separated key=value pairs")
    s.set_defaults(func=cmd_add_node)

    s = sub.add_parser("add-edge")
    s.add_argument("--from", dest="from_id", required=True)
    s.add_argument("--rel", required=True)
    s.add_argument("--to", dest="to_id", required=True)
    s.add_argument("--confidence", choices=CONFIDENCE_LEVELS)
    s.add_argument("--source")
    s.set_defaults(func=cmd_add_edge)


    s = sub.add_parser("check-integrity")
    s.set_defaults(func=cmd_check_integrity)

    s = sub.add_parser("snapshot")
    s.set_defaults(func=cmd_snapshot)

    return p


if __name__ == "__main__":
    parser = build_parser()
    ns = parser.parse_args()
    ns.func(ns)
