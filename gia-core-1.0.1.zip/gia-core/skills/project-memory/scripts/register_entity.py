#!/usr/bin/env python3
"""register_entity.py - add ONE entity code to all three places that must agree, atomically.

  1. AKOS references/knowledge-graph-schema.md   (entity enum)
  2. AKOS references/taxonomy-and-metadata-standards.md (entity code table + 'N entities' wording)
  3. this skill's config/entities.json

The code, name, country and sector must come from the OWNER: the AKOS taxonomy says "use these exactly -
don't invent variants", so this tool never proposes a code. Dry-run by default; --apply writes (with .bak).
"""
from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import fsutil  # noqa: E402
import strictjson  # noqa: E402
from errors import InputError, run_cli  # noqa: E402

NUM = {9: "nine", 10: "ten", 11: "eleven", 12: "twelve", 13: "thirteen", 14: "fourteen", 15: "fifteen"}
CODE_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 -]{0,30}$")
ENUM = re.compile(r'("entity":\s*"string \()([^)]*)(\)")')


def plan(akos: Path, config: Path, code: str, name: str, country: str, sector: str):
    if not CODE_RE.match(code) or code == "Group":
        raise ValueError(f"invalid entity code {code!r}")
    schema, tax = akos / "references/knowledge-graph-schema.md", akos / "references/taxonomy-and-metadata-standards.md"
    s, t, c = schema.read_text(encoding="utf-8"), tax.read_text(encoding="utf-8"), json.loads(config.read_text())
    m = ENUM.search(s)
    if not m:
        raise ValueError("entity enum not found in knowledge-graph-schema.md")
    members = m.group(2).split("|")
    if code in members or code in c.get("entities", []) or re.search(rf"^\| {re.escape(code)} \|", t, re.M):
        raise ValueError(f"{code!r} is already registered in at least one list - refusing to double-register")
    members.insert(members.index("Group") if "Group" in members else len(members), code)
    s2 = s[:m.start(2)] + "|".join(members) + s[m.end(2):]
    head, sep, rest = t.partition("| Code | Entity | Country | Sector |")
    if not sep:
        raise ValueError("entity table header not found in taxonomy-and-metadata-standards.md")
    lines = rest.split("\n")
    last = max(i for i, ln in enumerate(lines[:60]) if ln.startswith("|"))
    lines.insert(last + 1, f"| {code} | {name} | {country} | {sector} |")
    t2 = head + sep + "\n".join(lines)
    # data rows only: the |---| separator row does not match "^| <text> |"
    n_before = len(re.findall(r"^\| [^|]+ \|", rest.split("\n\n", 1)[0], re.M))
    n_after = n_before + 1
    for old, new in ((NUM.get(n_before), NUM.get(n_after)),):
        if old and new:
            t2 = t2.replace(f"{old} entities", f"{new} entities")
    c2 = dict(c)
    ents = list(c.get("entities", []))
    ents.insert(ents.index("Group") if "Group" in ents else len(ents), code)
    c2["entities"] = ents
    return {schema: s2, tax: t2, config: json.dumps(c2, indent=2) + "\n"}


def _main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--akos-dir", required=True)
    ap.add_argument("--config", default=str(Path(__file__).resolve().parent.parent / "config/entities.json"))
    ap.add_argument("--code", required=True); ap.add_argument("--name", required=True)
    ap.add_argument("--country", required=True); ap.add_argument("--sector", required=True)
    ap.add_argument("--apply", action="store_true")
    a = ap.parse_args(argv)
    for field in ("name", "country", "sector"):
        v = getattr(a, field)
        if not v.strip() or any(ch in v for ch in "|\n\r\x00"):
            raise InputError(f"--{field} must be non-empty text without '|' or line breaks (it goes into a markdown table)")
    changes = plan(Path(a.akos_dir), Path(a.config), a.code, a.name, a.country, a.sector)
    for path in changes:
        print(f"{'WRITE' if a.apply else 'would write'}: {path}")
    if not a.apply:
        print("\n(dry run - re-run with --apply)")
        return 0
    baks = []
    try:
        for path in changes:                                   # keep a .bak of each file, as before
            shutil.copy2(path, str(path) + ".bak")
            baks.append(Path(str(path) + ".bak"))
        fsutil.multi_replace(changes)                          # ALL three change, or NONE do
    except BaseException:
        for b in baks:
            b.unlink(missing_ok=True)                          # leave no litter after a failed run
        raise
    return 0


def main(argv=None) -> int:
    return run_cli(_main, argv)


if __name__ == "__main__":
    sys.exit(main())
