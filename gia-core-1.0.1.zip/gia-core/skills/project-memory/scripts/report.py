#!/usr/bin/env python3
"""report.py - dual-format reporting: a self-contained HTML dashboard and an Excel workbook.

Two output rules that exist because labels come from documents nobody here controls:
  * HTML: every dynamic value is html.escape()d (a label like "<script>..." must render as text).
  * Excel: a cell value that starts with = + - @ (or tab/CR) would be executed as a FORMULA by Excel
    (formula/CSV injection). safe() prefixes such strings with an apostrophe so they stay text.
Confidential shelves appear as COUNTS ONLY: no labels, ids or locations ever reach a report.
"""
from __future__ import annotations

import html
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import akos_graph as ag  # noqa: E402
import brain  # noqa: E402
import fsutil  # noqa: E402
import textsafe  # noqa: E402

TRUST_COLOUR = {"CONFIRMED": "#1a7f37", "PROVISIONAL": "#b7791f", "INDICATOR": "#c0392b"}
SEV_COLOUR = {"ERROR": "#c0392b", "WARN": "#b7791f"}
_DANGEROUS = ("=", "+", "-", "@", "\t", "\r")


class Formula(str):
    """A formula WE wrote (totals, COUNTIF summaries). Everything else is data and is neutralised."""


def safe(v):
    """Excel-safe cell value: XML-illegal characters removed, over-long text truncated, formula prefixes neutralised."""
    return v if isinstance(v, Formula) else textsafe.xlsx_text(v)


def _ap(ws, row):
    """Append a row; every value goes through safe() so no cell can carry a crash or a live formula from data."""
    ws.append([safe(v) for v in row])


def esc(v) -> str:
    """HTML-safe, control-character-safe text."""
    return html.escape(textsafe.display(v, 2000), quote=True)


# ---- data collection -----------------------------------------------------------------------------------
def collect(lib: Path, today: str | None = None) -> dict:
    mf = brain.load_manifest(lib)
    today = today or fsutil.today_local()
    st = brain.status(lib, today)
    guard = brain.guard(lib)
    stale = brain.stale_report(lib, today)
    conf = {r["shelf"] for r in st["shelves"] if r.get("confidential")}
    stale_items = []
    for i in stale["items"]:
        shelf_conf = i["shelf"] in conf
        stale_items.append({**i, "label": "(confidential shelf: withheld)" if shelf_conf else i["label"],
                            "id": "(withheld)" if shelf_conf else i["id"]})
    memory = []
    for name in mf["shelves"]:
        idx = lib / "shelves" / name / "memory_index.json"
        if idx.exists():
            try:
                c = Counter(r.get("outcome") for r in ag.load_json(idx))
            except (OSError, ValueError):
                continue
            for outcome, n in sorted(c.items()):
                memory.append({"shelf": name, "outcome": outcome, "count": n})
    return {"library": Path(lib).name, "generated": today, "policy": mf["policy"], "shelves": st["shelves"],
            "guard": guard, "stale": stale_items, "memory": memory, "last_index": st.get("last_index")}


# ---- HTML -------------------------------------------------------------------------------------------------
CSS = """
:root{--bg:#fff;--fg:#1c2330;--muted:#5b6575;--card:#f5f7fa;--line:#dde3ea}
@media (prefers-color-scheme:dark){:root{--bg:#10141b;--fg:#e6ebf2;--muted:#9aa6b5;--card:#182030;--line:#2a3547}}
:root[data-theme=light]{--bg:#fff;--fg:#1c2330;--muted:#5b6575;--card:#f5f7fa;--line:#dde3ea}
:root[data-theme=dark]{--bg:#10141b;--fg:#e6ebf2;--muted:#9aa6b5;--card:#182030;--line:#2a3547}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font:15px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;padding:24px;max-width:1100px;margin-inline:auto}
h1{font-size:22px;margin:0 0 4px}h2{font-size:16px;margin:28px 0 8px}.sub{color:var(--muted);margin:0 0 18px}
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px}.card b{display:block;font-size:24px}
.card span{color:var(--muted);font-size:12px}.wrap{overflow-x:auto}
table{border-collapse:collapse;width:100%;min-width:640px}th,td{border-bottom:1px solid var(--line);padding:7px 9px;text-align:left;vertical-align:top;font-size:13px}
th{color:var(--muted);font-weight:600}.pill{display:inline-block;border-radius:999px;padding:1px 9px;color:#fff;font-size:12px}
.bar{display:flex;height:10px;border-radius:5px;overflow:hidden;background:var(--line);min-width:120px}
.note{color:var(--muted);font-size:12px;margin-top:18px}
"""


def render_html(d: dict) -> str:
    tot = Counter()
    for r in d["shelves"]:
        for k, v in r.get("trust_mix", {}).items():
            tot[k] += v
    nodes = sum(r["nodes"] for r in d["shelves"])
    edges = sum(r["edges"] for r in d["shelves"])
    errs = sum(1 for g in d["guard"] if g["severity"] == "ERROR")
    warns = len(d["guard"]) - errs
    card = lambda n, label, col=None: (  # noqa: E731
        f'<div class="card"><b style="color:{col or "inherit"}">{esc(n)}</b><span>{esc(label)}</span></div>')
    parts = [f"<!doctype html><html lang='en'><head><meta charset='utf-8'>",
             "<meta name='viewport' content='width=device-width, initial-scale=1'>",
             f"<title>Library brain: {esc(d['library'])}</title><style>{CSS}</style></head><body>",
             f"<h1>Library brain: {esc(d['library'])}</h1>",
             f"<p class='sub'>Generated {esc(d['generated'])} · last index {esc(d['last_index'] or 'never')} · "
             f"confidential shelves are shown as counts only</p>",
             "<div class='cards'>",
             card(len(d["shelves"]), "shelves"), card(nodes, "nodes"), card(edges, "edges"),
             card(tot["CONFIRMED"], "confirmed", TRUST_COLOUR["CONFIRMED"]),
             card(tot["PROVISIONAL"], "provisional", TRUST_COLOUR["PROVISIONAL"]),
             card(tot["INDICATOR"], "indicator only", TRUST_COLOUR["INDICATOR"]),
             card(errs, "guard errors", SEV_COLOUR["ERROR"] if errs else TRUST_COLOUR["CONFIRMED"]),
             card(warns, "guard warnings", SEV_COLOUR["WARN"] if warns else TRUST_COLOUR["CONFIRMED"]),
             card(len(d["stale"]), "stale / undated", SEV_COLOUR["ERROR"] if d["stale"] else TRUST_COLOUR["CONFIRMED"]),
             "</div>"]
    # guard
    parts.append("<h2>Guard</h2>")
    if d["guard"]:
        parts.append("<div class='wrap'><table><tr><th>Severity</th><th>Code</th><th>Where</th><th>Message</th></tr>")
        for g in d["guard"]:
            parts.append(f"<tr><td><span class='pill' style='background:{SEV_COLOUR.get(g['severity'], '#555')}'>{esc(g['severity'])}</span></td>"
                         f"<td>{esc(g['code'])}</td><td>{esc(g.get('ref') or '')}</td><td>{esc(g['message'])}</td></tr>")
        parts.append("</table></div>")
    else:
        parts.append("<p>No findings: confidentiality, backend and memory checks all pass.</p>")
    # shelves
    parts.append("<h2>Shelves</h2><div class='wrap'><table><tr><th>Shelf</th><th>Kind</th><th>Entity</th><th>Confidential</th>"
                 "<th>Nodes</th><th>Edges</th><th>Trust mix</th><th>Memory</th><th>Stale</th></tr>")
    for r in d["shelves"]:
        mix = r.get("trust_mix", {})
        n = max(1, sum(mix.values()))
        bar = "".join(f"<span style='width:{100 * mix.get(k, 0) / n:.1f}%;background:{TRUST_COLOUR[k]}' title='{esc(k)}: {mix.get(k, 0)}'></span>"
                      for k in ("CONFIRMED", "PROVISIONAL", "INDICATOR"))
        parts.append(f"<tr><td>{esc(r['shelf'])}</td><td>{esc(r['kind'])}</td><td>{esc(r['entity'])}</td>"
                     f"<td>{'yes' if r['confidential'] else 'no'}</td><td>{r['nodes']}</td><td>{r['edges']}</td>"
                     f"<td><div class='bar'>{bar}</div></td><td>{r['memory_entries']}</td><td>{r['stale_items']}</td></tr>")
    parts.append("</table></div>")
    # stale
    parts.append("<h2>Statutory freshness</h2>")
    if d["stale"]:
        parts.append("<div class='wrap'><table><tr><th>Shelf</th><th>Item</th><th>State</th><th>Review by</th></tr>")
        for i in d["stale"]:
            parts.append(f"<tr><td>{esc(i['shelf'])}</td><td>{esc(i['id'])}: {esc(i['label'])}</td>"
                         f"<td><span class='pill' style='background:{SEV_COLOUR['ERROR']}'>{esc(i['state'])}</span></td>"
                         f"<td>{esc(i.get('review_by') or '-')}</td></tr>")
        parts.append("</table></div><p class='note'>Re-validate each item against the portal (R1 evidence) before reliance.</p>")
    else:
        parts.append("<p>No stale or undated statutory items.</p>")
    # memory
    parts.append("<h2>Work memory (indicators of usefulness, not evidence)</h2>")
    if d["memory"]:
        parts.append("<div class='wrap'><table><tr><th>Shelf</th><th>Outcome</th><th>Count</th></tr>" +
                     "".join(f"<tr><td>{esc(m['shelf'])}</td><td>{esc(m['outcome'])}</td><td>{m['count']}</td></tr>" for m in d["memory"]) +
                     "</table></div>")
    else:
        parts.append("<p>No saved memory yet.</p>")
    parts.append("<p class='note'>Trust labels: CONFIRMED (100%/High, not proposed, evidence R1-R3 or unranked) · "
                 "PROVISIONAL (Medium, or R4) · INDICATOR (Low, proposed, alleged, graph-inferred, saved-memory, or R5). "
                 "Retrieval rank never changes a label.</p></body></html>")
    return "".join(parts)


# ---- XLSX -------------------------------------------------------------------------------------------------
def _style(ws, widths):
    from openpyxl.styles import Font, PatternFill, Alignment
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="1F3A5F")
        c.alignment = Alignment(vertical="center", wrap_text=True)
    ws.freeze_panes = "A2"
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[chr(64 + i)].width = w


def _fill(cell, colour):
    from openpyxl.styles import PatternFill, Font
    cell.fill = PatternFill("solid", fgColor=colour.lstrip("#"))
    cell.font = Font(color="FFFFFF", bold=True)


def write_brain_xlsx(d: dict, path: Path) -> Path:
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.title = "Shelves"
    _ap(ws, ["Shelf", "Kind", "Entity", "Confidential", "Nodes", "Edges", "Proposed", "CONFIRMED", "PROVISIONAL",
               "INDICATOR", "Memory entries", "Stale items"])
    for r in d["shelves"]:
        m = r.get("trust_mix", {})
        _ap(ws, [safe(r["shelf"]), safe(r["kind"]), safe(r["entity"]), "yes" if r["confidential"] else "no", r["nodes"], r["edges"],
                   r.get("proposed", 0), m.get("CONFIRMED", 0), m.get("PROVISIONAL", 0), m.get("INDICATOR", 0),
                   r["memory_entries"], r["stale_items"]])
    last = ws.max_row
    _ap(ws, ["TOTAL (formula)", "", "", "", *[Formula(f"=SUM({chr(64 + c)}2:{chr(64 + c)}{last})") for c in range(5, 13)]])
    from openpyxl.styles import Font
    for c in ws[ws.max_row]:
        c.font = Font(bold=True)
    _style(ws, [22, 14, 14, 13, 9, 9, 10, 12, 13, 11, 14, 12])
    for col, key in ((8, "CONFIRMED"), (9, "PROVISIONAL"), (10, "INDICATOR")):
        _fill(ws.cell(row=1, column=col), TRUST_COLOUR[key])

    g = wb.create_sheet("Guard")
    _ap(g, ["Severity", "Code", "Where", "Message"])
    for x in d["guard"]:
        _ap(g, [x["severity"], safe(x["code"]), safe(x.get("ref") or ""), safe(x["message"])])
        _fill(g.cell(row=g.max_row, column=1), SEV_COLOUR.get(x["severity"], "#555555"))
    if not d["guard"]:
        _ap(g, ["OK", "none", "", "No findings"])
    _style(g, [10, 30, 22, 100])

    s = wb.create_sheet("Stale")
    _ap(s, ["Shelf", "Item", "Label", "State", "Review by"])
    for i in d["stale"]:
        _ap(s, [safe(i["shelf"]), safe(i["id"]), safe(i["label"]), i["state"], safe(i.get("review_by") or "")])
        _fill(s.cell(row=s.max_row, column=4), SEV_COLOUR["ERROR"])
    _style(s, [18, 18, 60, 11, 12])

    m = wb.create_sheet("Memory")
    _ap(m, ["Shelf", "Outcome", "Count"])
    for x in d["memory"]:
        _ap(m, [safe(x["shelf"]), safe(x["outcome"]), x["count"]])
    _style(m, [22, 14, 8])
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)
    return path


def write_kg_xlsx(kg: dict, path: Path, gate: str = "draft") -> Path:
    """Working-paper workbook for one Knowledge Graph: Summary (COUNTIF formulas), Nodes, Edges, Validation."""
    from openpyxl import Workbook
    wb = Workbook()
    nodes = wb.active
    nodes.title = "Nodes"
    _ap(nodes, ["ID", "Type", "Label", "Entity", "Confidence", "Trust", "Evidence rank", "Status", "Origin",
                  "Source location", "Review by"])
    for n in kg.get("nodes", []):
        _ap(nodes, [safe(n.get("id")), safe(n.get("type")), safe(n.get("label")), safe(n.get("entity")), n.get("confidence"),
                      brain.trust_label(n), n.get("evidence_rank") or "UNRANKED", n.get("status", "CONFIRMED"),
                      safe(n.get("origin") or ""), safe(n.get("source_location")), safe(n.get("review_by") or "")])
        _fill(nodes.cell(row=nodes.max_row, column=6), TRUST_COLOUR[brain.trust_label(n)])
    _style(nodes, [16, 12, 48, 12, 11, 13, 13, 11, 14, 40, 12])
    edges = wb.create_sheet("Edges")
    _ap(edges, ["From", "To", "Relationship", "Confidence", "Indicator only", "Origin", "Evidence"])
    for e in kg.get("edges", []):
        _ap(edges, [safe(e.get("from")), safe(e.get("to")), safe(e.get("relationship")), e.get("confidence"),
                      "yes" if e.get("indicator_only") else "no", safe(e.get("origin") or ""), safe(e.get("evidence"))])
    _style(edges, [18, 18, 14, 11, 13, 14, 60])
    val = wb.create_sheet("Validation")
    _ap(val, ["Severity", "Code", "Where", "Message"])
    issues = ag.validate_kg(kg, gate)
    for i in issues:
        _ap(val, [i["severity"], i["code"], safe(i.get("ref") or ""), safe(i["message"])])
        _fill(val.cell(row=val.max_row, column=1), SEV_COLOUR.get(i["severity"], "#555555"))
    if not issues:
        _ap(val, ["OK", "none", "", f"No findings at the {gate} gate"])
    _style(val, [10, 24, 30, 100])
    summ = wb.create_sheet("Summary", 0)
    _ap(summ, ["Measure", "Value"])
    rows = [("Engagement", safe(kg.get("engagement", ""))), ("Gate", gate),
            ("Nodes", Formula("=COUNTA(Nodes!A:A)-1")), ("Edges", Formula("=COUNTA(Edges!A:A)-1")),
            ("Nodes at 100%", Formula('=COUNTIF(Nodes!E:E,"100%")')), ("Nodes at High", Formula('=COUNTIF(Nodes!E:E,"High")')),
            ("Nodes at Medium", Formula('=COUNTIF(Nodes!E:E,"Medium")')), ("Nodes at Low", Formula('=COUNTIF(Nodes!E:E,"Low")')),
            ("CONFIRMED", Formula('=COUNTIF(Nodes!F:F,"CONFIRMED")')), ("PROVISIONAL", Formula('=COUNTIF(Nodes!F:F,"PROVISIONAL")')),
            ("INDICATOR", Formula('=COUNTIF(Nodes!F:F,"INDICATOR")')), ("Unranked evidence", Formula('=COUNTIF(Nodes!G:G,"UNRANKED")')),
            ("Validation errors", Formula('=COUNTIF(Validation!A:A,"ERROR")')), ("Validation warnings", Formula('=COUNTIF(Validation!A:A,"WARN")'))]
    for r in rows:
        _ap(summ, list(r))
    _style(summ, [26, 60])
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)
    return path


def build_dashboard(lib: Path, out_dir: Path, today: str | None = None) -> dict:
    d = collect(lib, today)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    h = out_dir / "brain-dashboard.html"
    h.write_text(render_html(d), encoding="utf-8")
    x = write_brain_xlsx(d, out_dir / "brain-dashboard.xlsx")
    return {"html": str(h), "xlsx": str(x), "shelves": len(d["shelves"]),
            "guard_errors": sum(1 for g in d["guard"] if g["severity"] == "ERROR"), "stale_items": len(d["stale"])}
