# Project memory protocols

Contents: Session start - Six registers - Document intake - Compression and fact sheets - Improvement boundary - File and repository handling - Gap handling - Confidential matters

## Session start

On a multi-session engagement, before any new work:

1. Look for the engagement's memory (`PROJECT_MEMORY.md` or `project-memory.json`) and its lessons log in the engagement folder.
2. If present, read them fully and apply every recorded fact and rule from the first reply.
3. If absent, this is session one: create the skeleton from `project-memory-schema.md` and a lessons skeleton (`gia-core:self-learning`) before proceeding.

If a fact, question, assumption or decision is not written into the memory, treat it as not existing for the next session. Conversation history does not survive between sessions.

## Six registers

| Register | Holds |
|---|---|
| Confirmed Facts | Verified facts only: source, confidence, validator, date. Corrections add a dated entry and mark the old one superseded; nothing is overwritten. |
| Outstanding Questions | Every unresolved issue: priority, owner, dependency, evidence required. |
| Assumptions | Temporary assumptions: reason, risk if wrong, expiry, what would validate or invalidate. Anything that gains R1-R4 evidence is promoted to a Fact. |
| Decisions | Structural and methodological decisions: why, alternatives, impact, dependencies. Not audit conclusions; those belong in the findings pipeline. |
| Knowledge | What was learned, by domain. |
| Evidence | Every document, rated R1-R5 per `gia-core:iron-rules`, linked to the risk, control, finding, process or entity it supports. A verbal-only claim is an Assumption, never Evidence. |

Confidence on a fact or graph edge uses one scale: Very High (95-100), High (85-94), Moderate (70-84), Low (below 70), never above the evidence available. `scripts/kg_tools.py` stores four of these registers as JSON (facts, assumptions, decisions, evidence); the other two live in the Markdown form.

## Document intake (every new document)

1. Classify: what it is, owner, date and version.
2. Link: entity, process, risks, controls, regulations, audit, project.
3. Check supersession: what it replaces and what depends on the version it replaces.
4. Run `kg_tools.py check-integrity`; never leave a node unlinked.

An unclassified document is unknown until verified, not silently ignored.

## Compression and fact sheets

Context should not simply reset on a long engagement; compress it into reusable intelligence each session. When a register grows large, summarise resolved items into the Knowledge register and keep open items in the working registers. Before drafting from a large or re-opened source, extract a short fact sheet of named ground truth only (user corrections, annotations, raw source data, confirmed facts) and draft from that, not from the whole document and never from a prior AI narrative (`gia-core:iron-rules` rules 27 and 28).

## Improvement boundary

Taxonomy, templates, workflows, metadata and question sets may be improved on initiative. Without new evidence and a logged rationale, never change a confirmed fact, a legal conclusion, an approved governance structure, a control design, a policy, a regulatory mapping or an audit conclusion. Any such change is a new Decisions entry stating the new evidence, the rationale and every dependency affected. Silence is not permission.

## File and repository handling

1. Do not reorganise files blindly; understand the existing structure and its reason first.
2. Keep traceability from every new location back to the original.
3. Record every structural decision in the Decisions register.
4. Prefer a reusable taxonomy dimension to a one-off folder.
5. Design for several entities and countries.
6. Make documents findable by folder, metadata and relationship, for people and for retrieval.
7. Ask a focused question rather than guess when information is incomplete.

## Gap handling

- Critical gap (it would change a classification, a risk rating or a control or legal conclusion): stop and ask before producing anything containing it.
- Minor gap (a date or reference that changes no conclusion): proceed and mark it inline `[Pending confirmation: <item>]`. A marker must be resolved or escalated before a report goes final.

## Confidential matters

Fraud-indicative, conflict-of-interest, whistleblower and active-investigation material gets its own confidential graph or shelf with a distinct engagement name. Merging across engagements is refused for a confidential graph. Allegations carry status ALLEGED, are never shown at 100 percent confidence and never appear in a deliverable. Hand off to `gia-fraud` skills for chain of custody. The need-to-know and no-lookup-on-named-individuals rules in `gia-core:gcgo-router` apply.
