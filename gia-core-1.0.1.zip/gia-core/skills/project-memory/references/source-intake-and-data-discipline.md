# Source intake and data-layer discipline

Standing engineering and extraction discipline for any audit tool, dataset or register that holds engagement data. Ported from the retired data-guardian, command-centre, RAG-document, second-brain and file-catalog skills. Entity and engagement facts were dropped; only the method is kept.

## Contents
1. Single source of truth for master data
2. Embedded-data defects and fixes
3. Browser cache and local state
4. Consistency invariants
5. Dashboard app: tabs and import
6. Extraction fidelity: five-step method
7. Document-grounded mode
8. File catalog rules
9. Tooling lessons

## 1. Single source of truth for master data
- Master data lives in one set of data files (entities, engagements, risk register, RACM, entity risk profiles, audit plan). Every export, CSV, HTML app or summary is a derived copy.
- Never hand-edit data inside an embedded baseline. Edit the master files first, mirror any CSV or Markdown copies, then regenerate the embedded block from the masters.
- After a rebuild of a server-hosted app, tell the user to hard-refresh (see section 3).
- Reconcile the data layer with `gia-analytics:gia-data-reconciliation`.

## 2. Embedded-data defects and fixes
| Defect | Cause | Fix |
|---|---|---|
| Script block breaks or page corrupts | `</script`, `<script` or `<!--` inside a string value of embedded JSON | Neutralise those sequences (escape `<` or split the string) when serialising into a script block |
| JS syntax error from an apostrophe | Hand-quoted string literals | Serialise every string with a JSON serialiser, never by string concatenation |
| Panels render empty on load | Init code resets rich-text fields to blank | Populate each field from the data object on first render |
| Script silently dead | String search for a marker such as `</head>` matched the wrong occurrence | Locate the marker structurally, or rebuild from a template |
| Fields duplicate visually | Several data fields bundled into one blob while the template also renders each | Keep each field separate in the data model |
| Cross-engagement contamination | Example text or statutes from another engagement's template survived | Audit every finding and reference against its own engagement before release |
| Stale narrative after a count change | Downstream sentences, ratios and totals not recomputed | Treat any scope-number change as a trigger to recompute every dependent statement |
| Stale cached data hides new data | Rebuild fires only when the new set is larger | Rebuild on any length mismatch, and preserve user edits |

Standing recommendation: replace manual string-injection generation with a proper template, or at minimum a JSON-serialiser-escaped data block.

## 3. Browser cache and local state
- A normal refresh can keep serving a stale embedded baseline from a local static server. Always instruct a hard refresh (Ctrl+F5) or use a cache-busting query string after a rebuild. Opening the file directly is not affected.
- Day-to-day edits made in the app live in browser local storage as changes layered on the baseline, not in the HTML file. Before regenerating or overwriting the app file, warn the user to export a backup. A reset-to-baseline action or a browser profile change can lose unexported edits. Recommend exporting weekly and after any significant session.

## 4. Consistency invariants (check after any data change)
- Every risk ID used in a RACM row exists in the risk register; every linked risk in the plan resolves.
- Risk score = likelihood x impact, each 1 to 5; residual score is not above inherent score.
- Every engagement file location resolves to a real path.
- CSV and Markdown totals match their JSON masters.
- Counts asserted anywhere (entities, engagements, risks, controls, plan lines) agree everywhere; update all at once.

## 5. Dashboard app: tabs and import
Typical tabs: group dashboard (KPI cards, heat map, engagement status, action tracker); audit universe; annual plan; import engagement; cross-entity findings; group risk register with likelihood x impact scoring; audit committee reporting. Import is by pasting an exported engagement JSON; findings, actions, management responses and rates then populate. Audit committee outputs: quarterly report, findings and risk summary, plan status, management response summary, follow-up progress, risk register summary. The app is a presentation layer; the masters in section 1 stay authoritative. Reports for the Board go through `gia-report-qa:gia-board-brief`.

## 6. Extraction fidelity: five-step method
For any source that is not already a clean table (converted PDF checklist, scanned book, photographed form, messy export, recording).
1. Recognise the failure pattern before parsing: repeating headers mean page breaks bled in; shifting column positions mean map columns fresh at each header; mixed wrap granularity means a record spans physical rows; a field stated once then blank is not a record boundary, so find the field that restarts per item.
2. Build the smallest parser that could work, run it and count. A record count far from a rough manual estimate is itself a signal.
3. Diagnose the mechanism on one bad record before changing the algorithm.
4. Apply one named fix, then re-run and re-check cases that already worked.
5. Report completeness and limits every time: per-field fill rate, sections needing a fallback, genuine source gaps versus parsing limits.

Modality notes: for scanned or handwritten evidence, render the pages and inspect them; do not trust an OCR text layer for figures or alterations. Read images directly and say when resolution is too low. Do not assume speech-to-text exists; ask for a transcript or a connected transcription tool.

Disclosure checklist before presenting an extraction as final:
- [ ] Per-field completeness percentage (compute by counting filled fields per record)
- [ ] Record count with a one-line sanity check against a manual estimate
- [ ] Sections handled differently, named
- [ ] Source gaps separated from parsing limitations
- [ ] A one-paragraph method note that lets someone else reproduce the extraction
After extraction, hand off findings work to the audit skills; memory across sessions stays in this skill.

## 7. Document-grounded mode
When answering from uploaded documents (policy review, RCM or work-program drafting, gap analysis, minutes analysis, evidence mapping):
- Confirm the documents are for the right entity and period, and that no superseded version is used.
- Ground every statement only in the loaded documents. Where they are silent, say so; do not fill from memory.
- Grade evidence R1 to R4 and never rely on R5 (`gia-core:iron-rules`).
- Label each output line: Current design, Recommendation, or Gap (document silent).
- Control assessments use deficiency types CD, SD and MW from `gia-core:iron-rules`.

## 8. File catalog rules
A catalog scan classifies files by entity, workstream, document type, status and priority and raises alerts: version confusion, stale draft, missing final, engagement without a final, duplicate, unconfirmed owner.
- Scope first: the session sees only uploaded files, or folders explicitly connected. Do not imply a scan reached folders it did not.
- Owner is never guessed from a path or filename; any inferred field is marked as inferred and the marker kept in summaries.
- Never move, rename or delete a file; remediation is the CAE's decision.
- An unrecognised engagement ID is flagged, not reclassified or dropped.
- Lead with alerts (critical, warning, info), not a file-by-file dump.
- Catalog files hold workpaper paths; keep them in the engagement working folder.

## 9. Tooling lessons
- Paths with spaces can break some file integrations; copy to a space-free path and retry.
- A file locked by Excel or Word cannot be overwritten; save a new minor version.
- A chat response has an output cap; write long reports to disk.
- A plugin install into a read-only directory can fail with a misleading error; use a writable plugins directory.
- If a file shows unexplained corruption after incremental edits, rebuild it from scratch.
