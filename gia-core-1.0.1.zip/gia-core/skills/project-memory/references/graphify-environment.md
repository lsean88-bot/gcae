# graphify environment notes

Result of running the `graphify-8` test suite on a clean Ubuntu 24 / Python 3.12 sandbox:
first run **22 failed**, after provisioning **4,903 passed, 78 skipped, 0 failed**. No graphify source change
was required: every failure was a provisioning gap. `scripts/bootstrap_env.sh` closes all of them.

| # | Symptom | Root cause | Fix |
|---|---|---|---|
| 1 | graphify's `test_terraform` test fails | optional `tree-sitter-hcl` not installed | `pip install "tree-sitter-hcl>=1.2.0"` |
| 2 | graphify's `test_ollama_retry_cap` test fails | `openai`/`tiktoken` not installed | `pip install openai tiktoken` |
| 3 | `test_install_references.py` wheel test | `build` missing, then `setuptools` < 77 | `pip install build wheel "setuptools>=77"` |
| 4 | graphify's `test_skillgen` test (≈18 tests) | needs pinned baseline commit blobs via `git show`; an unpacked zip has no git history | `git init`, add upstream remote, `git fetch --depth=1 origin <SHA>` for each SHA in `tools/skillgen/gen.py` |

| 5 | `pip install mcp` fails: `Cannot uninstall PyJWT ... RECORD file not found` | Debian/Ubuntu own PyJWT | `pip install --ignore-installed PyJWT "mcp>=1,<3" "starlette>=1.3.1,<2"` (`bootstrap_env.sh --with-mcp` does this) |

Operational notes
- Needs network access to `github.com` for #4. Offline machines will see skillgen failures; that is expected.
- `bash_tool`-style sandboxes may run `/bin/sh` (dash): no `{a,b}` brace expansion, no `time`, no `<( )`.
  Use `bash -c '...'` for those. A brace-expanded `mkdir` there silently creates a literal directory named `{a,b}`.
- graphify's no-LLM `update` command rebuilds code (AST) only; docs/PDFs need `/graphify` (semantic pass by Claude).
- MCP verified end to end (real client handshake): `graphify.serve` exposes 10 tools. Results carry graphify's labels, not the
  brain's trust labels, so use `brain.py recall` for reliance decisions and MCP for exploration.
- graphify's backend auto-detect order is gemini > kimi > claude > openai > deepseek > azure > bedrock > ollama. Pass `--backend` explicitly.
