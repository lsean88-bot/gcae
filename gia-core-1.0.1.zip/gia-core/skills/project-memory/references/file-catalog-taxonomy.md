# File catalog taxonomy

Ported from the retired file-catalog skill (both copies). Entity codes are not repeated here: they live in `config/entities.json` and the router registry. The scanner scripts are not carried (see `gia-core/MIGRATION.md`, Port disposition).

## Contents
1. Workstream codes
2. Document type codes
3. Status lifecycle
4. Priority matrix
5. Identifier conventions

## 1. Workstream codes
| Code | Workstream | Typical files |
|---|---|---|
| AUD | Audit | Workpapers, fieldwork, testing |
| RISK | Risk | Risk registers, heat maps |
| CTRL | Control and ICFR | RACM, control testing, deficiencies |
| FRAUD | Fraud and investigation | Whistleblower matters, digit analysis |
| GOV | Governance | Committee packs, Board papers, charters, SOPs |
| HR | HR and payroll | Statutory contributions, payroll audits |
| TAX | Tax | Indirect tax, e-invoicing |

## 2. Document type codes
WP workpaper; FDG finding; RPT report; SOP procedure; ACP committee or Board pack; RACM risk and control matrix; EVI evidence; MGT management response; FUP follow-up or closure; TPL template.

## 3. Status lifecycle
Draft, Review, Final, Archived; Superseded when a newer version replaces a file. A file matching no status keyword is Reference (background, prior-year or attachment) and is not forced into the lifecycle.

## 4. Priority matrix
| Priority | Assigned when |
|---|---|
| Critical | Path or name cites a committee or Board meeting, a regulator, or urgency |
| High | Set by judgement, not keyword: an alert (stale draft, missing final) sits on an engagement closing soon |
| Medium | Default for anything still in Draft |
| Low | Default for Review, Final or Reference material with no other signal |

## 5. Identifier conventions
Engagement IDs follow the form `GIA-<ENTITY>-<CODE>-<YYYY>-<MON>-<SEQ>`; SOPs use `SOP-<AREA>-<ENTITY>-<YYYY>-<SEQ>`. A scan extracts an ID found in a filename and never generates one; files with no embedded ID are flagged, not numbered. A catalog row ID (CAT-0001, in scan order) is internal to the catalog and resets on rescan. An unrecognised engagement ID is flagged as unrecognised, not reclassified.
