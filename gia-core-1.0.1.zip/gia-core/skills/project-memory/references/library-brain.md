# The Library Brain: how graphify memory and a knowledge base fit AKOS

## Contents
- 1. What graphify gives you (verified in the graphify-8 source, not assumed)
- 2. Why "just run graphify on everything" is not a library brain for audit
- 3. The shelf model
- 4. The trust ladder every recall result carries
- 5. The loop (what "learning" means here)
- 5b. Retrieval you can trust (v1.2)
- 5c. Dual-format output
- 6. Deliberately not wired (and how to add later)
- 7. Where Claude's own memory fits
- 8. Integrity: audit trail, seals, anchors (v2.0)


Read this to understand *why* each piece exists. Commands are in `SKILL.md`; code is `scripts/brain.py`.

## 1. What graphify gives you (verified in the graphify-8 source, not assumed)

| graphify feature | What it really is | Trust level for audit |
|---|---|---|
| `graph.json` (extract / update) | Entities and relationships found in files. Code via AST (free); documents via a semantic pass by an LLM | Structure is reliable; *relationships between ideas* are model judgement |
| `save-result` → `memory/*.md` | Saves a question, the answer and an outcome (`useful` / `dead_end` / `corrected`). The notes are re-read into the graph on the next update | **Indicator only.** A saved answer is a model's output, not evidence |
| `reflect` → `LESSONS.md` + `.graphify_learning.json` | Aggregates saved outcomes with time-decay and a corroboration threshold into "which sources helped". Kept in a *sidecar*; graphify says it never writes learning fields into the graph | Experience about *retrieval*, never about facts |
| `global add` → `~/.graphify/global-graph.json` | One merged graph across projects | **Dangerous for audit unless filtered**: it would mix confidential investigations with routine work |
| `serve` (MCP) | Lets Claude query a graph live: query, node, neighbours, path, god-nodes | Safe if it serves only non-confidential shelves |
| `wiki`, `watch`, git hooks, `check-update` | Agent-readable wiki export, auto-rebuild on change, stale-semantic detection | Useful, optional; not wired by default (see section 6) |
| `GRAPHIFY_QUERY_LOG` | Plaintext log of questions and paths, opt-in | Keep OFF for confidential work |

## 2. Why "just run graphify on everything" is not a library brain for audit

Four audit-specific hazards, each handled by a specific control in this skill:

1. **A saved answer becomes its own evidence.** graphify re-extracts `memory/` notes into the graph. Next week an AI answer looks like a source document. Control: nodes from `graphify-out/memory/` are capped at `Low`, `indicator_only`, and can never reach a deliverable (`MEMORY_AS_EVIDENCE`).
2. **Confidential investigations leak into a shared index.** Control: investigation shelves are always `confidential`; the global graph is built only from non-confidential shelves; `brain.py guard` fails if one ever appears there; a confidential shelf can only be recalled alone.
3. **Documents silently leave the approved boundary.** graphify's backend auto-detect order is gemini → kimi → claude → openai → deepseek. A stray `GEMINI_API_KEY` wins even if an Anthropic key exists. Control: `guard` asks graphify which backend it *would* pick and errors if it is not on the allowed list (default: claude, claude-cli, ollama).
4. **Statutory facts go stale.** A brain that confidently returns last year's minimum wage is worse than none. Control: statutory shelves carry `review_by` dates; recall labels items `STALE` / `UNDATED`; `stale --strict` can gate a schedule.

## 3. The shelf model

```
library/
  brain.json                     policy: allowed backends, confidential-never-in-global, query log off
  shelves/<shelf>/
     shelf.json                  kind: engagement | statutory | policy | investigation | reference ; entity ; confidential
     KNOWLEDGE_GRAPH.json        AKOS-owned facts for this shelf
     graphify-out/               graph.json, memory/, reflections/LESSONS.md   (derived, rebuildable)
     memory_index.json           which saved answers helped, dead-ended, or were corrected
  index/global/                  derived graph over NON-confidential shelves, ids namespaced "shelf::ID"
  lessons/PROPOSED_LESSONS.md    candidates only. The owner promotes (AKOS Module 7)
```

Suggested shelves for MKTron (names are yours to choose): one `statutory` shelf per jurisdiction (e.g. Tamil Nadu,
Maharashtra, Malaysia), one `engagement` shelf per audit, one `policy` shelf for Group policies and the Iron
Rules, one `reference` shelf for frameworks (IIA, COSO), and one `investigation` shelf per live fraud matter.

## 4. The trust ladder every recall result carries

| Label | Meaning | May it go in a Board paper? |
|---|---|---|
| `CONFIRMED` | confidence 100% or High, not proposed, not memory-derived | Yes, via `deliverable`, with its evidence |
| `PROVISIONAL` | Medium | Only after validation |
| `INDICATOR` | Low, PROPOSED, ALLEGED, graph-inferred, or from saved memory | **No.** It tells you where to look |
| `STALE` / `UNDATED` (flag) | statutory item past `review_by`, or never dated | Re-validate against the portal (R1) first |

Retrieval score only ranks; the label decides reliance.

## 5. The loop (what "learning" means here)

```
documents ─ graphify extract ─▶ graph.json ─ from-graphify ─▶ PROPOSED items
      ▲                                                          │ classify + evidence (human / domain skill)
      │                                                          ▼
   reflect ◀─ remember ◀─ recall ◀─ index ◀──────────── KNOWLEDGE_GRAPH.json (confirmed)
      │
      └─▶ PROPOSED_LESSONS.md ─▶ owner accepts ─▶ LESSONS_LEARNED.md (engagement) / iron-rules (portfolio, needs go-ahead)
```

The brain gets better at *finding* (which sources help, which questions dead-end) without ever getting more
*certain* on its own. Certainty only increases when a human attaches evidence.

## 5b. Retrieval you can trust (v1.2)

- **Script-aware.** Latin accents are folded (`Nómina` equals `nomina`, so it no longer matches "mina"), Tamil words stay whole,
  Chinese text is matched on character pairs. Before this, Tamil and Chinese items could never be found.
- **Synonyms are explicit, editable and visible.** `synonyms.json` holds groups such as payroll / nómina / gaji or EPF / provident
  fund. A query that mentions one phrase also searches the others at half weight, and `expanded_terms` shows exactly what was added.
  A wrong entry degrades results, so review it like any other controlled list.
- **Evidence ranks matter.** A node may carry `evidence_rank` R1-R5 (your hierarchy). R4 (management-prepared, unverified) is shown
  PROVISIONAL and R5 (verbal) INDICATOR regardless of the stated confidence; `validate` warns when 100% rests on R4/R5.
- **Dates fail safe.** Only `YYYY-MM-DD` is accepted. Anything else is `BAD_DATE`, treated like stale, never like fresh.
- **File modes.** Shared shelves are readable by the team (0644); confidential shelves are owner-only (0700/0600) and `guard` warns if that drifts.

## 5c. Dual-format output

`brain.py dashboard <lib> --out <dir>` writes an interactive-friendly HTML dashboard (colour-coded trust mix, guard findings,
statutory freshness, memory outcomes; light and dark) and an Excel workbook with live total formulas. `akos_graph.py export-xlsx`
produces a working-paper workbook for one Knowledge Graph (Summary via COUNTIF formulas, Nodes, Edges, Validation). Labels come
from documents, so HTML is escaped and any cell starting with `=`, `+`, `-` or `@` is neutralised to stop Excel formula injection.

## 6. Deliberately not wired (and how to add later)

- **Git hooks / `watch`:** fine for non-confidential shelves that live in a repo. Skipped by default because most
  audit folders are not repos and a background rebuild can surprise you. Add with `graphify hook install` per repo.
- **`graphify wiki` / Obsidian export:** a readable index for people or agents to crawl. Add per shelf once a shelf is stable.
- **`global add`:** do not use for this library. `brain.py index` replaces it because it knows about confidentiality.
- **MCP:** `brain.py mcp-config` prints the config. Requires `pip install "graphifyy[mcp]"`.

## 7. Where Claude's own memory fits

Claude's platform memory holds *how you like to work* (formats, evidence ranking, slash commands). The library holds
*what the organisation knows* (facts, documents, relationships). Keep client and entity facts out of personal memory.


## 8. Integrity: audit trail, seals, anchors (v2.0)

- **Audit trail.** Every change made through the tool (init, shelf-add, index, remember, reflect, seal, index recovery) appends a line to
  `audit.log`; each line carries the SHA-256 of the one before. Edit, delete, reorder or insert in the middle of the log and the chain breaks at that line.
- **Seal.** A human attests a shelf's current content with a reason; the tool snapshots it. `changes` then lists exactly what differs, and flags
  a confidence raised (with the evidence rank now attached), a status changed, an edge or node removed. Editing the Knowledge Graph by hand is normal
  (that is how facts get classified); a seal turns "someone changed something" into "this specific confidence went from Medium to 100% on R5 evidence".
- **Anchor.** The chain proves internal consistency; it cannot prove the *whole* log wasn't replaced. Record the `audit_head` printed by `seal` somewhere
  outside the library and pass it to `verify --anchor`: a truncated or rewritten log cannot reproduce an older head.
- **Confidential shelves.** Nothing derived from their content (answer file names, seal reasons, lessons) enters the shared log; it stays in the shelf, owner-only.
- **Limits worth knowing.** Locks are advisory; the audit log's own file permissions protect it only as well as the file system does; retrieval remains lexical
  (accent- and script-aware, with synonyms and optional IDF), not semantic.
