# Enterprise Project Memory (EPM) — Field Templates & Schema

Read this when actually creating or updating a `PROJECT_MEMORY.md` / `.json` file for
an engagement. SKILL.md Module 4 gives the summary; this file gives the exact fields.

## Table of Contents
1. Storage convention
2. Confirmed Facts register
3. Outstanding Questions register
4. Assumptions register
5. Decisions register
6. Knowledge register
7. Evidence register
8. JSON schema (machine-readable form)

---

## 1. Storage Convention

- One `PROJECT_MEMORY.md` per engagement, saved in the engagement's own working
  folder (not a global file shared across unrelated engagements).
- Optionally mirror it as `PROJECT_MEMORY.json` for programmatic queries — same
  fields, structured form (Section 8).
- **Append, never overwrite.** When a fact changes, add a new row with a new date and
  mark the old row `Superseded` — don't delete history.
- Update at the end of every work session, and immediately whenever something is
  confirmed, resolved, or decided (don't batch it up and risk forgetting).

---

## 2. Confirmed Facts Register

| Field | Description |
|---|---|
| Entity/Subject | What the fact is about |
| Fact | The verified statement itself, stated plainly |
| Status | Confirmed / Superseded |
| Evidence | Specific document/system/portal that supports it |
| Confidence | 100% / High / Medium (see Module 10 — Low facts don't belong here) |
| Validated By | Which specialist lens or person confirmed it |
| Date Verified | ISO date |

Example row:

```
Entity: MK Tron Auto Parts Pvt Ltd (MKAPL)
Fact: Registered office is in Chennai, Tamil Nadu; manufacturing across JD/ST/DC divisions
Status: Confirmed
Evidence: Organisation Chart v4
Confidence: 100%
Validated By: Knowledge Architect
Date Verified: 2026-07-17
```

---

## 3. Outstanding Questions Register

| Field | Description |
|---|---|
| Question | The unresolved issue, phrased so anyone could act on it |
| Priority | High / Medium / Low |
| Owner | Who needs to answer or resolve it |
| Dependency | What's blocked until this resolves |
| Required Evidence | What would resolve it |
| Status | Open / Resolved / Deferred |

---

## 4. Assumptions Register

| Field | Description |
|---|---|
| Assumption | The temporary working assumption |
| Reason | Why it was necessary to assume rather than confirm |
| Risk | What happens if the assumption is wrong |
| Confidence | Medium / Low (assumptions are never 100%/High by definition) |
| Expiry | When this must be validated or replaced by fact |
| Validation Required | What evidence would confirm or reject it |

---

## 5. Decisions Register

| Field | Description |
|---|---|
| Decision | The structural/methodological choice made |
| Why | Rationale |
| Alternatives Considered | What else was on the table |
| Impacts | What this decision changes downstream |
| Dependencies | What relies on this decision holding |
| Date | ISO date |
| Decided By | Person or specialist lens |

Use this register for every taxonomy choice, naming standard, scope boundary, or
methodology selection — not just "big" governance decisions. Per Module 11, any
change to a confirmed fact, policy, control design, or audit conclusion is itself a
Decisions Register entry.

---

## 6. Knowledge Register

Organise by domain, not chronologically — this is where resolved/settled learning
accumulates so the working registers above stay small and current:

Business · Audit · Finance · Operations · Manufacturing · IT · Compliance ·
Governance · Healthcare · Engineering

| Field | Description |
|---|---|
| Domain | One of the categories above |
| Topic | Short label |
| Knowledge | What was learned, stated plainly |
| Source | Evidence or engagement it came from |
| Reusability | Would this apply to another entity/engagement? |

---

## 7. Evidence Register

| Field | Description |
|---|---|
| Evidence ID | Short stable identifier |
| Type | Document / Screenshot / Email / Report / Policy / SOP / Audit Report / Minutes / ERP Export / Invoice / Contract |
| Description | What it is |
| Original Location | File path or system source — never lose this |
| Linked To | Risk / Control / Finding / Process / Entity it supports |
| R-Rank | R1 (primary/gazette) through R5 (verbal — never cited in findings) — see the evidence hierarchy in `gia-core:iron-rules` |

---

## 8. JSON Schema (Machine-Readable Form)

```json
{
  "engagement": "string",
  "last_updated": "ISO-8601 date",
  "confirmed_facts": [
    {
      "entity": "string",
      "fact": "string",
      "status": "Confirmed|Superseded",
      "evidence": "string",
      "confidence": "100%|High|Medium",
      "validated_by": "string",
      "date_verified": "ISO-8601 date",
      "supersedes_id": "string|null"
    }
  ],
  "outstanding_questions": [
    {
      "question": "string",
      "priority": "High|Medium|Low",
      "owner": "string",
      "dependency": "string",
      "required_evidence": "string",
      "status": "Open|Resolved|Deferred"
    }
  ],
  "assumptions": [
    {
      "assumption": "string",
      "reason": "string",
      "risk": "string",
      "confidence": "Medium|Low",
      "expiry": "string",
      "validation_required": "string"
    }
  ],
  "decisions": [
    {
      "decision": "string",
      "why": "string",
      "alternatives_considered": ["string"],
      "impacts": "string",
      "dependencies": "string",
      "date": "ISO-8601 date",
      "decided_by": "string"
    }
  ],
  "knowledge": [
    {
      "domain": "Business|Audit|Finance|Operations|Manufacturing|IT|Compliance|Governance|Healthcare|Engineering",
      "topic": "string",
      "knowledge": "string",
      "source": "string",
      "reusability": "string"
    }
  ],
  "evidence": [
    {
      "evidence_id": "string",
      "type": "string",
      "description": "string",
      "original_location": "string",
      "linked_to": ["string"],
      "r_rank": "R1|R2|R3|R4|R5"
    }
  ]
}
```
