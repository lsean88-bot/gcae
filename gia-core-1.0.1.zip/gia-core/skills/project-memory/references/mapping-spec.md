# Mapping specification: AKOS ⇄ graphify

Single source of truth for `scripts/akos_graph.py`. Change a rule here and in the code together,
then re-run `pytest tests/`. The round-trip tests are the contract.

## 1. Node mapping

| AKOS field | graphify field | Notes |
|---|---|---|
| `id` | `akos_id` (original) and `id` (slug) | slug = lowercase `[a-z0-9_]`; collisions after slugging are refused |
| `label` | `label` = `[AKOS-ID] label` | prefix lets `graphify path/explain/query` find nodes by AKOS id; stripped on return |
| `type` | `akos_type`, plus `file_type` | graphify allows only six `file_type` values |
| `entity` | `entity` | carried verbatim |
| `created_date` | `created_date` | |
| `confidence` | `akos_confidence` | |
| `source_location` | `source_file` | AKOS "source_location" is a document path/URL; graphify's `source_location` is a line anchor. Not the same thing. |
| `status`, `engagement`, `evidence_rank`, `review_by`, `valid_from`, `shelf`, `shelf_kind`, `origin`, `indicator_only` | same | optional, carried through so they survive indexing |

`file_type`: Document, Evidence, Policy, Procedure, Regulation, Folder, Meeting → `document`;
Decision → `rationale`; everything else → `concept`.

## 2. Edge mapping

| AKOS | graphify |
|---|---|
| `from`, `to` | `source`, `target` **and** `akos_from`, `akos_to` (graphify persists an undirected graph) |
| `relationship` | `relation` (verbatim: all 15 AKOS verbs pass through) |
| `evidence` | `evidence` |
| `confidence` | `akos_confidence`, plus derived `confidence` / `confidence_score` below |
| `indicator_only` | `indicator_only` |

### Confidence, AKOS → graphify (display only)

| AKOS | graphify `confidence` | score |
|---|---|---|
| 100%, High | EXTRACTED | 1.0 |
| Medium | INFERRED | 0.75 |
| Low | AMBIGUOUS | 0.2 |

graphify therefore shows `[EXTRACTED]` for both 100% and High edges. `akos_confidence` is the truth.

### Confidence, graphify → AKOS (staging; never inflates)

| graphify | AKOS | indicator_only |
|---|---|---|
| EXTRACTED | **High** (never 100%) | no |
| INFERRED, score ≥ 0.75 | Medium | yes |
| INFERRED, score < 0.75 | Low | yes |
| AMBIGUOUS | Low | yes |

If the edge already carries `akos_confidence` (it came from an AKOS export), that value is restored unchanged.

### Relation vocabulary, graphify → AKOS (original kept in `original_relation`)

calls→uses · imports→depends_on · contains→contains · references→references · cites→references ·
implements→implements · inherits→depends_on · method→contains · uses→uses ·
rationale_for / shares_data_with / semantically_similar_to / conceptually_related_to → relates_to

## 3. Staging rules for native graphify nodes (no `akos_*` attributes)

- id: `GFY-<GRAPHIFY-ID-UPPER>` (truncated to 60 chars)
- type: `Document` if graphify `file_type` is document/paper/image, else `UNCLASSIFIED`
- entity: from the user-supplied `--entity-map` (path substring match), else `UNCLASSIFIED`
- confidence `Medium`, status `PROPOSED`, origin `graphify`
- Existing KG nodes are never overwritten. Disagreements are reported under `conflicts`.

## 4. Validation codes

ERROR always: NODE_FIELD_MISSING, EDGE_FIELD_MISSING, DUPLICATE_ID, DANGLING_EDGE, TYPE_INVALID,
REL_INVALID, CONF_INVALID, CONF_ELEVATED, EVIDENCE_REQUIRED, INDICATOR_AS_EVIDENCE,
ALLEGED_AS_CONFIRMED, CONFIDENTIAL_LEAK.

WARN in draft, ERROR in final: ORPHAN_NODE, TYPE_UNCLASSIFIED, ENTITY_UNCLASSIFIED, ENTITY_UNKNOWN.

Final gate only: STATUS_NOT_FINAL (PROPOSED/RETRACTED), LOW_IN_FINAL (ERROR), MEDIUM_IN_FINAL (WARN).

WARN always: NEAR_DUPLICATE (accent/script-aware), SELF_LOOP, DATE_FORMAT (review_by / valid_from not YYYY-MM-DD),
CONF_VS_RANK (100% resting on R4/R5 evidence).

ERROR always (added v1.2): RANK_INVALID (evidence_rank not R1-R5), MEMORY_AS_EVIDENCE.

## 5. Known limits

- graphify's deterministic (no-LLM) pass on markdown yields document structure only. Risk/control/finding
  relationships need the semantic pass.
- `from-graphify` cannot know your folder → entity convention; it asks rather than guesses.
- No cryptographic evidence integrity. Chain-of-custody stays with `group-cae-fraud-v2`.
