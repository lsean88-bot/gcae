# Document-grounded mode: rules, labels and record formats

Ported from the retired RAG document-intelligence skill. Complements section 7 of `source-intake-and-data-discipline.md`. The retired dashboard, its JSON export and import hub, and its model-configuration tab are not carried.

## Contents
1. Document library record
2. Answer labels and citation
3. Query types
4. Grounding rules (DG-01 to DG-09)
5. Response protocol

## 1. Document library record
| # | Document name | Type (R1 to R4) | Date | Status | Relevance | Gap note |
|---|---|---|---|---|---|---|
Status is Active, Superseded, Missing or Pending. Record the entity, source and scope relevance of each document. Evidence ranks follow `gia-core:iron-rules`.

## 2. Answer labels and citation
Every answer cites document name, section or page, and document date. Every statement carries one label:
- `[From your documents]`: directly sourced.
- `[General best practice, not in your documents]`: supplementary, never presented as sourced.
- `[Gap: documents are silent on this point]`: no source exists.
- `[Conflict: document versions differ]`: documents contradict; name both.
Output lines about design carry: Current design, Recommendation, or Gap (document silent).

## 3. Query types
Factual (a threshold in a policy); control (what controls exist for a process); compliance (does a procedure meet a cited requirement); gap (what is missing against a customer or regulatory requirement); comparison (this policy against its prior version).

## 4. Grounding rules
| ID | Rule |
|---|---|
| DG-01 | Loaded documents are the only source of grounded answers |
| DG-02 | Every answer cites document, section or page, and date |
| DG-03 | Where no loaded document addresses the query, say so; any filler carries the best-practice label |
| DG-04 | Tag superseded documents as such; never cite one as current |
| DG-05 | Verbal or unverified content (R5) is never added to the library as evidence |
| DG-06 | Control matrices and work programs drafted from documents are drafts for CAE review |
| DG-07 | Internal-control assessments are grounded: each component conclusion cites a document |
| DG-08 | Policy-gap outputs are draft findings and pass the 12-item quality gate before release |
| DG-09 | Evidence-sufficiency assessments are advisory; the CAE confirms before the report |

## 5. Response protocol
1. Pre-check: right entity and period, current versions, evidence ranks, no memory fill.
2. Document check: confirm relevant documents are loaded and flag gaps.
3. Scope: is the query answerable from what is loaded?
4. Draft the answer from the documents only, with citations.
5. Label every statement (section 2).
6. State confidence, driven by evidence quality.
7. Route the output: findings to `gia-audit:gia-fieldwork-workpapers`, control matrices to `gia-audit:gia-racm-icfr-testing`.
