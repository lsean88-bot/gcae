# Node & Relationship Catalogue

Reference only — read when deciding how to classify a new node or edge. The `type`
field is free text in the schema (nothing enforces this list at write time), but stay
inside it unless there's a genuine new category, so cross-engagement graphs stay
comparable.

## Node types

| Type | Examples |
|---|---|
| Document | Policy PDF, SOP, audit report, email, contract, invoice, minutes |
| Entity | MK Autoparts Pvt Ltd, MKSDL, Erawan LMW, Nephrocare Management |
| Process | Procure-to-pay, order-to-cash, payroll, contract labour onboarding |
| Risk | A named inherent or residual risk |
| Control | A named control (preventive/detective, manual/automated) |
| Policy | Group policy, SOP, delegation of authority |
| Regulation | A specific Act/Section/Standard (e.g., CLRA 1970, IIA GIAS Standard 15) |
| Finding | A raised audit finding (mirror of the Module 13 findings pipeline entry) |
| Recommendation | A SMART recommendation tied to a Finding |
| Project | An engagement or workstream |
| Plant / Country | A physical site or jurisdiction |
| System | SAP B1, HRMS, banking portal |
| Vendor / Customer | Third parties relevant to a process |
| Employee / Role | Referenced by role, not name, where the person is not the user's
  direct report — avoid storing personal data unnecessarily |
| Committee | Audit Committee, Board, ExCo |
| Decision | Mirrors a `project-memory.json` decision entry, if it needs graph links |
| Evidence | Mirrors a `project-memory.json` evidence entry, if it needs graph links |

## Relationship verbs (keep to one verb/verb-phrase per edge)

`owns` · `uses` · `implements` · `supports` · `mitigates` · `affects` · `tested_by` ·
`references` · `reported_in` · `supersedes` · `depends_on` · `employs` · `reports_to` ·
`governs` · `applies_to` · `located_in` · `contains` · `escalated_to`

## Worked examples

```
Policy —supports→ Control —mitigates→ Risk —affects→ Financial Statement Assertion
    —tested_by→ Audit Programme —references→ Working Papers —reported_in→ Audit Report
```

```
Entity —owns→ Process —uses→ System —contains→ Configuration —implements→ Control
    —tested_by→ ToD/ToE Finding
```

## Document-arrival checklist (expand of SKILL.md's intake protocol)

For every new document, resolve and record:
what it is · who owns it · which process · which entity · which country · which
risk(s) · which control(s) · which audit/project · which regulation · which SOP ·
which prior document(s) it relates to · what it supersedes · what depends on it.

If any of these can't be resolved yet, log it as an open item rather than guessing —
an unresolved link is honest; a fabricated one is an Article 12/13 violation.
