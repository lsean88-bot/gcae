# EPM-KG File Schemas

## Contents
- `project-memory.json`
- `knowledge-graph.json`
- Invariants `check-integrity` enforces


Read this file when you need exact field names — not by default. `scripts/kg_tools.py`
handles reading/writing these correctly; hand-edit only if the script can't do what you
need, and re-run `check-integrity` immediately after.

## `project-memory.json`

```json
{
  "schema_version": "1.0",
  "engagement": "<free text — entity/engagement name>",
  "confirmed_facts": [
    {
      "id": "F-0001",
      "text": "...",
      "evidence_id": "E-0001",
      "confidence": "Very High | High | Moderate | Low",
      "confidence_basis": "one line, per Article 23",
      "date_confirmed": "YYYY-MM-DD",
      "superseded_by": null,
      "status": "active | superseded"
    }
  ],
  "assumptions": [
    {
      "id": "A-0001",
      "text": "...",
      "risk_if_wrong": "...",
      "confidence": "Very High | High | Moderate | Low",
      "expiry_condition": "...",
      "validation_required": "...",
      "date_logged": "YYYY-MM-DD",
      "status": "open | validated | invalidated | expired"
    }
  ],
  "decisions": [
    {
      "id": "D-0001",
      "text": "...",
      "rationale": "...",
      "alternatives_considered": "...",
      "affects": ["node ids or free text"],
      "date": "YYYY-MM-DD",
      "decided_by": "..."
    }
  ],
  "evidence": [
    {
      "id": "E-0001",
      "description": "...",
      "rank": "R1 | R2 | R3 | R4 | R5",
      "source": "file name / portal URL / doc ref",
      "linked_nodes": ["node ids"],
      "date_obtained": "YYYY-MM-DD"
    }
  ],
  "prompt_evolution": [
    {
      "id": "P-0001",
      "target": "which SKILL.md / prompt",
      "problem_addressed": "...",
      "expected_benefit": "...",
      "regression_risk": "...",
      "validation_status": "pending | validated | rejected",
      "date": "YYYY-MM-DD",
      "retired": false
    }
  ],
  "template_evolution": [
    {
      "id": "T-0001",
      "target": "which template",
      "change": "...",
      "reason": "...",
      "date": "YYYY-MM-DD",
      "retired": false
    }
  ]
}
```

## `knowledge-graph.json`

```json
{
  "schema_version": "1.0",
  "nodes": [
    {
      "id": "N-0001",
      "type": "Document | Entity | Process | Risk | Control | Policy | Regulation | Finding | Recommendation | Project | Plant | Country | System | Vendor | Employee | Role | Committee | Decision | Evidence",
      "name": "...",
      "attributes": { "any": "free-form key-value pairs specific to this node type" },
      "date_added": "YYYY-MM-DD"
    }
  ],
  "edges": [
    {
      "id": "R-0001",
      "from": "node id",
      "relationship": "owns | uses | implements | supports | mitigates | affects | tested_by | references | reported_in | supersedes | depends_on | ... (free text verb, keep it a single lowercase verb or verb phrase)",
      "to": "node id",
      "confidence": "Very High | High | Moderate | Low",
      "source": "evidence id or free text",
      "date_added": "YYYY-MM-DD"
    }
  ]
}
```

## Invariants `check-integrity` enforces

1. Every `edges[].from` and `edges[].to` must reference an existing `nodes[].id`
   (no broken references)
2. No two nodes may share the same `type` + `name` (no duplicates — merge instead)
3. Every node should appear in at least one edge (no orphans) — informational warning,
   not a hard failure, since a brand-new node may be legitimately unlinked for one turn
4. Every `assumptions[]` with `status: "open"` is checked against its `expiry_condition`
   text at snapshot time and flagged if it looks stale
