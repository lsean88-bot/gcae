---
name: project-memory
description: "Persistent engagement memory and knowledge graph: registers of facts, assumptions, decisions and evidence, typed graph links, document intake, confidential recall. Use when an engagement spans sessions, entities or many documents, when starting or resuming one, or logging a fact or decision. Do NOT use for one-session tasks, lessons (use gia-core:self-learning)."
---

# Project Memory and Knowledge Graph

State lives in files in the engagement folder, not in the conversation. This skill is the memory substrate; it has no audit methodology (that is `gia-audit:gia-audit-lifecycle`) and no router (that is `gia-core:gcgo-router`).

## When to use it

Use it when the engagement crosses any of: more than one entity or jurisdiction, many sessions, more documents than you can track without re-reading, several contributors. For one session and one entity, skip it; the overhead does not earn its keep.

## Session start

Read the engagement memory and lessons log before any new work; create them if this is session one. Update the memory immediately after a fact is confirmed, a question resolved or a decision made. Details: `references/protocols.md`.

## Registers and graph

- Registers: Confirmed Facts, Outstanding Questions, Assumptions, Decisions, Knowledge, Evidence. Never overwrite a confirmed fact; supersede it with a dated entry. Evidence is rated R1-R5 under `gia-core:iron-rules`; a verbal claim is an assumption.
- Graph: documents, entities, processes, risks, controls, policies, regulations, findings, people as nodes with typed edges. Every new document gets classified, linked and checked for supersession before anything else.
- Never autonomously change a fact, conclusion, control design, policy or regulatory mapping; that needs new evidence and a Decisions entry.

## Tools

1. `scripts/kg_tools.py` (stdlib only): `init`, `add-fact`, `add-assumption`, `add-decision`, `add-evidence`, `add-node`, `add-edge`, `check-integrity`, `snapshot`. It writes `project-memory.json` and `knowledge-graph.json`. Prefer it to hand-editing JSON; hand edits are how orphans and duplicates appear. Run `check-integrity` before treating the graph as reliable for a Board or Audit Committee deliverable.
2. Library brain: `scripts/brain.py` and `scripts/akos_graph.py` keep shelves (engagement, statutory, policy, investigation, reference), each with its own `KNOWLEDGE_GRAPH.json`. `brain.py recall` returns ranked nodes with a trust label (CONFIRMED, PROVISIONAL, INDICATOR), source, evidence rank and a STALE flag. Report the label with every item and never present an INDICATOR as a finding. `remember` logs whether an answer helped; `guard` checks confidentiality before anything is shared. The commands and flags are in `references/library-brain.md`.
3. Entity codes are in `config/entities.json`. The brain will not invent a code.

## Confidential matters

Investigation shelves are always confidential and recalled on their own. A confidential graph never merges with another engagement. ALLEGED items are never shown at 100 percent confidence or in a deliverable. See `references/protocols.md`.

## Honest limits

- A file-based pattern read and updated each turn by sequential reasoning; it is not a live database and not always-on agents.
- The brain's graph extraction and indexing need the external `graphify` package. It is not bundled; without it indexing does not run and the related tests are skipped, not passed (see `tests/` and `references/graphify-environment.md`).
- `kg_tools.py` JSON and the brain's `KNOWLEDGE_GRAPH.json` are two designs for one idea; they are not yet unified. Entity codes in `config/entities.json` mix the router codes with older ones; reconcile before relying on cross-tool queries.
- The recall trust label depends on the quality of what was ingested.

## References

- `references/protocols.md`: session start, registers, intake, improvement boundary, file handling, gaps, confidentiality.
- `references/project-memory-schema.md`: Markdown and JSON field templates for the six registers.
- `references/kg-schema.md` and `references/node-relationship-catalogue.md`: the `kg_tools.py` schema and node and edge types.
- `references/knowledge-graph-schema.md`: the fuller graph schema used by the brain.
- `references/library-brain.md`, `references/mapping-spec.md`, `references/graphify-environment.md`: the library brain.
- `references/document-grounded-rules.md`: answer labels, citation, grounding rules DG-01 to DG-09, record format.
- `references/file-catalog-taxonomy.md`: workstream, document type, status and priority codes, identifier conventions.
- `references/source-intake-and-data-discipline.md`: single source of truth, embedded-data defects, cache and local-state warnings, consistency invariants, extraction method and disclosure checklist, document-grounded mode, file-catalog rules.
