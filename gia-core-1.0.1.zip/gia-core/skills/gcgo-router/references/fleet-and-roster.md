# Fleet, specialist roster and where each ask goes

Contents: 1. Which orchestration model · 2. Fleet agents · 3. Specialist roster by domain · 4. Where each kind of ask goes · 5. Sequencing a standard engagement · 6. Independent QA mandate

This replaces the old routing tables (portfolio roster, fleet dispatch, master router, persona orchestrator). It records the routing content only; the methodology lives in the specialist skills.

## 1. Which orchestration model

| The work is | Use | Because |
|---|---|---|
| A single-thread engagement where one actor stays throughout | `gia-audit:gia-audit-lifecycle` alone | No need for subagents or a memory layer |
| Multi-entity or multi-session, facts and decisions must persist and stay linked | `gia-core:project-memory` | Persistent registers and graph, not task splitting |
| Genuinely parallel, independent workstreams where isolated context matters | gia-core fleet agents | Only real subagents give isolated context |

These are not mutually exclusive. A large multi-entity engagement can use all three: memory across the engagement, fleet agents for independent fieldwork streams, the engine for single-thread days. Say at the start which you invoke and why.

## 2. Fleet agents (gia-core `agents/`)

Eleven specialists, each pinned to a Sonnet or Haiku model with an effort note (Rule 32). The planner-tier model never executes through them without the CAE's approval.

| Agent | Reach for it when you need | Do not use it for |
|---|---|---|
| alpha-scout | A scan of regulatory changes, enforcement actions or industry incidents for a named entity and jurisdiction | Drafting a risk rating or finding |
| beta-analyst | Quantitative testing on a named dataset: Benford, duplicates, reconciliation, outliers | Fraud conclusions: it flags, others decide |
| gamma-mapper | Turning a walkthrough or process narrative into a process map and RACM | Testing whether a control works |
| delta-validator | Checking that a drafted finding's evidence is sufficient before it goes in a report (read-only) | Writing the finding |
| epsilon-strategist | Turning validated findings into Board, Audit Committee or regulator narrative | Validating evidence |
| zeta-remediator | Logging findings, reviewing action plans against root cause, checking closure evidence | Deciding whether a finding is valid |
| eta-compliance | A sourced answer to whether a law applies and what it requires | Anything outside a compliance question |
| theta-simulator | A what-if model with stated assumptions and sensitivity | Inputs that cannot be named: it says so rather than guessing |
| iota-kaizen | A quality-gate check before finalising a report, or a closure retrospective (read-only) | Producing new findings |
| kappa-linguist | Extracting specific facts from contracts, emails or minutes at volume | Conclusions about intent |
| lambda-cyber | ITGC design and evidence review, or reading an existing scan or SOC report | Active scans or exploit code, always out of scope |

If two agents conflict, show both outputs and the conflict to the CAE. Escalation points are in `references/operating-protocol.md`.

## 3. Specialist roster by domain

| Domain | Owner | Fleet support |
|---|---|---|
| Methodology, internal audit lifecycle | `gia-audit:gia-audit-lifecycle` | gamma-mapper |
| Controls, ICFR, ITGC | `gia-audit:gia-racm-icfr-testing` | lambda-cyber, delta-validator |
| Fraud and forensic | `gia-fraud:gia-fraud-investigation` and the other gia-fraud skills | beta-analyst, delta-validator |
| Statutory and jurisdiction | `gia-audit:gia-pack-india`, `gia-pack-malaysia`, `gia-pack-mexico`; dated register via `gia-audit:gias-navigator` | eta-compliance, alpha-scout |
| Financial analysis and cost accounting | `gia-analytics:gia-cost-accounting` | beta-analyst |
| Business performance | `gia-analytics:gia-performance-analytics` | beta-analyst, theta-simulator |
| Payroll and overtime analytics | `gia-analytics:gia-payroll-analytics` | beta-analyst |
| Reporting and Board material | `gia-report-qa:gia-ia-report`, `gia-board-brief`, `gia-presentation` | epsilon-strategist |
| Independent QA and challenge | `gia-report-qa:gia-report-qa`; `gia-core:skill-hygiene` portfolio challenger | delta-validator, iota-kaizen |
| Self-learning | `gia-core:self-learning` | iota-kaizen |

## 4. Where each kind of ask goes

| The ask is about | Route |
|---|---|
| Identity, tone, report structure, recommendation format | `gia-report-qa:gia-ia-report` (format) and `gia-core:iron-rules` (policy) |
| What a framework requires (COSO, GIAS) | `gia-audit:gias-navigator` |
| Running fieldwork: walkthrough, requests, sampling, findings pipeline | `gia-audit:gia-fieldwork-workpapers` |
| ToD and ToE, deficiency classification, RACM design | `gia-audit:gia-racm-icfr-testing` |
| Fraud allegation triage, ACFE Fraud Tree, anti-bribery, whistleblower handling | `gia-fraud:gia-fraud-investigation` |
| A named entity or jurisdiction | The matching pack in gia-audit |
| Entity facts, plan operation, master data | `gia-core:project-memory` and `gia-audit:gia-engagement-planning` |
| Board, Audit Committee or Chairman communication | `gia-report-qa:gia-board-brief` |
| Is this actually confirmed | `gia-core:iron-rules` evidence hierarchy, then `gia-report-qa:gia-evidence-trace` |

## 5. Sequencing a standard engagement

1. alpha-scout during planning informs risk focus.
2. gamma-mapper during walkthrough produces the process map and RACM.
3. beta-analyst, eta-compliance and lambda-cyber during fieldwork, as scope requires.
4. Draft findings on the engine.
5. delta-validator checks evidence sufficiency before a finding is final.
6. iota-kaizen runs the quality gate before the report is final.
7. epsilon-strategist writes the Board or Audit Committee narrative.
8. zeta-remediator tracks to closure, then iota-kaizen runs the retrospective.

Not every engagement needs every agent. Independent workstreams run in parallel; sequence only where one deliverable depends on another.

## 6. Independent QA mandate

No deliverable of consequence (a report, a skill retirement or consolidation, a new module) goes final without an independent challenge pass on a different agent from the preparer. Use delta-validator and iota-kaizen where real subagents exist; otherwise run a separate explicit review pass. The pass is mandatory because a false completion claim can stand unchallenged for weeks when it is skipped.
