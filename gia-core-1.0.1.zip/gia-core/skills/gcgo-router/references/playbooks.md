# Playbooks (generated from capability-registry.json; edit the registry, not this file)

Contents: P00 Unscoped request; P01 New engagement; P02 Fieldwork and evidence testing; P03 Fraud, conflict-of-interest or misconduct matter; P04 Findings to final report; P05 Board / Audit Committee pack; P06 External submission (regulator, external auditor, lender, investor); P07 Follow-up, chasers and closure; P08 Continuous monitoring and scheduled routines; P09 Regulatory / statutory change; P10 Vendor / counterparty review; P11 Data analytics and reconciliation; P12 Function governance and quality (charter, aspiration, QAIP); P13 File governance and cataloguing; P14 ICFR / RACM / SOX-style control testing; P15 Payroll, overtime, claims and HR compliance; P16 IT general controls and cyber; P17 Skill library and routing maintenance; P18 Report conversion into the official template; P19 Engagement status and handoff; P20 Contradictory or inconsistent evidence; P21 Entity-scoped review; P22 Contract or agreement review (legal skills, not audit method)

## P00: Unscoped request: stop and scope before any drafting

1. `gia-core:gcgo-router`: Do not go from documents to a report. Restate the request, propose Mode 0 or 1, and ask for entity, period, objective, criteria and approved findings
   - GATE: the CAE answers the scoping questions
2. `gia-audit:gia-fieldwork-workpapers` mode 0-1: Scope lock and evidence register before any analysis
   - GATE: Scope lock approved (the CAE)
3. `{entity_skills}` (optional): Criteria knowledge once entity and jurisdiction are known

## P01: New engagement: accept, scope-lock, set up

1. `gia-audit:gia-engagement-planning`: Check the engagement fits the annual plan and the Audit Charter authority
   - GATE: Fits plan/charter? (the CAE)
2. `gia-audit:gia-engagement-planning`: Mandate and independence check, Terms of Engagement, strategy posture, DRL and project charter
   - GATE: Independence confirmed; TOE approved (the CAE)
3. `gia-audit:gia-fieldwork-workpapers` mode 0: Scope lock, engagement control sheet, folder tree and registers
   - GATE: Scope lock approved (the CAE)
4. `{entity_skills}`: Load entity and jurisdiction criteria knowledge for the scope
5. `gia-core:project-memory` (optional): Only if multi-session or multi-entity: initialise project memory and graph

## P02: Fieldwork and evidence testing

1. `gia-audit:gia-fieldwork-workpapers` mode 1: Evidence register and criteria register, facts only
   - GATE: Gate A: scope, criteria, evidence register, population completeness, sampling plan (the CAE)
2. `{engine}`: Walkthrough, ToD and ToE structure for the named procedure
3. `gia-audit:gia-fieldwork-workpapers` (optional): Detailed walkthrough, ToD, ToE, sampling and reconciliation-test steps (v6 does not carry this detail)
4. `gia-audit:gia-fieldwork-workpapers` (optional): Fieldwork panels, AI analysis (Benford, variance), learning engine, workpaper export
5. `{entity_skills}`: Entity and jurisdiction criteria and typical control points
6. `gia-analytics:gia-data-reconciliation` (optional): Clean raw extracts first, with before/after reconciliation
7. `gia-core:gcgo-router` (optional) [subagent]: Delegate independent workstreams (mapping, analytics, compliance, ITGC) to isolated subagents
8. `gia-audit:gia-fieldwork-workpapers` mode 3-4: Sample per approved method; test one procedure at a time
   - GATE: Item-level results only; no conclusions
9. `gia-audit:gia-fieldwork-workpapers` mode 5: Exception, contradiction and gap registers; management questions
   - GATE: Gate B: the CAE classifies each exception reportable / not / more evidence

## P03: Fraud, conflict-of-interest or misconduct matter  [CONFIDENTIAL]

1. `gia-core:gcgo-router`: Confidentiality gate: need-to-know list, no web or personal-data lookups on named individuals without approval, evidence preservation first
   - GATE: the CAE approves whether and how to open the matter
2. `gia-fraud:gia-fraud-investigation`: Fraud triangle, allegation triage, CFE protocol, red flags, interview and chain-of-custody planning
3. `gia-audit:gia-fieldwork-workpapers` mode 1,5: Evidence register and exception/contradiction/gap registers; allegation wording stays blocked until approved
   - GATE: No classification of fraud or misconduct without the CAE
4. `{entity_skills}` (optional): Entity/jurisdiction criteria and typical fraud schemes for the area under review
5. `gia-fraud:gia-fraud-entity-watch` (optional): If a vendor or related party is named: structured third-party red-flag review
6. `gia-core:gcgo-router` (optional) [subagent]: beta-analyst (Benford, duplicates) and kappa-linguist (document facts) in isolated context
7. `gia-core:gcgo-router`: Escalation path, counsel and HR involvement are the CAE's decisions; GCGO lists the options and who must be told
   - GATE: Escalation decision (the CAE)

## P04: Findings to final report

1. `gia-audit:gia-fieldwork-workpapers` mode 5-6: Finding gate and locked finding sheets from approved exceptions only
   - GATE: Gate C: finding sheets approved and locked (the CAE)
2. `{engine}`: Findings pipeline and the 12-item Quality Gate (Rule 09)
3. `{entity_skills}` (optional): Check criteria citations against the entity/jurisdiction baseline
4. `gia-report-qa:gia-ia-report`: Report structure and narrative (standard concise IA report plus Excel working paper)
5. `gia-report-qa:gia-board-brief` (optional): Translate to Chairman/AC language where the audience is the Board
6. `gia-report-qa:gia-ia-report` (optional): Migrate approved content into the official HTML IAR template without altering it
7. `gia-audit:gia-fieldwork-workpapers` mode 8: QA log plus gia-report-qa qa_scan.py (--audience director for Board material)
   - GATE: Gate D: QA cleared; release approval (the CAE)

## P05: Board / Audit Committee pack

1. `gia-report-qa:gia-board-brief`: Business-value framing for Chairman, AC and directors
2. `gia-report-qa:gia-ia-report`: AC paper structure and templates
3. `pptx` (optional): Deck, if a presentation is requested
4. `gia-analytics:gia-continuous-assurance` (optional): AC dashboard, audit universe and follow-up status
5. `gia-audit:gia-fieldwork-workpapers` mode 7-8: Two-layer director report; traceability to workpapers; qa_scan.py --audience director
   - GATE: Release approval (the CAE)

## P06: External submission (regulator, external auditor, lender, investor)  [EXTERNAL]

1. `gia-audit:gia-fieldwork-workpapers` mode 8: Evidence trace and no-drift check on the draft
   - GATE: the CAE confirms every statement is supported
2. `gia-report-qa:gia-external-release`: Zero-artefact final document with localised statutory terms
3. `legal:compliance-check` (optional): Applicable-approvals check where regulatory content is involved
   - GATE: Legal review (counsel), not Claude
4. `gia-core:gcgo-router`: Hold: nothing is sent or filed by Claude
   - GATE: the CAE signs off and sends

## P07: Follow-up, chasers and closure

1. `gia-analytics:gia-continuous-assurance`: Management response tracker and follow-up audit (GIAS Standard 15)
2. `gia-core:gcgo-router` (optional) [subagent]: zeta-remediator: action-plan vs root-cause and closure-evidence review
3. `gia-fraud:gia-fraud-risk-governance`: Draft chaser / escalation memo / AC notification on the escalation ladder
   - GATE: Draft only; the CAE confirms before anything is sent
4. `gia-analytics:gia-continuous-assurance` (optional): Turn recurring chasers into Cowork scheduled tasks
5. `gia-audit:gia-fieldwork-workpapers` mode 4-5: Closure evidence is evidence: tested, not accepted on assertion

## P08: Continuous monitoring and scheduled routines

1. `gia-analytics:gia-continuous-assurance`: KRI thresholds, licence/agreement expiry watchlists, alert triage
2. `gia-analytics:gia-continuous-assurance`: Scheduled task configuration (runs without an open session)
3. `gia-fraud:gia-fraud-risk-governance` (optional): Escalation drafts when an alert needs a formal response
   - GATE: Draft only

## P09: Regulatory / statutory change

1. `gia-audit:gias-navigator`: Read the dated register first: what is already known, how strong the source is, and how old it is
2. `web_search`: Verify current law and rates from official sources; do not rely on skill text for anything that may have changed
3. `{entity_skills}`: Compare against the skill's baseline and flag what is stale
4. `gia-core:gcgo-router` (optional) [subagent]: alpha-scout (change scan) and eta-compliance (does it apply)
5. `gia-analytics:gia-continuous-assurance` (optional): Add dated items to the watchlist

## P10: Vendor / counterparty review

1. `gia-fraud:gia-fraud-entity-watch`: Due diligence, red flags, ongoing monitoring
2. `gia-analytics:gia-performance-analytics`: Routes financial-health research and dashboards to the right tool
3. `bigdata-com:bigdata-company-brief` (optional): Public-company counterparties: recent developments and risk (bigdata-com family)
4. `gia-core:gcgo-router`: Caution: no web scraping of named individuals or personal data without approval
   - GATE: the CAE approves any external data gathering on people

## P11: Data analytics and reconciliation

1. `gia-analytics:gia-data-reconciliation`: Clean and standardise exports with control totals
2. `data:analyze` (optional): Analysis; data:statistical-analysis for outlier and distribution work
3. `finance:reconciliation` (optional): GL-to-subledger, bank and intercompany reconciliations
4. `xlsx`: Working-paper workbook with live formulas
5. `data:validate-data` (optional): QA the analysis before it is relied on
6. `gia-audit:gia-fieldwork-workpapers` mode 4: Results recorded item-level; analytics flag, auditor concludes

## P12: Function governance and quality (charter, aspiration, QAIP)

1. `gia-audit:gia-engagement-planning`: Aspiration, Audit Charter, QAIP
2. `gia-audit:gia-engagement-planning`: Standard 8 conformance self-assessment, including the tooling portfolio
3. `gia-core:gcgo-router`: Registry health check as evidence for the QAIP toolkit-currency question

## P13: File governance and cataloguing

1. `gia-audit:gia-fieldwork-workpapers`: Scan and classify files by entity, engagement ID, period, status
2. `gia-audit:gia-fieldwork-workpapers`: Stale drafts, duplicates, version confusion, engagements with no final
3. `gia-audit:gia-fieldwork-workpapers` (optional): Gap register and stakeholder follow-ups

## P14: ICFR / RACM / SOX-style control testing

1. `gia-audit:gia-racm-icfr-testing`: RACM lifecycle: scoping, key controls, ToD/ToE, deficiency classification
2. `finance:sox-testing` (optional): Sample selection and testing workpapers
3. `finance:audit-support` (optional): Control testing methodology and deficiency classification
4. `gia-analytics:gia-data-reconciliation`: Check any received RACM or model workbook for spreadsheet risk before relying on it
5. `gia-audit:gia-fieldwork-workpapers` mode 4-5: Deficiency evaluation stays with the CAE; Claude records results and gaps
   - GATE: Deficiency classification (the CAE)

## P15: Payroll, overtime, claims and HR compliance

1. `gia-audit:gias-navigator`: Freshness gate: build the dated rate table with sources, run check_rates.py, fix HIGH findings before any recompute (installed India payroll skills may state a stale EPF ceiling)
   - GATE: Rate table sourced and verified (the CAE)
2. `gia-analytics:gia-payroll-analytics`: Hire-to-retire, OT, claims, DoA, ghost-employee analytics across entities
3. `{juris_hr_skills}`: Statutory baseline for the jurisdiction (Malaysia, TN, MH, Mexico)
4. `gia-fraud:gia-fraud-investigation` (optional): Overlay only if payroll fraud indicators arise
5. `gia-audit:gia-fieldwork-workpapers` mode 4-5: Statutory rates and thresholds must be verified as current before use
   - GATE: Rates verified against official source

## P16: IT general controls and cyber

1. `gia-audit:gia-racm-icfr-testing`: ITGC (access, change, backup) and Cybersecurity Topical Requirement
2. `gia-core:gcgo-router` (optional) [subagent]: lambda-cyber: control design and evidence review (never active scanning)
3. `gia-audit:gia-fieldwork-workpapers` mode 4-5: Results, exceptions and gaps

## P17: Skill library and routing maintenance

1. `gia-core:gcgo-router`: Run library_inventory.py; list drift, duplicates, dangling references; propose registry edits
   - GATE: the CAE approves any archive, rename or edit
2. `gia-core:skill-hygiene` (optional): Create or improve a skill (description length, triggers, tests)
3. `gia-core:self-learning` (optional): Log lessons; propose CLAUDE.md rule promotion
4. `gia-core:self-learning` (optional): Any code change to scripts or plugins: plan first, verify, log

## P18: Report conversion into the official template

1. `gia-report-qa:gia-ia-report`: Content migration into the approved HTML template with exception log and change log
2. `gia-report-qa:gia-ia-report` (optional): Blank IAR template v8.2 (cited by the library but not installed; ask the CAE for the file)
3. `gia-audit:gia-fieldwork-workpapers` mode 8: No-drift check: converted text must match approved text; change ledger for any difference; qa_scan.py
   - GATE: Release approval (the CAE)

## P19: Engagement status and handoff

1. `gia-core:gcgo-router`: Run engagement_status.py on the engagement folder; report counts, items waiting on the CAE, gates that look ready, next actions; write the handoff note
   - GATE: the CAE confirms any gate that 'looks ready'

## P20: Contradictory or inconsistent evidence

1. `gia-audit:gia-fieldwork-workpapers` mode 5: Preserve both sources unaltered with IDs; state the conflict neutrally; classify; assess reliability of each; log a CE item; say what can and cannot be concluded
   - GATE: the CAE decides how to corroborate or accept as a limitation
2. `gia-analytics:gia-data-reconciliation` (optional): If either source is a workbook: check it for hardcodes, broken links and hidden sheets before relying on it
3. `{entity_skills}` (optional): Entity/jurisdiction knowledge on what the correct record should look like

## P21: Entity-scoped review: scope first, then load the right specialists

1. `gia-core:gcgo-router`: The request names an entity, jurisdiction or area but no stage. Ask the one question that matters: is this planning (Mode 0-2), testing with evidence in hand (Mode 3-5) or reporting (Mode 6-8)?
   - GATE: the CAE names the stage and objective
2. `{entity_skills}`: Load entity and jurisdiction criteria knowledge for the scope
3. `gia-audit:gia-fieldwork-workpapers` mode 0-1: Scope lock, criteria register and evidence register before any analysis
   - GATE: Scope lock approved (the CAE)

## P22: Contract or agreement review (legal skills, not audit method)

1. `legal:review-contract`: Clause-by-clause review against the negotiation playbook, deviations and redlines
2. `legal:triage-nda` (optional): If the document is an NDA: green/yellow/red triage
3. `gia-core:gcgo-router`: Claude is not a lawyer: legal conclusions and any binding position go to counsel; confirm whether this is audit evidence (then handle under gia-audit:gia-fieldwork-workpapers) or a legal review
   - GATE: Counsel review for any legal conclusion

