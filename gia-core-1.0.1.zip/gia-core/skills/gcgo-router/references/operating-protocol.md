# GCGO operating protocol

Contents: 1. Intake questions · 2. Work Requirement Profile template · 3. Delegation brief · 4. Reviewing a return · 5. Handling conflicts · 6. Handoff note · 7. Session routines · 8. Escalation and stop conditions · 9. Worked routing examples

## 1. Intake: ask the fewest questions that change the route

Infer first. Ask only when the answer would change which skills run or who decides. One question at a time, and offer a default.

Questions, in order of how often they change the route:
1. Is there evidence in hand, or is this planning? (decides whether `gia-audit:gia-fieldwork-workpapers` mode work applies)
2. Which entity, and for India, which plant or state?
3. Who is the audience: audit team, management, Audit Committee/Board, regulator or external auditor?
4. What is the deliverable and by when?
5. Is anything confidential or already escalated?

Never ask for information the registers, CLAUDE.md or the uploaded files already contain.

## 2. Work Requirement Profile (WRP)

```
Request (one line):
Outcome and audience:
Entity / jurisdiction / period:
Lifecycle stage:
Evidence in hand vs conclusion requested:
Risk flags: confidential | external | legal interpretation | personal data | irreversible action | rating/conclusion
Intents matched / playbooks:
Conductor and why:
Methodology engine (one):
Governors on:
Specialists:
Subagents (if available):
Tools:
Gates for the CAE:
Assumptions I made (to be corrected):
```

## 3. Delegation brief

Every handoff to a skill, subagent or parallel workstream carries all of this. Under-specified delegation is the usual cause of drift; a subagent that asks for missing context is telling you the brief was incomplete.

```xml
<delegation_brief>
  <objective>One sentence outcome.</objective>
  <engagement ref="[REF]" entity="[ ]" period="[ ]" mode="[0-8]" procedure="[PROC-###]"/>
  <scope_lock>In scope / out of scope as approved.</scope_lock>
  <sources>Evidence IDs, criteria IDs, approved finding IDs. Nothing else is evidence.</sources>
  <allowed>Exact permitted actions.</allowed>
  <prohibited>No ratings, causes, fraud or legal conclusions, scope changes, or external lookups on named people unless stated.</prohibited>
  <return>Format, with references and labels; what to flag; what questions to raise.</return>
  <stop_rule>If the task would exceed approved evidence, scope or mode, stop and report.</stop_rule>
</delegation_brief>
```

## 4. Reviewing a return

Before anything reaches the CAE:
- Does it address the objective and return format?
- Does every material statement carry an ID, and does the ID exist?
- Are facts, representations, hypotheses and gaps labelled?
- Does it stay inside scope, mode and sources?
- Does it contradict another return or an approved finding?
- Does any wording go beyond the evidence? (`gia-report-qa:gia-report-qa` scripts/qa_scan.py for drafts)
- Is anything marked "rating", "root cause", "fraud" without the CAE's approval?

If it fails: send back once with the specific defect. If it fails again, take the task back and tell the CAE why. If the failure came from the brief, fix the brief and log it with `gia-core:self-learning`.

## 5. Handling conflicts

1. State the conflict neutrally with both sources.
2. Classify: fact conflict, threshold or rate conflict, method conflict, version conflict, scope conflict.
3. Do not pick. For a statutory rate or threshold, offer to verify against an official source with web search and let the CAE accept the result.
4. Log it (contradiction register for engagement evidence; registry notes for skill-versus-skill conflicts).
5. Continue other work that does not depend on it.

## 6. Handoff note (end of session or between workstreams)

```
Engagement / stage:
Done since last note:
Decisions the CAE made (with date):
Waiting on the CAE:
Blocked on evidence or access:
Next actions, who does them:
Open conflicts / contradictions:
Registry or CLAUDE.md changes proposed:
```

Keep it to one screen. The point is that a new session can resume without rereading the transcript.

## 7. Session routines

- Start: engagement and stage? engagement instruction file? what was waiting on the CAE last time? run `engagement_status.py` if a folder exists.
- During: restate scope before each stage; stop at gates; keep the running status.
- End: handoff note; log lessons; propose registry or CLAUDE.md edits; list drift found.
- Monthly: `library_inventory.py --registry`; review lessons; archive decisions (the CAE's); update the registry.

## 8. Escalation and stop conditions

Stop and ask the CAE when: scope, criteria or sample must change; evidence is incomplete, contradictory or out of period; a legal, tax, HR, safety, privacy, fraud or conflict-of-interest conclusion is implied; a High or Critical rating may be needed; external distribution is requested; two specialists disagree on substance; a matter looks like an independence or conflict issue for the audit function itself; a confidential matter would require involving more people than the CAE has approved.

## 9. Worked routing examples

**"Start the MKAPL Pune stamping audit, delegate the data forensics, and get it board-ready."**
Three workstreams: P01 (set-up), P11 (analytics), P05 (board pack). Conductor: fleet (if subagents available), else GCGO in-thread. Entity skill: `gia-audit:gia-pack-india` (Maharashtra); `gia-audit:gia-pack-india` and `gia-analytics:gia-payroll-analytics` as support. Order: P01 first (gates: plan fit, independence/TOE, scope lock), then analytics under Mode 3-4, board pack last and only from approved findings. Board-ready is the end state, not the first step.

**"We received a whistleblower allegation about a vendor at MKPC."**
P03, confidential. First step is a decision, not work: the CAE approves whether and how to open the matter; need-to-know list; preserve evidence. Then `gia-fraud:gia-fraud-investigation`, `gia-audit:gia-fieldwork-workpapers` Mode 1 and 5, `vendor-third-party-risk` if a vendor is named. No lookups on named individuals without approval; no allegation wording until the CAE approves.

**"Audit these documents and prepare the report for the board."**
P00, unscoped. Do not go from documents to a report. Ask for entity, period, objective, criteria and approved findings; propose Mode 0 or 1.

**"What changed in EPF and SOCSO rates this year?"**
P09 then P15. Web search against official sources first; compare with the skill's baseline; flag what is stale; add dated items to the watchlist.

**"Draft chasers for overdue actions and schedule them weekly."**
P07. `enforcement-escalation` drafts; `automated-action-engine` schedules; nothing is sent without the CAE.

**"Which skill should I use for a vendor financial health check?"**
P10: `vendor-third-party-risk`, `financial-monitoring-reporting` (routes to bigdata-com for public counterparties). The routing answer is the plan itself.
