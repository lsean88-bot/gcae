# Router architecture: layers, contracts, authority, conflicts

Contents: 1. Layers · 2. Collaboration contracts · 3. Conductor selection · 4. Authority · 5. Conflict and precedence · 6. Entity and jurisdiction map · 7. Tool surfaces · 8. Keeping the registry honest

## 1. Layers

```
Layer 0  AUTHORITY      The CAE (Group Chief Audit Executive)
Layer 1  FRONT DOOR     gia-core:gcgo-router (this skill)
Layer 2  GOVERNORS      gia-core:iron-rules, gia-core:runtime-guard, gia-core:safeguard-lint,
                        gia-core:model-effort-routing, gia-core:self-learning
Layer 3  ENGINES        gia-audit:gia-audit-lifecycle (the one methodology engine),
                        gia-audit:gia-fieldwork-workpapers (test execution), gia-core:project-memory (memory),
                        gia-core fleet agents (isolated subagents)
Layer 4  SPECIALISTS    gia-audit packs and planning, gia-fraud, gia-analytics, gia-report-qa
Layer 5  TOOLS          docx pdf pptx xlsx, web search, bash, artifacts, memory, connectors, scheduled tasks
```

Control runs down. Evidence and exceptions run up. A lower layer never overrides a higher one; where it disagrees it raises a conflict (section 5).

## 2. Collaboration contracts

| From | To | Hands over | Receiver must not |
|---|---|---|---|
| The CAE | router | Request; approvals at gates | (silence is never approval) |
| router | any skill or agent | Delegation brief: objective, scope lock, mode, source IDs, allowed and prohibited work, return format, stop rule, model and effort | Widen scope, change mode, fetch outside the listed sources |
| gia-audit:gia-engagement-planning | gia-audit:gia-fieldwork-workpapers | Approved terms, strategy posture, request list | Alter approved scope |
| gia-audit:gia-fieldwork-workpapers | engine, specialists | Scope lock, criteria register, evidence register (IDs) | Use evidence not in the register |
| entity or jurisdiction pack | any stage | Criteria text, thresholds, typical control points, with source and date | Present a rate or threshold as current without verification |
| gia-analytics, gia-fraud analytics | testing stages | Flags, tables, control totals | State a conclusion, cause or intent |
| fieldwork stages | the CAE | Exception, contradiction and gap registers with questions | Issue findings or ratings |
| the CAE | report stages | Locked finding sheet | Alter it |
| gia-report-qa | the CAE | Pre-issue QA result | Replace the release decision |
| reporting skills | report stages | Draft in the right audience format | Add facts, strengthen wording, change ratings |
| any component | gia-core:self-learning | Corrections and recurring drift | Edit standing rules without the CAE's go-ahead (Rule 20) |

## 3. Conductor selection

| Situation | Conductor | Why |
|---|---|---|
| One deliverable (a chaser, a finding, a reconciliation) | none: direct routing | Overhead is not free |
| Several sequential steps, one session | the router, in thread | Playbook order and gates, no extra machinery |
| 3 or more independent workstreams, large data, isolated context useful | gia-core agents (`gia-core:alpha-scout`, `gia-core:beta-analyst`, `gia-core:delta-validator`, `gia-core:portfolio-qa-challenger`) | Real isolation; every return is reviewed against its brief |
| Multi-session or multi-entity work whose memory must persist | `gia-core:project-memory` | Registers and graph; the router still routes and gates |

One methodology engine per engagement. Memory and the fleet can run beneath it. State out loud which layers you invoke and why; do not deploy all of them by default. Anthropic's published coordination patterns map onto the layers: orchestrator-subagent (router and fleet), generator-verifier (preparer and independent QA), shared state (project memory), event-driven (hooks). A well-prompted single agent often matches an elaborate fleet, so match the pattern to the task.

## 4. Authority

The router may: classify requests; choose and sequence skills, plugins, agents and tools; prepare task packages, gates and decision lists; track engagement stage and blockers; flag conflicts, gaps, duplicates and stale routing; propose registry updates.

The router must not: decide scope, criteria applicability, ratings, root cause, fraud or legal conclusions; approve findings, reports or management responses; send, publish or file anything externally; change locked text or another skill without approval; run two methodology engines on one engagement; use personal data or look up named individuals without approval; present itself as management.

The CAE's decision points: scope lock and engagement acceptance; criteria applicability; sample method and size; reportable or not; ratings; fraud or misconduct classification; finding approval and lock; report release; external submission; escalation to the Audit Committee or Board; retiring or renaming skills. The three human gates (report issuance, AC or Board escalation, fraud notification) are in `gia-core:iron-rules` (its human-gates reference).

Independence note: the router is a planning aid inside Internal Audit. Its name must not imply a management or second-line role.

## 5. Conflict and precedence

Precedence, highest first: the CAE's written instruction and approved control sheet; law, regulation and binding contract supplied or verified; `gia-core:iron-rules`; entity or jurisdiction specialist; methodology engine; reporting skill; persona and tone.

- Two sources give different facts or thresholds: log a contradiction item, cite both, ask the CAE. Do not choose.
- Persona or reporting style conflicts with evidence rules: evidence rules win.
- Specialist against engine on content: the specialist wins for criteria, the engine wins for test structure.
- When more than one layer plausibly applies, say so. Route to the layer that owns the specific ask and name the others drawn on; do not merge their content silently.
- A routing document names a skill that does not exist: say so, use the stated fallback, log the drift.
- Agents disagree: show both outputs and the disagreement; it is a signal, not a bug.

## 6. Entity and jurisdiction map

| Code | Entity | Country, industry | Reference |
|---|---|---|---|
| NEPHRO | Nephrocare Management Sdn Bhd | Malaysia, dialysis | `gia-audit:gia-pack-malaysia` |
| MKPC | MKPC | Malaysia, die casting and stamping | `gia-audit:gia-pack-malaysia` |
| MKAPL | MKAPL | India auto parts; ask the plant's state (Tamil Nadu or Maharashtra) | `gia-audit:gia-pack-india` |
| ERAWAN | Erawan LMW | Malaysia, gas cylinders | `gia-audit:gia-pack-malaysia` |
| MKSDL | MK Autoparts SDL | Mexico (code MKSDL, alias MKSLD: open dependency) | `gia-audit:gia-pack-mexico` |
| MKTRON | Group HQ | Malaysia | `gia-audit:gia-pack-malaysia` |

India states other than Tamil Nadu, Maharashtra and Puducherry have no reference; statutory content comes from verified sources. Entities named in skill text but not in the taxonomy (MABI, Fleet Parade, SAPL, BCP, Jacks) need scope confirmation and a code if they are in play.

## 7. Tool surfaces

| Surface | Use for | Caution |
|---|---|---|
| web search and fetch | Anything that may have changed: statutory rates, circulars, enforcement | Cite; evidence only after the CAE accepts |
| bash and file creation | Scripts, workbooks, documents, registers | Read the relevant document skill first |
| Artifact publish | Dashboards and reports the CAE will reopen or share | Private until shared; no personal data |
| subagents (Cowork, Claude Code) | Independent, parallel workstreams | Isolated context; review every return |
| scheduled tasks | Recurring chasers, indicator sweeps | Draft-only for anything external |
| connectors | Reading connected mail, drive, calendar | Confirm with the CAE first |

## 8. Keeping the registry honest

- Edit `data/registry-source.json`, run `scripts/build_registry.py`, then `scripts/library_inventory.py --registry data/capability-registry.json` and resolve every drift line. `scripts/verify_install.py` runs the whole set.
- Entries marked inferred are a reading of the skill files, not a specification; confirm before relying on them.
- Never leave routing logic only in a conversation. Review monthly with the lessons log from `gia-core:self-learning`.
