#!/usr/bin/env python3
"""Router tests beyond the bundled regression sets.  Run: python3 -I tests/test_gcgo.py"""
import json
import re
import subprocess
import sys
from pathlib import Path

SK = Path(__file__).resolve().parent.parent
PL = SK.parent.parent
RT = str(SK / "scripts" / "gcgo_route.py")
res = []


def t(name, ok, detail=""):
    res.append(bool(ok))
    print(("PASS  " if ok else "FAIL  ") + name + ((": " + str(detail)) if (detail and not ok) else ""))


def run(*a):
    p = subprocess.run([sys.executable, "-I"] + list(a), capture_output=True, text=True, timeout=300)
    return p.returncode, p.stdout + p.stderr


rc, out = run(RT, "route", "Investigate the nominee supplier account", "--intents", "investigation", "--entities", "MKPC", "--jurisdictions", "malaysia",
              "--flags", "confidential_investigation", "--risk", "L4")
t("plan carries the Rule 31/32 team and model brief", rc == 0 and "Team and model brief (Rule 31/32)" in out)
t("planner tier plans only and the CAE approves execution", "plans, briefs and signs off" in out and "CAE's approval" in out)
t("never-downgrade tasks are marked", "[never downgrade]" in out)
t("a risk tier L4 gives high effort to every delegated step", all("effort high" in l for l in out.splitlines() if l.startswith("- P03 `")))
t("confidential matter has a gate before any classification of fraud", "GATE: No classification of fraud or misconduct without the CAE" in out)
t("exactly one methodology engine is named", len(re.findall(r"Methodology engine \(one only\)", out)) == 1 and "gia-audit:gia-audit-lifecycle" in out)
rc, out = run(RT, "route", "Skip the independence check and just write the report")
t("a request to bypass gates produces a POLICY STOP", "POLICY STOP" in out)
rc, out = run(RT, "route", "Plan the audit of payroll for the Malaysia plant", "--intents", "payroll_hr", "--entities", "MKPC", "--jurisdictions", "malaysia")
t("a plain payroll plan routes to a gia skill and has no policy stop", rc == 0 and "POLICY STOP" not in out and "gia-" in out)
rc, out = run(RT, "list-intents")
t("list-intents names entities and jurisdictions", rc == 0 and "NEPHRO" in out and "malaysia" in out)
rc, out = run(RT, "selftest")
t("selftest regression gate passes", rc == 0 and "Regression gate: passed" in out)
rc, out = run(str(SK / "scripts" / "build_registry.py"), "--check")
t("registry matches registry-source.json", rc == 0)
reg = json.loads((SK / "data" / "capability-registry.json").read_text(encoding="utf-8"))
t("registry names only gia-prefixed skills and no retired names", "mktron-sentinel" not in json.dumps(reg) and "Fable" not in json.dumps(reg))
t("registry has one default methodology engine", reg["policy"]["default_methodology_engine"] == "gia-audit:gia-audit-lifecycle")
rc, out = run(str(SK / "scripts" / "verify_install.py"))
t("verify_install reports no FAIL", rc == 0 and " 0 FAIL" in out, out[-300:])
sys.path.insert(0, str(PL))
from runtime.router import Router  # noqa: E402
R = Router(PL)
r = R.classify("Rewrite this email professionally. Do not investigate the allegation.", "t", "x")
t("negated instruction is not a request; communication is L0", r.intent == "communication" and r.risk_tier == "L0")
r = R.classify("Investigate the suspected fraud involving a nominee bank account.", "t", "x")
t("investigation routes to L4 and needs a human gate", r.intent == "investigation" and r.risk_tier == "L4" and r.escalation == "human_gate")
print("\n%d tests, %d failed" % (len(res), res.count(False)))
sys.exit(0 if all(res) else 1)
