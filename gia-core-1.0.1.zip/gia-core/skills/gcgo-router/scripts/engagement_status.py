#!/usr/bin/env python3
"""
engagement_status.py - status board for an engagement folder created by init_engagement.py.

Reads the register workbooks and reports counts, open decisions, which stage gates look ready,
and the next actions that are blocked on the CAE. It reads what is in the registers; it cannot
tell whether the entries are right.

Usage
  python engagement_status.py <engagement folder>
  python engagement_status.py <engagement folder> --json
"""
import argparse
import datetime as dt
import json
import sys
from pathlib import Path

try:
    import openpyxl
except ImportError:
    sys.exit("openpyxl is required (pip install openpyxl).")

UNREADABLE = []
REG = {
    "control": ("00_Project-Governance", "01_Engagement-Control-Sheet.xlsx"),
    "decisions": ("00_Project-Governance", "04_Engagement-Decision-Log.xlsx"),
    "lessons": ("00_Project-Governance", "05_Lessons-Log.xlsx"),
    "criteria": ("02_Criteria-and-Control-Framework", "01_Criteria-Register.xlsx"),
    "evidence": ("03_Evidence-and-Populations", "01_Evidence-Register.xlsx"),
    "populations": ("03_Evidence-and-Populations", "02_Population-Completeness-Reconciliation.xlsx"),
    "samples": ("04_Sampling-and-Testing", "01_Sample-Selection-Record.xlsx"),
    "procedures": ("04_Sampling-and-Testing", "02_Procedure-Tracker.xlsx"),
    "exceptions": ("05_Exceptions-and-Resolution", "01_Exception-Register.xlsx"),
    "ce": ("05_Exceptions-and-Resolution", "02_Contradictory-Evidence-Register.xlsx"),
    "gaps": ("05_Exceptions-and-Resolution", "03_Evidence-Gap-Register.xlsx"),
    "responses": ("05_Exceptions-and-Resolution", "05_Management-Response-Log.xlsx"),
    "findings": ("06_Findings-and-Reporting", "02_Finding-Register.xlsx"),
    "trace": ("07_Quality-Assurance", "01_Evidence-to-Finding-Traceability.xlsx"),
    "qa": ("07_Quality-Assurance", "03_Report-QA-Log.xlsx"),
    "actions": ("08_Follow-up-and-Closure", "01_Action-Tracker.xlsx"),
}


def read(root: Path, key):
    folder, fname = REG[key]
    p = root / folder / fname
    if not p.exists():
        return None
    try:
        wb = openpyxl.load_workbook(str(p), read_only=True, data_only=True)
        ws = wb.worksheets[0]
    except Exception as e:
        UNREADABLE.append(f"{fname} ({type(e).__name__})")
        return None
    rows = list(ws.iter_rows(values_only=True))
    if not rows:
        return []
    head = [str(h or "").strip() for h in rows[0]]
    out = []
    for r in rows[1:]:
        if any(c not in (None, "") for c in r):
            out.append({head[i]: r[i] for i in range(min(len(head), len(r)))})
    return out


def blank(v):
    return v is None or str(v).strip() == ""


def col(row, startswith):
    for k, v in row.items():
        if k.lower().startswith(startswith.lower()):
            return v
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("folder")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    root = Path(a.folder)
    if not root.exists():
        sys.exit(f"Folder not found: {root}")

    d = {k: read(root, k) for k in REG}
    missing = [k for k, v in d.items() if v is None]
    if UNREADABLE:
        print("WARNING: unreadable register file(s): " + ", ".join(UNREADABLE) + ". Counts below exclude them; fix or restore before relying on this board.\n")
    n = lambda k: len(d[k] or [])

    exc_wait = [r for r in (d["exceptions"] or []) if blank(col(r, "Auditor decision"))]
    ce_open = [r for r in (d["ce"] or []) if str(col(r, "Status") or "Open").lower() not in ("resolved",)]
    gap_wait = [r for r in (d["gaps"] or []) if blank(col(r, "Auditor decision"))]
    fstat = {}
    for r in d["findings"] or []:
        s = str(col(r, "Status") or "Draft")
        fstat[s] = fstat.get(s, 0) + 1
    qa_open = [r for r in (d["qa"] or []) if blank(col(r, "Cleared by"))]
    today = dt.date.today()
    act_open, act_overdue = [], []
    for r in d["actions"] or []:
        if str(col(r, "Status") or "").lower() not in ("closed", "closed-validated"):
            act_open.append(r)
            due = col(r, "Due date")
            if isinstance(due, dt.datetime):
                due = due.date()
            elif isinstance(due, str):
                try:
                    due = dt.date.fromisoformat(due.strip()[:10])
                except ValueError:
                    due = None
            if isinstance(due, dt.date) and due < today:
                act_overdue.append(r)
    untraced = [r for r in (d["trace"] or []) if blank(col(r, "Evidence IDs"))]

    gateA = n("control") > 0 and n("criteria") > 0 and n("evidence") > 0 and n("samples") > 0
    gateB = gateA and n("exceptions") + n("ce") + n("gaps") > 0 and not exc_wait and not ce_open and not gap_wait
    total_f = sum(fstat.values())
    gateC = total_f > 0 and fstat.get("Approved-locked", 0) + fstat.get("Issued", 0) + fstat.get("Closed", 0) == total_f
    gateD = gateC and not qa_open and not untraced and n("trace") > 0

    next_actions = []
    if n("control") == 0:
        next_actions.append("the CAE: approve and record scope lock in the engagement control sheet (Mode 0).")
    if n("criteria") == 0:
        next_actions.append("Claude (Mode 1): extract criteria verbatim into the criteria register; the CAE confirms applicability.")
    if n("evidence") == 0:
        next_actions.append("Claude (Mode 1): build the evidence register from the uploaded files.")
    if gateA is False and n("samples") == 0 and n("evidence") > 0:
        next_actions.append("the CAE: approve sampling method and size; record in the sample selection record.")
    if exc_wait:
        next_actions.append(f"the CAE: decide {len(exc_wait)} exception(s): reportable / not / more evidence.")
    if ce_open:
        next_actions.append(f"the CAE: resolve or accept as limitation {len(ce_open)} open contradiction(s).")
    if gap_wait:
        next_actions.append(f"the CAE: decide {len(gap_wait)} evidence gap(s): obtain / alternative procedure / scope limitation.")
    if fstat.get("Draft"):
        next_actions.append(f"the CAE: approve and lock {fstat['Draft']} draft finding(s) before report assembly.")
    if untraced:
        next_actions.append(f"Claude: {len(untraced)} traceability row(s) have no evidence ID; close or mark not permitted.")
    if qa_open:
        next_actions.append(f"Claude/the CAE: clear {len(qa_open)} open QA point(s).")
    if act_overdue:
        next_actions.append(f"the CAE: {len(act_overdue)} agreed action(s) overdue; consider chaser (draft only).")
    if not next_actions:
        next_actions.append("No blocked decisions detected in the registers. Check that the registers are actually being kept up to date.")

    result = {
        "engagement": root.name, "as_of": str(today), "missing_registers": missing,
        "counts": {k: n(k) for k in REG},
        "awaiting_sean": {"exceptions": len(exc_wait), "contradictions_open": len(ce_open), "gaps": len(gap_wait),
                          "draft_findings": fstat.get("Draft", 0), "qa_open": len(qa_open), "actions_overdue": len(act_overdue)},
        "findings_by_status": fstat,
        "gates_look_ready": {"A_before_testing": gateA, "B_before_finding_drafting": gateB,
                             "C_before_report_assembly": gateC, "D_before_release": gateD},
        "next_actions": next_actions,
    }
    if a.json:
        print(json.dumps(result, indent=2, default=str))
        return
    o = [f"# Status board: {root.name}", f"As of {today}", ""]
    if missing:
        o.append("Registers not found: " + ", ".join(missing) + "\n")
    o += ["## Counts"] + [f"- {k}: {v}" for k, v in result["counts"].items() if v]
    o += ["", "## Waiting on the CAE"] + [f"- {k.replace('_', ' ')}: {v}" for k, v in result["awaiting_sean"].items()]
    if fstat:
        o += ["", "## Findings by status"] + [f"- {k}: {v}" for k, v in fstat.items()]
    o += ["", "## Gates (as far as the registers show)"]
    for k, v in result["gates_look_ready"].items():
        o.append(f"- {k}: {'looks ready for the CAE to confirm' if v else 'not ready'}")
    o += ["", "## Next actions"] + [f"{i}. {x}" for i, x in enumerate(next_actions, 1)]
    o += ["", "A gate that 'looks ready' still needs the CAE's confirmation; registers show what was recorded, not whether it is right."]
    print("\n".join(o))


if __name__ == "__main__":
    main()
