#!/usr/bin/env python3
"""verify_install.py - prove the router and its registry are healthy.

  python3 -I verify_install.py [--plugins-dir DIR] [--json out.json]

Checks (PASS, WARN or FAIL):
  1. every gia-core skill present, SKILL.md parses, name matches folder, description within 1024 characters
  2. every shipped script compiles
  3. registry is up to date with data/registry-source.json (build_registry.py --check)
  4. registry drift against the sibling plugin folders (installed but unregistered, registered but absent)
  5. router selftest (regression gate)
  6. Rule 32 matrix and selector present
Exit 0 = no FAIL; 1 = at least one FAIL. WARN means act, but the router still works.
"""
import argparse
import json
import py_compile
import re
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
SKILL = HERE.parent
PLUGIN = SKILL.parent.parent
CORE = ["iron-rules", "gcgo-router", "runtime-guard", "safeguard-lint", "model-effort-routing", "project-memory", "self-learning", "skill-hygiene"]
results = []


def rec(status, check, detail=""):
    results.append({"status": status, "check": check, "detail": detail})
    print("%-5s %s%s" % (status, check, (": " + detail) if detail else ""))


def run(args):
    p = subprocess.run([sys.executable, "-I"] + args, capture_output=True, text=True, timeout=300)
    return p.returncode, (p.stdout + p.stderr)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--plugins-dir", default=str(PLUGIN.parent))
    ap.add_argument("--json")
    a = ap.parse_args()
    # 1 skills
    for name in CORE:
        sm = PLUGIN / "skills" / name / "SKILL.md"
        if not sm.exists():
            rec("FAIL", "skill %s" % name, "SKILL.md missing")
            continue
        m = re.match(r"---\n(.*?)\n---\n", sm.read_text(encoding="utf-8"), re.S)
        if not m:
            rec("FAIL", "skill %s" % name, "no frontmatter")
            continue
        fm = m.group(1)
        nm = re.search(r"^name:\s*(\S+)", fm, re.M)
        desc = re.search(r"^description:\s*(.+)", fm, re.M)
        if not nm or nm.group(1) != name:
            rec("FAIL", "skill %s" % name, "name does not match folder")
        elif not desc or len(desc.group(1)) > 1024:
            rec("FAIL", "skill %s" % name, "description missing or over 1024 characters")
        else:
            rec("PASS", "skill %s" % name)
    # 2 scripts compile
    bad = []
    n = 0
    for p in sorted(PLUGIN.glob("**/*.py")):
        if "tests" in p.parts or "__pycache__" in p.parts:
            continue
        n += 1
        try:
            py_compile.compile(str(p), cfile=str(Path(tempfile.gettempdir()) / "vi.pyc"), doraise=True)
        except py_compile.PyCompileError as e:
            bad.append("%s: %s" % (p.name, str(e)[:80]))
    rec("FAIL" if bad else "PASS", "scripts compile (%d)" % n, "; ".join(bad))
    # 3 registry current
    rc, out = run([str(HERE / "build_registry.py"), "--check"])
    rec("PASS" if rc == 0 else "FAIL", "registry matches registry-source.json", out.strip().splitlines()[-1] if out.strip() else "")
    # 4 drift
    rc, out = run([str(HERE / "library_inventory.py"), "--plugins-dir", a.plugins_dir, "--registry", str(SKILL / "data" / "capability-registry.json")])
    m1 = re.search(r"installed but not in registry \((\d+)\)", out)
    m2 = re.search(r"in registry but not installed \((\d+)\)", out)
    if rc != 0 or not m1 or not m2:
        rec("WARN", "registry drift", "inventory did not run (sibling plugins not found?)")
    else:
        un, ab = int(m1.group(1)), int(m2.group(1))
        rec("PASS" if un == 0 and ab == 0 else "WARN", "registry drift", "unregistered %d, absent %d" % (un, ab))
    # 5 selftest
    rc, out = run([str(HERE / "gcgo_route.py"), "selftest"])
    rec("PASS" if rc == 0 else "FAIL", "router selftest", [l for l in out.splitlines() if l.startswith("Regression gate")][0] if "Regression gate" in out else out[-120:])
    # 6 matrix
    ok = (PLUGIN / "skills" / "model-effort-routing" / "data" / "matrix.json").exists() and (PLUGIN / "skills" / "model-effort-routing" / "scripts" / "select_model_effort.py").exists()
    rec("PASS" if ok else "FAIL", "Rule 32 matrix and selector present")
    fails = [r for r in results if r["status"] == "FAIL"]
    print("\n%d PASS, %d WARN, %d FAIL" % (sum(r["status"] == "PASS" for r in results), sum(r["status"] == "WARN" for r in results), len(fails)))
    if a.json:
        Path(a.json).write_text(json.dumps(results, indent=1), encoding="utf-8")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
