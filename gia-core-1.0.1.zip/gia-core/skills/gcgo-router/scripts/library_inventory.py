#!/usr/bin/env python3
"""
library_inventory.py - evidence-based map of the installed skill/plugin library.

Scans skill roots for SKILL.md files and reports, from the files themselves (not memory):
  * inventory by tier/family (+ descriptions longer than 1024 chars)
  * duplicate skills (identical description text) and name collisions
  * a cross-reference graph: which skill's text mentions which other installed skill
    (hubs, and orphans inside the GIA cluster)
  * dangling references: skill-like names cited in routing/orchestrator documents that are
    not installed
  * trigger-vocabulary overlap between GIA-cluster skills (Jaccard on description words)
  * registry drift when --registry is given (installed but unregistered; registered but absent)

Usage
  python3 -I library_inventory.py                   # scan the sibling plugin folders (plugin:skill ids), print markdown
  python3 -I library_inventory.py --plugins-dir DIR --registry ../data/capability-registry.json
  python3 -I library_inventory.py --roots /mnt/skills/user --json inv.json --md inv.md   # legacy flat roots
"""
import argparse
import hashlib
import json
import re
import sys
from collections import defaultdict
from itertools import combinations
from pathlib import Path

DEFAULT_ROOTS = []
DEFAULT_PLUGINS_DIR = Path(__file__).resolve().parent.parent.parent.parent.parent   # <plugins>/<plugin>/skills/gcgo-router/scripts -> <plugins>

GIA_PREFIXES = ("mktron-", "gia-", "akos", "grc-", "cae-", "group-cae", "my-", "mx-", "in-manufacturing",
                "chennai", "pune", "payroll", "racm", "super-grc", "master-audit", "managing-internal",
                "board-chairman", "debugger", "charlie-hills")

# documents whose references to other skills we treat as routing claims
ROUTING_DOC_HINTS = ("gcgo-router", "gia-audit-lifecycle", "project-memory", "skill-hygiene")

STOP = set("""this that with from will your have been into their they them when which what where there
about also each more most other some such than then these those only over under very while would should
could must use used using uses audit skill skills plugin work works based within across through
before after both either neither whether like just make makes made need needs including include
includes etc and the for are not any all can may its per via one two three new get gets set sets
trigger triggers always never ever full end data file files report reports task tasks request requests
user users claude""".split())


def parse_frontmatter(text):
    m = re.match(r"^---\s*\n(.*?)\n---\s*\n?", text, re.S)
    if not m:
        return {}, text
    block, body = m.group(1), text[m.end():]
    try:
        import yaml
        fm = yaml.safe_load(block) or {}
        if not isinstance(fm, dict):
            fm = {}
    except Exception:
        fm = {}
        n = re.search(r"^name:\s*(.+)$", block, re.M)
        d = re.search(r"^description:\s*(.+?)(?:\n\w+:|\Z)", block, re.M | re.S)
        if n:
            fm["name"] = n.group(1).strip()
        if d:
            fm["description"] = " ".join(d.group(1).split())
    return fm, body


def family_of(dirname, tier):
    if ":" in dirname:
        return dirname.split(":", 1)[0]
    return f"[{tier}]"


def scan(roots):
    skills = {}
    for root in roots:
        r = Path(root)
        if not r.exists():
            continue
        tier = r.name
        for d in sorted(p for p in r.iterdir() if p.is_dir()):
            f = d / "SKILL.md"
            if not f.exists():
                continue
            text = f.read_text(encoding="utf-8", errors="replace")
            fm, body = parse_frontmatter(text)
            desc = " ".join(str(fm.get("description", "")).split())
            sid = d.name if tier == "plugins" else f"{tier}/{d.name}"
            refs_text = body
            ref_dir = d / "references"
            if ref_dir.exists():
                for rf in ref_dir.glob("*.md"):
                    refs_text += "\n" + rf.read_text(encoding="utf-8", errors="replace")
            skills[sid] = {
                "id": sid, "dir": d.name, "tier": tier, "family": family_of(d.name, tier),
                "name": str(fm.get("name", d.name)), "description": desc, "desc_len": len(desc),
                "body": body, "all_text": refs_text, "path": str(f),
            }
    return skills


def scan_plugins(parent):
    """Skills from sibling plugin folders. id = plugin:skill (plugin name from .claude-plugin/plugin.json)."""
    skills = {}
    base = Path(parent)
    if not base.exists():
        return skills
    for sk in sorted(base.glob("*/skills/*/SKILL.md")):
        d = sk.parent
        pdir = d.parent.parent
        try:
            pname = json.loads((pdir / ".claude-plugin" / "plugin.json").read_text(encoding="utf-8")).get("name", pdir.name)
        except (OSError, json.JSONDecodeError):
            pname = pdir.name
        text = sk.read_text(encoding="utf-8", errors="replace")
        fm, body = parse_frontmatter(text)
        desc = " ".join(str(fm.get("description", "")).split())
        refs = body
        if (d / "references").exists():
            for rf in (d / "references").glob("*.md"):
                refs += "\n" + rf.read_text(encoding="utf-8", errors="replace")
        sid = "%s:%s" % (pname, d.name)
        skills[sid] = {"id": sid, "dir": sid, "tier": "plugins", "family": pname, "name": str(fm.get("name", d.name)),
                       "description": desc, "desc_len": len(desc), "body": body, "all_text": refs, "path": str(sk)}
    return skills


def short(sid):
    return sid.split("/", 1)[-1]


def duplicates(skills):
    by_hash = defaultdict(list)
    for s in skills.values():
        if s["description"]:
            by_hash[hashlib.sha256(s["description"].encode()).hexdigest()].append(s["id"])
    dup_desc = [v for v in by_hash.values() if len(v) > 1]
    by_name = defaultdict(list)
    for s in skills.values():
        by_name[s["name"]].append(s["id"])
    dup_name = {k: v for k, v in by_name.items() if len(v) > 1}
    return dup_desc, dup_name


def reference_graph(skills):
    tokens = {}
    for s in skills.values():
        cand = {s["dir"], s["name"]}
        if ":" in s["dir"]:
            cand.add(s["dir"].split(":", 1)[1])
        for c in cand:
            if len(c) >= 8 or "-" in c:
                tokens.setdefault(c, set()).add(s["id"])
    edges = defaultdict(set)
    for s in skills.values():
        text = s["description"] + "\n" + s["all_text"]
        for tok, owners in tokens.items():
            if len(owners) > 1 and tok not in (s["dir"], s["name"]):
                pass
            if re.search(r"(?<![\w:-])" + re.escape(tok) + r"(?![\w-])", text):
                for o in owners:
                    if o != s["id"] and short(o) != short(s["id"]):
                        edges[s["id"]].add(o)
    return edges


def is_gia(s):
    d = s["dir"].split(":", 1)[-1]
    f = s["family"]
    return s["tier"] in ("plugins", "user") and (f.startswith(GIA_PREFIXES) or d.startswith(GIA_PREFIXES) or d in ("iron-rules", "gcgo-router", "runtime-guard", "safeguard-lint", "model-effort-routing", "project-memory", "self-learning", "skill-hygiene", "gias-navigator"))


COND = re.compile(r"if (?:it is |they are |that skill is |the skill is )?(?:installed|present|available)|when installed|"
                  r"not installed|if absent|fallback|availability|may not be installed|if you have", re.I)


def dangling(skills):
    """Skill-like names cited in routing/orchestrator documents that are not installed.
    Ignores: plugin names, subagent files (agents/<name>.md in the same skill), and names that
    appear only on lines that already say 'if installed / not installed / fallback'."""
    installed = set()
    plugins = set()
    for s in skills.values():
        installed |= {s["dir"], s["name"], s["dir"].split(":", 1)[-1]}
        if ":" in s["dir"]:
            plugins.add(s["dir"].split(":", 1)[0])
    found = defaultdict(set)
    for s in skills.values():
        if not any(h in s["dir"] for h in ROUTING_DOC_HINTS):
            continue
        for line in s["all_text"].splitlines():
            if COND.search(line):
                continue
            for tok in re.findall(r"`([a-z][a-z0-9]*(?:[-:][a-z0-9]+)+)`", line):
                if tok in installed or tok in plugins or "." in tok or tok.startswith("--"):
                    continue
                if tok.split(":")[0] in plugins:
                    continue
                if re.fullmatch(r"v\d.*|.*-v\d+|[a-z]+-\d+", tok) and tok.split("-")[0] in installed:
                    continue
                found[tok].add(s["dir"])
    skip = {"quick-validate", "run-eval", "run-loop"}
    return {k: sorted(v) for k, v in found.items() if k not in skip}


def vocab(desc):
    words = re.findall(r"[a-z][a-z0-9]{3,}", desc.lower())
    return {w for w in words if w not in STOP}


def overlap(skills, min_j=0.18, top=15):
    gia = [s for s in skills.values() if is_gia(s) and not s["description"].lower().startswith("retired redirect")]
    voc = {s["id"]: vocab(s["description"]) for s in gia}
    pairs = []
    for a, b in combinations(gia, 2):
        va, vb = voc[a["id"]], voc[b["id"]]
        if not va or not vb:
            continue
        j = len(va & vb) / len(va | vb)
        if j >= min_j:
            pairs.append((round(j, 2), a["id"], b["id"], sorted(va & vb)[:8]))
    pairs.sort(reverse=True)
    return pairs[:top]


def registry_drift(skills, registry_path):
    reg = json.loads(Path(registry_path).read_text(encoding="utf-8"))
    reg_ids = set(reg.get("skills", {}).keys())
    patterns = [re.compile(p) for p in reg.get("family_patterns", {}).keys()]
    ignore = [re.compile(p) for p in reg.get("ignore_patterns", [])]
    installed = {s["id"] for s in skills.values()}

    def covered(sid):
        d = short(sid)
        return (sid in reg_ids or d in reg_ids or any(p.match(d) for p in patterns)
                or any(p.match(sid) or p.match(d) for p in ignore))

    unregistered = sorted(i for i in installed if not covered(i))
    absent = sorted(i for i in reg_ids if i not in installed and ("plugins/" + i) not in installed
                    and not any(short(x) == i for x in installed)
                    and reg["skills"][i].get("status") != "duplicate")
    return unregistered, absent


def render_md(skills, edges, dup_desc, dup_name, dang, ovl, drift):
    out = ["# Library inventory and relationship analysis", ""]
    by_tier = defaultdict(int)
    by_family = defaultdict(int)
    for s in skills.values():
        by_tier[s["tier"]] += 1
        by_family[s["family"]] += 1
    out += [f"Installed skills found: **{len(skills)}** (" + ", ".join(f"{k}: {v}" for k, v in sorted(by_tier.items())) + ")", ""]
    out += ["## Families (plugin prefixes and standalone)", ""]
    for fam, n in sorted(by_family.items(), key=lambda x: -x[1]):
        out.append(f"- {fam}: {n}")
    long_desc = [(s["id"], s["desc_len"]) for s in skills.values() if s["desc_len"] > 1024]
    out += ["", f"## Descriptions over 1024 characters ({len(long_desc)})", ""]
    out += [f"- {i}: {n}" for i, n in sorted(long_desc, key=lambda x: -x[1])] or ["- none"]

    out += ["", f"## Duplicate skills: identical description text ({len(dup_desc)} groups)", ""]
    out += ["- " + "  =  ".join(g) for g in dup_desc] or ["- none"]
    if dup_name:
        out += ["", "## Same `name` in more than one location", ""]
        out += [f"- {k}: {', '.join(v)}" for k, v in dup_name.items()]

    inbound = defaultdict(set)
    for a, tgts in edges.items():
        for t in tgts:
            inbound[t].add(a)
    gia = [s for s in skills.values() if is_gia(s)]
    out += ["", f"## Cross-reference hubs in the GIA cluster ({len(gia)} skills): most referenced by other skills", ""]
    hubs = sorted(((len(inbound[s["id"]]), s["id"]) for s in gia), reverse=True)[:12]
    out += [f"- {i}: referenced by {n}" for n, i in hubs]
    orph = sorted(s["id"] for s in gia if not inbound[s["id"]])
    out += ["", f"## GIA skills no other skill mentions ({len(orph)})", "",
            "(Not necessarily a problem: a leaf specialist is reached by trigger match, not by reference. "
            "But nothing routes to these on purpose.)", ""]
    out += [f"- {o}" for o in orph] or ["- none"]

    out += ["", f"## Dangling references: cited in routing/orchestrator docs but not installed ({len(dang)})", ""]
    out += [f"- `{k}` (cited in: {', '.join(v)})" for k, v in sorted(dang.items())] or ["- none"]

    out += ["", "## Trigger-vocabulary overlap inside the GIA cluster (Jaccard on description words)", ""]
    out += [f"- {j}: {a}  <>  {b}  (shared: {', '.join(w)})" for j, a, b, w in ovl] or ["- none above threshold"]

    if drift is not None:
        un, ab = drift
        out += ["", f"## Registry drift: installed but not in registry ({len(un)})", ""]
        out += [f"- {u}" for u in un] or ["- none"]
        out += ["", f"## Registry drift: in registry but not installed ({len(ab)})", ""]
        out += [f"- {a}" for a in ab] or ["- none"]
    return "\n".join(out)


def main():
    ap = argparse.ArgumentParser(description="Map the installed skill library.")
    ap.add_argument("--roots", nargs="*", default=DEFAULT_ROOTS)
    ap.add_argument("--plugins-dir", default=str(DEFAULT_PLUGINS_DIR), help="folder holding the plugin folders (default: the folder above this plugin)")
    ap.add_argument("--registry", help="capability-registry.json to check for drift")
    ap.add_argument("--json", help="write machine-readable output here")
    ap.add_argument("--md", help="write markdown report here")
    a = ap.parse_args()

    skills = scan(a.roots)
    skills.update(scan_plugins(a.plugins_dir))
    if not skills:
        sys.exit("No skills found under the given roots.")
    edges = reference_graph(skills)
    dup_desc, dup_name = duplicates(skills)
    dang = dangling(skills)
    ovl = overlap(skills)
    drift = registry_drift(skills, a.registry) if a.registry else None
    md = render_md(skills, edges, dup_desc, dup_name, dang, ovl, drift)
    if a.json:
        Path(a.json).write_text(json.dumps({
            "skills": {k: {kk: vv for kk, vv in v.items() if kk not in ("body", "all_text")} for k, v in skills.items()},
            "edges": {k: sorted(v) for k, v in edges.items()},
            "duplicate_descriptions": dup_desc, "duplicate_names": dup_name,
            "dangling": dang, "overlap": ovl,
            "drift": {"unregistered": drift[0], "absent": drift[1]} if drift else None,
        }, indent=2), encoding="utf-8")
    if a.md:
        Path(a.md).write_text(md, encoding="utf-8")
        print(f"Wrote {a.md}")
    else:
        print(md)


if __name__ == "__main__":
    main()
