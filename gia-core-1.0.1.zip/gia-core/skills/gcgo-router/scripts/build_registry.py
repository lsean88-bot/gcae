#!/usr/bin/env python3
"""Build data/capability-registry.json from data/registry-source.json.

  python3 -I build_registry.py [--check]

registry-source.json is the hand-edited authority (entities, jurisdictions, intents, playbooks, policy, skills).
This script validates it, refreshes each skill's description from its SKILL.md when the sibling plugin folders are
present, and writes the registry the router reads. With --check it writes nothing and exits 1 when the committed
registry differs from what would be built or validation fails.

Validation: every playbook step, entity specialist and jurisdiction skill is a registered skill, a placeholder
({engine}, {entity_skills}, {juris_hr_skills}) or an allowed external tool; every intent points to a playbook;
no stale or retired names appear anywhere in the data.
"""
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
DATA = HERE.parent / "data"
PLUGIN_ROOT = HERE.parent.parent.parent
EXTERNAL = re.compile(r"^(web_search|pptx|xlsx|docx|pdf|skill-creator|(finance|data|legal|financial-analysis|bigdata-com|daloopa|lseg|sp-global):[\w-]+)$")
PLACEHOLDER = re.compile(r"^\{[a-z_]+\}$")
BANNED = re.compile(r"mktron-sentine[l]|\bF[a]ble\b|\bSea[n]\b", re.I)


def sibling_descriptions():
    """plugin:skill -> description, from SKILL.md frontmatter of sibling plugin folders."""
    out = {}
    root = PLUGIN_ROOT.parent
    for sk in list(root.glob("*/skills/*/SKILL.md")) + list(root.glob("*/*/skills/*/SKILL.md")):
        plugin_dir = sk.parent.parent.parent
        try:
            pname = json.loads((plugin_dir / ".claude-plugin" / "plugin.json").read_text(encoding="utf-8")).get("name", plugin_dir.name)
        except (OSError, json.JSONDecodeError):
            pname = plugin_dir.name
        m = re.match(r"---\n(.*?)\n---", sk.read_text(encoding="utf-8"), re.S)
        if m:
            d = re.search(r"^description:\s*(.+(?:\n[ \t]+.+)*)", m.group(1), re.M)
            if d:
                out["%s:%s" % (pname, sk.parent.name)] = re.sub(r"\s+", " ", d.group(1)).strip()
    return out


def validate(src):
    errs = []
    skills = set(src["skills"])
    def known(s):
        return s in skills or PLACEHOLDER.match(s) or EXTERNAL.match(s) or s.startswith("(")
    for pid, pb in src["playbooks"].items():
        for i, st in enumerate(pb["steps"], 1):
            if not known(st["skill"]):
                errs.append("%s step %d: unknown skill %s" % (pid, i, st["skill"]))
    for code, e in src["entities"].items():
        for s in e.get("specialists", []) + e.get("support", []):
            if s not in skills:
                errs.append("entity %s: unknown skill %s" % (code, s))
    for j, spec in src["jurisdictions"].items():
        for s in spec["skills"]:
            if s not in skills:
                errs.append("jurisdiction %s: unknown skill %s" % (j, s))
    for k, spec in src["intents"].items():
        if spec["playbook"] not in src["playbooks"]:
            errs.append("intent %s: unknown playbook %s" % (k, spec["playbook"]))
    for k in ("default_methodology_engine", "default_fieldwork_tool", "default_fraud_skill"):
        if src["policy"][k] not in skills:
            errs.append("policy.%s: unknown skill %s" % (k, src["policy"][k]))
    m = BANNED.search(json.dumps(src))
    if m:
        errs.append("banned or stale text in source: %r" % m.group(0))
    return errs


def build():
    src = json.loads((DATA / "registry-source.json").read_text(encoding="utf-8"))
    errs = validate(src)
    desc = sibling_descriptions()
    for sid, sk in src["skills"].items():
        if sid in desc:
            sk["description"] = desc[sid]
            sk["installed_here"] = True
    src["meta"]["skill_count"] = len(src["skills"])
    src["meta"]["playbook_count"] = len(src["playbooks"])
    return src, errs


def main():
    check = "--check" in sys.argv
    reg, errs = build()
    for e in errs:
        print("FAIL", e)
    out = DATA / "capability-registry.json"
    text = json.dumps(reg, indent=1, ensure_ascii=False, sort_keys=True) + "\n"
    if check:
        same = out.exists() and out.read_text(encoding="utf-8") == text
        print("registry up to date" if same else "registry differs from registry-source.json (run build_registry.py)")
        return 0 if (same and not errs) else 1
    if errs:
        return 1
    out.write_text(text, encoding="utf-8")
    print("wrote %s: %d skills, %d playbooks, %d intents" % (out.name, len(reg["skills"]), len(reg["playbooks"]), len(reg["intents"])))
    return 0


if __name__ == "__main__":
    sys.exit(main())
