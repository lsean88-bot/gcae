#!/usr/bin/env python3
"""
gcgo_route.py - turn a work request into a Work Requirement Profile and a routing plan.

Deterministic: keyword scoring against data/capability-registry.json. It proposes; the CAE and the
assistant confirm. It does not read the request's meaning the way the assistant does, so treat the
output as a checklist to sanity-check, not as an oracle. Every plan ends with a Rule 31/32 team and
model brief (chief specialist, delegations, model tier and effort per step, independent QA).

Usage
  python3 -I gcgo_route.py list-intents
  python3 -I gcgo_route.py route "Start the MKAPL Pune stamping audit" --intents new_engagement --entities MKAPL --jurisdictions india-mh
  python3 -I gcgo_route.py route "payroll fraud red flags at MKPC" --json [--risk L3]
  python3 -I gcgo_route.py explain gia-fraud:gia-fraud-investigation
  python3 -I gcgo_route.py graph P04            # Mermaid flow for a playbook
  python3 -I gcgo_route.py selftest | list-playbooks | playbooks-md
"""
import argparse
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
REG_PATHS = [HERE.parent / "data" / "capability-registry.json", Path("data/capability-registry.json")]
SKILL_ROOTS = ["/mnt/skills/public", "/mnt/skills/examples", "/mnt/skills/user", "/mnt/skills/plugins"]
PLUGIN_ROOT = HERE.parent.parent.parent          # <plugin>/skills/gcgo-router/scripts -> <plugin>
MATRIX = PLUGIN_ROOT / "skills" / "model-effort-routing" / "data" / "matrix.json"
SELECTOR = PLUGIN_ROOT / "skills" / "model-effort-routing" / "scripts" / "select_model_effort.py"


def load_registry(path=None):
    for p in ([Path(path)] if path else REG_PATHS):
        if p.exists():
            try:
                return json.loads(p.read_text(encoding="utf-8"))
            except json.JSONDecodeError as e:
                sys.exit(f"Registry {p} is not valid JSON ({e}). Rebuild it with scripts/build_registry.py or restore from backup.")
    sys.exit("capability-registry.json not found (use --registry).")


def installed_set():
    """Names as plugin:skill. Looks at the sibling plugin folders (cache layout <root>/<plugin>/skills/<skill> or <root>/<plugin>/<version>/skills/<skill>)."""
    names = set()
    roots = [PLUGIN_ROOT.parent]
    for root in roots:
        if root.exists():
            for sk in list(root.glob("*/skills/*/SKILL.md")) + list(root.glob("*/*/skills/*/SKILL.md")):
                skill_dir = sk.parent
                plugin_dir = skill_dir.parent.parent
                pname = plugin_dir.name
                try:
                    pm = json.loads((plugin_dir / ".claude-plugin" / "plugin.json").read_text(encoding="utf-8"))
                    pname = pm.get("name", pname)
                except (OSError, json.JSONDecodeError):
                    pass
                names.add("%s:%s" % (pname, skill_dir.name))
    for root in SKILL_ROOTS:
        r = Path(root)
        if r.exists():
            for d in r.iterdir():
                if d.is_dir() and (d / "SKILL.md").exists():
                    names.add(d.name)
    return names


import functools


@functools.lru_cache(maxsize=None)
def sig_regex(sig):
    sig = sig.strip().lower()
    if sig.endswith("*"):
        return re.compile(r"(?<![a-z0-9])" + re.escape(sig[:-1]) + r"[a-z0-9]*")
    suffix = r"(?:s|es|ed|d|ing)?" if len(sig) >= 4 and not sig.endswith("s") else ""
    return re.compile(r"(?<![a-z0-9])" + re.escape(sig) + suffix + r"(?![a-z0-9])")


def hits(text, signals):
    found = []
    for s in signals:
        if sig_regex(s).search(text):
            found.append(s)
    return found



STOP = set("a an the of to in on for and or but with from by at as is are was were be been it this that these those i we you our my me us your please can could would should do does did have has had will shall not no any all some what which who how when where why there their them then than so if into about over under out up down before after just also too very".split())


def stem(w):
    for suf in ("ations", "ation", "ings", "ing", "ies", "ied", "es", "ed", "ly", "s"):
        if w.endswith(suf) and len(w) - len(suf) >= 3:
            return w[: -len(suf)] + ("y" if suf in ("ies", "ied") else "")
    return w


def toks(text):
    return [stem(w) for w in re.findall(r"[a-z][a-z0-9']+", text.lower()) if w not in STOP and len(w) > 1]


def char_grams(text, ns=(3, 4, 5)):
    t = " " + re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]", " ", text.lower())) + " "
    return [t[i:i + n] for n in ns for i in range(len(t) - n + 1)]


_INDEX = {}
_DOCS = {}


def _tfidf_best(text, docs, tokfn):
    import math
    key = (id(docs), tokfn.__name__)
    if key not in _INDEX:
        toked = [(i, ph, tokfn(ph)) for i, ph in docs]
        df = {}
        for _, _, t in toked:
            for w in set(t):
                df[w] = df.get(w, 0) + 1
        n = len(toked) or 1
        idf_ = {w: math.log((n + 1) / (c + 1)) + 1 for w, c in df.items()}
        default = math.log(n + 1) + 1

        def vec_(t):
            v = {}
            for w in t:
                v[w] = v.get(w, 0) + 1
            v = {w: c * idf_.get(w, default) for w, c in v.items()}
            norm = math.sqrt(sum(x * x for x in v.values())) or 1
            return {w: x / norm for w, x in v.items()}
        _INDEX[key] = ([(i, ph, vec_(t)) for i, ph, t in toked], vec_)
    docvecs, vec = _INDEX[key]
    q = vec(tokfn(text))
    best = {}
    for i, ph, d in docvecs:
        sim = sum(q[w] * d.get(w, 0) for w in q)
        if sim > best.get(i, (0, ""))[0]:
            best[i] = (sim, ph)
    return best


def knn_scores(text, exemplars):
    """Average of word-stem and character n-gram TF-IDF cosine, best exemplar per intent.
    Returns [(sim, intent, nearest_phrase)]. A WEAK signal (leave-one-out top-3 hit about 80%, top-1 about 54%):
    used only to suggest candidate intents, never to assign one."""
    docs = _DOCS.get(id(exemplars))
    if docs is None:
        docs = _DOCS[id(exemplars)] = [(i, ph) for i, phs in exemplars.items() for ph in phs]
    text = text[:2000]
    a = _tfidf_best(text, docs, toks)
    b = _tfidf_best(text, docs, char_grams)
    out = []
    for i in set(a) | set(b):
        sa, pa = a.get(i, (0, "")); sb, pb = b.get(i, (0, ""))
        out.append(((sa + sb) / 2, i, pa if sa >= sb else pb))
    return sorted(out, reverse=True)


def classify(text, reg, exemplars=None):
    t = " " + re.sub(r"\s+", " ", text.lower()) + " "
    # intents
    scored = []
    for name, spec in reg["intents"].items():
        if spec.get("requires_context"):
            continue
        f = hits(t, spec["signals"])
        score = sum(2 if " " in s or "-" in s else 1 for s in f)
        if score:
            scored.append((score, name, f))
    scored.sort(reverse=True)
    chosen = []
    if scored:
        top = scored[0][0]
        for sc, name, f in scored:
            if sc >= max(1, round(0.4 * top)):
                chosen.append({"intent": name, "score": sc, "signals": f, "playbook": reg["intents"][name]["playbook"]})
    # entity / region context, used by context-dependent intents
    ctx_entity = any(hits(t, e["signals"]) for e in reg["entities"].values()) or any(hits(t, j["signals"]) for j in reg["jurisdictions"].values())
    region = bool(re.search(r"karnataka|gujarat|haryana|uttar pradesh|andhra|telangana|kerala|rajasthan|west bengal", t))
    unk = any(re.search(r"(?<![a-z])" + re.escape(u.lower()) + r"(?![a-z])", t) for u in reg.get("entities_unmapped_seen_in_skills", []))
    if not chosen and (ctx_entity or region or unk):
        for name, spec in reg["intents"].items():
            if spec.get("requires_context"):
                f = hits(t, spec["signals"])
                if f:
                    chosen.append({"intent": name, "score": 1, "signals": f, "playbook": spec["playbook"]})
    # collapse intents that map to the same playbook
    seen, uniq = set(), []
    for c in chosen:
        if c["playbook"] not in seen:
            seen.add(c["playbook"])
            uniq.append(c)
    # similarity: suggestions only (never auto-assigns an intent)
    suggestions = []
    rt = reg.get("router", {})
    ex = exemplars if exemplars is not None else reg.get("exemplars", {})
    if ex and len(toks(text)) >= rt.get("knn_min_tokens", 3):
        have = {c["intent"] for c in uniq}
        for sim, intent, phrase in knn_scores(text, ex)[:4]:
            if reg["intents"].get(intent) and intent not in have:
                suggestions.append({"intent": intent, "similarity": round(sim, 2), "nearest_example": phrase[:90]})
        suggestions = suggestions[:3]
    # entities
    entities = []
    for code, e in reg["entities"].items():
        f = hits(t, e["signals"])
        if f:
            entities.append({"code": code, "signals": f})
    # jurisdictions
    juris = []
    for j, spec in reg["jurisdictions"].items():
        f = hits(t, spec["signals"])
        if f:
            juris.append({"jurisdiction": j, "signals": f})
    flags = {k: hits(t, v) for k, v in reg["risk_flags"].items()}
    flags = {k: v for k, v in flags.items() if v}
    multi = bool(re.search(r"multi-?session|long[- ]running|across (?:all )?entities|several entities|each entity|group-wide|knowledge (?:repository|graph)", t))
    parallel = bool(re.search(r"delegate|subagent|in parallel|parallel workstreams|fleet|deploy the fleet", t))
    rq = bool(hits(t, reg.get("routing_question_signals", [])))
    unknown_ent = [u for u in reg.get("entities_unmapped_seen_in_skills", []) if re.search(r"(?<![a-z])" + re.escape(u.lower()) + r"(?![a-z])", t)]
    classify.last_suggestions = suggestions
    return uniq, scored, entities, juris, flags, multi, parallel, unknown_ent, rq


def detect_policy(text, reg):
    t = " " + re.sub(r"\s+", " ", text.lower()) + " "
    out = {}
    for name, spec in reg.get("policy_requests", {}).items():
        for pat in spec["patterns"]:
            m = re.search(pat, t)
            if m:
                out[name] = {"matched": m.group(0).strip(), "response": spec["response"]}
                break
    return out


def resolve_entity_skills(entities, juris, reg):
    primary, support, notes = [], [], []
    for e in entities:
        spec = reg["entities"][e["code"]]
        primary += spec.get("specialists", [])
        support += spec.get("support", [])
    for j in juris:
        sk = reg["jurisdictions"][j["jurisdiction"]]["skills"]
        if j["jurisdiction"] == "india" and any(x["jurisdiction"] in ("india-tn", "india-mh") for x in juris):
            continue  # state skill is more specific than the generic India skill
        primary += sk
    # MKAPL with no state signal: ask
    if any(e["code"] == "MKAPL" for e in entities) and not any(j["jurisdiction"] in ("india-tn", "india-mh") for j in juris):
        notes.append("MKAPL: no plant/state named. Ask which plant (Tamil Nadu vs Maharashtra) before choosing the state reference in gia-audit:gia-pack-india.")
    # de-dupe preserving order
    def dd(xs):
        out = []
        for x in xs:
            if x not in out:
                out.append(x)
        return out
    primary = dd(primary)
    support = [s for s in dd(support) if s not in primary]
    return primary, support, notes


def canonical(sid, reg, installed):
    sk = reg["skills"].get(sid, {})
    c = sk.get("canonical")
    if c and c != sid:
        return c
    return sid


def status_of(sid, reg, installed):
    if sid in ("gia-core:gcgo-router", "web_search", "gcgo-in-thread", "gia-core-agents") or sid.startswith(("{", "(")):
        return "n/a"
    base = sid
    if not installed:
        return "unchecked"
    return "installed" if base in installed else "NOT INSTALLED"


def build_plan(request, reg, engine=None, installed=None, declared=None, risk=None):
    intents, scored, entities, juris, flags, multi, parallel, unknown_ent, rq = classify(request, reg)
    suggestions = classify.last_suggestions
    classification = "inferred by keyword signals"
    if declared:
        classification = "declared by the caller (Claude or the CAE), not inferred"
        bad = [i for i in declared.get("intents", []) if i not in reg["intents"]]
        if bad:
            sys.exit(f"Unknown intent(s) {bad}. Valid: {sorted(reg['intents'])}")
        if declared.get("intents"):
            intents = [{"intent": i, "score": 3, "signals": ["declared"], "playbook": reg["intents"][i]["playbook"]} for i in dict.fromkeys(declared["intents"])]
            seen_pb = set(); uniq_i = []
            for c in intents:
                if c["playbook"] not in seen_pb:
                    seen_pb.add(c["playbook"]); uniq_i.append(c)
            intents = uniq_i
        for code in declared.get("entities", []):
            if code not in reg["entities"]:
                sys.exit(f"Unknown entity {code}. Valid: {sorted(reg['entities'])}")
            if code not in [e["code"] for e in entities]:
                entities.append({"code": code, "signals": ["declared"]})
        for j in declared.get("jurisdictions", []):
            if j not in reg["jurisdictions"]:
                sys.exit(f"Unknown jurisdiction {j}. Valid: {sorted(reg['jurisdictions'])}")
            if j not in [x["jurisdiction"] for x in juris]:
                juris.append({"jurisdiction": j, "signals": ["declared"]})
        for f_ in declared.get("flags", []):
            if f_ not in reg["risk_flags"]:
                sys.exit(f"Unknown flag {f_}. Valid: {sorted(reg['risk_flags'])}")
            flags.setdefault(f_, ["declared"])
    pol = reg["policy"]
    policy_flags = detect_policy(request, reg)
    engine = engine or pol["default_methodology_engine"]
    primary, support, notes = resolve_entity_skills(entities, juris, reg)
    warnings = []

    if not intents:
        return {"request": request, "intents": [], "policy_flags": policy_flags, "confidence": "none", "suggestions": suggestions,
                "warnings": [f"POLICY: {v['response']}" for v in policy_flags.values()] + ["No intent recognised by the keyword signals. Read the request yourself first; if still unclear ask the CAE one question about the outcome wanted (deliverable, entity, stage)." + (" Closest candidates by similarity (a weak signal): " + ", ".join(f"{x['intent']} ({x['similarity']})" for x in suggestions) if suggestions else "")],
                "entities": entities, "jurisdictions": juris, "flags": flags}
    playbooks = sorted((reg["playbooks"][i["playbook"]] | {"id": i["playbook"]} for i in intents), key=lambda p: p["order"])
    # conductor
    n_work = len(playbooks)
    if n_work >= 2:
        warnings.append("Multiple workstreams detected (" + ", ".join(p["id"] for p in playbooks) + "). Confirm the order and which one starts first.")
    if multi:
        conductor = "gia-core:project-memory"
        why = "multi-session / multi-entity memory need"
    elif parallel or n_work >= 3:
        conductor = "gia-core-agents"
        why = "3+ workstreams or explicit delegation to the gia-core agents (alpha-scout, beta-analyst, delta-validator, portfolio-qa-challenger) (subagents exist only in Claude Code/Cowork; in plain chat the router runs them sequentially)"
    elif n_work == 2:
        conductor = "gcgo-in-thread"
        why = "two sequential workstreams; GCGO runs the playbooks in order"
    else:
        conductor = "none (direct routing)" if all(len(p["steps"]) <= 3 for p in playbooks) else "gcgo-in-thread"
        why = "single workstream"

    entity_skill_ids = primary
    hr_skills = [s for s in primary if "pack-" in s]
    steps_out = []
    for pb in playbooks:
        block = {"playbook": pb["id"], "name": pb["name"], "confidential": pb.get("confidential", False),
                 "external": pb.get("external", False), "steps": []}
        for st in pb["steps"]:
            sid = st["skill"]
            if sid == "{engine}":
                sids = [engine]
            elif sid == "{entity_skills}":
                if not entity_skill_ids and st.get("optional"):
                    continue
                sids = entity_skill_ids or ["(none detected: ask which entity/jurisdiction)"]
            elif sid == "{juris_hr_skills}":
                sids = hr_skills or primary or ["(none detected: ask which jurisdiction)"]
            else:
                sids = [sid]
            for s in sids:
                c = canonical(s, reg, installed)
                note = None
                if c != s:
                    note = f"{s} is legacy/duplicate; using {c}"
                elif reg["skills"].get(s, {}).get("status") in ("legacy", "stale", "duplicate"):
                    note = f"status {reg['skills'][s]['status']}"
                block["steps"].append({
                    "skill": c, "mode": st.get("mode"), "purpose": st["purpose"], "gate": st.get("gate"),
                    "optional": st.get("optional", False), "execution": st.get("execution", "in-thread"),
                    "install": status_of(c, reg, installed), "note": note})
        steps_out.append(block)

    # governors
    governors = []
    if any(pb.get("evidence_context") for pb in playbooks):
        governors.append("gia-core:iron-rules")
    governors.append("gia-core:runtime-guard (hooks, when installed)")
    governors.append("gia-core:self-learning (on any correction)")
    if any(pb.get("confidential") for pb in playbooks) or "confidential_investigation" in flags:
        warnings.append("CONFIDENTIAL MATTER: need-to-know only; evidence preservation first; no web or personal-data lookups on named people without the CAE's approval; allegation wording stays blocked until the CAE approves.")
    if "external_distribution" in flags:
        warnings.append("External distribution: drafts only. Use gia-report-qa:gia-external-release, expect legal/counsel review, the CAE signs off and sends.")
    if "legal_interpretation" in flags:
        warnings.append("Legal interpretation asked: Claude can summarise sourced requirements; legal conclusions go to counsel.")
    if "personal_data" in flags:
        warnings.append("Personal data cues: mask identifiers unless essential; confirm entity data-protection rules before uploading.")
    if "irreversible_action" in flags:
        warnings.append("Action words (send/publish/delete/archive/rename): GCGO prepares, the CAE confirms; nothing is executed outside the chat.")
    if "rating_or_conclusion" in flags:
        warnings.append("A rating or conclusion is implied: reserved to the CAE. Claude returns options and evidence, not the call.")
    for v in policy_flags.values():
        warnings.insert(0, f"POLICY: {v['response']}")
    for n in notes:
        warnings.append(n)
    for e in entities:
        on = reg["entities"].get(e["code"], {}).get("open_note")
        if on:
            warnings.append(f"Entity {e['code']}: {on}")
    for u in unknown_ent:
        warnings.append(f"Entity '{u}' appears in skill text but is not in the GIA entity taxonomy; confirm scope and which specialist applies.")
    if any(j["jurisdiction"].startswith("india") for j in juris) is False and any(w in request.lower() for w in ("karnataka", "gujarat", "puducherry", "pondicherry", "haryana", "uttar pradesh", "andhra", "telangana", "kerala")):
        warnings.append("State/UT outside Tamil Nadu, Maharashtra and Puducherry named: no jurisdiction skill covers it; verify statutory content from official sources.")
    elif re.search(r"karnataka|gujarat|haryana|uttar pradesh|andhra|telangana|kerala", request.lower()):
        warnings.append("State/UT outside Tamil Nadu, Maharashtra and Puducherry named: the TN/MH skills do not cover it; verify statutory content from official sources.")
    if installed:
        missing = [s["skill"] for b in steps_out for s in b["steps"] if s["install"] == "NOT INSTALLED"]
        for m in sorted(set(missing)):
            warnings.append(f"{m} is referenced but not installed: use the fallback or ask the CAE.")

    result = {"request": request, "intents": intents, "entities": entities, "jurisdictions": juris, "flags": flags,
            "classification": classification, "routing_question": rq, "policy_flags": policy_flags, "confidence": ("high" if max(i["score"] for i in intents) >= 3 else "medium" if max(i["score"] for i in intents) == 2 else "low"), "suggestions": suggestions, "engine": engine, "conductor": conductor, "conductor_reason": why, "governors": governors,
            "entity_specialists": entity_skill_ids, "support_skills": support, "plan": steps_out, "warnings": warnings}
    result["team_brief"] = team_brief(result, risk)
    return result


def _selector():
    import importlib.util
    spec = importlib.util.spec_from_file_location("select_model_effort", SELECTOR)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def team_brief(plan, risk=None):
    """Rule 31/32 step: a Chief Specialist plans and delegates; each delegated step gets a model tier and effort from the Rule 32 matrix.
    Selection is keyword based on the step purpose; the planner confirms. Independent QA is always a different agent from the preparer."""
    if not MATRIX.exists() or not SELECTOR.exists():
        return {"available": False, "note": "Rule 32 matrix not found next to this skill; choose model and effort with gia-core:model-effort-routing."}
    sel = _selector()
    m = sel.load(MATRIX)
    rows, seen = [], set()
    for b in plan.get("plan", []):
        for s in b["steps"]:
            if s["skill"] in ("gia-core:gcgo-router",) or s["skill"].startswith(("(", "{")):
                continue
            key = (b["playbook"], s["skill"], s["purpose"][:40])
            if key in seen:
                continue
            seen.add(key)
            r = sel.select(s["skill"].split(":")[-1].replace("-", " ") + " " + s["purpose"], risk, m)
            rows.append({"playbook": b["playbook"], "skill": s["skill"], "task": r["task"], "tier": r["tier"], "model": r["model"], "effort": r["effort"],
                         "never_downgrade": r["never_downgrade"], "gate": bool(s.get("gate"))})
    return {"available": True, "chief_specialist": "The planner-tier model acts as Chief Specialist: it plans, briefs and signs off; it does not execute without the CAE's approval (Rule 32).",
            "delegations": rows,
            "independent_qa": "Independent QA re-performs key numbers before drafting and reviews the draft on a different agent from the preparer (Rules 31, 32).",
            "rules": m.get("operating_rules", [])[:3]}


def render(plan, reg):
    o = ["# Routing plan", "", f"**Request:** {plan['request']}", "", "## Work Requirement Profile"]
    if not plan["intents"]:
        for k, v in plan.get("policy_flags", {}).items():
            o.append(f"- **POLICY STOP ({k})**: {v['response']}")
        o += ["- No intent recognised.", ""] + [f"- {w}" for w in plan["warnings"] if not w.startswith("POLICY")]
        return "\n".join(o)
    for k, v in plan.get("policy_flags", {}).items():
        o.append(f"- **POLICY STOP ({k})**: {v['response']}")
    o.append(f"- Classification: {plan.get('classification', 'n/a')}")
    o.append(f"- Router confidence: {plan.get('confidence', 'n/a')}" + (" (a single weak keyword matched: confirm the intent before acting)" if plan.get("confidence") == "low" else ""))
    if plan.get("confidence") in ("low", "medium") and plan.get("suggestions"):
        o.append("- Other candidate intents by similarity (weak signal): " + ", ".join(f"{x['intent']} ({x['similarity']})" for x in plan["suggestions"]))
    o.append("- Intents: " + "; ".join(f"{i['intent']} (score {i['score']}: {', '.join(i['signals'])})" for i in plan["intents"]))
    o.append("- Entities: " + (", ".join(e["code"] for e in plan["entities"]) or "none detected"))
    o.append("- Jurisdictions: " + (", ".join(j["jurisdiction"] for j in plan["jurisdictions"]) or "none detected"))
    o.append("- Risk flags: " + (", ".join(plan["flags"]) or "none"))
    if plan.get("routing_question"):
        o.append("- This is a routing question: the plan below IS the answer (which skills, in what order, who decides).")
    o += ["", "## Command structure",
          f"- Conductor: **{plan['conductor']}** ({plan['conductor_reason']})",
          f"- Methodology engine (one only): **{plan['engine']}**",
          "- Governors always on: " + "; ".join(plan["governors"])]
    if plan.get("entity_specialists"):
        o.append("- Entity / jurisdiction specialists (load for criteria knowledge): " + ", ".join(f"`{x}`" for x in plan["entity_specialists"]))
    for b in plan["plan"]:
        o += ["", f"## {b['playbook']}: {b['name']}" + ("  [CONFIDENTIAL]" if b["confidential"] else "") + ("  [EXTERNAL]" if b["external"] else "")]
        for i, s in enumerate(b["steps"], 1):
            tag = " (optional)" if s["optional"] else ""
            mode = f" mode {s['mode']}" if s["mode"] else ""
            ex = f" [{s['execution']}]" if s["execution"] != "in-thread" else ""
            inst = "" if s["install"] in ("n/a", "installed", "unchecked") else f"  <{s['install']}>"
            o.append(f"{i}. `{s['skill']}`{mode}{tag}{ex}{inst}: {s['purpose']}")
            if s["note"]:
                o.append(f"   - note: {s['note']}")
            if s["gate"]:
                o.append(f"   - GATE: {s['gate']}")
    if plan.get("support_skills"):
        o += ["", "Support skills available (load only if the scope needs them): " + ", ".join(f"`{x}`" for x in plan["support_skills"])]
    if plan["warnings"]:
        o += ["", "## Warnings and questions for the CAE"] + [f"- {w}" for w in plan["warnings"]]
    tb = plan.get("team_brief")
    if tb:
        o += ["", "## Team and model brief (Rule 31/32)"]
        if not tb.get("available"):
            o.append("- " + tb["note"])
        else:
            o.append("- " + tb["chief_specialist"])
            for r in tb["delegations"]:
                o.append(f"- {r['playbook']} `{r['skill']}`: {r['model']}, effort {r['effort']}" + (" [never downgrade]" if r["never_downgrade"] else ""))
            o.append("- " + tb["independent_qa"])
    o += ["", "Human decision points are marked GATE. Nothing here is approved until the CAE confirms the plan."]
    return "\n".join(o)


def cmd_explain(sid, reg):
    sk = reg["skills"].get(sid)
    if not sk:
        for fam, spec in reg["family_patterns"].items():
            if re.match(fam, sid):
                print(json.dumps({"family": spec, "id": sid}, indent=2))
                return
        sys.exit(f"{sid} not in registry.")
    print(json.dumps({sid: sk}, indent=2, ensure_ascii=False))
    users = [k for k, v in reg["skills"].items() if sid in (v.get("requires") or []) or sid in (v.get("supersedes") or []) or v.get("canonical") == sid]
    used_in = [p for p, spec in reg["playbooks"].items() if any(st["skill"] == sid for st in spec["steps"])]
    print("\nreferenced by registry entries:", ", ".join(users) or "none")
    print("used in playbooks:", ", ".join(used_in) or "none")


def cmd_graph(pid, reg):
    pb = reg["playbooks"].get(pid)
    if not pb:
        sys.exit(f"Unknown playbook {pid}.")
    print("flowchart TD")
    prev = "START"
    print(f'  START(["{pid}: {pb["name"]}"])')
    for i, st in enumerate(pb["steps"], 1):
        nid = f"S{i}"
        label = st["skill"].replace('"', "'") + (f" · mode {st['mode']}" if st.get("mode") else "")
        shape = f'{nid}["{label}"]' if not st.get("optional") else f'{nid}("{label} (optional)")'
        print(f"  {shape}")
        print(f"  {prev} --> {nid}")
        prev = nid
        if st.get("gate"):
            g = f"G{i}"
            print(f'  {g}{{"{st["gate"][:60]}"}}')
            print(f"  {prev} --> {g}")
            prev = g
    print(f"  {prev} --> END([Done])")


def cmd_playbooks_md(reg):
    o = ["# Playbooks (generated from capability-registry.json; edit the registry, not this file)", "",
         "Contents: " + "; ".join("%s %s" % (pid, pb["name"].split(":")[0]) for pid, pb in sorted(reg["playbooks"].items())), ""]
    for pid, pb in sorted(reg["playbooks"].items()):
        flags = [x for x in ("confidential", "external") if pb.get(x)]
        o += [f"## {pid}: {pb['name']}" + (f"  [{', '.join(flags).upper()}]" if flags else ""), ""]
        for i, st in enumerate(pb["steps"], 1):
            mode = f" mode {st['mode']}" if st.get("mode") else ""
            opt = " (optional)" if st.get("optional") else ""
            ex = f" [{st['execution']}]" if st.get("execution") else ""
            o.append(f"{i}. `{st['skill']}`{mode}{opt}{ex}: {st['purpose']}")
            if st.get("gate"):
                o.append(f"   - GATE: {st['gate']}")
        o.append("")
    print("\n".join(o))


def cmd_selftest(reg):
    """Regression check on bundled scenarios. The first two files must pass 100% (they define expected behaviour);
    the info sets were used to diagnose weaknesses and are reported for tracking, not as accuracy claims."""
    base = HERE.parent / "data" / "regression"
    if not base.exists():
        sys.exit("No regression scenarios found next to the registry.")
    gate_fail = False
    for f in sorted(base.glob("*.json")):
        sc = json.loads(f.read_text(encoding="utf-8"))
        ok = 0
        bad = []
        for x in sc:
            e = x["expect"]
            plan = build_plan(x["request"], reg, None, None)
            got = [i["intent"] for i in plan.get("intents", [])]
            steps = [st["skill"] for b in plan.get("plan", []) for st in b["steps"]] + list(plan.get("entity_specialists", []))
            warns = " ".join(plan.get("warnings", [])).lower()
            probs = []
            if e.get("no_route") and got: probs.append("routed")
            for i in e.get("intents", []):
                if i not in got: probs.append("intent " + i)
            if e.get("intents_any") and not any(i in got for i in e["intents_any"]): probs.append("intents_any")
            for c in e.get("entities", []):
                if c not in [y["code"] for y in plan.get("entities", [])]: probs.append("entity " + c)
            for j in e.get("jurisdictions", []):
                if j not in [y["jurisdiction"] for y in plan.get("jurisdictions", [])]: probs.append("jurisdiction " + j)
            for fl in e.get("flags", []):
                if fl not in plan.get("flags", {}): probs.append("flag " + fl)
            for fl in e.get("policy_flags", []):
                if fl not in plan.get("policy_flags", {}): probs.append("policy " + fl)
            for sk in e.get("skills_include", []):
                if sk not in steps: probs.append("skill " + sk)
            for w in e.get("warn_contains", []):
                if w.lower() not in warns: probs.append("warning " + w)
            if e.get("conductor_in") and plan.get("conductor") not in e["conductor_in"]: probs.append("conductor")
            ok += not probs
            if probs: bad.append((x["id"], probs))
        gate = not f.name.startswith("router_info")
        print(f"{f.name}: {ok}/{len(sc)}" + ("" if gate else "  (informational: diagnosed set, not an accuracy claim)"))
        if gate and ok != len(sc):
            gate_fail = True
            for b in bad[:10]: print("   FAIL", b)
    print("\nRegression gate:", "FAILED" if gate_fail else "passed")
    print("Measured accuracy on unseen natural requests is lower than these numbers: see SKILL.md (strict 29-42%, with top-3 suggestions 78-82%).")
    sys.exit(1 if gate_fail else 0)


def main():
    ap = argparse.ArgumentParser(description="GCGO router")
    ap.add_argument("--registry")
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("route")
    r.add_argument("request")
    r.add_argument("--engine")
    r.add_argument("--json", action="store_true")
    r.add_argument("--no-install-check", action="store_true")
    r.add_argument("--risk", choices=["L0", "L1", "L2", "L3", "L4"], help="runtime risk tier; raises effort in the Rule 32 brief, never lowers it")
    r.add_argument("--intents", help="comma-separated intents you have classified (see list-intents); replaces keyword inference")
    r.add_argument("--entities", help="comma-separated entity codes, e.g. MKPC,NEPHRO")
    r.add_argument("--jurisdictions", help="comma-separated jurisdictions, e.g. india-mh,malaysia")
    r.add_argument("--flags", help="comma-separated risk flags, e.g. confidential_investigation")
    r.add_argument("--profile", help="JSON file with intents, entities, jurisdictions, flags")
    e = sub.add_parser("explain")
    e.add_argument("skill")
    g = sub.add_parser("graph")
    g.add_argument("playbook")
    sub.add_parser("list-playbooks")
    sub.add_parser("playbooks-md")
    sub.add_parser("selftest")
    sub.add_parser("list-intents")
    a = ap.parse_args()
    reg = load_registry(a.registry)
    if a.cmd == "route":
        inst = None if a.no_install_check else (installed_set() or None)
        declared = None
        if a.profile:
            try:
                declared = json.loads(Path(a.profile).read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as e:
                sys.exit(f"Could not read profile {a.profile}: {e}")
        elif a.intents or a.entities or a.jurisdictions or a.flags:
            sp = lambda v: [x.strip() for x in v.split(",") if x.strip()] if v else []
            declared = {"intents": sp(a.intents), "entities": sp(a.entities), "jurisdictions": sp(a.jurisdictions), "flags": sp(a.flags)}
        plan = build_plan(a.request, reg, a.engine, inst, declared, a.risk)
        print(json.dumps(plan, indent=2, ensure_ascii=False) if a.json else render(plan, reg))
    elif a.cmd == "explain":
        cmd_explain(a.skill, reg)
    elif a.cmd == "graph":
        cmd_graph(a.playbook, reg)
    elif a.cmd == "list-intents":
        for k in sorted(reg["intents"]):
            print(f"{k:24s} {reg.get('intent_descriptions', {}).get(k, '')}  -> {reg['intents'][k]['playbook']}")
        print("\nentities: " + ", ".join(sorted(reg["entities"])) + "\njurisdictions: " + ", ".join(sorted(reg["jurisdictions"])) + "\nflags: " + ", ".join(sorted(reg["risk_flags"])))
    elif a.cmd == "selftest":
        cmd_selftest(reg)
    elif a.cmd == "playbooks-md":
        cmd_playbooks_md(reg)
    else:
        for pid, pb in sorted(reg["playbooks"].items()):
            print(f"{pid}: {pb['name']}")


if __name__ == "__main__":
    main()
