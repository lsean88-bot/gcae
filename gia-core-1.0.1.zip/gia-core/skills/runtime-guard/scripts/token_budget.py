#!/usr/bin/env python3
"""Estimate the context-token cost of what GIA loads. ESTIMATE ONLY (characters / 4); no tokenizer is available offline.
Always loaded: skill name+description. Loaded on invocation: SKILL.md body. Per prompt: the hook's route message. Skills are read from the whole plugin (skills/*/SKILL.md)."""
import os, re, glob, json, sys
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
est = lambda s: round(len(s) / 4)
def measure():
    skills = {}
    for p in sorted(glob.glob(os.path.join(ROOT, "skills/*/SKILL.md"))):
        t = open(p, encoding="utf-8").read(); fm = re.match(r"^---\n(.*?)\n---\n", t, re.S).group(1)
        skills[os.path.basename(os.path.dirname(p))] = {"frontmatter": est(fm), "total": est(t)}
    return {"always_loaded": sum(v["frontmatter"] for v in skills.values()), "skills": skills,
            "router": skills["gcgo-router"]["total"], "heaviest_non_router": max(v["total"] for k, v in skills.items() if k != "gcgo-router")}
if __name__ == "__main__":
    m = measure(); print(json.dumps(m, indent=1)) if "--json" in sys.argv else print("always-loaded ~%d tokens; router skill ~%d; heaviest other skill ~%d (estimates)" % (m["always_loaded"], m["router"], m["heaviest_non_router"]))
