#!/usr/bin/env python3
"""Render core/RUNTIME_CONTROLS.md from core/policy/runtime-controls.json (single source).

  python3 -I render_runtime_controls.py          write the file
  python3 -I render_runtime_controls.py --check  exit 1 when the file is stale
"""
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
OUT = os.path.join(ROOT, "core", "RUNTIME_CONTROLS.md")


def render():
    d = json.load(open(os.path.join(ROOT, "core/policy/runtime-controls.json"), encoding="utf-8"))
    out = ["# Runtime controls GR-01 to GR-%02d (%s)" % (len(d["rules"]), d["version"]), "",
           "These are guard controls, not the Iron Rules. The canonical Iron Rules live in `gia-core:iron-rules`; the mapping is in `skills/runtime-guard/references/gr-mapping.md`. "
           "MECHANICAL controls are enforced by hooks and proven by tests and mutants; ADVISORY controls only warn; BEHAVIOURAL controls cannot be enforced by hooks and are verified from live transcripts; "
           "PROCESS controls govern acceptance. Generated from `core/policy/runtime-controls.json`; do not edit by hand.", ""]
    for r in d["rules"]:
        out.append("## %s %s [%s]" % (r["id"], r["title"], r["type"]))
        out.append(r["rule"])
        out.append("")
        out.append("- Enforcement: %s" % r["enforcement"])
        if r.get("maps_to_rules"):
            out.append("- Serves Iron Rules: %s" % ", ".join(str(n) for n in r["maps_to_rules"]))
        if r["stop_reasons"]:
            out.append("- Stop reasons: %s" % ", ".join(r["stop_reasons"]))
        if r["tests"]:
            out.append("- Tests: %s" % ", ".join(r["tests"]))
        if r.get("tests_ext"):
            out.append("- Tests: %s" % ", ".join(r["tests_ext"]))
        n = len(r["mutants"]) + len(r.get("mutants_ext", []))
        if n:
            out.append("- Mutants proving it: %d" % n)
        if r["uat"]:
            out.append("- Live UAT: %s" % ", ".join(r["uat"]))
        if r.get("template"):
            out.append("- Template: %s in core/output-templates.md" % r["template"])
        out.append("")
    return "\n".join(out)


if __name__ == "__main__":
    text = render()
    if "--check" in sys.argv:
        ok = os.path.exists(OUT) and open(OUT, encoding="utf-8").read() == text
        print("RUNTIME_CONTROLS.md " + ("current" if ok else "STALE"))
        sys.exit(0 if ok else 1)
    open(OUT, "w", encoding="utf-8", newline="\n").write(text)
    print("wrote", OUT)
