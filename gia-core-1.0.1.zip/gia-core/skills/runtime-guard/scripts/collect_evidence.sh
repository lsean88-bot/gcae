#!/usr/bin/env bash
# Collect the UAT evidence package (read-only on source; raw logs are copied, never edited).
# Usage: skills/runtime-guard/scripts/collect_evidence.sh <project_dir_with_.gia> <plugin_root> <out_dir>
set -u
PROJ="${1:?project dir}"; PLUG="${2:?plugin root}"; OUT="${3:?output dir}"
mkdir -p "$OUT/raw" "$OUT/env"
[ -d "$PROJ/.gia" ] && cp -R "$PROJ/.gia" "$OUT/raw/gia" || echo "NO .gia DIRECTORY FOUND (guard never ran)" > "$OUT/raw/NO_GUARD_EVIDENCE.txt"
{ echo "collected_utc=$(date -u +%FT%TZ)"; echo "uname=$(uname -a)"; echo "python=$(python3 --version 2>&1 || python --version 2>&1)";
  echo "claude_version=$(claude --version 2>&1 | head -1)"; echo "plugin_root=$PLUG"; } > "$OUT/env/environment.txt"
( cd "$PLUG" && find . -type f -not -path './.git/*' -not -path './.gia/*' -not -name '*.pyc' -print0 | sort -z | xargs -0 sha256sum ) > "$OUT/env/plugin_files.sha256"
sha256sum "$OUT/env/plugin_files.sha256" | cut -d' ' -f1 > "$OUT/env/plugin_tree_sha256.txt"
for s in "$OUT"/raw/gia/sessions/*/; do [ -d "$s" ] || continue
  GIA_STATE_DIR="$OUT/raw/gia" python3 "$PLUG/hooks/gia_guard.py" verify --dir "$OUT/raw/gia" > "$OUT/env/chain_verify_$(basename "$s").json" 2>&1 || echo "CHAIN VERIFY FAILED $(basename "$s")" >> "$OUT/env/chain_verify_FAILURES.txt"
done
echo "Add by hand (not capturable here): exact prompts, exact responses, Claude Code transcript, screenshots, scorecard." > "$OUT/MANUAL_ITEMS.txt"
( cd "$OUT" && find . -type f -not -name 'EVIDENCE_MANIFEST.sha256' -print0 | sort -z | xargs -0 sha256sum ) > "$OUT/EVIDENCE_MANIFEST.sha256"
echo "evidence package: $OUT  ($(wc -l < "$OUT/EVIDENCE_MANIFEST.sha256") files hashed)"
