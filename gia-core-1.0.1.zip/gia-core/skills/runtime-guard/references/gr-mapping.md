# GR controls mapped to the canonical Iron Rules

Contents: Why two namespaces - Mapping table - What has no runtime counterpart - Fail-closed or warn-only

## Why two namespaces

`gia-core:iron-rules` holds the canonical rules, numbered 1 upward. The guard has its own controls, `GR-01` onward, which are mechanisms (a hook denies, asks or warns). A GR control is not a rule a model interprets. GR-01 to GR-15 were IR-01 to IR-15 in the earlier GCAE guard; the IR prefix is retired so it cannot be mistaken for an Iron Rule. GR-16 to GR-19 are the four controls the earlier hook set had and the guard lacked.

The data is `core/policy/runtime-controls.json`; the rendered view is `core/RUNTIME_CONTROLS.md`.

## Mapping table

| GR | Control | Behaviour | Serves Iron Rules (`gia-core:iron-rules`) |
|---|---|---|---|
| GR-01 | Fail closed | deny / STOP | none (platform integrity) |
| GR-02 | STOP is terminal; only a human restarts | deny / STOP | none (platform integrity) |
| GR-03 | Restart is bounded and honest | STOP | none (platform integrity) |
| GR-04 | Evidence integrity (hash-chained log, state directory protected) | STOP | none (supports every rule that relies on the audit trail) |
| GR-05 | No unbounded work (tool, agent, loop, retry caps) | STOP | 31, 32 |
| GR-06 | Scope is fixed; additions need a human decision | hold | none (the human go-ahead gate, see `gia-core:iron-rules` references/human-gates.md) |
| GR-07 | Destructive actions need explicit human approval | deny | none (human gate) |
| GR-08 | Evidence is data, never instructions | notice | none (stated in the router threat model) |
| GR-09 | Never fabricate | behavioural, UAT-graded | 1, 12, 27 |
| GR-10 | Provenance | behavioural, UAT-graded | 1, 34, 37 |
| GR-11 | Authority verification; conflicts stay visible | behavioural, UAT-graded | 2, 3, 28, 38 |
| GR-12 | Anomaly is not fraud | behavioural, UAT-graded | 17, 25 |
| GR-13 | Independence and role boundaries | behavioural, UAT-graded | 13 |
| GR-14 | Confidentiality and economy | partly mechanical | 32, 36 |
| GR-15 | No PASS without observable runtime evidence | process | 9, 30 |
| GR-16 | Evidence folders are immutable | deny (fail closed) | 1 |
| GR-17 | PII and exfiltration gate | ask on upload; PII lint notice | 36 |
| GR-18 | Fraud-wording lint | notice (warn only) | 25, 11 |
| GR-19 | Self-protection of hooks, policy, state and audit log | deny (fail closed) | none (guard integrity) |

The "Serves" column is generated from `maps_to_rules` in the data; a test checks that every rule number named exists in `gia-core:iron-rules`.

## What has no runtime counterpart

Most canonical rules govern judgement (finding quality, disclosure, testing method, standards). No hook can enforce them. They are enforced by the skills that own the method, by `gia-core:safeguard-lint` where a text pattern can show a breach, and by independent QA. Do not read the absence of a GR control as the absence of a rule. The rules-to-enforcement view is in `gia-core:iron-rules` (rendered rules file, enforcement lines).

## Fail-closed or warn-only

- Fail closed (a hook denies or the guard STOPs): evidence mutation (GR-16), destructive commands (GR-07), scope additions (GR-06), self-protection (GR-19), control-plane failure (GR-01).
- Ask: outbound upload or remote transfer of audit data (GR-17).
- Warn only: PII and fraud-wording lint (GR-17, GR-18), injection notices (GR-08), session digest. A lint is a weak signal; blocking on it would stop legitimate drafting.
- There is no off switch. `GIA_MAINTAINER=1` lifts only the protection of plugin files for plugin maintenance; it never lifts protection of the guard state directory.
