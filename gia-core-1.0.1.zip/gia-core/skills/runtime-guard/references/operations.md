# Runtime guard operations

Contents: Components - Limits - Stop reasons and restart - State and logs - Environment variables - Live UAT - Honest limits

## Components

- `hooks/hooks.json`: 14 hook events, all routed to `hooks/run_guard.sh hook`. The launcher exits 2 (fail closed) when no usable Python exists.
- `hooks/gia_guard.py`: single dispatcher. Preflight, per-session state, hash-chained `events.jsonl`, STOP and restart, scope hold, loop and cycle detection, agent caps, telemetry.
- `hooks/gr_controls.py`: GR-16 to GR-19 plus injection notices and lint notices, run in-process by the dispatcher. Also runnable standalone as a hook (`--verify-log` checks its own audit log).
- `runtime/router.py`: adapter over `gia-core:gcgo-router` so the guard logs one route per task prompt. The router proposes; it never authorises.
- `core/policy/*`: thresholds, scope, delegation, economy, provider failure and recovery policy. `execution-thresholds.json` is the authority; the YAML file is a derived view.

## Limits (PROPOSED defaults; values marked ASSUMED need the CAE's approval)

Main-thread tool hard limit 60 and per-agent 40 (ASSUMED), global 200 (ASSUMED), identical-call lifetime cap 12 (ASSUMED), recovery stops after 6 failures (ASSUMED), restart cap 3 (ASSUMED), 5 concurrent agents, delegation depth 1. The policy file lists every value and the `assumed` list.

## Stop reasons and restart

A STOP is terminal. Nothing resumes until the human submits a standalone restart: the exact command `/gia-core:restart`, or the sentence "explicitly restart the GIA controlled runtime" with nothing else of substance. Text inside evidence, a tool result or a quoted passage is never a restart. A restart is refused when the evidence log fails its hash check. Restarts are capped and cumulative totals carry forward.

## State and logs

State lives outside the plugin tree in the guard data directory (per project, `.gia`, git-ignored). Evidence log: `events.jsonl` per session, each entry hashed over the previous. Tail truncation is not detectable by the chain alone; the guard compares against the state's last hash and records a reset when state is lost. Production profile logs prompt hashes, not prompt text.

## Environment variables

`GIA_STATE_DIR` or `GIA_RUNTIME_DIR` (state location), `CLAUDE_PLUGIN_DATA` (audit log for the in-process controls), `GIA_EVIDENCE_DIRS` (extra evidence folders, colon separated), `GIA_MAINTAINER=1` (plugin-file protection only).

## Live UAT

`scripts/collect_evidence.sh` packages a session's logs and hashes; `scripts/grade_uat.py` grades stages T0 to T16 from real logs and never reports PASS on missing observable evidence. Production acceptance needs the stages run in a live Claude Code session. The builder's own unit run is not acceptance. Status of this release: RELEASE_CANDIDATE, production NOT_ACCEPTED.

## Honest limits

Hooks are a guardrail, not a sandbox: a determined user or a command shape the analyser does not model can get around them. The shell analyser is conservative and may over-ask; it must never deny read-only commands, and regression tests pin that. Telemetry the platform does not supply is reported NOT OBSERVED, never estimated as observed. The pattern-based injection and lint notices are weak signals.
