---
name: model-effort-routing
description: "Rule 32 model and effort selection: picks model tier and effort level for a task from one matrix, applies the never-downgrade list and risk-tier floor, lints agent frontmatter. Use when delegating to a subagent, writing an agent file, briefing a team, or asking which model or effort a task needs. Do NOT use for choosing which skill does the work (use gia-core:gcgo-router)."
---

# Model and Effort Routing (Rule 32)

One matrix, `data/matrix.json`, is the source. The Rule 32 section of `gia-core:iron-rules` is rendered from it. Do not copy the matrix into other files; point here.

## The matrix in brief

- **Planner tier (currently Opus):** plans, briefs, resolves conflicts, gives final judgement on opinion and ratings. Executes nothing without the CAE's approval. Never the model of an execution agent.
- **Sonnet:** professional executor. Fieldwork, reconciliations, analytics, statutory validation, fraud analytics, finding and report drafting, independent QA.
- **Haiku:** volume executor. Inventory, extraction, cleaning, lookup, template population, formatting.
- Effort is `low`, `medium` or `high`. Defaults per task are in the matrix.

## Never downgrade

Statutory validation, fraud wording, final judgement and independent QA keep their tier and effort whatever the cost pressure. A risk tier L3 or L4 from `gia-core:runtime-guard` raises effort to `high`; it never lowers it.

## How to use

1. Select: `python3 -I ${CLAUDE_PLUGIN_ROOT}/skills/model-effort-routing/scripts/select_model_effort.py select "<task description>" [--risk L3] [--json]`. The selector is keyword based and deterministic. It proposes; the planner confirms. Where no task matches it returns the default task and says so in `basis`.
2. Agent file: `python3 -I ${CLAUDE_PLUGIN_ROOT}/skills/model-effort-routing/scripts/select_model_effort.py frontmatter <task_id>` prints the `model:` line and the effort comment to paste in.
3. Lint: `python3 -I ${CLAUDE_PLUGIN_ROOT}/skills/model-effort-routing/scripts/select_model_effort.py check-agents <agents dir>` checks every agent file for an allowed model (sonnet or haiku, never opus or inherit), a one-line effort note, and Read, Grep, Glob only for QA and reviewer agents. Exit 1 on any violation.
4. `list` shows task ids, tiers and efforts.

## Operating rules

- Plan on the planner tier, execute on Sonnet or Haiku, and keep QA on a different agent from the preparer (Rule 13).
- Escalate one step up, with a reason recorded, when a lower tier returns work that fails its brief twice; do not retry the same tier a third time.
- The routing result belongs in the brief that `gia-core:gcgo-router` writes (step 3 of its loop).

## Honest limits

Keyword selection is a first pass; an unusual task can land on the default. Agent `model:` frontmatter is honoured by Claude Code and Cowork only; in plain chat the tier is advice. Effort is a note, not an enforced runtime setting.

## Files

- `data/matrix.json`: tiers, tasks, never-downgrade list, risk floor, agent frontmatter rules.
- `scripts/select_model_effort.py`: selector and agent lint.
- `references/matrix-rendered.md`: the matrix as a table, generated from the data.
- `tests/test_selector.py`: selector tests.
