# Rule 32 matrix (generated)

Generated from `data/matrix.json` by `scripts/render_matrix.py`. Do not edit by hand.

Contents: Tiers, Tasks, Risk floor

## Tiers

| Tier | Role | Default effort | Executes |
|---|---|---|---|
| Planner (currently Opus) | Master strategic planner / brain | - | no |
| Sonnet | Professional executor | medium | yes |
| Haiku | Volume executor | low | yes |

## Tasks

| Task | Tier | Effort | Never downgrade |
|---|---|---|---|
| scope_plan | planner | - |  |
| final_judgement | planner | - | yes |
| statutory_validation | sonnet | high | yes |
| fraud_wording | sonnet | high | yes |
| independent_qa | sonnet | high | yes |
| reconciliation | sonnet | high |  |
| board_drafting | sonnet | high |  |
| fieldwork | sonnet | medium |  |
| analytics | sonnet | medium |  |
| finding_report_drafting | sonnet | medium |  |
| inventory_extraction | haiku | low |  |
| search_lookup | haiku | low |  |
| template_population | haiku | low |  |

## Risk floor

- L3: effort at least high
- L4: effort at least high
- A risk tier from gia-core:runtime-guard (L0-L4) can raise effort, never lower it.
