#!/usr/bin/env python3
"""Render data/matrix.json to references/matrix-rendered.md.  --check exits 1 when the file is stale."""
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def render():
    d = json.loads((ROOT / "data" / "matrix.json").read_text(encoding="utf-8"))
    nd = set(d["never_downgrade"])
    L = ["# Rule 32 matrix (generated)", "", "Generated from `data/matrix.json` by `scripts/render_matrix.py`. Do not edit by hand.", "",
         "Contents: Tiers, Tasks, Risk floor", "", "## Tiers", "", "| Tier | Role | Default effort | Executes |", "|---|---|---|---|"]
    for k, t in d["tiers"].items():
        L.append("| %s | %s | %s | %s |" % (t["label"], t["role"], t.get("default_effort") or "-", "yes" if t["executes"] else "no"))
    L += ["", "## Tasks", "", "| Task | Tier | Effort | Never downgrade |", "|---|---|---|---|"]
    for t in d["tasks"]:
        L.append("| %s | %s | %s | %s |" % (t["id"], t["tier"], t.get("effort") or "-", "yes" if (t["id"] in nd or t.get("never_downgrade")) else ""))
    L += ["", "## Risk floor", ""]
    for k, v in d["risk_floor"].items():
        if k != "note":
            L.append("- %s: effort at least %s" % (k, v))
    L.append("- " + d["risk_floor"].get("note", ""))
    return "\n".join(L) + "\n"


def main():
    out = ROOT / "references" / "matrix-rendered.md"
    text = render()
    if "--check" in sys.argv:
        ok = out.exists() and out.read_text(encoding="utf-8") == text
        print("matrix-rendered.md " + ("current" if ok else "STALE"))
        return 0 if ok else 1
    out.parent.mkdir(exist_ok=True)
    out.write_text(text, encoding="utf-8")
    print("wrote", out)
    return 0


if __name__ == "__main__":
    sys.exit(main())
