#!/usr/bin/env python3
"""Rule 32 selector: pick the model tier and effort for a task from data/matrix.json (the single source).

  python3 -I select_model_effort.py select "reconcile the bank statements to the ledger" [--risk L3] [--json]
  python3 -I select_model_effort.py frontmatter TASK_ID            # model + effort note lines for an agent file
  python3 -I select_model_effort.py list                           # task ids, tiers, efforts
  python3 -I select_model_effort.py check-agents DIR [DIR ...]     # lint agent frontmatter against the matrix rules
Exit 0 = ok, 1 = check-agents found violations, 2 = usage or data error.

Selection is keyword based and deterministic. It proposes; the planner confirms. A risk tier (L0-L4) can raise effort, never lower it.
"""
import argparse
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
MATRIX = HERE.parent / "data" / "matrix.json"
RANK = {None: 0, "low": 1, "medium": 2, "high": 3}


def load(path=None):
    try:
        return json.loads(Path(path or MATRIX).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as e:
        sys.exit("cannot read matrix: %s" % e)


def _hit(text, sig):
    return re.search(r"(?<![a-z0-9])" + re.escape(sig) + r"(?![a-z0-9])", text) is not None


def select(text, risk=None, matrix=None):
    m = matrix or load()
    t = " " + re.sub(r"\s+", " ", (text or "").lower()) + " "
    scored = []
    for task in m["tasks"]:
        hits = [s for s in task["signals"] if _hit(t, s)]
        if hits:
            # never-downgrade tasks win ties so that economy cannot hide a protected task
            scored.append((len(hits) + (0.5 if task.get("never_downgrade") else 0), task, hits))
    scored.sort(key=lambda x: -x[0])
    if scored:
        task, hits = scored[0][1], scored[0][2]
        basis = "signals: " + ", ".join(hits)
    else:
        task = next(x for x in m["tasks"] if x["id"] == m["default_task"])
        hits, basis = [], "no signal matched; default task %s" % task["id"]
    effort = task.get("effort")
    floor = m.get("risk_floor", {}).get(risk) if risk else None
    if floor and task["tier"] != "planner" and RANK[floor] > RANK[effort]:
        effort, basis = floor, basis + "; effort raised to %s by risk tier %s" % (floor, risk)
    protected = [x["id"] for x in m["tasks"] if x.get("never_downgrade") and x["id"] != task["id"]
                 and any(_hit(t, s) for s in x["signals"])]
    return {"task": task["id"], "work": task["work"], "tier": task["tier"], "model": m["tiers"][task["tier"]]["model_alias"],
            "effort": effort, "never_downgrade": bool(task.get("never_downgrade")), "also_protected": protected,
            "executes": m["tiers"][task["tier"]]["executes"], "basis": basis, "risk": risk}


def frontmatter(task_id, matrix=None):
    m = matrix or load()
    task = next((x for x in m["tasks"] if x["id"] == task_id), None)
    if not task:
        print("unknown task id %r (use list)" % task_id, file=sys.stderr); sys.exit(2)
    if task["tier"] == "planner":
        print("task %r belongs to the planner tier; an agent file must not use it" % task_id, file=sys.stderr); sys.exit(2)
    model = m["tiers"][task["tier"]]["model_alias"]
    effort = task["effort"] or m["tiers"][task["tier"]]["default_effort"]
    return "model: %s\n# effort: %s (Rule 32%s)" % (model, effort, "; never downgrade" if task.get("never_downgrade") else "")


FM = re.compile(r"\A---\n(.*?)\n---\n", re.S)


def check_agent_file(p, m):
    rules = m["agent_frontmatter"]
    text = Path(p).read_text(encoding="utf-8")
    probs = []
    mt = FM.match(text)
    if not mt:
        return ["%s: no frontmatter" % p]
    fm = mt.group(1)
    mm = re.search(r"^model:\s*(\S+)", fm, re.M)
    if not mm:
        probs.append("%s: no model line" % p)
    else:
        model = mm.group(1).strip("\"'")
        if model in rules["forbidden_models"] or model not in rules["allowed_models"]:
            probs.append("%s: model %r not allowed (use %s)" % (p, model, "|".join(rules["allowed_models"])))
    if rules.get("effort_note_required") and not re.search(r"effort", fm + "\n" + text[mt.end():mt.end() + 600], re.I):
        probs.append("%s: no effort note" % p)
    name = re.search(r"^name:\s*(\S+)", fm, re.M)
    if name and re.search(r"(qa|review|critic|challenger|validator|auditor-of)", name.group(1), re.I):
        tl = re.search(r"^tools:\s*(.*)$", fm, re.M)
        tools = [x.strip() for x in re.split(r"[,\s]+", tl.group(1)) if x.strip()] if tl else []
        if not tools or set(tools) - set(rules["qa_agent_tools"]):
            probs.append("%s: QA/review agent tools must be only %s (found %s)" % (p, "/".join(rules["qa_agent_tools"]), tools or "none"))
    return probs


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("select")
    s.add_argument("text")
    s.add_argument("--risk", choices=["L0", "L1", "L2", "L3", "L4"])
    s.add_argument("--json", action="store_true")
    f = sub.add_parser("frontmatter")
    f.add_argument("task_id")
    sub.add_parser("list")
    c = sub.add_parser("check-agents")
    c.add_argument("dirs", nargs="+")
    a = ap.parse_args()
    m = load()
    if a.cmd == "select":
        r = select(a.text, a.risk, m)
        if a.json:
            print(json.dumps(r, indent=1))
        else:
            print("task: %(task)s | tier: %(tier)s (%(model)s) | effort: %(effort)s | never downgrade: %(never_downgrade)s\nbasis: %(basis)s" % r)
            if r["also_protected"]:
                print("also touches protected work: " + ", ".join(r["also_protected"]))
            if not r["executes"]:
                print("planner tier plans only: delegate execution to sonnet or haiku, or ask the user to approve planner execution")
        return 0
    if a.cmd == "frontmatter":
        print(frontmatter(a.task_id, m))
        return 0
    if a.cmd == "list":
        for t in m["tasks"]:
            print("%-24s %-8s %-7s %s" % (t["id"], t["tier"], t["effort"] or "-", "never-downgrade" if t.get("never_downgrade") else ""))
        return 0
    bad = []
    n = 0
    for d in a.dirs:
        for p in sorted(Path(d).glob("*.md")):
            n += 1
            bad += check_agent_file(p, m)
    for b in bad:
        print("FAIL", b)
    print("agents checked: %d, violations: %d" % (n, len(bad)))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
