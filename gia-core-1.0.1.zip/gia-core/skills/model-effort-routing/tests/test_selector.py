#!/usr/bin/env python3
"""Tests for the Rule 32 selector.  Run: python3 -I tests/test_selector.py"""
import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SEL = str(ROOT / "scripts" / "select_model_effort.py")
M = json.loads((ROOT / "data" / "matrix.json").read_text(encoding="utf-8"))
res = []


def t(name, ok):
    res.append(bool(ok))
    print(("PASS  " if ok else "FAIL  ") + name)


def run(*a):
    p = subprocess.run([sys.executable, "-I", SEL] + list(a), capture_output=True, text=True, timeout=60)
    return p.returncode, p.stdout + p.stderr


def sel(text, risk=None):
    a = ["select", text, "--json"] + (["--risk", risk] if risk else [])
    rc, out = run(*a)
    return json.loads(out) if rc == 0 else {}


# matrix shape
t("matrix has planner, sonnet, haiku", set(M["tiers"]) == {"planner", "sonnet", "haiku"})
t("planner does not execute", M["tiers"]["planner"]["executes"] is False)
t("never_downgrade lists the four protected tasks", set(M["never_downgrade"]) == {"statutory_validation", "fraud_wording", "final_judgement", "independent_qa"})
t("every never-downgrade task exists", all(x in {k["id"] for k in M["tasks"]} for x in M["never_downgrade"]))
t("forbidden models include opus and inherit", {"opus", "inherit"} <= set(M["agent_frontmatter"]["forbidden_models"]))
# selection
r = sel("validate the statutory rate and effective date")
t("statutory validation -> sonnet high", r.get("task") == "statutory_validation" and r["model"] == "sonnet" and r["effort"] == "high")
r = sel("check the fraud wording of this paragraph")
t("fraud wording -> sonnet high never_downgrade", r.get("task") == "fraud_wording" and r["effort"] == "high" and r["never_downgrade"])
r = sel("independent QA of the draft report")
t("independent QA -> sonnet high", r.get("task") == "independent_qa" and r["effort"] == "high")
r = sel("extract fields from the invoice files")
t("extraction -> haiku low", r.get("model") == "haiku" and r["effort"] == "low")
r = sel("extract fields from the invoice files", "L4")
t("risk L4 raises haiku effort to high", r.get("model") == "haiku" and r["effort"] == "high")
r = sel("extract fields from the invoice files", "L1")
t("risk L1 does not change effort", r.get("effort") == "low")
r = sel("scope and plan the engagement")
t("planning -> planner tier", r.get("tier") == "planner")
t("selection is deterministic", sel("reconcile the bank to the ledger") == sel("reconcile the bank to the ledger"))
rc, out = run("select", "qqq zzz", "--json")
t("unmatched text falls back to the default task", rc == 0 and json.loads(out)["task"] == M["default_task"])
rc, out = run("frontmatter", "fraud_wording")
t("frontmatter prints model and effort note", rc == 0 and "model: sonnet" in out and "effort" in out)
rc, out = run("frontmatter", "no_such_task")
t("unknown task id -> exit 2", rc == 2)
# agent lint
with tempfile.TemporaryDirectory() as d:
    dd = Path(d)
    (dd / "good.md").write_text("---\nname: good\ndescription: x\nmodel: sonnet\n# effort: medium\ntools: Read, Grep, Glob\n---\nbody\n")
    (dd / "bad-opus.md").write_text("---\nname: bad\ndescription: x\nmodel: opus\n# effort: high\n---\nbody\n")
    (dd / "bad-noeffort.md").write_text("---\nname: bad2\ndescription: x\nmodel: haiku\n---\nbody\n")
    rc, out = run("check-agents", str(dd))
    t("lint flags opus and missing effort note", rc == 1 and "bad-opus" in out and "bad-noeffort" in out and "good.md" not in out.replace("agents checked", ""))
    (dd / "bad-opus.md").unlink()
    (dd / "bad-noeffort.md").unlink()
    rc, out = run("check-agents", str(dd))
    t("lint passes a clean directory", rc == 0)
    (dd / "qa-reviewer.md").write_text("---\nname: qa-reviewer\ndescription: x\nmodel: sonnet\n# effort: high\ntools: Read, Write, Bash\n---\nbody\n")
    rc, out = run("check-agents", str(dd))
    t("lint flags a QA agent with write tools", rc == 1 and "qa-reviewer" in out)
rc, out = subprocess.run([sys.executable, "-I", str(ROOT / "scripts" / "render_matrix.py"), "--check"], capture_output=True, text=True).returncode, ""
t("matrix-rendered.md current", rc == 0)
print("\n%d tests, %d failed" % (len(res), res.count(False)))
sys.exit(0 if all(res) else 1)
