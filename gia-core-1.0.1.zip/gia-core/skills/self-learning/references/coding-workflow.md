# Coding workflow

Applies to any script, test, bug fix, refactor, build or technical decision in GIA work (monitor scripts, hook code, Excel and HTML generators). The five-phase cycle (Plan, Verify, Execute, Check, Log) is defined once in `gia-core:iron-rules` references/charlie-hills.md. This file adds the coding-specific habits and the lesson discipline; it does not redefine the cycle.

## Habits

- **Plan first.** For anything of three or more steps or an architectural choice, write the plan with checkable items (project file `tasks/todo.md`) before touching code, and check it with the human before building. If work goes sideways, stop and re-plan.
- **Use subagents to keep the main context clean.** One task per subagent. Route model and effort through `gia-core:model-effort-routing`.
- **Verify before done.** Never mark work complete without proof: run the test, read the log, show the behaviour, diff against the main branch where it matters. Ask whether a senior reviewer would approve.
- **Elegance, balanced.** For a non-trivial change ask whether a simpler way exists; if a fix feels hacky, do the clean one. Skip this for obvious fixes.
- **Bugs.** Given a bug report, find the root cause from the logs, errors and failing tests and fix it. No temporary fixes.
- **Simplicity and minimal impact.** Touch only what is needed. Do not add features, abstractions or error handling nobody asked for. See `karpathy-coding-principles.md`.
- **Known-positive and known-negative.** A new heuristic is finished when it gives the right answer on both a case it should catch and a case it should not, not when it runs without error.

## Lessons discipline

After any correction, log it with `scripts/log_lesson.py` (the cross-project store) and, in a coding project, also append the pattern to that project's `tasks/lessons.md`. Review the project's `tasks/lessons.md` at session start.

## Standing rules need a go-ahead

A recurring pattern may justify a rule in the project's `CLAUDE.md` or in the promoted lessons. Propose the exact wording to the CAE and wait for the go-ahead (Rule 20) before it takes effect. Do not edit `CLAUDE.md` unprompted. Triggers for a proposal: a correction that reveals a missing rule, a pattern seen twice, a project convention found during the work, a tool preference the user confirmed. Keep `CLAUDE.md` short; propose merging or deleting stale lessons.

## Self-check before marking anything done

- Plan written before implementation started?
- Tests pass, logs clean, behaviour shown?
- Would a senior reviewer approve it, honestly?
- Any correction this session logged?
- Any recurring pattern proposed for a standing rule?
- Minimal code touched, no side effects?
