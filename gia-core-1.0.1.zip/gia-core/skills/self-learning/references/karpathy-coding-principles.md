# Coding discipline: four guardrails

Adapted from the "Karpathy Guidelines" (github.com/forrestchang/andrej-karpathy-skills, MIT licensed), itself derived from Andrej Karpathy's public observations on common LLM coding pitfalls. Reproduced and adapted here as a reference companion to `charlie-hills-code`, not as a separate competing skill — see `engineering-discipline/SKILL.md` for why that separation matters and how the two fit together.

## 1. Think before coding

Don't assume. Don't hide confusion. Surface tradeoffs.

- State assumptions explicitly — if uncertain, ask rather than guess.
- If multiple interpretations exist, present them; don't silently pick one.
- If a simpler approach exists, say so — push back when warranted.
- If something is unclear, stop, name what's unclear, and ask.

## 2. Simplicity first

Minimum code that solves the problem. Nothing speculative.

- No features beyond what was asked.
- No abstractions for single-use code.
- No "flexibility" or "configurability" that wasn't requested.
- No error handling for impossible scenarios.
- If 200 lines could be 50, rewrite it.

Test: would a senior engineer call this overcomplicated? If yes, simplify.

## 3. Surgical changes

Touch only what you must. Clean up only your own mess.

- Don't "improve" adjacent code, comments, or formatting while making an unrelated change.
- Don't refactor things that aren't broken.
- Match existing style, even if you'd do it differently.
- If you notice unrelated dead code, mention it — don't delete it unasked.
- Remove imports/variables/functions that YOUR change made unused; don't remove pre-existing dead code unless asked.

Test: every changed line should trace directly to the request.

## 4. Goal-driven execution

Define success criteria. Loop until verified, don't just declare done.

- "Add validation" → "write tests for invalid inputs, then make them pass."
- "Fix the bug" → "write a test that reproduces it, then make it pass."
- "Refactor X" → "ensure tests pass before and after."
- For multi-step tasks, state a brief plan with a verify-step per item before starting.

Strong success criteria let work proceed independently; weak criteria ("make it work") require constant clarification — the same principle `charlie-hills-code`'s "Verification Before Done" section already applies, restated here as a planning-time check rather than only a completion-time one.

## Tradeoff note

These guardrails bias toward caution over speed. For trivial changes (an obvious one-line fix, a typo), use judgment — not every change needs the full checklist. The goal is reducing costly mistakes on non-trivial work, not adding ceremony to simple tasks.
