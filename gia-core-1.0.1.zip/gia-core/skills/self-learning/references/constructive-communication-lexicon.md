# Constructive Communication & Kaizen Language Lexicon

**Status note (27 September 2026):** this file did not exist before this update —
`SKILL.md` Module 16 referenced it, the old plugin coordination registry routed
to it, and Module 15's index listed it, but nothing was actually behind the reference.
That's the exact failure `gia-core:iron-rules` rule 1 exists to catch ("no finding
without named evidence") applied to a skill's own internal citations, not just to audit
findings. This is the real file, so Module 16 is now a working reference, not an
aspirational one.

## §1. Purpose

Governs *how* validated conclusions are phrased for Board, Audit Committee, Chairman,
regulator, external-auditor, or internal-comms audiences. It never governs *what* the
conclusion is. A finding is drafted once, correctly, using this lexicon for tone — not
drafted "straight" and then softened afterward.

## §2. Protected Terms — never substituted, regardless of audience

These are reported exactly as tested or determined. Rephrasing any of these into softer
language is not constructive framing — it's misstating the finding:

- Control/deficiency ratings (e.g. Critical, High, Medium, Low; CD/SD/MW classification)
- Audit opinions and conclusions
- Compliance classifications (compliant / non-compliant / partially compliant)
- Substantiated findings on the fraud ladder and their classification under the ACFE Fraud Tree
- Quantum (a confirmed financial figure, exposure, or loss amount)
- Tracker priority tags (e.g. overdue, escalated)

If a stakeholder pushes back on a Protected Term, the response is to revisit the
*evidence* (does it actually support a different rating?) — never to reword the term
while keeping the same underlying evidence and conclusion.

## §3. Constructive framing — what actually changes

What's adjustable is the surrounding narrative:

| Instead of | Use |
|---|---|
| "Management failed to implement X" | "X has not yet been implemented; the control gap this creates is [impact]" |
| "This is the third time this issue has recurred" | "This issue has recurred across three cycles — the recommended fix targets the recurring root cause, not just this instance" |
| "No evidence of review" | "No review evidence was available for the sample tested; recommend [specific control]" |
| A finding with no forward path | A finding paired with an owned, dated, evidence-linked recommendation |

Forward-looking, ownership-oriented, root-cause-focused — never blame-oriented, never
vague, never softened on the rating itself.

## §4. Where this applies

Board/AC papers, Chairman briefings, regulator and external-auditor submissions,
internal comms, and skill/eval development reports (retrospectives, lessons-learned
write-ups) — anywhere a human stakeholder, not just a working file, is the reader.
Working documents (Project Memory, the Knowledge Graph, internal QA notes) are not in
scope — precision there matters more than tone, and this lexicon should never be used
to justify vague internal notes.

## §5. Worked example

**Raw finding (working file, no lexicon applied):** "Segregation of duties failed.
Same person created and approved 14 of 20 sampled purchase orders. Deficiency: High."

**Board-facing version (lexicon applied, rating unchanged):** "Testing of purchase order
approvals identified a segregation-of-duties gap: the same individual both created and
approved 14 of 20 orders sampled. Rated High — this is a control design gap, not a
confirmed loss. Recommended fix: system-enforced dual approval above [threshold], target
[date], owner [named role]."

The rating (**High**) is identical in both. Only the narrative changed.
