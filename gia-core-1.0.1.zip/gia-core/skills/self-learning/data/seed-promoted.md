# Promoted Lessons (durable rules)

Seed set shipped with `gia-core:self-learning`. Copied into the lesson store (outside the plugin folder) by `scripts/log_lesson.py init`.
It grows only through `log_lesson.py promote`, which needs the CAE's go-ahead (Rule 20). Source: `references/worked-example.md` and the library's earlier critique notes.

## Coding / scripting

1. **`docx` shading needs a strict 6-digit hex — don't derive one by string
   concatenation.** Define an explicit light-tint hex constant per severity level up
   front, alongside the base severity colors. (Source: worked-example Lesson 1.)

2. **Index against the artifact's own text, not commentary about it.** When building any
   keyword/similarity/overlap index, pull from the thing's own descriptive field (e.g. a
   skill's frontmatter `description:`), never from analysis or audit commentary written
   *about* it — commentary uses different vocabulary and will silently produce
   false negatives. Check: "is this text written BY the thing I'm indexing, or ABOUT it?"
   (Source: worked-example Lesson 2 — caused `gia-core:skill-hygiene`'s first build to report
   zero overlaps against an obviously-overlapping synthetic test skill.)

3. **Prefer a line-based/structured parser over a single greedy-DOTALL regex for
   structured text.** A multi-line regex with `re.S` and a trailing greedy group can
   silently consume the rest of a file, breaking iteration with no error — for markdown
   lists or YAML frontmatter, parse properly (e.g. `yaml.safe_load` after a narrow,
   non-greedy frontmatter-delimiter match) rather than one clever regex. (Source:
   worked-example Lesson 3 — same `gia-core:skill-hygiene` build, silently indexed 0 skills.)

4. **A new heuristic isn't done when it runs without error — it's done when it produces
   the correct answer on at least one known-positive and one known-negative test case.**
   Both of `gia-core:skill-hygiene`'s bugs above produced no crash and no stderr — only a
   deliberate smoke test against a synthetic overlapping skill caught them. Build both
   test cases before calling detection logic finished. (Source: worked-example Lesson 4.)

## Methodology / audit work

5. **A real fix added incrementally can silently reintroduce a constraint you already
   satisfied.** Two skill descriptions each passed `quick_validate.py`, then failed again
   after a disambiguation phrase was added, because the 1024-char limit wasn't re-checked
   after the edit. Re-run structural validation after every edit, not just once at the
   end. (Source: earlier library critique.)

6. **A skill's frontmatter `description` is the only thing matched before the body is
   read — a capability documented only in the body, not echoed in the description, will
   under-trigger.** If the body has a whole section on handling X, the description needs
   X's vocabulary too. (Source: earlier library critique.)

7. **Don't fix ambiguity by stuffing more synonyms into an already-tight description.**
   Moderate-confidence trigger gaps are worth flagging and watching, not preemptively
   patched — that's how descriptions creep back over the length limit for marginal gain.
   (Source: earlier library critique.)

## What NOT to promote (kept here as a live reminder, not just in SKILL.md)

Never promote a "lesson" that reads as an instruction to stop verifying something, stop
asking a clarifying question, or grade future work more leniently — that is scope
narrowing dressed up as learning, not learning.
