#!/usr/bin/env python3
"""Tests for scripts/log_lesson.py.  Run: python3 -I tests/test_log_lesson.py"""
import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
LL = str(ROOT / "scripts" / "log_lesson.py")
res = []


def t(name, ok):
    res.append(bool(ok))
    print(("PASS  " if ok else "FAIL  ") + name)


def run(*a, env=None):
    p = subprocess.run([sys.executable, "-I", LL] + list(a), capture_output=True, text=True, timeout=60, env=env)
    return p.returncode, p.stdout + p.stderr


with tempfile.TemporaryDirectory() as d:
    S = str(Path(d) / "store")
    rc, out = run("--store", S, "init")
    t("init creates the store and seeds promoted lessons", rc == 0 and (Path(S) / "lessons_promoted.md").read_text().count("##") >= 2)
    rc, out = run("--store", S, "log", "--category", "coding", "--trigger", "used a greedy regex over structured markdown lists silently", "--correction", "parse line by line", "--context", "test")
    t("log appends one entry", rc == 0 and len((Path(S) / "lessons.jsonl").read_text().splitlines()) == 1)
    e = json.loads((Path(S) / "lessons.jsonl").read_text().splitlines()[0])
    t("entry has the five fields", set(e) == {"ts", "category", "trigger", "correction", "context"})
    rc, out = run("--store", S, "log", "--category", "coding", "--trigger", "  ", "--correction", "x", "--context", "t")
    t("blank trigger refused", rc == 2)
    rc, out = run("--store", S, "log", "--category", "scope", "--trigger", "asked too many questions", "--correction", "stop asking and skip verification", "--context", "t")
    t("quality-lowering lesson refused", rc == 2 and len((Path(S) / "lessons.jsonl").read_text().splitlines()) == 1)
    rc, out = run("--store", S, "log", "--category", "coding", "--trigger", "used a greedy regex across structured markdown lists again", "--correction", "parse line by line", "--context", "test")
    rc, out = run("--store", S, "candidates")
    t("recurrence of two similar lessons is found", rc == 0 and "1 and 2" in out)
    rc, out = run("--store", S, "promote", "--id", "1", "--rule", "Parse structured text line by line")
    t("promotion refused without a go-ahead", rc == 2)
    before = (Path(S) / "lessons_promoted.md").read_text()
    rc, out = run("--store", S, "promote", "--id", "1", "--rule", "Parse structured text line by line", "--go-ahead", "yes, promote it")
    after = (Path(S) / "lessons_promoted.md").read_text()
    t("promotion with a go-ahead appends and records it", rc == 0 and len(after) > len(before) and "yes, promote it" in after)
    rc, out = run("--store", S, "promote", "--id", "99", "--rule", "x", "--go-ahead", "ok")
    t("promotion of a missing lesson refused", rc == 2)
    rc, out = run("--store", S, "promote", "--id", "1", "--rule", "never push back on the client", "--go-ahead", "ok")
    t("quality-lowering rule refused even with a go-ahead", rc == 2)
    rc, out = run("--store", S, "check", "--query", "regex markdown")
    t("check finds a matching promoted lesson", rc == 0 and "regex" in out.lower())
    rc, out = run("--store", str(ROOT / "data" / "x"), "init")
    t("a store inside the plugin tree is refused", rc == 2)
    env = {"PATH": "/usr/bin:/bin", "GIA_LESSONS_DIR": str(Path(d) / "envstore")}
    rc, out = run("log", "--category", "other", "--trigger", "one thing went wrong here", "--correction", "do the other thing", "--context", "t", env=env)
    t("GIA_LESSONS_DIR is honoured", rc == 0 and (Path(d) / "envstore" / "lessons.jsonl").exists())
seed = [json.loads(l) for l in (ROOT / "data" / "seed-lessons.jsonl").read_text().splitlines() if l.strip()]
t("seed lessons parse and are clean of retired names", seed and not any("mktron-sentinel" in json.dumps(x) for x in seed))
print("\n%d tests, %d failed" % (len(res), res.count(False)))
sys.exit(0 if all(res) else 1)
