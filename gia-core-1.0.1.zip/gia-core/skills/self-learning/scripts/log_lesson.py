#!/usr/bin/env python3
"""log_lesson.py - the single write path for the lesson store of gia-core:self-learning.

The store lives OUTSIDE the plugin folder (plugin files are protected by the runtime guard and are replaced on update):
  1. --store DIR, else
  2. $GIA_LESSONS_DIR, else
  3. $CLAUDE_PLUGIN_DATA/lessons, else
  4. ~/.gia/lessons
Files in the store: lessons.jsonl (raw, append-only) and lessons_promoted.md (curated, grows only through `promote`).

Subcommands
  init                                      create the store, seeding promoted lessons from data/seed-promoted.md
  log --category C --trigger T --correction X --context W
  check [--query WORDS]                     print the promoted lessons (optionally only matching lines) and recurrence candidates
  candidates                                categories or triggers that recurred (2 or more) and are not yet promoted
  promote --id N --rule "text" --go-ahead "the CAE's confirming words"
                                            append a rule to lessons_promoted.md. Refused without a go-ahead (Rule 20):
                                            propose the exact wording to the CAE first, promote only after the CAE agrees.
Exit 0 ok, 2 refused or usage error.
"""
import argparse
import json
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
SEED = HERE.parent / "data" / "seed-promoted.md"

# A "lesson" that is really an instruction to lower quality or avoid friction is refused (scope narrowing dressed up as learning).
DISALLOWED = ["stop checking", "stop asking", "stop verifying", "don't verify", "do not verify", "skip verification", "never push back",
              "always agree", "lower the bar", "grade leniently", "be less strict", "skip the check", "skip qa", "no need to verify"]


def store_dir(arg=None):
    if arg:
        return Path(arg)
    for var, sub in (("GIA_LESSONS_DIR", ""), ("CLAUDE_PLUGIN_DATA", "lessons")):
        v = os.environ.get(var)
        if v:
            return Path(v) / sub if sub else Path(v)
    return Path.home() / ".gia" / "lessons"


def inside_plugin(p):
    plugin_root = HERE.parent.parent.parent.resolve()
    try:
        Path(p).resolve().relative_to(plugin_root)
        return True
    except ValueError:
        return False


def refuse(msg):
    print("REFUSED: " + msg, file=sys.stderr)
    sys.exit(2)


def disallowed(text):
    low = text.lower()
    return any(p in low for p in DISALLOWED)


def ensure(d):
    if inside_plugin(d):
        refuse("the lesson store must be outside the plugin folder (%s)" % d)
    d.mkdir(parents=True, exist_ok=True)
    pm = d / "lessons_promoted.md"
    if not pm.exists():
        pm.write_text(SEED.read_text(encoding="utf-8") if SEED.exists() else "# Promoted lessons\n", encoding="utf-8")
    (d / "lessons.jsonl").touch()
    return d


def read_raw(d):
    out = []
    f = d / "lessons.jsonl"
    if f.exists():
        for i, line in enumerate(f.read_text(encoding="utf-8").splitlines(), 1):
            try:
                e = json.loads(line)
                e["_n"] = i
                out.append(e)
            except ValueError:
                continue
    return out


def cmd_log(a):
    d = ensure(store_dir(a.store))
    for name, v in (("trigger", a.trigger), ("correction", a.correction), ("context", a.context), ("category", a.category)):
        if not v.strip():
            refuse("--%s is empty. A lesson needs content to be worth logging." % name)
    for name, v in (("trigger", a.trigger), ("correction", a.correction)):
        if disallowed(v):
            refuse("--%s reads as an instruction to lower quality or avoid friction, not a methodological correction. Tell the CAE instead of logging it." % name)
    e = {"ts": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "category": a.category, "trigger": a.trigger, "correction": a.correction, "context": a.context}
    with open(d / "lessons.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(e, ensure_ascii=False) + "\n")
    n = len(read_raw(d))
    print("Logged lesson %d to %s" % (n, d / "lessons.jsonl"))


def cmd_init(a):
    d = ensure(store_dir(a.store))
    print("Lesson store ready: %s" % d)


def toks(s):
    return {w for w in re.findall(r"[a-z]{4,}", s.lower())}


def recurrences(raw):
    """Pairs of raw lessons that share a category and at least 4 distinctive trigger words: a recurrence candidate."""
    out = []
    for i, x in enumerate(raw):
        for y in raw[i + 1:]:
            if x.get("category") == y.get("category") and len(toks(x.get("trigger", "")) & toks(y.get("trigger", ""))) >= 4:
                out.append((x["_n"], y["_n"], x.get("category")))
    return out


def cmd_check(a):
    d = ensure(store_dir(a.store))
    text = (d / "lessons_promoted.md").read_text(encoding="utf-8")
    if a.query:
        q = toks(a.query)
        paras = [p for p in re.split(r"\n\s*\n", text) if q & toks(p)]
        print("\n\n".join(paras) if paras else "No promoted lesson matches: %s" % a.query)
    else:
        print(text)
    r = recurrences(read_raw(d))
    if r:
        print("\nRecurrence candidates (raw lesson numbers): " + ", ".join("%d+%d (%s)" % x for x in r))


def cmd_candidates(a):
    d = ensure(store_dir(a.store))
    r = recurrences(read_raw(d))
    for x in r:
        print("lessons %d and %d recur in category %s: propose a standing rule to the CAE" % x)
    if not r:
        print("No recurrences found.")


def cmd_promote(a):
    d = ensure(store_dir(a.store))
    if not a.go_ahead or not a.go_ahead.strip():
        refuse("promotion changes behaviour across engagements and needs the CAE's go-ahead (Rule 20). Propose the exact wording and ask first.")
    if disallowed(a.rule):
        refuse("the rule reads as an instruction to lower quality or avoid friction; it cannot be promoted.")
    raw = {e["_n"]: e for e in read_raw(d)}
    if a.id not in raw:
        refuse("no raw lesson number %d" % a.id)
    with open(d / "lessons_promoted.md", "a", encoding="utf-8") as f:
        f.write("\n- **%s** (promoted %s from lesson %d, go-ahead: \"%s\")\n" % (a.rule.strip(), datetime.now(timezone.utc).strftime("%Y-%m-%d"), a.id, a.go_ahead.strip()[:120]))
    print("Promoted lesson %d" % a.id)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--store")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("init").set_defaults(fn=cmd_init)
    s = sub.add_parser("log")
    for f in ("category", "trigger", "correction", "context"):
        s.add_argument("--" + f, required=True)
    s.set_defaults(fn=cmd_log)
    s = sub.add_parser("check")
    s.add_argument("--query")
    s.set_defaults(fn=cmd_check)
    sub.add_parser("candidates").set_defaults(fn=cmd_candidates)
    s = sub.add_parser("promote")
    s.add_argument("--id", type=int, required=True)
    s.add_argument("--rule", required=True)
    s.add_argument("--go-ahead", dest="go_ahead", default="")
    s.set_defaults(fn=cmd_promote)
    a = ap.parse_args()
    a.fn(a)
    return 0


if __name__ == "__main__":
    sys.exit(main())
