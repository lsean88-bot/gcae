---
name: self-learning
description: "Correction capture and lesson promotion so a mistake is not repeated: logs corrections to a store outside the plugin, checks lessons before non-trivial work, promotes a lesson to a rule only on CAE approval. Use when the person corrects or pushes back, at the start of a task of three or more steps, or for a retrospective. Do NOT use for engagement facts (use gia-core:project-memory)."
---

# Self-Learning

A mistake made once is a cost. The same mistake made twice means nothing durable was written down. This skill is the one capture path, the one promotion rule and the one place the coding workflow lives.

## Three moments

**1. Capture, the instant a correction happens.** Fix the immediate issue, then log it:

`python3 -I ${CLAUDE_PLUGIN_ROOT}/skills/self-learning/scripts/log_lesson.py log --category <coding|audit-methodology|scope|tone|tooling-hygiene|other> --trigger "<what was done wrong>" --correction "<what was wanted>" --context "<skill or task>"`

Tell the person briefly that it was logged. In a coding project also append to that project's `tasks/lessons.md`. Run `log_lesson.py init` once if the store does not exist.

**2. Check, before non-trivial work.** For any task of three or more steps or in a domain where a lesson may apply, run `python3 -I ${CLAUDE_PLUGIN_ROOT}/skills/self-learning/scripts/log_lesson.py check [--query "<words>"]` and apply what is relevant. This is a quick look, not a research task. Do not rely on a session-start hook to surface lessons; hooks cannot be guaranteed to reach the model.

**3. Promote, deliberately.** A raw lesson is not yet a rule. Promote when:
- a correction reveals a missing rule: promote at once;
- a workflow shortcut is confirmed twice by the person: promote after the second confirmation;
- an error pattern recurs twice or more (`log_lesson.py candidates` finds likely recurrences): promote and add to the error-pattern library in `references/kaizen-and-lessons.md`.

State the exact proposed wording to the CAE and wait. Only after the go-ahead (Rule 20) run `log_lesson.py promote --id N --rule "<text>" --go-ahead "<their words>"`; the script refuses without one. Recording a lesson needs no sign-off; changing future behaviour across engagements does. A portfolio-wide rule is written to `gia-core:iron-rules` (Rule 20), not invented as a local fix.

## Where the store lives

Outside the plugin folder, because plugin files are protected and replaced on update: `--store`, else `$GIA_LESSONS_DIR`, else `$CLAUDE_PLUGIN_DATA/lessons`, else `~/.gia/lessons`. `init` seeds the promoted lessons from `data/seed-promoted.md`. The script refuses a store inside the plugin tree.

## What not to log or promote

- One-off typos with no pattern, or a preference the person framed as for this task only.
- Anything that reads as stop verifying, stop asking, grade more leniently or avoid pushing back. That is scope narrowing, not learning; the script refuses it. Tell the person instead.
- Engagement-specific facts. Those go to the engagement's memory (`gia-core:project-memory`).

## Retrospective

After a task of consequence ask: what worked and failed, what needed manual correction, what caused rework, which questions were unnecessary or should have come earlier, which template or approach did better. Formats, domain categories and the prompt and template version log are in `references/kaizen-and-lessons.md`.

## Coding work

Follow `references/coding-workflow.md` and the four principles in `references/karpathy-coding-principles.md`. The Plan, Verify, Execute, Check, Log cycle is defined in `gia-core:iron-rules` (references/charlie-hills.md).

## Honest limits

Capture depends on the model noticing a correction; nothing forces it. The recurrence finder is a word-overlap heuristic and only proposes. Lessons shape behaviour only when read, so the check step matters more than the log.

## References

- `references/kaizen-and-lessons.md`: retrospective, record format, promotion rules, error-pattern library, version log.
- `references/coding-workflow.md`, `references/karpathy-coding-principles.md`: coding discipline.
- `references/worked-example.md`: four real corrections from earlier builds.
- `references/constructive-communication-lexicon.md`: constructive wording for lessons and findings.
- `data/seed-promoted.md`, `data/seed-lessons.jsonl`: seed content.
