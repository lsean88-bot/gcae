# Standing monitoring schedule (fraud and control tests)

Default cadence for tests that suit recurring runs. Frequencies are defaults; set per entity risk and data availability. Objective IDs and script status come from `gia-fraud:gia-fraud-analytics` references/test-id-registry.md (NO SCRIPT YET means the test cannot be run by a script today and must be manual or built).

## Contents
1. Schedule
2. Per-test design fields
3. Notes

## 1. Schedule
| Monitoring test | Default frequency | Objective ID | Script status | Output |
|---|---|---|---|---|
| Payroll headcount vs statutory submission | Monthly | P01 | COVERED (FA-P1) | Exception list |
| AP duplicate payment scan | Weekly | V02 | COVERED (FA-A3) | Alert report |
| Vendor master change log review | Weekly | none assigned | Manual (ERP audit trail) | Change log review |
| Journal entry testing | Monthly | J01, J02, J05, J06 | PARTIAL (FA-J1) | JE exception report |
| Benford, payroll amounts | Monthly | B01 | COVERED (FA-B1; refuses invalid populations) | Deviation table with MAD band and table version |
| Benford, AP invoices | Monthly | B02 | COVERED (FA-B1) | Deviation table |
| Threshold avoidance | Monthly | V03 | PARTIAL (FA-A1, FA-A2) | Exception list |
| Ghost employee cross-check | Quarterly | P02, P04, P09, P10 | COVERED (FA-P1) | Mismatch report |
| Vendor-employee match | Quarterly | V01, V09 | COVERED (FA-V1) | Relationship list |
| Conflict-of-interest declaration check | Annual | none assigned | Manual (HR system) | Undisclosed conflicts |
| Gifts and hospitality register review | Quarterly | none assigned | Manual | Threshold breaches |
| Whistleblower volume trend | Monthly | none assigned | Manual (dashboard) | Emerging patterns |

## 2. Per-test design fields (all required)
Source system and extract | population and completeness check | frequency | threshold (set in advance) | owner (role) | exception workflow (who triages, clearance requires a named explanation) | validation (how the test itself is kept working: re-performance, seeded test data) | escalation (to whom, by what trigger; human-gated).

## 3. Notes
- Monitoring is management's (second line) ongoing activity. Independent assurance is the third line's periodic re-performance. Do not describe monitoring results as assurance.
- A flag is an indicator (Rule 17); clearing an exception needs a named innocent explanation, as in `gia-fraud-analytics` triage.
- Control limits for KPI-style tests use the group convention (3 sigma alarm, 2 sigma warning): `gia-analytics:gia-performance-analytics`.
