#!/usr/bin/env python3
"""Validate a continuous-assurance monitoring register (CSV).

Required columns (design fields): test_id, objective_id, type, source, population, frequency, threshold,
owner, exception_workflow, validation, escalation.
Checks per row:
  * every design field non-empty
  * type is 'monitoring' or 'assurance'
  * frequency in {daily, weekly, monthly, quarterly, semi-annual, annual, continuous, event-driven}
  * objective_id matches a known pattern (P/V/J/B/F/OB/O/C + digits, FA-xx, or 'none') and is not blank
  * type=monitoring must not have an owner that is the internal audit function (independence: monitoring is management's)
  * threshold must be set before running: values 'TBD' or 'tbc' are rejected
  * duplicate test_id rejected
Exit 1 if any error. Warnings (exit 0): objective_id 'none' (manual test) is listed so it is visible.
Usage: python3 check_monitoring_register.py --register register.csv [--json]
"""
import argparse, csv, json, re, sys

REQ = ["test_id", "objective_id", "type", "source", "population", "frequency", "threshold", "owner", "exception_workflow", "validation", "escalation"]
FREQ = {"daily", "weekly", "monthly", "quarterly", "semi-annual", "annual", "continuous", "event-driven"}
OBJ = re.compile(r"^(?:(?:P|V|J|B|F|OB|O|C)\d{1,2}(?:\s*[,;/]\s*(?:P|V|J|B|F|OB|O|C)\d{1,2})*|FA-[A-Z]\d|none)$", re.I)

def check(rows):
    errors, warnings, seen = [], [], set()
    for i, r in enumerate(rows, start=2):
        tid = (r.get("test_id") or "").strip() or f"row{i}"
        for f in REQ:
            if not (r.get(f) or "").strip():
                errors.append(f"{tid}: missing {f}")
        t = (r.get("type") or "").strip().lower()
        if t and t not in ("monitoring", "assurance"):
            errors.append(f"{tid}: type must be monitoring or assurance")
        fq = (r.get("frequency") or "").strip().lower()
        if fq and fq not in FREQ:
            errors.append(f"{tid}: frequency {fq!r} not in {sorted(FREQ)}")
        ob = (r.get("objective_id") or "").strip()
        if ob and not OBJ.match(ob):
            errors.append(f"{tid}: objective_id {ob!r} not a registry pattern")
        if ob.lower() == "none":
            warnings.append(f"{tid}: no objective ID assigned (manual test; confirm in registry)")
        if t == "monitoring" and re.search(r"internal audit|\bgia\b|\bcae\b", (r.get("owner") or ""), re.I):
            errors.append(f"{tid}: monitoring owner is internal audit; monitoring is management's, assurance is the third line")
        if re.fullmatch(r"\s*(tbd|tbc|n/a|\?)\s*", r.get("threshold") or "", re.I):
            errors.append(f"{tid}: threshold must be set in advance")
        if tid in seen:
            errors.append(f"{tid}: duplicate test_id")
        seen.add(tid)
    return errors, warnings

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--register", required=True); ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    with open(a.register, newline="", encoding="utf-8") as f:
        rd = csv.DictReader(f)
        missing = [c for c in REQ if c not in (rd.fieldnames or [])]
        if missing:
            print(f"ERROR: register lacks columns {missing}", file=sys.stderr); sys.exit(2)
        rows = list(rd)
    e, w = check(rows)
    if a.json: print(json.dumps({"rows": len(rows), "errors": e, "warnings": w}, indent=2))
    else:
        print(f"rows: {len(rows)}; errors: {len(e)}; warnings: {len(w)}")
        for x in e: print("ERROR:", x)
        for x in w: print("WARN:", x)
    sys.exit(1 if e else 0)

if __name__ == "__main__":
    main()
