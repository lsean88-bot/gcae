---
name: gia-continuous-assurance
description: "Designs repeatable monitoring tests with source, frequency, threshold, owner, exception workflow and escalation, keeps a monitoring register, separates management monitoring from assurance. Use when you need to set up recurring tests, a monitoring schedule or a standing test from a finding. Do NOT use for one-off tests (use gia-fraud:gia-fraud-analytics)."
---

# Continuous Assurance Design

Turns a test into a repeatable control: designed once, run on a cadence, with an owner who clears exceptions and a way to know the test still works. Rules by number are in `gia-core:iron-rules` (Rules 14, 17, 25).

## 1. Monitoring is not assurance

| | Monitoring | Independent assurance |
|---|---|---|
| Owner | Management (first or second line) | Internal audit (third line) |
| Cadence | Ongoing, per the schedule | Periodic, risk-based |
| Purpose | Detect and fix | Re-perform and opine on whether monitoring works |
Never report monitoring results as assurance. Never assign the monitoring task to internal audit: it impairs independence and turns audit into a control.

## 2. Design fields (all eight required for every test)

1. Source: system, extract, who runs it, reconciliation to the ledger.
2. Population and completeness check.
3. Frequency.
4. Threshold, set in advance (not tuned after seeing results).
5. Owner (role, not name).
6. Exception workflow: who triages, what evidence clears an exception (a named innocent explanation, not "reviewed"), time limit.
7. Validation: how the test is kept working (seeded test records, periodic re-performance, change control on parameters).
8. Escalation: to whom, on what trigger; the decision to notify outside management is human-gated.

## 3. Method

1. Start from the objective and its test ID (`gia-fraud:gia-fraud-analytics` references/test-id-registry.md). If status is NO SCRIPT YET the test is manual or needs building; say so in the register.
2. Prefer tests that already pass their regression (seeded data). Record script version and parameters in each run.
3. Set thresholds from the first two or three runs' baseline plus judgement, and freeze them; changes go through change control with a reason.
4. Expect false positives. Count them each cycle; a test whose exceptions are never cleared with an explanation is noise and is redesigned or retired.
5. Review the register at least annually and when a case closes (post-case loop question E in `gia-fraud:gia-fraud-investigation`).

## 4. Standing schedule and register

Default schedule with objective IDs and script status: `references/monitoring-schedule.md`. Keep one register (CSV) with the design fields plus type (monitoring or assurance) and objective ID. Validate it:
`python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-continuous-assurance/scripts/check_monitoring_register.py --register register.csv`
It rejects missing design fields, unset thresholds, unknown frequencies, unknown objective ID patterns, duplicate IDs, and monitoring tests owned by internal audit; manual tests with no objective ID are listed as warnings.

## 5. Reporting

Report per cycle: tests run, tests not run and why, population, exceptions found, exceptions cleared with the explanation named, exceptions open past the limit, parameter changes. Present indicators as indicators (ladder level: indicator) and describe patterns, never motive.

## Tests

`python3 -I tests/test_monitoring_register.py`.

## Related

`gia-fraud:gia-fraud-analytics` | `gia-fraud:gia-fraud-entity-watch` | `gia-analytics:gia-performance-analytics` | `gia-analytics:gia-data-reconciliation` | `gia-core:iron-rules`.
