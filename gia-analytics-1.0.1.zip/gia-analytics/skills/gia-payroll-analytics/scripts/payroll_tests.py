#!/usr/bin/env python3
"""Payroll, overtime and claims analytics (objective IDs P, O, C). Standard library only.

Indicators only: output lists exceptions with reason codes and the innocent explanations to rule out.
Never a conclusion about a person or intent (Rule 25); analytics output is not finding evidence (Rule 17).

Config (JSON): {"files": {...}, "params": {...}} - see fixtures/config.json. Dates ISO YYYY-MM-DD, periods YYYY-MM.
Files (CSV with header): employees(emp_id,id_number,manager_id,grade,hire_date,cost_centre),
  payroll(period,emp_id,cost_centre,basic,gross,statutory_deductions,ot_pay), ot(emp_id,date,hours,day_type),
  leave(emp_id,date), claims(claim_id,emp_id,invoice_no,amount,expense_date,submit_date,approver_id),
  grades(grade,max_basic), changes(emp_id,change_date,field).
Statutory inputs are NEVER defaulted here: ot_divisor_days, ot_hours_per_day, ot_multipliers (by day_type) and
monthly_ot_cap_hours come from the entity policy or the jurisdiction statutory register and must be supplied;
a test whose required parameter is missing is reported NOT RUN with the reason. Review parameters
(thresholds that are audit judgement, not law) have documented defaults listed in DEFAULTS.

Tests: P03 dup ID number | P05 zero leave | P06 OT on leave | P07 OT rate recalculation | P11 master change
shortly before payroll run | P12 cost-centre payroll variance | P13 zero statutory deduction | P14 basic above grade
maximum | O01 OT to basic ratio | O02 fixed OT pattern | O03 OT above cap | C01 duplicate claim invoice |
C03 stale claim | C04 self or reverse approval | C05 round-amount share.
Usage: python3 payroll_tests.py --config config.json [--out result.json]
"""
import argparse, csv, datetime as dt, json, sys
from collections import defaultdict, Counter

DEFAULTS = {"zero_leave_months": 12, "ot_rate_tolerance": 0.02, "master_change_window_days": 2,
            "cost_centre_variance_pct": 0.05, "ot_to_basic_ratio": 0.5, "fixed_ot_tolerance": 0.05,
            "fixed_ot_months": 3, "stale_claim_days": 30, "round_share_threshold": 0.30, "round_min_claims": 30}

INNOCENT = {
    "P03": ["Data-entry error in ID number", "Same person re-hired under a new employee ID"],
    "P05": ["Leave not captured in the leave extract", "Employee on unrecorded long-term arrangement", "Recently joined or period too short"],
    "P06": ["Leave cancelled after the OT was worked", "Date or time-zone keying error in either register"],
    "P07": ["Different OT multiplier for the day type than configured", "Basic changed mid-period", "Rounding policy"],
    "P11": ["Legitimate pre-payroll correction with approval", "Joiner or leaver processing"],
    "P12": ["Headcount, bonus or arrears timing", "Cost-centre reorganisation"],
    "P13": ["Statutory exemption or below-threshold category", "Deduction booked in a separate column"],
    "P14": ["Approved exception to the grade band", "Grade structure not current in the extract"],
    "O01": ["Seasonal production peak with approved OT", "Low basic for the role"],
    "O02": ["Roster-based fixed overtime in the contract", "Standing shift allowance recorded as OT"],
    "O03": ["Cap applies per a different period basis than configured", "Approved exemption"],
    "C01": ["Receipt re-submitted after rejection and the first claim withdrawn", "Shared receipt for a split bill claimed once each"],
    "C03": ["Late travel return", "Year-end batch submission permitted by policy"],
    "C04": ["Delegated authority recorded elsewhere", "Small-entity setup with one approver"],
    "C05": ["Fixed allowances claimed in round amounts", "Per-diem rates"],
}

def rcsv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def d(s):
    return dt.date.fromisoformat(s.strip())

def exc(tid, code, record, detail):
    return {"objective_id": tid, "reason_code": code, "record": record, "detail": detail, "innocent_explanations_to_rule_out": INNOCENT[tid]}

def run(cfg, base_dir="."):
    import os
    P = dict(DEFAULTS, **cfg.get("params", {}))
    F = {k: rcsv(os.path.join(base_dir, v)) for k, v in cfg.get("files", {}).items()}
    out, not_run, coverage = [], [], {}
    def need(test, files=(), params=()):
        miss = [f"file:{x}" for x in files if x not in F] + [f"param:{x}" for x in params if x not in P]
        if miss:
            not_run.append({"objective_id": test, "reason": "missing " + ", ".join(miss)}); return False
        return True
    emp = {r["emp_id"]: r for r in F.get("employees", [])}

    if need("P03", ["employees"]):
        c = defaultdict(list)
        for r in F["employees"]:
            if r.get("id_number", "").strip(): c[r["id_number"].strip()].append(r["emp_id"])
        for k, v in c.items():
            if len(v) > 1: out.append(exc("P03", "DUP-ID-NUMBER", {"emp_ids": sorted(v)}, f"{len(v)} records share one ID number"))
        coverage["P03"] = {"population": len(F["employees"])}
    if need("P05", ["employees", "leave"], ["as_of"]):
        as_of = d(P["as_of"]); start = dt.date(as_of.year - P["zero_leave_months"] // 12, as_of.month, 1) if P["zero_leave_months"] % 12 == 0 else None
        if start is None: start = as_of - dt.timedelta(days=int(P["zero_leave_months"] * 30.4375))
        took = {r["emp_id"] for r in F["leave"] if start <= d(r["date"]) <= as_of}
        pop = 0
        for r in F["employees"]:
            if r.get("hire_date") and d(r["hire_date"]) > start: continue
            pop += 1
            if r["emp_id"] not in took:
                out.append(exc("P05", "ZERO-LEAVE", {"emp_id": r["emp_id"]}, f"no leave recorded {start} to {as_of}"))
        coverage["P05"] = {"population": pop, "window_start": str(start), "as_of": str(as_of)}
    if need("P06", ["ot", "leave"]):
        lv = {(r["emp_id"], r["date"]) for r in F["leave"]}
        for r in F["ot"]:
            if (r["emp_id"], r["date"]) in lv:
                out.append(exc("P06", "OT-ON-LEAVE", {"emp_id": r["emp_id"], "date": r["date"]}, f"{r['hours']} OT hours on an approved leave day"))
        coverage["P06"] = {"population": len(F["ot"])}
    if need("P07", ["ot", "payroll"], ["ot_divisor_days", "ot_hours_per_day", "ot_multipliers"]):
        exp = defaultdict(float)
        basic = {(r["period"], r["emp_id"]): float(r["basic"]) for r in F["payroll"]}
        paid = {(r["period"], r["emp_id"]): float(r.get("ot_pay") or 0) for r in F["payroll"]}
        hrs = defaultdict(float)
        for r in F["ot"]:
            per = r["date"][:7]; k = (per, r["emp_id"])
            if k not in basic: continue
            m = P["ot_multipliers"].get(r["day_type"])
            if m is None:
                out.append(exc("P07", "DAY-TYPE-NOT-CONFIGURED", {"emp_id": r["emp_id"], "date": r["date"]}, f"day_type {r['day_type']!r} has no multiplier in config")); continue
            exp[k] += basic[k] / P["ot_divisor_days"] / P["ot_hours_per_day"] * m * float(r["hours"])
        for k, e in exp.items():
            if e == 0: continue
            diff = (paid[k] - e) / e
            if abs(diff) > P["ot_rate_tolerance"]:
                out.append(exc("P07", "OT-RATE-VARIANCE", {"period": k[0], "emp_id": k[1]}, f"paid {paid[k]:.2f} vs recalculated {e:.2f} ({diff:+.1%})"))
        coverage["P07"] = {"population": len(exp), "tolerance": P["ot_rate_tolerance"]}
    if need("P11", ["changes"], ["payroll_run_dates"]):
        for r in F["changes"]:
            per = r["change_date"][:7]
            run_d = P["payroll_run_dates"].get(per)
            if run_d and 0 <= (d(run_d) - d(r["change_date"])).days <= P["master_change_window_days"]:
                out.append(exc("P11", "MASTER-CHANGE-BEFORE-RUN", {"emp_id": r["emp_id"], "field": r.get("field", "")}, f"changed {r['change_date']}, run {run_d}"))
        coverage["P11"] = {"population": len(F["changes"]), "window_days": P["master_change_window_days"]}
    if need("P12", ["payroll"]):
        tot = defaultdict(float)
        for r in F["payroll"]: tot[(r["cost_centre"], r["period"])] += float(r["gross"])
        for (cc, per), v in sorted(tot.items()):
            y, m = int(per[:4]), int(per[5:])
            prev = f"{y - 1}-12" if m == 1 else f"{y}-{m - 1:02d}"
            if (cc, prev) in tot and tot[(cc, prev)] > 0:
                ch = v / tot[(cc, prev)] - 1
                if abs(ch) > P["cost_centre_variance_pct"]:
                    out.append(exc("P12", "CC-PAYROLL-VARIANCE", {"cost_centre": cc, "period": per}, f"{ch:+.1%} vs {prev}"))
        coverage["P12"] = {"population": len(tot), "threshold": P["cost_centre_variance_pct"]}
    if need("P13", ["payroll"]):
        for r in F["payroll"]:
            if float(r["gross"]) > 0 and float(r.get("statutory_deductions") or 0) == 0:
                out.append(exc("P13", "ZERO-STATUTORY", {"period": r["period"], "emp_id": r["emp_id"]}, "gross > 0 with no statutory deduction"))
        coverage["P13"] = {"population": len(F["payroll"])}
    if need("P14", ["payroll", "employees", "grades"]):
        gm = {r["grade"]: float(r["max_basic"]) for r in F["grades"]}
        for r in F["payroll"]:
            g = emp.get(r["emp_id"], {}).get("grade")
            if g in gm and float(r["basic"]) > gm[g]:
                out.append(exc("P14", "BASIC-ABOVE-GRADE-MAX", {"period": r["period"], "emp_id": r["emp_id"]}, f"basic {r['basic']} > grade {g} max {gm[g]}"))
        coverage["P14"] = {"population": len(F["payroll"])}
    if need("O01", ["payroll"]):
        for r in F["payroll"]:
            b, o = float(r["basic"]), float(r.get("ot_pay") or 0)
            if b > 0 and o / b > P["ot_to_basic_ratio"]:
                out.append(exc("O01", "OT-TO-BASIC", {"period": r["period"], "emp_id": r["emp_id"]}, f"OT pay is {o / b:.0%} of basic"))
        coverage["O01"] = {"population": len(F["payroll"]), "threshold": P["ot_to_basic_ratio"]}
    ot_month = defaultdict(float)
    for r in F.get("ot", []): ot_month[(r["emp_id"], r["date"][:7])] += float(r["hours"])
    if need("O02", ["ot"]):
        by = defaultdict(list)
        for (e, per), h in ot_month.items(): by[e].append((per, h))
        n = P["fixed_ot_months"]
        for e, series in by.items():
            series.sort()
            for i in range(len(series) - n + 1):
                w = [h for _, h in series[i:i + n]]
                consecutive = all(_next(series[j][0]) == series[j + 1][0] for j in range(i, i + n - 1))
                if consecutive and max(w) > 0 and (max(w) - min(w)) / max(w) <= P["fixed_ot_tolerance"]:
                    out.append(exc("O02", "FIXED-OT-PATTERN", {"emp_id": e, "from": series[i][0]}, f"{n} consecutive months with near-identical OT hours {w}")); break
        coverage["O02"] = {"population": len(by), "months": n, "tolerance": P["fixed_ot_tolerance"]}
    if need("O03", ["ot"], ["monthly_ot_cap_hours"]):
        for (e, per), h in sorted(ot_month.items()):
            if h > P["monthly_ot_cap_hours"]:
                out.append(exc("O03", "OT-ABOVE-CAP", {"emp_id": e, "period": per}, f"{h} hours > configured cap {P['monthly_ot_cap_hours']}"))
        coverage["O03"] = {"population": len(ot_month), "cap_source": "config (statutory register or policy)"}
    if need("C01", ["claims"]):
        c = defaultdict(list)
        for r in F["claims"]:
            if r.get("invoice_no", "").strip(): c[r["invoice_no"].strip()].append(r["claim_id"])
        for k, v in c.items():
            if len(v) > 1: out.append(exc("C01", "DUP-CLAIM-INVOICE", {"invoice_no": k, "claim_ids": sorted(v)}, f"{len(v)} claims cite one invoice number"))
        coverage["C01"] = {"population": len(F["claims"])}
    if need("C03", ["claims"]):
        for r in F["claims"]:
            lag = (d(r["submit_date"]) - d(r["expense_date"])).days
            if lag > P["stale_claim_days"]:
                out.append(exc("C03", "STALE-CLAIM", {"claim_id": r["claim_id"]}, f"submitted {lag} days after expense date"))
        coverage["C03"] = {"population": len(F["claims"]), "threshold_days": P["stale_claim_days"]}
    if need("C04", ["claims", "employees"]):
        for r in F["claims"]:
            a, e = r.get("approver_id", "").strip(), r["emp_id"]
            if a and a == e:
                out.append(exc("C04", "SELF-APPROVED", {"claim_id": r["claim_id"]}, "approver is the claimant"))
            elif a and emp.get(a, {}).get("manager_id", "").strip() == e:
                out.append(exc("C04", "REVERSE-APPROVAL", {"claim_id": r["claim_id"]}, "approver reports to the claimant"))
        coverage["C04"] = {"population": len(F["claims"])}
    if need("C05", ["claims"]):
        n = len(F["claims"])
        if n >= P["round_min_claims"]:
            share = sum(1 for r in F["claims"] if float(r["amount"]) == int(float(r["amount"]))) / n
            if share > P["round_share_threshold"]:
                out.append(exc("C05", "ROUND-AMOUNT-SHARE", {"claims": n}, f"{share:.0%} of claims are whole-unit amounts"))
        else:
            not_run.append({"objective_id": "C05", "reason": f"only {n} claims; minimum {P['round_min_claims']}"})
        coverage["C05"] = {"population": n, "threshold": P["round_share_threshold"]}
    return {"exceptions": out, "not_run": not_run, "coverage": coverage, "parameters": {k: P[k] for k in sorted(P)},
            "counts": dict(Counter(e["objective_id"] for e in out)),
            "note": "Indicators only. Clearing an exception requires a named innocent explanation. Not run tests are listed in not_run."}

def _next(per):
    y, m = int(per[:4]), int(per[5:])
    return f"{y + 1}-01" if m == 12 else f"{y}-{m + 1:02d}"

def main():
    import os
    ap = argparse.ArgumentParser(); ap.add_argument("--config", required=True); ap.add_argument("--out")
    a = ap.parse_args()
    cfg = json.load(open(a.config))
    try:
        r = run(cfg, os.path.dirname(os.path.abspath(a.config)))
    except (FileNotFoundError, KeyError, ValueError) as e:
        print(f"ERROR: {e!r}", file=sys.stderr); sys.exit(2)
    if a.out: json.dump(r, open(a.out, "w"), indent=2)
    print(json.dumps({"counts": r["counts"], "not_run": [x["objective_id"] for x in r["not_run"]]}))

if __name__ == "__main__":
    main()
