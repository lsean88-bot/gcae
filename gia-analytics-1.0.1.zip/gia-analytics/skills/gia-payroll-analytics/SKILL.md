---
name: gia-payroll-analytics
description: "Payroll, overtime and expense-claim analytics on supplied extracts with exception lists and innocent explanations: duplicate IDs, overtime on leave, rate recalculation, zero statutory deduction, duplicate claims, self-approval. Use when asked for payroll tests, overtime analytics or claims screens. Do NOT use for the HR audit programme (use gia-audit)."
---

# Payroll, overtime and claims analytics

Executable tests for objective IDs P, O and C. The audit programme, interview steps and statutory tables for payroll live in the `gia-audit` HR and payroll pack; this skill supplies the data tests only. Registry and retired DA-xx mapping: `references/test-registry.md`.

## 1. Rules that apply
- Output is an indicator list, never a conclusion about a person or intent (Rules 25 and 11). Use the ladder weakness, indicator, suspicion, allegation, corroborated, substantiated; never motive (see `gia-core:iron-rules`).
- Analytics output is not finding evidence (Rule 17). A finding needs source records at R1 or R2 for the amounts and dates (strict R3 test).
- Statutory inputs are never defaulted by the script. Overtime divisor, hours per day, multipliers and monthly cap come from the entity policy or `statutory-register-<juris>.md` (owned by `gia-audit`, with a verified-on date). A test with a missing input is reported NOT RUN with the reason, and the coverage statement lists it.
- No inline statutory figures in this skill or in reports built from it.
- Extracts hold personal data (Rule 36). Keep them in the restricted case repository; report employee IDs, not names.

## 2. Workflow
1. Confirm the extract source, extract dates and that totals reconcile to the payroll ledger (`gia-analytics:gia-data-reconciliation`). Unreconciled data stops the run (Rule 02).
2. Build `config.json` (files and params) from `fixtures/config.json`. Record every parameter and its source.
3. Run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-payroll-analytics/scripts/payroll_tests.py --config config.json --out result.json`. Exit codes and the NOT RUN list are part of the output.
4. For each exception, work the listed innocent explanations first and record the outcome.
5. Hand surviving exceptions to the audit lead. Do not widen the test or change parameters after seeing results without recording why.
6. Population and totals tested versus total go in the coverage statement. State tests not run and why.

## 3. Tests in the script
| ID | Test | Required inputs |
|---|---|---|
| P03 | Duplicate ID number | employees |
| P05 | Zero leave in window | employees, leave |
| P06 | Overtime on leave days | ot, leave |
| P07 | OT rate recalculation | payroll, ot, divisor, hours, multipliers |
| P11 | Master change shortly before run | changes, run dates |
| P12 | Cost-centre variance vs prior month | payroll |
| P13 | Zero statutory deduction | payroll |
| P14 | Basic above grade maximum | employees, payroll, grades |
| O01 | OT to basic ratio | payroll |
| O02 | Fixed OT pattern | payroll |
| O03 | OT above cap | ot, cap |
| C01 | Duplicate claim invoice | claims |
| C03 | Stale claim | claims, as-of date |
| C04 | Self or reverse approval | claims, employees |
| C05 | Round-amount share | claims (minimum 30) |

Tests with no script yet (P15, O04-O06, C02, C06, P16) are listed in the registry and stated as not covered; do not simulate them. Duplicate bank account, terminated-but-paid, headcount reconciliation and Benford are covered by `gia-fraud:gia-fraud-analytics`.

## 4. Output and reporting
- `result.json`: counts per test, exceptions with reason codes and innocent explanations, parameters used, tests not run.
- Use the standard concise internal audit report plus the Excel workpaper; each figure in the report cross-references a workpaper row. No guilt wording; describe the pattern and what was ruled out.
- A fixture run proves the script works, not that the population is clean.

## 5. Limits
Tests run on the extract supplied; a clean result covers only that extract and period. Fixture parameter values are illustrative test values, not statutory figures.
