# Payroll, overtime and claims test registry

Objective IDs for payroll analytics, mapped to the retired DA-01 to DA-25 battery and to the fraud registry (`gia-fraud:gia-fraud-analytics` references/test-id-registry.md). One ID system: P (payroll), O (overtime), C (claims), V and B shared with the fraud registry. DA-xx IDs are retired.

## Contents
1. Registry
2. Retired DA-xx mapping
3. Parameters
4. Data shapes

## 1. Registry
| Objective | Test | Script | Status | Fraud-registry overlap |
|---|---|---|---|---|
| P01 | Headcount vs statutory submission | `gia-fraud` FA-P1 | COVERED (fraud plugin) | P01 |
| P02 | Duplicate bank account | `gia-fraud` FA-P1 | COVERED (fraud plugin) | P02 |
| P03 | Duplicate ID number | payroll_tests.py | COVERED | P03 |
| P04 | Terminated but paid | `gia-fraud` FA-P1 | COVERED (fraud plugin) | P04 |
| P05 | Zero leave in window | payroll_tests.py | COVERED | P05 |
| P06 | OT on leave days | payroll_tests.py | COVERED | P06 |
| P07 | OT rate recalculation (rate rule supplied) | payroll_tests.py | COVERED | P07 |
| P08 | Salary to third-party account | `gia-fraud` FA-P1 | PARTIAL (fraud plugin) | P08 |
| P11 (new) | Master change shortly before payroll run | payroll_tests.py | COVERED | none |
| P12 (new) | Cost-centre payroll variance vs prior month | payroll_tests.py | COVERED | none |
| P13 (new) | Zero statutory deduction with gross pay | payroll_tests.py | COVERED | none |
| P14 (new) | Basic above grade maximum | payroll_tests.py | COVERED | none |
| P15 (new) | HRMS incompatible roles (SoD) | none | NO SCRIPT YET (access matrix review) | none |
| O01 (new) | OT pay to basic ratio | payroll_tests.py | COVERED | none |
| O02 (new) | Fixed OT pattern, consecutive months | payroll_tests.py | COVERED | none |
| O03 (new) | OT above configured monthly cap | payroll_tests.py | COVERED (cap supplied) | none |
| O04 (new) | OT during plant shutdown | none | NO SCRIPT YET (needs shutdown calendar) | none |
| O05 (new) | Supervisor OT approval concentration | none | NO SCRIPT YET | none |
| O06 (new) | OT without production output | none | NO SCRIPT YET | none |
| C01 (new) | Duplicate claim invoice number | payroll_tests.py | COVERED | V02 analogue |
| C02 (new) | Claims just below approval threshold | none | NO SCRIPT YET (use `gia-fraud` FA-A1 on claims) | V03 analogue |
| C03 (new) | Stale claims | payroll_tests.py | COVERED | none |
| C04 (new) | Self or reverse approval | payroll_tests.py | COVERED | J05 analogue |
| C05 (new) | Round-amount share | payroll_tests.py | COVERED (minimum 30 claims) | V04 analogue |
| C06 (new) | Claim vendor bank or address matches employee | none | NO SCRIPT YET (use `gia-fraud` FA-V1 on claims payee data) | V01, V09 |
| B01-B03 | Benford on payroll, OT, claims amounts | `gia-fraud` FA-B1 | COVERED (fraud plugin; refuses invalid populations) | B01, B03 |

## 2. Retired DA-xx mapping
| DA | New | DA | New | DA | New |
|---|---|---|---|---|---|
| DA-01 | P03 | DA-10 | O02 | DA-19 | ranking (descriptive; no ID) |
| DA-02 | P02 | DA-11 | C01 | DA-20 | C05 |
| DA-03 | P04 | DA-12 | C02 | DA-21 | P05 |
| DA-04 | P13 | DA-13 | C03 | DA-22 | P16 (shared address or phone clusters; NO SCRIPT YET) |
| DA-05 | P14 | DA-14 | C06 | DA-23 | P12 |
| DA-06 | P11 | DA-15 | B01 | DA-24 | C04 |
| DA-07 | P06 | DA-16 | B01 (OT amounts) | DA-25 | P15 |
| DA-08 | O03 | DA-17 | B03 | DA-18 | ranking (descriptive; no ID) |
| DA-09 | O01 | | | | |

## 3. Parameters
Statutory inputs are never defaulted: `ot_divisor_days`, `ot_hours_per_day`, `ot_multipliers`, `monthly_ot_cap_hours` come from the entity policy or `statutory-register-<juris>.md` (verified-on date recorded in the run notes). Review parameters and defaults (audit judgement, not law): zero-leave window 12 months; OT rate tolerance 2%; master change window 2 days; cost-centre variance 5%; OT to basic 50%; fixed OT 3 months within 5%; stale claim 30 days; round share 30% with minimum 30 claims. Record the values used.

## 4. Data shapes
CSV with header, ISO dates, periods YYYY-MM, one currency per run. Columns per file are listed in the `payroll_tests.py` docstring and shown in `fixtures/`. Extracts contain personal data: store in the restricted case repository; findings use employee IDs, never names.
