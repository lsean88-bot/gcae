---
name: gia-performance-analytics
description: "Operational and financial data into audit insight: KPI and KRI baselines, control limits, trend versus noise, entity benchmarking, variance narrative. Use when asked for KPI trend analysis, materiality of a movement, OTIF, utilisation, yield, DSO or benchmarking. Do NOT use for fraud tests (use gia-fraud:gia-fraud-analytics) or cost variances (use gia-analytics:gia-cost-accounting)."
---

# Performance Analytics

Analytical layer between raw data and a finding, KRI register entry or Board paper. Output is analysis and narrative, not the dashboard artefact.

## 1. Division of labour

| Need | Owner |
|---|---|
| Interpret a KPI or KRI trend, judge materiality, root-cause a variance | This skill |
| Build the interactive dashboard | `data:build-dashboard` |
| Recurring data pulls, monitoring cadence, thresholds, owners | `gia-analytics:gia-continuous-assurance` |
| Cost variances (price, usage, efficiency, overhead) and yield | `gia-analytics:gia-cost-accounting` |
| Fraud-detection analytics (Benford, duplicates, ghost payees) | `gia-fraud:gia-fraud-analytics` |
| Board paper wording, report QA | `gia-report-qa` |

## 2. Step 1 - baseline before judging any movement

Never assess one period in isolation. Before flagging a movement:
1. Take a rolling history of at least 12 periods (the longest available if shorter; below 6 points no limits are set).
2. Compute the baseline: mean and sample standard deviation, or median and a robust spread when the series is skewed or has outliers.
3. Classify the movement: trend (sustained direction), noise (normal variation) or step-change (discrete shift tied to an event such as a new line, process change, headcount change, contract change).

Control limits (group standard; statistical-process-control convention, calibrate to the series):

| Signal | Rule | Meaning |
|---|---|---|
| ALARM | Point outside baseline mean +/- 3 sd | Investigate and explain before reporting |
| WARNING | Point outside mean +/- 2 sd | Watch; explain if repeated |
| WARNING (run) | 8 or more consecutive points on one side of the mean | Sustained shift, not noise |

A 2 sd limit alone is not an alarm: it flags about one point in twenty by chance. Use `python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-performance-analytics/scripts/control_limits.py --input series.csv --column value` (frozen baseline by default; `--rolling` adapts the baseline and therefore absorbs a sustained shift, so use it only for slowly drifting series). A flag means "explain the movement", not "control failure". Seasonal series are de-seasonalised first or compared with the same period last year.

## 3. Step 2 - operational KPI library

| KPI | Formula | What deviation usually means |
|---|---|---|
| OTIF | Orders delivered complete and on time / total orders | Falling with stable capacity: planning or scheduling weakness. Falling with rising utilisation: capacity constraint |
| Capacity utilisation | Actual output hours / available capacity hours | Persistently low with an unchanged fixed-cost base: overhead absorption risk (`gia-cost-accounting`) |
| First-pass yield | Units passing first inspection / units started | Sustained decline: process control weakness. Sudden drop: discrete event (tooling, material batch, operator change) |
| Downtime % | Unplanned downtime hours / scheduled hours | Rising without maintenance spend: deferred-maintenance risk |
| DSO | (Receivables / revenue) x days in period | Rising by customer or entity: credit control weakness; test cut-off with `gia-fraud:gia-fraud-fsf-window-dressing` |
| Inventory days | (Average inventory / COGS) x days in period | Rising without a strategic build: obsolescence risk; test net realisable value |
| Scrap or yield trend | See `gia-cost-accounting` | This skill presents the trend; cost skill investigates the cause |

Apply the relevant subset by entity type: manufacturing KPIs for plants, clinic KPIs (chair utilisation, treatment volume) for healthcare entities. Never force one set on the other.

## 4. Step 3 - cross-entity benchmarking without misleading comparisons

- Normalise for entity type and scale; compare only within genuinely comparable clusters.
- Disclose denominator and definition differences; confirm definitions match before ranking.
- Rank on trend as well as level where baselines differ structurally.
- State the like-for-like base, the cut-off date and the population for every comparison (Rule 39).

## 5. Step 4 - variance-to-budget narrative

Variance % = (Actual - Budget) / Budget x 100. State the sign convention used (Rule 39); cost-variance sign conventions follow `gia-cost-accounting` (favourable positive).
A defensible narrative names in order: (1) the driver - volume, price, mix or efficiency; (2) whether it is controllable by the entity or externally imposed (for example a commodity-linked price move); (3) whether it is a one-off or a trend visible in the baseline. A narrative that restates the number without a driver goes back for root cause before it reaches a Board paper.

## 6. Step 5 - presenting results

Carry the evidence limitations with the output: data source, extract date, reconciliation status, and basis class for each statement (Rule 37). Severity is shown in words and a table (Critical, High, Medium, Low), not symbols. A clean chart can look more authoritative than the data supports, so state the limitation next to it.

## 7. Quality gate before any performance finding is final

1. Is the baseline long enough to separate trend from noise?
2. Is there a plausible driver, corroborated against an independent data point rather than asserted?
3. If cross-entity, were denominator and definition differences checked?
4. Did a different agent re-perform the key numbers and review the output (`gia-report-qa`) before it feeds a Board paper?

## Tests

`python3 -I tests/test_control_limits.py`.

## Related

`gia-analytics:gia-continuous-assurance` | `gia-analytics:gia-cost-accounting` | `gia-fraud:gia-fraud-analytics` | `gia-report-qa` | `gia-core:iron-rules`.
