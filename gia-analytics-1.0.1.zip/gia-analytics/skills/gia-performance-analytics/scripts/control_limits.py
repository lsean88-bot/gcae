#!/usr/bin/env python3
"""Control limits for a KPI/KRI series: 3-sigma ALARM, 2-sigma WARNING, run rule WARNING.

Convention (group standard): warning limit = baseline mean +/- 2 sd; alarm limit = mean +/- 3 sd.
Run rule: `--run-length` consecutive points (default 8) on one side of the mean = WARNING (sustained shift).
These are statistical-process-control conventions to be calibrated to the series; they are screening
limits, not audit conclusions. A flag means "explain the movement", not "control failure".

Baseline: the first --baseline-n points (default 12, frozen) unless --rolling, which uses the
trailing --baseline-n points before each point. Sample standard deviation (n-1) is used.
A flat baseline (sd = 0) cannot define limits: points that differ are marked BASELINE_FLAT for review.

Usage: python3 control_limits.py --input series.csv --column value [--baseline-n 12] [--rolling]
                                 [--run-length 8] [--out result.json]
"""
import argparse, csv, json, math, sys

def mean_sd(xs):
    m = sum(xs) / len(xs)
    sd = math.sqrt(sum((x - m) ** 2 for x in xs) / (len(xs) - 1)) if len(xs) > 1 else 0.0
    return m, sd

def evaluate(values, baseline_n=12, rolling=False, run_length=8):
    if len(values) <= baseline_n:
        raise ValueError(f"need more than baseline_n={baseline_n} points; got {len(values)}")
    if baseline_n < 6:
        raise ValueError("baseline_n below 6 is too short to separate noise from trend")
    out, run_side, run_len = [], 0, 0
    m0, sd0 = mean_sd(values[:baseline_n])
    for i in range(baseline_n, len(values)):
        m, sd = mean_sd(values[i - baseline_n:i]) if rolling else (m0, sd0)
        v = values[i]
        if sd == 0:
            flag, z = ("BASELINE_FLAT" if v != m else "OK"), None
        else:
            z = (v - m) / sd
            flag = "ALARM" if abs(z) > 3 else "WARNING" if abs(z) > 2 else "OK"
        side = 0 if v == m else (1 if v > m else -1)
        run_len = run_len + 1 if side != 0 and side == run_side else (1 if side != 0 else 0)
        run_side = side
        run_flag = run_len >= run_length
        if run_flag and flag == "OK":
            flag = "WARNING_RUN"
        out.append({"index": i, "value": v, "baseline_mean": round(m, 6), "baseline_sd": round(sd, 6),
                    "z": None if z is None else round(z, 3), "run_length_same_side": run_len, "flag": flag,
                    "ucl_alarm": round(m + 3 * sd, 6), "lcl_alarm": round(m - 3 * sd, 6),
                    "ucl_warning": round(m + 2 * sd, 6), "lcl_warning": round(m - 2 * sd, 6)})
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True); ap.add_argument("--column", default="value")
    ap.add_argument("--baseline-n", type=int, default=12); ap.add_argument("--rolling", action="store_true")
    ap.add_argument("--run-length", type=int, default=8); ap.add_argument("--out")
    a = ap.parse_args()
    vals = [float(r[a.column]) for r in csv.DictReader(open(a.input))]
    try:
        res = evaluate(vals, a.baseline_n, a.rolling, a.run_length)
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr); sys.exit(2)
    doc = {"convention": "warning=2sd, alarm=3sd, run rule", "baseline_n": a.baseline_n, "rolling": a.rolling,
           "run_length": a.run_length, "points": res,
           "summary": {k: sum(1 for p in res if p["flag"] == k) for k in ("ALARM", "WARNING", "WARNING_RUN", "BASELINE_FLAT", "OK")}}
    if a.out: json.dump(doc, open(a.out, "w"), indent=2)
    print(json.dumps(doc["summary"]))

if __name__ == "__main__":
    main()
