# Worked example - pricing recovery and scrap (illustrative)

Values are constructed for this skill; they are not case data. Reproduce with `python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-recovery-analysis/scripts/recovery_model.py --input fixtures/worked_example.json`.

## Contents
1. Inputs
2. Per-piece model
3. Population
4. Sensitivity grid
5. Reading the result

## 1. Inputs (all assumptions until confirmed)
Purchase rate 540.00 per blank; sale rate 470.00 per finished part; blank 9.00 kg; finished 4.50 kg; steel rate 60.00 per kg; scrap price 38.00 per kg; 10,000 blanks bought; 9,000 parts sold.

## 2. Per-piece model
| Measure | Working | Result |
|---|---|---|
| Gap | 540 - 470 | 70.00 |
| Scrap kg | 9.00 - 4.50 | 4.50 |
| Scrap value | 4.50 x 38 | 171.00 |
| Net material cost | 540 - 171 | 369.00 |
| Contribution over material | 470 - 369 (= 171 - 70) | 101.00 |
| Steel in finished part | 4.50 x 60 | 270.00 |
| Scrap spread loss | 4.50 x (60 - 38) | 99.00 |
| Break-even scrap price | 70 / 4.50 | 15.56 |

## 3. Population
Scrap on parts sold 9,000 x 4.50 = 40,500 kg; on all blanks bought 45,000 kg; blanks not yet sold 1,000 (potential scrap 4,500 kg). Values are model outputs; the extract does not evidence that any scrap was recovered, sold or credited, which is the question to put to management.

## 4. Sensitivity grid (contribution per piece)
| Finished kg \ scrap price | 30 | 38 | 46 |
|---|---|---|---|
| 4.2 | 74.0 | 112.4 | 150.8 |
| 4.5 | 65.0 | 101.0 | 137.0 |
| 4.8 | 56.0 | 89.6 | 123.2 |

## 5. Reading the result
The 70 gap is covered only if scrap is recovered at or above the break-even price. State the exposure as "money touched under these assumptions" and the deciding question: who owns and sells the scrap, at what price, and where are the credit notes?
