#!/usr/bin/env python3
"""Pricing-recovery and scrap model for a counterparty that is both vendor and customer.

Per piece (inputs are assumptions or source values; label each in the working paper):
  scrap_kg                 = blank_kg - finished_kg
  scrap_value              = scrap_kg x scrap_price
  net_material_cost        = purchase_rate - scrap_value
  contribution_over_material = sale_rate - net_material_cost    (before labour, power, overhead)
  gap                      = purchase_rate - sale_rate
  steel_in_finished        = finished_kg x steel_rate
  scrap_spread_loss        = scrap_kg x (steel_rate - scrap_price)
  break_even_scrap_price   = gap / scrap_kg                       (scrap price at which contribution = 0)
Identity: contribution_over_material = scrap_value - gap.
Population: scrap kg and value on parts sold, on all blanks bought, and on blanks not yet sold (potential only).
Sensitivity grid: contribution_over_material across finished weight x scrap price.
Never mix pieces (NOS) and kilograms: conversion happens only through the stated blank and finished weights.
Usage: python3 recovery_model.py --input case.json [--out result.json]
"""
import argparse, json, sys

def per_piece(c):
    scrap_kg = c["blank_kg"] - c["finished_kg"]
    if scrap_kg <= 0:
        raise ValueError("blank_kg must exceed finished_kg (no scrap implied); check weights")
    gap = c["purchase_rate"] - c["sale_rate"]
    scrap_value = scrap_kg * c["scrap_price"]
    net = c["purchase_rate"] - scrap_value
    return {"scrap_kg": round(scrap_kg, 4), "gap": round(gap, 2), "scrap_value": round(scrap_value, 2),
            "net_material_cost": round(net, 2), "contribution_over_material": round(c["sale_rate"] - net, 2),
            "steel_in_finished": round(c["finished_kg"] * c["steel_rate"], 2),
            "scrap_spread_loss": round(scrap_kg * (c["steel_rate"] - c["scrap_price"]), 2),
            "break_even_scrap_price": round(gap / scrap_kg, 4)}

def population(c, p):
    sk = p["scrap_kg"]
    sold, bought = c["qty_sold"], c["qty_bought"]
    return {"scrap_kg_on_parts_sold": round(sk * sold, 2), "scrap_value_on_parts_sold": round(sk * sold * c["scrap_price"], 2),
            "scrap_kg_on_all_blanks_bought": round(sk * bought, 2), "scrap_value_on_all_blanks_bought": round(sk * bought * c["scrap_price"], 2),
            "blanks_not_yet_sold": bought - sold, "potential_scrap_kg_on_blanks_not_yet_sold": round(sk * (bought - sold), 2),
            "label": "scrap values are model outputs under stated assumptions; scrap recovery itself is not evidenced by this model"}

def grid(c, finished_kgs, scrap_prices):
    rows = []
    for f in finished_kgs:
        row = {"finished_kg": f}
        for sp in scrap_prices:
            cc = dict(c, finished_kg=f, scrap_price=sp)
            row[f"scrap_price_{sp}"] = per_piece(cc)["contribution_over_material"]
        rows.append(row)
    return rows

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--input", required=True); ap.add_argument("--out")
    a = ap.parse_args(); c = json.load(open(a.input))
    try:
        p = per_piece(c)
    except ValueError as e:
        print(f"ERROR: {e}", file=sys.stderr); sys.exit(2)
    r = {"per_piece": p, "population": population(c, p),
         "sensitivity_grid": grid(c, c.get("grid_finished_kg", [c["finished_kg"]]), c.get("grid_scrap_price", [c["scrap_price"]]))}
    if a.out: json.dump(r, open(a.out, "w"), indent=2)
    print(json.dumps(r, indent=2))

if __name__ == "__main__":
    main()
