#!/usr/bin/env python3
"""Build the template working-paper workbook for a two-way trade recovery analysis.

Sheets: Summary, Inputs, Pricing_Recovery, Scrap_Recovery, Sensitivity, Qty_Bridge, CreditNote_Test,
Ageing_Net, Exceptions, Src_Purchase, Src_Sale. Source sheets are left empty for the raw extracts (paste
unchanged); analysis cells are formulas (no hard-coded results). Input cells are blue font on yellow fill:
every input is a source value or an ASSUMPTION to be labelled. Recalculate before use (LibreOffice or Excel).
Usage: python3 build_workbook.py --out recovery_template.xlsx [--inputs fixtures/worked_example.json]
"""
import argparse, json
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill

INPUT_FONT, INPUT_FILL = Font(color="0000FF"), PatternFill("solid", fgColor="FFFF00")
INPUTS = [  # key, label, default, basis
    ("purchase_rate", "Purchase rate per piece (blank bought)", 0, "Source: purchase sheet"),
    ("sale_rate", "Sale rate per piece (finished part sold)", 0, "Source: sale sheet"),
    ("blank_kg", "Blank weight (kg)", 0, "ASSUMPTION until confirmed by management or BOM"),
    ("finished_kg", "Finished part weight (kg)", 0, "ASSUMPTION until confirmed by management or BOM"),
    ("steel_rate", "Steel rate per kg", 0, "Source or ASSUMPTION"),
    ("scrap_price", "Scrap price per kg", 0, "ASSUMPTION until confirmed"),
    ("qty_bought", "Quantity bought (NOS)", 0, "Source: purchase sheet"),
    ("qty_sold", "Quantity sold (NOS)", 0, "Source: sale sheet"),
]

def build(path, vals=None):
    vals = vals or {}
    wb = Workbook(); wb.remove(wb.active)
    names = ["Summary", "Inputs", "Pricing_Recovery", "Scrap_Recovery", "Sensitivity", "Qty_Bridge",
             "CreditNote_Test", "Ageing_Net", "Exceptions", "Src_Purchase", "Src_Sale"]
    ws = {n: wb.create_sheet(n) for n in names}
    # Inputs
    s = ws["Inputs"]; s.append(["Input", "Value", "Basis (label source vs assumption)"])
    ref = {}
    for i, (k, label, d, basis) in enumerate(INPUTS, start=2):
        s.cell(row=i, column=1, value=label); c = s.cell(row=i, column=2, value=vals.get(k, d))
        c.font, c.fill = INPUT_FONT, INPUT_FILL; s.cell(row=i, column=3, value=basis); ref[k] = f"Inputs!$B${i}"
    # Pricing_Recovery
    p = ws["Pricing_Recovery"]; p.append(["Measure", "Per piece", "Formula meaning"])
    rows = [("Gap (purchase - sale)", f"={ref['purchase_rate']}-{ref['sale_rate']}", "purchase_rate - sale_rate"),
            ("Cover % (sale / purchase)", f"=IF({ref['purchase_rate']}=0,\"n/a\",{ref['sale_rate']}/{ref['purchase_rate']})", "sale_rate / purchase_rate"),
            ("Implied weight at steel rate (clue only)", f"=IF({ref['steel_rate']}=0,\"n/a\",{ref['purchase_rate']}/{ref['steel_rate']})", "purchase_rate / steel_rate"),
            ("Steel in finished part", f"={ref['finished_kg']}*{ref['steel_rate']}", "finished_kg x steel_rate")]
    for r in rows: p.append(list(r))
    # Scrap_Recovery (rows reference Inputs)
    q = ws["Scrap_Recovery"]; q.append(["Measure", "Value", "Formula meaning"])
    q.append(["Scrap kg per piece", f"={ref['blank_kg']}-{ref['finished_kg']}", "blank_kg - finished_kg"])               # B2
    q.append(["Scrap value per piece", f"=B2*{ref['scrap_price']}", "scrap_kg x scrap_price"])                            # B3
    q.append(["Net material cost per piece", f"={ref['purchase_rate']}-B3", "purchase_rate - scrap_value"])             # B4
    q.append(["Contribution over material per piece", f"={ref['sale_rate']}-B4", "sale_rate - net_material_cost"])      # B5
    q.append(["Scrap spread loss per piece", f"=B2*({ref['steel_rate']}-{ref['scrap_price']})", "scrap_kg x (steel_rate - scrap_price)"])  # B6
    q.append(["Break-even scrap price", f"=IF(B2<=0,\"n/a\",({ref['purchase_rate']}-{ref['sale_rate']})/B2)", "gap / scrap_kg"])      # B7
    q.append(["Scrap kg on parts sold", f"=B2*{ref['qty_sold']}", "scrap_kg x qty_sold"])                                  # B8
    q.append(["Scrap value on parts sold", f"=B3*{ref['qty_sold']}", "model output, recovery not evidenced"])             # B9
    q.append(["Scrap kg on all blanks bought", f"=B2*{ref['qty_bought']}", "scrap_kg x qty_bought"])                      # B10
    q.append(["Blanks not yet sold (NOS)", f"={ref['qty_bought']}-{ref['qty_sold']}", "qty_bought - qty_sold"])           # B11
    # Sensitivity: finished weight (rows) x scrap price (cols), contribution
    g = ws["Sensitivity"]; g.append(["Contribution over material per piece", "Finished kg (rows) x scrap price per kg (columns)"])
    g.cell(row=2, column=1, value="finished_kg \\ scrap_price")
    for j, sp in enumerate([30, 38, 46], start=2):
        c = g.cell(row=2, column=j, value=sp); c.font, c.fill = INPUT_FONT, INPUT_FILL
    for i, fk in enumerate([4.2, 4.5, 4.8], start=3):
        c = g.cell(row=i, column=1, value=fk); c.font, c.fill = INPUT_FONT, INPUT_FILL
        for j in range(2, 5):
            col = "BCD"[j - 2]
            g.cell(row=i, column=j, value=f"={ref['sale_rate']}-({ref['purchase_rate']}-({ref['blank_kg']}-$A{i})*{col}$2)")
    ws["Qty_Bridge"].append(["Family", "Bought (NOS)", "Sold (NOS)", "Balance", "First receipt date", "First sale date", "Note"])
    ws["CreditNote_Test"].append(["Trigger", "Expected note?", "Notes found in extract", "Result", "Question for management"])
    for t in ("Price difference", "Scrap value", "Rejected goods", "Weight shortfall", "Quantity difference"):
        ws["CreditNote_Test"].append([t, "", "", "", ""])
    ws["Ageing_Net"].append(["As-at date (input)", "", "Net position = purchases incl tax - sales incl tax, BEFORE payments (payments not in file)"])
    ws["Exceptions"].append(["Ref", "Sheet and row range", "Exception", "Basis class (Verified / Supplied / Inference / Proposal)", "Question that decides it"])
    ws["Src_Purchase"].append(["Paste source extract unchanged below this row"])
    ws["Src_Sale"].append(["Paste source extract unchanged below this row"])
    # Summary links
    m = ws["Summary"]; m.append(["Key figure", "Value", "Basis"])
    m.append(["Gap per piece", "=Pricing_Recovery!B2", "Calculated from source rates"])
    m.append(["Scrap kg per piece", "=Scrap_Recovery!B2", "ASSUMPTION-dependent"])
    m.append(["Contribution over material per piece", "=Scrap_Recovery!B5", "ASSUMPTION-dependent; before labour, power, overhead"])
    m.append(["Break-even scrap price", "=Scrap_Recovery!B7", "Calculated"])
    wb.save(path)

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--out", required=True); ap.add_argument("--inputs")
    a = ap.parse_args(); build(a.out, json.load(open(a.inputs)) if a.inputs else None); print("wrote", a.out)

if __name__ == "__main__":
    main()
