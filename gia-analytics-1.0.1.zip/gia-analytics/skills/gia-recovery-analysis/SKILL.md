---
name: gia-recovery-analysis
description: "Audits GRN and sale sheets for a counterparty that is both vendor and customer: integrity tests, pricing recovery and scrap model, quantity bridges, credit-note trigger test, net position. Use when asked for two-way trade pricing, scrap recovery, back-billing exposure or missing credit notes. Do NOT use for cost variances (use gia-analytics:gia-cost-accounting)."
---

# Two-Way Trade: Pricing Recovery and Credit Notes

Method for Excel purchase and sale extracts of a counterparty that sells the group a material or blank and buys finished parts or coil back. The worked example is illustrative (`references/worked-example.md`); no case data is held here.

## Operating rules (never skip)
1. Label facts, inferences and approximations separately (Rule 37). State exposure ("money touched") and the question that decides it; never state a conclusion of loss (Rule 25).
2. Never mix NOS (pieces) and KGS. Convert only with a stated weight and label it an assumption.
3. If a hypothesis is contradicted by new facts, withdraw it in writing and rebuild.
4. Ask early for missing facts (weights, scrap price, scrap ownership, meaning of "Open", where credit notes live) and keep working with what exists. Missing facts are open dependencies, not assumptions (Rule 12).
5. Every number in the report traces to a workbook cell or row range; verify row references after the last rebuild (Rule 34).

## Phase 0 - understand the file
Open every sheet (shape, headers, status values, UOM, dates, document types). Write the trade flow in one sentence per direction. Note PO, drawing or part numbers that link purchases to sales, and remark fields: key facts (a weight, a price) often sit in a remark.

## Phase 1 - integrity tests (both sheets)
- Quantity x rate = basic value; tax components = expected; total = basic + tax.
- Price on receipt = PO rate (SUMPRODUCT); PO utilisation vs PO quantity.
- Duplicates: invoice, GRN, e-invoice reference, transport document across unrelated invoices.
- Multi-line invoices: a header total repeated on each line overstates the column sum; compute invoice-level totals and the difference.
- Missing e-invoice or acknowledgement number; invoice dated before the customer PO; GRN date vs vendor date.
- Quality: QC document blank, accepted quantity zero on closed GRNs, rejected quantity all zero.
- Coding: category vs item group mismatch; missing customer part codes.

## Phase 2 - link purchase and sale by family
Group by drawing or part number into families. Family table: purchased quantity and value, sold quantity and value, average rates.

## Phase 3 - pricing recovery and scrap model
1. Per piece: purchase rate, sale rate, gap, cover % (sale / purchase).
2. Convert the rate to kg at the steel rate to see the weight each price implies. A clue only, not a finished weight.
3. Scrap model (needs blank kg, finished kg, scrap price from management or BOM): scrap kg, scrap value, net material cost, contribution over material (before labour, power, welding, overhead), steel in the finished part, scrap spread loss, break-even scrap price = gap / scrap kg, and population (scrap on parts sold, on all blanks bought, on blanks not yet sold).
4. Sensitivity grid: finished weight x scrap price.
Run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-recovery-analysis/scripts/recovery_model.py --input case.json`; formulas and identity are in the script docstring. Contribution over material equals scrap value minus gap: use it as a check.
5. Price history by customer PO (rate changes, effective dates, back-billing). If customer price lists are absent, say sale rate vs customer PO cannot be tested.

## Phase 4 - quantity and weight bridges
Per family: bought vs sold vs balance; cumulative balance by date (never negative?); pair imbalance; stock static for months; long gap between first receipt and first sale. Weight: kg received per part sold vs a theoretical weight from dimensions x density (assumption cell); kg of coil sold vs kg-equivalent of blanks received.

## Phase 5 - credit and debit note test
Look for negative lines, document types other than invoice, QC rejected quantity. Test the triggers that should create notes: price differences, scrap value, rejected goods, weight shortfall, quantity differences. Absence of any note across the period is itself a finding to raise as a question (do notes live in another record?).

## Phase 6 - ageing and net position
Invoice-level ageing with an as-at input cell. Treat "Open" as unsettled only as an assumption to confirm. Net position = purchases incl tax - sales incl tax, labelled "before payments, payments not in file". Recommend a statement of account and written offset terms.

## Phase 7 - workbook
`python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-recovery-analysis/scripts/build_workbook.py --out wp.xlsx --inputs case.json` builds the template: Summary, Inputs, Pricing_Recovery, Scrap_Recovery, Sensitivity, Qty_Bridge, CreditNote_Test, Ageing_Net, Exceptions, Src_Purchase, Src_Sale. Source sheets stay unchanged; analysis uses formulas; blue on yellow cells are inputs or assumptions. Recalculate, confirm zero formula errors, spot-check three formulas against Python, and recheck cross-sheet references after inserting rows. Working-paper standards: `gia-audit` fieldwork workpapers.

## Rating
Use the group deficiency scale and the group rating scale (`gia-audit`); cap at High if the evidence is extract-only. The previous skill's local High/Medium/Low scale is retired.

## Hand-off
Auditee report and Board note: `gia-report-qa` (standard concise report plus Excel working paper). If indicators of fraud arise, route to `gia-fraud:gia-fraud-investigation`; do not state intent.

## Tests
`python3 -I tests/test_recovery.py` (hand-computed model, workbook recalculated in LibreOffice).

## Related
`gia-analytics:gia-cost-accounting` | `gia-fraud:gia-fraud-investigation` | `gia-report-qa` | `gia-audit` | `gia-core:iron-rules`.
