#!/usr/bin/env python3
"""Standard-cost variance calculator with ONE sign convention: favourable = positive, unfavourable = negative.

All cost variances are (Standard - Actual) in cost terms, so a positive number always means the actual
outcome cost less than (or absorbed more than) the standard allowed.

  Material price      = (Std price - Actual price) x Actual qty
  Material usage      = (Std qty allowed for actual output - Actual qty) x Std price
  Labour rate         = (Std rate - Actual rate) x Actual hours
  Labour efficiency   = (Std hours allowed - Actual hours) x Std rate
  Var OH spending     = Std var OH rate x Actual activity - Actual var OH
  Var OH efficiency   = (Std activity allowed - Actual activity) x Std var OH rate
  Fixed OH spending   = Budgeted fixed OH - Actual fixed OH
  Fixed OH volume     = (Std activity allowed for actual output - Budgeted activity) x Std fixed OH rate
                        (= overhead absorbed - budgeted; negative = under-absorbed)
  Total               = Std cost allowed for actual output - Actual cost  (must equal the sum of the eight)

Activity base for overhead is whatever the entity uses (labour hours or machine hours); pass it as "activity"
in the input and keep it consistent. The script fails (exit 3) if the components do not reconcile to the total.

Usage:
  python3 variance_calc.py variance --input case.json [--out result.json]
  python3 variance_calc.py yield --input_kg 1000 --good_kg 870 --scrap_kg 130 --alloy_cost 2.40 --recovery_value 1.90
Input JSON for `variance` (see fixtures/worked_example.json).
"""
import argparse, json, sys

def variances(c):
    s, a = c["standard"], c["actual"]
    out_units = c["actual_output_units"]
    std_qty = s["material_qty_per_unit"] * out_units
    std_hours = s["labour_hours_per_unit"] * out_units
    std_act = s["activity_per_unit"] * out_units
    v = {
        "material_price": (s["material_price"] - a["material_price"]) * a["material_qty"],
        "material_usage": (std_qty - a["material_qty"]) * s["material_price"],
        "labour_rate": (s["labour_rate"] - a["labour_rate"]) * a["labour_hours"],
        "labour_efficiency": (std_hours - a["labour_hours"]) * s["labour_rate"],
        "variable_oh_spending": s["variable_oh_rate"] * a["activity"] - a["variable_oh"],
        "variable_oh_efficiency": (std_act - a["activity"]) * s["variable_oh_rate"],
        "fixed_oh_spending": s["budgeted_fixed_oh"] - a["fixed_oh"],
        "fixed_oh_volume": (std_act - s["budgeted_activity"]) * s["fixed_oh_rate"],
    }
    std_cost = (std_qty * s["material_price"] + std_hours * s["labour_rate"]
                + std_act * s["variable_oh_rate"] + std_act * s["fixed_oh_rate"])
    act_cost = (a["material_qty"] * a["material_price"] + a["labour_hours"] * a["labour_rate"]
                + a["variable_oh"] + a["fixed_oh"])
    total = std_cost - act_cost
    comp_sum = sum(v.values())
    return {"components": {k: round(x, 2) for k, x in v.items()},
            "label": {k: ("F" if x > 0 else "U" if x < 0 else "-") for k, x in v.items()},
            "standard_cost_allowed": round(std_cost, 2), "actual_cost": round(act_cost, 2),
            "total_variance": round(total, 2), "sum_of_components": round(comp_sum, 2),
            "reconciles": abs(total - comp_sum) < 0.01,
            "convention": "favourable = positive (Standard - Actual); fixed OH volume = absorbed - budgeted"}

def metal_yield(input_kg, good_kg, scrap_kg, alloy_cost, recovery_value):
    if input_kg <= 0:
        raise ValueError("input_kg must be positive")
    return {"metal_yield_pct": round(good_kg / input_kg * 100, 2),
            "effective_scrap_rate_pct": round(scrap_kg / input_kg * 100, 2),
            "scrap_cost": round(scrap_kg * (alloy_cost - recovery_value), 2),
            "mass_balance_gap_kg": round(input_kg - good_kg - scrap_kg, 3),
            "note": "gap = input - good - scrap; a non-zero gap is melt loss or an unreconciled quantity to explain, not a conclusion"}

def main():
    ap = argparse.ArgumentParser(); sub = ap.add_subparsers(dest="cmd", required=True)
    v = sub.add_parser("variance"); v.add_argument("--input", required=True); v.add_argument("--out")
    y = sub.add_parser("yield")
    for k in ("input_kg", "good_kg", "scrap_kg", "alloy_cost", "recovery_value"):
        y.add_argument(f"--{k}", type=float, required=True)
    a = ap.parse_args()
    if a.cmd == "variance":
        r = variances(json.load(open(a.input)))
        if a.out: json.dump(r, open(a.out, "w"), indent=2)
        print(json.dumps(r, indent=2))
        sys.exit(0 if r["reconciles"] else 3)
    print(json.dumps(metal_yield(a.input_kg, a.good_kg, a.scrap_kg, a.alloy_cost, a.recovery_value), indent=2))

if __name__ == "__main__":
    main()
