---
name: gia-cost-accounting
description: "Manufacturing cost audit: costing systems, standard cost cards, eight standard-cost variances, yield and scrap costing, overhead absorption, product profitability. Use when asked for costing audits, standard versus actual or cost card checks. Do NOT use for KPI trends (use gia-analytics:gia-performance-analytics) or two-way trade recovery (use gia-analytics:gia-recovery-analysis)."
---

# Cost Accounting and Financial Analysis (manufacturing)

Costing lens for die casting, stamping and assembly engagements. Entity process and statutory detail come from the entity packs in `gia-audit`; this skill supplies the costing method. Findings follow the standard finding structure (condition, criteria, cause, effect, recommendation) and the group deficiency scale; no separate report format.

Never treat an internally supplied costing sheet as authoritative until it is reconciled to source (BOM, routing, rate cards, ledger).

## 1. Lead or support

Lead when the question is cost, margin, variance or profitability. Support when another audit surfaces a costing question (for example an unexplained scrap variance): apply this method rather than reasoning ad hoc.

## 2. Costing systems - confirm which one is in use

| System | Cost capture | Audit focus |
|---|---|---|
| Standard costing | Pre-set unit cost; variances posted separately | Standard-setting rigour, variance investigation, revision cadence |
| Actual costing | Traced to job or batch as incurred | Allocation accuracy, job-cost completeness |
| Normal costing | Actual material and labour, budgeted overhead rate | Overhead rate derivation, over and under-absorption treatment |
| Activity-based costing | Overhead via cost drivers | Driver validity; does it change decisions |

Most die-casting and stamping operations run standard costing with normal-costing overhead absorption. Confirm; do not assume.

## 3. Standard cost card - completeness checklist

| Element | Source | Common finding |
|---|---|---|
| Direct material: kg per unit x alloy price | BOM, price list | Stale alloy price on a commodity-linked alloy distorts price variance |
| Material yield and scrap allowance | Engineering standard | Not re-validated after a tooling or process change; hides yield decline inside "planned scrap" |
| Direct labour: standard hours x rate | Routing, payroll rate | Routing not updated after a cycle-time change; permanently favourable labour variance |
| Variable overhead: rate x allocation base | Budget | Base not representative of the driver in an automated cell |
| Fixed overhead: rate x allocation base | Budget and normal capacity | Normal capacity not re-derived after a capacity change; persistent volume variance |
| Tooling amortisation per unit | Tool cost / expected life units | Life assumption untested against shots to date |

## 4. Variance framework - ONE sign convention

All cost variances are Standard minus Actual in cost terms: favourable is positive, unfavourable is negative. State this next to every variance table (Rule 39).

```
Material price        = (Std price - Actual price) x Actual qty
Material usage        = (Std qty allowed for actual output - Actual qty) x Std price
Labour rate           = (Std rate - Actual rate) x Actual hours
Labour efficiency     = (Std hours allowed - Actual hours) x Std rate
Variable OH spending  = Std var OH rate x Actual activity - Actual var OH
Variable OH efficiency= (Std activity allowed - Actual activity) x Std var OH rate
Fixed OH spending     = Budgeted fixed OH - Actual fixed OH
Fixed OH volume       = (Std activity allowed for actual output - Budgeted activity) x Std fixed OH rate
Total variance        = Std cost allowed for actual output - Actual cost = sum of the eight
```

Correction to the previous framework: fixed OH volume was written (Budgeted - Actual activity) x rate, which is positive when overhead is under-absorbed (unfavourable), the opposite sign to every other line, and it used actual rather than standard activity (mixing in efficiency). The formula above equals overhead absorbed minus budgeted: negative means under-absorbed.

Worked example with numbers, reconciliation and the old-formula contrast: `references/worked-example.md`. Calculator: `python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-cost-accounting/scripts/variance_calc.py variance --input case.json` (exit 3 if the components do not reconcile to the total).

Investigation threshold: investigate any variance above the greater of 5% of standard cost or the engagement's quantitative materiality (calibrate to the entity, not a fixed rule). Investigate ANY recurring favourable variance regardless of size: it is as often a loose standard (or an indicator, section 9) as genuine improvement.

## 5. Metal yield and scrap costing (die casting, stamping)

```
Metal yield %        = Good output weight / Total metal input weight x 100
Scrap cost           = Scrap weight x (Alloy cost - Scrap recovery value)
Effective scrap rate = Scrap weight / Total metal input weight
```
`python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-cost-accounting/scripts/variance_calc.py yield ...` also reports the mass-balance gap (input - good - scrap). A non-zero gap is melt loss or an unreconciled quantity to explain, not a conclusion.
- Reconcile weighbridge and material test certificate records to BOM-implied consumption for the period; a gap is a reconciliation exception for the entity audit and for `gia-fraud:gia-fraud-analytics` (scrap tests are NO SCRIPT YET).
- Runner, riser and flash re-melted in house is costed at recovery value, not as a full loss.
- Test whether the scrap allowance is a genuine engineering estimate or a carried-forward plug; ask for the date it was last recalculated against shop-floor data.

## 6. Overhead absorption

- Allocation base mismatch: labour-hour absorption in an automated cell misallocates between labour-intensive and machine-intensive lines; consider machine-hour or ABC where automation intensity varies.
- Idle capacity masking: fixed overhead absorbed at normal capacity when utilisation is structurally below normal overstates inventory and understates period expense; flag for the financial reporting framework applied (inventory valuation standard).
- Under or over-absorption trend: a growing under-absorption balance written to COGS each period without investigation is itself a finding.

## 7. Product and customer profitability

```
Gross margin % = (Selling price - Standard cost) / Selling price x 100
Contribution   = Selling price - Variable cost  (decisions only; not inventory valuation)
```
Reconcile standard-cost margin to actual landed-cost margin: customer price-down commitments can erode actual margin below the standard-cost margin still being reported. Flag any product and customer combination priced below standard variable cost for explicit management justification; assume neither strategic loss-leader nor unnoticed erosion without evidence.

## 8. Cost-audit techniques

| Technique | Tests |
|---|---|
| Cost card recomputation | Rebuild the card from BOM, routing and current rates; compare to the system card |
| Trace to ledger | Standard cost postings, variance postings and revaluation entries agree to the general ledger |
| BOM to actual consumption | BOM-implied consumption vs actual issues and receipts for the period |
| Rate re-performance | Recompute the overhead absorption rate from budget data |
| Standard revision history | Revision on a defined cadence; a standard untouched for years on a volatile-price alloy is a finding |

## 9. Cost-linked fraud indicators (indicators only; investigation in gia-fraud)

- Persistently favourable usage variance without process-improvement evidence: possible unrecorded scrap diversion or phantom yield.
- Scrap sales proceeds not reconciled to recorded scrap weight.
- Standard cost cards revised just before an incentive measurement period in a direction favouring the metric.
- Tooling amortisation life lengthened without engineering basis, timed to a margin metric.
Route to `gia-fraud:gia-fraud-investigation`; do not state intent (Rule 25).

## 10. Ranges

Yield and scrap ranges are not held as benchmarks here: `references/illustrative-ranges.md` records the previous illustrative figures as [UNVERIFIED]. Use the entity's own historical baseline.

## Tests

`python3 -I tests/test_variance_calc.py`.

## Related

`gia-analytics:gia-performance-analytics` | `gia-analytics:gia-recovery-analysis` | `gia-fraud:gia-fraud-analytics` | `gia-audit` (entity packs) | `gia-core:iron-rules`.
