# Worked example - standard-cost variances (illustrative)

Constructed for this skill; no entity data. Activity base is direct labour hours. Convention: favourable positive. Reproduce with `python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-cost-accounting/scripts/variance_calc.py variance --input fixtures/worked_example.json`.

## Contents
1. Inputs
2. Calculation
3. Reconciliation
4. Old formula contrast

## 1. Inputs
| Item | Standard | Actual |
|---|---|---|
| Output | 10,000 units | 10,000 units |
| Material per unit / price | 1.50 kg at 3.00 | 15,600 kg in total at 3.10 |
| Labour hours / rate | 0.10 h per unit at 20.00 (1,000 h allowed) | 1,050 h at 19.50 |
| Variable OH | 8.00 per hour | 8,820 |
| Fixed OH | budget 14,400 on 1,200 h = 12.00 per hour | 14,900 |

## 2. Calculation
| Variance | Working | Result |
|---|---|---|
| Material price | (3.00 - 3.10) x 15,600 | -1,560 U |
| Material usage | (15,000 - 15,600) x 3.00 | -1,800 U |
| Labour rate | (20.00 - 19.50) x 1,050 | +525 F |
| Labour efficiency | (1,000 - 1,050) x 20.00 | -1,000 U |
| Variable OH spending | 8.00 x 1,050 - 8,820 | -420 U |
| Variable OH efficiency | (1,000 - 1,050) x 8.00 | -400 U |
| Fixed OH spending | 14,400 - 14,900 | -500 U |
| Fixed OH volume | (1,000 - 1,200) x 12.00 | -2,400 U (under-absorbed) |
| Total | | -7,555 U |

## 3. Reconciliation
Standard cost allowed for actual output: 45,000 material + 20,000 labour + 8,000 variable OH + 12,000 fixed OH absorbed = 85,000. Actual cost: 48,360 + 20,475 + 8,820 + 14,900 = 92,555. Standard minus actual = -7,555 = sum of the eight components.

## 4. Old formula contrast
(Budgeted activity - Actual activity) x rate = (1,200 - 1,050) x 12.00 = +1,800. It reads as favourable although fixed overhead is under-absorbed (12,000 absorbed against a 14,400 budget, a -2,400 volume variance), and it mixes the 50 excess hours, which are an efficiency effect, into volume. Do not use it.
