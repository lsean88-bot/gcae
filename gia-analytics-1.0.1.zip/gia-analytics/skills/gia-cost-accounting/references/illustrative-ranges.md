# Illustrative yield and scrap ranges - [UNVERIFIED]

Carried from the previous skill for completeness. Unsourced starting points for scepticism only; never cite as a benchmark and never flag a deviation against them. Use the entity's own history.

| KPI | Previous illustrative range |
|---|---|
| Metal yield, high-pressure die casting | 85-95% (lower for complex geometries) |
| Scrap cost as share of material cost | 3-8% |
| Overhead absorption rate variance | within +/-5% of budget on a rolling basis |
