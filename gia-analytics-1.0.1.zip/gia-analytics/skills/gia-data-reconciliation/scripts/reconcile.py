#!/usr/bin/env python3
"""
GIA 06_DATA reconciliation checker (8-point checklist).

Runs the standing 8-point reconciliation checklist against the JSON data
layer (entities.json, engagements.json, risk_register.json, racm.json,
entity_risk_profiles.json, audit_plan.json) and prints a pass/fail report.

Usage:
    python reconcile.py --data-dir /path/to/06_DATA [--json] [--strict]

--json    also write the structured result to stdout after the text report
--strict  exit code 1 if any check FAILs (default exit 0, as in the original)
Entity aliases: an entities.json record may carry "alias" (e.g. MKSDL with alias MKSLD).
A record that uses an alias instead of the canonical name is reported as a defect.
"""
import argparse
import json
import os
import sys
from collections import Counter


def load(data_dir, filename):
    path = os.path.join(data_dir, filename)
    if not os.path.exists(path):
        print(f"  [SKIP] {filename} not found at {path}")
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def check_entity_name_consistency(entities, *sources):
    """Return {name: note}. note is 'unrecognised' or 'alias of <canonical>'."""
    canonical = {e["name"] for e in entities} if entities else set()
    aliases = {}
    for e in entities or []:
        for a in ([e["alias"]] if isinstance(e.get("alias"), str) else e.get("alias", []) or []):
            aliases[a] = e["name"]
    canonical.add("Group")  # audit_plan.json uses "Group" for thematic engagements
    bad = {}
    for src in sources:
        if not src:
            continue
        for row in src:
            name = row.get("Entity", row.get("entity"))
            if name and name not in canonical:
                bad[name] = f"alias of {aliases[name]}; normalise to the canonical name" if name in aliases else "unrecognised"
    return bad


def check_risk_counts(entity_profiles, risk_register):
    mismatches = []
    if not entity_profiles or not risk_register:
        return mismatches
    counts = Counter(r["Entity"] for r in risk_register)
    for profile in entity_profiles:
        ent = profile["entity"]
        actual = counts.get(ent, 0)
        stated = profile.get("total_risks")
        if stated != actual:
            mismatches.append((ent, stated, actual))
    return mismatches


def check_audit_evidence_resolves(risk_register, engagements):
    missing = []
    if not risk_register or not engagements:
        return missing
    valid_ids = {e["EngagementID"] for e in engagements}
    for risk in risk_register:
        evidence = risk.get("AuditEvidence", "")
        for chunk in evidence.replace(";", ",").split(","):
            chunk = chunk.strip().split(" ")[0]  # strip trailing notes
            if not chunk.startswith("ENG-"):
                continue
            # Expand slash-shorthand like "ENG-124/125/126/127" or
            # dash-range shorthand like "ENG-124-127" into individual IDs.
            if "/" in chunk:
                prefix = "ENG-"
                parts = chunk.split("/")
                ids_to_check = [parts[0]] + [prefix + p for p in parts[1:]]
            elif chunk.count("-") == 2:
                # e.g. ENG-124-127 -> range ENG-124..ENG-127
                try:
                    _, start, end = chunk.split("-")
                    ids_to_check = [f"ENG-{n:03d}" for n in range(int(start), int(end) + 1)]
                except ValueError:
                    ids_to_check = [chunk]
            else:
                ids_to_check = [chunk]
            for token in ids_to_check:
                if token not in valid_ids:
                    missing.append((risk["RiskID"], token))
    return missing


def check_racm_riskid_resolves(racm, risk_register):
    missing = []
    entity_mismatch = []
    if not racm or not risk_register:
        return missing, entity_mismatch
    risk_by_id = {r["RiskID"]: r for r in risk_register}
    for control in racm:
        rid = control.get("RiskID")
        risk = risk_by_id.get(rid)
        if risk is None:
            missing.append((control["RACM_ID"], rid))
        elif risk.get("Entity") != control.get("Entity"):
            entity_mismatch.append((control["RACM_ID"], control["Entity"], risk["Entity"]))
    return missing, entity_mismatch


def check_audit_plan_linked_risks(audit_plan, risk_register):
    missing = []
    if not audit_plan or not risk_register:
        return missing
    valid_ids = {r["RiskID"] for r in risk_register}
    for plan in audit_plan:
        for rid in plan.get("LinkedRisks", []):
            if rid not in valid_ids:
                missing.append((plan["PlanID"], rid))
    return missing


def check_duplicate_ids(risk_register, racm, engagements, audit_plan):
    dupes = {}
    for label, rows, key in [
        ("RiskID", risk_register, "RiskID"),
        ("RACM_ID", racm, "RACM_ID"),
        ("EngagementID", engagements, "EngagementID"),
        ("PlanID", audit_plan, "PlanID"),
    ]:
        if not rows:
            continue
        counts = Counter(r[key] for r in rows)
        dupes[label] = [k for k, v in counts.items() if v > 1]
    return dupes


def check_avg_residual_score(entity_profiles, risk_register, tolerance=0.5):
    drift = []
    if not entity_profiles or not risk_register:
        return drift
    scores_by_entity = {}
    for r in risk_register:
        scores_by_entity.setdefault(r["Entity"], []).append(float(r["ResidualScore"]))
    for profile in entity_profiles:
        ent = profile["entity"]
        scores = scores_by_entity.get(ent, [])
        if not scores:
            continue
        computed = sum(scores) / len(scores)
        stated = profile.get("avg_residual_score")
        if stated is not None and abs(computed - stated) > tolerance:
            drift.append((ent, stated, round(computed, 2)))
    return drift


def check_exports_nonempty(data_dir):
    results = {}
    for fname in ["AUDIT_PLAN.csv", "AUDIT_PLAN.xlsx"]:
        path = os.path.join(data_dir, fname)
        if not os.path.exists(path):
            results[fname] = "not found"
        elif os.path.getsize(path) == 0:
            results[fname] = "EMPTY"
        else:
            results[fname] = f"ok ({os.path.getsize(path)} bytes)"
    return results


def run_checks(d):
    """Run all 8 checks on data dir d. Returns list of dicts: n, name, status, details."""
    entities = load(d, "entities.json")
    entities_list = entities.get("entities") if isinstance(entities, dict) else entities
    engagements = load(d, "engagements.json")
    engagements_list = engagements.get("engagements") if isinstance(engagements, dict) else engagements
    risk_register = load(d, "risk_register.json")
    racm = load(d, "racm.json")
    entity_profiles = load(d, "entity_risk_profiles.json")
    audit_plan = load(d, "audit_plan.json")
    R = []

    bad = check_entity_name_consistency(entities_list, engagements_list, risk_register, racm, entity_profiles, audit_plan)
    R.append(dict(n=1, name="Entity-name consistency", status="FAIL" if bad else "PASS",
                  details=[f"Entity name {k!r}: {v}" for k, v in sorted(bad.items())]))
    mm = check_risk_counts(entity_profiles, risk_register)
    R.append(dict(n=2, name="Risk-count consistency", status="FAIL" if mm else "PASS",
                  details=[f"{e}: profile states total_risks={st}, actual={ac}" for e, st, ac in mm]))
    me = check_audit_evidence_resolves(risk_register, engagements_list)
    R.append(dict(n=3, name="AuditEvidence ENG-xxx resolution", status="FAIL" if me else "PASS",
                  details=[f"{r} references missing engagement {g}" for r, g in me]))
    mr, em = check_racm_riskid_resolves(racm, risk_register)
    R.append(dict(n=4, name="RACM RiskID resolution", status="FAIL" if (mr or em) else "PASS",
                  details=[f"{c} references missing risk {r}" for c, r in mr] +
                          [f"{c} entity={a} but linked risk entity={b}" for c, a, b in em]))
    ml = check_audit_plan_linked_risks(audit_plan, risk_register)
    R.append(dict(n=5, name="audit_plan.json LinkedRisks resolution", status="FAIL" if ml else "PASS",
                  details=[f"{p} references missing risk {r}" for p, r in ml]))
    dp = check_duplicate_ids(risk_register, racm, engagements_list, audit_plan)
    R.append(dict(n=6, name="Duplicate ID check", status="FAIL" if any(dp.values()) else "PASS",
                  details=[f"Duplicate {k}: {i}" for k, v in dp.items() for i in v]))
    dr = check_avg_residual_score(entity_profiles, risk_register)
    R.append(dict(n=7, name="avg_residual_score recompute", status="FLAG" if dr else "PASS",
                  details=[f"{e}: stated={st}, computed={c}" for e, st, c in dr]))
    ex = check_exports_nonempty(d)
    R.append(dict(n=8, name="Export non-emptiness", status="FAIL" if any(v == "EMPTY" for v in ex.values()) else "PASS",
                  details=[f"{f}: {v}" for f, v in ex.items()]))
    return R


def render(R):
    print("\n=== GIA 8-Point Reconciliation Report ===\n")
    for r in R:
        print(f"{r['n']}. {r['name']}: {r['status']}")
        for x in r["details"]:
            print(f"   - {x}")
    print("\n=== End of report ===\n")


def main():
    parser = argparse.ArgumentParser(description="GIA 8-point data reconciliation checker")
    parser.add_argument("--data-dir", required=True, help="Path to the 06_DATA directory")
    parser.add_argument("--json", action="store_true", help="print structured result as JSON after the report")
    parser.add_argument("--strict", action="store_true", help="exit 1 if any check FAILs")
    args = parser.parse_args()
    R = run_checks(args.data_dir)
    render(R)
    if args.json:
        print(json.dumps(R, indent=2))
    if args.strict and any(r["status"] == "FAIL" for r in R):
        sys.exit(1)


if __name__ == "__main__":
    main()
