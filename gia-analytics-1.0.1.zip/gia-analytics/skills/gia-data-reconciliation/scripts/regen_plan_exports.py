#!/usr/bin/env python3
"""
Regenerate AUDIT_PLAN.csv (and .xlsx, if openpyxl is available) from
audit_plan.json. audit_plan.json is always the source of truth -- never
hand-edit the exports directly.

Usage:
    python regen_plan_exports.py --audit-plan /path/to/audit_plan.json --out-dir /path/to/output
"""
import argparse
import csv
import json
import os

DEFAULT_CAPACITY = 132  # planning days per quarter; overridden by config/planning_config.json or --capacity-days


FIELD_ORDER = [
    "PlanID", "Year", "Quarter", "QuarterStart", "Entity", "EngagementTitle",
    "EngagementType", "LinkedRisks", "ScopeSummary", "Justification",
    "EstimatedEffortDays", "LeadRole", "Status", "Priority",
    "DeliverableStandard", "EntityTier",
]


def load_audit_plan(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def write_csv(plan, out_path):
    with open(out_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELD_ORDER)
        writer.writeheader()
        for row in plan:
            flat = dict(row)
            if isinstance(flat.get("LinkedRisks"), list):
                flat["LinkedRisks"] = "; ".join(flat["LinkedRisks"])
            writer.writerow({k: flat.get(k, "") for k in FIELD_ORDER})
    print(f"Wrote {out_path} ({len(plan)} rows)")


def write_xlsx(plan, out_path):
    try:
        from openpyxl import Workbook
    except ImportError:
        print("openpyxl not available -- skipping .xlsx export (CSV still written)")
        return
    wb = Workbook()
    ws = wb.active
    ws.title = "Audit Plan"
    ws.append(FIELD_ORDER)
    for row in plan:
        flat = dict(row)
        if isinstance(flat.get("LinkedRisks"), list):
            flat["LinkedRisks"] = "; ".join(flat["LinkedRisks"])
        ws.append([flat.get(k, "") for k in FIELD_ORDER])
    # basic readability: freeze header, widen columns a bit
    ws.freeze_panes = "A2"
    for col_cells in ws.columns:
        length = max(len(str(c.value)) if c.value is not None else 0 for c in col_cells)
        ws.column_dimensions[col_cells[0].column_letter].width = min(max(length + 2, 10), 60)
    wb.save(out_path)
    print(f"Wrote {out_path} ({len(plan)} rows)")


def capacity_check(plan, ceiling=DEFAULT_CAPACITY):
    """Print a per-quarter days total vs the planning ceiling. Returns {quarter: total}."""
    totals = {}
    for row in plan:
        key = row.get("Quarter", "UNKNOWN")
        totals[key] = totals.get(key, 0) + int(row.get("EstimatedEffortDays", 0) or 0)
    print(f"\nPer-quarter effort-day totals (ceiling: {ceiling} days/quarter):")
    for quarter, total in sorted(totals.items()):
        flag = "  <-- EXCEEDS CEILING" if total > ceiling else ""
        print(f"  {quarter}: {total} days{flag}")
    return totals


def config_ceiling(config_path):
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            return int(json.load(f)["capacity"]["planning_days_per_quarter"])
    except Exception:
        return DEFAULT_CAPACITY


def main():
    parser = argparse.ArgumentParser(description="Regenerate AUDIT_PLAN exports from audit_plan.json")
    parser.add_argument("--audit-plan", required=True, help="Path to audit_plan.json")
    parser.add_argument("--out-dir", required=True, help="Directory to write AUDIT_PLAN.csv/.xlsx into")
    parser.add_argument("--config", default=os.path.join(os.path.dirname(__file__), "..", "config", "planning_config.json"))
    parser.add_argument("--capacity-days", type=int, help="override the quarterly planning ceiling")
    args = parser.parse_args()
    ceiling = args.capacity_days or config_ceiling(args.config)

    os.makedirs(args.out_dir, exist_ok=True)
    plan = load_audit_plan(args.audit_plan)

    write_csv(plan, os.path.join(args.out_dir, "AUDIT_PLAN.csv"))
    write_xlsx(plan, os.path.join(args.out_dir, "AUDIT_PLAN.xlsx"))
    capacity_check(plan, ceiling)


if __name__ == "__main__":
    main()
