#!/usr/bin/env python3
"""Composite priority score for audit-plan lines (weights from config/planning_config.json).

Score = w_res*Residual + w_rec*Recency + w_fraud*FraudFlag + w_reg*RegulatoryExposure + w_cae*CAEJudgment
Inputs per line (JSON list), all on a 0-25 residual scale and 0-5 for the others, normalised here to 0-1:
  {"PlanID": "...", "ResidualScore": 0-25, "Recency": 0-5, "FraudFlag": 0-5, "RegulatoryExposure": 0-5,
   "CAEJudgment": 0-5, "Tier": "Critical|High|Medium|Low", "FraudLinked": true|false}
Buckets: P1 = top quartile by score OR (Tier Critical and FraudLinked); P3 = bottom quartile; else P2.
Scores are decision support; the CAE judgment overlay is a human input.
Usage: python3 priority_score.py --lines lines.json [--config planning_config.json]
"""
import argparse, json, os, sys

def score(line, w):
    return round(
        w["residual_score"] * (float(line["ResidualScore"]) / 25.0)
        + w["recency"] * (float(line["Recency"]) / 5.0)
        + w["fraud_flag"] * (float(line["FraudFlag"]) / 5.0)
        + w["regulatory_exposure"] * (float(line["RegulatoryExposure"]) / 5.0)
        + w["cae_judgment"] * (float(line["CAEJudgment"]) / 5.0), 4)

def rank(lines, w):
    out = [dict(l, Score=score(l, w)) for l in lines]
    if not out:
        return out
    srt = sorted(x["Score"] for x in out)
    q3 = srt[int(0.75 * (len(srt) - 1))]
    q1 = srt[int(0.25 * (len(srt) - 1))]
    for x in out:
        if x["Score"] >= q3 or (x.get("Tier") == "Critical" and x.get("FraudLinked")):
            x["Bucket"] = "P1"
        elif x["Score"] <= q1:
            x["Bucket"] = "P3"
        else:
            x["Bucket"] = "P2"
    return sorted(out, key=lambda x: -x["Score"])

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lines", required=True)
    ap.add_argument("--config", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config", "planning_config.json"))
    a = ap.parse_args()
    w = json.load(open(a.config))["priority_weights"]
    if abs(sum(w.values()) - 1.0) > 1e-9:
        print(f"ERROR: weights sum to {sum(w.values())}, expected 1.0", file=sys.stderr); sys.exit(2)
    print(json.dumps(rank(json.load(open(a.lines)), w), indent=2))

if __name__ == "__main__":
    main()
