---
name: gia-data-reconciliation
description: "Reconciles the GIA data layer (entities, engagements, risk register, RACM, audit plan JSON): 8-point integrity checklist, plan exports, plan-line prioritisation, quarterly capacity check. Use when you need to validate or cross-check GIA data, regenerate AUDIT_PLAN, or resolve PlanID, RiskID or RACM_ID references. Do NOT use for report narrative (use gia-report-qa)."
---

# GIA Data Reconciliation and Audit Plan Maintenance

Data-integrity and planning-math skill. Report format is not set here: reports follow the standard concise IA report plus Excel working paper (`gia-report-qa:ia-report`); this skill supplies the clean data underneath.

## 1. Principle: JSON is the source of truth

The `06_DATA/*.json` files are canonical. `AUDIT_PLAN.csv` and `.xlsx` are always regenerated from `audit_plan.json`, never hand-edited. A request to "fix the CSV" means fixing the JSON and regenerating, and saying so.

## 2. The 8-point checklist (run before delivering any data-derived artefact)

Run when asked to clean up, validate or check the data, before any export or dashboard drawing on several JSON files, and after any edit to more than one file.

| # | Check | Defect means |
|---|---|---|
| 1 | Entity-name consistency: every `Entity` matches a canonical name in entities.json; aliases and near-matches are defects | Reporting by entity splits or drops rows |
| 2 | Risk-count consistency: profile `total_risks` equals actual rows per entity | Dashboards disagree with the register |
| 3 | AuditEvidence resolution: every ENG reference exists in engagements.json (slash and dash ranges expanded) | Evidence trail broken |
| 4 | RACM cross-reference: every RiskID exists in the register and the entity matches | Control mapped to another entity's risk |
| 5 | Plan linkage: every LinkedRisks entry resolves | Plan line without a risk basis |
| 6 | Duplicate IDs: none across RiskID, RACM_ID, EngagementID, PlanID | Counts and joins corrupt |
| 7 | Residual-score recompute: profile average within tolerance of the register | Stale profile |
| 8 | Export non-emptiness: CSV and XLSX non-empty and match the JSON | Stale or blank export |

Run: `python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-data-reconciliation/scripts/reconcile.py --data-dir <06_DATA> [--strict] [--json]`. `--strict` exits 1 on any FAIL. Report as a table: check number, status, defect detail, affected records. Do not silently auto-fix substantive defects (entity names, IDs); only regenerate exports mechanically.

Entity code: use `MKSDL`. The alias `MKSLD` is recognised from `entities.json` and reported as a defect to normalise (owner to confirm the convention).

## 3. Coverage tiers, scoring and capacity (data in `config/planning_config.json`)

The tier table, weights, capacity model and refresh triggers are owner-maintained data with an as-of date, not method. Read them from the file; do not copy values into outputs without the as-of date. If the file is past its review date, say so.

Composite priority score: weighted sum of residual score, recency, fraud flag, regulatory exposure and CAE judgment overlay; weights in the config. `python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-data-reconciliation/scripts/priority_score.py --lines lines.json` scores and buckets (P1, P2, P3). The CAE judgment input is a human decision. Recency treats a never-tested risk as maximum. Fraud flag applies to fraud and corruption categories or open investigations.

Capacity: planning days per quarter come from the config (core FTE, productive days, reserve). `scripts/regen_plan_exports.py` flags any quarter above the ceiling. When adding a plan line, check the receiving quarter first; do not overcommit silently.

## 4. Rolling-plan refresh

Triggers (config `refresh_triggers`) cause an out-of-cycle refresh, not only the quarterly cadence. On refresh: re-score against the current register, roll forward one quarter keeping a constant 24-month look-ahead, and mark superseded or closed rows through `Status`. Never delete or renumber a PlanID.

## 5. Conventions in outputs

Deliverable numbering `GIA/CIAR/IAR-YYYY-[ENTITY]-NNN`. RACM schema fields: Process, SubProcess, RiskID, ControlID, ControlType, ControlNature, Frequency, ControlOwner, TestProcedure, TestResult, DeficiencyRef, RemediationStatus. Basis of statements: counts and totals are labelled with their source file and as-of date (Rule 39).

## 6. Tests

`python3 -I tests/test_reconcile.py` (fixtures `fixtures/data_good` and `fixtures/data_bad` with one seeded defect per check).

## Related

`gia-analytics:gia-continuous-assurance` (monitoring design) | `gia-audit` (planning and statutory) | `gia-fraud:gia-fraud-analytics` (fraud tests) | `gia-report-qa` (reports) | `gia-core:iron-rules`.
