#!/usr/bin/env python3
"""Sensitivity tools for audit scenario modelling. Standard library only.

Subcommands
  grid       Two-variable grid of an arithmetic expression:   --spec grid.json
  tornado    One-at-a-time +/- swing of each input:            --spec tornado.json
  scenarios  Status quo / partial control / structural fix with payback:  --spec scenarios.json

Expression language (grid, tornado): numbers, named variables, + - * / ** and parentheses, min(), max(), abs().
Nothing else is evaluated (parsed with `ast`; no names outside the inputs, no calls other than those three).

Rules enforced:
  * every input carries a label ACTUAL | ASSUMPTION | ILLUSTRATIVE (unlabelled input = error)
  * a range is produced only when a `range_driver` justification is supplied
  * base exposure is verified exception value / observed months (refuses months <= 0)
  * no confidence percentage is ever output; outputs are ranges and sensitivities, not predictions
  * a scenario is never presented as a prediction: output carries a falsifier line from the spec (required)
Specs: see fixtures/*.json.
"""
import argparse, ast, csv, json, operator, sys

OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul, ast.Div: operator.truediv, ast.Pow: operator.pow}
FUNCS = {"min": min, "max": max, "abs": abs}
LABELS = ("ACTUAL", "ASSUMPTION", "ILLUSTRATIVE")

def evaluate(expr, env):
    def ev(n):
        if isinstance(n, ast.Expression): return ev(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)): return n.value
        if isinstance(n, ast.Name):
            if n.id not in env: raise ValueError(f"unknown variable {n.id!r}")
            return env[n.id]
        if isinstance(n, ast.BinOp) and type(n.op) in OPS: return OPS[type(n.op)](ev(n.left), ev(n.right))
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, ast.USub): return -ev(n.operand)
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in FUNCS and not n.keywords:
            return FUNCS[n.func.id](*[ev(a) for a in n.args])
        raise ValueError(f"unsupported expression element: {ast.dump(n)[:60]}")
    return ev(ast.parse(expr, mode="eval"))

def check_labels(inputs):
    bad = [k for k, v in inputs.items() if not isinstance(v, dict) or v.get("label") not in LABELS or "value" not in v]
    if bad: raise ValueError(f"inputs missing value or label (ACTUAL/ASSUMPTION/ILLUSTRATIVE): {bad}")
    return {k: v["value"] for k, v in inputs.items()}

def grid(spec):
    base = check_labels(spec["inputs"]); x, y = spec["x"], spec["y"]
    for ax in (x, y):
        if ax["var"] not in base: raise ValueError(f"axis variable {ax['var']!r} not in inputs")
    rows = []
    for yv in y["values"]:
        rows.append({"y": yv, "cells": [round(evaluate(spec["expression"], dict(base, **{x["var"]: xv, y["var"]: yv})), 4) for xv in x["values"]]})
    return {"expression": spec["expression"], "x_var": x["var"], "x_values": x["values"], "y_var": y["var"],
            "labels": {k: v["label"] for k, v in spec["inputs"].items()}, "rows": rows}

def tornado(spec):
    base = check_labels(spec["inputs"]); pct = spec.get("swing_pct", 20) / 100.0
    centre = evaluate(spec["expression"], base); out = []
    for k, v in base.items():
        lo = evaluate(spec["expression"], dict(base, **{k: v * (1 - pct)}))
        hi = evaluate(spec["expression"], dict(base, **{k: v * (1 + pct)}))
        out.append({"input": k, "label": spec["inputs"][k]["label"], "low": round(lo, 4), "high": round(hi, 4), "swing": round(abs(hi - lo), 4)})
    return {"centre": round(centre, 4), "swing_pct": pct * 100, "ranked": sorted(out, key=lambda r: -r["swing"]),
            "note": "swing is output change for the input varied alone; the most sensitive input is where evidence effort should go"}

def scenarios(spec):
    if not spec.get("falsifier"): raise ValueError("falsifier line required: which observed fact would invalidate this forecast?")
    if spec["observed_months"] <= 0: raise ValueError("observed_months must be positive")
    for k in ("verified_exception_value", "observed_months", "horizon_months"):
        if k not in spec: raise ValueError(f"missing {k}")
    unlabeled = [s["name"] for s in spec["scenarios"] if s.get("label") not in LABELS]
    if unlabeled: raise ValueError(f"scenario effectiveness needs a label ACTUAL/ASSUMPTION/ILLUSTRATIVE: {unlabeled}")
    base_m = spec["verified_exception_value"] / spec["observed_months"]
    h = spec["horizon_months"]
    status_quo = base_m * h * spec.get("volume_factor", 1.0) * spec.get("persistence_factor", 1.0)
    out = []
    for s in spec["scenarios"]:
        residual = status_quo * (1 - s["effectiveness"])
        avoided = status_quo - residual
        one_time, recurring = s.get("one_time_cost", 0.0), s.get("recurring_monthly_cost", 0.0)
        avoided_m = avoided / h
        net_m = avoided_m - recurring
        out.append({"scenario": s["name"], "label": s["label"], "effectiveness": s["effectiveness"],
                    "exposure_over_horizon": round(residual, 2), "avoided_over_horizon": round(avoided, 2),
                    "one_time_cost": one_time, "recurring_cost_over_horizon": round(recurring * h, 2),
                    "net_benefit_over_horizon": round(avoided - one_time - recurring * h, 2),
                    "payback_months": round(one_time / net_m, 2) if net_m > 0 and one_time > 0 else (0.0 if one_time == 0 and net_m > 0 else None)})
    res = {"base_monthly_exposure": round(base_m, 2), "horizon_months": h,
           "exclusions": spec.get("exclusions", []), "scenarios": out, "falsifier": spec["falsifier"],
           "note": "scenarios are not predictions; range shown only with a stated driver; no confidence percentage"}
    if spec.get("range_driver"):
        res["range"] = {"low_0.5x": round(status_quo * 0.5, 2), "base_1x": round(status_quo, 2), "high_1.5x": round(status_quo * 1.5, 2), "driver": spec["range_driver"]}
    else:
        res["range"] = "not produced: no range_driver justification supplied"
    return res

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("cmd", choices=["grid", "tornado", "scenarios"])
    ap.add_argument("--spec", required=True); ap.add_argument("--out"); ap.add_argument("--csv", help="grid only: also write CSV")
    a = ap.parse_args()
    try:
        r = {"grid": grid, "tornado": tornado, "scenarios": scenarios}[a.cmd](json.load(open(a.spec)))
    except (ValueError, KeyError, ZeroDivisionError) as e:
        print(f"ERROR: {e}", file=sys.stderr); sys.exit(2)
    if a.cmd == "grid" and a.csv:
        with open(a.csv, "w", newline="") as f:
            w = csv.writer(f); w.writerow([f"{r['y_var']}\\{r['x_var']}"] + r["x_values"])
            for row in r["rows"]: w.writerow([row["y"]] + row["cells"])
    if a.out: json.dump(r, open(a.out, "w"), indent=2)
    print(json.dumps(r, indent=2))

if __name__ == "__main__":
    main()
