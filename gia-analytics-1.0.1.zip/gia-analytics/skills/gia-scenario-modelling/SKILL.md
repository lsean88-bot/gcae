---
name: gia-scenario-modelling
description: "Audit scenario and sensitivity models: exposure extrapolation, three scenarios with break-even and payback, sensitivity grids, tornado ranking, assumptions register. Use when a decision-maker needs what-if numbers, remediation comparisons or exposure projection. Do NOT use for KPI trends (use gia-analytics:gia-performance-analytics) or cost variances (use gia-analytics:gia-cost-accounting)."
---

# Scenario and Sensitivity Modelling

Models show how an answer moves when assumptions move. They are not predictions and never carry an invented confidence figure. Rules by number are in `gia-core:iron-rules` (Rules 12, 14, 34, 37, 39).

## 1. Before modelling

1. State every input, its source and its label: ACTUAL (from evidence, with reference), ASSUMPTION (stated range if a point estimate is not defensible) or ILLUSTRATIVE (placeholder to be confirmed by the user). Unlabelled inputs are not accepted by the script. Silent assumptions are prohibited; labelled ones are allowed.
2. If inputs are too thin to model responsibly, say "insufficient data to model reliably" and list the inputs needed. Do not produce a precise-looking number anyway.
3. Separate recurring run-rate from one-off items. Never annualise a one-off. Exclude disputed, recovered and unverified items and list the exclusions.

## 2. Extrapolation template

```
Base monthly exposure = verified exception value / observed months
Projected exposure    = base x horizon x volume factor x persistence factor
Range                 = Low 0.5x / Base 1x / High 1.5x ONLY with a stated driver for the spread
Confidence            = Low / Medium / High with the reason (qualitative; no percentage)
```

## 3. Three scenarios

| Scenario | Content |
|---|---|
| S0 status quo | Exposure path, reporting or regulatory consequences, detection latency |
| S1 partial control | What remains detectable and the residual leakage. If the user gave no effectiveness input, apply a labelled ILLUSTRATIVE placeholder (for example 50%) and list the input to confirm |
| S2 structural fix | Root-cause removal, cost, payback, residual risk, key risk indicator |

Show all three, always. Break-even: one-time cost / (avoided monthly exposure - recurring monthly cost) = months to payback. Resource projections separate one-time implementation from recurring monitoring effort. Include a falsifier line: which observed fact would invalidate this forecast.

## 4. Tools

`python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-scenario-modelling/scripts/sensitivity_grid.py <grid|tornado|scenarios> --spec spec.json [--out result.json] [--csv grid.csv]`
- `grid`: any arithmetic expression over two varied inputs (for example finished weight by scrap price, or effectiveness by horizon).
- `tornado`: each input varied alone by plus or minus a percentage; ranks by output swing, so evidence effort goes to the most sensitive input.
- `scenarios`: the S0, S1, S2 table above with payback; refuses a missing falsifier, unlabelled effectiveness, or non-positive observed months; produces a range only when a driver is supplied.
Specs: `fixtures/grid.json`, `fixtures/scenarios.json`. Expressions are parsed safely (arithmetic, min, max, abs only).

## 5. Reporting

Show the formula, inputs with labels, period, exclusions, range with its driver, the most sensitive input, limitations (what the model cannot capture and what would break it, for example a regime change) and the falsifier. Label results "ESTIMATE", never "actual loss". A range is not an audited figure. Basis class per statement (Rule 37); like-for-like base and cut-off dates stated (Rule 39). Fraud-related exposure follows the impact ladder in `gia-fraud:gia-fraud-investigation` (observed, potential, quantified, corroborated, confirmed).

## 6. Agents

The `scenario-simulator` agent (sonnet) runs this skill; independent review by a different agent (`gia-report-qa`).

## Tests

`python3 -I tests/test_sensitivity_grid.py` (hand-computed grid, tornado, payback; evaluator rejects unsafe expressions).

## Related

`gia-fraud:gia-fraud-rbia-frm` (engagement-level forecast stage) | `gia-analytics:gia-continuous-assurance` | `gia-analytics:gia-performance-analytics` | `gia-core:iron-rules`.
