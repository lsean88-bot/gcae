"""control_limits.py: 3-sigma alarm, 2-sigma warning, run rule, flat baseline, refusal. Hand-computed baseline."""
import pathlib, sys, math, subprocess, tempfile, csv, json
SK = pathlib.Path(__file__).resolve().parent.parent / "skills" / "gia-performance-analytics" / "scripts"
sys.path.insert(0, str(SK))
import control_limits as cl
res = []
def t(n, c): res.append((n, bool(c))); print("PASS" if c else "FAIL", n)
base = [10, 12] * 6                         # mean 11; sample sd = sqrt(12/11) = 1.04447
m, sd = cl.mean_sd(base)
t("baseline mean 11", abs(m - 11) < 1e-12)
t("baseline sample sd sqrt(12/11)", abs(sd - math.sqrt(12 / 11)) < 1e-12)
def flag(v, **kw): return cl.evaluate(base + [v], **kw)[0]["flag"]
t("11.0 inside limits -> OK", flag(11.0) == "OK")
t("13.5 (z=2.39) -> WARNING", flag(13.5) == "WARNING")
t("15.0 (z=3.83) -> ALARM", flag(15.0) == "ALARM")
t("7.0 (z=-3.83) low side -> ALARM", flag(7.0) == "ALARM")
t("2.6-sigma is NOT an alarm (old +/-2sd rule would have alarmed)", flag(11 + 2.6 * sd) == "WARNING")
t("limits reported: alarm UCL = mean+3sd", abs(cl.evaluate(base + [11], baseline_n=12)[0]["ucl_alarm"] - (11 + 3 * sd)) < 1e-5)
# run rule: 8 points at 11.8 (z=0.77) all above mean, frozen baseline
r = cl.evaluate(base + [11.8] * 8)
t("8 consecutive same side -> last point WARNING_RUN", r[-1]["flag"] == "WARNING_RUN" and all(x["flag"] == "OK" for x in r[:-1]))
t("7 consecutive same side -> no run flag", all(x["flag"] == "OK" for x in cl.evaluate(base + [11.8] * 7)))
t("run broken by a point at the mean resets", all(x["flag"] == "OK" for x in cl.evaluate(base + [11.8] * 5 + [11.0] + [11.8] * 5)))
# flat baseline
fl = cl.evaluate([5.0] * 12 + [5.0, 6.0])
t("flat baseline: identical point OK, different point BASELINE_FLAT", fl[0]["flag"] == "OK" and fl[1]["flag"] == "BASELINE_FLAT")
# refusals
for bad, kw in (([1, 2, 3], {}), ([1.0] * 12, {}), ([1.0] * 20, {"baseline_n": 4})):
    try: cl.evaluate(bad, **kw); ok = False
    except ValueError: ok = True
    t(f"refuses short series/baseline {len(bad)}/{kw}", ok)
# rolling baseline adapts to a sustained shift (frozen would alarm)
shift = base + [20.0] * 6
t("frozen baseline flags a level shift as ALARM", cl.evaluate(shift)[0]["flag"] == "ALARM")
t("rolling baseline: first shifted point ALARM, later points adapt", cl.evaluate(shift, rolling=True)[0]["flag"] == "ALARM" and cl.evaluate(shift, rolling=True)[-1]["flag"] != "ALARM")
# CLI
d = tempfile.mkdtemp(); p = pathlib.Path(d) / "s.csv"
with open(p, "w", newline="") as f:
    w = csv.writer(f); w.writerow(["value"]); [w.writerow([v]) for v in base + [15.0]]
o = subprocess.run([sys.executable, str(SK / "control_limits.py"), "--input", str(p)], capture_output=True, text=True)
t("cli summary shows 1 ALARM", json.loads(o.stdout)["ALARM"] == 1)
print(f"{sum(v for _, v in res)}/{len(res)} passed")
sys.exit(0 if all(v for _, v in res) else 1)
