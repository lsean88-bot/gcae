#!/bin/sh
# Run from anywhere. Writes tests/RESULTS.md from real output (exit code recorded per test).
D=$(cd "$(dirname "$0")/.." && pwd)
OUT="$D/tests/RESULTS.md"
T=$(mktemp)
FAIL=0
{
echo "# Test results - gia-analytics"
echo "Run: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
for t in test_reconcile.py test_control_limits.py test_variance_calc.py test_recovery.py test_sensitivity_grid.py test_monitoring_register.py test_payroll_tests.py; do
  python3 -I "$D/tests/$t" > "$T" 2>&1; rc=$?
  [ $rc -ne 0 ] && FAIL=1
  echo; echo "## $t (exit $rc)"; echo '```'; tail -40 "$T"; echo '```'
done
python3 -I "$D/../validate_structure.py" "$D" > "$T" 2>&1; rc=$?
[ $rc -ne 0 ] && FAIL=1
echo; echo "## validate_structure.py (exit $rc)"; echo '```'; tail -40 "$T"; echo '```'
echo; echo "Overall: $([ $FAIL -eq 0 ] && echo PASS || echo FAIL)"
} > "$OUT"
rm -f "$T"
grep -E "passed|RESULT|checks passed|^FAIL|^## |Overall" "$OUT"
exit $FAIL
