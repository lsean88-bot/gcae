"""recovery_model.py hand-computed worked example; workbook formulas recalculated in LibreOffice and compared with the model."""
import json, pathlib, shutil, subprocess, sys, tempfile
SK = pathlib.Path(__file__).resolve().parent.parent / "skills" / "gia-recovery-analysis"
sys.path.insert(0, str(SK / "scripts"))
import recovery_model as rm, build_workbook as bw
res = []
def t(n, c): res.append((n, bool(c))); print("PASS" if c else "FAIL", n)
case = json.load(open(SK / "fixtures" / "worked_example.json"))
p = rm.per_piece(case)
exp = dict(scrap_kg=4.5, gap=70.0, scrap_value=171.0, net_material_cost=369.0, contribution_over_material=101.0, steel_in_finished=270.0, scrap_spread_loss=99.0)
for k, v in exp.items(): t(f"hand-computed {k} = {v}", abs(p[k] - v) < 1e-9)
t("break-even scrap price 70/4.5 = 15.5556", abs(p["break_even_scrap_price"] - 15.5556) < 1e-4)
t("identity contribution = scrap_value - gap", abs(p["contribution_over_material"] - (p["scrap_value"] - p["gap"])) < 1e-9)
t("at break-even scrap price contribution is zero", abs(rm.per_piece(dict(case, scrap_price=70 / 4.5))["contribution_over_material"]) < 1e-9)
pop = rm.population(case, p)
t("population 9,000 sold x 4.5 kg = 40,500 kg; 10,000 bought = 45,000; 1,000 unsold", pop["scrap_kg_on_parts_sold"] == 40500 and pop["scrap_kg_on_all_blanks_bought"] == 45000 and pop["blanks_not_yet_sold"] == 1000)
gr = rm.grid(case, [4.2, 4.5, 4.8], [30, 38, 46])
t("grid centre = per-piece contribution (101); corners 74/150.8/56/123.2", gr[1]["scrap_price_38"] == 101 and gr[0]["scrap_price_30"] == 74 and gr[0]["scrap_price_46"] == 150.8 and gr[2]["scrap_price_30"] == 56 and gr[2]["scrap_price_46"] == 123.2)
try: rm.per_piece(dict(case, finished_kg=9.5)); ok = False
except ValueError: ok = True
t("refuses finished weight above blank weight", ok)
# workbook
d = pathlib.Path(tempfile.mkdtemp()); x = d / "t.xlsx"; bw.build(str(x), case)
from openpyxl import load_workbook
wb = load_workbook(x)
t("workbook has 11 sheets incl. Src_Purchase and Src_Sale", len(wb.sheetnames) == 11 and "Src_Sale" in wb.sheetnames)
t("analysis cells are formulas", str(wb["Scrap_Recovery"]["B5"].value).startswith("=") and str(wb["Sensitivity"]["C4"].value).startswith("="))
t("input cells styled blue on yellow", wb["Inputs"]["B2"].font.color.rgb.endswith("0000FF") and wb["Inputs"]["B2"].fill.fgColor.rgb.endswith("FFFF00"))
if shutil.which("soffice"):
    out = d / "out"; out.mkdir()
    r = subprocess.run(["soffice", "--headless", "--convert-to", "xlsx", "--outdir", str(out), str(x)], capture_output=True, text=True, timeout=120)
    wv = load_workbook(out / "t.xlsx", data_only=True)
    sr = wv["Scrap_Recovery"]
    t("recalculated: contribution B5 = 101", abs(sr["B5"].value - 101) < 1e-9)
    t("recalculated: break-even B7 = 15.5556", abs(sr["B7"].value - 70 / 4.5) < 1e-9)
    t("recalculated: scrap kg sold B8 = 40,500", sr["B8"].value == 40500)
    sv = wv["Sensitivity"]
    t("recalculated: sensitivity grid matches model (corners)", abs(sv["B3"].value - 74) < 1e-9 and abs(sv["D5"].value - 123.2) < 1e-9 and abs(sv["C4"].value - 101) < 1e-9)
    errs = [c.value for w in wv for row in w.iter_rows() for c in row if isinstance(c.value, str) and c.value.startswith("#")]
    t("zero formula errors after recalculation", not errs)
else:
    print("SKIPPED recalculation: soffice not available")
print(f"{sum(v for _, v in res)}/{len(res)} passed"); sys.exit(0 if all(v for _, v in res) else 1)
