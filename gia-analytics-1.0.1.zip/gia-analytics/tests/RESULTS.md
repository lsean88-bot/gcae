# Test results - gia-analytics
Run: 2026-10-30T06:56:31Z

## test_reconcile.py (exit 0)
```
PASS good fixture: checks 1-7 all PASS
PASS good fixture: check 8 PASS (csv present)
PASS good fixture: slash and dash ENG ranges expand
PASS bad: check1 flags near-match entity
PASS bad: check1 flags alias MKSLD as alias of MKSDL
PASS bad: check2 flags wrong total_risks
PASS bad: check3 flags missing engagement
PASS bad: check4 flags missing risk and entity mismatch
PASS bad: check5 flags missing linked risk
PASS bad: check6 flags duplicate RiskID and PlanID
PASS bad: check7 flags avg score drift
PASS bad: check8 flags empty export
PASS cli --strict exit 0 on good
PASS cli --strict exit 1 on bad
PASS cli default exit 0 (original behaviour kept)
  [SKIP] entities.json not found at /tmp/tmptswumepl/entities.json
  [SKIP] engagements.json not found at /tmp/tmptswumepl/engagements.json
  [SKIP] risk_register.json not found at /tmp/tmptswumepl/risk_register.json
  [SKIP] racm.json not found at /tmp/tmptswumepl/racm.json
  [SKIP] entity_risk_profiles.json not found at /tmp/tmptswumepl/entity_risk_profiles.json
  [SKIP] audit_plan.json not found at /tmp/tmptswumepl/audit_plan.json
PASS empty dir does not crash
PASS regen writes csv with joined LinkedRisks
PASS regen flags quarter over a 100-day ceiling
PASS regen uses config ceiling 132 by default (no flag)
PASS regen xlsx written
PASS weights sum to 1
PASS max score = 1.0, min = 0.0
PASS hand-computed mid score 0.35*0.5+0.2*0.5 = 0.275
PASS Critical fraud-linked line forced to P1 despite lowest score
24/24 passed
```

## test_control_limits.py (exit 0)
```
PASS baseline mean 11
PASS baseline sample sd sqrt(12/11)
PASS 11.0 inside limits -> OK
PASS 13.5 (z=2.39) -> WARNING
PASS 15.0 (z=3.83) -> ALARM
PASS 7.0 (z=-3.83) low side -> ALARM
PASS 2.6-sigma is NOT an alarm (old +/-2sd rule would have alarmed)
PASS limits reported: alarm UCL = mean+3sd
PASS 8 consecutive same side -> last point WARNING_RUN
PASS 7 consecutive same side -> no run flag
PASS run broken by a point at the mean resets
PASS flat baseline: identical point OK, different point BASELINE_FLAT
PASS refuses short series/baseline 3/{}
PASS refuses short series/baseline 12/{}
PASS refuses short series/baseline 20/{'baseline_n': 4}
PASS frozen baseline flags a level shift as ALARM
PASS rolling baseline: first shifted point ALARM, later points adapt
PASS cli summary shows 1 ALARM
18/18 passed
```

## test_variance_calc.py (exit 0)
```
PASS hand-computed material_price = -1560
PASS hand-computed material_usage = -1800
PASS hand-computed labour_rate = 525
PASS hand-computed labour_efficiency = -1000
PASS hand-computed variable_oh_spending = -420
PASS hand-computed variable_oh_efficiency = -400
PASS hand-computed fixed_oh_spending = -500
PASS hand-computed fixed_oh_volume = -2400
PASS total = std cost allowed 85,000 - actual 92,555 = -7,555
PASS components reconcile to total
PASS labour rate favourable (positive) labelled F, others U
PASS old formula would give +1,800 (wrong sign); fixed version is -2,400
PASS over-absorbed (output above budget) -> fixed OH volume positive F
PASS yield 87.0%, scrap rate 12.5%, scrap cost 62.5, gap 5 kg
PASS yield refuses zero input
15/15 passed
```

## test_recovery.py (exit 0)
```
PASS hand-computed scrap_kg = 4.5
PASS hand-computed gap = 70.0
PASS hand-computed scrap_value = 171.0
PASS hand-computed net_material_cost = 369.0
PASS hand-computed contribution_over_material = 101.0
PASS hand-computed steel_in_finished = 270.0
PASS hand-computed scrap_spread_loss = 99.0
PASS break-even scrap price 70/4.5 = 15.5556
PASS identity contribution = scrap_value - gap
PASS at break-even scrap price contribution is zero
PASS population 9,000 sold x 4.5 kg = 40,500 kg; 10,000 bought = 45,000; 1,000 unsold
PASS grid centre = per-piece contribution (101); corners 74/150.8/56/123.2
PASS refuses finished weight above blank weight
PASS workbook has 11 sheets incl. Src_Purchase and Src_Sale
PASS analysis cells are formulas
PASS input cells styled blue on yellow
PASS recalculated: contribution B5 = 101
PASS recalculated: break-even B7 = 15.5556
PASS recalculated: scrap kg sold B8 = 40,500
PASS recalculated: sensitivity grid matches model (corners)
PASS zero formula errors after recalculation
21/21 passed
```

## test_sensitivity_grid.py (exit 0)
```
PASS evaluate arithmetic and precedence
PASS evaluate variables and min/max/abs
PASS evaluator rejects "__import__('os').system('echo "
PASS evaluator rejects 'a.__class__'
PASS evaluator rejects "open('/etc/passwd')"
PASS evaluator rejects '[1,2]'
PASS evaluator rejects 'a if b else c'
PASS evaluator rejects 'lambda: 1'
PASS unknown variable rejected
PASS grid hand-computed (6,.25)=45000 (12,.5)=60000 (24,.75)=60000
PASS grid carries input labels
PASS unlabelled input rejected
PASS tornado centre 60000; most sensitive input is effectiveness? check ranking by swing
PASS tornado swings hand-computed (24000 each for a multiplicative form)
PASS base monthly = 60000/6 = 10000
PASS S1 net benefit 36000, payback 3.0 months
PASS S2 net benefit 62000, payback 4.71 months
PASS S0 has no payback (None)
PASS range produced with driver: 60000 / 120000 / 180000
PASS range withheld without a driver
PASS falsifier required
PASS observed_months <= 0 refused
PASS unlabelled scenario effectiveness refused
PASS no confidence percentage key in output
PASS cli grid writes csv
PASS cli bad spec exits 2
26/26 passed
```

## test_monitoring_register.py (exit 0)
```
PASS good register: no errors
PASS good register: manual test (objective none) surfaced as warning
PASS bad: missing source, exception_workflow, validation, escalation flagged
PASS bad: frequency 'fortnightly' rejected
PASS bad: threshold TBD rejected
PASS bad: objective ZZ9 rejected
PASS bad: type 'reporting' rejected
PASS bad: duplicate test_id CA-01 flagged
PASS bad: monitoring owned by internal audit flagged (independence)
PASS 'CAE office' owner on monitoring row also flagged
PASS objective pattern accepts P01
PASS objective pattern accepts V02, V09
PASS objective pattern accepts FA-A3
PASS objective pattern accepts OB4
PASS objective pattern accepts O03
PASS objective pattern accepts none
PASS objective pattern rejects X1
PASS objective pattern rejects P
PASS objective pattern rejects P001
PASS objective pattern rejects fa-xyz
PASS cli exit 1 on bad register
PASS cli exit 0 on good register
PASS cli exit 2 when columns missing
23/23 passed
```

## test_payroll_tests.py (exit 0)
```
PASS P03 duplicate ID number: E1,E2 only
PASS P05 zero leave: E2 only (recent joiner E6 excluded)
PASS P06 OT on leave: E3 2026-03-10
PASS P07 OT rate variance: E4 only (expected 125.00 vs paid 100.00)
PASS P11 master change within 2 days of run: E3 only (E1 29 days earlier not flagged)
PASS P12 cost-centre variance: (CC-B, 2026-06) and (CC-A, 2026-07)
PASS P13 zero statutory deduction: E4 2026-06
PASS P14 basic above grade max: E4 only
PASS O01 OT/basic over 50%: E1 2026-07 only (E2 at 46.9% not flagged)
PASS O02 fixed OT pattern: E5 from 2026-04
PASS O03 OT above configured cap: E2 (65 > 60)
PASS C01 duplicate claim invoice: INV-1 (CL1, CL2); blank invoice ignored
PASS C03 stale claim: CL3 only
PASS C04 self-approval CL4 and reverse approval CL5
PASS C05 NOT RUN with 6 claims (minimum 30), listed in not_run
PASS every exception lists innocent explanations
PASS total exceptions = 16 (sum of the per-test counts)
PASS without statutory params P07 and O03 are NOT RUN, with reason
PASS without statutory params no P07/O03 exceptions are fabricated
PASS missing leave file: P05 and P06 NOT RUN
PASS unconfigured day_type flagged DAY-TYPE-NOT-CONFIGURED, not guessed
PASS C05 with 40 claims, 20 round -> 1 exception
PASS C05 with 40 claims, 4 round -> 0 exception
PASS cli runs and prints counts
24/24 passed
```

## validate_structure.py (exit 0)
```
checks passed: 120; failures: 0
```

Overall: PASS

## 1.0.1 defect-fix pass (30-Oct-2026)

| Item | Result |
|---|---|
| Test entry point re-run | tests/run_all_tests.sh: 24, 18, 15, 21, 26, 23, 24; structure 120/0. |
| `build/xref_check.py` (colon refs, in-skill links, router selections, description length, relative script paths, YAML frontmatter) | PASS: 0 findings |
| Economy: always-loaded name plus description tokens (chars/4) | skills 690, agents 262, commands 83, total 1035; longest skill or agent description 400 chars or fewer (target of 700 total still not met; each description is capped at 400) |
| D5 cross-references, D7 links, D13 script paths | Fixed and checked by xref_check.py |
