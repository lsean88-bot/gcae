"""sensitivity_grid.py: safe expression evaluator, grid, tornado, scenarios; hand-computed values; rule enforcement."""
import json, pathlib, subprocess, sys, tempfile
SK = pathlib.Path(__file__).resolve().parent.parent / "skills" / "gia-scenario-modelling"
sys.path.insert(0, str(SK / "scripts"))
import sensitivity_grid as sg
res = []
def t(n, c): res.append((n, bool(c))); print("PASS" if c else "FAIL", n)
def raises(f, *a):
    try: f(*a); return False
    except (ValueError, KeyError, ZeroDivisionError): return True
t("evaluate arithmetic and precedence", sg.evaluate("2 + 3 * 4 ** 2 / 8", {}) == 8.0)
t("evaluate variables and min/max/abs", sg.evaluate("max(a, b) - abs(c)", {"a": 3, "b": 5, "c": -2}) == 3)
for bad in ("__import__('os').system('echo x')", "a.__class__", "open('/etc/passwd')", "[1,2]", "a if b else c", "lambda: 1"):
    t(f"evaluator rejects {bad[:30]!r}", raises(sg.evaluate, bad, {"a": 1, "b": 1, "c": 1}))
t("unknown variable rejected", raises(sg.evaluate, "zzz + 1", {}))
spec = json.load(open(SK / "fixtures" / "grid.json"))
g = sg.grid(spec)
# 10000 * horizon * (1 - eff): rows y=horizon 6,12,24 ; cols eff .25,.5,.75
t("grid hand-computed (6,.25)=45000 (12,.5)=60000 (24,.75)=60000", g["rows"][0]["cells"][0] == 45000 and g["rows"][1]["cells"][1] == 60000 and g["rows"][2]["cells"][2] == 60000)
t("grid carries input labels", g["labels"]["effectiveness"] == "ILLUSTRATIVE")
nolabel = json.loads(json.dumps(spec)); del nolabel["inputs"]["horizon"]["label"]
t("unlabelled input rejected", raises(sg.grid, nolabel))
tor = sg.tornado(dict(spec, swing_pct=20))
t("tornado centre 60000; most sensitive input is effectiveness? check ranking by swing", tor["centre"] == 60000 and tor["ranked"][0]["swing"] >= tor["ranked"][-1]["swing"])
# swing for base_monthly: 0.8 and 1.2 -> 48000 / 72000 -> 24000 ; effectiveness: .4/.6 -> 72000/48000 -> 24000 ; horizon 9.6/14.4 -> 48000/72000 -> 24000
t("tornado swings hand-computed (24000 each for a multiplicative form)", all(abs(r["swing"] - 24000) < 1e-6 for r in tor["ranked"]))
sc = json.load(open(SK / "fixtures" / "scenarios.json"))
r = sg.scenarios(sc)
t("base monthly = 60000/6 = 10000", r["base_monthly_exposure"] == 10000)
s = {x["scenario"][:2]: x for x in r["scenarios"]}
t("S1 net benefit 36000, payback 3.0 months", s["S1"]["net_benefit_over_horizon"] == 36000 and s["S1"]["payback_months"] == 3.0)
t("S2 net benefit 62000, payback 4.71 months", s["S2"]["net_benefit_over_horizon"] == 62000 and s["S2"]["payback_months"] == 4.71)
t("S0 has no payback (None)", s["S0"]["payback_months"] is None)
t("range produced with driver: 60000 / 120000 / 180000", r["range"]["low_0.5x"] == 60000 and r["range"]["high_1.5x"] == 180000)
nd = dict(sc); nd.pop("range_driver")
t("range withheld without a driver", isinstance(sg.scenarios(nd)["range"], str) and "not produced" in sg.scenarios(nd)["range"])
nf = dict(sc); nf.pop("falsifier")
t("falsifier required", raises(sg.scenarios, nf))
t("observed_months <= 0 refused", raises(sg.scenarios, dict(sc, observed_months=0)))
nl = json.loads(json.dumps(sc)); del nl["scenarios"][1]["label"]
t("unlabelled scenario effectiveness refused", raises(sg.scenarios, nl))
t("no confidence percentage key in output", "confidence" not in json.dumps(r).lower().replace("no confidence percentage", ""))
d = tempfile.mkdtemp(); csvp = pathlib.Path(d) / "g.csv"
o = subprocess.run([sys.executable, str(SK / "scripts" / "sensitivity_grid.py"), "grid", "--spec", str(SK / "fixtures" / "grid.json"), "--csv", str(csvp)], capture_output=True, text=True)
t("cli grid writes csv", o.returncode == 0 and csvp.read_text().splitlines()[1].startswith("6,45000"))
o = subprocess.run([sys.executable, str(SK / "scripts" / "sensitivity_grid.py"), "scenarios", "--spec", str(SK / "fixtures" / "grid.json")], capture_output=True, text=True)
t("cli bad spec exits 2", o.returncode == 2)
print(f"{sum(v for _, v in res)}/{len(res)} passed"); sys.exit(0 if all(v for _, v in res) else 1)
