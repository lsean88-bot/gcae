"""Tests for gia-data-reconciliation scripts: reconcile.py (good + seeded-defect fixtures),
regen_plan_exports.py (CSV, capacity), priority_score.py."""
import json, os, shutil, subprocess, sys, tempfile, pathlib
SK = pathlib.Path(__file__).resolve().parent.parent / "skills" / "gia-data-reconciliation"
sys.path.insert(0, str(SK / "scripts"))
import reconcile, priority_score  # noqa: E402
res = []
def t(n, c): res.append((n, bool(c))); print("PASS" if c else "FAIL", n)

good = reconcile.run_checks(str(SK / "fixtures" / "data_good"))
t("good fixture: checks 1-7 all PASS", all(r["status"] == "PASS" for r in good if r["n"] <= 7))
t("good fixture: check 8 PASS (csv present)", good[7]["status"] == "PASS")
t("good fixture: slash and dash ENG ranges expand", good[2]["status"] == "PASS")

bad = {r["n"]: r for r in reconcile.run_checks(str(SK / "fixtures" / "data_bad"))}
t("bad: check1 flags near-match entity", any("Alpha-Plant" in d and "unrecognised" in d for d in bad[1]["details"]))
t("bad: check1 flags alias MKSLD as alias of MKSDL", any("MKSLD" in d and "alias of MKSDL" in d for d in bad[1]["details"]))
t("bad: check2 flags wrong total_risks", bad[2]["status"] == "FAIL" and any("Beta Plant" in d for d in bad[2]["details"]))
t("bad: check3 flags missing engagement", any("ENG-999" in d for d in bad[3]["details"]))
t("bad: check4 flags missing risk and entity mismatch", any("R-777" in d for d in bad[4]["details"]) and any("entity=" in d for d in bad[4]["details"]))
t("bad: check5 flags missing linked risk", any("R-888" in d for d in bad[5]["details"]))
t("bad: check6 flags duplicate RiskID and PlanID", any("RiskID: R-002" in d for d in bad[6]["details"]) and any("PlanID: P-002" in d for d in bad[6]["details"]))
t("bad: check7 flags avg score drift", bad[7]["status"] == "FLAG" and any("Alpha Plant" in d for d in bad[7]["details"]))
t("bad: check8 flags empty export", bad[8]["status"] == "FAIL" and any("EMPTY" in d for d in bad[8]["details"]))

# CLI: --strict exit codes
py = [sys.executable]
r = subprocess.run(py + [str(SK / "scripts" / "reconcile.py"), "--data-dir", str(SK / "fixtures" / "data_good"), "--strict"], capture_output=True, text=True)
t("cli --strict exit 0 on good", r.returncode == 0)
r = subprocess.run(py + [str(SK / "scripts" / "reconcile.py"), "--data-dir", str(SK / "fixtures" / "data_bad"), "--strict"], capture_output=True, text=True)
t("cli --strict exit 1 on bad", r.returncode == 1)
r = subprocess.run(py + [str(SK / "scripts" / "reconcile.py"), "--data-dir", str(SK / "fixtures" / "data_bad")], capture_output=True, text=True)
t("cli default exit 0 (original behaviour kept)", r.returncode == 0)

# missing files tolerated
d = tempfile.mkdtemp()
t("empty dir does not crash", isinstance(reconcile.run_checks(d), list))

# regen_plan_exports
out = tempfile.mkdtemp()
r = subprocess.run(py + [str(SK / "scripts" / "regen_plan_exports.py"), "--audit-plan", str(SK / "fixtures" / "data_good" / "audit_plan.json"), "--out-dir", out, "--capacity-days", "100"], capture_output=True, text=True)
csvt = pathlib.Path(out, "AUDIT_PLAN.csv").read_text()
t("regen writes csv with joined LinkedRisks", "R-001; R-002" in csvt)
t("regen flags quarter over a 100-day ceiling", "2027-Q1: 120 days  <-- EXCEEDS CEILING" in r.stdout)
r2 = subprocess.run(py + [str(SK / "scripts" / "regen_plan_exports.py"), "--audit-plan", str(SK / "fixtures" / "data_good" / "audit_plan.json"), "--out-dir", out], capture_output=True, text=True)
t("regen uses config ceiling 132 by default (no flag)", "ceiling: 132" in r2.stdout and "EXCEEDS" not in r2.stdout)
t("regen xlsx written", pathlib.Path(out, "AUDIT_PLAN.xlsx").exists())

# priority score
w = json.load(open(SK / "config" / "planning_config.json"))["priority_weights"]
t("weights sum to 1", abs(sum(w.values()) - 1) < 1e-9)
top = dict(PlanID="A", ResidualScore=25, Recency=5, FraudFlag=5, RegulatoryExposure=5, CAEJudgment=5)
low = dict(PlanID="B", ResidualScore=0, Recency=0, FraudFlag=0, RegulatoryExposure=0, CAEJudgment=0)
t("max score = 1.0, min = 0.0", priority_score.score(top, w) == 1.0 and priority_score.score(low, w) == 0.0)
mid = dict(PlanID="C", ResidualScore=12.5, Recency=2.5, FraudFlag=0, RegulatoryExposure=0, CAEJudgment=0)
t("hand-computed mid score 0.35*0.5+0.2*0.5 = 0.275", priority_score.score(mid, w) == 0.275)
lines = [dict(top, PlanID=f"L{i}", ResidualScore=25 - 5 * i) for i in range(5)] + [dict(low, PlanID="CF", Tier="Critical", FraudLinked=True)]
rk = {x["PlanID"]: x for x in priority_score.rank(lines, w)}
t("Critical fraud-linked line forced to P1 despite lowest score", rk["CF"]["Bucket"] == "P1")
print(f"{sum(v for _, v in res)}/{len(res)} passed")
sys.exit(0 if all(v for _, v in res) else 1)
