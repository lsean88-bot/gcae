"""check_monitoring_register.py on a good and a seeded-bad register."""
import csv, pathlib, subprocess, sys, tempfile
SK = pathlib.Path(__file__).resolve().parent.parent / "skills" / "gia-continuous-assurance"
sys.path.insert(0, str(SK / "scripts"))
import check_monitoring_register as cm
res = []
def t(n, c): res.append((n, bool(c))); print("PASS" if c else "FAIL", n)
rd = lambda p: list(csv.DictReader(open(p, newline="")))
e, w = cm.check(rd(SK / "fixtures" / "register_good.csv"))
t("good register: no errors", e == [])
t("good register: manual test (objective none) surfaced as warning", len(w) == 1 and "CA-03" in w[0])
e, w = cm.check(rd(SK / "fixtures" / "register_bad.csv"))
joined = "\n".join(e)
t("bad: missing source, exception_workflow, validation, escalation flagged", all(x in joined for x in ("missing source", "missing exception_workflow", "missing validation", "missing escalation")))
t("bad: frequency 'fortnightly' rejected", "fortnightly" in joined)
t("bad: threshold TBD rejected", "threshold must be set in advance" in joined)
t("bad: objective ZZ9 rejected", "ZZ9" in joined)
t("bad: type 'reporting' rejected", "type must be monitoring or assurance" in joined)
t("bad: duplicate test_id CA-01 flagged", "duplicate test_id" in joined)
t("bad: monitoring owned by internal audit flagged (independence)", "CA-05" in joined and "monitoring owner is internal audit" in joined)
t("'CAE office' owner on monitoring row also flagged", "CA-01: monitoring owner is internal audit" in joined)
# objective id patterns
for ok_id in ("P01", "V02, V09", "FA-A3", "OB4", "O03", "none"): t(f"objective pattern accepts {ok_id}", cm.OBJ.match(ok_id))
for bad_id in ("X1", "P", "P001", "fa-xyz"): t(f"objective pattern rejects {bad_id}", not cm.OBJ.match(bad_id))
r = subprocess.run([sys.executable, str(SK / "scripts" / "check_monitoring_register.py"), "--register", str(SK / "fixtures" / "register_bad.csv")], capture_output=True, text=True)
t("cli exit 1 on bad register", r.returncode == 1)
r = subprocess.run([sys.executable, str(SK / "scripts" / "check_monitoring_register.py"), "--register", str(SK / "fixtures" / "register_good.csv")], capture_output=True, text=True)
t("cli exit 0 on good register", r.returncode == 0)
d = pathlib.Path(tempfile.mkdtemp()) / "x.csv"; d.write_text("test_id\nA\n")
r = subprocess.run([sys.executable, str(SK / "scripts" / "check_monitoring_register.py"), "--register", str(d)], capture_output=True, text=True)
t("cli exit 2 when columns missing", r.returncode == 2)
print(f"{sum(v for _, v in res)}/{len(res)} passed"); sys.exit(0 if all(v for _, v in res) else 1)
