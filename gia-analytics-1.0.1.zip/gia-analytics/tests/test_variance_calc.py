"""variance_calc.py: sign convention (favourable positive), worked example hand-computed, reconciliation, yield."""
import json, pathlib, sys
SK = pathlib.Path(__file__).resolve().parent.parent / "skills" / "gia-cost-accounting"
sys.path.insert(0, str(SK / "scripts"))
import variance_calc as vc
res = []
def t(n, c): res.append((n, bool(c))); print("PASS" if c else "FAIL", n)
case = json.load(open(SK / "fixtures" / "worked_example.json"))
r = vc.variances(case); c = r["components"]
exp = {"material_price": -1560, "material_usage": -1800, "labour_rate": 525, "labour_efficiency": -1000,
       "variable_oh_spending": -420, "variable_oh_efficiency": -400, "fixed_oh_spending": -500, "fixed_oh_volume": -2400}
for k, v in exp.items(): t(f"hand-computed {k} = {v}", abs(c[k] - v) < 0.005)
t("total = std cost allowed 85,000 - actual 92,555 = -7,555", r["total_variance"] == -7555 and r["standard_cost_allowed"] == 85000 and r["actual_cost"] == 92555)
t("components reconcile to total", r["reconciles"])
t("labour rate favourable (positive) labelled F, others U", r["label"]["labour_rate"] == "F" and r["label"]["material_price"] == "U")
# sign fix: under-absorbed fixed OH volume is NEGATIVE (unfavourable); old formula (Budget - Actual activity) x rate was positive
old = (case["standard"]["budgeted_activity"] - case["actual"]["activity"]) * case["standard"]["fixed_oh_rate"]
t("old formula would give +1,800 (wrong sign); fixed version is -2,400", old == 1800 and c["fixed_oh_volume"] == -2400)
# over-absorption: more output than budget -> favourable positive
c2 = json.loads(json.dumps(case)); c2["actual_output_units"] = 13000
c2["actual"].update(material_qty=19500, labour_hours=1300, activity=1300, variable_oh=10400, fixed_oh=14400)
r2 = vc.variances(c2)
t("over-absorbed (output above budget) -> fixed OH volume positive F", r2["components"]["fixed_oh_volume"] == (1300 - 1200) * 12 and r2["label"]["fixed_oh_volume"] == "F" and r2["reconciles"])
# yield
y = vc.metal_yield(1000, 870, 125, 2.40, 1.90)
t("yield 87.0%, scrap rate 12.5%, scrap cost 62.5, gap 5 kg", y["metal_yield_pct"] == 87.0 and y["effective_scrap_rate_pct"] == 12.5 and y["scrap_cost"] == 62.5 and y["mass_balance_gap_kg"] == 5.0)
try: vc.metal_yield(0, 0, 0, 1, 1); ok = False
except ValueError: ok = True
t("yield refuses zero input", ok)
print(f"{sum(v for _, v in res)}/{len(res)} passed"); sys.exit(0 if all(v for _, v in res) else 1)
