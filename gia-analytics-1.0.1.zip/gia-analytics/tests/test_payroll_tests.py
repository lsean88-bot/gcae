"""payroll_tests.py on seeded fixtures: exact exception sets, clean records not flagged, NOT RUN honesty, no statutory defaults."""
import json, pathlib, subprocess, sys, tempfile, shutil, csv
SK = pathlib.Path(__file__).resolve().parent.parent / "skills" / "gia-payroll-analytics"
sys.path.insert(0, str(SK / "scripts"))
import payroll_tests as pt
res = []
def t(n, c): res.append((n, bool(c))); print("PASS" if c else "FAIL", n)
cfg = json.load(open(SK / "fixtures" / "config.json"))
r = pt.run(cfg, str(SK / "fixtures"))
ex = r["exceptions"]
def recs(tid): return [e["record"] for e in ex if e["objective_id"] == tid]
t("P03 duplicate ID number: E1,E2 only", recs("P03") == [{"emp_ids": ["E1", "E2"]}])
t("P05 zero leave: E2 only (recent joiner E6 excluded)", [x["emp_id"] for x in recs("P05")] == ["E2"])
t("P06 OT on leave: E3 2026-03-10", recs("P06") == [{"emp_id": "E3", "date": "2026-03-10"}])
t("P07 OT rate variance: E4 only (expected 125.00 vs paid 100.00)", [x["emp_id"] for x in recs("P07")] == ["E4"] and "125.00" in [e for e in ex if e["objective_id"] == "P07"][0]["detail"])
t("P11 master change within 2 days of run: E3 only (E1 29 days earlier not flagged)", [x["emp_id"] for x in recs("P11")] == ["E3"])
t("P12 cost-centre variance: (CC-B, 2026-06) and (CC-A, 2026-07)", sorted((x["cost_centre"], x["period"]) for x in recs("P12")) == [("CC-A", "2026-07"), ("CC-B", "2026-06")])
t("P13 zero statutory deduction: E4 2026-06", recs("P13") == [{"period": "2026-06", "emp_id": "E4"}])
t("P14 basic above grade max: E4 only", [x["emp_id"] for x in recs("P14")] == ["E4"])
t("O01 OT/basic over 50%: E1 2026-07 only (E2 at 46.9% not flagged)", recs("O01") == [{"period": "2026-07", "emp_id": "E1"}])
t("O02 fixed OT pattern: E5 from 2026-04", recs("O02") == [{"emp_id": "E5", "from": "2026-04"}])
t("O03 OT above configured cap: E2 (65 > 60)", recs("O03") == [{"emp_id": "E2", "period": "2026-06"}])
t("C01 duplicate claim invoice: INV-1 (CL1, CL2); blank invoice ignored", recs("C01") == [{"invoice_no": "INV-1", "claim_ids": ["CL1", "CL2"]}])
t("C03 stale claim: CL3 only", recs("C03") == [{"claim_id": "CL3"}])
t("C04 self-approval CL4 and reverse approval CL5", sorted((e["reason_code"], e["record"]["claim_id"]) for e in ex if e["objective_id"] == "C04") == [("REVERSE-APPROVAL", "CL5"), ("SELF-APPROVED", "CL4")])
t("C05 NOT RUN with 6 claims (minimum 30), listed in not_run", any(x["objective_id"] == "C05" and "minimum 30" in x["reason"] for x in r["not_run"]))
t("every exception lists innocent explanations", all(e["innocent_explanations_to_rule_out"] for e in ex))
t("total exceptions = 16 (sum of the per-test counts)", len(ex) == 16)
# statutory parameters are never defaulted
c2 = json.loads(json.dumps(cfg)); [c2["params"].pop(k) for k in ("ot_divisor_days", "ot_hours_per_day", "ot_multipliers", "monthly_ot_cap_hours")]
r2 = pt.run(c2, str(SK / "fixtures"))
nr = {x["objective_id"]: x["reason"] for x in r2["not_run"]}
t("without statutory params P07 and O03 are NOT RUN, with reason", "P07" in nr and "O03" in nr and "param:monthly_ot_cap_hours" in nr["O03"])
t("without statutory params no P07/O03 exceptions are fabricated", not [e for e in r2["exceptions"] if e["objective_id"] in ("P07", "O03")])
t("missing leave file: P05 and P06 NOT RUN", {"P05", "P06"} <= {x["objective_id"] for x in pt.run({"files": {k: v for k, v in cfg["files"].items() if k != "leave"}, "params": cfg["params"]}, str(SK / "fixtures"))["not_run"]})
# unknown day type reported, not guessed
d = pathlib.Path(tempfile.mkdtemp()); shutil.copytree(SK / "fixtures", d / "f")
with open(d / "f" / "ot.csv", "a") as f: f.write("E1,2026-06-20,2,holiday\n")
r3 = pt.run(cfg, str(d / "f"))
t("unconfigured day_type flagged DAY-TYPE-NOT-CONFIGURED, not guessed", any(e["reason_code"] == "DAY-TYPE-NOT-CONFIGURED" for e in r3["exceptions"]))
# C05 with enough claims
def claims(n, round_n):
    p = d / "c.csv"
    with open(p, "w", newline="") as f:
        w = csv.writer(f); w.writerow(["claim_id", "emp_id", "invoice_no", "amount", "expense_date", "submit_date", "approver_id"])
        for i in range(n): w.writerow([f"K{i}", "E1", f"I{i}", 100 if i < round_n else 100.37, "2026-06-01", "2026-06-02", "M1"])
    return p
for n, rn, want in ((40, 20, 1), (40, 4, 0)):
    p = claims(n, rn)
    rr = pt.run({"files": {"claims": "c.csv", "employees": str(SK / "fixtures" / "employees.csv")}, "params": {}}, str(d))
    got = len([e for e in rr["exceptions"] if e["objective_id"] == "C05"])
    t(f"C05 with {n} claims, {rn} round -> {want} exception", got == want)
r = subprocess.run([sys.executable, str(SK / "scripts" / "payroll_tests.py"), "--config", str(SK / "fixtures" / "config.json")], capture_output=True, text=True)
t("cli runs and prints counts", r.returncode == 0 and '"P03": 1' in r.stdout)
print(f"{sum(v for _, v in res)}/{len(res)} passed"); sys.exit(0 if all(v for _, v in res) else 1)
