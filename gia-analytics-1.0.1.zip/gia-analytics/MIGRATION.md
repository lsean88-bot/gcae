# Migration map - gia-analytics

Status key: PORTED = unique strength carried into the destination; REDIRECT = duplicate replaced by a stub; MERGED; MOVED; DROPPED (reason).

## Skills
| Old skill | Destination | Status |
|---|---|---|
| mktron-gia-data-reconciliation | `gia-data-reconciliation` | PORTED (fixtures, tests, alias-aware codes, config externalised) |
| gia-business-performance-analytics | `gia-performance-analytics` | PORTED (3 sigma alarm, 2 sigma warning, script and tests) |
| mfg-cost-accounting-financial-analysis | `gia-cost-accounting` | PORTED (variance sign fixed, worked example) |
| two-way-trade-pricing-recovery-audit | `gia-recovery-analysis` | PORTED (model, workbook builder, worked example) |
| payroll-ot-claims-audit Parts C5, G, H | `gia-payroll-analytics` | PORTED as scripts (15 tests); DA-xx IDs retired |
| payroll-ot-claims-audit remainder (Parts A-F, I-N) | `gia-audit` HR and payroll pack | REDIRECT |
| payroll-ot-claims-audit Part O (document intake) | evidence-ingestion skill | REDIRECT |
| payroll-ot-claims-audit statutory tables | `statutory-register-<juris>.md` (gia-audit) | MOVED (verified-on dates required) |
| theta-simulator (agent) | `gia-scenario-modelling` and `scenario-simulator` agent | MERGED |
| beta-analyst (agent) | `recon-analyst` (reconciliation); fraud tests go to `gia-fraud:fraud-data-analyst` | MERGED |
| data-validator (agent) | `data-validator` | PORTED (no Write tool) |
| GCAE agents AG-005, AG-006, AG-007, AG-009, AG-019 | skill content in the matching skills | HARVESTED (agents dropped) |
| rbia financial-cost-accounting (agent) | `cost-accounting-analyst` | MOVED from gia-fraud |
| continuous monitoring schedule | `gia-continuous-assurance` | PORTED (from the fraud investigation skill 5.2) |

## Unique strengths
| Strength | Destination | Status |
|---|---|---|
| Planning tier, weight and capacity data | config/planning_config.json | PORTED (externalised) |
| Priority scoring | priority_score.py | PORTED |
| Eight standard-cost variances | variance_calc.py | PORTED (sign corrected) |
| OT rate recalculation, OT on leave, zero leave, duplicate ID | payroll_tests.py | PORTED (P03, P05, P06, P07) |

## Dropped
| Item | Reason |
|---|---|
| DA-01 to DA-25 IDs | Retired; mapped in `gia-payroll-analytics/references/test-registry.md` |
| Inline statutory rates, multipliers and caps | No primary source or verified-on date; belong in the statutory register |
| Case facts and personal names | Method content only |
| Old fixed-overhead volume formula | Gave the wrong sign (+1,800 for a case under-absorbed by 2,400); corrected to -2,400 |

## Inbound references to repoint
Persona, fleet roster, fraud coordinator, performance analytics, cost accounting, data reconciliation and payroll audit skills that name the old skills.
