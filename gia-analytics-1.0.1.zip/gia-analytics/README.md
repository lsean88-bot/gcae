# gia-analytics

Data reconciliation, performance analytics, manufacturing cost accounting, recovery analysis, scenario modelling, continuous assurance and payroll analytics for Group Internal Audit. Version 1.0.0. Standard library Python only.

## Skills (7)
| Skill | Use for |
|---|---|
| `gia-data-reconciliation` | Reconcile extracts to source, planning-data integrity, priority scoring, plan exports (alias-aware entity codes) |
| `gia-performance-analytics` | KPI trends, control limits (3 sigma alarm, 2 sigma warning, run of 8) |
| `gia-cost-accounting` | Standard-cost variances (favourable positive), yield, scrap, absorption, worked example |
| `gia-recovery-analysis` | Contribution, break-even and recovery workbook for two-way trade audits |
| `gia-scenario-modelling` | Sensitivity grid, status quo / partial control / structural fix ranges |
| `gia-continuous-assurance` | Monitoring schedule and register check (owners, thresholds, escalation) |
| `gia-payroll-analytics` | Payroll, overtime and claims tests (P, O, C IDs); statutory inputs never defaulted |

## Agents (4) and commands (4)
Agents: recon-analyst, scenario-simulator, data-validator, cost-accounting-analyst. Pinned to sonnet or haiku with effort noted.
Commands: /reconcile-data, /sensitivity-grid, /variance-calc, /payroll-tests.

## Boundaries
- Statutory figures and verified-on dates live in `statutory-register-<juris>.md` (owned by `gia-audit`); no skill here carries inline statutory values.
- Fraud-indicator tests (Benford, vendor, threshold, duplicate, journal) are in `gia-fraud:gia-fraud-analytics`. Analytics output is indicator-grade, not finding evidence.
- Fixtures hold illustrative values only. A fixture pass proves the script, not a clean population.

## Tests
`sh tests/run_all_tests.sh` runs seven script test files and structure validation, and writes `tests/RESULTS.md` from the real output.

## Standards applied
Iron rules by number via `gia-core:iron-rules`; evidence R1 to R5; standard concise internal audit report plus Excel workpaper.
