# Changelog

## 1.0.1 (30-Oct-2026), QA defect fixes (D5, D7, D9 to D15)

- Cross-references: every `gia-*:<name>` now resolves to a built skill, agent or command (short blueprint names replaced with built names).
- Descriptions of all skills and agents are 400 characters or fewer, trigger words first, with the Do NOT use clause kept (one redirect where space was short); all quoted so frontmatter parses as YAML.
- Script paths in skills, commands and agents use `${CLAUDE_PLUGIN_ROOT}/skills/<skill>/scripts/...`.
- Dangling in-skill links fixed or removed; empty directories and caches deleted.
- `data-validator` is now read-only (Read, Grep, Glob); recomputation is handed to `recon-analyst`.
- Always-loaded name plus description tokens (chars/4): skills 690, agents 262, commands 83, total 1035.

## 1.0.0 - 2026-10-30
Initial consolidated release.
- Built from: data reconciliation skill, business performance analytics skill, manufacturing cost accounting skill, two-way trade recovery skill, payroll, overtime and claims audit (Parts C5, G, H tests), theta-simulator, beta-analyst, data-validator, and the RBIA financial cost accounting agent.
- Added: reconcile.py fixtures and tests; sensitivity-grid script with fixtures; payroll_tests.py with 15 tests and fixtures; monitoring-register checker; control-limit, variance and recovery scripts with tests; planning configuration externalised to config/planning_config.json; payroll test registry (DA-xx mapped to P, O, C).
- Changed: control limits set to 3 sigma alarm and 2 sigma warning; variance sign convention fixed to favourable positive with a worked example (fixed-overhead under-absorption is adverse); entity code MKSDL with alias MKSLD; statutory parameters removed from scripts and skills.
- Removed: inline statutory tables, case facts and personal names, DA-xx test IDs (retired).
