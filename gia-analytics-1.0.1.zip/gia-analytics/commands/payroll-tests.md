---
description: Run payroll, overtime and claims tests on supplied extracts
argument-hint: <path to payroll config.json>
---
Run gia-payroll-analytics ${CLAUDE_PLUGIN_ROOT}/skills/gia-payroll-analytics/scripts/payroll_tests.py with the config in $ARGUMENTS after the data-validator agent clears the extracts. Present counts per test, exceptions with innocent explanations to rule out, tests not run (missing statutory inputs are NOT RUN), and the coverage statement. No conclusion on intent. Stop for human triage.
