---
description: Reconcile extracts to source totals and check planning-data integrity
argument-hint: <paths to extracts and source totals>
---
Use the recon-analyst agent with gia-data-reconciliation on $ARGUMENTS. Run reconcile.py with --json, present differences, unmatched items, checks not run, and whether the dataset is cleared for analysis. Do not explain differences away.
