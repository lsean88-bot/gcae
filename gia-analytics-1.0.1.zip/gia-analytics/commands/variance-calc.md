---
description: Recompute standard-cost variances with the favourable-positive sign convention
argument-hint: <path to cost card and actuals json>
---
Use the cost-accounting-analyst agent with gia-cost-accounting on $ARGUMENTS. Return each variance, the total, standard versus actual cost, and one worked line showing the sign.
