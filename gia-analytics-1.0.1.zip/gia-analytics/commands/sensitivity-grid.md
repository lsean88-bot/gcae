---
description: Run a sensitivity grid from a measured base with assumptions and ranges
argument-hint: <grid json path or description of base and drivers>
---
Use the scenario-simulator agent with gia-scenario-modelling on $ARGUMENTS. Return the full grid, the drivers that move the result most, assumptions with their sources, and exclusions. Present as ranges, not predictions.
