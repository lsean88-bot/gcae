# Install guide: MKTron GIA skill and plugin 2.0.1

**What you are installing:** `akos-graphify-bridge`, a skill that turns audit knowledge into a searchable, tamper-evident library with trust labels
and confidential shelves, plus 12 slash commands for it. It is lean (about 290 KB of scripts and references).

## Choose your route

| You use | Route | One line |
|---|---|---|
| **claude.ai** (web or desktop app) | **1** | Upload `claude-ai-upload/akos-graphify-bridge.zip` |
| **Claude Code** (terminal or IDE) | **2** | `python3 install.py --apply --with-commands` |
| A plugin loader | **3** | Use `plugin/akos-graph-plugin-2.0.1.zip` |

## Route 1: claude.ai (upload the skill)
These steps follow Anthropic's Help Center article *Using Skills in Claude*. Menu names can change, so if one differs, check that article.
1. **Settings → Capabilities**: make sure *Code execution and file creation* is on (skills need it).
2. **Settings → Capabilities → Skills → Upload skill**, and choose `claude-ai-upload/akos-graphify-bridge.zip` (it contains the folder `akos-graphify-bridge/`).
3. Switch the skill on. On Team or Enterprise plans an owner may need to enable skills first. An uploaded skill is private to your account.
4. Try it: *"Use the akos-graphify-bridge skill to validate this Knowledge Graph at the final gate"*, attaching a `KNOWLEDGE_GRAPH.json`.

claude.ai uses the skill through conversation; the slash commands in Route 2 and 3 are for Claude Code style tools.

**graphify may not exist inside claude.ai's sandbox.** This was tested with graphify absent. Without it, these work: `validate`, `stats`, `deliverable`, `merge`, `export-xlsx`,
`from-graphify`, and `brain` `init`, `shelf-add`, `recall`, `status`, `stale`, `guard`, `seal`, `changes`, `verify`, `dashboard`, `doctor`.
These need graphify and give a clear one-line message (exit 2) instead: `to-graphify`, `brain index`, `brain remember`, `brain reflect`.

## Route 2: Claude Code (installer, recommended)
```
python3 install.py                              # DRY RUN: shows what it would do, changes nothing
python3 install.py --apply --with-commands      # installs the skill and the 12 slash commands
python3 install.py --apply --project .          # or: only for the project in the current folder
python3 install.py --uninstall                  # removes it and restores anything it replaced
```
- The skill goes to `~/.claude/skills/akos-graphify-bridge`, the commands to `~/.claude/commands/` (these are Claude Code's usual locations;
  if your version uses another place, add `--dest <skills folder>`).
- Anything it replaces is copied to `~/.claude/gia-install-backup-<time>/` first. Installing twice changes nothing.
- After installing it runs its own self-checks (validate a sample graph, create a library, verify the audit trail, run the doctor) and tells you the result.
- Open a new session afterwards so the skill is picked up. Then try `/akos-brain-doctor`.

## Route 3: plugin
Unzip `plugin/akos-graph-plugin-2.0.1.zip`. It has `.claude-plugin/plugin.json`, `commands/` and `skills/`. How you load a plugin depends on your tool and version,
and I could not verify that step for yours. Route 2 with `--with-commands` gives you the same 12 commands and is the dependable equivalent.

## Requirements
Python 3.10 or newer, and `pip install openpyxl` (Excel outputs). graphify is optional, see the lists above (`pip install -e <graphify checkout>`).

## First ten minutes
```
S=~/.claude/skills/akos-graphify-bridge/scripts          # adjust if you used --project or --dest
python3 $S/brain.py doctor ./my-library                  # checks your environment (library optional)
python3 $S/brain.py init ./my-library
python3 $S/brain.py shelf-add ./my-library tn-statutory --kind statutory --entity Group --review-days 90
#   put your KNOWLEDGE_GRAPH.json in ./my-library/shelves/tn-statutory/ , then:
python3 $S/brain.py recall ./my-library "minimum wage" --max-rank R3
python3 $S/brain.py seal ./my-library --shelf tn-statutory --reason "Reviewed against the portal on <date>"
python3 $S/brain.py dashboard ./my-library --out ./report        # HTML + Excel
```
When `seal` prints an `audit_head`, **record it somewhere outside the library** (an email to the CAE, a ticket). It is what lets `verify --anchor` prove the log was not truncated or rewritten.

## Reading the results
| You see | Meaning |
|---|---|
| CONFIRMED / PROVISIONAL / INDICATOR | may be relied on / needs validation / tells you where to look, never evidence |
| STALE, UNDATED, BAD_DATE | a statutory item past its review date, never dated, or with an unreadable date: re-check the portal |
| exit 0 / 1 / 2 / 3 | ok / findings to act on / bad input or refused / a bug (run with `GIA_DEBUG=1` and report it) |

## If something goes wrong
| Message | Do this |
|---|---|
| `graphify is not installed` | `pip install -e <graphify checkout>`, or use a command that does not need it |
| `not a brain library` | run `brain.py init <folder>` first |
| `could not get the lock` | another run is in progress; wait, then retry |
| `entity 'X' is not in config/entities.json` | the entity code must come from your owner; the tool never invents one |
| `symbolic link` refused | links inside a library are refused on purpose; remove them |
| anything odd | `brain.py doctor <library>` then `brain.py guard <library>` |

## Verify this bundle
`python3 install.py --verify-bundle` checks every file against `MANIFEST.sha256`. Tests: `python3 -m pytest tests`.

## What was and was not verified
**Verified:** the installer (9 tests: dry run, apply, backup and restore, idempotency, uninstall, rendered commands executing, upload ZIP structure); the skill validates and its
scripts run from the lean copy; behaviour with graphify absent; the full package passes its release gate.
**Not verified, because only you can:** the upload in your own claude.ai account and its menus; where your Claude Code version loads commands from; your plugin loader's command;
Windows. If any of those differ, nothing is lost: the installer made backups, and `--uninstall` undoes it.

Open owner decisions and everything the tool does and does not guarantee: `docs/UAT-report-v4.md` and `docs/DECISIONS_PENDING.md`.
