# MKTron GIA Install Bundle 2.0.1
Start with **INSTALL.md**. Files: `install.py` (installer), `claude-ai-upload/` (ZIP for claude.ai and a `.skill` copy), `plugin/` (folder and ZIP),
`skill/` (the lean skill), `docs/` (UAT report, guide, changelog, open decisions), `tests/` (installer tests), `MANIFEST.sha256`.
