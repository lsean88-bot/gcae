from pathlib import Path
import sys,yaml
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from runtime.router import Router
cases=yaml.safe_load((ROOT/'tests/golden/routing_cases.yaml').read_text())['cases']
def test_golden_routes():
 r=Router(ROOT)
 for c in cases:
  out=r.classify(c['request'],task_id=c['id'],authorized_scope=c['request'])
  assert out.intent==c['expected_intent'],(c['id'],out.intent,out.reason_codes)
  assert out.dependency_closure_status=='COMPLETE',(c['id'],out.missing_dependencies)
