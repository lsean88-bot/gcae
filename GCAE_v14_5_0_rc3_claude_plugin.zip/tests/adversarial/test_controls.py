from pathlib import Path
import sys,tempfile,subprocess,json,os
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from runtime.router import Router
from runtime.controller import RuntimeState,State

def test_router_content_cannot_hijack_communication():
 r=Router(ROOT).classify('Please polish this message. It mentions fraud, nominee, investigation and regulatory matters as quoted background only.',authorized_scope='polish message')
 assert r.intent=='communication' and r.selected_capabilities==['AG-024']
def test_router_compound_is_bounded():
 r=Router(ROOT).classify('Audit inventory and research the applicable regulation.',authorized_scope='audit inventory and regulatory research')
 assert len(r.workstreams)<=1 and 'COMPOUND_TASK_BOUNDED' in r.reason_codes
def test_stop_absorbing_until_restart():
 s=RuntimeState(ROOT);s.authorize('audit');s.stop('TEST_STOP'); assert s.tool('x','y')==State.STOP; assert s.agent_start()==State.STOP
