#!/usr/bin/env python3
"""Authoritative builder QA for v14.5.0-rc3. Independent acceptance remains external."""
from pathlib import Path
import json, yaml, hashlib, subprocess, tempfile, os, sys, shutil
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from runtime.router import Router
from runtime.dependency_closure import DependencyClosure
from runtime.controller import RuntimeState,State
from runtime.claude_code_adapter import normalize

fail=[]
def ok(name,cond):
    if not cond: fail.append(name)

def test_registry():
    idx=json.loads((ROOT/'core/capability-index.json').read_text())
    ok('100-capability-index',len(idx)==100)
    ok('45-agents',sum(1 for x in idx.values() if x.get('type')=='agent')==45)
    ok('42-references',sum(1 for x in idx.values() if x.get('type')=='reference')==42)
    ok('8-industries',sum(1 for x in idx.values() if x.get('type')=='industry')==8)
    ok('3-jurisdictions',sum(1 for x in idx.values() if x.get('type')=='jurisdiction')==3)
    reg=yaml.safe_load((ROOT/'capability-registry.yaml').read_text())
    ok('registry-100',len(reg.get('capabilities',[]))==100)
    ok('registry-version',str(reg.get('version'))=='14.5.0-rc3')

def test_dependencies():
    c=DependencyClosure(ROOT)
    idx=json.loads((ROOT/'core/capability-index.json').read_text())
    for cid in idx:
        r=c.close([cid])
        ok(f'dep:{cid}',r['status']=='COMPLETE')

def test_routing():
    r=Router(ROOT)
    cases=[
      ('Rewrite this email: "We suspect fraud and nominee payments".','communication'),
      ('Audit the statutory compliance process and identify control gaps.','assurance'),
      ('Audit the VAT refund reconciliation and test supporting documents.','assurance'),
      ('Prepare an enterprise risk assessment for inventory risk.','risk'),
      ('Prepare a Board Assurance Paper on the NMSB audit findings.','advisory'),
      ('Review this supplier contract for legal and governance risks.','analysis'),
      ('Reconcile AP ledger to supplier SOA and quantify exposure.','assurance'),
      ('Review dialysis consumable usage vs treatments.','analysis'),
      ('Research Section 143(5) CGST treatment of scrap.','research'),
      ('Explain what GRNI means and why it matters.','analysis'),
      ('Find the previous audit report for KUL branch.','retrieval'),
      ('Check whether the plugin has duplicate routing and misfiring.','build_qa'),
      ('Rewrite this paragraph exactly; it contains the words audit, fraud, investigation, nominee account.','communication'),
      ('Polish this email and analyse whether the finding is valid.','analysis'),
    ]
    for i,(q,e) in enumerate(cases,1): ok(f'route-{i}',r.classify(q,authorized_scope=q).intent==e)
    c=r.classify('Please polish this message. It mentions fraud, nominee, investigation and regulatory matters as quoted background only.',authorized_scope='polish message')
    ok('communication-isolation',c.intent=='communication' and c.selected_capabilities==['AG-024'])
    c=r.classify('Audit inventory and research the applicable regulation.',authorized_scope='audit inventory and regulatory research')
    ok('compound-bounded',len(c.workstreams)<=1 and 'COMPOUND_TASK_BOUNDED' in c.reason_codes)

def test_runtime():
    s=RuntimeState(ROOT); ok('missing-scope-stop',s.authorize('')==State.STOP)
    s=RuntimeState(ROOT); s.authorize('audit inventory'); s.check_scope({'authorized_scope':s.authorized_scope,'operation':'unrelated legal advice'}); ok('scope-outside',s.state==State.STOP and s.stop_reason=='SCOPE_DRIFT')
    s=RuntimeState(ROOT); s.authorize('audit')
    for i in range(2): s.tool('read','file-a',result={'value':i})
    s.tool('read','file-b',result={'value':'new'})
    ok('repeat-episode-reset',s.state!=State.STOP)
    s=RuntimeState(ROOT); s.authorize('audit')
    for x in ['a','b','a','b']:
        s.tool('read',x,result={'v':x})
    ok('cycle-control',s.state==State.STOP)

def test_provider():
    for e,expected in [('rate_limit','RATE_LIMIT'),('authentication_failed','AUTH_FAILURE'),('billing_error','BILLING_FAILURE'),('server_error','TRANSIENT_SERVER_ERROR'),('overloaded','TRANSIENT_SERVER_ERROR'),({'code':429},'RATE_LIMIT'),({'status':503},'TRANSIENT_SERVER_ERROR'),({'name':'timeout'},'TIMEOUT')]:
        d={'hook_event_name':'StopFailure','error':e}; ok('provider-'+str(e),normalize(d).failure_code==expected)
    ok('provider-business-content',normalize({'error':{'message':'invoice RM4290.50'}}).failure_code is None)
    u=normalize({'usage':{'input_tokens':10,'output_tokens':20},'model':'claude-test','effort':'high'})
    ok('nested-usage',u.input_tokens==10 and u.output_tokens==20)

def test_hook():
    hook=ROOT/'hooks/gcae_guard.py'
    with tempfile.TemporaryDirectory() as td:
      env=os.environ.copy();env['GCAE_RUNTIME_DIR']=td;env['CLAUDE_PLUGIN_ROOT']=str(ROOT)
      def run(p): return subprocess.run([sys.executable,str(hook)],input=json.dumps(p)+'\n',text=True,capture_output=True,env=env)
      run({'session_id':'qa','hook_event_name':'UserPromptSubmit','prompt':'Audit inventory reconciliation and prepare findings'})
      st=json.loads((Path(td)/'sessions/qa/state.json').read_text())
      ok('hook-task-envelope',bool(st.get('task_envelope')))
      run({'session_id':'qa','hook_event_name':'PreToolUse','tool_name':'Read','tool_input':{'file':'inventory.xlsx'}})
      st=json.loads((Path(td)/'sessions/qa/state.json').read_text()); ok('hook-read-within',st['status']=='RUNNING')
      run({'session_id':'qa','hook_event_name':'StopFailure','error':'rate_limit'})
      st=json.loads((Path(td)/'sessions/qa/state.json').read_text()); ok('hook-native-stop',st['status']=='STOP')
      run({'session_id':'qa','hook_event_name':'UserPromptSubmit','prompt':'continue'})
      st=json.loads((Path(td)/'sessions/qa/state.json').read_text()); ok('natural-restart-denied',st['status']=='STOP')
      run({'session_id':'qa','hook_event_name':'UserPromptSubmit','prompt':'/gcae-enterprise-assurance-risk:restart'})
      st=json.loads((Path(td)/'sessions/qa/state.json').read_text()); ok('human-restart',st['status']=='RUNNING' and st['epoch']==2)
      # Agent creation must be blocked before spawn because SubagentStart is observational/non-blocking.
      run({'session_id':'qa','hook_event_name':'UserPromptSubmit','prompt':'Audit inventory'})
      for i in range(5):
        run({'session_id':'qa','hook_event_name':'SubagentStart','agent_id':f'a{i}','agent_type':'general-purpose'})
      run({'session_id':'qa','hook_event_name':'PreToolUse','tool_name':'Task','tool_input':{'subagent_type':'general-purpose','description':'sixth'}})
      st=json.loads((Path(td)/'sessions/qa/state.json').read_text()); ok('hook-agent-cap',st['status']=='STOP' and st['reason']=='AGENT_LIMIT')
      # Depth: a child at depth 2 may start; a grandchild request must be denied before spawn.
      run({'session_id':'qa2','hook_event_name':'UserPromptSubmit','prompt':'Audit inventory'})
      run({'session_id':'qa2','hook_event_name':'SubagentStart','agent_id':'root-agent','agent_type':'general-purpose'})
      run({'session_id':'qa2','hook_event_name':'PreToolUse','tool_name':'Task','agent_id':'root-agent','tool_input':{'subagent_type':'general-purpose','description':'child'}})
      run({'session_id':'qa2','hook_event_name':'SubagentStart','agent_id':'child-agent','parent_agent_id':'root-agent','agent_type':'general-purpose'})
      run({'session_id':'qa2','hook_event_name':'PreToolUse','tool_name':'Task','agent_id':'child-agent','tool_input':{'subagent_type':'general-purpose','description':'grandchild'}})
      st2=json.loads((Path(td)/'sessions/qa2/state.json').read_text()); ok('hook-depth-cap',st2['status']=='STOP' and st2['reason']=='DEPENDENCY_DEPTH_LIMIT')



def test_versions_and_tree():
    plugin=json.loads((ROOT/'.claude-plugin/plugin.json').read_text()); ok('plugin-version',plugin['version']=='14.5.0-rc3')
    ident=yaml.safe_load((ROOT/'core/authority/release-identity.yaml').read_text()); ok('identity-version',ident['version']=='14.5.0-rc3')
    rel=yaml.safe_load((ROOT/'release-control/production-acceptance-policy.yaml').read_text()); ok('release-policy-version',str(rel['version'])=='14.5.0-rc3')
    ok('legacy-schema-removed',not (ROOT/'core/schema').exists())
    ok('canonical-schemas',all((ROOT/'core/schemas'/n).exists() for n in ['dependency-closure.json','execution-state.json','route-decision.json','runtime-event.json','task-envelope.json']))
    bad=[p for p in ROOT.rglob('*') if '__pycache__' in p.parts or p.suffix=='.pyc' or p.name=='.pytest_cache']
    ok('clean-tree',not bad)

def main():
    test_registry();test_dependencies();test_routing();test_runtime();test_provider();test_hook();test_versions_and_tree()
    print(json.dumps({'status':'PASS' if not fail else 'FAIL','failures':fail,'failure_count':len(fail)},indent=2))
    return 0 if not fail else 1
if __name__=='__main__': raise SystemExit(main())
