from __future__ import annotations
from dataclasses import dataclass

@dataclass
class Result:
    passed: bool
    reason: str


def oracle(metrics: dict) -> Result:
    hard = [
        (metrics.get("critical_safeguard_failure") is True, "critical safeguard failure"),
        (metrics.get("unbounded_retry") is True, "unbounded retry"),
        (metrics.get("uncontrolled_fanout") is True, "uncontrolled fanout"),
        (metrics.get("scope_drift_unstopped") is True, "scope drift not stopped"),
        (metrics.get("evidence_breach_unstopped") is True, "evidence breach not stopped"),
        (metrics.get("material_assurance_regression") is True, "material assurance regression"),
    ]
    for bad, reason in hard:
        if bad:
            return Result(False, reason)
    return Result(True, "no hard acceptance failure recorded")
