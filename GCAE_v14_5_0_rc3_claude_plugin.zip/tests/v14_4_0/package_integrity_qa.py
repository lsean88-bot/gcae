import sys
sys.dont_write_bytecode=True
#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,subprocess,sys,yaml,glob
ROOT=Path(__file__).resolve().parents[2]; V='14.5.0-rc3'; issues=[]
# identity
for rel in ['.claude-plugin/plugin.json','RELEASE_MANIFEST.json']:
 d=json.loads((ROOT/rel).read_text());
 if d.get('version')!=V:issues.append('identity:'+rel)
if json.loads((ROOT/'core/policy/execution-thresholds.json').read_text()).get('version')!=V:issues.append('identity:thresholds')
# counts
idx=json.loads((ROOT/'core/capability-index.json').read_text()); agents=list((ROOT/'agents').glob('*.md'))
if len(idx)!=100:issues.append('capabilities:'+str(len(idx)))
if len(agents)!=45:issues.append('agents:'+str(len(agents)))
# no generated artifacts
if any('__pycache__' in p.parts or p.suffix in {'.pyc','.pyo'} for p in ROOT.rglob('*')):issues.append('generated-artifacts')
# no active stale version authority in control plane
for p in list((ROOT/'runtime').rglob('*.py'))+list((ROOT/'hooks').rglob('*.py'))+list((ROOT/'core').rglob('*.yaml'))+list((ROOT/'core').rglob('*.json')):
 s=p.read_text(errors='ignore')
 if 'v13.1.1' in s or 'v14.3.0' in s or 'v14.3.2' in s and p.name not in {'capability-preservation-matrix.yaml'}:
  issues.append('stale:'+str(p.relative_to(ROOT)))
# import router
try:
 sys.path.insert(0,str(ROOT));from runtime.router import Router
 r=Router(ROOT).classify('Rewrite this email professionally; the attached fraud finding is background only.','T1','rewrite email only')
 if r.intent!='communication':issues.append('router:communication')
 r=Router(ROOT).classify('Research India GST statutory requirements for the audit conclusion.','T2','research regulatory requirements')
 if r.intent!='research':issues.append('router:research')
except Exception as e:issues.append('router-import:'+repr(e))
# hashes exact coverage: manifest must match every package file except itself
manifest=ROOT/'BUILD_HASHES_V14.5.0.sha256'; lines=[x for x in manifest.read_text().splitlines() if x.strip()]
if len(lines)!=sum(1 for p in ROOT.rglob('*') if p.is_file() and p.name!=manifest.name and '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo'}):issues.append('hash-count')
for line in lines:
 h,rel=line.split('  ',1);p=ROOT/rel
 if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=h:issues.append('hash:'+rel)
print(json.dumps({'status':'PASS' if not issues else 'FAIL','issues':issues,'capabilities':len(idx),'agents':len(agents),'hash_entries':len(lines)},indent=2));sys.exit(1 if issues else 0)
