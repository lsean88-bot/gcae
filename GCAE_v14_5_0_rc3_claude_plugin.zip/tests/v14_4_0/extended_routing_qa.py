import sys
sys.dont_write_bytecode=True
#!/usr/bin/env python3
from pathlib import Path
import yaml,json,sys
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT));from runtime.router import Router
cases=yaml.safe_load((ROOT/'tests/golden/routing_cases.yaml').read_text())['cases'];r=Router(ROOT);fail=[]
for c in cases:
 x=r.classify(c['request'],c['id'],c['request'])
 if x.intent!=c['expected_intent']:fail.append({'id':c['id'],'got':x.intent,'expected':c['expected_intent']})
 if x.dependency_closure_status!='COMPLETE':fail.append({'id':c['id'],'closure':x.dependency_closure_status,'missing':x.missing_dependencies})
print(json.dumps({'status':'PASS' if not fail else 'FAIL','cases':len(cases),'failures':fail},indent=2));sys.exit(1 if fail else 0)
