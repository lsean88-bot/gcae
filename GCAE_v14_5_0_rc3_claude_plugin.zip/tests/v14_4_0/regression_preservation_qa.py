import sys
sys.dont_write_bytecode=True
#!/usr/bin/env python3
from pathlib import Path
import json,hashlib,sys,yaml
BASE=Path('/mnt/data/gcae_rebuild/v1432');ROOT=Path(__file__).resolve().parents[2];issues=[];changed=[]
bidx=json.loads((BASE/'core/capability-index.json').read_text());idx=json.loads((ROOT/'core/capability-index.json').read_text())
if set(bidx)!=set(idx):issues.append('capability-id-set-changed')
for cid in bidx:
 if bidx[cid].get('file')!=idx[cid].get('file'):issues.append('capability-file:'+cid)
 if bidx[cid].get('type')!=idx[cid].get('type'):issues.append('capability-type:'+cid)
bagents={p.name for p in (BASE/'agents').glob('*.md')};agents={p.name for p in (ROOT/'agents').glob('*.md')}
if bagents!=agents:issues.append('agent-file-set-changed')
# protected payload file set comparison outside known added control files
for d in ['agents','references','jurisdictions','industries','evidence']:
 a={str(p.relative_to(BASE)) for p in (BASE/d).rglob('*') if p.is_file()}; b={str(p.relative_to(ROOT)) for p in (ROOT/d).rglob('*') if p.is_file()}
 if a!=b:issues.append(f'payload-set:{d}')
# baseline accepted runtime controls must remain represented
required=['core/policy/execution-thresholds.json','runtime/dependency_closure.py','runtime/claude_code_adapter.py','runtime/router.py','runtime/controller.py','hooks/gcae_guard.py','hooks/hooks.json','hooks/run_guard.sh','tools/grade_uat.py','core/output-templates.md','tests/guard/suite.py','tests/authoritative/TEST_AUTHORITY.yaml','independent_counsel/COUNSEL_CONSTITUTION.md']
for rel in required:
 if not (ROOT/rel).exists():issues.append('missing-required:'+rel)
print(json.dumps({'status':'PASS' if not issues else 'FAIL','issues':issues,'capabilities':len(idx),'agents':len(agents)},indent=2));sys.exit(1 if issues else 0)
