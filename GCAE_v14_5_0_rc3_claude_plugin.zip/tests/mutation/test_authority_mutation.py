from pathlib import Path
import tempfile,shutil,json,yaml,sys
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from runtime.dependency_closure import DependencyClosure

def test_missing_dependency_is_fail_closed(tmp_path):
 shutil.copytree(ROOT,tmp_path/'pkg',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 p=tmp_path/'pkg/capability-index.json' if False else tmp_path/'pkg/core/capability-index.json'
 d=json.loads(p.read_text());d['AG-002']['dependencies']=d['AG-002']['dependencies']+['REF-THIS-DOES-NOT-EXIST'];p.write_text(json.dumps(d))
 c=DependencyClosure(tmp_path/'pkg').close(['AG-002']);assert c['status']=='INVALID' and any(m.endswith('REF-THIS-DOES-NOT-EXIST') for m in c['missing'])
