#!/usr/bin/env python3
"""Authoritative runner. Executes every test in tests/authoritative/TEST_AUTHORITY.yaml with no external dependency (pytest optional).
Fails on: non-zero exit, a failing test function, or ZERO tests collected (v14.4.0 reported PASS for pytest-style files that ran nothing)."""
import sys, os, io, json, time, subprocess, importlib.util, inspect, tempfile, pathlib, traceback, contextlib, yaml
ROOT = pathlib.Path(__file__).resolve().parents[1]; sys.dont_write_bytecode = True; sys.path.insert(0, str(ROOT))

def load(path):
    spec = importlib.util.spec_from_file_location("t_" + path.stem + str(abs(hash(str(path)))), path); m = importlib.util.module_from_spec(spec)
    sys.path.insert(0, str(path.parent)); spec.loader.exec_module(m); return m

def run_file(entry):
    rel, style = (entry["file"], entry["style"]) if isinstance(entry, dict) else (entry, "pytest")
    path = ROOT / "tests" / rel; t0 = time.time()
    if not path.exists(): return {"file": rel, "status": "FAIL", "detail": "missing"}
    if style == "pytest":
        m = load(path); fns = [(n, f) for n, f in vars(m).items() if n.startswith("test_") and callable(f)]
        if not fns: return {"file": rel, "status": "FAIL", "detail": "ZERO_TESTS_COLLECTED"}
        bad = []
        for n, f in fns:
            try:
                kw = {"tmp_path": pathlib.Path(tempfile.mkdtemp())} if "tmp_path" in inspect.signature(f).parameters else {}
                with contextlib.redirect_stdout(io.StringIO()): f(**kw)
            except Exception as e: bad.append("%s: %s" % (n, str(e)[:160] or type(e).__name__))
        return {"file": rel, "status": "FAIL" if bad else "PASS", "tests": len(fns), "failed": bad, "seconds": round(time.time() - t0, 1)}
    r = subprocess.run([sys.executable, str(path)], capture_output=True, text=True, cwd=str(ROOT), env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1"), timeout=900)
    if r.returncode == 0 and not r.stdout.strip(): return {"file": rel, "status": "FAIL", "detail": "SCRIPT_PRODUCED_NO_OUTPUT (vacuous)"}
    ok = r.returncode == 0 and '"status": "FAIL"' not in r.stdout
    return {"file": rel, "status": "PASS" if ok else "FAIL", "tests": "script", "detail": (r.stdout + r.stderr)[-300:] if not ok else "", "seconds": round(time.time() - t0, 1)}

if __name__ == "__main__":
    auth = yaml.safe_load((ROOT / "tests/authoritative/TEST_AUTHORITY.yaml").read_text())
    tier = sys.argv[1] if len(sys.argv) > 1 else "all"
    files = list(auth["mandatory"]) + (list(auth.get("reference_model", [])) if tier in ("all", "reference") else [])
    res = [run_file(f) for f in files]
    for r in res: print("%-4s %-52s %s" % (r["status"], r["file"], ("tests=%s" % r.get("tests", "")) + (" " + "; ".join(r.get("failed", []))[:200] if r.get("failed") else "") + (" " + r.get("detail", "") if r["status"] == "FAIL" else "")))
    bad = [r for r in res if r["status"] != "PASS"]
    print("\n%d/%d test files passed" % (len(res) - len(bad), len(res))); json.dump(res, open(os.environ.get("RUN_ALL_JSON", "/tmp/run_all.json"), "w"), indent=1)
    sys.exit(1 if bad else 0)
