import subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
print(subprocess.run([sys.executable,str(ROOT/"tests/v14_3_2_current_qa.py")],check=False).returncode)
