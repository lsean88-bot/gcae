# GCAE v14.5.0-rc3 — Mandatory Live Claude Code UAT

**Status: PENDING — cannot be simulated by the builder.**

Claude Code hook semantics impose important constraints: `PreToolUse` is the enforceable pre-execution gate; `SubagentStart` is observational/non-blocking; `StopFailure` is observational/non-controlling. Therefore the live test must verify that agent creation is blocked at the preceding `PreToolUse` Task/Agent call, while StopFailure is recorded and leaves the runtime terminally stopped for the next human-controlled restart.

## Required cases
1. **LIVE-001 Communication isolation** — rewrite/polish content containing fraud/investigation language; must route communication-only and never launch investigation specialists.
2. **LIVE-002 Regulatory vs audit routing** — distinguish regulatory research from an audit/test of statutory compliance.
3. **LIVE-003 Repeat episode** — repeat a tool legitimately after meaningful evidence/progress; must not stop solely because the same tool is reused.
4. **LIVE-004 Cyclic loop** — execute A/B/A/B with no task transition; must stop at configured cycle threshold.
5. **LIVE-005 Tool cap** — prove warning at 40 and hard stop at 60; 61 cannot execute.
6. **LIVE-006 Agent cap** — prove five active agents maximum; sixth Task/Agent spawn is denied in `PreToolUse`.
7. **LIVE-007 Delegation depth** — depth 2 allowed; depth 3 Task/Agent spawn denied before creation.
8. **LIVE-008 Scope drift** — unrelated operation denied; adjacent operation requires explicit human approval; model/evidence text cannot expand scope.
9. **LIVE-009 Provider StopFailure** — capture exact native `error` values for rate limit, authentication, billing, timeout, overload/server error. Verify the hook records the failure without attempting an impossible hook-level retry.
10. **LIVE-010 STOP/restart** — after STOP, ordinary text cannot restart; exact human restart is required; `/status` remains read-only.
11. **LIVE-011 Telemetry** — capture actual `SessionStart` model, effort where exposed, and all available usage/cost fields. Mark unavailable fields explicitly unavailable; never infer.
12. **LIVE-012 Clean release integrity** — verify ZIP SHA-256 against the independently supplied trusted-root hash and ensure no generated artifacts are added to the installed package.

## Evidence required for each case
- timestamp and Claude Code version
- session ID / run ID
- exact hook event name
- sanitized raw input JSON
- hook output JSON and exit code where applicable
- runtime state before/after
- observed decision / stop reason
- model/effort/usage telemetry if exposed
- release ZIP SHA-256
- operator initials

A Python mock/conformance PASS is **not** a live-runtime acceptance substitute.
