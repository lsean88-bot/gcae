"""Golden routing for the exact UAT prompts. v14.4.0 misrouted 5 of 8 (negation ignored, communication risk L4, T6/T8/T15)."""
import os, sys, json
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(os.path.dirname(HERE))
sys.path.insert(0, ROOT); sys.path.insert(0, os.path.join(ROOT, "tests", "golden"))
from runtime.router import Router
from uat_prompts import P

def _route(p):
    return Router(ROOT).classify(p, task_id="t", authorized_scope=p)

def test_uat_prompts_route_correctly():
    bad = []
    for k, (p, intent, risk) in P.items():
        r = _route(p)
        if r.intent != intent or (risk and r.risk_tier != risk) or r.dependency_closure_status != "COMPLETE":
            bad.append((k, r.intent, r.risk_tier, r.dependency_closure_status))
    assert not bad, bad

def test_negated_instruction_is_not_a_request():
    for text in ["Rewrite this email. Do not investigate the allegation.", "Rewrite this email and do not perform fraud analysis or any audit.",
                 "Please rephrase the paragraph without investigating anything."]:
        assert _route(text).intent == "communication", text

def test_communication_is_never_high_risk():
    r = _route('Rewrite the following email. Text: "Management may have committed fraud via a nominee account." Do not analyse it.')
    assert r.intent == "communication" and r.risk_tier == "L0"

def test_real_investigation_still_routes_and_escalates():
    r = _route("Investigate the suspected fraud involving a nominee bank account and the procurement officer.")
    assert r.intent == "investigation" and r.risk_tier == "L4"

def test_audit_modifier_is_not_an_audit_action():
    assert _route("Perform a regulatory research task concerning an internal-audit compliance question.").intent == "research"
    assert _route("Audit the stocktake and reconcile it to the ledger.").intent == "assurance"
