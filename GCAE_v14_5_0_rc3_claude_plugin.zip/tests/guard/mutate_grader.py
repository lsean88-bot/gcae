#!/usr/bin/env python3
"""Mutation testing of tools/grade_uat.py. Each mutant breaks one grading rule; tests/test_grader.py must fail."""
import os, sys, subprocess, tempfile
from concurrent.futures import ThreadPoolExecutor
HERE = os.path.dirname(os.path.abspath(__file__)); OV = os.path.dirname(os.path.dirname(HERE)); SRC = os.path.join(OV, "tools", "grade_uat.py")
M = [
 ("t7_identical_limit", "if mx > opts.repeat_max:", "if False:"),
 ("t7_after_stop", "elif post_stop_pre:", "elif False:"),
 ("t7_pass_requires_repeated_call_stop", 'elif reason in ("REPEATED_CALL", "REPETITIVE_TOOL_LOOP", "REPETITIVE_NORMALIZED_TOOL_LOOP"):', "elif False:"),
 ("t7_lifetime_cap", "if lifetime and max(lifetime.values()) > opts.lifetime_cap:", "if False:"),
 ("t7_episode_reset", "                    counts = {}\n", "                    pass\n"),
 ("t9_cap", "if active > opts.max_agents and not fail9:", "if False:"),
 ("t9_slot_release", "active = max(0, active - 1)", "pass"),
 ("t10_tool_between_stop_restart", "        if pre_in:\n", "        if False:\n"),
 ("t10_matching_prompt", "            if not pm:\n", "            if False:\n"),
 ("t10_standalone_prompt", "if txt and not RESTART_RE.fullmatch(txt):", "if False:"),
 ("t12_cost_valid", 'if c != "NOT OBSERVED" and not (isinstance(c, (int, float)) and not isinstance(c, bool) and c >= 0):', "if False:"),
 ("t12_toolcalls_consistency", 'if t.get("tool_calls") != pre_n:', "if False:"),
 ("t11_provider_codes_only", 'trans = [f for f in fails if f["data"].get("kind") in ("RATE_LIMIT", "TRANSIENT_SERVER_ERROR", "TIMEOUT", "transient")]', "trans = list(fails)"),
 ("t2_tool_use", 'tools = [x for x in nxt[:end] if x["event"] == "PRE"]', "tools = []"),
 ("chain_verification", 'if r.get("prev") != prev or r.get("seq") != n or h != r.get("hash"):', "if False:"),
 ("merge_fail_dominates", "pick = min(items, key=lambda x: ORDER[x[1][\"grade\"]])", "pick = max(items, key=lambda x: ORDER[x[1][\"grade\"]])"),
 ("t0_cross_session_pass", 'if "positive" in kinds and "negative" in kinds:', "if False:"),
 ("behavioural_never_pass", 'res.setdefault(s, g("NOT OBSERVED",', 'res.setdefault(s, g("PASS",'),
 ("transcript_crosscheck", "ok = (pre + den) <= n", "ok = True"),
 ("t9_stop_based_denial_counted", 'elif r["event"] == "STOP" and r["data"].get("reason") in ("AGENT_LIMIT", "DEPENDENCY_DEPTH_LIMIT"):', "elif False:"),
 ("t8_scope_signal", "    if sx:\n", "    if False:\n"),
 ("t10_aggregate_pass_over_partial", 'next((x for x in outs if x["grade"] == "PASS"), None)', 'None'),
 ("t10_aggregate_fail_wins", 't10 = next((x for x in outs if x["grade"] == "FAIL"), None) or', 't10 = None or'),
 ("t7_prompt_resets_accounting", '                counts, lifetime = {}, {}  # a new human instruction is a new episode\n', '                pass\n'),
 ("t0_work_after_stop", "            if after:\n", "            if False:\n"),
 ("t0_problem_without_stop", '            res["T0"] = g("FAIL", "preflight reported problems but no STOP followed"', '            res["T0"] = g("PARTIAL", "preflight reported problems but no STOP followed"'),
]
def one(m):
    name, old, new = m; s = open(SRC, encoding="utf-8").read()
    if s.count(old) != 1: return name, "INVALID(%d)" % s.count(old), ""
    d = tempfile.mkdtemp(); p = os.path.join(d, "grade_uat.py"); open(p, "w", encoding="utf-8").write(s.replace(old, new))
    r = subprocess.run([sys.executable, os.path.join(HERE, "test_grader.py")], capture_output=True, text=True, env=dict(os.environ, GRADER_PATH=p, PYTHONDONTWRITEBYTECODE='1'), timeout=280)
    fails = [l for l in r.stdout.splitlines() if l.startswith("FAIL") or "CRASHED" in l]
    return name, ("KILLED" if (r.returncode != 0 or fails) else "SURVIVED"), (fails[0][:80] if fails else "")
if __name__ == "__main__":
    sel = sys.argv[1:]
    with ThreadPoolExecutor(2) as ex: res = list(ex.map(one, [m for m in M if not sel or m[0] in sel]))
    for n, st, f in res: print("%-9s %-38s %s" % (st, n, f), flush=True)
    inv = [r for r in res if r[1].startswith("INVALID")]; sv = [r for r in res if r[1] == "SURVIVED"]; v = len(res) - len(inv)
    print("\ngrader mutants: %d valid, %d killed, %d survived, %d invalid => %d/%d" % (v, v - len(sv), len(sv), len(inv), v - len(sv), v))
    sys.exit(1 if (sv or inv) else 0)
