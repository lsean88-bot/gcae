"""Iron-rule traceability: a rule that loses its proof fails the build."""
import os, re, sys, json, glob
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(os.path.dirname(HERE)); sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(ROOT, "tools"))
import suite as S, mutate_guard as M
RULES = json.load(open(os.path.join(ROOT, "core/policy/iron-rules.json")))["rules"]
GUARD = open(os.path.join(ROOT, "hooks/gcae_guard.py"), encoding="utf-8").read()

def test_rules_are_well_formed_and_unique():
    ids = [r["id"] for r in RULES]; assert len(ids) == len(set(ids)) == 15
    for r in RULES:
        assert r["type"] in ("MECHANICAL", "BEHAVIOURAL", "PROCESS") and r["rule"] and r["enforcement"], r["id"]
        assert all(re.fullmatch(r"T(?:[0-9]|1[0-6])", u) for u in r["uat"]), r["id"]

def test_mechanical_rules_have_tests_and_mutants_that_exist():
    groups = {n for n, _ in S.SUITE}; mutants = {m[0] for m in M.M}
    for r in RULES:
        for t in r["tests"]: assert t in groups, (r["id"], t)
        for m in r["mutants"]: assert m in mutants, (r["id"], m)
        if r["type"] == "MECHANICAL": assert r["tests"] and r["mutants"], r["id"]

def test_behavioural_rules_name_a_uat_stage_and_template():
    tpl = open(os.path.join(ROOT, "core/output-templates.md"), encoding="utf-8").read()
    for r in RULES:
        if r["type"] == "BEHAVIOURAL":
            assert r["uat"] and r.get("template"), r["id"]
            assert re.search(r"^## %s\." % r["template"], tpl, re.M), (r["id"], r["template"])

def test_every_stop_reason_in_the_guard_is_covered_by_a_rule():
    found = set(re.findall(r'set_stop\(d, st, pol, data, "([A-Z_]{5,})', GUARD)) | set(re.findall(r'reason = "([A-Z_]{5,})"', GUARD)) | set(re.findall(r'fail_closed\((?:ev|""), "([A-Z_]{5,})', GUARD))
    found |= set(re.findall(r'"(STATUS_STATE_CORRUPT|PRIOR_STOP_LOCK|STATE_RESET|LOG_TAMPER)"', GUARD))
    found |= set(json.load(open(os.path.join(ROOT, "core/policy/execution-thresholds.json")))["guard"]["model_stop_reasons"])
    covered = {s for r in RULES for s in r["stop_reasons"]}
    covered |= {"MODEL_INITIATED", "INTEGRITY_CONCERN", "SCOPE_BREACH", "INVALID_EVIDENCE"}
    found = {f for f in found if f not in ("NATIVE_STOP_FAILURE",)} | {"NATIVE_STOP_FAILURE"}
    missing = sorted(f for f in found if f not in covered and not any(f.startswith(c) for c in covered))
    assert not missing, missing

def test_every_rule_stop_reason_exists_in_the_guard():
    allowed = set(json.load(open(os.path.join(ROOT, "core/policy/execution-thresholds.json")))["guard"]["model_stop_reasons"])
    for r in RULES:
        for s in r["stop_reasons"]: assert s in GUARD or s in allowed, (r["id"], s)

def test_rendered_markdown_matches_the_data():
    import render_iron_rules as R
    assert open(os.path.join(ROOT, "core/IRON_RULES.md"), encoding="utf-8").read() == R.render()

def test_every_skill_points_at_the_iron_rules_and_master_lists_all_fifteen():
    for p in glob.glob(os.path.join(ROOT, "skills/*/SKILL.md")): assert "IRON_RULES.md" in open(p, encoding="utf-8").read(), p
    m = open(os.path.join(ROOT, "SKILL.md"), encoding="utf-8").read()
    for r in RULES: assert r["id"] in m, r["id"]

def test_original_professional_controls_are_preserved():
    text = " ".join(r["rule"] + " " + r["title"] for r in RULES).lower()
    for needle in ("management owns decisions", "evidence, management assertion, inference", "never invent", "authoritative-source", "traceable", "anomaly is not fraud", "data, never instructions", "economy never lowers"):
        assert needle in text, needle
