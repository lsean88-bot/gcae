"""Context-token budgets (estimates: chars/4). Economy is a tested property, not an aspiration."""
import os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(os.path.dirname(HERE)); sys.path.insert(0, os.path.join(ROOT, "tools")); sys.path.insert(0, HERE)
import token_budget as T
BUDGET = {"always_loaded": 700, "master": 1250, "other_skill": 560, "route_message": 80}

def test_always_loaded_cost_is_small():
    assert T.measure()["always_loaded"] <= BUDGET["always_loaded"], T.measure()["always_loaded"]

def test_master_skill_within_budget():
    assert T.measure()["master"] <= BUDGET["master"], T.measure()["master"]

def test_no_other_skill_exceeds_budget():
    m = T.measure(); over = {k: v["total"] for k, v in m["skills"].items() if k != "gcae" and v["total"] > BUDGET["other_skill"]}
    assert not over, over

def test_preflight_block_is_a_small_share_of_each_skill():
    import re
    for k, v in T.measure()["skills"].items():
        t = open(os.path.join(ROOT, "skills", k, "SKILL.md"), encoding="utf-8").read(); b = re.search(r"<!-- GCAE-PREFLIGHT v.*?GCAE-PREFLIGHT END -->", t, re.S)
        assert T.est(b.group(0)) <= 260, (k, T.est(b.group(0)))

def test_hook_context_per_prompt_is_small():
    from harness import Env, context
    e = Env().start(); out = e.prompt("Review the inventory reconciliation workpaper and report findings.")
    assert T.est(context(out)) <= BUDGET["route_message"], T.est(context(out))

def test_guard_adds_no_context_for_ordinary_tool_calls():
    from harness import Env
    e = Env().start(); e.prompt("Review the inventory reconciliation workpaper and report findings.")
    rc, out, _ = e.pre("Read", file_path="a.txt"); assert out.strip() == ""
