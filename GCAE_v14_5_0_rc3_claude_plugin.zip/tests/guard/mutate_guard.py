#!/usr/bin/env python3
"""Mutation testing of hooks/gcae_guard.py: break one control at a time; the suite must fail. Survivors = untested controls.
Each mutant first runs the suite groups most likely to detect it (fast); if it survives it is re-run against the FULL suite."""
import os, sys, tempfile
from concurrent.futures import ThreadPoolExecutor
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import suite as S
SRC = S.GUARD
EQUIVALENT = {"preflight_policy": "redundant: a missing/corrupt policy is also caught by required_paths and release identity"}
PRE, STOP, AG, REP, LIM, SC, INT, TEL, PRV, MAL, RT, ALL = "preflight", "stop_restart", "agents", "repeat_family", "noprogress_limits", "scope_destructive", "integrity", "telemetry", "provider", "malformed_corrupt", "routing_runtime", None
M = [  # (name, groups, exact old text (once), replacement)
 ("preflight_required_paths", [PRE], "    if missing:\n", "    if False:\n"),
 ("preflight_skills", [PRE], "    if nos:\n", "    if False:\n"),
 ("preflight_policy", [PRE], "    if not pol_ok:\n", "    if False:\n"),
 ("release_identity", [PRE], "        if len(set(ids)) != 1:", "        if False:"),
 ("preflight_logchain", [INT], "    if not chain_ok:\n        tamper.append", "    if False:\n        tamper.append"),
 ("hash_manifest", [PRE], '        if bad:\n            problems.append("hash manifest mismatch', '        if False:\n            problems.append("hash manifest mismatch'),
 ("corrupt_state_detection", [MAL], '    if kind == "corrupt":', "    if False:"),
 ("corrupt_state_exit2", [MAL, "baseline_18"], "return emit_stop(ev, st, rc=2)", "return emit_stop(ev, st, rc=0)"),
 ("state_reset_detection", [INT], "        elif reset_suspect:\n", "        elif False:\n"),
 ("lineage_restarts_rebuild", [INT], 'st["lineage"]["restarts"] = sum(1 for r in recs if r.get("event") == "RESTART")', "pass"),
 ("project_stop_lock", [STOP], 'elif pol["stop_lock_scope"] == "project" and os.path.exists(lock):', "elif False:"),
 ("stop_blocks_prompts", [STOP], "        return block_prompt(stop_msg(st))\n    if STATUS_RE", "        return 0\n    if STATUS_RE"),
 ("restart_phrase_standalone", [STOP], 'RESTART_PHRASE_RE.fullmatch(p))', "RESTART_PHRASE_RE.search(p))"),
 ("restart_cap", [STOP], 'if st["lineage"]["restarts"] >= pol["max_restarts"]:', "if False:"),
 ("tamper_restart_refused", [INT], 'if st["reason"] == "LOG_TAMPER":', "if False:"),
 ("tamper_detect_on_prompt", [INT], 'if not chain_ok and st["status"] != "STOP":', "if False:"),
 ("status_prompt_in_stop", [STOP], "        if STATUS_RE.fullmatch(prompt.strip()):\n", "        if False:\n"),
 ("scope_command_handling", [SC], "    if m:\n        decision = m.group(1).lower()", "    if False:\n        decision = m.group(1).lower()"),
 ("scope_expansion_detection", [SC], "    if env and is_scope_expansion(prompt):", "    if False:"),
 ("scope_hold_denies_tools", [SC], '    if st.get("scope_hold"):\n        log_event(d, "DENY", {"tool": tool, "why": "scope_hold"})', '    if False:\n        log_event(d, "DENY", {"tool": tool, "why": "scope_hold"})'),
 ("injection_prompt_flag", ["injection_misc"], '    if INJ_RE.search(prompt):\n        st["injection_flags"] += 1\n        log_event(d, "INJECTION_SUSPECTED", {"where": "user_prompt_evidence"', '    if False:\n        st["injection_flags"] += 1\n        log_event(d, "INJECTION_SUSPECTED", {"where": "user_prompt_evidence"'),
 ("route_closure_stop", [RT], '        elif rd["closure"] != "COMPLETE":', "        elif False:"),
 ("terminal_stop_gate", [STOP], '    if st["status"] == "STOP":\n        if tool == "Bash" and GUARD_CMD_RE.match(cmd):\n            return 0\n        fp', '    if False:\n        if tool == "Bash" and GUARD_CMD_RE.match(cmd):\n            return 0\n        fp'),
 ("protect_state_dir_tools", [INT], "    if protected_write(tool, tin, cmd, data):\n", "    if False:\n"),
 ("protect_state_dir_bash", [INT], '    if tool == "Bash" and (".gcae" in cmd or gd in cmd):', "    if False:"),
 ("delegation_depth", [AG], '        if depth > pol["max_depth"]:', "        if False:"),
 ("agent_cap", [AG], '        if st["agents_active"] >= pol["max_agents"]:', "        if False:"),
 ("agent_duplicate", [AG], "        if akey in st[\"agent_keys\"]:", "        if False:"),
 ("subagent_slot_release", [AG], 'st["agents_active"] = max(0, st["agents_active"] - 1)', "pass"),
 ("destructive_tool_stop", [SC], "    if set(tool_tokens(tool)) & DESTRUCTIVE_TOKENS:", "    if False:"),
 ("tool_hard_limit", [LIM], '    if cnt >= hard or sum(st["ctx_tools"].values()) >= pol["global_tool_hard"] or st["tool_count"] >= pol["lifetime_tool_hard"]:', "    if False:"),
 ("per_agent_budget", [LIM], 'hard = pol["tool_hard"] if ctx == "main" else pol["per_agent_tool_hard"]', 'hard = pol["tool_hard"]'),
 ("exact_repeat", [REP], '    if st["exact"][ex] >= pol["repeat_exact"]:', "    if False:"),
 ("normalized_repeat", [REP], '    elif st["normalized"][nm] >= pol["repeat_norm"]:', "    elif False:"),
 ("lifetime_cap", [REP], '    elif st["lifetime"][nm] >= pol["lifetime_identical_cap"]:', "    elif False:"),
 ("cycle_detection", [REP], "            if seq[-k:] == seq[-2 * k:-k]:", "            if False:"),
 ("bash_description_volatile", [REP], 'skip = VOLATILE_FIELDS | (BASH_VOLATILE if tool == "Bash" else set())', "skip = set()"),
 ("task_description_substantive", [AG], 'skip = VOLATILE_FIELDS | (BASH_VOLATILE if tool == "Bash" else set())', "skip = VOLATILE_FIELDS | BASH_VOLATILE"),
 ("normalise_case", [REP], "        s = v.lower()\n", "        s = v\n"),
 ("normalise_whitespace", [REP], '        s = re.sub(r"\\s+", " ", s)\n', ""),
 ("normalise_url_fragment", [REP], '            s = re.sub(r"#\\S*", "", s)\n', ""),
 ("reference_budget", ["references"], '            if len(st["ref_files"]) >= budget:', "            if False:"),
 ("episode_reset_on_progress", [REP], '        st["no_progress_events"], st["last_progress"] = 0, q\n        episode_reset(st)', '        st["no_progress_events"], st["last_progress"] = 0, q'),
 ("no_progress_stop", [LIM], '    if st["no_progress_events"] >= pol["noprogress"]:', "    if False:"),
 ("task_completed_reset", [REP], 'force=(ev == "TaskCompleted")', "force=False"),
 ("recovery_bounded", [PRV], '    if st["status"] != "STOP" and st["fail_total"] >= pol["recovery_stop_after"]:', "    if False:"),
 ("provider_failure_stops", [PRV], '    if st["status"] != "STOP":\n        set_stop(d, st, pol, data, "NATIVE_STOP_FAILURE:%s" % code', '    if False:\n        set_stop(d, st, pol, data, "NATIVE_STOP_FAILURE:%s" % code'),
 ("cost_basis_required", [TEL], '    if "cost_usd" in t and data.get("cost_basis") not in ("provider_reported", "provider_rate_card"):', "    if False:"),
 ("invalid_telemetry_stop", [TEL], "        if not valid_number(v):\n", "        if False:\n"),
 ("transcript_dedupe", [TEL], 'usage[m.get("id") or "line%d" % i] = u', 'usage["line%d" % i] = u'),
 ("effort_object_parse", [TEL], '    if isinstance(e, dict) and e.get("level"):', "    if False:"),
 ("chain_hash_check", [INT], 'or _hash(prev, r) != r.get("hash")', "or False"),
 ("stale_lock_heal", [INT], "                    if time.time() - os.path.getmtime(self.p) > 10:", "                    if False:"),
 ("lock_failure_exit2", [INT], '            return fail_closed(ev, "STATE_LOCK_FAILURE")', "            return 0"),
 ("internal_error_fail_closed", [MAL], '            return fail_closed(ev, "GUARD_INTERNAL_ERROR:%s" % type(e).__name__)', "            return 0"),
 ("malformed_input_exit2", [MAL], '            return fail_closed("", "INVALID_HOOK_INPUT")', "            return 0"),
 ("fail_closed_log_write", [INT], 'if ev == "PreToolUse" and pol["fail_closed_on_log_error"]:', "if False:"),
 ("model_stop_reason_allowlist", [STOP], 'if reason not in pol["model_stop_reasons"]:', "if False:"),
 ("no_heartbeat_detection", [PRE], '    if d is None:\n        print(json.dumps({"runtime_available": False, "detail": "no guard heartbeat', '    if False:\n        print(json.dumps({"runtime_available": False, "detail": "no guard heartbeat'),
 ("guard_cmd_anchor", [STOP], ')\\s*$""")', ').*""")'),
 ("restart_counter_reset", [STOP], '"tool_count": 0})', '"tool_count": st["tool_count"]})'),
 ("restart_lineage_carry", [STOP], 'st["lineage"]["tool_calls_total"] += st["tool_count"]', "pass"),
 ("restart_blocked_on_broken_chain", ["hardening"], 'if not chain_ok and st["reason"] != "LOG_TAMPER":', "if False:"),
 ("log_size_cap", ["hardening"], 'if os.path.exists(lp) and os.path.getsize(lp) > pol["max_log_bytes"]:', "if False:"),
 ("stop_verifies_chain", ["hardening"], '            ok, _, msg = verify_chain(os.path.join(d, "events.jsonl"))\n            if not ok and st["status"] != "STOP":', '            ok, _, msg = verify_chain(os.path.join(d, "events.jsonl"))\n            if False and st["status"] != "STOP":'),
 ("prompt_text_profile", ["hardening"], 'if pol["log_prompt_text"] or os.environ.get("GCAE_PROFILE") == "uat":', "if True:"),
 ("tool_name_coercion", ["hardening"], 'tool, tin = as_tool(data.get("tool_name")), data.get("tool_input") or {}', 'tool, tin = data.get("tool_name") or "", data.get("tool_input") or {}'),
 ("path_coercion", ["hardening"], "        if isinstance(v, str) and v:", "        if v:"),
 ("agent_ctx_string", ["hardening"], 'ctx = str(data.get("agent_id") or "main")', 'ctx = data.get("agent_id") or "main"'),
 ("session_id_string", ["hardening"], 'sid = str(data.get("session_id") or "nosession")', 'sid = data.get("session_id") or "nosession"'),
 ("transcript_path_string", ["hardening"], 'if isinstance(data.get("transcript_path"), str) and data["transcript_path"]:', 'if data.get("transcript_path"):'),
 ("gitignore_safeguard", ["hardening"], "    if not os.path.exists(gi):", "    if False:"),
 ("analysis_truncation", ["hardening"], 'full_prompt, prompt = prompt, prompt[:pol["max_analysis_chars"]]', "full_prompt, prompt = prompt, prompt"),
 ("epoch_after_state_loss", ["hardening"], '                st["epoch"] = 1 + st["lineage"]["restarts"]', "                pass"),
 ("verify_session_argument", [INT], 'if "--session" in args and args.index("--session") + 1 < len(args):', "if False:"),
 ("new_turn_resets_budgets", ["turns"], "        new_turn(st)\n        if not env:", "        pass\n        if not env:"),
 ("lifetime_tool_backstop", ["turns"], 'or st["tool_count"] >= pol["lifetime_tool_hard"]:', "or False:"),
 ("global_budget_per_instruction", ["turns"], 'sum(st["ctx_tools"].values()) >= pol["global_tool_hard"]', 'st["tool_count"] >= pol["global_tool_hard"]'),
 ("internal_fault_never_swallows_prompt", [MAL], "    if event in NON_BLOCKING_EVENTS:", "    if False:"),
 ("crlf_tolerant_manifest", ["turns"], "                    if parts[1].lower().endswith(TEXT_EXT):", "                    if False:"),
 ("closure_stop_keeps_message", [RT], '+ stop_msg(st))\n            return 0', '+ stop_msg(st))\n            return block_prompt(stop_msg(st))'),
 ("stop_message_both_restart_forms", ["turns"], '"Explicitly restart the GCAE controlled runtime and begin a new controlled session.)  Send', '"Restart.)  Send'),
]

def one(m):
    name, groups, old, new = m
    s = open(SRC, encoding="utf-8").read()
    if s.count(old) != 1: return name, "INVALID(%d)" % s.count(old), ""
    d = tempfile.mkdtemp(prefix="gm_"); p = os.path.join(d, "gcae_guard.py"); open(p, "w", encoding="utf-8").write(s.replace(old, new))
    res = S.run_suite(p, tuple(g for g in groups if g))
    f = [n for n, ok in res if not ok]
    if f: return name, "KILLED", f[0][:80]
    res = S.run_suite(p)  # fall back to the full suite
    f = [n for n, ok in res if not ok]
    return name, ("KILLED(full)" if f else "SURVIVED"), (f[0][:80] if f else "")

if __name__ == "__main__":
    sel = sys.argv[1:]
    res = []
    with ThreadPoolExecutor(2) as ex:
        for n, st, f in ex.map(one, [m for m in M if not sel or m[0] in sel]):
            res.append((n, st, f)); print("%-9s %-32s %s" % (st, n, f), flush=True)  # stream: a crash never loses finished results
    inv = [r for r in res if r[1].startswith("INVALID")]; sv = [r for r in res if r[1] == "SURVIVED" and r[0] not in EQUIVALENT]; v = len(res) - len(inv) - len([r for r in res if r[0] in EQUIVALENT and r[1] == "SURVIVED"])
    for r in res:
        if r[0] in EQUIVALENT and r[1] == "SURVIVED": print("EQUIVALENT %-32s %s" % (r[0], EQUIVALENT[r[0]]))
    print("\nguard mutants: %d valid, %d killed, %d survived, %d invalid-anchor => %d/%d" % (v, v - len(sv), len(sv), len(inv), v - len(sv), v))
    sys.exit(1 if (sv or inv) else 0)
