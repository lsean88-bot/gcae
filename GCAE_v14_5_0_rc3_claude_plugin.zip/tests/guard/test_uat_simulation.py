"""The simulated UAT (red-team agents against the real launcher) must contain every attempt and the grader must grade the mechanical stages correctly."""
import os, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import uat_simulation as U

def test_every_simulated_attack_is_contained_and_graded():
    assert U.main(["--out", tempfile.mkdtemp()]) == 0
