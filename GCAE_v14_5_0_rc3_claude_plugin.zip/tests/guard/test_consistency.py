"""Package invariants. Each guards a drift/defect class found in v14.4.0 (duplicated authority, stale manifests, dangling docs, unregistered files)."""
import os, re, sys, json, glob, yaml, filecmp
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(os.path.dirname(HERE)); sys.path.insert(0, ROOT)
def J(rel): return json.load(open(os.path.join(ROOT, rel), encoding="utf-8"))
def Y(rel): return yaml.safe_load(open(os.path.join(ROOT, rel), encoding="utf-8"))
V = lambda: J(".claude-plugin/plugin.json")["version"]

def test_single_version_authority():
    v = V(); src = open(os.path.join(ROOT, "hooks/gcae_guard.py")).read(); rel = open(os.path.join(ROOT, "runtime/release.py")).read()
    bad = []
    for name, got in [("manifest", J("RELEASE_MANIFEST.json")["version"]), ("policy", J("core/policy/execution-thresholds.json")["version"]), ("registry", str(Y("capability-registry.yaml")["version"])),
                      ("guard", re.search(r'GUARD_VERSION = "([^"]+)"', src).group(1)), ("release.py", re.search(r"VERSION='([^']+)'", rel).group(1))]:
        if got != v: bad.append((name, got))
    for p in glob.glob(os.path.join(ROOT, "core/policy/*.yaml")):
        if str(yaml.safe_load(open(p)).get("version")) != v: bad.append((os.path.basename(p), "version"))
    assert not bad, bad

def test_no_stale_versions_in_active_files():
    v = V(); bad = []
    for rel in ["README.md", "docs/CLAUDE_INSTALL_AND_UAT.md", "SKILL.md"] + [os.path.relpath(p, ROOT) for p in glob.glob(os.path.join(ROOT, "skills/*/SKILL.md"))]:
        t = open(os.path.join(ROOT, rel), encoding="utf-8").read()
        for m in re.findall(r"\b14\.\d+\.\d+(?:-rc\d+)?\b", t):
            if m != v: bad.append((rel, m))
    assert not bad, bad[:10]

def test_policy_json_is_single_authority_and_yaml_is_a_faithful_view():
    assert Y("core/policy/execution-thresholds.yaml") == J("core/policy/execution-thresholds.json")
    p = J("core/policy/execution-thresholds.json"); sp = Y("core/policy/execution-safety-policy.yaml"); x = p["execution"]
    t = sp.get("thresholds") or {}
    pairs = [("tool_call_warning", x["tool_call_warning"]), ("tool_call_hard_limit", x["tool_call_hard_limit"])]
    for k, want in pairs:
        if k in t: assert t[k] == want, (k, t[k], want)

def test_guard_policy_block_is_sane():
    g = J("core/policy/execution-thresholds.json")["guard"]; x = J("core/policy/execution-thresholds.json")["execution"]
    assert g["max_restarts"] >= 1 and g["lifetime_identical_cap"] > x["repeated_call"]["exact_threshold"]
    assert g["per_agent_tool_hard"] <= g["global_tool_hard"] and x["tool_call_hard_limit"] <= g["global_tool_hard"]
    assert g["stop_lock_scope"] in ("session", "project") and x["agent"]["delegation_depth"] == 1

def test_root_skill_equals_gcae_skill():
    assert filecmp.cmp(os.path.join(ROOT, "SKILL.md"), os.path.join(ROOT, "skills/gcae/SKILL.md"), shallow=False)

def test_expected_skills_match_directory_and_every_skill_has_preflight():
    exp = set(J("core/policy/execution-thresholds.json")["guard"]["expected_skills"]); have = set(os.listdir(os.path.join(ROOT, "skills")))
    assert exp == have, (exp ^ have)
    for s in have:
        t = open(os.path.join(ROOT, "skills", s, "SKILL.md"), encoding="utf-8").read()
        fm = re.match(r"^---\n(.*?)\n---\n", t, re.S).group(1); name = re.search(r"^name:\s*(\S+)", fm, re.M).group(1); desc = re.search(r"^description:\s*(.*)$", fm, re.M).group(1)
        assert name == s and len(desc) <= 1024, (s, name, len(desc))
        assert "GCAE-PREFLIGHT v" in t and "run_guard.sh" in t, s

def test_hooks_json_is_valid_single_dispatcher():
    h = J("hooks/hooks.json")["hooks"]; known = {"SessionStart", "UserPromptSubmit", "UserPromptExpansion", "PreToolUse", "PostToolUse", "PostToolUseFailure", "PostToolBatch", "SubagentStart", "SubagentStop", "TaskCreated", "TaskCompleted", "Stop", "StopFailure", "SessionEnd"}
    assert set(h) <= known and {"SessionStart", "UserPromptSubmit", "PreToolUse", "PostToolUse", "PostToolUseFailure", "SubagentStop", "Stop", "StopFailure"} <= set(h)
    for ev, arr in h.items():
        assert len(arr) == 1 and len(arr[0]["hooks"]) == 1, ev   # exactly one handler per event: hooks run in parallel and would race on state
        c = arr[0]["hooks"][0]; assert "run_guard.sh" in c["command"] and c.get("timeout"), ev
    assert not os.path.exists(os.path.join(ROOT, "hooks/telemetry_hook.py"))

def test_launcher_is_fail_closed_and_not_python_only():
    t = open(os.path.join(ROOT, "hooks/run_guard.sh")).read()
    assert "exit 2" in t and "python3" in t and "py -3" in t

def test_every_reference_is_registered_or_declared_support():
    idx = J("core/capability-index.json"); reg = {v["file"] for v in idx.values() if v.get("file")}; sup = set(Y("package-structure.yaml").get("support_references", []))
    orphan = [f for f in os.listdir(os.path.join(ROOT, "references")) if "references/" + f not in reg and f not in sup]
    assert not orphan, orphan
    assert all(os.path.exists(os.path.join(ROOT, f)) for f in reg)

def test_no_dangling_documentation_paths():
    pat = re.compile(r"`((?:tests|core|runtime|hooks|docs|references|agents|tools|release-control|skills)/[A-Za-z0-9_./\-]+\.[a-z]+)`"); bad = []
    for f in ["README.md", "SKILL.md"] + [os.path.relpath(p, ROOT) for p in glob.glob(os.path.join(ROOT, "docs/*.md")) + glob.glob(os.path.join(ROOT, "skills/*/SKILL.md")) + glob.glob(os.path.join(ROOT, "tests/live-runtime/*.md"))]:
        if os.path.basename(f).startswith("V14_4_0"): continue
        for m in pat.findall(open(os.path.join(ROOT, f), encoding="utf-8", errors="ignore").read()):
            if "${" not in m and not os.path.exists(os.path.join(ROOT, m)): bad.append((f, m))
    assert not bad, bad

def test_guard_and_scope_authority_share_one_destructive_set():
    from runtime.scope import DESTRUCTIVE; src = open(os.path.join(ROOT, "hooks/gcae_guard.py")).read()
    toks = set(re.findall(r'"(\w+)"', re.search(r"DESTRUCTIVE_TOKENS = \{(.*?)\}", src, re.S).group(1)))
    assert toks == DESTRUCTIVE

def test_no_stale_hash_manifests():
    names = [os.path.basename(p) for p in glob.glob(os.path.join(ROOT, "BUILD_HASHES_*.sha256"))]
    assert all(n == "BUILD_HASHES_V14.5.0.sha256" for n in names), names

def test_telemetry_policy_matches_what_hooks_can_observe():
    sp = Y("core/policy/execution-safety-policy.yaml")["controlled_run"]
    assert sp["invalid_telemetry"] == "fail_closed" and "NOT_OBSERVED" in sp["absent_telemetry"]

def test_preserved_baseline_counts_and_files():
    idx = J("core/capability-index.json"); agents = [v for v in idx.values() if v.get("type") == "agent"] if any("type" in v for v in idx.values()) else []
    assert len(idx) == 100, len(idx)
    assert len(os.listdir(os.path.join(ROOT, "agents"))) == 45
    assert all(os.path.exists(os.path.join(ROOT, v["file"])) for v in idx.values() if v.get("file"))

def test_release_identity_sources_declared_and_equal():
    ident = Y("core/authority/release-identity.yaml"); v = V()
    assert str(ident["version"]) == v and ident["baseline"] == "14.4.0"
    for rel in ident["release_identity_sources"]: assert os.path.exists(os.path.join(ROOT, rel)), rel
