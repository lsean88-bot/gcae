import json, os, subprocess, sys, tempfile, concurrent.futures
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]; HOOK = ROOT / "hooks" / "gcae_guard.py"

def test_parallel_pretooluse_has_no_lost_updates(tmp_path):
    env = dict(os.environ, GCAE_RUNTIME_DIR=str(tmp_path), CLAUDE_PLUGIN_ROOT=str(ROOT), PYTHONDONTWRITEBYTECODE="1")
    def run(p): return subprocess.run([sys.executable, str(HOOK), "hook"], input=json.dumps(p), text=True, capture_output=True, env=env)
    run({"session_id": "c", "hook_event_name": "UserPromptSubmit", "prompt": "Audit inventory reconciliation"})
    with concurrent.futures.ThreadPoolExecutor(16) as ex:
        rcs = list(ex.map(lambda i: run({"session_id": "c", "hook_event_name": "PreToolUse", "tool_name": "Read", "tool_input": {"file": "f%d" % i}}).returncode, range(30)))
    st = json.loads((tmp_path / "sessions" / "c" / "state.json").read_text())
    assert set(rcs) == {0}
    assert st["tool_count"] == 30   # v14.4.0 asserted only 0 <= n <= 30, which any lost-update count satisfies
