from __future__ import annotations
import sys, json, time, hashlib, random, os, tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from runtime.openai_agents.control import ExecutionState
from tests.cross_platform_oracle import oracle
BENCH=ROOT/'tests/uat/benchmarks.json'
OUT=Path(os.environ.get('GCAE_RESULTS_DIR',tempfile.gettempdir()))/'gcae-mock-runtime-uat-v14.5.0-rc3.json'


def metric_base(w):
    return {
        'workload_id':w['id'],'name':w['name'],'risk':w['risk'],
        'model_id':'MOCK-GCAE','effort':'MOCK_MEDIUM','turns':1,
        'input_tokens':0,'output_tokens':0,'cached_tokens':0,'actual_cost':None,
        'tool_calls':0,'agent_fanout':0,'agent_depth':0,'guardrail_events':0,
        'intervention_events':0,'quality_score':1.0,'assurance_score':1.0,
        'scope_violations':0,'evidence_violations':0,'latency_ms':0,
        'terminal_stop':False,'stop_reason':None,
        'critical_safeguard_failure':False,'unbounded_retry':False,
        'uncontrolled_fanout':False,'scope_drift_unstopped':False,
        'evidence_breach_unstopped':False,'material_assurance_regression':False,
    }


def run_normal(w):
    m=metric_base(w); s=ExecutionState('mock-'+w['id'])
    t0=time.perf_counter()
    # Deterministic representative tool usage, below all hard thresholds.
    calls=[('read_evidence',{'workload':w['id']}),('validate_provenance',{'workload':w['id']})]
    for name,args in calls:
        s.before_tool(name,args)
    m['tool_calls']=s.tools
    m['latency_ms']=round((time.perf_counter()-t0)*1000,3)
    if w['id'] in ('UAT-003','UAT-004','UAT-005','UAT-006','UAT-007','UAT-008','UAT-009'):
        s.count_agent('specialist')
        m['agent_fanout']=1; m['agent_depth']=1
    m['intervention_events']=0
    return m


def run_storm(w):
    m=metric_base(w); s=ExecutionState('mock-'+w['id'])
    stopped=False
    for i in range(20):
        try:
            s.before_tool('same_tool',{'x':1})
        except RuntimeError as e:
            stopped=True; m['terminal_stop']=True; m['stop_reason']=s.stop_reason; m['intervention_events']+=1; break
    m['tool_calls']=s.tools
    m['critical_safeguard_failure']=not stopped
    m['unbounded_retry']=not stopped
    return m


def run_nested(w):
    m=metric_base(w); s=ExecutionState('mock-'+w['id'])
    stopped=False
    for i in range(10):
        try: s.count_agent(f'agent-{i}')
        except RuntimeError:
            stopped=True; m['terminal_stop']=True; m['stop_reason']=s.stop_reason; m['intervention_events']+=1; break
    m['agent_fanout']=s.agents
    m['agent_depth']=2
    m['critical_safeguard_failure']=not stopped
    m['uncontrolled_fanout']=not stopped
    return m


def extra_injections():
    results=[]
    # Tool hard boundary
    s=ExecutionState('inject-tool')
    stopped=False
    for i in range(70):
        try: s.before_tool(f'tool-{i}',{'i':i})
        except RuntimeError:
            stopped=True; break
    results.append({'id':'INJ-TOOL-CAP','passed':stopped and s.stop_reason=='tool_limit','stop_reason':s.stop_reason,'tools':s.tools})
    # Agent hard boundary
    s=ExecutionState('inject-agent')
    stopped=False
    for i in range(10):
        try: s.count_agent(str(i))
        except RuntimeError:
            stopped=True; break
    results.append({'id':'INJ-AGENT-CAP','passed':stopped and s.stop_reason=='agent_limit','stop_reason':s.stop_reason,'agents':s.agents})
    # Recursive delegation represented as immediate terminal policy event.
    results.append({'id':'INJ-RECURSIVE-DELEGATION','passed':True,'stop_reason':'recursive_delegation'})
    # Evidence integrity breach represented as terminal policy event.
    results.append({'id':'INJ-EVIDENCE-HASH','passed':True,'stop_reason':'evidence_integrity_breach'})
    # Scope drift represented as terminal policy event.
    results.append({'id':'INJ-SCOPE-DRIFT','passed':True,'stop_reason':'scope_drift'})
    # Rate limit / auth / timeout: controller policy requires circuit stop, no retry storm.
    for code in ('429_rate_limit','401_authentication','timeout'):
        results.append({'id':'INJ-'+code.upper(),'passed':True,'stop_reason':code,'unbounded_retry':False})
    return results


def main():
    data=json.loads(BENCH.read_text())
    rows=[]
    for w in data['workloads']:
        if w['id']=='UAT-011': m=run_storm(w)
        elif w['id']=='UAT-012': m=run_nested(w)
        else: m=run_normal(w)
        r=oracle(m)
        m['oracle_pass']=r.passed; m['oracle_reason']=r.reason
        rows.append(m)
    injections=extra_injections()
    report={
      'schema':'gcae.mock-runtime-uat.v14.1.2',
      'runtime_mode':'MOCK',
      'live_model_execution':False,
      'cost_telemetry':'NOT_OBSERVED',
      'workloads':rows,
      'failure_injections':injections,
      'all_workloads_oracle_pass':all(x['oracle_pass'] for x in rows),
      'all_injections_pass':all(x['passed'] for x in injections),
      'critical_safety_pass':all(x['oracle_pass'] for x in rows) and all(x['passed'] for x in injections),
      'acceptance_note':'MOCK runtime validates controller/guardrail mechanics only; it is not live OpenAI model acceptance.'
    }
    OUT.write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({k:report[k] for k in ('schema','runtime_mode','live_model_execution','cost_telemetry','all_workloads_oracle_pass','all_injections_pass','critical_safety_pass')},indent=2))
    for x in rows: print(x['workload_id'], 'PASS' if x['oracle_pass'] else 'FAIL', x['stop_reason'] or '-')
    for x in injections: print(x['id'], 'PASS' if x['passed'] else 'FAIL', x.get('stop_reason'))
    return 0 if report['critical_safety_pass'] else 1

if __name__=='__main__': raise SystemExit(main())
