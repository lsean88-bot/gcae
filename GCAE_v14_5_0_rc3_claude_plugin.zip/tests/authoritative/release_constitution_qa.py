#!/usr/bin/env python3
import sys
sys.dont_write_bytecode=True
#!/usr/bin/env python3
from pathlib import Path
import json,yaml,sys
ROOT=Path(__file__).resolve().parents[2]; issues=[]; V='14.5.0-rc3'
plugin=json.loads((ROOT/'.claude-plugin/plugin.json').read_text())
if plugin.get('version')!=V: issues.append('plugin-version')
for p in (ROOT/'core/policy').glob('*.yaml'):
 d=yaml.safe_load(p.read_text()) or {}
 if str(d.get('version'))!=V: issues.append('policy-version:'+p.name)
for rel in ['capability-registry.yaml','routing-manifest.yaml','package-structure.yaml','core/disposition-register.yaml','release-control/production-acceptance-policy.yaml']:
 d=yaml.safe_load((ROOT/rel).read_text()) or {}
 if str(d.get('version'))!=V: issues.append('metadata-version:'+rel)
for rel in ['iia-standards-conformance.yaml','knowledge-boundary.yaml']:
 d=yaml.safe_load((ROOT/rel).read_text()) or {}
 if str(d.get('package_version'))!=V: issues.append('package-version:'+rel)
if (ROOT/'core/schema').exists(): issues.append('legacy-core-schema-active')
if len(list((ROOT/'agents').glob('*.md'))) != 45: issues.append('agent-count')
idx=json.loads((ROOT/'core/capability-index.json').read_text())
if len(idx)!=100: issues.append('capability-count')
for p in ROOT.rglob('*'):
 if '__pycache__' in p.parts or p.suffix=='.pyc' or p.name=='.pytest_cache': issues.append('generated:'+str(p.relative_to(ROOT)))
print(json.dumps({'status':'PASS' if not issues else 'FAIL','issues':issues},indent=2));sys.exit(0 if not issues else 1)
