# v11.2.1 QA & Release Checklist

## Static control-plane gates
- [ ] Global test IDs unique and immutable
- [ ] Every active agent registered and routable exactly once or via declared alias
- [ ] Every reference/jurisdiction/industry production object registered
- [ ] Registry schema complete
- [ ] Agent contracts complete
- [ ] Reference metadata complete
- [ ] Topical Requirements register current and engagement applicability mechanism present
- [ ] IIA 15-principle conformance matrix present
- [ ] Version/status/hash consistent across release artifacts
- [ ] No stale release artefacts
- [ ] Dependency graph acyclic and resolvable

## Runtime gates
- [ ] Critical persistence UAT executed in target runtime
- [ ] Critical independence/evidence/security UAT executed
- [ ] Prompt-injection tests executed
- [ ] Memory poisoning/rollback tests executed
- [ ] Alert escalation tests executed
- [ ] Runtime model/version recorded
- [ ] No unresolved critical failures

## Release state
Static PASS alone = RELEASE-CANDIDATE.
RUNTIME-ACCEPTED requires target-runtime evidence.
PRODUCTION requires approved release record and zero unresolved critical safeguards.
