from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT))
from runtime.router import Router

def test_whitespace_case_invariance():
 r=Router(ROOT)
 a=r.classify('Research and verify India GST statutory requirements.',authorized_scope='India GST research')
 b=r.classify('  RESEARCH   AND   VERIFY   INDIA   GST   STATUTORY   REQUIREMENTS. ',authorized_scope='India GST research')
 assert a.intent==b.intent=='research'
