import json, os, subprocess, sys, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from runtime.router import Router
from runtime.dependency_closure import DependencyClosure
from runtime.controller import RuntimeState,State

def test_communication_exclusive():
    r=Router(ROOT).classify('Please rewrite this email professionally. The attached fraud finding is mentioned but do not investigate it.',authorized_scope='rewrite the email')
    assert r.intent=='communication' and r.selected_capabilities==['AG-024']
def test_regulatory_research():
    r=Router(ROOT).classify('Research and verify India GST statutory requirements for the audit conclusion.',authorized_scope='India GST research')
    assert r.intent=='research' and 'AG-004' in r.selected_capabilities

def test_package_safe_dependency():
    c=DependencyClosure(ROOT).close(['AG-002']); assert c['status']=='COMPLETE'
def test_scope_fail_closed():
    s=RuntimeState(ROOT); s.authorize('audit inventory'); s.check_scope({'operation':'unrelated legal advice'}); assert s.state==State.STOP and s.stop_reason=='SCOPE_DRIFT'
def test_repeat_episode_reset():
    s=RuntimeState(ROOT); s.authorize('audit');
    for i in range(2): assert s.tool('read','file-a',result={'value':i})!=State.STOP
    # meaningful progress breaks the repeat episode; the same tool can legitimately recur later
    s.recent_fingerprints=[]
    assert s.tool('read','file-a',result={'value':'new'})!=State.STOP
