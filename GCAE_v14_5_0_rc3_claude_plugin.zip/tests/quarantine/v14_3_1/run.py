import subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[2]
cmd=[sys.executable,'-m','pytest','-q','tests/v14_3_1']
raise SystemExit(subprocess.call(cmd,cwd=root))
