#!/usr/bin/env python3
"""Authoritative v14.3.1 package QA; builder evidence only, not independent certification."""
from pathlib import Path
import json, hashlib, re, yaml, sys
ROOT=Path(__file__).resolve().parents[2]
issues=[]
plugin=json.loads((ROOT/'.claude-plugin/plugin.json').read_text())
if plugin.get('version')!='14.3.1': issues.append('plugin version')
manifest=json.loads((ROOT/'RELEASE_MANIFEST.json').read_text())
if manifest.get('version')!='14.3.1': issues.append('manifest version')
identity=yaml.safe_load((ROOT/'core/authority/release-identity.yaml').read_text())
if identity['release']['version']!='14.3.1': issues.append('release identity version')
for p in (ROOT/'core/policy').glob('*.yaml'):
    d=yaml.safe_load(p.read_text()) or {}
    if 'version' in d and str(d['version'])!='14.3.1': issues.append(f'stale policy:{p}')
idx=json.loads((ROOT/'core/capability-index.json').read_text())
if len(idx)!=100: issues.append(f'capabilities:{len(idx)}')
if len(list((ROOT/'agents').glob('*.md'))) != 45: issues.append('agents')
for p in ROOT.rglob('*'):
    if '__pycache__' in p.parts or p.suffix=='.pyc': issues.append(f'generated:{p.relative_to(ROOT)}')
if not (ROOT/'independent_counsel/COUNSEL_CONSTITUTION.md').exists(): issues.append('counsel')
if not (ROOT/'tests/authoritative/TEST_AUTHORITY.yaml').exists(): issues.append('test authority')
if not (ROOT/'audit_lifecycle/ENGINE.md').exists(): issues.append('lifecycle boundary')
# Verify the hash file is structurally complete against the tree, excluding the hash file itself.
hashfile=ROOT/'BUILD_HASHES_V14.3.1.sha256'
lines=[x for x in hashfile.read_text().splitlines() if x.strip()]
listed={line.split('  ',1)[1] for line in lines if '  ' in line}
expected={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and p.name!='BUILD_HASHES_V14.3.1.sha256' and p.suffix!='.pyc' and '__pycache__' not in p.parts}
if listed != expected: issues.append(f'hash coverage missing={len(expected-listed)} extra={len(listed-expected)}')
print(json.dumps({'status':'PASS' if not issues else 'FAIL','issues':issues,'capabilities':len(idx),'agents':len(list((ROOT/'agents').glob('*.md'))),'hash_entries':len(lines)},indent=2))
sys.exit(0 if not issues else 1)
