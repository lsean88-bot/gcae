import json,os,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]; HOOK=ROOT/'hooks/telemetry_hook.py'
def run(payload,td):
    e=os.environ.copy();e['GCAE_RUNTIME_DIR']=td
    p=subprocess.run([sys.executable,str(HOOK)],input=json.dumps(payload)+'\n',text=True,capture_output=True,env=e)
    return p

def test_plain_native_provider_events():
    with tempfile.TemporaryDirectory() as td:
      for err in ['rate_limit','authentication_failed','billing_error','server_error','overloaded']:
        p=run({'session_id':'x','hook_event_name':'StopFailure','error':err},td)
        state=json.loads(Path(td,'x.status.json').read_text())
        assert state['state']=='STOP',err

def test_business_content_429_not_provider_failure():
    with tempfile.TemporaryDirectory() as td:
      p=run({'session_id':'x','hook_event_name':'PreToolUse','tool_name':'Read','tool_input':{'file':'invoice RM4290.50'}},td)
      state=json.loads(Path(td,'x.status.json').read_text()); assert state['state']!='STOP'

def test_restart_is_human_only():
    with tempfile.TemporaryDirectory() as td:
      run({'session_id':'x','hook_event_name':'StopFailure','error':'rate_limit'},td)
      p=run({'session_id':'x','hook_event_name':'UserPromptSubmit','prompt':'continue'},td)
      state=json.loads(Path(td,'x.status.json').read_text()); assert state['state']=='STOP'
      run({'session_id':'x','hook_event_name':'UserPromptSubmit','prompt':'/gcae-enterprise-assurance-risk:restart'},td)
      state=json.loads(Path(td,'x.status.json').read_text()); assert state['state']=='RUNNING' and state['run_id']==2
