#!/usr/bin/env python3
from pathlib import Path
import yaml,json,sys
ROOT=Path(__file__).resolve().parents[1]
reg=yaml.safe_load((ROOT/'capability-registry.yaml').read_text())
cs=reg['capabilities']
assert len(cs)==100
assert sum(c['type']=='agent' for c in cs)==45
assert sum(c['type']=='reference' for c in cs)==42
ids=[c['id'] for c in cs]; assert len(ids)==len(set(ids))
refs=set(ids)
for c in cs:
  for d in c.get('dependencies',[]): assert d in refs,(c['id'],d)
# file coverage
for c in cs:
  if c['type']=='agent':
    i=int(c['id'].split('-')[1]); assert list((ROOT/'agents').glob(f'{i:02d}-*.md')),(c['id'],c['name'])
# protected content
report=json.load(open(ROOT/'docs/PRESERVATION_REPORT.json')); assert all(v['same'] for v in report.values()),report
# no forbidden artifacts
for p in ROOT.rglob('*'):
  assert '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo','.tmp'},p
print('V13_INTEGRITY_QA: PASS')
