"""Verify release manifest file count and forbidden artifacts."""
import json,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
files=[p for p in root.rglob('*') if p.is_file()]
assert not any('__pycache__' in p.parts or p.suffix in {'.pyc','.pyo','.tmp'} for p in files)
m=json.loads((root/'RELEASE_MANIFEST.json').read_text())
assert m['counts']['files']==len(files),(m['counts']['files'],len(files))
assert m['version']=='14.0.1'
assert m['counts']['extreme_adversarial_cases']==1034
assert m['counts']['misfire_tests']==14
assert m['counts']['mutation_checks']==11
print(f'RELEASE_MANIFEST_QA: PASS ({len(files)} files)')
