"""Observable runtime QA: status, checkpoints, explicit hard-limit intervention."""
import json, os, subprocess, sys, tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
hook=root/'hooks/telemetry_hook.py'
run=Path(tempfile.mkdtemp(prefix='gcae_obs_'))
env=dict(os.environ); env['GCAE_RUNTIME_DIR']=str(run)

def call(payload):
    p=subprocess.run([sys.executable,str(hook)],input=json.dumps(payload),text=True,capture_output=True,env=env)
    assert p.returncode==0, p.stderr
    return p.stdout.strip()

sid='OBSQA'
out=call({'session_id':sid,'hook_event_name':'UserPromptSubmit','prompt':'test'})
assert 'GCAE STATUS: RUNNING' in out
for i in range(1,6):
    call({'session_id':sid,'hook_event_name':'PreToolUse','tool_name':'Bash','tool_use_id':f't{i}'})
out=call({'session_id':sid,'hook_event_name':'PostToolBatch','tool_calls':[]})
assert 'tools=5/30' in out

sid='STOPQA'
for i in range(31):
    out=call({'session_id':sid,'hook_event_name':'PreToolUse','tool_name':'Bash','tool_use_id':f't{i}'})
assert 'TOOL_CALL_LIMIT' in out
status=json.loads((run/f'{sid}.status.json').read_text())
assert status['state']=='STOP' and status['stop_reason']=='TOOL_CALL_LIMIT'

sid='AGENTQA'
for i in range(5): call({'session_id':sid,'hook_event_name':'SubagentStart','agent_id':f'a{i}'})
out=call({'session_id':sid,'hook_event_name':'PreToolUse','tool_name':'Task'})
assert 'AGENT_LIMIT' in out
print('OBSERVABILITY_QA: PASS')
