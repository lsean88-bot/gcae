import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from runtime.router import Router
from runtime.model_effort_selector import select
root=Path(__file__).resolve().parents[1]
router=Router(root)
cases=json.loads((root/'tests/v13/misfire-routing.json').read_text())['cases']
fail=[]
for c in cases:
 r=router.classify(c['input'],c['id'])
 ok=r.intent==c['expected_intent'] and c['expected_agent'] in r.selected_agents
 if not ok: fail.append((c,r))
 print(c['id'], 'PASS' if ok else 'FAIL', r.intent, r.selected_agents, r.quarantined_evidence_terms)
if fail: raise SystemExit(1)
print(f'MISFIRE_QA: PASS ({len(cases)}/{len(cases)})')
