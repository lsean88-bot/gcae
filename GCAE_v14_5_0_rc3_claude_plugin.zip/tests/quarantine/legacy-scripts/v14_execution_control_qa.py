import json, os, subprocess, sys, tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]; hook=root/'hooks/telemetry_hook.py'
env=dict(os.environ); run=Path(tempfile.mkdtemp(prefix='gcae_v14_')); env['GCAE_RUNTIME_DIR']=str(run)
def call(p):
 r=subprocess.run([sys.executable,str(hook)],input=json.dumps(p),text=True,capture_output=True,env=env); assert r.returncode==0, r.stderr; return r.stdout
assert 'GCAE STATUS' in call({'session_id':'s1','hook_event_name':'UserPromptSubmit'})
for i in range(3): call({'session_id':'rep','hook_event_name':'PreToolUse','tool_name':'Bash','tool_input':{'cmd':'same'}})
out=call({'session_id':'rep','hook_event_name':'PreToolUse','tool_name':'Bash','tool_input':{'cmd':'same'}}); assert 'REPETITIVE_TOOL_LOOP' in out
out=call({'session_id':'rep','hook_event_name':'PreToolUse','tool_name':'Bash','tool_input':{'cmd':'different'}}); assert 'terminally stopped' in out
for i in range(5): call({'session_id':'ag','hook_event_name':'SubagentStart','agent_id':str(i)})
out=call({'session_id':'ag','hook_event_name':'PreToolUse','tool_name':'Task','tool_input':{}}); assert 'AGENT_LIMIT' in out
r=subprocess.run([sys.executable,str(hook)],input='{bad',text=True,capture_output=True,env=env); assert 'INVALID_HOOK_INPUT' in r.stdout
out=call({'session_id':'rl','hook_event_name':'PreToolUse','tool_name':'Bash','tool_input':{'x':'429 rate_limit'}}); assert 'RATE_LIMIT_SIGNAL' in out
assert (root/'SKILL.md').exists(); assert json.loads((root/'.claude-plugin/plugin.json').read_text())['version']=='14.0.1'
print('V14_EXECUTION_CONTROL_QA: PASS')
