#!/usr/bin/env python3
import json, pathlib, sys
r=pathlib.Path(__file__).resolve().parents[1]
errors=[]
def req(p):
    if not (r/p).exists(): errors.append(f"missing: {p}")
for p in ['.claude-plugin/plugin.json','skills/gcae/SKILL.md','hooks/hooks.json','hooks/telemetry_hook.py','capability-registry.yaml','core/invariants.yaml','core/precedence.yaml','runtime/router.py','runtime/controller.py','runtime/model_effort_selector.py','runtime/telemetry.py','agents','references','tests','release-control'] : req(p)
try:
 m=json.loads((r/'.claude-plugin/plugin.json').read_text()); assert m['name']=='gcae-enterprise-assurance-risk'; assert m['version']=='14.0.1'
except Exception as e: errors.append('invalid plugin.json: '+str(e))
try:
 h=json.loads((r/'hooks/hooks.json').read_text()); assert 'PreToolUse' in h['hooks'] and 'SubagentStart' in h['hooks']
except Exception as e: errors.append('invalid hooks.json: '+str(e))
for d in ['agents','references']:
 if not list((r/d).glob('*')): errors.append(f'empty: {d}')
print('PLUGIN_VALIDATION: '+('PASS' if not errors else 'FAIL'))
for e in errors: print(e)
sys.exit(1 if errors else 0)
