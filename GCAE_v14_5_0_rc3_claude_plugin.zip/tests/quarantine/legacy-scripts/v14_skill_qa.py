from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
skills=sorted((root/'skills').glob('*/SKILL.md'))
assert len(skills)==9
names=[]; desc=[]
for p in skills:
    t=p.read_text()
    assert t.startswith('---\n') and '\n---\n' in t[:1200], p
    fm=t.split('---',2)[1]
    m=re.search(r'^name:\s*(.+)$',fm,re.M); d=re.search(r'^description:\s*(.+)$',fm,re.M)
    assert m and d, p
    names.append(m.group(1).strip()); desc.append(d.group(1).strip())
assert len(names)==len(set(names)), names
expected={'gcae','audit','investigation','risk','research','board-assurance','communication','plugin-admin','status'}
assert set(names)==expected, names
comm=(root/'skills/communication/SKILL.md').read_text().lower(); assert 'do not perform substantive investigation' in comm
status=(root/'skills/status/SKILL.md').read_text().lower(); assert 'read-only' in status and 'do not infer completion from silence' in status
admin=(root/'skills/plugin-admin/SKILL.md').read_text().lower(); assert 'do not emit repetitive no-change status messages' in admin
master=(root/'skills/gcae/SKILL.md').read_text().lower(); assert 'bounded recovery protocol' in master and 'never retry indefinitely' in master
print('V14_SKILL_QA: PASS | 9 skills | unique names | communication isolation | status read-only | bounded recovery')
