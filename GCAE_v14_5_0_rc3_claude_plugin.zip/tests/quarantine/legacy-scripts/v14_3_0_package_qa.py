from pathlib import Path
import json,yaml,sys,zipfile
root=Path(__file__).resolve().parents[1]
issues=[]
pm=json.loads((root/'.claude-plugin/plugin.json').read_text())
reg=yaml.safe_load((root/'capability-registry.yaml').read_text())
if pm.get('version')!='14.3.0': issues.append('version')
if len(reg['capabilities'])!=100: issues.append('capabilities')
if not (root/'runtime/dependency_closure.py').exists(): issues.append('dependency closure')
if 'DependencyClosure' not in (root/'runtime/router.py').read_text(): issues.append('router integration')
if 'structured_provider_failure' not in (root/'hooks/telemetry_hook.py').read_text(): issues.append('provider failure')
print(json.dumps({'status':'PASS' if not issues else 'FAIL','issues':issues},indent=2));sys.exit(0 if not issues else 1)
