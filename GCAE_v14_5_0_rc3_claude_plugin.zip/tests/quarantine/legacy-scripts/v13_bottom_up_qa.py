#!/usr/bin/env python3
from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from runtime.router import Router
from runtime.model_effort_selector import select
from runtime.controller import RuntimeState,State

sc=json.loads((ROOT/'tests/v13/complex-adversarial-uat.json').read_text())['scenarios']
router=Router(ROOT)
results=[]
for s in sc:
    r=router.classify(s['name'],s['id'])
    sel=select(s['name'], risk=r.risk_tier, intent=r.intent)
    if s['id']=='UAT-001': ok=(r.intent=='investigation' and sel=='OPUS_MEDIUM')
    elif s['id']=='UAT-002': ok=(r.intent=='investigation' and sel=='OPUS_MEDIUM')
    elif s['id']=='UAT-003': ok=(r.intent=='investigation' and sel=='OPUS_HIGH')
    elif s['id']=='UAT-004': ok=(r.intent=='research' and sel=='SONNET_HIGH')
    elif s['id']=='UAT-005': ok=(r.intent=='investigation' and r.risk_tier=='L4' and sel=='OPUS_MEDIUM')
    elif s['id']=='UAT-006': ok=(r.intent in {'assurance','analysis'} and sel=='SONNET_HIGH')
    elif s['id']=='UAT-007': ok=(r.intent=='communication' and r.selected_agents==['AG-022'] and sel=='SONNET_LOW')
    elif s['id']=='UAT-014': ok=(sel=='SONNET_LOW')
    elif s['id']=='UAT-015': ok=(sel=='OPUS_HIGH')
    elif s['id']=='UAT-017': ok=(r.intent=='research' and sel=='SONNET_HIGH')
    elif s['id'] in {'UAT-008','UAT-009','UAT-010','UAT-011','UAT-012','UAT-013','UAT-018'}: ok=True
    else: ok=bool(r.selected_agents)
    results.append({'id':s['id'],'router_intent':r.intent,'risk':r.risk_tier,'agents':r.selected_agents,'selector':sel,'pass':ok})

checks=[]
for name,kwargs,expected in [
 ('hard_budget',{'cost':1.0},State.STOP),
 ('tool_cap',{'tools':31},State.STOP),
 ('agent_cap',{'agents':6},State.STOP),
 ('recursive',{'recursive':True},State.STOP),
 ('telemetry_unknown',{'telemetry_valid':False},State.STOP),
 ('evidence_breach',{'evidence_breach':True},State.STOP),
 ('scope_drift',{'scope_drift':True},State.STOP),
 ('instruction_breach',{'instruction_breach':True},State.STOP),
 ('no_progress',{'progress':False},State.STOP),
]:
    st=RuntimeState()
    if name=='no_progress':
        for _ in range(3): got=st.observe(**kwargs)
    else: got=st.observe(**kwargs)
    checks.append({'name':name,'got':got.value,'expected':expected.value,'pass':got==expected})

structural=[
 (ROOT/'core/routing-truth-table.yaml').exists(),
 (ROOT/'core/dependency-graph.json').exists(),
 (ROOT/'core/disposition-register.yaml').exists(),
 (ROOT/'history/quarantine/v12.2/router').exists(),
 not (ROOT/'router').exists(),
]
print(json.dumps({'uat':results,'controller':checks,'structural_pass':all(structural),'uat_pass':all(x['pass'] for x in results),'controller_pass':all(x['pass'] for x in checks)},indent=2))
raise SystemExit(0 if all(x['pass'] for x in results+checks) and all(structural) else 1)
