from pathlib import Path
import json, zipfile, hashlib, yaml, subprocess, sys
root=Path(__file__).resolve().parents[1]
manifest=json.loads((root/'RELEASE_MANIFEST.json').read_text())
plugin=json.loads((root/'.claude-plugin/plugin.json').read_text())
assert plugin['version']=='14.0.1'
assert manifest['version']=='14.0.1'
required=['.claude-plugin/plugin.json','SKILL.md','capability-registry.yaml','iia-standards-conformance.yaml','knowledge-boundary.yaml','topical-requirements-register.yaml']
for x in required: assert (root/x).exists(), x
for d in ['core','agents','references','jurisdictions','industries','evidence','skills','tests','runtime','release-control','history/quarantine']: assert (root/d).is_dir(), d
assert len(list((root/'agents').glob('*.md')))==45
assert len(list((root/'references').glob('*.md')))==44
skills=list((root/'skills').glob('*/SKILL.md')); assert len(skills)==9
assert all((p.read_text().startswith('---\n') for p in skills))
for p in root.rglob('*'):
 if p.is_file(): assert '__pycache__' not in p.parts and p.suffix not in {'.pyc','.pyo','.tmp'}
# no active v12 router outside quarantine
active=[p for p in (root/'runtime').glob('*') if p.is_file() and 'router' in p.name.lower()]
assert active
print('V14_PACKAGE_QA: PASS | agents=45 | refs=44 | skills=9 | required_contract=PASS | hygiene=PASS')
