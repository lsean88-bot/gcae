"""Extreme adversarial QA for GCAE v13.1.3."""
import math, random, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from runtime.router import Router
from runtime.model_effort_selector import select
from runtime.controller import RuntimeState, State
ROOT=Path(__file__).resolve().parents[1]
r=Router(ROOT)
cases=[
('make this professional: audit the VAT refund','communication'),
('draft a board assurance email about fraud investigation','communication'),
('please explain why audit findings mention fraud','analysis'),
('do not investigate; explain this fraud allegation','analysis'),
('find the previous audit report and audit it','assurance'),
('what is the difference between audit and investigation?','analysis'),
('risk assessment for production release','risk'),
('research plugin security','research'),
('rewrite: research the VAT law, but do not research it','communication'),
('draft an email asking management to investigate fraud','communication'),
('draft an email and investigate fraud','investigation'),
('check whether the plugin has duplicate routing and misfiring','build_qa'),
('release the plugin to production','build_qa'),
('prepare an enterprise risk assessment','risk'),
]
for i,(text,expected) in enumerate(cases):
    got=r.classify(text,f'EXT-{i}').intent
    assert got==expected,(text,got,expected)
# 1,000 randomized adversarial strings; no exception and hard cap invariant.
for i in range(1000):
    toks=random.sample(['audit','fraud','investigate','research','rewrite','plugin','uat','risk','board','retrieve','explain','production','nominee','reconcile'],k=random.randint(0,8))
    text=' '.join(toks)+random.choice(['',' !!!',' "fraud"',' do not investigate',' and research'])
    q=r.classify(text,f'FUZZ-{i}')
    assert len(q.selected_capabilities)<=5 and len(q.selected_agents)<=5
# Budget/cap boundaries.
for cost,expected in [(None,State.STOP),(-1,State.STOP),(0,State.GREEN),(.75,State.AMBER),(.9,State.RED),(1.0,State.STOP),(float('inf'),State.STOP),(float('nan'),State.STOP)]:
    st=RuntimeState(); valid=cost is not None and cost>=0 and cost==cost
    assert st.observe(cost=cost,telemetry_valid=valid)==expected,(cost,st.state)
for tools,expected in [(30,State.GREEN),(31,State.STOP)]:
    assert RuntimeState().observe(tools=tools)==expected
for agents,expected in [(5,State.GREEN),(6,State.STOP)]:
    assert RuntimeState().observe(agents=agents)==expected
# Effort ladder safety.
assert select('rewrite this email containing fraud investigation','L0','communication')=='SONNET_LOW'
assert select('forensic reconstruction of nominee payment','L4','investigation')=='OPUS_HIGH'
assert select('plugin UAT misfire routing','L3','build_qa')=='SONNET_HIGH'
print('EXTREME_QA: PASS (14 semantic adversarial + 1000 fuzz + controller boundaries + effort safety)')
