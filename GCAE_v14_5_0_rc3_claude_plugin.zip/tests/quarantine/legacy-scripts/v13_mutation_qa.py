#!/usr/bin/env python3
from pathlib import Path
import yaml,json,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from runtime.router import Router
from runtime.controller import RuntimeState,State

reg=yaml.safe_load((ROOT/'capability-registry.yaml').read_text())
ids={c['id'] for c in reg['capabilities']}
results=[]
# mutation 1: orphan dependency
mutated=next(c for c in reg['capabilities'] if c['id']=='AG-001').copy(); mutated['dependencies']=list(mutated.get('dependencies',[]))+['REF-999']
results.append(('orphan_dependency_detected', 'REF-999' not in ids))
# mutation 2: communication contamination
r=Router(ROOT).classify('Please rewrite this email: "fraud and investigation"; do not investigate it.')
results.append(('communication_exclusivity', r.intent=='communication' and r.selected_agents==['AG-022']))
# mutation 3: recursive delegation
results.append(('recursive_delegation_stop', RuntimeState().observe(recursive=True)==State.STOP))
# mutation 4: evidence breach
results.append(('evidence_breach_stop', RuntimeState().observe(evidence_breach=True)==State.STOP))
# mutation 5: unknown cost
results.append(('unknown_cost_stop', RuntimeState().observe(telemetry_valid=False)==State.STOP))
# mutation 6: hard budget
results.append(('hard_budget_stop', RuntimeState().observe(cost=1.0)==State.STOP))
# mutation 7: hard operational limits are terminal
results.append(('hard_tool_cap_stop', RuntimeState().observe(tools=31)==State.STOP))
results.append(('hard_agent_cap_stop', RuntimeState().observe(agents=6)==State.STOP))
results.append(('scope_drift_stop', RuntimeState().observe(scope_drift=True)==State.STOP))
# mutation 8: specialist cannot create recursive routing (contract check)
contract=(ROOT/'core/policy/agent-contract.yaml').read_text()
results.append(('agent_cannot_route', 'create recursive agent routing' in contract and 'redefine routing policy' in contract))
# mutation 9: legacy router is quarantined
results.append(('legacy_quarantine', not (ROOT/'router').exists() and (ROOT/'history/quarantine/v12.2/router').exists()))
for n,p in results: print(n, 'PASS' if p else 'FAIL')
raise SystemExit(0 if all(p for _,p in results) else 1)
