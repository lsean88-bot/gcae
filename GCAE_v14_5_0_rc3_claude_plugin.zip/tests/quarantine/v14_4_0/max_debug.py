#!/usr/bin/env python3
"""Maximum deterministic + target-hook simulation suite for GCAE v14.5.0-rc1.
This is not a substitute for a real Claude Code session; it exercises the actual hook process boundary.
"""
from pathlib import Path
import subprocess,json,tempfile,os,shutil,hashlib,random,threading
ROOT=Path(__file__).resolve().parents[2]; HOOK=ROOT/'hooks/telemetry_hook.py'
PASS=[]; FAIL=[]
def run(state_dir,payload):
 e=os.environ.copy(); e['GCAE_RUNTIME_DIR']=str(state_dir)
 p=subprocess.run(['python',str(HOOK)],input=json.dumps(payload)+'\n',text=True,capture_output=True,env=e,timeout=15)
 try:o=json.loads(p.stdout.strip()) if p.stdout.strip() else {}
 except Exception:o={'_raw':p.stdout}
 return p.returncode,o,p.stderr

def check(name,cond,detail=''):
 (PASS if cond else FAIL).append((name,detail))

def main():
 with tempfile.TemporaryDirectory(prefix='gcae1440-') as td:
  d=Path(td); sid='MAXSIM'
  base={'session_id':sid,'hook_event_name':'UserPromptSubmit','prompt':'Build and test the GCAE runtime package with audit evidence.'}
  run(d,base)
  print('start',flush=True)
  # 1 structured exact-string provider failures (historical defect).
  for err in ['rate_limit','authentication_failed','billing_error','server_error','overloaded']:
   rc,o,_=run(d,{'session_id':sid,'hook_event_name':'StopFailure','error':err})
   st=json.loads((d/f'{sid}.status.json').read_text()); check('provider:'+err,st['state']=='STOP',str(st))
   run(d,{'session_id':sid,'hook_event_name':'UserPromptSubmit','prompt':'/gcae-enterprise-assurance-risk:restart'})
  run(d,{'session_id':sid,'hook_event_name':'UserPromptSubmit','prompt':'Continue the runtime build and testing task.'})
  print('after1',flush=True)
  # 2 false-positive immunity: content contains 429 / usage limit but no error field.
  run(d,{'session_id':sid,'hook_event_name':'PreToolUse','tool_name':'Read','tool_input':{'path':'RM4290.50_usage_limit_notes.txt'}})
  st=json.loads((d/f'{sid}.status.json').read_text()); check('content-token-no-false-stop',st['state']!='STOP',str(st))
  run(d,{'session_id':sid,'hook_event_name':'UserPromptSubmit','prompt':'Continue audit runtime testing and inspect files.'})
  print('after2',flush=True)
  # 3 legitimate episode reset.
  for i in range(2): run(d,{'session_id':sid,'hook_event_name':'PreToolUse','tool_name':'Read','tool_input':{'path':'same.xlsx'}})
  run(d,{'session_id':sid,'hook_event_name':'PostToolUse','tool_response':{'rows':100,'changed':True}})
  for i in range(2): run(d,{'session_id':sid,'hook_event_name':'PreToolUse','tool_name':'Read','tool_input':{'path':'same.xlsx'}})
  st=json.loads((d/f'{sid}.status.json').read_text()); check('episode-reset',st['state']!='STOP',str(st))
  print('after3',flush=True)
  # 4 exact/normalized/cycle.
  for seq,name in [([('A',1)]*3,'exact')]:
   for tool,val in seq: run(d,{'session_id':sid,'hook_event_name':'PreToolUse','tool_name':'Read','tool_input':{'path':f'x{val}'}})
  st=json.loads((d/f'{sid}.status.json').read_text()); check('repeat-stop',st['state']=='STOP',str(st)); run(d,{'session_id':sid,'hook_event_name':'UserPromptSubmit','prompt':'/gcae-enterprise-assurance-risk:restart'})
  for x in ['A','B','A','B']:
   run(d,{'session_id':sid,'hook_event_name':'PreToolUse','tool_name':'Read','tool_input':{'path':x}})
  st=json.loads((d/f'{sid}.status.json').read_text()); check('cycle-stop',st['state']=='STOP',str(st)); run(d,{'session_id':sid,'hook_event_name':'UserPromptSubmit','prompt':'/gcae-enterprise-assurance-risk:restart'})
  run(d,{'session_id':sid,'hook_event_name':'UserPromptSubmit','prompt':'Continue testing the runtime build.'})
  print('after4',flush=True)
  # 5 scope and destructive tools.
  run(d,{'session_id':sid,'hook_event_name':'PreToolUse','tool_name':'Delete','tool_input':{'path':'x'}})
  st=json.loads((d/f'{sid}.status.json').read_text()); check('destructive-block',st['state']=='STOP',str(st)); run(d,{'session_id':sid,'hook_event_name':'UserPromptSubmit','prompt':'/gcae-enterprise-assurance-risk:restart'})
  run(d,{'session_id':sid,'hook_event_name':'UserPromptSubmit','prompt':'Continue testing the runtime build.'})
  print('after5',flush=True)
  # 6 depth and agent limits.
  for depth in [3]: run(d,{'session_id':sid,'hook_event_name':'PreToolUse','tool_name':'Task','tool_input':{'description':'x'},'delegation_depth':depth})
  st=json.loads((d/f'{sid}.status.json').read_text()); check('depth-stop',st['state']=='STOP',str(st)); run(d,{'session_id':sid,'hook_event_name':'UserPromptSubmit','prompt':'/gcae-enterprise-assurance-risk:restart'})
  for i in range(6): run(d,{'session_id':sid,'hook_event_name':'SubagentStart','agent_id':str(i),'delegation_depth':1})
  st=json.loads((d/f'{sid}.status.json').read_text()); check('agent-stop',st['state']=='STOP',str(st)); run(d,{'session_id':sid,'hook_event_name':'UserPromptSubmit','prompt':'/gcae-enterprise-assurance-risk:restart'})
  print('after6',flush=True)
  # 7 malformed input fail closed.
  e=os.environ.copy();e['GCAE_RUNTIME_DIR']=str(d)
  p=subprocess.run(['python',str(HOOK)],input='not-json\n',text=True,capture_output=True,env=e); check('malformed-stop',p.returncode!=0 and 'INVALID_HOOK_INPUT' in p.stdout,p.stdout)
  print('after7',flush=True)
  # 8 status after STOP is read-only; no restart.
  run(d,{'session_id':sid,'hook_event_name':'UserPromptSubmit','prompt':'/gcae-enterprise-assurance-risk:restart'})
  run(d,{'session_id':sid,'hook_event_name':'PreToolUse','tool_name':'Delete','tool_input':{'path':'x'}})
  run(d,{'session_id':sid,'hook_event_name':'UserPromptSubmit','prompt':'/status'})
  st=json.loads((d/f'{sid}.status.json').read_text()); check('status-read-only',st['state']=='STOP',str(st))
  run(d,{'session_id':sid,'hook_event_name':'UserPromptSubmit','prompt':'Continue testing the runtime build and inspect files.'})
  print('after8',flush=True)
  # 9 concurrency: independent processes against one session.
  run(d,{'session_id':sid,'hook_event_name':'UserPromptSubmit','prompt':'/gcae-enterprise-assurance-risk:restart'})
  import concurrent.futures
  payloads=[{'session_id':sid,'hook_event_name':'PreToolUse','tool_name':'Read','tool_input':{'path':f'f{i}.txt'}} for i in range(30)]
  with concurrent.futures.ThreadPoolExecutor(max_workers=10) as ex:list(ex.map(lambda x:run(d,x),payloads))
  st=json.loads((d/f'{sid}.status.json').read_text()); check('concurrency-integrity',0<=st['tool_count']<=60 and st['state'] in {'RUNNING','AMBER','STOP'},str(st))
 print(json.dumps({'suite':'GCAE v14.5.0-rc1 max hook simulation','passed':len(PASS),'failed':len(FAIL),'failures':FAIL},indent=2))
 raise SystemExit(1 if FAIL else 0)
if __name__=='__main__':main()
