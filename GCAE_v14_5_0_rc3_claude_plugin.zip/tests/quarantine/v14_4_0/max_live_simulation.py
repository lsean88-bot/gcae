#!/usr/bin/env python3
"""Maximum hook simulation: full hook logic in-process + real subprocess smoke tests.
Not a substitute for actual Claude Code target-runtime UAT."""
from pathlib import Path
import sys
sys.dont_write_bytecode=True
import subprocess,json,tempfile,os,io,contextlib,importlib.util
ROOT=Path(__file__).resolve().parents[2]; HOOK=ROOT/'hooks/telemetry_hook.py'; PASS=[]; FAIL=[]
spec=importlib.util.spec_from_file_location('gcae_hook',HOOK); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
def run(d,payload):
 os.environ['GCAE_RUNTIME_DIR']=str(d); old=sys.stdin if False else None
 import sys
 inp=io.StringIO(json.dumps(payload)+'\n'); out=io.StringIO()
 oldin=sys.stdin;sys.stdin=inp
 try:
  with contextlib.redirect_stdout(out): rc=mod.main()
 finally: sys.stdin=oldin
 txt=out.getvalue().strip(); return rc,(json.loads(txt) if txt else {}),''
def proc(d,payload):
 e=os.environ.copy();e['GCAE_RUNTIME_DIR']=str(d)
 p=subprocess.run(['python',str(HOOK)],input=json.dumps(payload)+'\n',text=True,capture_output=True,env=e,timeout=12)
 return p.returncode,p.stdout,p.stderr
def state(d,s='MAXSIM'):return json.loads((d/f'{s}.status.json').read_text())
def ck(n,c,x=''): (PASS if c else FAIL).append((n,x))
def prompt(d,text): run(d,{'session_id':'MAXSIM','hook_event_name':'UserPromptSubmit','prompt':text})
def restart(d): run(d,{'session_id':'MAXSIM','hook_event_name':'UserPromptSubmit','prompt':'/gcae-enterprise-assurance-risk:restart'}); prompt(d,'Continue the approved runtime build and testing task.')
def main():
 with tempfile.TemporaryDirectory(prefix='gcae1440-') as td:
  d=Path(td); prompt(d,'Build, test, debug and package the GCAE runtime with audit evidence.')
  # Provider exact enums.
  for err in ['rate_limit','authentication_failed','billing_error','server_error','overloaded']:
   run(d,{'session_id':'MAXSIM','hook_event_name':'StopFailure','error':err}); ck('provider:'+err,state(d)['state']=='STOP',str(state(d))); restart(d)
  # False positive immunity.
  run(d,{'session_id':'MAXSIM','hook_event_name':'PreToolUse','tool_name':'Read','tool_input':{'path':'RM4290.50_usage_limit_notes.txt'}}); ck('no-content-token-stop',state(d)['state']!='STOP',str(state(d)))
  # Episode reset.
  for _ in range(2):run(d,{'session_id':'MAXSIM','hook_event_name':'PreToolUse','tool_name':'Read','tool_input':{'path':'same.xlsx'}})
  run(d,{'session_id':'MAXSIM','hook_event_name':'PostToolUse','tool_response':{'rows':100,'changed':True}})
  for _ in range(2):run(d,{'session_id':'MAXSIM','hook_event_name':'PreToolUse','tool_name':'Read','tool_input':{'path':'same.xlsx'}})
  ck('episode-reset',state(d)['state']!='STOP',str(state(d)))
  # Exact and cycle.
  for _ in range(3):run(d,{'session_id':'MAXSIM','hook_event_name':'PreToolUse','tool_name':'Read','tool_input':{'path':'repeat.xlsx'}})
  ck('exact-repeat-stop',state(d)['state']=='STOP',str(state(d)));restart(d)
  for x in ['A','B','A','B']:run(d,{'session_id':'MAXSIM','hook_event_name':'PreToolUse','tool_name':'Read','tool_input':{'path':x}})
  ck('cycle-stop',state(d)['state']=='STOP',str(state(d)));restart(d)
  # Scope, delegation and depth.
  run(d,{'session_id':'MAXSIM','hook_event_name':'PreToolUse','tool_name':'Delete','tool_input':{'path':'x'}});ck('destructive-stop',state(d)['state']=='STOP',str(state(d)));restart(d)
  for i in range(5):run(d,{'session_id':'MAXSIM','hook_event_name':'PreToolUse','tool_name':'Task','tool_input':{'description':f'specialist-{i}'},'delegation_depth':1})
  ck('five-agents-allowed',state(d)['state']!='STOP',str(state(d)))
  run(d,{'session_id':'MAXSIM','hook_event_name':'PreToolUse','tool_name':'Task','tool_input':{'description':'sixth'},'delegation_depth':1});ck('sixth-agent-stop',state(d)['state']=='STOP',str(state(d)));restart(d)
  run(d,{'session_id':'MAXSIM','hook_event_name':'PreToolUse','tool_name':'Task','tool_input':{'description':'too deep'},'delegation_depth':3});ck('depth-stop',state(d)['state']=='STOP',str(state(d)));restart(d)
  # Corrupt state and malformed input fail closed.
  e=os.environ.copy();e['GCAE_RUNTIME_DIR']=str(d)
  (d/'MAXSIM.status.json').write_text('{bad');pout=proc(d,{'session_id':'MAXSIM','hook_event_name':'PreToolUse','tool_name':'Read','tool_input':{'path':'x'}});ck('corrupt-state-stop',pout[0]!=0 and 'STATUS_STATE_CORRUPT' in pout[1],pout[1])
  pm=subprocess.run(['python',str(HOOK)],input='not-json\n',text=True,capture_output=True,env=e,timeout=12);ck('malformed-stop',pm.returncode!=0 and 'INVALID_HOOK_INPUT' in pm.stdout,pm.stdout)
  # Real subprocess smoke: valid prompt, provider failure, restart.
  d2=Path(td)/'subprocess';d2.mkdir();
  rc,out,_=proc(d2,{'session_id':'LIVE-SMOKE','hook_event_name':'UserPromptSubmit','prompt':'Test the runtime package.'});ck('subprocess-prompt',rc==0,(out))
  rc,out,_=proc(d2,{'session_id':'LIVE-SMOKE','hook_event_name':'StopFailure','error':{'code':'rate_limit'}});ck('subprocess-provider',rc==0,'')
  rc,out,_=proc(d2,{'session_id':'LIVE-SMOKE','hook_event_name':'UserPromptSubmit','prompt':'/gcae-enterprise-assurance-risk:restart'});ck('subprocess-restart',rc==0 and 'HUMAN RESTART' in out,out)
 print(json.dumps({'suite':'GCAE v14.4.0 maximum hook/process simulation','passed':len(PASS),'failed':len(FAIL),'failures':FAIL},indent=2)); raise SystemExit(1 if FAIL else 0)
if __name__=='__main__':main()
