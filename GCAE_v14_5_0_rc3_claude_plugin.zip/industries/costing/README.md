# Manufacturing Costing Library

Cost stack: direct material + direct labour + machine + energy + tooling + manufacturing overhead + scrap/yield + rework + logistics/other relevant costs.

Compare: standard vs actual; quote vs actual; budget vs actual; prior period vs current; customer price vs cost; contribution and gross margin.
