# Gas Cylinder Manufacturing Library

Process map: material → forming/drawing → welding/joining → heat treatment → testing → finishing → certification/traceability → dispatch.

Audit lenses: material traceability, wall dimensions, weld integrity, heat treatment, hydro/pressure/leak testing, rejection, safety, certification, production yield, maintenance and cost.
