# Tooling Library

Lifecycle: requirement → design → quotation → supplier selection → manufacture → trial/validation → production use → maintenance/modification → retirement.

Audit lenses: ownership, custody, price benchmarking, supplier conflicts, variations, engineering changes, tool life, repair, utilisation, capitalisation, amortisation and obsolete tooling.
