# Die Casting Industry Library

Process map: melt/material preparation → injection/casting → cooling/ejection → trimming → finishing → inspection → packing.

Audit lenses: material yield, shot weight, cycle time, machine availability, die life, porosity/defects, scrap/rework, energy, OEE, traceability, customer specifications, maintenance, tooling and cost.
