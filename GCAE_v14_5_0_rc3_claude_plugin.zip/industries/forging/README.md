# Forging Industry Library

Process map: billet receipt → heating → forming/forging → trimming → heat treatment → machining/finishing → inspection.

Audit lenses: billet yield, heating efficiency, die life, flash, rejection, heat-treatment controls, traceability, cycle time, energy, capacity, quality and cost.
