# Metal Stamping Industry Library

Process map: coil/sheet receipt → slitting/blanking → press/stamping/forming → inspection → secondary operations → packing.

Audit lenses: press capacity, tonnage, cycle, die condition/life, material utilisation, scrap, setup/changeover, quality, traceability, production scheduling, OEE and cost.
