# Assembly Industry Library

Process map: material/kitting → line feeding → assembly → in-process checks → end-of-line test → packing/shipping.

Audit lenses: takt/cycle, line balance, bottleneck, standard work, manpower, poka-yoke, FPY, rework, WIP, shortages, traceability, downtime and customer quality.
