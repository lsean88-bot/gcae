# Kidney Dialysis Operations Library

Operational chain: appointment → attendance/no-show → treatment start/completion → consumable issue/use → treatment record → billing → revenue → receivable → cash.

Audit lenses: DIMS/system integrity, patient/treatment reconciliation, consumable theoretical usage, physical counts, wastage, billing completeness/duplication, licensing, privacy, clinical governance, procurement and debtor/creditor reconciliation.

Clinical decisions must remain with qualified clinical professionals and applicable regulators.
