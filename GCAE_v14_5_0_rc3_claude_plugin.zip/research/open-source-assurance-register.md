# GCAE Open-Source Assurance & Risk Research Register
Research date: 2026-10-03

| Repository | Primary capability | GCAE relevance | Disposition | Key lesson |
|---|---|---|---|---|
| xactasolutionsai/grc | GRC, audit universe, workpapers, risk, controls, evidence, dashboards, local AI | Very high | ADAPT | Structured audit/GRC object relationships and evidence/workpaper architecture; AGPL-3.0 code reuse requires review |
| Kirk-KV/AuditFlow | Reproducible data-driven audit engagements | Very high | ADAPT | Risk→Control→Test→Evidence→Result→Observation→Action→Report and traceability validation |
| dogukancihanbeyoglu/auditai | Configurable controls, exception testing, alerts, scheduled analytics | Very high | ADAPT | Deterministic rule engine, scheduled testing and audit-event history |
| Ankit-Uniyal/grc-automation-toolkit | Audit universe, risk planning, reproducible sampling, finding/CAPA sync | Very high | ADAPT | Seeded sampling, workpaper completeness and central action register |
| intuitem/ciso-assistant-community | Mature GRC: risk, audit, evidence, controls, TPRM, BIA, remediation, quality checks | Very high | INSPIRE/ADAPT | Separate frameworks from controls; reusable mappings; standing quality checks; AGPLv3/community vs commercial boundaries |
| Marc-Dvci/AssuranceOS | AI-native multi-agent internal audit | High | INSPIRE/WATCH | Multi-agent audit direction; maturity/security/evaluation must be verified before dependency |
| casarezaz/grc-engineering-toolkit | Risk register, heatmaps, compliance metrics, audit readiness | High | INSPIRE | Simple measurable GRC dashboards |
| Nimesh-Tharaka/lean-asset-risk-engine-Dashboard- | Manufacturing risk intelligence | Very high | ADAPT | Plant KPI → risk → health dashboard |
| nawwarah-analyst/ehs-safety-intelligence | EHS analytics | High | ADAPT | Incident × training × audit linkage and data-quality pipeline |
| Bobby10105/OpenWorkpaper | Audit lifecycle, sign-off, collaboration, export, backup | High | INSPIRE | Workpaper lifecycle and portability |
| Ricky-7-Yan/intelligent-audit-system | Evidence-grounded AI agents, human review, evaluation | High | WATCH/INSPIRE | Agent evaluation and human-in-loop patterns |
| anirudhnshandilya/auditpilot | AI compliance, evidence intelligence, control mapping, CAPA | Medium-high | WATCH | Evidence/control mapping pattern; maturity to validate |
| ifixai-ai/iFixAi | AI-agent auditing/evaluation | High | INSPIRE/WATCH | AI systems become an auditable domain |

All external repositories require current licence/security/maintenance verification before any code reuse.
