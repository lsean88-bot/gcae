# GCAE Open-Source Capability Benchmark — 2026-10-03

## Executive conclusion
No single public repository covers the complete GCAE responsibility. Retain the GCAE OS as the governing architecture and selectively absorb proven patterns.

## Xacta GRC
Provides audit universe/entity hierarchy, audit planning, engagements, checklists, workpapers, review/approval, controls, evidence, risk scenarios and dashboards, plus optional local Ollama AI. The repository is AGPL-3.0. Adopt the data-model and evidence/workpaper concepts, not the application as the GCAE reasoning layer.

## AuditFlow
Provides a transparent reproducible audit workspace using YAML for structured facts/relationships, Markdown/QMD for narrative, Python/SQL for analysis and Git/Quarto for review/rendering. Its chain is Risk→Control→Test→Evidence→Result→Observation→Action→Report. It states that validation covers structure/traceability, not evidence sufficiency or conclusion quality, and identifies itself as alpha-stage. MIT licensed. Adopt evidence lineage and reproducibility concepts.

## AuditAI
A privacy-safe internal-audit analytics prototype with bounded data ingestion, deterministic rules, scheduled runs, alerts, audit events and automated tests. Treat as research, not production dependency. Adopt deterministic continuous-control testing patterns.

## GRC Automation Toolkit
Demonstrates risk-scored audit-universe planning, reproducible seeded sampling, workpaper completeness and central finding/CAPA synchronization. Adopt these controls into the CAE office and fieldwork architecture.

## CISO Assistant Community
A mature open-source GRC platform covering risk, compliance/audit, evidence, controls, TPRM, BIA, remediation and analytics. Its model separates compliance requirements from applied controls and provides reusable mappings and standing “X-rays” quality checks. Community code is AGPLv3; commercial enterprise material is separately licensed. Adopt object-model and QA concepts; do not copy commercial code.

## AssuranceOS / AI-native audit projects
Useful as architectural direction for multi-agent, evidence-grounded and human-reviewed audit workflows. Keep as INSPIRE/WATCH until runtime maturity, security and evaluation are independently established.

## Manufacturing and EHS intelligence
Manufacturing risk dashboards demonstrate KPI-to-risk transformation. EHS intelligence demonstrates raw messy data → warehouse → risk/KPI model → executive dashboard, including incident/training/audit relationships. Adopt the analytical patterns, not unverified thresholds.

## OpenWorkpaper
Useful lifecycle, sign-off, collaboration, export and backup patterns. It should not replace the GCAE reasoning/evidence architecture.

## New v9.1 capabilities
- Agent 41: Open-Source Assurance Research
- Agent 42: Evidence Lineage & Reproducible Audit Analytics
- Agent 43: GRC Data & Control Architecture
- Agent 44: AI Agent Assurance & Governance

## Strategic conclusion
The external ecosystem validates the GCAE direction but shows that the differentiator should be the integration of independent assurance, Chairman advisory, risk intelligence, specialist operational knowledge, evidence discipline, adaptive agent architecture and continuous improvement—not simply another GRC application.


## v12.1 verified integration research — 2026-10-05

- Anthropic Agent SDK Python provides lifecycle hooks including PreToolUse and related controls; see official repository.
- Langfuse tracks usage and cost by model/use case and supports alerts and metrics queries.
- LiteLLM supports provider/model/tag budgets and budget-aware routing; its documentation warns that usage-based routing can add latency.
- LiteLLM documents effort ladders as a routing dimension and recommends exhausting cheaper effort tiers before moving to a more expensive model where appropriate.
- Anthropic Agent SDK has an open issue documenting nested-agent budget-limit behaviour; GCAE therefore treats nested budget enforcement as a mandatory runtime UAT item rather than an assumed control.
