# External Research Library

Benchmark reports and the controlled research register for external repositories and public technical projects relevant to GCAE capabilities. Research is evidence for architecture decisions, not authoritative professional guidance.
