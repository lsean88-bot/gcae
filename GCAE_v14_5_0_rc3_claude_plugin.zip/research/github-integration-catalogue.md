# GitHub / Open-Source Integration Catalogue

Research date: 2026-10-04

## Integration rule

These repositories are external research assets. Do not copy their code, prompts or configuration into the GCAE skill merely because they are useful. First check licence, security, dependency risk, maintenance, data handling, deployment requirements and compatibility with the GCAE evidence/independence model.

### Disposition classes
- ADAPT: adopt the architectural pattern into GCAE; no code dependency.
- INSPIRE: use design ideas only.
- WATCH: monitor maturity; no integration yet.
- RUNTIME: potentially run separately and connect through controlled APIs/files/tools.
- CLAUDE-DIRECT: repository contains Claude-specific plugin/skills structures that may be inspectable for adaptation.

| Repository | URL | Capability | Licence / boundary | Disposition | Claude integration path |
|---|---|---|---|---|---|
| Xacta GRC | https://github.com/xactasolutionsai/grc | Audit universe, engagements, controls, evidence, workpapers, dashboards | AGPL-3.0 per repository | ADAPT / RUNTIME | Study object model; do not paste application code into skill |
| AuditFlow | https://github.com/Kirk-KV/AuditFlow | Reproducible audit engagements, evidence lineage, Python/SQL analysis | MIT | ADAPT / RUNTIME | Strong candidate for local analytical workflow; expose outputs to Claude as files |
| AuditAI | https://github.com/dogukancihanbeyoglu/auditai | Deterministic audit analytics, exceptions, scheduled tests | Research prototype; verify current licence before reuse | WATCH / ADAPT | Extract rule/testing patterns; do not assume production readiness |
| GRC Automation Toolkit | https://github.com/Ankit-Uniyal/grc-automation-toolkit | Risk-based planning, sampling, workpaper/CAPA automation | Verify current licence before reuse | ADAPT | Use concepts in CAE planning/analytics |
| CISO Assistant Community | https://github.com/intuitem/ciso-assistant-community | GRC, audit, evidence, controls, TPRM, BIA, mappings, reporting | Community code AGPLv3; enterprise directory commercial | INSPIRE / RUNTIME | Potential standalone GRC runtime; never mix enterprise code into open-source integration |
| AssuranceOS | https://github.com/Marc-Dvci/AssuranceOS | AI-native/multi-agent audit architecture | Verify current licence/status before reuse | INSPIRE / WATCH | Study orchestration only until independently validated |
| GRC Engineering Toolkit | https://github.com/casarezaz/grc-engineering-toolkit | Risk register, heatmaps, controls, compliance dashboards | Verify current licence before reuse | INSPIRE / RUNTIME | Useful standalone HTML dashboard patterns |
| Manufacturing Risk Dashboard | https://github.com/Nimesh-Tharaka/lean-asset-risk-engine-Dashboard- | Plant risk, KPI, heatmaps, operational health | Verify current licence before reuse | ADAPT / RUNTIME | Power BI reference; integrate data outputs, not code into skill |
| EHS Safety Intelligence | https://github.com/nawwarah-analyst/ehs-safety-intelligence | EHS incident/audit/training/risk analytics | Verify current licence before reuse | ADAPT | Adopt data-quality and KPI-risk patterns |
| OpenWorkpaper | https://github.com/Bobby10105/OpenWorkpaper | Audit lifecycle, sign-off, collaboration, export | Verify current licence before reuse | INSPIRE / RUNTIME | Possible standalone workpaper application |
| Intelligent Audit System / AuditPilot | https://github.com/Ricky-7-Yan/intelligent-audit-system | Agent runtime, evidence graph, evaluation harness, human review, MCP-style tools | Apache-2.0 shown by repository | ADAPT / INSPIRE | Strong architecture reference for agent evaluation and evidence graph |
| AuditPilot | https://github.com/anirudhnshandilya/auditpilot | Evidence intelligence, control mapping, CAPA, compliance | Apache-2.0 shown by repository | WATCH / INSPIRE | Study evidence/control mapping |
| iFixAi | https://github.com/ifixai-ai/iFixAi | Independent auditing/evaluation of AI agents | Apache-2.0 shown by repository | INSPIRE / CLAUDE-DIRECT candidate | Study plugin/agent-audit structure; do not assume self-audit proves assurance |

## Download / acquisition

GitHub repositories should be obtained from their official repository page or tagged release. Prefer a tagged release over an unpinned main branch for reproducibility. CISO Assistant explicitly warns against using its main branch directly for production and recommends stable tags/releases. See its official release page.

For local acquisition, use the included `scripts/download_github_repos.ps1` or `scripts/download_github_repos.sh`. These scripts clone the pinned/default branch into a separate research workspace; they do not modify the GCAE skill.

## Claude integration distinction

1. **Skill integration:** Markdown/YAML/skill instructions that Claude can load as a capability.
2. **Tool integration:** A local or hosted application exposed through a supported connector/MCP/API/tool boundary.
3. **Knowledge integration:** Extracted documentation, schemas, control libraries or synthetic examples added to the GCAE knowledge layer after review.
4. **Analytics integration:** Python/SQL/Power BI/HTML workflows run externally and passed into Claude as evidence/results.
5. **Application integration:** A complete GRC/audit application operated independently from the Claude skill.

Do not treat an entire GitHub application as a Claude Skill.
