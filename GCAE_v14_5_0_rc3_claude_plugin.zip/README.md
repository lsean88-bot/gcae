# GCAE Enterprise Assurance & Risk — Claude Code plugin 14.5.0-rc3

**Release candidate. Not production accepted.** Consolidates the v14.4.0 package with a fail-closed, evidence-grade runtime guard and fixes the defects found when v14.4.0 was run (see `docs/V14_5_0_CONSOLIDATION_REPORT.md`).

## Start here
0. `core/IRON_RULES.md` — 15 non-waivable rules, each mapped to its enforcement, stop reasons, tests, mutants and live-UAT stage (a test fails the build if a rule loses its proof).
1. `docs/CLAUDE_INSTALL_AND_UAT.md` — prerequisites (Python 3.8+, Git Bash on Windows), install, commands, troubleshooting.
2. `tests/live-runtime/LIVE_UAT_T0_T16.md` — the live UAT protocol and evidence package.
3. `docs/V14_5_0_CONSOLIDATION_REPORT.md` — defects, SWOT, control traceability, decisions, action plan, measured results.

## Layout
- `hooks/` — `gcae_guard.py` (single runtime authority), `hooks.json` (one handler per event), `run_guard.sh` (fail-closed launcher).
- `core/policy/execution-thresholds.json` — single policy authority (YAML files are verified views). `core/output-templates.md` — review templates for behavioural controls.
- `runtime/` — router, dependency closure, provider adapter (executed by the guard); `controller.py` and `openai_agents/` are reference models, not enforcement.
- `skills/` — 11 skills (adds the human-only `scope` control); each starts with the fail-closed preflight.
- `agents/`, `references/`, `capability-registry.yaml`, `core/` — preserved v14.4.0 content base (100 capabilities, 45 agents).
- `tools/` — `grade_uat.py` (log-driven grader), `collect_evidence.sh`, `build_hashes.py`.
- `tests/` — `run_all.py` (authoritative runner; fails on zero collected tests), `guard/` (suite, grader tests, invariants, UAT routing, mutation harnesses), preserved legacy suites, `quarantine/`.

## Lockout safety
A guard fault or a missing Python never blocks the human's own message (tool calls are blocked instead). Loop, tool, agent, failure and reference budgets bound ONE instruction and reset on the next; a restart is always possible with either `/gcae-enterprise-assurance-risk:restart` or the explicit sentence. See `docs/CLAUDE_INSTALL_AND_UAT.md`.

## Human commands
`/gcae-enterprise-assurance-risk:status` · `/gcae-enterprise-assurance-risk:restart` (alone, after a STOP) · `/gcae-enterprise-assurance-risk:scope approve|decline` (alone, when scope is held).

## Verify before live UAT
`python3 tests/run_all.py`, `python3 tests/guard/mutate_guard.py` (no survivors) and `python3 tests/guard/fuzz_guard.py --seeds 1500 --steps 70` (zero violations). Production acceptance requires the live Claude Code UAT.
