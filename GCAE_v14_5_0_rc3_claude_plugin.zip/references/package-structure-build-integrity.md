---
id: REF-041
version: 11.2.1
status: active
type: reference
name: package-structure-build-integrity
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Package Structure & Reproducible Build Integrity.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Package Structure & Reproducible Build Integrity

The package structure is itself a controlled assurance object.

## Structural rules
- one canonical capability registry; derived routing/plugin/test indexes must reconcile to it;
- production paths are explicitly classified; historical material is quarantined;
- generated runtime artifacts such as `__pycache__`, `.pyc`, temporary files and editor metadata are prohibited;
- required files and directories are checked before release;
- archive paths must be relative, unique and free of traversal or absolute-path components;
- package content hashing must be deterministic before and after QA execution;
- self-referential manifest fields are excluded only through an explicit documented rule;
- version, counts and status must reconcile across control-plane documents;
- source test suites generate the derived test registry and oracle index;
- a release cannot be promoted solely because its own manifest declares PASS.

## Reproducibility gate
Run structural QA, generate derived indexes, freeze source content, compute the content hash, run QA with bytecode generation disabled, and recompute the hash. Any change is a release failure requiring investigation.
