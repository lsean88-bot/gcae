---
id: REF-040
version: 11.2.1
status: active
type: reference
name: financial-exposure-containment
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Financial Exposure, Recovery & Investigation Containment.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Financial Exposure, Recovery & Investigation Containment

Financial impact must be assessed separately from the existence of a conflict or misconduct.

## Exposure ladder
1. Observed variance
2. Potential exposure
3. Quantified exposure
4. Corroborated loss
5. Confirmed recoverable / irrecoverable loss

Do not label an allegation as financial loss merely because a relationship exists. Conversely, absence of quantified loss does not by itself eliminate a conflict-of-interest or control concern.

## Quantification
Identify gross value, incremental cost/benefit, avoided cost, overpayment, duplicate payment, margin impact, recovery potential, remediation cost and relevant time period. Reconcile source populations and document assumptions.

## Containment
Containment is a risk-management action, not a finding. Possible safeguards include segregation, dual approval, temporary recusal, independent review, access restriction, enhanced monitoring, evidence preservation and controlled reassignment. Avoid irreversible personnel or commercial actions before facts are sufficiently established unless an immediate legal, safety, security or financial risk requires them.
