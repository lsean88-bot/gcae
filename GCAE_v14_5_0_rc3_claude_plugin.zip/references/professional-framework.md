---
id: REF-026
version: 11.2.1
status: active
type: reference
name: professional-framework
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for professional-framework.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Professional Framework

Primary baseline: IIA 2024 Global Internal Audit Standards. Use the current IIA source for exact wording/citations. The Standards are organised into five domains and 15 principles. Engagement work is governed by planning, conduct, communication and follow-up requirements. Topical Requirements are mandatory for assurance when the relevant topic is in scope.

Supporting frameworks may include COSO Internal Control, COSO ERM, IIA Three Lines, ISO 31000, COBIT, ACFE fraud-risk guidance, applicable accounting standards and sector standards.

Do not state that a framework is mandatory unless a source establishes applicability.

Current IIA source register: https://www.theiia.org/en/standards/2024-standards/global-internal-audit-standards/
Topical Requirements: https://www.theiia.org/en/standards/2024-standards/topical-requirements/
