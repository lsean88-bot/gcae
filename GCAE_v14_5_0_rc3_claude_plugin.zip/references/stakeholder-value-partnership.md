---
id: REF-034
version: 11.2.1
status: active
type: reference
name: stakeholder-value-partnership
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for stakeholder-value-partnership.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Stakeholder Value Partnership

Stakeholder universe: governing body; Chairman; CEO/EXCO; CFO/Finance/Treasury/Tax; COO/Operations; BU/plant leadership; Risk/ERM; Compliance; Legal; HR; IT/Cyber; Quality/EHS; Procurement/Supply Chain; Sales/Commercial; employees/whistleblowers; external auditors; advisers; regulators; customers; suppliers; lenders/investors/shareholders; other assurance providers.

Engagement model: Understand → Challenge → Advise → Assure → Follow Through.

Every material stakeholder plan should define objective, authority, information need, cadence, confidentiality, escalation, independence threat, expected value and feedback method.
