---
id: REF-012
version: 11.2.1
status: active
type: reference
name: financial-models
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for financial-models.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Financial Intelligence Models

Core model chain:
P&L ↔ Balance Sheet ↔ Cash Flow.

Diagnostics:
- revenue volume × price × mix
- gross margin bridge
- EBITDA bridge
- material/labour/overhead variance
- working capital: DSO, DPO, inventory days, cash conversion cycle
- capex: spend, commissioning, utilisation, ROI/ROIC where relevant
- forecast: base/upside/downside and sensitivity
- liquidity and covenant analysis where applicable

Model controls:
source-data reconciliation, assumption register, formula integrity, sign convention, period cut-off, intercompany elimination, FX treatment, accounting policy consistency, sensitivity and independent reasonableness check.
