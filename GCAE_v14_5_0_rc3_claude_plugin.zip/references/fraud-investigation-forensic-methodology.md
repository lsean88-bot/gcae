---
id: REF-039
version: 11.2.1
status: active
type: reference
name: fraud-investigation-forensic-methodology
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Forensic Fraud & Conflict Investigation Methodology.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Forensic Fraud & Conflict Investigation Methodology

Use for allegations, conflicts of interest, related parties, nominee relationships, vendor/customer nexus, suspected preferential treatment, transaction schemes and investigative fact patterns.

## Investigation model

TRIGGER → PRESERVE → CLASSIFY → HYPOTHESISE → MAP RELATIONSHIPS → RECONSTRUCT CHRONOLOGY → TEST POPULATION → CORROBORATE → QUANTIFY → CONTAIN → CONCLUDE → REPORT.

### Evidence ladder
Control weakness → Indicator → Suspicion → Allegation → Corroborated evidence → Substantiated conclusion.

An anomaly, analytics result, management denial, witness statement or document is not independently conclusive without assessing reliability, completeness, authenticity, corroboration and context.

### Required forensic domains
- beneficial/legal ownership and control; nominee and related-party relationships;
- vendor/customer master data, onboarding, KYC and approval history;
- duplicate invoices/payments, split transactions, round-dollar patterns and unusual timing;
- bank-account, address, telephone, email, employee, director, accountant, device and transaction-network relationships where lawfully available;
- retrospective document creation, metadata, version history and approval chronology;
- communication and interview corroboration;
- population completeness and data lineage;
- chronology from relationship formation through transactions, approvals, delivery, payment and benefit;
- containment decisions kept separate from final investigative conclusions.

### Interview rule
Document source basis, first-hand versus hearsay knowledge, chronology, contradictions, corroborating records and any relevant interest or bias. Do not treat confidence, seniority or consistency alone as proof.
