---
id: REF-007
version: 11.2.1
status: active
type: reference
name: control-plane-and-release-gates
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for control-plane-and-release-gates.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Control Plane & Release Gates

The control plane governs the master skill, routing manifest, capability registry, reference registry, topical-requirement registry, test registry, alert policy and release manifest.

## Mandatory invariants
1. Version equality across release artifacts.
2. Status equality and release-state semantics.
3. Every active production capability is registered and routable.
4. Every registry object resolves to an actual artifact.
5. No orphan active capability or reference.
6. No duplicate IDs globally.
7. No undeclared dependency or dependency cycle.
8. All mandatory agent/reference schemas validate.
9. All critical tests have unique immutable IDs.
10. Runtime behavioural tests are distinguished from test-design records.
11. Package hash is recorded after final build.
12. Any mutation of critical control-plane files triggers full regression.

## Release states
DRAFT → INTERNAL-TEST → RED-TEAM → RELEASE-CANDIDATE → RUNTIME-ACCEPTED → PRODUCTION → DEPRECATED → RETIRED.

Never label a package PRODUCTION or RUNTIME-ACCEPTED based solely on static QA.
