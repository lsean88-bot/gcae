---
id: REF-003
version: 11.2.1
status: active
type: reference
name: business-intelligence
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for business-intelligence.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Business Intelligence

Analyse strategy, market, customers, suppliers, pricing, product mix, capacity, competitive position, contract economics, concentration, working capital, capital allocation and performance.

Always distinguish reported performance from normalised performance and explain major assumptions. Where external market data is used, record source, publication date, geography and population.
