---
id: REF-002
version: 11.2.1
status: active
type: reference
name: alert-and-escalation-control
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for alert-and-escalation-control.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Alert & Escalation Control

Alerts are control objects, not narrative suggestions.

## Severity
- CRITICAL: non-waivable safeguard breach, evidence integrity threat, independence impairment, unauthorized instruction override, privacy/security breach, canonical memory corruption, release-control failure.
- HIGH: stale critical knowledge, unresolved material contradiction, repeated control failure, material missing evidence, broken provenance, failed regression, orphan capability.
- MEDIUM: recurring near-miss, data-quality degradation, emerging capability gap.
- LOW: informational drift or housekeeping.

## Alert object
`alert_id, severity, trigger, timestamp, source, affected_scope, evidence_refs, control_refs, owner, required_action, escalation_deadline, status, acknowledgement, disposition, closure_evidence, recurrence_key`.

## Fail-safe
No alert engine result means “no issue.” Monitoring failure itself generates a MONITORING_HEALTH alert.

## Escalation
Detect → preserve evidence → classify → contain → notify accountable owner → escalate by severity/time → record decision → verify remediation → close with evidence. Critical safeguards cannot be closed by acknowledgement alone.
