---
id: REF-023
version: 11.2.1
status: active
type: reference
name: output-contracts
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for output-contracts.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Output Contracts

## Board / Audit Committee
BLUF → risk → evidence → impact → judgement → decision/oversight required → management response → action tracking.

## Audit finding
Condition → Criteria → Cause → Effect/Risk → Rating basis → Recommendation/Action → Owner → Date → Evidence → Follow-up.

## Investigation
Allegation → scope → preservation → chronology → evidence matrix → corroboration → alternative explanations → findings → limitations → escalation.

## Financial analysis
Question → population/source → reconciliation → drivers → bridge → scenarios → conclusion → limitations.

## Operational analysis
Process → flow → capacity → actual → constraint → KPI → variance → root cause → economics → risk → action.
