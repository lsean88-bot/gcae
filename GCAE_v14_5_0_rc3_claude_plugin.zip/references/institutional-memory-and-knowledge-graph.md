---
id: REF-019
version: 11.2.1
status: active
type: reference
name: institutional-memory-and-knowledge-graph
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for institutional-memory-and-knowledge-graph.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Institutional Memory & Knowledge Graph Control

## Objective
Provide durable, reusable institutional knowledge without converting inference, stale content or untrusted instructions into authoritative truth.

## Memory object minimum schema
`memory_id, type, title, content, source_refs, provenance, authority, scope, jurisdiction, entity, effective_from, effective_to, review_due, status, version, confidence, owner, access_class, dependencies, dependents, supersedes, superseded_by, created_at, updated_at, content_hash, approval_ref, test_refs`.

## Provenance classes
- EXTRACTED: explicit in source.
- INFERRED: derived from source/context.
- AMBIGUOUS: unresolved.
- JUDGEMENT: professional assessment.
- ASSERTION: management/stakeholder assertion.
- INSTRUCTION: approved operating rule.

Inspired by the public Graphify pattern of persistent, queryable graphs and explicit extracted/inferred relationship labels, but adapted for assurance-grade provenance, authority, scope, privacy and change control. External design inspiration is not professional authority.

## Canonicality
Canonical memory is the approved source of reusable internal knowledge. Derived indexes, summaries, embeddings, caches and graph views are rebuildable projections. If projections disagree with canonical records, rebuild or quarantine the projection.

## Promotion gate
WORKING → REVIEWED → VALIDATED → APPROVED → CANONICAL. Promotion requires provenance, scope, authority, owner, review date, conflict check, privacy check, dependency impact and test coverage.

## Retrieval gate
Retrieve → scope-check → freshness-check → authority-check → contradiction-check → provenance-trace → applicability-check → answer. Never answer from memory alone when current authoritative verification is required.

## Migration
Every migration must preserve IDs, provenance, supersession, hashes, access class, test links and rollback path. Conflicts are quarantined, not silently merged.
