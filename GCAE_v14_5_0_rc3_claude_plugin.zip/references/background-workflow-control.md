# Background Workflow Control

## Purpose
Prevent silent progress loops, premature synthesis, version overwrite and unsupported completion claims in long-running multi-agent rebuilds.

## Mandatory state model
A background workflow must maintain explicit states: PLANNED → RUNNING → BUILDER_COMPLETE → QA_COMPLETE → SYNTHESIS_READY → SYNTHESIS_COMPLETE → RECONCILED → RELEASE_READY → COPIED → CLOSED.

## Nine-builder pattern
For a nine-entity rebuild:
1. Create a manifest with exactly nine entity IDs.
2. Each builder writes only to its own new `v2` location.
3. The corresponding QA step is independent of the builder and must inspect the actual builder output, not merely the builder's status message.
4. Group synthesis is blocked until all nine required QA results are present, unless an explicit exception is recorded.

## Evidence gates
- Every material figure must trace to a fact-base source.
- Reconciliation must compare source facts, entity outputs, QA outputs and synthesis.
- A correction is logged to `data/lessons.jsonl` only when an actual correction occurred; a discrepancy alone is not a correction.
- An audit-file check is NOT TRIGGERED when no audit file exists.
- v1 is immutable. No overwrite, rename or in-place repair is permitted.

## Progress / heartbeat anti-misfire
Do not repeatedly emit the same “still running / nothing to log” message. A progress update is valid only when at least one measurable field changes: completed builders, completed QA, current state, files written, error count, reconciliation count or elapsed checkpoint. If nothing changed, remain silent until the next meaningful checkpoint.

## Completion claim
Never claim completion from elapsed time or lack of errors. Completion requires the manifest, v2 file inventory, QA results, reconciliation, hashes and destination verification.

## Copy gate
Copy to a destination only after RELEASE_READY. Generate source/destination manifest and verify hashes after copy.
