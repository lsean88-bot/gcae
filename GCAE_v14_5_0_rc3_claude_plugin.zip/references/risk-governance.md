---
id: REF-031
version: 11.2.1
status: active
type: reference
name: risk-governance
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for risk-governance.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Risk & Governance Model

Assess governance, risk and control separately and then in aggregate.

Risk dimensions: strategic, financial, operational, compliance/legal, fraud, technology/cyber, people, third-party, supply chain, resilience, reputational, country/geopolitical, ESG where applicable.

Risk assessment: inherent risk → response/control → residual risk → appetite/tolerance → velocity → persistence → concentration → interdependency → emerging risk.

Governance questions:
- Who owns the risk?
- Who sets appetite?
- Who monitors?
- Who challenges?
- Who provides independent assurance?
- Is information timely and decision-useful?
- Are exceptions escalated?
- Are accepted risks formally authorised?

Three Lines: management owns and manages; second line supports/challenges/monitors; third line independently assures. Combined roles require explicit independence safeguards.
