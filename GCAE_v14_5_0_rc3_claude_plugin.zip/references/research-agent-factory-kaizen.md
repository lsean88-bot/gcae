---
id: REF-029
version: 11.2.1
status: active
type: reference
name: research-agent-factory-kaizen
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for research-agent-factory-kaizen.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Research, Agent Factory & Kaizen Operating Framework

## Purpose
This module makes the GCAE operating system extensible. It governs how new work, risks, regulations, technologies, recurring requests and lessons learned become controlled capability improvements without uncontrolled agent proliferation.

## Core principle
**Do not predict every future capability. Build a controlled mechanism that discovers, evaluates, creates, tests, integrates, monitors, improves and retires capabilities as work evolves.**

## Capability decision tree
For every new requirement ask, in order:
1. Can an existing agent handle it with no material gap?
2. Is the gap knowledge only? If yes, update/create a reference or knowledge module.
3. Is the gap procedural? If yes, create/update a workflow.
4. Is the gap computational/repetitive? If yes, create/update a tool or script.
5. Is the gap recurring, domain-specific and materially distinct? Consider a new specialist agent.
6. Does the proposed agent duplicate an existing agent? Prefer merge, refactor or routing changes.

## Lifecycle
**DETECT → RESEARCH → GAP-ASSESS → DESIGN → BUILD → UNIT TEST → INTEGRATION TEST → RED-TEAM → QA → REGISTER → RELEASE → MONITOR → K A I Z E N**

### DETECT
Sources include new user requests, repeated tasks, audit findings, failed outputs, new regulations, new industries, new systems, new data types, emerging risks, stakeholder feedback and technology changes.

### RESEARCH
Establish authoritative requirements, domain concepts, recurring patterns, evidence requirements, existing internal capability and applicable constraints. For current law, regulation, standards or software behaviour, verify current primary sources.

### GAP-ASSESS
Document the exact capability gap. Identify affected agents, references, workflows, tests and stakeholders. Estimate materiality and recurrence.

### DESIGN
Define mandate, non-mandate, inputs, outputs, dependencies, routing triggers, evidence requirements, escalation, independence boundaries and failure modes.

### BUILD
Create the smallest sufficient capability. Prefer composability over monolithic agents.

### TEST
Test normal, ambiguous, incomplete, contradictory, multilingual, hostile and boundary cases. Include negative tests proving that unsafe behaviour is rejected.

### INTEGRATION TEST
Check interactions with other agents, references, role hats, evidence rules, jurisdiction routing and output contracts.

### RED-TEAM
Actively attempt to induce hallucination, duplication, role confusion, unsupported conclusions, evidence laundering, legal overreach, management ownership, false precision and instruction conflict.

### QA
Confirm source integrity, naming, metadata, dependency resolution, routing, documentation, test coverage, versioning and regression status.

### REGISTER
Add the capability to the controlled registry with unique ID, version, owner, purpose, dependencies, status, date, evidence basis and review cadence.

### MONITOR
Capture failure modes, usage, usefulness, duplication, stale knowledge and stakeholder feedback.

### KAIZEN
Improve, split, merge, retire or replace capability based on evidence. Do not change production capability merely because of a single stylistic preference; require a defensible improvement case.

## Agent design contract
Every specialist agent must state:
- Purpose
- Trigger conditions
- In-scope work
- Out-of-scope work
- Required inputs
- Evidence standards
- Core analytical models
- Dependencies
- Outputs
- Independence / Three Lines boundaries
- Escalation conditions
- Known failure modes
- QA requirements
- Version and review metadata

## New-agent approval test
A new agent is justified only when at least one is true:
- recurring material work cannot be handled adequately by current capabilities;
- specialist expertise is materially distinct;
- regulatory/industry complexity requires a stable specialist boundary;
- repeated failures show a persistent capability gap;
- orchestration quality materially improves through separation.

A new agent should normally be rejected when it merely repackages an existing agent, duplicates a reference library, or creates a narrow prompt that can be handled by an existing workflow.

## Knowledge lifecycle
Knowledge modules follow:
**Source → Applicability → Capture → Version → Verify → Use → Review → Supersede/Retire**.

Never silently overwrite authoritative requirements. Preserve superseded status and effective dates.

## Kaizen evidence log
Each improvement should record:
- trigger;
- observed problem;
- evidence/examples;
- root cause;
- proposed change;
- alternative options considered;
- risk of change;
- tests added/updated;
- validation result;
- release version;
- owner;
- review date.

## Regression rule
Every material change must rerun:
1. structural validation;
2. routing/dependency checks;
3. affected behavioural tests;
4. relevant hostile tests;
5. independence/role-boundary tests;
6. output-contract tests.

## Agent health states
**ACTIVE** — approved and current.
**PROVISIONAL** — built for testing only.
**DEPRECATED** — retained for backward compatibility but not preferred.
**RETIRED** — no longer routed.
**QUARANTINED** — blocked pending defect investigation.

## No self-authorised production mutation
The operating system may recommend new agents or improvements. Production changes require controlled build, testing, QA and release. It must never silently rewrite its own production instructions during an engagement.
