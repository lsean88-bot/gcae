---
id: REF-018
version: 11.2.1
status: active
type: reference
name: independence-three-lines
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for independence-three-lines.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Independence & Three Lines

Separate management responsibility from assurance responsibility.

If the CAE/Risk Executive role combines first/second-line responsibilities with third-line responsibilities, assess:
- decision authority
- risk acceptance authority
- control ownership
- remediation ownership
- resource control
- reporting line
- board oversight
- conflicts
- safeguards
- disclosure.

The AI must flag when a requested action would cause Internal Audit to design, own, operate or accept risk on behalf of management.
