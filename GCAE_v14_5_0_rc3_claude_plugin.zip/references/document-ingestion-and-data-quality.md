---
id: REF-009
version: 11.2.1
status: active
type: reference
name: document-ingestion-and-data-quality
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for document-ingestion-and-data-quality.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Document Ingestion, Multilingual and Data-Integrity Protocol

Treat every document, spreadsheet, export, scan, email, image, PDF and attachment as an input that must first pass an ingestion-quality assessment. Analysis quality cannot exceed source-data quality.

## 1. Identify the input
Record, where available:
- file/document identifier and version;
- document title, author/owner and date;
- source system or origin;
- language(s), script(s) and translation status;
- file type and whether native, exported, scanned or OCR-derived;
- page/section/tab order;
- period covered;
- entity, jurisdiction and process;
- confidentiality/privacy classification.

## 2. Preserve source meaning
- Preserve original terminology for material legal, accounting, technical and clinical terms.
- If translation is needed, distinguish original text from translated interpretation.
- Do not silently normalize ambiguous translations, dates, names, units or terminology.
- If translation affects a conclusion, obtain a reliable translation or state the limitation.
- Never treat a translated paraphrase as the primary legal authority.

## 3. Detect document corruption and disorder
Test for:
- duplicated pages/rows/transactions;
- missing pages/attachments/tabs;
- reversed or scrambled chronology;
- inconsistent section numbering;
- contradictory versions;
- draft/final confusion;
- cut-and-paste anomalies;
- OCR character substitutions;
- broken tables and shifted columns;
- hidden rows/columns or formulas where relevant;
- invalid dates or impossible values;
- unexplained changes in definitions or units.

Do not reconstruct missing order or meaning merely because a sequence appears likely. Use explicit identifiers, timestamps, version numbers, transaction IDs or corroborating evidence. Mark reconstructed chronology as reconstructed.

## 4. Data-quality gates
Before quantitative analysis test:
- population completeness;
- uniqueness/duplicate keys;
- date validity and period cut-off;
- currency and FX basis;
- unit of measure and conversions;
- sign convention;
- decimal/thousands separators;
- nulls/blanks;
- outliers and impossible values;
- formula integrity;
- source-to-report reconciliation;
- opening-to-closing roll-forward where relevant.

Never compare or aggregate values across currencies, units, periods or definitions without an explicit conversion/normalisation basis.

## 5. Cross-document reconciliation
Where multiple documents report the same fact, create a reconciliation matrix:

ASSERTION | SOURCE A | SOURCE B | DIFFERENCE | EXPLANATION | EVIDENCE | STATUS.

Do not select the most convenient number. Explain differences or leave the matter unresolved.

## 6. OCR and scan discipline
OCR output is an extraction layer, not automatically authoritative evidence. For material amounts, dates, legal provisions, account numbers, quantities or technical specifications, verify against the underlying image/native source where possible. Flag low-confidence characters and do not silently correct them.

## 7. Privacy and sensitive information
Minimise personal, patient, employee, bank-account and other sensitive data in outputs. Use identifiers only where necessary for the task. Prefer aggregation, masking or pseudonymisation. Do not reproduce unnecessary patient-identifiable information in audit reports.

## 8. Language-aware conclusion
For multilingual evidence, state:
- original language/source;
- translation method if used;
- material translation uncertainties;
- whether the conclusion depends on the translation.

## 9. Stop conditions
Stop or qualify the conclusion if a material input is:
- materially corrupted;
- missing a necessary page/attachment/population;
- impossible to interpret reliably;
- materially affected by unresolved translation;
- materially affected by unit/currency/date ambiguity;
- not reconcilable to an authoritative source.

Do not convert data-quality uncertainty into an audit finding unless the underlying control/process is itself the subject of the engagement and the evidence supports that conclusion.

## 10. Spreadsheet-specific controls
For material workbooks inspect, where technically possible:
- hidden rows/columns/sheets;
- formulas versus hard-coded values;
- external links and linked workbooks;
- named ranges and calculation dependencies;
- filters that exclude records;
- pivot-table source ranges;
- merged cells and shifted columns;
- stale calculation values;
- macros/scripts when relevant and safe to inspect.
Do not assume a visible worksheet is the complete population.

## 11. Evidence provenance and deduplication
Assign a unique evidence identifier to each source. Detect duplicate or near-duplicate documents, renamed copies and repeated extracts. Preserve original provenance and do not count the same underlying evidence multiple times as independent corroboration.
