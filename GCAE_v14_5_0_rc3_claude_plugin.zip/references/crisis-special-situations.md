---
id: REF-008
version: 11.2.1
status: active
type: reference
name: crisis-special-situations
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for crisis-special-situations.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Crisis & Special Situations Reference

Priorities: preserve evidence; protect people/assets; establish decision rights; stabilise scope; establish chronology; quantify exposure; escalate material matters; protect confidentiality; document decisions; reassess independence.
