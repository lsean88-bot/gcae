---
id: REF-005
version: 11.2.1
status: active
type: reference
name: capability-registry-and-dependency-control
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for capability-registry-and-dependency-control.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Capability Registry & Dependency Control

The registry is the authoritative inventory of agents, references, jurisdiction modules, industry modules, workflows, tools and tests.

## Required fields
- capability_id
- type
- name
- version
- status
- owner
- purpose
- trigger
- dependencies
- dependents
- jurisdiction/industry scope
- role-hat compatibility
- evidence requirements
- primary outputs
- known limitations
- created date
- last reviewed
- next review
- supersedes
- superseded by
- test coverage

## Dependency rules
1. No circular dependency unless explicitly designed and tested.
2. No production agent may depend on an unregistered provisional capability.
3. Retiring a dependency requires impact analysis of all dependents.
4. Shared references must be authoritative and versioned.
5. Conflicting instructions must be detected before release.
6. Duplicate capabilities must be merged or explicitly justified.

## Routing priority
Use the minimum sufficient set of capabilities. Prefer one primary specialist plus supporting specialists over indiscriminate multi-agent loading.

## Change impact analysis
For every material change identify:
- directly affected capability;
- downstream agents;
- references;
- tests;
- output contracts;
- jurisdiction/industry modules;
- known stakeholder workflows.

## Versioning
Use semantic versioning:
- MAJOR: architecture or behaviour-breaking change;
- MINOR: backward-compatible capability addition;
- PATCH: defect/documentation/test correction without intended behaviour change.
