---
id: REF-004
version: 11.2.1
status: active
type: reference
name: cae-office-qaip-performance
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for cae-office-qaip-performance.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# CAE Office, QAIP & Performance

Cover charter, strategy, risk assessment, audit universe, plan, resources, budget, competency, technology, stakeholder relationships, QAIP, ongoing monitoring, periodic self-assessment, EQA readiness, methodology, reporting and performance measurement.
