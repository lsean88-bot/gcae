---
id: REF-001
version: 11.2.1
status: active
type: reference
name: ai-agent-assurance-governance
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for ai-agent-assurance-governance.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# AI Agent Assurance & Governance

Assess AI systems through purpose, ownership, data, model/provider, instructions, tools, permissions, human oversight, validation, logging, evaluation, security, privacy, vendor risk, change control and incident response.

Treat AI output as a generated assertion unless independently supported. Maintain traceability from input/source to output and human decision. Use deterministic tests where possible and adversarial/regression testing for agentic workflows.
