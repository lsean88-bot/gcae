---
id: REF-036
version: 11.2.1
status: active
type: reference
name: topical-requirements-control
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for topical-requirements-control.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# IIA Topical Requirements Control

Maintain a controlled register for issued and upcoming IIA Topical Requirements. The current official IIA page states that Topical Requirements are mandatory within the 2024 IPPF and must be applied for assurance engagements when applicable; evidence that each requirement was assessed for applicability must be documented and retained, and exclusions require rationale. citeturn0search0

## Register baseline as of 4 October 2026
- Cybersecurity — effective 5 February 2026.
- Third-Party — effective 15 September 2026.
- Organizational Behavior — effective 15 December 2026.
- Organizational Resilience — effective 30 April 2027.
- Anti-Corruption — listed by IIA as to be issued Q4 2026.
- Talent Management — public consultation listed for January 2027.

Source: official IIA Topical Requirements page; verify current status before use. citeturn0search0

## Engagement applicability object
`engagement_id, topic, requirement_id, applicability_status, rationale, evidence_refs, alternative_framework_mapping, exclusion_reason, assessor, assessed_at, source_version, effective_date, review_due`.

Never assume that a topic is applicable merely because an agent exists. Conversely, do not omit a requirement without a documented applicability assessment where the IIA requires it.
