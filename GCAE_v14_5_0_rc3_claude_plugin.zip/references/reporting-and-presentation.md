---
id: REF-028
version: 11.2.1
status: active
type: reference
name: reporting-and-presentation
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for reporting-and-presentation.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Reporting & Presentation Reference

## Professional baseline
The IIA Global Internal Audit Standards require internal audit communications to be accurate, objective, clear, concise, constructive, complete and timely. Standard 11.2 also states that clarity is increased by avoiding unnecessary technical language and using terminology understood by the intended audience. Standard 15.1 requires final engagement communication to include objectives, scope, recommendations/action plans where applicable, conclusions and, for assurance engagements, findings and their significance/prioritization, scope limitations and a conclusion on governance, risk management and control processes. The CAE reviews and approves final engagement communication before issue.

Primary source: IIA, 2024 Global Internal Audit Standards: https://www.theiia.org/en/standards/2024-standards/global-internal-audit-standards/

## Current IIA communication guidance
The IIA issued Global Practice Guide "Communicating Final Engagement Results" in September 2025 and "Communicating Results of Internal Audit Services" in December 2025. These materials address written reports, presentations, engagement conclusions, significance of findings, management action plans and follow-up.

Primary source: https://www.theiia.org/en/content/guidance/recommended/supplemental/practice-guides/communicating-final-engagement-results/
Primary source: https://www.theiia.org/en/content/guidance/recommended/supplemental/practice-guides/communicating-results-of-internal-audit-services/

## Communication standard
Every output should answer, in the appropriate depth:
1. What is the objective?
2. What was reviewed?
3. What did the evidence show?
4. What does it mean for the business / risk / governance?
5. What remains uncertain?
6. What is management doing?
7. What does the audience need to decide, challenge, approve or monitor?

## Human writing standard
Natural professional prose. No fake personality. No fabricated experience. No artificial confidence. No filler. No jargon unless necessary. No unexplained acronyms. No generic management clichés. No repetition of the same conclusion in slightly different words.

## Executive compression
Use progressive disclosure:
- Level 1: one-page executive view.
- Level 2: concise report / presentation narrative.
- Level 3: detailed findings and analysis.
- Level 4: technical evidence / appendices / workpapers.

The executive layer must remain faithful to the detailed evidence.
