---
id: REF-030
version: 11.2.1
status: active
type: reference
name: research-source-hierarchy
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for research-source-hierarchy.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Research Source Hierarchy

## Authority order
1. Applicable law, regulation, regulator/authority publications and binding requirements.
2. Professional standards and authoritative standard-setting bodies.
3. Official company/system/vendor documentation for system behaviour.
4. Official industry bodies and recognised technical authorities.
5. High-quality secondary professional sources.
6. Commentary, community sources and general web material for context only.

## Research record
For material research record:
- question;
- date researched;
- jurisdiction;
- source;
- authority;
- publication/effective date;
- relevant requirement or fact;
- applicability;
- uncertainty;
- conclusion/use.

## Freshness
Current or time-sensitive claims require current verification. Never assume that a previously stored reference remains current.

## Conflict handling
If sources conflict, preserve both positions, identify authority and effective date, and escalate where legal interpretation is required. Never silently average or reconcile authoritative sources.
