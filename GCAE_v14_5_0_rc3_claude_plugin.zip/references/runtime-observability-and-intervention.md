# Runtime Observability and Intervention

## Problem addressed
A controlled workflow that reaches a limit without a visible status message is operationally unacceptable. The user must be able to distinguish RUNNING, AMBER, STALLED, STOPPED and COMPLETED without relying on the model's narrative.

## Required behaviour
1. Every session has a persistent, external status record.
2. Every tool call is counted before execution.
3. Tool-limit and Task/subagent admission breaches are surfaced before the prohibited action executes.
4. Meaningful checkpoints emit concise user-visible status messages.
5. `/gcae-enterprise-assurance-risk:status` is the authoritative read-only status inspection path.
6. Cost/token limits are not claimed as enforced by hook telemetry unless actual provider cost telemetry is available. Unknown cost is `UNKNOWN`, not zero.
7. A hard limit is terminal for the controlled run. The agent must not silently continue or silently disappear.
8. Background workflows must expose their own stage counters and heartbeat; the runtime hook cannot infer builder/QA completion merely from tool activity.

## Limit escalation
- warning threshold: configurable, default 20 of 30 tool calls
- hard tool limit: 30
- hard active-agent admission limit: 5
- on hard limit: deny the next prohibited PreToolUse action and emit a user-visible STOP message with reason and current counters

## Status integrity
Status is observational. It must never be used to manufacture evidence, claim completion, or override substantive QA/reconciliation gates.
