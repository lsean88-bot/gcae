---
id: REF-037
version: 11.2.1
status: active
type: reference
name: writing-style-and-humanity
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for writing-style-and-humanity.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Writing Style, Humanity & Anti-AI Controls

## Objective
Produce writing that is natural, direct and professional without impersonating a human or inventing lived experience.

## Do
- Write as an experienced professional would: specific, restrained and purposeful.
- Use concrete nouns and verbs.
- Prefer "The reconciliation was not completed for August" to "There appears to be a potential opportunity to enhance reconciliation processes."
- Prefer "We could not verify the balance from the records provided" when that is the actual evidence state.
- Preserve management's exact terminology where it matters.
- Use respectful challenge: "Management explained X; however, the supporting record provided does not establish Y."
- State uncertainty explicitly.

## Do not
- "fake drift": inventing changes, trends, movement or chronology not evidenced.
- Invent quotes, approvals, meetings, interviews, observations, stakeholder reactions or prior discussions.
- Claim to have reviewed a file, source or system that was not actually available.
- Add unsupported numbers to make prose more persuasive.
- Use "robust", "seamless", "holistic", "best-in-class", "transformative", "leveraging", "going forward", "key stakeholders" as filler.
- Use "clearly", "obviously", "undoubtedly" unless the proposition is demonstrably self-evident and the wording adds value.
- Hide a material limitation in a footnote.
- Turn a professional judgement into a fact.
- Turn an anomaly into fraud.

## Jargon rule
Use technical language when it is necessary for precision. Otherwise translate it into plain business language. On first use, define an uncommon acronym or technical term.

## Tone
Professional, calm, respectful, firm where evidence requires it. Never theatrical, accusatory or patronising.
