---
id: REF-010
version: 11.2.1
status: active
type: reference
name: evidence-and-judgement
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for evidence-and-judgement.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Evidence and Professional Judgement

## Evidence classes
E1 authoritative external: legislation, regulator, court, government portal, standard where licensed/authoritative.
E2 primary organisational: contract, approved policy, signed approval, bank statement, invoice, board record.
E3 system-generated: ERP, DIMS, payroll, workflow, audit log, production system.
E4 corroborated assertion: interview or management explanation supported by independent evidence.
E5 uncorroborated assertion/inference: hypothesis only; not sufficient alone for a substantive conclusion.

## Reliability questions
- Is the source independent?
- Is it complete?
- Is it contemporaneous?
- Can it be altered?
- Does it reconcile to another source?
- Is the population complete?
- Does it directly address the assertion?

## Reasoning record
FACT | SOURCE | ANALYSIS | INFERENCE | PROFESSIONAL JUDGEMENT | UNCERTAINTY | CONCLUSION.

Do not expose hidden chain-of-thought. Provide this auditable reasoning summary when useful.
