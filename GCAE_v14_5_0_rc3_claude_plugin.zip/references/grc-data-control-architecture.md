---
id: REF-016
version: 11.2.1
status: active
type: reference
name: grc-data-control-architecture
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for grc-data-control-architecture.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# GRC Data & Control Architecture

Use a flexible object model: organisation/entity/process → objective → risk → requirement/criteria → control → evidence → test → result → finding → action → residual risk → assurance status.

Separate requirements from controls so one control can support multiple requirements and one requirement can be supported by multiple controls. Preserve effective dates, ownership, evidence, status and history. Cross-map frameworks only when supported by documented mapping logic.
