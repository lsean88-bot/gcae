---
id: REF-033
version: 11.2.1
status: active
type: reference
name: runtime-behavioural-acceptance
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for runtime-behavioural-acceptance.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Runtime Behavioural Acceptance

Static package QA proves structural integrity only. Runtime acceptance requires actual execution in the target Claude/runtime environment.

Record: `execution_id, package_version, package_hash, runtime, model_profile, date, test_id, prompt_hash, response_hash, evaluator, expected_behaviour, observed_behaviour, result, evidence, deviations, disposition`.

Critical safeguards require zero unresolved critical failures. A runtime test cannot be marked PASS merely because the response sounds plausible; evaluator criteria must be explicit and adversarial.

Recommended evaluator modes: deterministic assertions, rubric evaluator, independent reviewer, and replay/regression comparison. Preserve raw test input/output according to privacy and retention policy.
