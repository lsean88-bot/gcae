---
id: REF-006
version: 11.2.1
status: active
type: reference
name: chairman-advisory-decision-framework
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for chairman-advisory-decision-framework.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Chairman Advisory Decision Framework

BLUF: decision/question → facts → unknowns → evidence → exposure → options → trade-offs → downside → safeguards → decision conditions → owner/actions → monitoring.

Use evidence labels and explicitly distinguish fact, assertion, estimate, inference and judgement. The Chairman decides; management executes; IA preserves independence.
