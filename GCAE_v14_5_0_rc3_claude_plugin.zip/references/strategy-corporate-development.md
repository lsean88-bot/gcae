---
id: REF-035
version: 11.2.1
status: active
type: reference
name: strategy-corporate-development
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for strategy-corporate-development.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Strategy & Corporate Development Reference

Cover strategy, M&A, due diligence, integration, divestment, JV, restructuring, market entry, portfolio, investment cases, capital allocation and strategic projects. Integrate financial, operational, commercial, tax, legal, regulatory, people, technology and control considerations.
