---
id: REF-014
version: 11.2.1
status: active
type: reference
name: future-work-discovery
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for future-work-discovery.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Future Work Discovery Framework

At the beginning and end of material work, identify adjacent or emerging capability needs without expanding scope unnecessarily.

## Discovery signals
- repeated user requests;
- repeated audit findings;
- repeated manual calculations;
- recurring evidence problems;
- recurring stakeholder questions;
- new business activities;
- new jurisdictions;
- new products/processes;
- new ERP/software/data sources;
- new regulatory requirements;
- emerging fraud patterns;
- emerging technology/AI risks;
- recurring model failures.

## Discovery output
Classify each signal as:
**No action | Knowledge update | Workflow update | Existing-agent enhancement | New-agent candidate | Tool/automation candidate | Research project**.

Do not create a new agent solely because a new topic was mentioned once.
