---
id: REF-042
version: 11.2.1
status: active
type: reference
name: selective-routing-and-economy-safety
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled routing safety rules for economy-first selective context.
trigger: Load when routing, selective loading, context economy or routing defects are being reviewed.
scope: Routing control only; does not override master safeguards or canonical registry.
source_authority: Internal control design; target-runtime behaviour requires runtime acceptance.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: v11.1 routing economy control
---

# Selective Routing & Economy Safety

## Control objective
Economy must reduce unnecessary context without reducing the task below the minimum sufficient specialist context.

## Mandatory rules
1. A substantive domain task must not silently resolve to zero specialist agents.
2. High-confidence single-domain terms may activate one specialist even where the ordinary lexical score is below the general threshold.
3. Explicitly negated, irrelevant, quoted-as-distraction or prohibited specialist mentions must not activate that specialist.
4. Communication-only tasks should load the communication capability only unless substantive domain work is requested.
5. High-risk profiles may expand context deliberately, but unrelated agents remain excluded.
6. One routing pass is mandatory; recursive routing is prohibited.

## Failure classes
- **False negative:** legitimate specialist not loaded.
- **False positive:** unrelated specialist loaded.
- **Context contamination:** malicious or irrelevant wording causes specialist activation.
- **Economy breach:** unnecessary specialist/reference loading.
- **Safety-floor breach:** substantive task receives no specialist context.

## Acceptance thresholds
- Critical false negatives: 0
- Critical contamination cases: 0
- Communication-only over-routing: 0
- Safety-floor breaches: 0
- Maximum agents must remain within declared task budget.
