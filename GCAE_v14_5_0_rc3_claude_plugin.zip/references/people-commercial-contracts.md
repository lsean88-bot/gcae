---
id: REF-024
version: 11.2.1
status: active
type: reference
name: people-commercial-contracts
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for people-commercial-contracts.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# People, Commercial & Contract Risk

Cover people/culture, payroll, recruitment, succession, conduct, procurement, supplier risk, pricing, quotation-to-payment, related parties, conflicts, contract obligations, liability, warranties, indemnity, termination and disputes.
