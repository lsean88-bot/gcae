---
id: REF-011
version: 11.2.1
status: active
type: reference
name: evidence-lineage-reproducibility
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for evidence-lineage-reproducibility.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Evidence Lineage & Reproducibility

Every material analytical conclusion should be traceable through objective/risk, criteria, population, procedure, transformation, calculation, result, evidence, workpaper, finding and report.

For sampling record population, period, selection rule, sample size, seed where randomised, exclusions and deviations. Reproducibility supports review but does not prove evidence sufficiency.

Preserve raw source data separately from transformed data. Record formulas, code/version, filters, joins, assumptions, tolerances, currency/unit normalisation and reconciliation. Never silently repair source data.
