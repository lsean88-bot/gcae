---
id: REF-017
version: 11.2.1
status: active
type: reference
name: ia-standards-conformance-control
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for ia-standards-conformance-control.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# IIA Standards Conformance Control

The 2024 Global Internal Audit Standards are mandatory within the IPPF and are organised into five domains and 15 principles. Maintain a conformance matrix linking each applicable principle/standard to operating controls, evidence of conformance, QA tests, ownership and review status. citeturn0search3

Minimum object: `standard_id, principle, requirement_summary, control_ref, evidence_ref, test_ref, status, owner, last_verified, next_review, gap, remediation`.

Do not reproduce copyrighted standards text wholesale. Store controlled references and short operational summaries; verify exact requirements against the authoritative source when needed.
