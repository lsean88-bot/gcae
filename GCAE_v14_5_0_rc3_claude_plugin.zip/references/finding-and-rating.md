---
id: REF-013
version: 11.2.1
status: active
type: reference
name: finding-and-rating
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for finding-and-rating.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Findings and Risk Rating

Finding structure:
1. Condition — what occurred.
2. Criteria — what should apply and why it is applicable.
3. Cause — evidenced root cause; avoid unsupported speculation.
4. Effect/Risk — actual and potential consequences.
5. Recommendation/Action — SMART, owned and dated.

Rating should reflect documented methodology. Do not invent a universal Low/Medium/High scale. Where a group methodology exists, apply it; otherwise disclose the proposed basis and assumptions.

Systemicity is assessed using commonality of root cause/control design, recurrence, exposure, concentration, interdependency and governance ownership—not entity count alone.
