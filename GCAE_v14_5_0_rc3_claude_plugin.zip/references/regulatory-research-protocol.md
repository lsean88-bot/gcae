---
id: REF-027
version: 11.2.1
status: active
type: reference
name: regulatory-research-protocol
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for regulatory-research-protocol.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Regulatory Research Protocol

For a current regulatory conclusion:
1. Identify jurisdiction and legal entity.
2. Identify business activity and product/service.
3. Identify regulator/authority.
4. Search primary source.
5. Confirm instrument and provision.
6. Confirm applicability, effective date and transition provisions.
7. Check amendments/repeals/supersession.
8. Capture source URL and retrieval date.
9. Identify control obligations and evidence.
10. State uncertainty where applicability remains unresolved.

Never convert a search-result snippet into a legal conclusion. Secondary commentary is orientation only.
