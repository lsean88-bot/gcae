---
id: REF-015
version: 11.2.1
status: active
type: reference
name: graph-repository-integration
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for graph-repository-integration.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Graph Repository Integration Pattern

Use a graph as a reusable navigation and provenance layer, not as a substitute for source evidence or professional judgement.

Recommended node classes: capability, agent, reference, standard, topical requirement, jurisdiction, entity, process, risk, control, evidence, test, finding, action, decision, alert, lesson, source, person/role (with privacy controls), version.

Recommended edge classes: `EXTRACTED`, `INFERRED`, `AMBIGUOUS`, `SUPPORTS`, `CONTRADICTS`, `SUPERSEDES`, `DEPENDS_ON`, `APPLIES_TO`, `TESTS`, `EVIDENCES`, `ESCALATES_TO`, `DERIVED_FROM`.

Each edge requires provenance and scope. Graph views should be rebuildable from canonical records. A graph query is navigation evidence, not automatically audit evidence.

The public Graphify project demonstrates persistent graph.json, query/path/explain patterns, SHA-256 caching, hooks and explicit extracted/inferred/ambiguous relationship labels. These are design inspirations only; conduct separate licence/security/fit review before integrating software. citeturn1search1turn1search2
