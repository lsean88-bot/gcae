---
id: REF-038
version: 11.2.1
status: active
type: reference
name: trusted-release-and-oracle-governance
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Trusted release root, independent test-oracle, four-eyes approval and release evidence governance.
trigger: Release, package mutation, oracle change, control-plane change or production promotion.
scope: Release integrity, oracle governance, external hash anchoring, meta-QA and approval evidence.
source_authority: Internal controlled architecture; cryptographic mechanisms must be implemented by the deployment environment.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: All production package releases and material control-plane changes.
---

# Trusted Release and Oracle Governance

A release system must not be its own sole judge. Internal hashes are useful for consistency, but authenticity and oracle integrity require an independently controlled baseline.

## Required release evidence
1. Candidate package SHA-256.
2. Canonical registry/version/count reconciliation.
3. Referential-integrity result.
4. Test-oracle integrity result.
5. Semantic mutation-test result.
6. IIA mapping/evidence integrity result.
7. Knowledge-boundary result.
8. Runtime status and explicit limitations.
9. Builder identity and independent reviewer identity.
10. Release decision and timestamp.

## Four-eyes rule
The person who materially builds or modifies the release must not be the sole approver of a critical production release. If independent approval is unavailable, status remains RELEASE-CANDIDATE / HOLD.

## Oracle rule
Expected behaviour, severity and pass criteria for critical tests are controlled test-oracle data. A test corpus change without corresponding independently approved oracle change is a release failure.
