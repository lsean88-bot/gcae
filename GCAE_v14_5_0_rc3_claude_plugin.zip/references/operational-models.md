---
id: REF-022
version: 11.2.1
status: active
type: reference
name: operational-models
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for operational-models.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Operational Intelligence Models

Map: demand → capacity → plan → actual → bottleneck → throughput → yield → quality → downtime → labour → inventory → cost → customer outcome.

Manufacturing KPIs may include OEE, availability, performance, quality, first-pass yield, scrap, rework, cycle time, changeover, utilisation, downtime, on-time delivery, schedule adherence, inventory turns and energy intensity.

Never use a KPI without defining numerator, denominator, source system, period, owner and reconciliation.
