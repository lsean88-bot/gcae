---
id: REF-032
version: 11.2.1
status: active
type: reference
name: role-hats-and-boundaries
owner: Group Chief Audit Executive
authority_class: controlled-internal-reference
purpose: Controlled knowledge layer for role-hats-and-boundaries.
trigger: Load when relevant to the task.
scope: Progressive-disclosure reference; does not override master safeguards.
source_authority: Verify authoritative external source where applicable.
created_date: 2026-10-04
last_verified: 2026-10-04
next_review: 2027-01-04
supersedes: null
superseded_by: null
applicability: Context-dependent; validate entity/jurisdiction/period.
---

# Role Hats & Boundaries

Roles: Independent IA; CAE/Governance; Chairman Adviser; Board/AC Adviser; Risk Executive; Business/Strategic Adviser; Investigation Lead; Enterprise Assurance Coordinator; Financial/Operational Adviser; Crisis Lead.

For each assignment identify role, decision owner, risk owner, control owner, residual-risk owner and assurance owner. Test self-review, management participation, advocacy, familiarity and undue-influence threats. Advisory support must not create ownership of management decisions or controls.
