# Jurisdiction × Industry Specialist Routing

This plugin's generic agents (04 Financial, 05 Operational, 06 Statutory/Compliance, 07 Legal, 09 Fraud, 11 IT) do **not** carry jurisdiction-specific statutory detail themselves — per Iron Rule 1 (no evidence, no fact), they must not improvise a Malaysian, Indian, or Mexican requirement they can't verify. Instead, for any engagement with a jurisdiction and/or industry, route to the already-verified skill below *before* Agent 06 or Agent 04 conclude anything statutory. This plugin still leads the lifecycle (planning, risk scoring, findings, QA) — it borrows the local facts, it doesn't reinvent them.

## Malaysia

| Industry | Verified skill to load | Notes |
|---|---|---|
| Die-casting / metal stamping / automotive parts | `my-mfg-diecast-stamping-audit` (general), `my-mkpc-mfg-audit` (MKPC-specific: Perodua/Denso OEM, IATF 16949) | Use the MKPC-specific one for MKPC entities, the general one otherwise |
| Gas cylinder manufacturing under LMW | `my-erawan-lmw-audit` | RMCD M1/M2/M4, export ratio, hydrostatic test cycle |
| Healthcare — dialysis | `my-hc-dialysis-audit` (dialysis-specific: CKAPS, PPT/FMC, PERKESO panel), `my-healthcare-clinical-dialysis-audit` | Use the dialysis-specific one for pure dialysis centres |
| Healthcare — multi-specialty clinic | `my-phc-clinic-audit` | PHFSA Borang B, LCP aesthetic, DCA biologics |
| HR / payroll / foreign worker | `my-malaysia-hr-audit` | EA 1955, EPF/SOCSO/EIS, Employment Pass, MACC s.17A |
| Fraud/governance overlay | `group-cae-fraud-v2` or `cae-fraud-investigation` | Apply MACC s.17A and ISO 37001 specifics from these, not from Agent 09 alone |

## India

| Industry | Verified skill to load | Notes |
|---|---|---|
| Manufacturing (die-casting/stamping, general) | `in-manufacturing-audit` | GST, ICAI SA/SIA, IATF 16949, CLRA |
| Chennai / Tamil Nadu operations | `chennai-india-ops-audit` | Supersedes `chennai-hr-audit` for TN context — use the ops-audit version |
| Pune / Maharashtra operations | `pune-india-ops-audit` | Supersedes `pune-hr-audit` for MH context — use the ops-audit version |
| Healthcare — dialysis | **Gap — no India-specific skill exists yet.** Do not let Agent 06 improvise Clinical Establishments Act, state-level nursing-home licensing, or CGHS/PMJAY panel billing rules. Flag this explicitly to the user rather than guessing, and treat it as a build item (parallel to `my-hc-dialysis-audit` for Malaysia) if an India dialysis engagement is imminent |
| Fraud/governance overlay | `group-cae-fraud-v2` or `cae-fraud-investigation` | India-specific: Prevention of Corruption Act, PMLA references |

## Mexico

| Industry | Verified skill to load | Notes |
|---|---|---|
| Manufacturing (auto parts / metal stamping / tooling) | `mx-manufacturing-audit` | SAT/CFDI, IMMEX, IATF 16949, die governance, material-balance/scrap reconciliation |
| HR / labour | Bundled inside `mx-manufacturing-audit` (REPSE, union/CCT, expat/INM) — no separate Mexico HR skill exists | Don't look for a standalone one; it's already in the manufacturing skill |
| Healthcare — dialysis | **Gap — no Mexico-specific skill exists yet.** Same caution as India: don't let Agent 06 improvise NOM healthcare regulations or IMSS clinical-service rules | Flag as a build item if needed |
| Fraud/governance overlay | `group-cae-fraud-v2` or `cae-fraud-investigation` | Mexico-specific: LGRA, FCPA, UK Bribery Act references already present in `mx-manufacturing-audit` |

## Cross-cutting (any jurisdiction, any industry)

- `cae-verification-discipline` — evidence-grounding gate; run before writing "verified" or "confirmed" anywhere
- `racm-ecosystem` — RACM lifecycle, ToD/ToE, SD/MW/MN deficiency classification
- `board-chairman-briefing`, `group-cae-reporting`, `iar-universal-template`, `group-cae-external-reporting` — reporting layer once findings are final
- `mktron-sentinel:self-learning-loop` — persistent, cross-session lessons learned (the real version of what the uploaded document called "Kaizen")
- `mktron-sentinel:continuous-control-monitoring`, `mktron-sentinel:enforcement-escalation`, `mktron-sentinel:automated-action-engine` — follow-up and action-plan tracking

## Working a combined request

**Example — single engagement, multiple domains:** "Malaysia dialysis centre, foreign worker payroll." Load `my-hc-dialysis-audit` for the clinical/statutory facts and `my-malaysia-hr-audit` for payroll/foreign-worker facts, in the same conversation, and run this plugin's Agent 03 (Risk & Control) and Agent 09 (Fraud) over both. That is what "in combination" means in practice — more than one skill's reference content applied together in one context, not a merged skill that would duplicate both.

**Example — genuinely independent, parallel workstreams:** "Run Malaysia MKPC, Mexico mksld, and India Chennai fraud sweeps at the same time." That is not something this plugin — or any skill file — can do on its own; see below.

## On "sub-agent spawning" — what this plugin can and can't do

A skill is a markdown file loaded into one conversation's context. Within that one conversation, "combining agents" means exactly what the section above describes: loading more than one reference file and applying both. That covers most "individually or in combination" requests for a single engagement.

What it cannot do is spawn genuinely parallel, independently-running agents — separate context windows working at the same time on separate jurisdictions — because nothing in a skill file executes; it's read, not run. If you want that kind of real parallelism (e.g., three jurisdiction sweeps proceeding simultaneously rather than one after another), that's a Claude Code capability via the Task tool, and `mktron-sentinel:orchestration-protocol` in your portfolio is already built specifically to invoke it — decomposing multi-workstream audit work and delegating independent pieces to separate subagent runs. Use that skill for genuine parallelism; use this plugin's own agent roster for depth within a single engagement. I'm not going to describe a "spawn" mechanism inside this plugin itself, for the same reason the model-routing and cron-scraping sections were declined earlier: it would look authoritative and do nothing.
