# Effort Tiering Guidance (Manual, Not Automated)

Claude cannot programmatically switch its own underlying model mid-skill, run scheduled jobs, or cache across sessions — none of that infrastructure exists inside a skill file. What genuinely helps is knowing **which lifecycle phases warrant more reasoning effort or a higher-capability model**, so you can make that call yourself — via claude.ai's model picker, Claude Code's subagent model flag, or by simply asking for more/less depth in the moment.

## Lower-complexity phases (fast, routine — a quick pass is usually enough)
- Document/data gathering and PBC list assembly (Phase 4)
- Evidence indexing and classification once tests are already designed (Phase 8, mechanical part)
- Drafting routine chaser/reminder correspondence
- Business/operating-model note-taking once the first walkthrough is done (Phase 3, after the initial pass)

## Higher-complexity phases (worth more reasoning time / a stronger model)
- Risk & control assessment and residual-risk judgement (Phase 5)
- Root-cause analysis — rejecting superficial causes takes real reasoning (Phase 9)
- Risk scoring and heat-map reconciliation, where arithmetic and narrative must agree (Phase 10)
- Management action-plan validation — the "will this actually fix it" test is a judgement call, not a checklist (Phase 11)
- Final report QA against the Iron Rules/Golden Rules, and the Agent 18/19 challenge-and-resolve step (Phase 12)
- Any fraud-indicator assessment (Agent 09) — the deficiency-vs-fraud distinction is exactly where shortcuts cause the most harm

## What this is, and isn't
This is a checklist for **your own judgement about where to spend attention** (yours or a stronger model's), not a routing engine. If you want actual automated model selection across a multi-part engagement, that's a real engineering project — e.g. a Claude Code script or Claude Agent SDK app that calls the Messages API directly with a model parameter per task — and is a different kind of build from a skill file. Say if you want help scoping that separately; it's buildable, just not as a skill.
