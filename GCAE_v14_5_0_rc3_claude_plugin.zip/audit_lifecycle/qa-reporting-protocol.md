# Final Report QA & Reporting Protocol

Read this file in full before issuing any final Internal Audit Report, and before any second-line/CAE quality review of a draft. Apply it regardless of how many prior engagements have already used it.

## 1. Review all source material
Reconcile the audit report, management responses/action plans, supporting schedules/records/evidence, working papers, risk assessments, control descriptions and management assertions. Where information conflicts, reconcile against the strongest available evidence and apply professional judgement. **Never invent, assume, fabricate, or fill a gap with unsupported information.**

## 2. Validate every audit issue
For each issue, independently reassess: (1) factual accuracy, (2) sufficiency/appropriateness of evidence, (3) clarity, (4) relevance to objective, (5) genuineness as a control/governance/risk/compliance weakness, (6) no duplication elsewhere, (7) proper linkage to the underlying risk, (8) appropriate rating, (9) support from the recommendation, (10) an appropriate Management response.
Validate the full chain: **Condition → Criteria → Cause → Risk/Effect → Root Cause → Recommendation → Management Action → Owner → Target Date.** Distinguish observation/process inefficiency/documentation gap from a material control deficiency — don't conflate them without evidence.

## 3. Reassess risk independently
Never simply accept Management's or a prior report's rating.
- **Inherent risk:** financial, operational, compliance/statutory, legal/contractual, fraud, reputational, customer, business continuity, strategic impact; likelihood; severity.
- **Control environment:** design, implementation, operating effectiveness, ownership, monitoring, evidence of execution, segregation of duties, oversight, gaps, compensating controls.
- **Residual risk:** after considering control effectiveness — but only reduce the rating to the extent design *and* operating effectiveness are evidenced, never merely because a control exists on paper.

## 4. Verify risk scoring methodology
Apply one consistent, transparent methodology throughout: likelihood, impact, inherent score, control effectiveness, residual score, overall classification, category, ranking, heat-map position. Check the arithmetic. Check the narrative supports the number. **The score must follow the risk — never manipulate the risk narrative to fit a predetermined score.** Change an incorrect score even if it appeared in an earlier draft.

## 5. Risk heat map
Recalculate against final approved scores. Every issue must appear once, in the correct position, agreeing with the risk-rating table, with consistent categories and labels. The heat map is a data representation, not decoration.

## 6. Report structure
Use a risk-based structure, e.g.: Executive Summary → Overall Audit Opinion/Conclusion → Audit Objective and Scope → Key Risk Overview → Risk Heat Map → Summary of Audit Issues → Detailed Audit Findings → Management Responses and Action Plans → Overall Conclusion → Appendices (only where genuinely necessary). Order findings by **risk**, not discovery order.

## 7. Each detailed finding
Consistent format: Audit Issue → Risk/Impact → Condition → Root Cause → Control Assessment → Risk Rating (methodology shown) → Recommendation → Management Action Plan (owner + target date where available). Recommendations must not become Management's operational instructions beyond what's appropriate for Internal Audit.

## 8. Management responses
Confirm the response addresses the actual issue and the root cause (not just the symptom); responsibility is clearly assigned; target dates are realistic and specific where given; Management hasn't merely acknowledged without committing to action; disagreement is represented accurately; unsupported Management assertions are not presented as fact. Retain independent assessment — never rewrite a response in a way that changes its meaning.

## 9. Language and presentation
Rewrite into clear, precise, natural professional English: concise, objective, evidence-based, direct, executive-friendly, free of jargon-without-explanation, repetition, emotional/accusatory language, generic audit boilerplate, or artificial/AI-sounding phrasing. It should read as though prepared and QA'd by an experienced Group CAE.

## 10. Tables, graphs, visuals
Use only where they materially aid understanding (executive risk summary, risk-rating table, heat map, finding-summary matrix, control-assessment table, action-plan table). Every visual must reconcile exactly with the underlying data — never decorative.

## 11. Iron Rules (absolute, no exception)
1. No evidence — no fact. 2. No unsupported assumption. 3. No fabricated information. 4. No invented management response, owner, date, control or evidence. 5. No finding without a clearly articulated risk. 6. No risk rating without a defensible methodology. 7. No risk score that conflicts with the underlying evidence. 8. No recommendation that doesn't address the identified weakness/root cause. 9. Internal Audit never assumes Management's responsibility. 10. Internal Audit preserves independence and objectivity.

## 12. Golden Rules
1. **Risk First** — prioritise by significance/risk. 2. **Evidence First** — every factual conclusion is evidenced. 3. **Cause and Effect** — connect weakness to risk/impact clearly. 4. **Accuracy** — facts, figures, dates, calculations, scores are correct and internally consistent. 5. **Proportionality** — severity of wording/rating/recommendation matches actual exposure. 6. **Clarity** — decision-makers understand issue/risk/required response without interpreting ambiguity. 7. **Independence** — Internal Audit assures and advises; Management owns process/control/decision/remediation. 8. **No Noise** — cut unnecessary narrative, duplication, drafting commentary, irrelevant detail. 9. **Consistency** — terminology, methodology, scoring, structure, numbering, presentation are uniform throughout. 10. **Decision Ready** — the reader must grasp: What is wrong → Why it matters → How serious it is → What Management must address.

## 13. Final CAE-level quality checklist
Before issuing, check: accuracy; completeness; evidence sufficiency; audit logic; risk assessment and scoring; control assessment; root cause; recommendations; management responses; action owners; target dates; finding prioritisation; numbering; cross-referencing; tables; heat map; calculations; internal consistency; language; formatting; executive readability. Correct every identified weakness before producing the final output.

## 14. Strict output rule
Produce **only the final Internal Audit Report.** Do not include review notes, draft/revision history, "first/second attempt", prior findings, commentary on what changed or was removed, what Management previously said, process commentary, AI commentary, QA notes, edit-process explanations, "I have revised…", "I recommend…", "the report has been improved…", or any other meta-commentary. Do not show the development audit trail. Where evidence is insufficient to support a statement, state the limitation within the report or omit the unsupported assertion — never fabricate a conclusion to fill the gap. The output is the final, clean, professional, risk-based Internal Audit Report suitable for formal issuance by the Group CAE.
