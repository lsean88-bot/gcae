# End-to-End Lifecycle Workflow

## Evidence chain (maintained across every phase)
`Source → Evidence → Test → Result → Conclusion → Finding`
Every finding in the final report must be traceable back through this chain. If a link is missing, the finding is not ready for reporting — go back and close the gap or state the limitation explicitly.

## Phase-by-phase hand-offs

1. **Planning (Agent 01):** mandate → audit universe → objective/scope/criteria → planning memo. Hand off scope + key risks to Agent 02.
2. **Knowledge acquisition (Agent 02):** build the business/operating model picture. Hand off to Agent 03 with: what the business does, how it makes/loses money, and where it structurally can fail.
3. **Document & data gathering (Agents 10, 13):** request/receive PBC items; run population, completeness and reconciliation checks; build the evidence index before fieldwork narrative begins.
4. **Risk & control assessment (Agent 03):** identify risks and controls, assess design; hand the Risk→Control map to the relevant domain agent(s) (04–09, 11) and to Agent 12 for test design.
5. **Domain substantive review (Agents 04–09, 11 — as scope requires):** each domain agent applies its own subject-matter checklist against the Risk→Control map, surfacing candidate issues with domain-specific evidence.
6. **Audit testing (Agent 12):** convert each candidate issue's control into an executable test (population, sample, procedure, expected vs actual result). No effectiveness conclusion without a completed test.
7. **Evidence & workpaper compilation (Agent 13):** classify and index all evidence gathered so far; verify sufficiency, reliability, and traceability before findings are drafted.
8. **Findings & root cause (Agent 14):** Condition → Criteria → Cause → Root Cause → Effect/Risk → Recommendation, for every substantiated issue. Reject superficial root causes.
9. **Risk scoring & heat map (Agent 15):** independently score likelihood/impact/inherent/control-effectiveness/residual for each finding; build the heat map; reconcile it against the finding table.
10. **Management action-plan validation (Agent 16):** test each proposed action against the SMART + root-cause-resolution test before it is accepted into the report as agreed.
11. **Draft report QA (Master Agent):** apply the full protocol in `qa-reporting-protocol.md` — this is a gate, not a formality; findings that fail the ten-point issue validation in §2 of that file go back to Agent 14, not into the report.
12. **Reporting (Agent 17):** produce the final report in the structure and language standard specified in `qa-reporting-protocol.md` §6–§10, applying the strict output rule in §14.

## Follow-Up (post-issuance, IIA GIAS Standard 15)
- Track each agreed action against its owner and target date.
- At the follow-up point, independently verify implementation — don't accept Management's self-reported "done" without evidence (same evidentiary bar as the original finding).
- Classify status: Not started / In progress / Implemented — verified / Implemented — not yet verified / Overdue / Management declined (with rationale).
- Overdue or declined items follow the engagement's escalation ladder (chaser → escalation memo → Audit Committee notification) rather than being silently carried forward.
- Report progress back to the Board/Audit Committee at the agreed cadence.

## Lessons Learned / Self-Improvement
- After report issuance and at follow-up, capture: what evidence gaps caused delay or rework; which risk ratings had to be revised during QA and why; which Management action plans were rejected on first submission and why; any root-cause pattern recurring across engagements (e.g. the same control gap appearing at multiple entities).
- Consolidate recurring corrections into durable guidance for the next engagement of the same type — don't let the same mistake recur silently across cycles.
- Where this plugin's own agent instructions produced a wrong or incomplete conclusion, note the specific gap so the relevant agent's checklist in `agent-team.md` can be corrected.
