# Kaizen Lessons-Learned Log (Human-Reviewed Template)

This is a log **you** fill in after each engagement or follow-up cycle — not a script that rewrites this plugin's own instructions unsupervised. Unsupervised self-modification of audit methodology is a control weakness in its own right; every change below should be a deliberate edit you make to `agent-team.md` or `qa-reporting-protocol.md`, reviewed by you, not an automatic diff.

For a durable, cross-session version of this same discipline, see `mktron-sentinel:self-learning-loop` in the wider portfolio — it's built for exactly this and persists lessons across engagements without needing this template re-created each time.

## Entry template

```
## [Engagement ref] — [date]

### What went well
- 

### What caused rework or delay
- (e.g. evidence gap discovered late, a root cause rejected at QA and redone, a risk score inconsistent with the heat map)

### Recurring pattern seen before?
- (check prior entries — is this the second/third time the same gap has appeared, e.g. at another entity in the same sector?)

### Correction to make going forward
- (a specific instruction to add to the relevant agent's checklist, or a QA step to tighten — write the actual wording you'd add)

### Applied?
- [ ] Yes — added to [file/section] on [date]
- [ ] Not yet — reason:
```

## Standards currency (replaces automated scraping)

Rather than an unsupervised script silently overwriting reference material, when starting a new engagement in a domain governed by IIA/COSO/ACFE or a specific jurisdiction's statutory requirements, explicitly web-search for updates before relying on this plugin's static references — e.g. "IIA Global Internal Audit Standards latest update" or the specific statute/regulation by name. Treat what you find as evidence to cite in the engagement, the same as any other source — not as a silent rewrite of this plugin.
