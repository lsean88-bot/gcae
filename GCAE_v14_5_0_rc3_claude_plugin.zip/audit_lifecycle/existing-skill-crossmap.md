# Cross-Map to Existing MKTron GIA Skills

This plugin is fully standalone and does not require any of the skills below to function. This file exists only so the user can choose to delegate a given phase to an already-installed, more specialised skill instead of running it inside this plugin — check here before assuming this plugin is the only option, and defer to `mktron-sentinel:skill-registry-navigator` if the choice is genuinely ambiguous.

| This plugin's phase / agent | Overlapping existing MKTron skill | Note |
|---|---|---|
| Phase 1–2 Planning & Scoping; Agent 01 | `super-grc-audit-plugin-l99` (v5.0, Part A/B), `managing-internal-audit`, `group-cae-core` | These carry the Group's audit-universe and annual-plan methodology already in production use |
| Phase 5 Risk & Control; Agent 03 | `racm-ecosystem`, `super-grc-audit-plugin-l99` | RACM lifecycle (ToD/ToE, deficiency classification) is more mature there |
| Phase 6 Domain review — Financial | `in-manufacturing-audit`, `mx-manufacturing-audit`, `chennai-india-ops-audit`, `pune-india-ops-audit`, entity-specific MY skills | Use the jurisdiction/entity-specific skill when one exists — it carries verified local statutory detail this plugin's Agent 04/06 cannot fabricate |
| Phase 6 Domain review — Statutory/HR | `my-malaysia-hr-audit`, `chennai-hr-audit`/`chennai-india-ops-audit`, `pune-hr-audit`/`pune-india-ops-audit` | Same reason — do not let Agent 06 improvise a jurisdiction requirement these skills already hold verified |
| Phase 6 — Fraud (Agent 09) | `group-cae-fraud-v2`, `cae-fraud-investigation` | Fuller ACFE/ISO 37001/FCPA/MACC coverage than this plugin's Agent 09 summary |
| Phase 6 — IT/Cyber (Agent 11) | `mktron-sentinel:it-cyber-audit` | Dedicated ITGC + Cybersecurity Topical Requirement skill |
| Phase 7 Testing; Phase 3–4 fieldwork execution | `cae-audit-cowork-plugin-v4`, `cae-cowork-plugin-v5`, `cae-cowork-ai-plugin` | These have the actual PBC/walkthrough/ToD-ToE tooling and templates already built |
| Phase 8 Evidence/Workpaper | `cae-verification-discipline` | Evidence-grounding gate — use before finalising any Agent 13/14 output |
| Phase 9 Findings/Root cause; Phase 10 Risk scoring | `super-grc-audit-plugin-l99` | 5C findings + R1–R5 evidence scale already standardised there |
| Phase 11 Management action-plan validation; Phase 14 Follow-up | `cae-command-centre`, `mktron-sentinel:enforcement-escalation`, `mktron-sentinel:automated-action-engine` | Tracker + escalation-ladder tooling already exists |
| Phase 12–13 Report QA & drafting | `group-cae-reporting`, `cae-report-conversion`, `iar-universal-template`, `board-chairman-briefing`, `group-cae-external-reporting` | Use the official HTML template and house style rather than re-deriving formatting here |
| Phase 15 Lessons learned | `mktron-sentinel:self-learning-loop` | Persistent cross-session lessons log this plugin's own note-taking can't replicate on its own |
| Multi-workstream orchestration across several of the above | `mktron-sentinel:orchestration-protocol` | For genuinely multi-entity/multi-agent engagements, this decomposes work to Sonnet subagents — heavier-weight than needed for a single-entity run of this plugin |

**When to actually use this plugin standalone** rather than the mapped skill: a quick, self-contained lifecycle walk-through where installing/loading five or six separate skills isn't worth the overhead, or a jurisdiction/entity with no dedicated existing skill, or the user explicitly wants this plugin's own agent framing.
