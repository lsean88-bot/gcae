# GCAE v13 Release Procedure

1. Freeze canonical registry and core policies.
2. Run structural, referential, dependency, semantic, mutation and adversarial QA.
3. Run 900-test v12.2 regression oracle unchanged.
4. Run v13 complex UAT/stress.
5. Run target-runtime Claude UAT with actual model/effort/token/cache/cost telemetry.
6. Compare quality and median cost against controlled baseline.
7. Generate package hash and external trusted-root record.
8. Obtain four-eyes review and governance approval.
9. Only then promote production.
