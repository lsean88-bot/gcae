#!/usr/bin/env python3
"""Render core/IRON_RULES.md from core/policy/iron-rules.json (single source; tests fail if the two differ)."""
import json, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def render():
    d = json.load(open(os.path.join(ROOT, "core/policy/iron-rules.json"), encoding="utf-8")); out = ["# GCAE Iron Rules (%s)" % d["version"], "",
      "Non-waivable. MECHANICAL rules are enforced by the runtime guard and proven by tests and mutants; BEHAVIOURAL rules cannot be enforced by hooks and are verified from live transcripts; PROCESS rules govern acceptance. Generated from `core/policy/iron-rules.json`; do not edit by hand.", ""]
    for r in d["rules"]:
        out.append("## %s %s [%s]" % (r["id"], r["title"], r["type"])); out.append(r["rule"]); out.append("")
        out.append("- Enforcement: %s" % r["enforcement"])
        if r["stop_reasons"]: out.append("- Stop reasons: %s" % ", ".join(r["stop_reasons"]))
        if r["tests"]: out.append("- Tests: %s" % ", ".join(r["tests"]))
        if r["mutants"]: out.append("- Mutants proving it: %d" % len(r["mutants"]))
        if r["uat"]: out.append("- Live UAT: %s" % ", ".join(r["uat"]))
        if r.get("template"): out.append("- Template: %s in core/output-templates.md" % r["template"])
        out.append("")
    return "\n".join(out)
if __name__ == "__main__":
    open(os.path.join(ROOT, "core/IRON_RULES.md"), "w", encoding="utf-8", newline="\n").write(render()); print("wrote core/IRON_RULES.md")
