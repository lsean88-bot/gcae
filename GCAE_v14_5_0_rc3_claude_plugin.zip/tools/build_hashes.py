#!/usr/bin/env python3
"""Write BUILD_HASHES_V14.5.0.sha256 (sha256sum format, POSIX paths) for the plugin root. Run last, after all edits.
The guard verifies this file at preflight when present (guard.require_manifest makes it mandatory)."""
import hashlib, os, sys
root = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), ".."))
name = "BUILD_HASHES_V14.5.0.sha256"; skip = {".git", "__pycache__", ".gcae", "node_modules"}; lines = []
for dp, dn, fn in os.walk(root):
    dn[:] = sorted(d for d in dn if d not in skip)
    for f in sorted(fn):
        if f == name or f.endswith(".pyc"): continue
        p = os.path.join(dp, f); lines.append("%s  %s" % (hashlib.sha256(open(p, "rb").read()).hexdigest(), os.path.relpath(p, root).replace(os.sep, "/")))
open(os.path.join(root, name), "w", newline="\n").write("\n".join(lines) + "\n"); print("wrote %d entries to %s" % (len(lines), name))
