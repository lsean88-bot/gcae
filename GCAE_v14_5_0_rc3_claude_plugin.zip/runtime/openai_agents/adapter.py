from __future__ import annotations
import os
from typing import Any

from .control import ExecutionState

try:
    from agents import Agent, Runner, function_tool, RunConfig
except ImportError:  # allows static QA without SDK installed
    Agent = Runner = function_tool = RunConfig = None


class GCAEOpenAIRuntime:
    """Thin adapter: OpenAI Agents SDK owns transport; GCAE owns policy and stop state."""

    def __init__(self, model: str | None = None):
        self.model = model or os.getenv("GCAE_OPENAI_MODEL")
        if not self.model:
            raise ValueError("Set GCAE_OPENAI_MODEL for live runtime execution.")
        self.state = ExecutionState(session_id=os.getenv("GCAE_SESSION_ID", "gcae-live"))

    def require_sdk(self) -> None:
        if Agent is None:
            raise RuntimeError("OpenAI Agents SDK is not installed. Install the runtime dependency before live UAT.")

    def make_agent(self, name: str, instructions: str, **kwargs: Any):
        self.require_sdk()
        return Agent(name=name, instructions=instructions, model=self.model, **kwargs)

    async def run(self, agent, input_text: str):
        self.require_sdk()
        # The GCAE controller remains outside the model. SDK tracing records the run.
        return await Runner.run(agent, input_text)
