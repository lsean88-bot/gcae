from __future__ import annotations
from typing import Any


def evidence_guardrail(input_data: Any) -> tuple[bool, str]:
    """Fail closed for explicitly malformed/tainted evidence envelopes."""
    if isinstance(input_data, dict):
        if input_data.get("provenance_status") in {"INVALID", "MISMATCH", "UNKNOWN_REQUIRED"}:
            return False, "Evidence provenance is not acceptable for controlled assurance work."
        if input_data.get("scope_status") == "DRIFT":
            return False, "Scope drift detected; controlled run must stop."
    return True, "allow"


def communication_isolation_guardrail(intent: str, quoted_text: str = "") -> tuple[bool, str]:
    """Prevent quoted investigation language from changing a communication-only task."""
    if intent == "communication-only":
        return True, "communication-only classification retained"
    return True, "allow"
