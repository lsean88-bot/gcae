"""GCAE OpenAI Agents SDK runtime adapter."""
