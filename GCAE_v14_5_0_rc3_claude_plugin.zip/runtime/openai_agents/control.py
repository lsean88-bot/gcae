from __future__ import annotations
from dataclasses import dataclass, field
from hashlib import sha256
from typing import Any


@dataclass
class ExecutionState:
    session_id: str
    tools: int = 0
    agents: int = 0
    tasks: int = 0
    identical_calls: dict[str, int] = field(default_factory=dict)
    terminal_stop: bool = False
    stop_reason: str | None = None
    last_progress: str | None = None

    def signature(self, tool_name: str, arguments: Any) -> str:
        raw = f"{tool_name}|{arguments!r}".encode("utf-8", "replace")
        return sha256(raw).hexdigest()

    def before_tool(self, tool_name: str, arguments: Any, tool_limit: int = 60, repeat_limit: int = 3) -> None:
        if self.terminal_stop:
            raise RuntimeError(f"GCAE TERMINAL STOP: {self.stop_reason}")
        if self.tools >= tool_limit:
            self.stop("tool_limit")
            raise RuntimeError("GCAE TERMINAL STOP: tool_limit")
        sig = self.signature(tool_name, arguments)
        self.identical_calls[sig] = self.identical_calls.get(sig, 0) + 1
        if self.identical_calls[sig] >= repeat_limit:
            self.stop("repeated_identical_tool_call")
            raise RuntimeError("GCAE TERMINAL STOP: repeated_identical_tool_call")
        self.tools += 1

    def count_agent(self, agent_name: str, agent_limit: int = 5) -> None:
        if self.terminal_stop:
            raise RuntimeError(f"GCAE TERMINAL STOP: {self.stop_reason}")
        if self.agents >= agent_limit:
            self.stop("agent_limit")
            raise RuntimeError("GCAE TERMINAL STOP: agent_limit")
        self.agents += 1
        self.last_progress = f"agent:{agent_name}"

    def stop(self, reason: str) -> None:
        self.terminal_stop = True
        self.stop_reason = reason
