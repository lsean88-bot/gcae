from __future__ import annotations
import json, os, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
BENCH = ROOT / "tests" / "uat" / "benchmarks.json"


def main() -> int:
    if not os.getenv("OPENAI_API_KEY"):
        print("LIVE_UAT_BLOCKED: OPENAI_API_KEY is not configured; no live runtime claim permitted.")
        return 2
    if not os.getenv("GCAE_OPENAI_MODEL"):
        print("LIVE_UAT_BLOCKED: GCAE_OPENAI_MODEL is not configured; no model claim permitted.")
        return 2
    try:
        import agents  # noqa: F401
    except ImportError:
        print("LIVE_UAT_BLOCKED: openai-agents package is not installed.")
        return 2
    data = json.loads(BENCH.read_text())
    print(f"LIVE_UAT_READY: {len(data['workloads'])} benchmark workloads loaded.")
    print("Execute through the target OpenAI Agents runtime; record trace IDs, token/cost telemetry, tool calls, handoffs, guardrail events, latency and oracle scores.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
