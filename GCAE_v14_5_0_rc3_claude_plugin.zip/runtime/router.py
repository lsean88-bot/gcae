"""GCAE 14.5.0-rc3 deterministic router.
Routing is based on explicit task intent and work-product semantics before domain enrichment.
Quoted/evidentiary text cannot create a route. Communication-only work is exclusive.
Compound tasks are decomposed into bounded intent components; the router does not delegate itself.
"""
from __future__ import annotations
from dataclasses import dataclass,field
from pathlib import Path
import json,re
from .dependency_closure import DependencyClosure
@dataclass
class Route:
    task_id:str; intent:str; task_class:str; risk_tier:str
    selected_capabilities:list[str]=field(default_factory=list); selected_agents:list[str]=field(default_factory=list)
    selected_references:list[str]=field(default_factory=list); dependency_closure_status:str='INCOMPLETE'
    missing_dependencies:list[str]=field(default_factory=list); authorized_scope:str=''; reason_codes:list[str]=field(default_factory=list)
    state_trace:list[str]=field(default_factory=list); escalation:str='none'; workstreams:list[dict]=field(default_factory=list)

def _terms(text, terms): return any(re.search(r'(?<!\w)'+re.escape(t)+r'(?!\w)', text, re.I) for t in terms)
def _leading_communication(low): return bool(re.match(r'^\s*(please\s+)?(rewrite|rephrase|proofread|polish|edit|improve|draft|write|compose|translate|shorten|humani[sz]e)\b',low))
def _strip_negations(low): return re.sub(r"\b(do not|don't|dont|without|never|avoid|must not|should not|shall not|no need to|not to)\b[^.;\n]*", ' ', low)
def _communication_evidence_quarantine(low):
    return bool(re.search(r'\b(quoted|quote|contains the words|background only|mentioned only|as background|verbatim)\b',low) or re.search(r'"[^"]*(fraud|investigat|audit|nominee|regulat|risk)[^"]*"',low))
def _risk(text,intent):
    if intent=='communication': return 'L0'  # v14.5.0: quoted/instructional fraud words must not escalate communication-only work
    if _terms(text,['production acceptance','four-eyes','four eyes','critical incident','chairman','board assurance','nominee account','nominee','fraud','forensic','material exposure']): return 'L4'
    if intent in {'investigation','research','build_qa','advisory'}: return 'L3'
    if intent=='communication': return 'L0'
    if intent in {'analysis','assurance','risk'}: return 'L2'
    return 'L1'
class Router:
    def __init__(self,root):
        self.root=Path(root); self.index=json.loads((self.root/'core/capability-index.json').read_text()); self.closer=DependencyClosure(root)
    def _classify_intent(self,low):
        raw=low; low=_strip_negations(low)  # v14.5.0: a negated instruction ('Do not investigate...') is not a request
        # Communication exclusivity is evaluated before any content-domain term.
        if _leading_communication(low):
            # A leading communication verb owns the task unless the user explicitly asks for a second analytical action.
            explicit_second=bool(re.search(r'\b(and|then|also|plus)\b.*\b(investigate|audit|assess|analyse|analyze|reconcile|test|verify|research|determine|forensic)\b',low))
            if _communication_evidence_quarantine(raw) or not explicit_second: return 'communication','communication',['COMMUNICATION_ONLY']
        if _terms(low,['plugin','skill','agent','routing','router','uat','mutation test','regression test','production ready','runtime control','architecture qa','architecture review','release manifest','claude code','release controls']) and _terms(low,['build','install','configure','validate','test','check','release','deploy','package','rebuild','harden','inspect','run uat','fix']): return 'build_qa','build_qa',['BUILD_QA_INTENT']
        regulatory=_terms(low,['regulation','regulatory','statutory','gst','cgst','vat','ckaps','iia standards','iso','iatf','legal conclusion','verify the law','legislation','compliance'])
        explicit_research=_terms(low,['research','researching'])
        audit_action=bool(re.search(r'\b(audit|test|reconcile|reconciliation|review|assess)\b(?!\s+(compliance|committee|finding|report|function|standard))',low) and not re.search(r'\bfor the audit (conclusion|report|finding)\b',low))
        if regulatory and explicit_research and not audit_action: return 'research','research',['REGULATORY_RESEARCH_PRIORITY']
        if regulatory and audit_action: return 'assurance','assurance',['ASSURANCE_OVER_REGULATORY_RESEARCH']
        if _terms(low,['fraud','forensic','nominee','price inflation','conflict of interest','coi','investigate','investigation','allegation','whistleblower']): return 'investigation','investigation',['INVESTIGATION_INTENT']
        if _terms(low,['enterprise risk','risk assessment','risk appetite','risk register','risk governance','three lines','control design']): return 'risk','risk',['RISK_INTENT']
        if _terms(low,['chairman','board','audit committee','decision memo','decision analysis','strategy','strategic options','board assurance']): return 'advisory','advisory',['ADVISORY_INTENT']
        if _terms(low,['find the previous','retrieve','locate the prior','search the files','look up the previous']): return 'retrieval','retrieval',['RETRIEVAL_INTENT']
        if _terms(low,['audit','audit finding','audit plan','audit program','rcm','control testing','assurance','reconcile','reconciliation','stocktake','control gap','physical count','remediation','access controls','segregation of duties','segregation of duty']): return 'assurance','assurance',['ASSURANCE_INTENT']
        if _terms(low,['knowledge base','institutional memory','knowledge graph','lessons learned']): return 'knowledge','knowledge',['KNOWLEDGE_INTENT']
        if _terms(low,['find the previous','retrieve','locate the prior','search the files','look up the previous']): return 'retrieval','retrieval',['RETRIEVAL_INTENT']
        return 'analysis','analysis',['GENERAL_ANALYSIS_FALLBACK']
    def _domains(self,low):
        domains=[(['dialysis','dims','dialyzer','patient treatment','consumable usage'],'AG-016'),(['stamping','press line','metal stamping'],'AG-013'),(['die casting','die-cast'],'AG-012'),(['forging','forge line'],'AG-014'),(['assembly line','assembly production'],'AG-015'),(['gas cylinder','gas cylinders'],'AG-017'),(['tooling','tool contract'],'AG-018'),(['costing','standard cost','cost sheet'],'AG-019'),(['supplier','procurement','purchase order','accounts payable','payables'],'AG-030'),(['contract','legal governance','supplier agreement'],'AG-031'),(['payroll','hr','human resources','employee'],'AG-029'),(['technology','cyber','erp','sap','system access'],'AG-010'),(['finance','financial statement','gl','general ledger','receivable','revenue','debtor','creditor','ap','ar'],'AG-005'),(['operations','operational','process performance'],'AG-006')]
        return [a for terms,a in domains if _terms(low,terms)]
    def _mandatory(self,intent):
        return {'communication':['AG-024'],'build_qa':['AG-037','AG-039'],'research':['AG-004','AG-036'],'investigation':['AG-008'],'risk':['AG-003'],'advisory':['AG-026','AG-027'],'assurance':['AG-002'],'knowledge':['AG-040'],'retrieval':['AG-040','AG-045'],'analysis':['AG-005']}[intent]
    def classify(self,request,task_id='TASK-UNSET',authorized_scope=None):
        text=request.strip(); low=text.casefold(); scope=(authorized_scope or '').strip()
        r=Route(task_id,'analysis','analysis','L2',authorized_scope=scope); r.state_trace=['INIT','INGRESS','TASK_ENVELOPE','INTENT']
        if not scope: r.escalation='scope-missing'; r.reason_codes.append('AUTHORIZED_SCOPE_MISSING'); r.state_trace.append('STOP') ; return r
        intent,task_class,reasons=self._classify_intent(low); r.intent=intent;r.task_class=task_class;r.reason_codes+=reasons
        caps=self._mandatory(intent)
        if intent not in {'communication','research','knowledge','retrieval','build_qa'}: caps+=self._domains(low)
        if intent=='research' and _terms(low,['legal','contract','statutory interpretation']): caps.append('AG-031')
        # Capabilities are selected by deterministic intent/domain rules, then de-duplicated.
        r.selected_capabilities=list(dict.fromkeys(caps))[:5]
        r.selected_agents=[x for x in r.selected_capabilities if self.index.get(x,{}).get('type')=='agent']
        r.risk_tier=_risk(low,intent); r.state_trace += ['RISK','CAPABILITY']
        # Compound tasks become explicit bounded workstreams rather than unconstrained fan-out.
        if re.search(r'\b(and|then|plus|also)\b',low) and intent!='communication':
            r.workstreams=[{'id':f'{task_id}-WS1','purpose':task_class,'capabilities':r.selected_capabilities[:3]}]
            r.reason_codes.append('COMPOUND_TASK_BOUNDED')
        closure=self.closer.close(r.selected_capabilities)
        r.selected_references=closure['references'];r.dependency_closure_status=closure['status'];r.missing_dependencies=closure['missing'];r.state_trace.append('DEPENDENCY_CLOSURE'); r.reason_codes.append(f'GRAPH_DEPTH:{closure.get("graph_depth",0)}')
        if closure['status']!='COMPLETE': r.escalation='dependency-fail-closed';r.reason_codes.append('DEPENDENCY_CLOSURE_INCOMPLETE');r.state_trace.append('STOP')
        else:r.state_trace += ['WORKSTREAM','ECONOMY','ROUTE_QA']
        return r
