"""GCAE 14.5.0-rc3 REFERENCE MODEL of the execution controller. NOT the enforcement authority:
the single runtime authority is hooks/gcae_guard.py. Retained for the preserved regression and conformance suites."""
from __future__ import annotations
from dataclasses import dataclass,field
from enum import Enum
from pathlib import Path
import yaml, hashlib, json, time, re
class State(str,Enum): INIT='INIT'; INGRESS='INGRESS'; PLANNED='PLANNED'; AUTHORIZED='AUTHORIZED'; RUNNING='RUNNING'; AMBER='AMBER'; RED='RED'; STOP='STOP'
class ControlStop(RuntimeError): pass
@dataclass
class RuntimeState:
    root:Path
    session_id:str='unknown'; run_id:int=1; state:State=State.INIT; tool_count:int=0; agent_count:int=0; depth:int=0; no_progress:int=0; stop_reason:str=''; authorized_scope:str=''; history:list=field(default_factory=list); recent_fingerprints:list=field(default_factory=list); cycle_fingerprints:list=field(default_factory=list); last_progress=None
    def __post_init__(self):
        p=yaml.safe_load((Path(self.root)/'core/policy/execution-thresholds.yaml').read_text()); self.policy=p
    @property
    def max_tools(self): return self.policy['execution']['tool_call_hard_limit']
    @property
    def warn_tools(self): return self.policy['execution']['tool_call_warning']
    @property
    def max_agents(self): return self.policy['execution']['agent']['active_hard_limit']
    @property
    def max_depth(self): return self.policy['execution']['agent']['delegation_depth']
    def stop(self,reason): self.state=State.STOP; self.stop_reason=reason; return self.state
    def authorize(self,scope):
        if not scope or not scope.strip(): return self.stop('AUTHORIZED_SCOPE_MISSING')
        self.authorized_scope=scope.strip(); self.state=State.AUTHORIZED; return self.state
    def _fp(self,v): return hashlib.sha256(json.dumps(v,sort_keys=True,default=str,separators=(',',':')).encode()).hexdigest()
    def check_scope(self,action):
        if self.state==State.STOP: return self.stop_reason
        decision = self.classify_scope(action)
        if decision=='OUTSIDE': return self.stop('SCOPE_DRIFT')
        if decision=='ADJACENT': return self.stop('SCOPE_APPROVAL_REQUIRED')
        return None
    def classify_scope(self, action):
        # The task envelope is authoritative. A caller-supplied decision may only
        # confirm an already computed classification; it cannot expand scope.
        if not isinstance(action,dict): return 'OUTSIDE'
        explicit=action.get('scope_decision')
        if explicit in {'OUTSIDE','ADJACENT','WITHIN'}: return explicit
        target=str(action.get('authorized_scope','')).strip().casefold()
        operation=str(action.get('operation','')).strip().casefold()
        if not target or not operation: return 'OUTSIDE'
        # Conservative lexical containment; semantic expansion requires an upstream
        # task-envelope classifier and explicit approval.
        if operation in target: return 'WITHIN'
        return 'OUTSIDE'
    def _derive_tool_scope(self,tool,input_value):
        name=str(tool or '').casefold(); scope=self.authorized_scope.casefold()
        if any(x in name for x in ('read','glob','grep','search','fetch','list','notebook')): return 'WITHIN'
        if any(x in name for x in ('delete','remove','destroy','drop','reset','overwrite')): return 'ADJACENT'
        if any(x in name for x in ('edit','write','create')): return 'WITHIN' if any(x in scope for x in ('write','draft','edit','prepare','report','finding','workpaper','build','fix')) else 'ADJACENT'
        if any(x in name for x in ('bash','shell','python','terminal','command')): return 'WITHIN' if any(x in scope for x in ('audit','analy','reconcil','test','build','inspect','research')) else 'ADJACENT'
        return 'ADJACENT'
    def tool(self,tool,input_value,scope_decision=None,result=None,meaningful_progress=True):
        if self.state==State.STOP: return self.state
        decision=scope_decision if scope_decision in {'OUTSIDE','ADJACENT','WITHIN'} else self._derive_tool_scope(tool,input_value)
        self.check_scope({'scope_decision':decision})
        if self.state==State.STOP: return self.state
        self.depth=max(self.depth,0)
        if self.depth>self.max_depth: return self.stop('DEPENDENCY_DEPTH_LIMIT')
        if self.tool_count>=self.max_tools: return self.stop('TOOL_CALL_LIMIT')
        exact=self._fp({'tool':tool,'input':input_value}); norm=self._fp({'tool':tool,'input':self._normalize(input_value)})
        self.recent_fingerprints.append((exact,norm)); self.recent_fingerprints=self.recent_fingerprints[-24:]
        self.cycle_fingerprints.append(norm); self.cycle_fingerprints=self.cycle_fingerprints[-24:]
        exact_n=sum(1 for x,_ in self.recent_fingerprints[-self.policy['execution']['repeated_call']['exact_threshold']: ] if x==exact)
        norm_n=sum(1 for _,x in self.recent_fingerprints[-self.policy['execution']['repeated_call']['normalized_threshold']: ] if x==norm)
        if exact_n>=self.policy['execution']['repeated_call']['exact_threshold']: return self.stop('REPETITIVE_TOOL_LOOP')
        if norm_n>=self.policy['execution']['repeated_call']['normalized_threshold']: return self.stop('REPETITIVE_NORMALIZED_TOOL_LOOP')
        if self._cycle_detected(): return self.stop('CYCLIC_TOOL_LOOP')
        self.tool_count+=1
        if result is not None:
            pf=self._fp(self._progress(result))
            if pf==self.last_progress: self.no_progress+=1
            else:
                self.no_progress=0; self.last_progress=pf
                # A meaningful result starts a new repeat episode. Historical execution
                # remains in the state trace, but stale repeat counters cannot poison
                # subsequent legitimate audit iterations.
                self.recent_fingerprints=[]
            if self.no_progress>=self.policy['execution']['no_progress']['threshold']: return self.stop('NO_PROGRESS_THRESHOLD')
        self.state=State.AMBER if self.tool_count>=self.warn_tools else State.RUNNING
        return self.state
    def _normalize(self,v,field=None):
        if isinstance(v,dict): return {str(k):self._normalize(val,str(k)) for k,val in sorted(v.items(),key=lambda kv:str(kv[0]))}
        if isinstance(v,list): return [self._normalize(x,field) for x in v]
        if isinstance(v,str):
            x=' '.join(v.strip().split())
            if field in {'query','search_query','search_term','pattern'}: x=x.casefold()
            return x
        return v
    def _progress(self,v):
        volatile={'timestamp','ts','attempt','request_id','tool_use_id','elapsed','latency_ms'}
        if isinstance(v,dict): return {k:self._progress(x) for k,x in sorted(v.items()) if k not in volatile}
        if isinstance(v,list): return [self._progress(x) for x in v]
        return v
    def _cycle_detected(self):
        seq=list(self.cycle_fingerprints)
        maxlen=min(6,len(seq)//2)
        for k in range(2,maxlen+1):
            if seq[-k:]==seq[-2*k:-k] and seq[-k:]: return True
        return False
    def agent_start(self,depth=1,scope_decision=None):
        if self.state==State.STOP: return self.state
        if scope_decision is None: scope_decision='WITHIN'
        if scope_decision!='WITHIN': return self.stop('SCOPE_DRIFT' if scope_decision=='OUTSIDE' else 'SCOPE_APPROVAL_REQUIRED')
        if depth>self.max_depth: return self.stop('DEPENDENCY_DEPTH_LIMIT')
        if self.agent_count>=self.max_agents: return self.stop('AGENT_LIMIT')
        self.agent_count+=1; self.depth=max(self.depth,depth); self.state=State.RUNNING; return self.state
    def agent_stop(self): self.agent_count=max(0,self.agent_count-1); self.depth=0 if self.agent_count==0 else self.depth; return self.state
