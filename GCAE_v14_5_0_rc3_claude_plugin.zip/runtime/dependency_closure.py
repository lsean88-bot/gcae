"""Complete transitive capability dependency closure; graph depth is not delegation depth."""
from __future__ import annotations
from pathlib import Path
import json
class DependencyClosureError(RuntimeError): pass
class DependencyClosure:
 def __init__(self,root):
  self.root=Path(root); self.index=json.loads((self.root/'core/capability-index.json').read_text()); self.nodes=set(self.index)
 def _exists(self,cid):
  n=self.index.get(cid)
  return bool(n and (not n.get('file') or (self.root/n['file']).exists()))
 def close(self,requested):
  requested=list(dict.fromkeys(requested or [])); missing=[]; visited=set(); active=set(); caps=[]; agents=[]; refs=[]; graph_depth=0
  def visit(cid,depth,path):
   nonlocal graph_depth
   graph_depth=max(graph_depth,depth)
   if cid in active: raise DependencyClosureError('CAPABILITY_DEPENDENCY_CYCLE:'+'>'.join(path+[cid]))
   if cid in visited:return
   if cid not in self.nodes: missing.append('UNKNOWN:'+cid); return
   if not self._exists(cid): missing.append('FILE:'+cid); return
   active.add(cid); n=self.index[cid]; visited.add(cid)
   typ=n.get('type')
   if typ=='agent': agents.append(cid)
   elif typ=='reference': refs.append(cid)
   else: caps.append(cid)
   for dep in n.get('dependencies',[]) or []: visit(dep,depth+1,path+[cid])
   active.remove(cid)
  for cid in requested: visit(cid,0,[])
  missing=list(dict.fromkeys(missing)); status='COMPLETE' if requested and not missing else ('INVALID' if missing else 'INCOMPLETE')
  return {'status':status,'capabilities':list(dict.fromkeys(caps)),'agents':list(dict.fromkeys(agents)),'references':list(dict.fromkeys(refs)),'missing':missing,'graph_depth':graph_depth}
