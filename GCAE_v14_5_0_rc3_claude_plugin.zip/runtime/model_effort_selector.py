"""GCAE 14.5.0-rc3 minimum-sufficient model/effort selector.
Selection is advisory within the authoritative economy policy; it never overrides risk,
scope, evidence or runtime controls. Actual provider telemetry is required for validation.
"""
import re
LADDER=['SONNET_LOW','SONNET_MEDIUM','SONNET_HIGH','OPUS_MEDIUM','OPUS_HIGH']
def _active(text): return re.sub(r'("(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'|`[^`]*`)',' ',text.lower())
def select(workload:str, risk:str='L2', intent:str|None=None):
    w=_active(workload)
    if intent=='communication' or any(x in w for x in ['format only','formatting','rewrite','rephrase','proofread','grammar only']): return 'SONNET_LOW'
    if intent=='build_qa' and any(x in w for x in ['architecture','plugin','uat','misfire','routing','regression']): return 'SONNET_HIGH'
    if any(x in w for x in ['forensic reconstruction','forensic analysis','forensic','price inflation','nominee payment reconstruction']): return 'OPUS_HIGH'
    if any(x in w for x in ['fraud investigation','investigation','conflict of interest','coi','duplicate billing']): return 'OPUS_MEDIUM'
    if any(x in w for x in ['regulatory research','legal research','legal conclusion','vat refund','statutory provision']): return 'SONNET_HIGH'
    if any(x in w for x in ['complex reconciliation','compound audit','cross-domain','complex finding']): return 'SONNET_HIGH'
    if risk=='L4': return 'OPUS_MEDIUM'
    if risk=='L3': return 'SONNET_HIGH'
    return 'SONNET_MEDIUM'
