"""Release identity and package-integrity authority for GCAE v14.5.0-rc3."""
from pathlib import Path
import json,hashlib
VERSION='14.5.0-rc3'
def verify_identity(root):
 root=Path(root); ids=[]
 plugin=json.loads((root/'.claude-plugin/plugin.json').read_text())['version']; ids.append(plugin)
 manifest=json.loads((root/'RELEASE_MANIFEST.json').read_text())['version']; ids.append(manifest)
 policy=json.loads((root/'core/policy/execution-thresholds.json').read_text())['version']; ids.append(policy)
 if ids != [VERSION,VERSION,VERSION]: raise RuntimeError('ACTIVE_VERSION_AUTHORITY_CONFLICT:'+','.join(ids))
 return True
def package_hashes(root,exclude=None):
 root=Path(root); exclude=set(exclude or {'BUILD_HASHES_V14.5.0.sha256'}); out=[]
 for p in sorted(root.rglob('*')):
  if p.is_file() and p.name not in exclude and '__pycache__' not in p.parts and not p.name.endswith('.pyc'):
   h=hashlib.sha256(p.read_bytes()).hexdigest(); out.append((str(p.relative_to(root)).replace('\\','/'),h))
 return out
