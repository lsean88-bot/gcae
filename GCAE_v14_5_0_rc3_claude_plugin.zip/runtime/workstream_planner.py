"""Bounded workstream planner; it does not authorize execution."""
from dataclasses import dataclass
@dataclass
class Workstream:
    id:str
    capability_ids:list
    sequence:list
    parallel_limit:int=5
    scope:str=''
    def validate(self):
        if len(self.capability_ids)>5: raise ValueError('WORKSTREAM_AGENT_LIMIT')
        if not self.scope.strip(): raise ValueError('AUTHORIZED_SCOPE_REQUIRED')
        return True
