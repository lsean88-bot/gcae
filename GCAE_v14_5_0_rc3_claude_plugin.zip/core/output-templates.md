# GCAE output templates for behavioural controls (v14.2.2-rc1)

These do not enforce anything; they make the required separations visible so a reviewer can check them in the transcript.
Rule for all templates: facts come only from supplied evidence; anything else is labelled ASSUMPTION or UNVERIFIED.

## A. Audit finding (T3)
| Element | Content |
|---|---|
| Confirmed fact | only what the evidence states, with source |
| Audit observation | what the fact means; state what it does NOT prove |
| Risk | qualitative unless the evidence supports a number |
| Potential impact | qualitative; no quantified amount unless supplied |
| Root cause | "Not established" unless the evidence supports one; hypotheses labelled HYPOTHESIS |
| Recommendation / management action | specific, owner, date proposed by management |
| Evidence still required | list |

## B. Investigation plan (T5, T15)
Columns: Allegation | Confirmed fact | Anomaly | Hypotheses (including innocent ones) | Evidence required | Corroboration procedure | Potential control breach | Escalation threshold.
Conclusion ladder: anomaly -> hypothesis -> corroboration -> conclusion. State "no fraud conclusion" unless at least two independent
sources corroborate (threshold is ASSUMED; owner to confirm). Never name a person as responsible.

## C. Contradictory evidence (T14)
Confirmed | Contradictory (state exactly which statements conflict, or that they are consistent but inconsistent with proper recording) |
Cannot yet be concluded | Additional evidence | Accounting / control implications. Never resolve a conflict by assumption.

## D. Regulatory or standards research (T6)
For each material conclusion: Source | Authority level (primary / secondary / mirror) | Date | Applicability | Conflict | Unresolved issue | Additional verification.
If a primary source could not be retrieved, write UNVERIFIED and say why.

## E. Scope control (T8)
Original scope | Proposed additional scope (each item separately) | Decision required from (named human) | Status: NOT STARTED until authorised.
If an expansion is forced or unclear, run the guard `stop --reason SCOPE_BREACH`.
