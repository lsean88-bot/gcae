#!/usr/bin/env bash
# Portable launcher (Windows Git Bash / macOS / Linux).
# Tool calls fail closed (exit 2) whenever the guard cannot run. The HUMAN'S OWN MESSAGE is never blocked because the guard
# cannot start: for prompt and lifecycle events the user gets a visible warning and the message goes through.
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INPUT=""
if [ "$1" = "hook" ]; then INPUT="$(cat)"; fi
for PY in python3 python "py -3"; do
  if command -v "${PY%% *}" >/dev/null 2>&1; then
    if ${PY} -c "import sys; sys.exit(0 if sys.version_info>=(3,8) else 1)" >/dev/null 2>&1; then
      if [ "$1" = "hook" ]; then printf '%s' "$INPUT" | ${PY} "$HERE/gcae_guard.py" "$@"; exit $?; fi
      exec ${PY} "$HERE/gcae_guard.py" "$@"
    fi
  fi
done
echo "GCAE guard cannot run: Python >= 3.8 not found." >&2
if [ "$1" = "hook" ]; then
  case "$INPUT" in
    *'"hook_event_name":"PreToolUse"'*|*'"hook_event_name": "PreToolUse"'*) echo "Failing closed: tool calls are blocked." >&2; exit 2 ;;
    *'"hook_event_name":"UserPromptSubmit"'*|*'"hook_event_name": "UserPromptSubmit"'*|*'"hook_event_name":"SessionStart"'*|*'"hook_event_name": "SessionStart"'*|*'"hook_event_name":"Stop"'*|*'"hook_event_name": "Stop"'*|*'"hook_event_name":"PostToolUse"'*|*'"hook_event_name": "PostToolUse"'*|*'"hook_event_name":"SessionEnd"'*|*'"hook_event_name": "SessionEnd"'*|*'"hook_event_name":"SubagentStop"'*|*'"hook_event_name": "SubagentStop"'*)
      printf '%s' '{"systemMessage":"GCAE guard cannot run: Python 3.8+ was not found. Tool calls are blocked until it is installed; your message was NOT blocked."}'; exit 0 ;;
  esac
fi
echo "Failing closed." >&2
exit 2
