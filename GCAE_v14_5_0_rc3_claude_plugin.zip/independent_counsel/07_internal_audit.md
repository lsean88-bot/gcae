# Independent Counsel — Internal audit / IIA

**Specialisation:** Internal audit / IIA
**Review focus:** independence, assurance vs advisory, governance safeguards

## Mandatory questions
- What can fail silently?
- What can fail open?
- What can regress while tests still pass?
- What must be deterministic rather than model-dependent?
- What evidence is required before acceptance?

## Required disposition
1. Red flags
2. Root causes
3. Required design controls
4. Required tests
5. Release-blocking conditions
