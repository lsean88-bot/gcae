# Independent Specialist Counsel Synthesis — GCAE v14.4.0

## Executive conclusion
The v14.4.0 rebuild should be treated as a **release candidate, not production accepted**. The architecture can be made materially stronger than v14.3.2 without reducing the 100-capability / 45-agent payload. The dominant historical defects were not individual regex defects; they were **authority fragmentation, runtime-boundary ambiguity, state-episode contamination, release-identity drift, and insufficient evidence of the actual Claude Code adapter contract**.

## Counsel consensus — root causes and solutions

| Counsel | Specialisation | Root cause | Required solution | Acceptance test |
|---|---|---|---|---|
| 01 | Runtime control | Multiple control points / implicit authority | One deterministic controller + terminal STOP + human restart | state-machine exhaustive traces |
| 02 | Claude Code adapter | Provider payload shape assumptions | Exact structured enum support; no arbitrary text scanning | native-payload simulation + live UAT |
| 03 | Routing | Content terms could override task intent | intent-first precedence; communication exclusivity; bounded compound workstreams | golden + adversarial routing |
| 04 | Dependency | Graph and runtime delegation depth conflated | independent transitive closure with cycle/missing-node detection | graph mutation + closure oracle |
| 05 | Evidence | Model output could be mistaken for evidence | evidence object lifecycle + provenance + corroboration | evidence-integrity mutation tests |
| 06 | Fraud | Investigation may over-conclude from one source | minimum independent corroboration + human review | fraud scenarios |
| 07 | Internal Audit | Assurance/advisory independence risk | explicit IA independence invariant and no management ownership | governance oracle |
| 08 | Security | Prompt injection / malicious tools can attempt control bypass | model never authorises scope, STOP, release or evidence | adversarial injection suite |
| 09 | Economy | Cost/telemetry can be absent or fabricated | observed/partial/unavailable semantics; no invented cost | telemetry mutation + real provider evidence |
| 10 | Software QA | stale tests and version drift can certify wrong artifact | authoritative test constitution + release identity validator | package QA + mutation |
| 11 | Release governance | candidate can silently regress baseline controls | regression-preservation gate; cryptographic manifest; trusted root | three-way baseline/candidate diff |
| 12 | Audit lifecycle | control hardening must not remove useful audit capability | preserve all 100 capabilities / 45 agents and lifecycle engine | capability coverage + golden use cases |

## Red flags that remain release-blocking
1. Actual Claude Code target-runtime event/permission semantics have not been demonstrated in this environment.
2. Real model/effort/token/cost telemetry is provider/runtime dependent and remains unobserved until live UAT.
3. Production acceptance must remain outside builder self-certification.
4. Any future release that deletes or silently disables an accepted control must fail the release gate.

## Design principle
**Safety controls are deterministic; specialist intelligence is delegated.** The model may propose, classify and analyse, but cannot authorise its own scope, restart a stopped run, certify evidence, override release gates or expand delegation beyond the controller's limits.
