# Independent Counsel Constitution — GCAE v14.4.0

Counsel is independent of the build authority. No counsel file may certify production acceptance. Counsel reviews control design, failure modes, regression, and evidence sufficiency.

## Non-waivable positions
- No silent fail-open control.
- No model-only authority for scope, STOP, evidence integrity or release identity.
- No fabricated telemetry or cost.
- No accepted capability may disappear without documented equivalence or approved retirement.
- No live-runtime claim without actual target-runtime evidence.
