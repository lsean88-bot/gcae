# Independent Counsel — Runtime control / state machine

**Specialisation:** Runtime control / state machine
**Review focus:** single enforcement point, terminal STOP, restart, state integrity

## Mandatory questions
- What can fail silently?
- What can fail open?
- What can regress while tests still pass?
- What must be deterministic rather than model-dependent?
- What evidence is required before acceptance?

## Required disposition
1. Red flags
2. Root causes
3. Required design controls
4. Required tests
5. Release-blocking conditions
