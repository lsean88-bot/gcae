# Release Manifest Trust Boundary

The release manifest is a controlled release artifact, not ordinary documentation.

## Trust rule

`RELEASE_MANIFEST.json` is excluded from the package-content hash to avoid recursive hashing. It is therefore protected by a **canonical manifest anchor** calculated from the manifest after removing the self-referential release-manifest hash and external-anchor fields. The resulting digest is recorded in the external trusted-root sidecar.

## Release gate

A release passes only when all of the following match the external trusted root:

- package content SHA-256;
- canonical release-manifest anchor SHA-256;
- canonical capability registry SHA-256;
- test registry SHA-256;
- oracle manifest SHA-256;
- required counts and release-state constraints.

Changing `RELEASE_MANIFEST.json` without updating the separately protected external trusted root must fail release QA.

## Limitation

The trusted root itself must be protected outside the package under independent release governance. This package cannot authenticate its own external trust anchor.
