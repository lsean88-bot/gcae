#!/usr/bin/env python3
"""GCAE v14.4.0 Claude Code enforcement hook.
The hook is fail-closed, episode-aware and trusts only explicit structured provider fields.
"""
from __future__ import annotations
import hashlib,json,os,sys,tempfile,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
RESTART='/gcae-enterprise-assurance-risk:restart'; STATUS='/status'; SCHEMA='gcae.execution-status.v14.4.0'
from runtime.claude_code_adapter import normalize as normalize_provider_event
from runtime.scope import classify,tool_class

def policy():
 d=json.loads((ROOT/'core/policy/execution-thresholds.json').read_text());x=d['execution']
 return {'MAX_TOOLS':int(x['tool_call_hard_limit']),'WARN_TOOLS':int(x['tool_call_warning']),'MAX_AGENTS':int(x['agent']['active_hard_limit']),'MAX_DEPTH':int(x['agent']['delegation_depth']),'REPEAT':int(x['repeated_call']['exact_threshold']),'NORM_REPEAT':int(x['repeated_call']['normalized_threshold']),'NO_PROGRESS':int(x['no_progress']['threshold']),'MAX_CYCLE':int(x['cyclic_loop']['max_cycle_length'])}
P=policy()
def root(): return Path(os.environ.get('GCAE_RUNTIME_DIR',Path(tempfile.gettempdir())/'gcae-runtime'))
def safe(v): return ''.join(c for c in str(v or 'unknown') if c.isalnum() or c in '-_')[:80] or 'unknown'
def paths(s):
 r=root();r.mkdir(parents=True,exist_ok=True);return r/f'{s}.status.json',r/f'{s}.jsonl',r/f'{s}.lock',r/f'{s}.history.jsonl'
def acquire(p):
 deadline=time.time()+3
 while True:
  try:p.mkdir();return
  except FileExistsError:
   if time.time()>=deadline:raise RuntimeError('STATE_LOCK_FAILURE')
   time.sleep(.01)
def release(p):
 try:p.rmdir()
 except OSError:pass
def state0(s,run=1):return {'schema':SCHEMA,'session_id':s,'run_id':run,'state':'RUNNING','tool_count':0,'agent_count':0,'events':0,'last_event':None,'last_event_ts':time.time(),'last_progress':None,'no_progress_events':0,'exact':{},'normalized':{},'recent':[],'cycle_recent':[],'episode':{'id':1,'tool_count':0,'progress_count':0},'stop_reason':None,'stop_ts':None,'controlled_run':True,'telemetry_state':'UNAVAILABLE','telemetry':{},'task_envelope':None,'agent_depths':{}}
def load(p,s):
 if not p.exists():return state0(s)
 try:
  d=json.loads(p.read_text())
  if d.get('schema')!=SCHEMA or d.get('session_id')!=s:raise ValueError
  return d
 except Exception:raise RuntimeError('STATUS_STATE_CORRUPT')
def save(p,s):
 t=p.with_suffix('.tmp');t.write_text(json.dumps(s,indent=2,sort_keys=True));os.replace(t,p)
def emit(msg=None,deny=False,stop=False,reason=None):
 o={}
 if msg:o['systemMessage']=msg
 if stop:o.update({'continue':False,'stopReason':reason or msg or 'GCAE CONTROL STOP'})
 if deny:o['hookSpecificOutput']={'hookEventName':'PreToolUse','permissionDecision':'deny','permissionDecisionReason':reason or msg or 'GCAE CONTROL STOP'}
 if o:print(json.dumps(o,separators=(',',':')))
def fp(v):return hashlib.sha256(json.dumps(v,sort_keys=True,ensure_ascii=False,default=str,separators=(',',':')).encode()).hexdigest()
def norm(v,field=None):
 if isinstance(v,dict):return {str(k):norm(x,str(k)) for k,x in sorted(v.items(),key=lambda kv:str(kv[0]))}
 if isinstance(v,list):return [norm(x,field) for x in v]
 if isinstance(v,str):
  x=' '.join(v.strip().split());return x.casefold() if field in {'query','search_query','search_term','pattern'} else x
 return v
def progress(v):
 if isinstance(v,dict):return {k:progress(x) for k,x in sorted(v.items()) if k not in {'timestamp','ts','attempt','request_id','tool_use_id','elapsed','latency_ms'}}
 if isinstance(v,list):return [progress(x) for x in v]
 return v
def record_telemetry(s,data):
 ev=normalize_provider_event(data); fields=['model','effort','input_tokens','output_tokens','cache_read_tokens','cache_creation_tokens','latency_ms','cost_usd','cost_basis']
 vals={k:getattr(ev,k) for k in fields if getattr(ev,k) is not None}
 if vals:s['telemetry'].update(vals)
 req=['model','effort','input_tokens','output_tokens','latency_ms','cost_usd'];present=sum(s['telemetry'].get(k) is not None for k in req)
 s['telemetry_state']='OBSERVED' if present==len(req) else ('PARTIAL' if present else 'UNAVAILABLE')
 return ev
def is_agent_spawn(data): return tool_class(data.get('tool_name'))=='AGENT'
def requested_depth(s,data):
 supplied=data.get('delegation_depth',data.get('depth'))
 if supplied is not None:
  try:return int(supplied)
  except:return P['MAX_DEPTH']+1
 parent=str(data.get('parent_agent_id') or data.get('parent_tool_use_id') or '')
 return int(s.get('agent_depths',{}).get(parent,0))+1 if parent else 1
def human_restart(s,h,p):
 old=s.get('run_id',1);h.open('a').write(json.dumps({'ts':time.time(),'event':'HUMAN_RESTART','previous_run_id':old,'previous_stop_reason':s.get('stop_reason')})+'\n');n=state0(s['session_id'],old+1);n['previous_run_id']=old;n['previous_stop_reason']=s.get('stop_reason');save(p,n);return n
def stop(s,reason):s.update(state='STOP',stop_reason=reason,stop_ts=time.time())
def main():
 try:data=json.load(sys.stdin)
 except Exception:
  emit('GCAE CONTROL STOP — invalid hook input.',True,True,'INVALID_HOOK_INPUT');return 2
 if not isinstance(data,dict): emit('GCAE CONTROL STOP — invalid hook input.',True,True,'INVALID_HOOK_INPUT');return 2
 sess=safe(data.get('session_id'));status,log,lock,hist=paths(sess)
 try:acquire(lock)
 except Exception:emit('GCAE CONTROL STOP — state lock unavailable.',True,True,'STATE_LOCK_FAILURE');return 2
 try:
  try:s=load(status,sess)
  except RuntimeError as e:
   s=state0(sess);stop(s,str(e));s['telemetry_state']='INVALID';save(status,s);emit('GCAE CONTROL STOP — state untrusted.',True,True,str(e));return 2
  event=str(data.get('hook_event_name') or data.get('event') or 'UNKNOWN');prompt=data.get('prompt') or data.get('user_prompt') or ''
  if event=='UserPromptSubmit' and isinstance(prompt,str) and prompt.strip()==RESTART:
   if s['state']=='STOP':s=human_restart(s,hist,status);emit(f'GCAE HUMAN RESTART AUTHORIZED — run_id={s["run_id"]}; STOP history retained.')
   else:emit('GCAE RESTART IGNORED — run is not stopped.')
   return 0
  if event=='UserPromptSubmit' and isinstance(prompt,str) and prompt.strip() in {STATUS,'/gcae-enterprise-assurance-risk:status'}:
   emit(f"GCAE STATUS: {s['state']} | run_id={s['run_id']} | tools={s['tool_count']} | agents={s['agent_count']} | telemetry={s.get('telemetry_state','UNKNOWN')}");return 0
  if event=='UserPromptSubmit' and isinstance(prompt,str) and prompt.strip() and s.get('state')!='STOP':
   req=prompt.strip(); allowed=[]
   words=req.casefold()
   if any(x in words for x in ('write','draft','rewrite','edit','create','update','build','fix','prepare','package','rebuild','report','workpaper','finding')): allowed += ['write','draft','rewrite','edit','create','update','build','fix','prepare','package','report','workpaper','finding']
   if any(x in words for x in ('run','execute','test','validate','inspect','analyse','analyze','audit','reconcile','research','debug','build','package')): allowed += ['run','execute','test','validate','inspect','analyse','analyze','audit','reconcile','research','debug','build','package']
   s['task_envelope']={'request':req,'authorized_scope':str(data.get('authorized_scope') or req),'evidence_boundary':str(data.get('evidence_boundary') or 'task-scoped'),'allowed_operations':list(dict.fromkeys(allowed)),'allow_delegation':True,'created_ts':time.time()}
  s['events']+=1;s['last_event']=event;s['last_event_ts']=time.time();record_telemetry(s,data)
  if event=='StopFailure':
   failure=normalize_provider_event(data).failure_code
   if failure:stop(s,f'NATIVE_STOP_FAILURE:{failure}');s['provider_failure']=failure;hist.open('a').write(json.dumps({'ts':time.time(),'event':event,'reason':failure})+'\n')
   save(status,s);return 0
  if s['state']=='STOP':
   emit(f"GCAE STATUS: STOPPED | run_id={s['run_id']} | reason={s.get('stop_reason')} | explicit restart required.",deny=event=='PreToolUse',stop=event!='PreToolUse',reason=s.get('stop_reason'));return 0
  if event=='PreToolUse':
   if is_agent_spawn(data):
    depth=requested_depth(s,data)
    if s['agent_count']>=P['MAX_AGENTS']:stop(s,'AGENT_LIMIT')
    elif depth>P['MAX_DEPTH']:stop(s,'DEPENDENCY_DEPTH_LIMIT')
    else:
     s['agent_count']+=1; aid=str(data.get('agent_id') or data.get('subagent_id') or data.get('agent_name') or f'agent-{s["agent_count"]}');s.setdefault('agent_depths',{})[aid]=depth
   if s['state']=='STOP':save(status,s);emit('GCAE CONTROL STOP — agent/delegation limit.',True,True,s['stop_reason']);return 0
   if s['tool_count']>=P['MAX_TOOLS']:stop(s,'TOOL_CALL_LIMIT')
   else:
    scope=classify(s.get('task_envelope'),data)
    if scope=='OUTSIDE':stop(s,'SCOPE_DRIFT')
    elif scope=='ADJACENT':stop(s,'SCOPE_APPROVAL_REQUIRED')
    else:
     tool=data.get('tool_name');inp=data.get('tool_input');e=fp({'tool':tool,'input':inp});n=fp({'tool':tool,'input':norm(inp)})
     s['recent']=(s.get('recent',[])+[n])[-24:];s['cycle_recent']=(s.get('cycle_recent',[])+[n])[-24:];s['exact'][e]=s['exact'].get(e,0)+1;s['normalized'][n]=s['normalized'].get(n,0)+1
     if s['exact'][e]>=P['REPEAT']:stop(s,'REPETITIVE_TOOL_LOOP')
     elif s['normalized'][n]>=P['NORM_REPEAT']:stop(s,'REPETITIVE_NORMALIZED_TOOL_LOOP')
     else:
      for k in range(2,min(P['MAX_CYCLE'],len(s['cycle_recent'])//2)+1):
       if s['cycle_recent'][-k:]==s['cycle_recent'][-2*k:-k]:stop(s,'CYCLIC_TOOL_LOOP');break
     if s['state']!='STOP':s['tool_count']+=1;s['episode']['tool_count']+=1
   if s['state']=='STOP':save(status,s);emit('GCAE CONTROL STOP — bounded execution control.',True,True,s['stop_reason']);return 0
  elif event=='SubagentStart':
   # SubagentStart is tracked for telemetry; PreToolUse Task is the authoritative blocking boundary.
   parent=str(data.get('parent_agent_id') or data.get('parent_tool_use_id') or '');aid=str(data.get('agent_id') or data.get('subagent_id') or data.get('agent_name') or f'agent-{s["agent_count"]+1}')
   depth=requested_depth(s,data)
   if depth>P['MAX_DEPTH'] or s['agent_count']>=P['MAX_AGENTS']: s['subagent_observed_violation']=True
   else:s.setdefault('agent_depths',{})[aid]=depth
  elif event=='SubagentStop':
   aid=str(data.get('agent_id') or data.get('subagent_id') or data.get('agent_name') or '');s['agent_count']=max(0,s['agent_count']-1);s.get('agent_depths',{}).pop(aid,None)
  if event in {'PostToolUse','PostToolBatch','TaskCompleted','SubagentStop'}:
   result=data.get('tool_response') if event=='PostToolUse' else data.get('tool_results');q=fp(progress(result)) if result is not None else None
   if q and q==s.get('last_progress'):s['no_progress_events']+=1
   elif q:
    s['no_progress_events']=0;s['last_progress']=q;s['episode']={'id':s['episode']['id']+1,'tool_count':0,'progress_count':s['episode'].get('progress_count',0)+1};s['exact']={};s['normalized']={};s['recent']=[];s['cycle_recent']=[]
   if s['no_progress_events']>=P['NO_PROGRESS']:stop(s,'NO_PROGRESS_THRESHOLD');save(status,s);emit('GCAE CONTROL STOP — no meaningful progress.',True,True,'NO_PROGRESS_THRESHOLD');return 0
  s['state']='AMBER' if s['tool_count']>=P['WARN_TOOLS'] else 'RUNNING';save(status,s);log.open('a').write(json.dumps({'ts':time.time(),'event':event,'state':s['state'],'run_id':s['run_id'],'tool_count':s['tool_count'],'agent_count':s['agent_count'],'telemetry_state':s['telemetry_state']})+'\n');return 0
 finally:release(lock)
if __name__=='__main__':sys.exit(main())
