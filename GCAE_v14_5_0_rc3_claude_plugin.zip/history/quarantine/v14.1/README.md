# Quarantined v14.1 Static QA

This test targeted the v14.1 cross-platform package structure (`.codex-plugin`, `control/`, and `skills/target-runtime-uat/`).

It is retained for historical regression reference only and is not an acceptance test for the Claude Code v14.2.x plugin architecture.

Use the active v14.2.2 package QA and runtime-spec hardening tests instead.
