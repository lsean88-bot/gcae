from __future__ import annotations
import json, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
required = [
    '.codex-plugin/plugin.json','plugin.json','README.md',
    'control/execution-safety-policy.yaml',
    'skills/target-runtime-uat/SKILL.md',
    'runtime/openai_agents/adapter.py',
    'runtime/openai_agents/control.py',
    'runtime/openai_agents/guardrails.py',
    'runtime/openai_agents/live_uat.py',
    'tests/uat/benchmarks.json',
    'tests/cross_platform_oracle.py'
]
missing = [p for p in required if not (ROOT/p).exists()]
assert not missing, missing
meta = json.loads((ROOT/'plugin.json').read_text())
assert meta['version'] == '14.2.0'
bench = json.loads((ROOT/'tests/uat/benchmarks.json').read_text())
assert len(bench['workloads']) == 12
assert len(bench['required_metrics']) >= 15
assert bench['acceptance']['target_median_cost_reduction_vs_controlled_baseline'] == 0.25
print('V14.1 STATIC QA: PASS | required files | metadata | 12 workloads | acceptance oracle')
