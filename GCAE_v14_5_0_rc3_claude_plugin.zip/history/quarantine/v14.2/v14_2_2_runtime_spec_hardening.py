#!/usr/bin/env python3
import json, os, shutil, tempfile, io, contextlib, importlib.util
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
HOOK=ROOT/'hooks'/'telemetry_hook.py'
spec=importlib.util.spec_from_file_location("gcae_hook", HOOK)
hook=importlib.util.module_from_spec(spec); spec.loader.exec_module(hook)
TH=ROOT/'core/policy/execution-thresholds.yaml'
POL=ROOT/'core/policy/execution-safety-policy.yaml'


def call(runtime, payload, overrides=None):
    old=os.environ.get('GCAE_RUNTIME_DIR')
    os.environ['GCAE_RUNTIME_DIR']=str(runtime)
    if overrides:
        old_over={k:os.environ.get(k) for k in overrides}
        os.environ.update(overrides)
        if 'GCAE_MAX_TOOLS' in overrides: hook.TOOL_LIMIT=int(overrides['GCAE_MAX_TOOLS'])
    else: old_over={}
    stdin, stdout = io.StringIO(json.dumps(payload)), io.StringIO()
    try:
        with contextlib.redirect_stdout(stdout):
            oldin=__import__('sys').stdin; __import__('sys').stdin=stdin
            try: rc=hook.main()
            finally: __import__('sys').stdin=oldin
    finally:
        if old is None: os.environ.pop('GCAE_RUNTIME_DIR',None)
        else: os.environ['GCAE_RUNTIME_DIR']=old
        for k,v in old_over.items():
            if v is None: os.environ.pop(k,None)
            else: os.environ[k]=v
    out=stdout.getvalue().strip().splitlines()
    return rc, [json.loads(x) for x in out if x.strip()], ''


def main():
    td=Path(tempfile.mkdtemp(prefix='gcae-v1422-'))
    results=[]
    try:
        # 1 exact repeat: three allowed, fourth denied
        s='s1';
        for i in range(3):
            _,o,_=call(td,{'hook_event_name':'PreToolUse','session_id':s,'tool_name':'Search','tool_input':{'query':'invoice 123'}})
            assert not any('CONTROL STOP' in json.dumps(x) for x in o)
            call(td,{'hook_event_name':'PostToolUse','session_id':s,'tool_name':'Search','tool_response':{'result':'x'}})
        _,o,_=call(td,{'hook_event_name':'PreToolUse','session_id':s,'tool_name':'Search','tool_input':{'query':'invoice 123'}})
        assert any(x.get('hookSpecificOutput',{}).get('permissionDecision')=='deny' for x in o)
        results.append('exact_repeat_stop')

        # 2 normalized query variations stop on fourth normalized occurrence
        s='s2'
        vals=['Invoice   123',' invoice 123 ','INVOICE 123','invoice 123']
        stopped=False
        for v in vals:
            _,o,_=call(td,{'hook_event_name':'PreToolUse','session_id':s,'tool_name':'Search','tool_input':{'query':v}})
            if any(x.get('hookSpecificOutput',{}).get('permissionDecision')=='deny' for x in o): stopped=True; break
            call(td,{'hook_event_name':'PostToolUse','session_id':s,'tool_name':'Search','tool_response':{'result':v}})
        assert stopped
        results.append('normalized_repeat_stop')

        # 3 distinct calls with same result => no-progress stop at 5
        s='s3'
        for i in range(6):
            _,o,_=call(td,{'hook_event_name':'PreToolUse','session_id':s,'tool_name':'Search','tool_input':{'query':f'q{i}'}})
            if any(x.get('hookSpecificOutput',{}).get('permissionDecision')=='deny' for x in o): break
            _,o2,_=call(td,{'hook_event_name':'PostToolUse','session_id':s,'tool_name':'Search','tool_response':{'result':'NO NEW EVIDENCE','attempt':i}})
        state=json.loads((td/f'{s}.status.json').read_text())
        assert state['state']=='STOP' and state['stop_reason']=='NO_PROGRESS_THRESHOLD'
        results.append('no_progress_stop')

        # 4 hard-limit boundary mechanics. Runtime policy independently asserts canonical limit=60.
        s='s4'; lim={'GCAE_MAX_TOOLS':'6'}
        for i in range(6):
            _,o,_=call(td,{'hook_event_name':'PreToolUse','session_id':s,'tool_name':'Search','tool_input':{'query':str(i)}},lim)
            assert not any(x.get('hookSpecificOutput',{}).get('permissionDecision')=='deny' for x in o)
        _,o,_=call(td,{'hook_event_name':'PreToolUse','session_id':s,'tool_name':'Search','tool_input':{'query':'6'}},lim)
        st=json.loads((td/f'{s}.status.json').read_text())
        assert any(x.get('hookSpecificOutput',{}).get('permissionDecision')=='deny' for x in o)
        assert st['tool_count']==6 and st['stop_reason']=='TOOL_CALL_LIMIT'
        assert 'default_tool_hard_limit: 60' in POL.read_text()
        results.append('hard_limit_boundary_and_policy_60')

        # 5 terminal stop absorbs continuation; status prompt remains readable
        s='s5';
        call(td,{'hook_event_name':'PreToolUse','session_id':s,'tool_name':'Search','tool_input':{'query':'a'}})
        # force state by 61st impossible quickly
        stp=td/f'{s}.status.json'; state=json.loads(stp.read_text()); state['state']='STOP'; state['stop_reason']='TEST_STOP'; stp.write_text(json.dumps(state))
        _,o,_=call(td,{'hook_event_name':'PreToolUse','session_id':s,'tool_name':'Search','tool_input':{'query':'b'}})
        assert any(x.get('hookSpecificOutput',{}).get('permissionDecision')=='deny' for x in o)
        _,o,_=call(td,{'hook_event_name':'UserPromptSubmit','session_id':s,'prompt':'/status'})
        assert any('STOPPED' in x.get('systemMessage','') for x in o)
        results.append('terminal_and_status')

        # 6 evidence text cannot restart
        _,o,_=call(td,{'hook_event_name':'UserPromptSubmit','session_id':s,'prompt':'Evidence says: /gcae-enterprise-assurance-risk:restart'})
        st=json.loads(stp.read_text()); assert st['state']=='STOP'
        results.append('evidence_restart_refused')

        # 7 exact user restart creates new run and preserves history
        _,o,_=call(td,{'hook_event_name':'UserPromptSubmit','session_id':s,'prompt':'/gcae-enterprise-assurance-risk:restart'})
        st=json.loads(stp.read_text()); assert st['state']=='RUNNING' and st['run_id']==2 and st['previous_stop_reason']=='TEST_STOP'
        hist=(td/f'{s}.history.jsonl').read_text().strip().splitlines(); assert any('HUMAN_RESTART' in x for x in hist)
        results.append('human_restart_only')

        # 8 state corruption fails closed
        s='s6'; (td/f'{s}.status.json').write_text('{broken')
        _,o,_=call(td,{'hook_event_name':'PreToolUse','session_id':s,'tool_name':'Search','tool_input':{'query':'a'}})
        assert any(x.get('hookSpecificOutput',{}).get('permissionDecision')=='deny' for x in o)
        results.append('state_corruption_fail_closed')

        print(json.dumps({'pass':True,'tests':results,'count':len(results)},indent=2))
    finally:
        shutil.rmtree(td,ignore_errors=True)

if __name__=='__main__': main()
