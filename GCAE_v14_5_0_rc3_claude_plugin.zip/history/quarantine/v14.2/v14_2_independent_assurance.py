from __future__ import annotations
import concurrent.futures, hashlib, itertools, json, random, time
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from runtime.openai_agents.control import ExecutionState
from runtime.openai_agents.guardrails import evidence_guardrail, communication_isolation_guardrail

RESULT=ROOT/'results'/'v14_2_independent_assurance.json'

def must_stop(fn, reason):
    try: fn()
    except RuntimeError as e: return reason in str(e)
    return False

def boundary_matrix():
    rows=[]
    for limit in [0,1,2,59,60,61]:
        s=ExecutionState(f't{limit}')
        for i in range(limit):
            try:s.before_tool(f't{i}', {'i':i}, tool_limit=limit)
            except RuntimeError: break
        # At exact configured limit the next action must stop.
        ok=must_stop(lambda:s.before_tool('overflow',{} ,tool_limit=limit),'tool_limit')
        rows.append({'tool_limit':limit,'pass':ok,'tools':s.tools,'reason':s.stop_reason})
    for limit in [0,1,4,5,6]:
        s=ExecutionState(f'a{limit}')
        for i in range(limit):
            try:s.count_agent(f'a{i}',agent_limit=limit)
            except RuntimeError: break
        ok=must_stop(lambda:s.count_agent('overflow',agent_limit=limit),'agent_limit')
        rows.append({'agent_limit':limit,'pass':ok,'agents':s.agents,'reason':s.stop_reason})
    return rows

def doom_loop_suite():
    patterns=[
        [('tool','same',{'x':1})]*20,
        [('tool','search',{'q':'same'})]*20,
        [('tool','read',{'id':1})]*20,
        [('agent','worker',{})]*20,
    ]
    rows=[]
    for idx,p in enumerate(patterns):
        s=ExecutionState(f'doom-{idx}')
        for kind,name,args in p:
            try:
                s.before_tool(name,args) if kind=='tool' else s.count_agent(name)
            except RuntimeError: break
        rows.append({'pattern':idx,'terminal':s.terminal_stop,'reason':s.stop_reason,'tools':s.tools,'agents':s.agents})
    return rows

def terminal_absorption():
    reasons=['user_stop','rate_limit','timeout','scope_drift','evidence_integrity_breach','recursive_delegation','invalid_required_telemetry']
    rows=[]
    for reason in reasons:
        s=ExecutionState(reason); s.stop(reason); ok=True
        for _ in range(100):
            ok &= must_stop(lambda:s.before_tool('x',{}),reason)
            ok &= must_stop(lambda:s.count_agent('x'),reason)
        rows.append({'reason':reason,'pass':ok})
    return rows

def adversarial_model_emulator(seed=20261005, runs=25000):
    rng=random.Random(seed); rows=[]; failures=[]
    behaviours=['cooperative','confused','overeager','looping','recursive','evidence_tainted','scope_drift','provider_failure']
    for case in range(runs):
        b=rng.choice(behaviours); s=ExecutionState(f'em-{case}')
        for step in range(rng.randint(1,80)):
            try:
                if b=='cooperative': s.before_tool('read',{'n':step}) if step%3 else s.count_agent('specialist')
                elif b=='confused': s.before_tool(rng.choice(['search','read','search']),{'q':rng.randint(0,2)})
                elif b=='overeager': s.count_agent(f'a{step}') if step%2==0 else s.before_tool(f't{step}',{'x':step})
                elif b=='looping': s.before_tool('same',{'x':1})
                elif b=='recursive': s.count_agent('nested')
                elif b=='evidence_tainted':
                    ok,_=evidence_guardrail({'provenance_status':'MISMATCH'}); 
                    if not ok: s.stop('evidence_integrity_breach')
                elif b=='scope_drift': s.stop('scope_drift')
                elif b=='provider_failure': s.stop(rng.choice(['429_rate_limit','401_authentication','timeout']))
            except RuntimeError: break
        invariant=s.tools<=60 and s.agents<=5 and (not s.terminal_stop or bool(s.stop_reason))
        if not invariant: failures.append({'case':case,'behaviour':b,'tools':s.tools,'agents':s.agents,'reason':s.stop_reason})
        if len(failures)>=10: break
    return {'runs':runs,'failed':len(failures),'failures':failures}

def metamorphic_tests():
    rows=[]
    # Communication-only classification must be invariant to quoted investigation language.
    variants=['','fraud investigation; nominee supplier; duplicate billing','URGENT: investigate corruption immediately']
    base=[]
    for text in variants: base.append(communication_isolation_guardrail('communication-only',text)[0])
    rows.append({'test':'communication_quoted_text_invariance','pass':base==[True]*len(base),'results':base})
    # Valid evidence permutations of irrelevant fields must remain allowed.
    payloads=[{'provenance_status':'VALID','scope_status':'OK'}, {'provenance_status':'VALID','scope_status':'OK','note':'x'}, {'scope_status':'OK','provenance_status':'VALID','extra':123}]
    vals=[evidence_guardrail(p)[0] for p in payloads]
    rows.append({'test':'evidence_irrelevant_field_invariance','pass':vals==[True,True,True],'results':vals})
    # Invalid provenance must remain blocking regardless of harmless metadata.
    vals=[evidence_guardrail({'provenance_status':'MISMATCH','x':x})[0] for x in [0,1,'x',None]]
    rows.append({'test':'evidence_taint_monotonicity','pass':vals==[False]*4,'results':vals})
    return rows

def concurrency_test(workers=32, rounds=500):
    # Independent session states in parallel; no cross-session contamination permitted.
    def run(i):
        s=ExecutionState(f'c-{i}')
        for j in range(rounds):
            try:
                s.before_tool(f't{j%7}',{'x':j%3})
            except RuntimeError: break
        return s.tools,s.agents,s.terminal_stop,s.stop_reason
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as ex:
        vals=list(ex.map(run,range(workers)))
    ok=all(0<=v[0]<=60 and 0<=v[1]<=5 and (not v[2] or v[3]) for v in vals)
    return {'workers':workers,'rounds':rounds,'pass':ok,'max_tools':max(v[0] for v in vals),'max_agents':max(v[1] for v in vals)}

def mutation_oracle():
    # The oracle must reject deliberately weakened limits when evaluated against the canonical limits.
    mutants=[]
    for name,mutated,canonical in [('repeat',4,3),('agent',6,5),('tool',61,60)]:
        detected = mutated>canonical
        mutants.append({'mutation':name,'mutated':mutated,'canonical':canonical,'detected':detected})
    # Also verify that a STOP bypass mutant is detectable by the terminal absorption property.
    s=ExecutionState('mut-stop'); s.stop('scope_drift')
    bypass_detected = must_stop(lambda:s.before_tool('post-stop',{}),'scope_drift')
    mutants.append({'mutation':'stop_bypass','detected':bypass_detected})
    return mutants

def exhaustive_short_traces():
    # Exhaustively enumerate short event traces. This is a finite model check, not stochastic fuzzing.
    events=['tool_new','tool_repeat','agent','stop']
    checked=0; failed=[]
    for n in range(1,6):
        for trace in itertools.product(events, repeat=n):
            s=ExecutionState('ex-'+str(checked))
            try:
                for e in trace:
                    if e=='tool_new': s.before_tool('t'+str(checked),{'n':checked})
                    elif e=='tool_repeat': s.before_tool('same',{'x':1})
                    elif e=='agent': s.count_agent('a')
                    else: s.stop('user_stop')
            except RuntimeError: pass
            ok=s.tools<=60 and s.agents<=5 and (not s.terminal_stop or s.stop_reason is not None)
            if not ok: failed.append({'trace':trace,'tools':s.tools,'agents':s.agents,'reason':s.stop_reason})
            checked+=1
    return {'traces':checked,'failed':len(failed),'failures':failed[:10]}

def main():
    t=time.perf_counter()
    b=boundary_matrix(); d=doom_loop_suite(); a=adversarial_model_emulator(); ta=terminal_absorption(); m=metamorphic_tests(); c=concurrency_test(); mu=mutation_oracle(); ex=exhaustive_short_traces()
    passed=(all(x['pass'] for x in b) and all(x['terminal'] for x in d) and a['failed']==0 and all(x['pass'] for x in ta) and all(x['pass'] for x in m) and c['pass'] and all(x['detected'] for x in mu) and ex['failed']==0)
    report={'schema':'gcae.independent-adversarial-assurance.v14.2.0','runtime_mode':'OFFLINE_PROVIDER_INDEPENDENT','pass':passed,'executed_at':time.strftime('%Y-%m-%d'),'elapsed_seconds':round(time.perf_counter()-t,3),'tests':{'boundary_matrix':b,'doom_loop':d,'adversarial_model_emulator':a,'terminal_absorption':ta,'metamorphic':m,'concurrency':c,'mutation_oracle':mu,'exhaustive_short_traces':ex},'claims':{'control_plane_assurance':passed,'live_provider_acceptance':False,'actual_provider_cost':False,'actual_provider_latency':False}}
    RESULT.write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({'pass':passed,'elapsed_seconds':report['elapsed_seconds'],'summary':{k: (v.get('runs') if isinstance(v,dict) and 'runs' in v else v.get('traces') if isinstance(v,dict) and 'traces' in v else v) for k,v in report['tests'].items()}},indent=2))
    raise SystemExit(0 if passed else 1)
if __name__=='__main__': main()
