#!/usr/bin/env python3
import hashlib,json,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]
errors=[]
required=['.claude-plugin/plugin.json','SKILL.md','capability-registry.yaml','core/policy/execution-thresholds.yaml','core/policy/execution-safety-policy.yaml','hooks/hooks.json','hooks/telemetry_hook.py','skills/restart/SKILL.md']
for x in required:
    if not (R/x).exists(): errors.append(f'missing:{x}')
for bad in R.rglob('*'):
    if bad.is_file() and ('__pycache__' in bad.parts or bad.suffix in {'.pyc','.pyo'} or bad.name in {'.DS_Store','Thumbs.db'} or bad.suffix=='.tmp'): errors.append(f'forbidden:{bad.relative_to(R)}')
manifest=json.loads((R/'.claude-plugin/plugin.json').read_text())
if manifest.get('version')!='14.2.2': errors.append('plugin version')
counts={'agents':len(list((R/'agents').glob('*.md'))),'references':len(list((R/'references').glob('*.md'))),'skills':len([x for x in (R/'skills').iterdir() if x.is_dir()])}
# capability registry count by id entries
reg=(R/'capability-registry.yaml').read_text()
counts['capability_ids']=reg.count('\n  - id:') + reg.count('\n- id:')
if counts['agents']!=45: errors.append('agents')
if counts['references']!=44: errors.append('references')
if counts['skills']!=10: errors.append('skills')
if 'default_tool_hard_limit: 60' not in (R/'core/policy/execution-safety-policy.yaml').read_text(): errors.append('tool limit')
if 'no_progress_events: 5' not in (R/'core/policy/execution-safety-policy.yaml').read_text(): errors.append('no progress')
if 'explicit_human_command' not in (R/'core/policy/execution-thresholds.yaml').read_text(): errors.append('restart authority')
print(json.dumps({'pass':not errors,'version':manifest.get('version'),'counts':counts,'errors':errors},indent=2))
if errors: sys.exit(1)
