from __future__ import annotations
import random, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from runtime.openai_agents.control import ExecutionState

s = ExecutionState('extreme-1')
for i in range(2):
    s.before_tool('search', {'q': f'unique-{i}'})
try:
    s.before_tool('search', {'q': 'same'})
    s.before_tool('search', {'q': 'same'})
    s.before_tool('search', {'q': 'same'})
    raise AssertionError('repeat limit did not stop')
except RuntimeError as e:
    assert 'repeated_identical_tool_call' in str(e)
assert s.terminal_stop

for seed in range(1000):
    random.seed(seed)
    x = ExecutionState(str(seed))
    stopped = False
    for _ in range(random.randint(1, 80)):
        try:
            x.before_tool('t'+str(random.randint(0, 8)), {'a': random.randint(0, 4)})
        except RuntimeError:
            stopped = True
            break
    assert stopped or x.tools < 60

print('V14.1 EXTREME QA: PASS | repeat-stop | 1000 deterministic fuzz runs | hard boundaries')
