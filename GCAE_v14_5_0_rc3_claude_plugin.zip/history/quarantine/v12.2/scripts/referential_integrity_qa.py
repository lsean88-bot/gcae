from pathlib import Path
import json,yaml
ROOT=Path(__file__).resolve().parents[1]
reg=yaml.safe_load((ROOT/'capability-registry.yaml').read_text()); caps={x['id']:x for x in reg['capabilities']}
allcases=[]
for p in (ROOT/'tests').glob('*.json'):
    if p.name not in {'test-registry.json','oracle-manifest.json'}: allcases += json.loads(p.read_text()).get('cases',[])
ids={c['id'] for c in allcases}
assert all(x.get('test_coverage') for x in caps.values() if x.get('type')=='agent'), 'agent capability coverage erasure detected'
missing=[]
for x in caps.values():
    for tid in x.get('test_coverage',[]):
        if tid not in ids: missing.append((x['id'],tid))
assert not missing, missing
con=yaml.safe_load((ROOT/'iia-standards-conformance.yaml').read_text())
for pr in con['principles']:
    for tid in pr['test_refs']: assert tid in ids,(pr['id'],tid)
    for eid in pr['evidence_refs']: assert (ROOT/'evidence'/'iia-control-design'/f'{eid}.yaml').exists(),eid
print(f'REFERENTIAL INTEGRITY PASS | capabilities={len(caps)} tests={len(ids)} IIA=15')
