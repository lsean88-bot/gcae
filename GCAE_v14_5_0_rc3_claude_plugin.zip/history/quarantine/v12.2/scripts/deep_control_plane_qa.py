from pathlib import Path
import json,yaml
ROOT=Path(__file__).resolve().parents[1]
sk=(ROOT/'SKILL.md').read_text()
required=['ROLE_HOOK','SCOPE_HOOK','EVIDENCE_HOOK','AUTHORITY_HOOK','PRIVACY_HOOK','INSTRUCTION_HOOK','ROUTING_HOOK','MEMORY_HOOK','ALERT_HOOK','OUTPUT_HOOK','QA_HOOK','UNCERTAINTY_HOOK','TRACE_HOOK','MEMORY_CAPTURE_HOOK','CHANGE_HOOK']
for h in required: assert h in sk,h
m=json.loads((ROOT/'RELEASE_MANIFEST.json').read_text()); assert len(m['non_waivable_controls'])==12 and m['trusted_root_required'] and m['four_eyes_required']
for f in ['persistence-memory-uat.json','control-plane-hooks-alerts-uat.json','round3-extreme-uat.json','capability-smoke-uat.json','iia-conformance-uat.json','test-registry.json','oracle-manifest.json']: assert (ROOT/'tests'/f).exists(),f
tr=json.loads((ROOT/'tests/test-registry.json').read_text()); assert tr['test_count']==len(tr['tests'])==tr['unique_ids']
for f in ['persistence-memory-uat.json','control-plane-hooks-alerts-uat.json','capability-smoke-uat.json','iia-conformance-uat.json']:
 d=json.loads((ROOT/'tests'/f).read_text()); assert d['cases'],f
for term in ['CANONICAL_FACT','INFERRED_RELATION','QUARANTINED_ITEM','If persistence cannot be verified','Non-waivable rules']: assert term in (ROOT/'agents/45-institutional-memory-knowledge-graph-governance.md').read_text(),term
con=yaml.safe_load((ROOT/'iia-standards-conformance.yaml').read_text()); assert len(con['principles'])==15 and all(p['evidence_refs'] and p['test_refs'] for p in con['principles'])
top=yaml.safe_load((ROOT/'topical-requirements-register.yaml').read_text()); assert len(top['topics'])>=6 and len(top['requirements'])>=6
print('DEEP CONTROL-PLANE QA PASS | hooks=15 nonwaivable=12 tests='+str(tr['test_count'])+' IIA=15 topical_requirements='+str(len(top['requirements'])))
