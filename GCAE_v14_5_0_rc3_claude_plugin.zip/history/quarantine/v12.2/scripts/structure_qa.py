from pathlib import Path
import json,sys,zipfile,re
ROOT=Path(__file__).resolve().parents[1]
S=json.loads(json.dumps(__import__("yaml").safe_load((ROOT/"package-structure.yaml").read_text())))
for f in S["required_files"]: assert (ROOT/f).is_file(), f"missing required file: {f}"
for d in S["required_directories"]: assert (ROOT/d).is_dir(), f"missing required directory: {d}"
for p in ROOT.rglob("*"):
    if p.is_file():
        rel=p.relative_to(ROOT).as_posix()
        assert not any(part=="__pycache__" for part in p.relative_to(ROOT).parts), f"generated cache present: {rel}"
        assert not p.name.endswith((".pyc",".pyo",".tmp",".swp")), f"generated artifact present: {rel}"
        assert not rel.startswith("/") and "\x00" not in rel and "\\" not in rel, f"unsafe path: {rel}"
reg=__import__("yaml").safe_load((ROOT/"capability-registry.yaml").read_text()); assert reg["registry_authority"]=="CANONICAL_SOURCE_OF_TRUTH"
print("STRUCTURE QA PASS | required paths, quarantine roots, generated-artifact exclusion and canonical registry present")
