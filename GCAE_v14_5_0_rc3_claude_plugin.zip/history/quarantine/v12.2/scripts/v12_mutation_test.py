from pathlib import Path
import tempfile,shutil,subprocess,sys,json,yaml,os,importlib.util
ROOT=Path(__file__).resolve().parents[1]
results=[]

def run_selector(d,task):
 spec=importlib.util.spec_from_file_location('mutsel',d/'scripts/select_context.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m.select(task,d)

def mutation_trigger(d):
 p=d/'router/routing-truth-table.yaml';x=yaml.safe_load(p.read_text());x['critical_single_trigger_rules']['AG-008']=[];
 for prof in x['profiles']:
  if prof['id'] in {'PROFILE-FRAUD-PROCUREMENT','PROFILE-COI-INVESTIGATION'}: prof['mandatory_agents']=[a for a in prof.get('mandatory_agents',[]) if a!='AG-008']
 x['agent_keyword_rules']['AG-008']['keywords']=[t for t in x['agent_keyword_rules']['AG-008'].get('keywords',[]) if t not in {'fraud','investigation','forensic'}]
 p.write_text(yaml.safe_dump(x,sort_keys=False));return not ('AG-008' in {a['id'] for a in run_selector(d,'Investigate suspected fraud in supplier payments.')['agents']})

def mutation_capability(d):
 p=d/'capability-registry.yaml';x=yaml.safe_load(p.read_text());x['capabilities']=[c for c in x['capabilities'] if c['id']!='AG-045'];p.write_text(yaml.safe_dump(x,sort_keys=False));r=subprocess.run([sys.executable,str(d/'scripts/validate_package.py')],cwd=d,capture_output=True,text=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});return r.returncode!=0

def mutation_budget(d):
 p=d/'router/routing-ontology.yaml';x=yaml.safe_load(p.read_text());x['hard_limits']['max_agents']=9;p.write_text(yaml.safe_dump(x,sort_keys=False));r=subprocess.run([sys.executable,str(d/'scripts/validate_package.py')],cwd=d,capture_output=True,text=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});return r.returncode!=0
for label,fn in [('critical-trigger-removal',mutation_trigger),('capability-removal',mutation_capability),('capacity-policy-downgrade',mutation_budget)]:
 with tempfile.TemporaryDirectory() as td:
  d=Path(td)/'pkg';shutil.copytree(ROOT,d);detected=fn(d);results.append({'mutation':label,'detected':bool(detected)})
print(json.dumps({'status':'PASS' if all(x['detected'] for x in results) else 'FAIL','mutations':results},indent=2));assert all(x['detected'] for x in results)
