#!/usr/bin/env python3
"""GCAE v11.2.1 deterministic, economy-first, adversarially hardened selector.

Routing boundary controls:
- intent-first communication exclusivity;
- active-task extraction for explicit interruptions;
- clause-level negative/noise quarantine;
- unique-signal weighting to resist keyword surge/repetition;
- conservative fuzzy matching for typos/spacing variants;
- multilingual safety lexicon with non-Latin substantive fallback;
- substantive-task zero-route prohibition;
- one-pass, bounded specialist/reference selection.
"""
import argparse,json,re,unicodedata
from difflib import SequenceMatcher
from pathlib import Path

NEG_PATTERNS=(
    r'\bnot\s+(?:relevant|applicable|needed|required)\b', r'\birrelevant\b', r'\bunrelated\b',
    r'\bdistraction\b', r'\bnoise\b', r'\bignore\s+(?:the\s+)?(?:this\s+)?(?:agent|specialist|domain|topic|following)\b',
    r'\bdo\s+not\s+(?:route|load|select|use)\b', r'\bdon.t\s+(?:route|load|select|use)\b',
    r'\bexclude\b', r'\bnot\s+about\b', r'\bonly\s+a\s+distraction\b', r'\bhypothetical\b', r'\bquoted\b'
)
SUBSTANTIVE=(
    'analyse','analyze','analysis','audit','assess','assessment','review','investigate','investigation',
    'test','testing','calculate','quantify','reconcile','evaluate','design','build','prepare','research',
    'verify','determine','identify','control','risk','finding','exposure','compliance','contract','supplier',
    'transaction','revenue','receivable','payable','production','quality','stamping','tooling','fraud',
    'regulation','law','governance','cybersecurity','dialysis','decision','inspect','validate','compare'
)
COMMUNICATION_START=(
    r'^(?:please\s+)?(?:rewrite|rephrase|polish|edit|improve|shorten|humanise|humanize|proofread)\b',
    r'\bjust\s+(?:rewrite|rephrase|polish|edit|improve|shorten|humanise|humanize|proofread)\b',
    r'^(?:please\s+)?(?:write|compose)\s+(?:a|an|the)\s+(?:email|message|whatsapp|reply|letter)\b',
    r'^(?:please\s+)?draft\b.*\b(?:email|message|whatsapp|reply|letter)\b',
)
ANALYTICAL=(
    'analyse','analyze','assess','assessment','review','investigate','calculate','quantify','reconcile','evaluate',
    'research','verify','determine','identify','testing','inspect','validate','compare','diagnose'
)
# Conservative cross-script safety lexicon. It is used for routing safety, not translation authority.
MULTI_LEXICON={
    # Chinese
    '调查':'investigate','调查欺诈':'investigate fraud','欺诈':'fraud','舞弊':'fraud','供应商':'supplier','采购':'procurement',
    '发票':'invoice','重复发票':'duplicate invoice','合同':'contract','审计':'audit','分析':'analyze','审核':'review',
    '库存':'inventory','合规':'compliance','风险':'risk','质量':'quality','主席':'chairman','董事会':'board',
    # Hindi
    'जांच':'investigate','धोखाधड़ी':'fraud','आपूर्तिकर्ता':'supplier','चालान':'invoice','अनुबंध':'contract','ऑडिट':'audit',
    'विश्लेषण':'analyze','जोखिम':'risk','वित्तीय':'financial','वित्त':'financial','अनुपालन':'compliance','इन्वेंटरी':'inventory',
    # Tamil
    'விசாரணை':'investigate','மோசடி':'fraud','சப்ளையர்':'supplier','விலைப்பட்டியல்':'invoice','ஒப்பந்த':'contract','ஒப்பந்தம்':'contract',
    'தணிக்கை':'audit','பகுப்பாய்வு':'analyze','ஆபத்து':'risk','நிதி':'financial','வெளிப்பாடு':'exposure','ஒப்பந்த':'contract','ஒப்பந்தம்':'contract','ஒழுங்குமுறை':'regulation','இணக்கம்':'compliance','மதிப்பிடவும்':'assess','ஆய்வு':'review','சரக்கு':'inventory','டயாலிசிஸ்':'dialysis'
}

def norm(s):
    s=unicodedata.normalize('NFKC',s or '')
    return re.sub(r'[^a-z0-9]+',' ',s.lower()).strip()
def toks(s): return set(norm(s).split())
def contains(text,term):
    t=norm(term)
    if not t:return False
    pat=r'(?<!\w)'+r'\s+'.join(re.escape(x) for x in t.split())+r'(?!\w)'
    return bool(re.search(pat,text))

def unicode_substantive(s):
    return any(any(ord(c)>127 for c in token) for token in (s or '').split())

def multilingual_expand(s):
    hits=[]; low=s or ''
    for src,dst in MULTI_LEXICON.items():
        if src in low: hits.append(dst)
    return ' '.join(hits)

def active_task(task):
    """Apply explicit user-level interruption markers to routing only.
    This does not alter instruction precedence or permit evidence to override the skill."""
    t=unicodedata.normalize('NFKC',task or '').strip()
    markers=[r'\bnew\s+task\s*:',r'\bnew\s+request\s*:',r'\bnew\s+instruction\s*:',
             r'\binstead\s*:',r'\bactually\s*:',r'\bchange\s+of\s+task\s*:']
    cuts=[m.end() for pat in markers for m in re.finditer(pat,t,re.I)]
    if cuts: return t[max(cuts[-1],0):].strip(), True
    # Common interactive interruption form: “stop; …” / “stop. …”
    m=list(re.finditer(r'\bstop\s*[:;\-]\s*',t,re.I))
    if m: return t[m[-1].end():].strip(), True
    return t,False

def strip_noise_clauses(s):
    """Remove explicit meta/noise clauses before domain scoring.
    Keep substantive wording outside the marked clause."""
    out=s
    patterns=[
      r'(?:the\s+)?(?:following|next)\s+(?:words?|terms?|text|items?)\s+(?:are|is)\s+(?:irrelevant|unrelated|noise|a\s+distraction)\s*[:\-].*?(?=[.!?]\s|$)',
      r'(?:irrelevant|unrelated|noise|distraction)\s*(?:words?|terms?|text|items?)?\s*[:\-].*?(?=[.!?]\s|$)',
      r'(?:mentioned|included)\s+(?:only|merely)\s+as\s+(?:context|an?\s+example|noise)\s*[:\-].*?(?=[.!?]\s|$)',
      r'\bdo\s+not\s+analyse\s+(?:the\s+)?(?:following|above).*?(?=[.!?]\s|$)'
    ]
    for pat in patterns: out=re.sub(pat,' ',out,flags=re.I|re.S)
    return re.sub(r'\s+',' ',out).strip()

def surge_compact(raw, expanded):
    """Bound noisy surge input without discarding a clear lead instruction.
    When a prompt is extremely long and the first sentence is a complete task, use that
    lead sentence plus a small bounded tail for routing. Evidence remains available to
    the downstream specialist; this function only controls specialist selection."""
    base=strip_noise_clauses(raw)
    words=norm(base).split()
    if len(words)<=100:
        return norm(base+' '+expanded)
    first=re.split(r'[.!?\n]',base,maxsplit=1)[0].strip()
    if len(first)>=12:
        return norm(first+' '+expanded)
    # No clear lead sentence: retain a bounded prefix rather than scanning the whole surge.
    return norm(' '.join(words[:160])+' '+expanded)

def negated(text,term):
    t=norm(term)
    if not contains(text,t): return False
    words=text.split(); tw=t.split(); n=len(tw)
    for i in range(len(words)-n+1):
        if words[i:i+n]!=tw: continue
        before=' '.join(words[max(0,i-5):i]); after=' '.join(words[i+n:min(len(words),i+n+10)])
        local=before+' '+t+' '+after
        direct=[
          rf'\bnot\s+(?:the\s+)?{re.escape(t)}\b', rf'\bno\s+{re.escape(t)}\b',
          rf'\b{re.escape(t)}\s+(?:is|are)\s+(?:not\s+)?(?:relevant|applicable|needed|required|a\s+distraction)\b',
          rf'\b(?:ignore|exclude|omit|skip)\s+(?:the\s+)?{re.escape(t)}\b',
          rf'\bdo\s+not\s+(?:load|route|select|use)\s+(?:the\s+)?{re.escape(t)}\b',
        ]
        if any(re.search(p,local) for p in direct): return True
        if re.search(rf'\b{re.escape(t)}(?:\s+\w+){{0,7}}\s+(?:is|was)\s+(?:irrelevant|unrelated|hypothetical|quoted|a\s+distraction)\b',local): return True
    return False

def fuzzy_positive(text,term):
    """Conservative typo tolerance: >=5-char terms, high similarity, one token or phrase."""
    if contains(text,term) or negated(text,term): return False
    nt=norm(term)
    if len(nt)<5: return False
    words=norm(text).split(); tw=nt.split()
    # Surge guard: fuzzy matching is intentionally disabled for very large noisy prompts;
    # exact/critical signals remain active and bounded. This prevents O(tokens × keywords) blow-up.
    if len(words)>300: return False
    if len(tw)==1:
        for w in words:
            if len(w)>=5 and SequenceMatcher(None,w,tw[0]).ratio() >= (0.86 if len(tw[0])>=7 else 0.90): return True
    else:
        n=len(tw)
        for i in range(len(words)-n+1):
            cand=' '.join(words[i:i+n])
            if SequenceMatcher(None,cand,nt).ratio()>=0.91:return True
    return False

def positive_contains(text,term):
    return (contains(text,term) or fuzzy_positive(text,term)) and not negated(text,term)

def communication_only(taskn):
    if not any(re.search(p,taskn,re.I) for p in COMMUNICATION_START): return False
    # Explicitly negated analysis is not analytical intent. This prevents words such as
    # “do not investigate” inside the email/topic from activating forensic routing.
    negverbs=sorted(set(ANALYTICAL+('analysis','audit','test','assessment','investigation','verify')),key=len,reverse=True)
    negpat='|'.join(re.escape(v) for v in negverbs)
    probe=re.sub(r'\b(?:do\s+not|dont|don.t|please\s+do\s+not|without|no(?:\s+(?:the|this|it|that))?)\s+(?:'+negpat+r')\b',' ',taskn,flags=re.I)
    if re.search(r'\b(?:only|just|wording\s+only|communication\s+only)\b',probe,re.I) and not re.search(r'\b(?:and|then)\s+(?:analyse|analyze|assess|review|investigate|calculate|quantify|reconcile|evaluate|research|audit|test|inspect|validate|compare)\b',probe,re.I):
        return True
    if any(re.search(r'\b'+re.escape(v)+r'\b',probe) for v in ANALYTICAL): return False
    return True

def select(task,root=None):
    root=Path(root or Path(__file__).resolve().parents[1])
    idx=json.loads((root/'router/capability-index.json').read_text())
    tp=json.loads((root/'router/task-profiles.json').read_text()); profiles=tp['profiles']; rules=tp.get('routing_rules',{})
    raw,interrupted=active_task(task)
    taskn=norm(raw); expanded=norm(multilingual_expand(raw)); scored_text=surge_compact(raw,expanded)
    tt=toks(scored_text)
    byid={a['id']:a for a in idx['agents']}; selected=[]; profile_hits=[]

    # Intent gate runs BEFORE any high-risk/domain routing. This is the key anti-overrouting control.
    comm_only=communication_only(taskn)
    if comm_only:
        return {
          'schema_version':'1.2','selector':'gcae-v11.2.1-single-pass','task':task,'active_task':raw,'interruption_applied':interrupted,
          'mode':'standard','confidence':0.95,'profiles':['PROFILE-COMMUNICATION'],'critical_triggers':[],
          'agents':[{'id':'AG-024','name':byid['AG-024']['name'],'file':byid['AG-024']['file'],'score':99,'matched':['communication-only-intent']}],
          'references':[],'jurisdictions':[],'industries':[],'load_policy':{'do_not_load_all_agents':True,'do_not_load_all_references':True,'history_prohibited_by_default':True,'tests_prohibited_by_default':True,'zero_specialist_for_substantive_task_prohibited':True,'negative_context_must_not_activate_specialist':True,'communication_only_is_exclusive':True},
          'excluded_domains':['all substantive specialists unless user explicitly requests analysis'],'next_action':'Load AG-024 only.'}

    multi_hint_agents=[]
    if expanded:
        hint_map=[('fraud','AG-008'),('investigate','AG-008'),('supplier','AG-030'),('procurement','AG-030'),('invoice','AG-005'),('financial','AG-005'),('contract','AG-031'),('compliance','AG-004'),('regulation','AG-004'),('dialysis','AG-016'),('quality','AG-020'),('inventory','AG-002'),('audit','AG-002'),('analyze','AG-002'),('review','AG-002')]
        for term,aid in hint_map:
            if contains(expanded,term) and aid not in multi_hint_agents: multi_hint_agents.append(aid)
    for aid in multi_hint_agents:
        if aid not in selected: selected.append(aid)

    for p in profiles:
        any_hits=[x for x in p.get('any',[]) if positive_contains(scored_text,x)]
        all_ok=all(positive_contains(scored_text,x) for x in p.get('all',[]))
        if any_hits and all_ok: profile_hits.append((len(set(any_hits)),p))

    forensic_terms=['fraud','kickback','bribery','nominee','beneficial ownership','duplicate invoice','duplicate invoices','duplicate payments','split po','split pos','preferential treatment','supplier fraud','forensic','misconduct']
    investigative_terms=['investigate','investigation','investigating','suspected','alleged','forensic']
    forensic_signal=any(positive_contains(scored_text,x) for x in forensic_terms)
    investigative_signal=any(positive_contains(scored_text,x) for x in investigative_terms)
    suppress=set()
    for _,p in profile_hits:suppress.update(p.get('suppress_profiles',[]))
    if any(p.get('id')=='PROFILE-REGULATORY' for _,p in profile_hits) and not forensic_signal and not investigative_signal:suppress.update({'PROFILE-COI-INVESTIGATION','PROFILE-FRAUD-PROCUREMENT','PROFILE-RESEARCH'})
    usable=[(n,p) for n,p in profile_hits if p.get('id') not in suppress]
    suppressed_agents=set()
    for _,p in profile_hits:
        if p.get('id') in suppress:suppressed_agents.update(p.get('agents',[]))
    for aid,a in byid.items():
        if any(negated(scored_text,k) for k in a.get('keywords',[])):suppressed_agents.add(aid)
    active_profile_agents={aid for _,p in usable for aid in p.get('agents',[])}; suppressed_agents-=active_profile_agents
    profile_priority={'PROFILE-CHAIRMAN':6,'PROFILE-COI-INVESTIGATION':5,'PROFILE-FRAUD-PROCUREMENT':5,'PROFILE-REGULATORY':5,'PROFILE-RELEASE-QA':5,'PROFILE-SKILL-BUILD':5,'PROFILE-SKILL-BUILD-2':5,'PROFILE-COMMUNICATION':9}
    usable_sorted=sorted(usable,key=lambda x:(profile_priority.get(x[1].get('id'),0),x[0]),reverse=True)
    for _,p in usable_sorted[:3]:
        for aid in p.get('agents',[]):
            if aid not in suppressed_agents and aid not in selected:selected.append(aid)

    critical_rules=rules.get('critical_single_trigger_rules',{}); critical_hits=[]
    for aid,terms in critical_rules.items():
        if aid in suppressed_agents:continue
        hits=[t for t in terms if positive_contains(scored_text,t)]
        if hits: critical_hits.append((aid,hits)); selected.append(aid) if aid not in selected else None

    scores=[]
    for a in idx['agents']:
        score=0; hits=[]
        for k in a['keywords']:
            nk=norm(k)
            if nk and positive_contains(scored_text,nk):
                fuzzy_hit = (not contains(scored_text,nk)) and fuzzy_positive(scored_text,nk)
                score += 2 if fuzzy_hit else (3 if ' ' in nk else 1)
                hits.append(k + ('~fuzzy' if fuzzy_hit else ''))
        for n in a.get('negative',[]):
            if positive_contains(scored_text,n):score-=4
        if a['id'] in selected:score+=8
        if score>0:scores.append((score,a,hits))
    scores.sort(key=lambda x:(-x[0],x[1]['cost_class'],x[1]['id']))

    high_terms=['fraud','nominee','beneficial ownership','kickback','bribery','law','regulation','chairman','board decision','release integrity','skill architecture','uat','regression test','investigation','forensic','legal']
    high=any(positive_contains(scored_text,x) for x in high_terms)
    profile_mode=next((p.get('mode') for _,p in usable if p.get('mode') in {'forensic','deep'}),None)
    substantive=any(positive_contains(scored_text,x) for x in SUBSTANTIVE)
    nonlatin=unicode_substantive(raw)
    # Unknown non-Latin substantive text must not silently fall into economy.
    if nonlatin and not scores and substantive: selected.append('AG-002')
    if nonlatin and not scores and not substantive and expanded:
        # expanded lexicon itself is substantive evidence
        substantive=True; selected.append('AG-008' if 'investigate' in expanded or 'fraud' in expanded else 'AG-002')

    max_agents=5 if high or profile_mode in {'forensic','deep'} else (3 if len(scores)>2 else 2)
    chosen=[]; seen=set()
    for score,a,hits in scores:
        if a['id'] in suppressed_agents or a['id'] in seen:continue
        if score<2 and a['id'] not in selected and not high:continue
        chosen.append((score,a,hits));seen.add(a['id'])
        if len(chosen)>=max_agents:break
    for aid in selected:
        if aid in suppressed_agents or aid in seen or len(chosen)>=max_agents:continue
        a=byid.get(aid)
        if a:chosen.append((8,a,['profile-or-critical-trigger']));seen.add(aid)

    if not chosen and substantive:
        # Deterministic safety floor: strongest lexical specialist; if no lexical signal, audit methodology.
        fallback=[x for x in scores if x[1]['id'] not in suppressed_agents]
        if fallback:
            s,a,h=fallback[0];chosen=[(max(2,s),a,h+['economy-safety-floor'])]
        else:
            a=byid['AG-002'];chosen=[(2,a,['substantive-safety-floor'])]
    refs=[]
    for _,a,_ in chosen:
        for r in a['dependencies']:
            if r not in refs and r in idx['references'] and not idx['references'][r].get('core'):refs.append(r)
    for _,pr in usable_sorted[:3]:
        for r in pr.get('refs',[]):
            if r not in refs and r in idx['references'] and not idx['references'][r].get('core'):refs.append(r)
    refs=refs[:8 if high else 4]
    jurisdictions=[j for j in ['india','malaysia','mexico'] if positive_contains(scored_text,j)]
    industries=[i for i in ['dialysis','stamping','die casting','forging','assembly','gas cylinder','tooling','costing'] if positive_contains(scored_text,i)]
    mode='forensic' if forensic_signal or profile_mode=='forensic' else ('deep' if high or profile_mode=='deep' else ('standard' if chosen else 'economy'))
    confidence=0.25
    if chosen:confidence=min(0.99,max(0.42,chosen[0][0]/12))
    return {'schema_version':'1.2','selector':'gcae-v11.2.1-single-pass','task':task,'active_task':raw,'interruption_applied':interrupted,'mode':mode,'confidence':round(confidence,2),'profiles':[p['id'] for _,p in usable_sorted[:3]],'critical_triggers':[{'agent_id':a,'matched':h} for a,h in critical_hits],'agents':[{'id':a['id'],'name':a['name'],'file':a['file'],'score':s,'matched':h} for s,a,h in chosen],'references':[{'id':r,'name':idx['references'][r]['name'],'file':idx['references'][r]['file']} for r in refs if idx['references'][r].get('file')],'jurisdictions':jurisdictions,'industries':industries,'load_policy':{'do_not_load_all_agents':True,'do_not_load_all_references':True,'history_prohibited_by_default':True,'tests_prohibited_by_default':True,'zero_specialist_for_substantive_task_prohibited':True,'negative_context_must_not_activate_specialist':True,'unique_signal_weighting':True,'fuzzy_matching_bounded':True,'multilingual_safety_fallback':True},'excluded_domains':['unmatched agents','unrelated references','history/quarantine/**','tests/**'],'next_action':'Load only selected files; if evidence/risk requires more, escalate explicitly.'}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--task',required=True);args=ap.parse_args();print(json.dumps(select(args.task),indent=2,ensure_ascii=False))
if __name__=='__main__':main()
