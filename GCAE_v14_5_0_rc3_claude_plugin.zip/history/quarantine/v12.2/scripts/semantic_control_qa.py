from pathlib import Path
import json,yaml,re
ROOT=Path(__file__).resolve().parents[1]
sk=(ROOT/'SKILL.md').read_text()
assert 'Hooks are control gates, not optional suggestions.' in sk
assert 'self-declared package hash proves internal consistency only' in sk
plugin=yaml.safe_load((ROOT/'plugin.yaml').read_text())['plugin']
assert plugin['safety'].get('fraud_requires_corroboration') is True and 'fraud_requires_corrobation' not in plugin['safety']
# production retrieval boundary
kb=yaml.safe_load((ROOT/'knowledge-boundary.yaml').read_text()); assert kb['default_retrieval_policy']=='PRODUCTION_ONLY'
for p in (ROOT/'history/quarantine').rglob('*'):
    if p.is_file():
        t=p.read_text(); assert 'authoritative_for_production: false' in t or 'classification: QUARANTINED_HISTORICAL' in t or 'classification: HISTORICAL_RELEASE_RECORD' in t
# IIA mappings are explicit and cautious
con=yaml.safe_load((ROOT/'iia-standards-conformance.yaml').read_text())
assert all(p['status']=='controlled-design-mapping' for p in con['principles'])
assert all(p['evidence_refs'] and p['test_refs'] for p in con['principles'])
# Test oracle exists and contains every test.
ora=json.loads((ROOT/'tests/oracle-manifest.json').read_text()); tr=json.loads((ROOT/'tests/test-registry.json').read_text()); assert set(ora['test_oracle_hashes'])=={x['id'] for x in tr['tests']}
# Topical requirements are applicability gates, not invented external text.
top=yaml.safe_load((ROOT/'topical-requirements-register.yaml').read_text()); assert top['requirement_level_policy'].startswith('This register does not reproduce external requirement text')
# No stale legacy release assertions in active QA programs.
for p in (ROOT/'scripts').glob('*.py'):
    if p.name in {'semantic_control_qa.py','meta_qa.py','validate_package.py'}: continue
    t=p.read_text(); legacy='9'+'.1.1'; assert legacy not in t and '=='+'44' not in t and '=='+'29' not in t and '=='+'162' not in t
print('SEMANTIC CONTROL QA PASS')
