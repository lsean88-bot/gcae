from pathlib import Path
import json,yaml
ROOT=Path(__file__).resolve().parents[1]
def load(p): return json.loads(p.read_text()) if p.suffix=='.json' else yaml.safe_load(p.read_text())
S=load(ROOT/'package-structure.yaml'); M=load(ROOT/'RELEASE_MANIFEST.json')
assert S['package_version']==M['version']
for f in S['required_files']: assert (ROOT/f).is_file(),f
reg=load(ROOT/'capability-registry.yaml'); assert reg['version']==M['version'] and reg['schema_version']=='3.0' and reg['registry_authority']=='CANONICAL_SOURCE_OF_TRUTH'
agent_files=sorted((ROOT/'agents').glob('*.md')); ref_files=sorted((ROOT/'references').glob('*.md'))
assert len(agent_files)==45 and len(ref_files)==42
agent_ids=set();ref_ids=set()
for p in agent_files:
 fm=yaml.safe_load(p.read_text().split('---\n',2)[1]); assert fm['version']=='11.2.1'; agent_ids.add(fm['id'])
for p in ref_files:
 fm=yaml.safe_load(p.read_text().split('---\n',2)[1]); assert fm['version']=='11.2.1'; ref_ids.add(fm['id'])
caps=reg['capabilities']; ids={x['id'] for x in caps}; assert len(caps)==100
assert agent_ids=={x['id'] for x in caps if x['type']=='agent'}
assert ref_ids=={x['id'] for x in caps if x['type']=='reference'}
for x in caps:
 for d in x.get('dependencies',[]): assert d in ids,(x['id'],d)
G={x['id']:x.get('dependencies',[]) for x in caps}; state={}
def dfs(n,path):
 if state.get(n)==1: raise AssertionError('dependency cycle: '+' -> '.join(path+[n]))
 if state.get(n)==2:return
 state[n]=1
 for d in G[n]:dfs(d,path+[n])
 state[n]=2
for n in G:dfs(n,[])
ont=load(ROOT/'router/routing-ontology.yaml'); assert ont['hard_limits']['max_agents']==5 and ont['hard_limits']['max_references_high']==8 and ont['hard_limits']['max_workstreams']==5
truth=load(ROOT/'router/routing-truth-table.yaml'); assert truth['version']==M['version']
truth_agents=set(a for p in truth['profiles'] for a in p.get('mandatory_agents',[])) | set(a for r in truth['critical_single_trigger_rules'] for a in [r])
assert truth_agents <= agent_ids
idx=load(ROOT/'router/capability-index.json'); assert len(idx['agents'])==45 and {x['id'] for x in idx['agents']}==agent_ids
contracts=load(ROOT/'router/agent-routing-contracts.json'); assert len(contracts['agents'])==45 and set(contracts['agents'])==agent_ids
rt=load(ROOT/'routing-manifest.yaml'); assert rt['source_of_truth']=='capability-registry.yaml' and len(rt['routes'])==45 and {r['agent_id'] for r in rt['routes']}==agent_ids
allcases=[]
for p in sorted((ROOT/'tests').glob('*.json')):
 if p.name in {'test-registry.json','oracle-manifest.json'}:continue
 allcases += load(p).get('cases',[])
assert len(allcases)==900 and len({c['id'] for c in allcases})==900
tr=load(ROOT/'tests/test-registry.json');assert tr['test_count']==900 and tr['unique_ids']==900
ora=load(ROOT/'tests/oracle-manifest.json');assert set(ora['test_oracle_hashes'])=={c['id'] for c in allcases}
con=load(ROOT/'iia-standards-conformance.yaml');assert len(con['principles'])==15
kb=load(ROOT/'knowledge-boundary.yaml');assert kb['default_retrieval_policy']=='PRODUCTION_ONLY'
print(f"STATIC VALIDATION PASS | v{M['version']} agents=45 refs=42 caps=100 routes=45 tests=900 IIA=15")
