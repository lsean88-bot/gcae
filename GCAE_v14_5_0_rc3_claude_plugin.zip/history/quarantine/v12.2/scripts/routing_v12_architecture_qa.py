from pathlib import Path
import json,glob,importlib.util,hashlib,yaml,shutil,tempfile,os,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('selector',ROOT/'scripts/select_context.py');selector=importlib.util.module_from_spec(spec);spec.loader.exec_module(selector)
# 1. Preserved explicit v11 route corpus + v12 architecture corpus
cases=[]
for p in sorted((ROOT/'tests').glob('*.json')):
 if p.name in {'test-registry.json','oracle-manifest.json','v12-routing-architecture-uat.json'}:continue
 cases += json.loads(p.read_text()).get('cases',[])
new=json.loads((ROOT/'tests/v12-routing-architecture-uat.json').read_text())['cases']
cases += new
fail=[]
for c in cases:
 if 'must_include' not in c and 'must_exclude' not in c:continue
 o=selector.select(c.get('task',c.get('query','')),ROOT);got={a['id'] for a in o['agents']}; inc=set(c.get('must_include',[]));exc=set(c.get('must_exclude',[]))
 if not inc<=got or got&exc or len(got)>c.get('max_agents',999) or ('max_refs' in c and len(o['references'])>c['max_refs']):
  fail.append((c['id'],sorted(got),sorted(inc-got),sorted(got&exc),len(got),c.get('max_agents'),len(o['references']),c.get('max_refs')))
assert not fail,fail
# 2. Decision order is explicit and no prohibited recursive transition.
sm=yaml.safe_load((ROOT/'router/routing-state-machine.yaml').read_text()); assert [x[0] for x in sm['transitions']]==['INGRESS','ACTIVE_TASK','INTENT','TASK_CLASS','RISK','DOMAIN','CONTEXT','CAPABILITY','EXCLUSION','DEPENDENCY','BUDGET','ROUTE_QA']; assert 'AGENT->AGENT_RECURSIVE_ROUTING' in sm['prohibited_transitions']
# 3. Hard demand limits.
ont=yaml.safe_load((ROOT/'router/routing-ontology.yaml').read_text()); assert ont['hard_limits']=={'max_agents':5,'max_references_standard':4,'max_references_high':8,'max_workstreams':5,'max_dependency_depth':2}
for c in new:
 o=selector.select(c['task'],ROOT);assert len(o['agents'])<=5 and len(o['references'])<=8 and len(o['workstreams'])<=5
# 4. Immutable content preservation.
def aggregate(base,sub):
 fs=[]
 for dp,_,names in os.walk(base/sub):
  for n in names:
   p=Path(dp)/n;fs.append((str(p.relative_to(base)),hashlib.sha256(p.read_bytes()).hexdigest(),p.stat().st_size))
 return hashlib.sha256(''.join(x[1] for x in sorted(fs)).encode()).hexdigest(),len(fs)
contract=json.loads((ROOT/'docs/PRESERVATION_CONTRACT.json').read_text())
# Compare current hashes to baseline values captured in the contract.
for sub,v in contract['families'].items():
 cur,n=aggregate(ROOT,sub);assert cur==v['baseline_aggregate_sha256'],(sub,cur,v['baseline_aggregate_sha256']);assert n==v['baseline_file_count']
print(f'V12 ROUTING ARCHITECTURE QA PASS | preserved-corpus={len(cases)} new={len(new)} | agents=45 | refs=42 | hard-cap=5')
