from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
EXCLUDED_FROM_CONTENT_HASH={"RELEASE_MANIFEST.json","tests/oracle-manifest.json"}
FORBIDDEN_SUFFIXES={".pyc",".pyo"}
FORBIDDEN_DIRS={"__pycache__"}
def sha256_bytes(b): return hashlib.sha256(b).hexdigest()
def sha256_file(p): return sha256_bytes(p.read_bytes())
def package_content_hash(root=ROOT):
    h=hashlib.sha256()
    files=[]
    for f in root.rglob("*"):
        if not f.is_file(): continue
        rel=f.relative_to(root).as_posix()
        if rel in EXCLUDED_FROM_CONTENT_HASH: continue
        if any(part in FORBIDDEN_DIRS for part in f.relative_to(root).parts): continue
        if f.suffix.lower() in FORBIDDEN_SUFFIXES: continue
        files.append((rel,f))
    for rel,f in sorted(files):
        h.update(rel.encode("utf-8")); h.update(f.read_bytes())
    return h.hexdigest()
def manifest_hash(root=ROOT): return sha256_file(root/"RELEASE_MANIFEST.json")
def oracle_hash(root=ROOT): return sha256_file(root/"tests/oracle-manifest.json")
def test_registry_hash(root=ROOT): return sha256_file(root/"tests/test-registry.json")
def canonical_registry_hash(root=ROOT): return sha256_file(root/"capability-registry.yaml")
def critical_oracle_hash(root=ROOT):
    d=json.loads((root/"tests/oracle-manifest.json").read_text()); vals=[d["test_oracle_hashes"][x] for x in d["critical_test_ids"]]; return sha256_bytes("\n".join(vals).encode())
def root_snapshot(root=ROOT):
    return {"package_version":json.loads((root/"RELEASE_MANIFEST.json").read_text())["version"],"package_content_sha256":package_content_hash(root),"release_manifest_sha256":manifest_hash(root),"canonical_registry_sha256":canonical_registry_hash(root),"test_registry_sha256":test_registry_hash(root),"oracle_manifest_sha256":oracle_hash(root),"critical_oracle_hashes_sha256":critical_oracle_hash(root)}
