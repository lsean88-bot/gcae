import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from runtime.controller import RuntimeController,RuntimeState
from runtime.model_effort_selector import select
from runtime.claude_capability import validate

cfg=json.loads((ROOT/'tests/v12.2-runtime/complex-uat-stress.json').read_text())
passed=0
for sc in cfg['scenarios']:
    tier=select(sc['workload'],requested_tier=sc['initial_tier'])
    r=RuntimeController(RuntimeState(sc['id'],.5,1.0,12,30,2,max_wall_seconds=900))
    state=None
    for ev in sc['events']:
        state=r.evaluate(**ev)
        if state=='STOP': break
    ok=state==sc['expect']
    print(('PASS' if ok else 'FAIL'),sc['id'],state,'expected',sc['expect'],'tier',tier.model,tier.effort)
    if ok: passed+=1
assert passed==len(cfg['scenarios']),f'{passed}/{len(cfg["scenarios"])} scenarios passed'
# Provider capability boundaries.
for model in ('claude-sonnet-5-5','claude-opus-5-5'):
    for effort in ('low','medium','high','xhigh','max'):
        validate(model,effort)
print('PASS provider-capability-boundaries')
print(f'V12.2 COMPLEX UAT PASS {passed}/{len(cfg["scenarios"])}')
