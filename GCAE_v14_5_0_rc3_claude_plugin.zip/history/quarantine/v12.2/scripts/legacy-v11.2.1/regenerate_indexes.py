from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[2]
SRC={"test-registry.json","oracle-manifest.json"}
cases=[]
for p in sorted((ROOT/"tests").glob("*.json")):
    if p.name in SRC: continue
    d=json.loads(p.read_text()); cases.extend(d.get("cases",[]))
ids=[c["id"] for c in cases]; assert len(ids)==len(set(ids)), "duplicate test IDs"
for c in cases:
    c.pop("oracle_hash",None); canon=json.dumps(c,sort_keys=True,separators=(",",":"),ensure_ascii=False); c["oracle_hash"]=hashlib.sha256(canon.encode()).hexdigest()
for p in sorted((ROOT/"tests").glob("*.json")):
    if p.name in SRC: continue
    d=json.loads(p.read_text()); d["cases"]=[next(c for c in cases if c["id"]==x["id"]) for x in d.get("cases",[])]; p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+"\n")
tr={"version":"11.2.1","status":"generated-derived-test-index","test_count":len(cases),"unique_ids":len(ids),"generated_from":[p.name for p in sorted((ROOT/"tests").glob("*.json")) if p.name not in SRC],"tests":cases}
(ROOT/"tests/test-registry.json").write_text(json.dumps(tr,indent=2,ensure_ascii=False)+"\n")
critical=set(); old=json.loads((ROOT/"tests/oracle-manifest.json").read_text()) if (ROOT/"tests/oracle-manifest.json").exists() else {}
critical.update(old.get("critical_test_ids",[])); critical.update(c["id"] for c in cases if c.get("suite")=="FRAUD"); critical={x for x in critical if x in ids}
o={"schema_version":"3.0","status":"controlled-oracle-baseline","authority":"INDEPENDENT_RELEASE_ORACLE","warning":"In-package oracle is not the final authenticity anchor; release acceptance requires an external trusted-root sidecar.","critical_test_ids":sorted(critical),"test_oracle_hashes":{k:v for k,v in sorted((c["id"],c["oracle_hash"]) for c in cases)}}
(ROOT/"tests/oracle-manifest.json").write_text(json.dumps(o,indent=2,ensure_ascii=False)+"\n")
print(f"INDEX REGEN PASS | tests={len(cases)} critical={len(critical)}")
