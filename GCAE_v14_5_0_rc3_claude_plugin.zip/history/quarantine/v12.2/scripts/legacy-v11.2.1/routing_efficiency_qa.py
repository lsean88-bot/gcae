#!/usr/bin/env python3
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]; sys.path.insert(0,str(ROOT/'scripts'))
from select_context import select
corpus=json.loads((ROOT/'tests/selective-loading-uat.json').read_text())['cases']; fail=[]
for c in corpus:
 r=select(c['task']); got={x['id'] for x in r['agents']}; exp=set(c.get('must_include',[])); forbid=set(c.get('must_exclude',[]))
 if not exp.issubset(got): fail.append((c['id'],'missed',sorted(exp-got),sorted(got)))
 if got & forbid: fail.append((c['id'],'overload',sorted(got&forbid),sorted(got)))
 if c.get('max_agents') is not None and len(got)>c['max_agents']: fail.append((c['id'],'too-many-agents',len(got),c['max_agents']))
 if c.get('max_refs') is not None and len(r['references'])>c['max_refs']: fail.append((c['id'],'too-many-refs',len(r['references']),c['max_refs']))
 if c.get('mode') and r['mode']!=c['mode']: fail.append((c['id'],'mode',r['mode'],c['mode']))
print(json.dumps({'total':len(corpus),'failed':len(fail),'passed':len(corpus)-len(fail),'status':'PASS' if not fail else 'FAIL','failures':fail[:100]},indent=2)); sys.exit(1 if fail else 0)
