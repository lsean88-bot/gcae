#!/usr/bin/env python3
"""Execute the independent routing-adversarial corpus against the deterministic selector."""
import json,sys,importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('selector',ROOT/'scripts/select_context.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
data=json.loads((ROOT/'tests/routing-adversarial-uat.json').read_text())
fail=[]
for c in data['cases']:
    out=mod.select(c['task'],ROOT); got=[x['id'] for x in out['agents']]
    missing=[x for x in c['must_include'] if x not in got]
    bad=[x for x in c['must_exclude'] if x in got]
    if missing or bad or len(got)>c['max_agents']:
        fail.append({'id':c['id'],'missing':missing,'unexpected':bad,'count':len(got),'agents':got,'task':c['task']})
print(json.dumps({'suite':data['suite'],'total':len(data['cases']),'passed':len(data['cases'])-len(fail),'failed':len(fail),'failures':fail},indent=2))
sys.exit(1 if fail else 0)
