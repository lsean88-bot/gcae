#!/usr/bin/env python3
import json,sys,importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('selector',ROOT/'scripts/select_context.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
data=json.loads((ROOT/'tests/routing-shock-uat.json').read_text());fail=[]
for c in data['cases']:
 try:o=mod.select(c['task'],ROOT);got=[x['id'] for x in o['agents']]
 except Exception as e:fail.append({'id':c['id'],'error':repr(e)});continue
 missing=[x for x in c['must_include'] if x not in got];bad=[x for x in c['must_exclude'] if x in got]
 if missing or bad or len(got)>c['max_agents'] or ('mode' in c and o['mode']!=c['mode']):
  fail.append({'id':c['id'],'missing':missing,'unexpected':bad,'count':len(got),'mode':o['mode'],'expected_mode':c.get('mode'),'agents':got,'task':c['task'][:300]})
print(json.dumps({'suite':data['suite'],'total':len(data['cases']),'passed':len(data['cases'])-len(fail),'failed':len(fail),'failures':fail[:50]},indent=2,ensure_ascii=False));sys.exit(1 if fail else 0)
