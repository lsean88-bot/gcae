#!/usr/bin/env python3
"""Compatibility entrypoint for the preserved v11.2.1 mutation gate.

v12 centralises routing truth in router/routing-truth-table.yaml and routing
contracts. The old task-profiles mutation harness targeted an obsolete routing
source and therefore could no longer provide a valid mutation oracle. This
wrapper intentionally delegates to the v12 mutation suite so the legacy
entrypoint remains usable without maintaining a second, contradictory oracle.
"""
from pathlib import Path
import subprocess,sys
ROOT=Path(__file__).resolve().parents[2]
p=ROOT/'scripts/v12_mutation_test.py'
r=subprocess.run([sys.executable,str(p)],cwd=ROOT)
sys.exit(r.returncode)
