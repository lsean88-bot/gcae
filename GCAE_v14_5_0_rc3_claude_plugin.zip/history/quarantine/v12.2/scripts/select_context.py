#!/usr/bin/env python3
"""GCAE v12.1.0 deterministic bottom-up routing engine.

Decision order:
INGRESS -> ACTIVE_TASK -> INTENT -> TASK_CLASS -> RISK -> DOMAIN -> CONTEXT
-> CAPABILITY -> EXCLUSION -> DEPENDENCY -> BUDGET -> ROUTE_QA -> EXECUTION.

The engine separates routing semantics from the specialist content.  It loads the
immutable routing state once per process, then performs bounded in-memory decisions.
"""
import argparse,json,re,unicodedata,time
from functools import lru_cache
from difflib import SequenceMatcher
from pathlib import Path

SUBSTANTIVE=(
 'analyse','analyze','analysis','audit','assess','assessment','review','investigate','investigation',
 'test','testing','calculate','quantify','reconcile','evaluate','design','build','prepare','research',
 'verify','determine','identify','control','risk','finding','exposure','compliance','contract','supplier',
 'transaction','revenue','receivable','payable','production','quality','stamping','tooling','fraud',
 'regulation','law','governance','cybersecurity','dialysis','decision','inspect','validate','compare'
)
ANALYTICAL=(
 'analyse','analyze','assess','assessment','review','investigate','calculate','quantify','reconcile','evaluate',
 'research','verify','determine','identify','testing','inspect','validate','compare','diagnose','audit'
)
COMMUNICATION_START=(
 r'^(?:please\s+)?(?:rewrite|rephrase|polish|edit|improve|shorten|humanise|humanize|proofread)\b',
 r'\bjust\s+(?:rewrite|rephrase|polish|edit|improve|shorten|humanise|humanize|proofread)\b',
 r'^(?:please\s+)?(?:write|compose)\s+(?:a|an|the)\s+(?:email|message|whatsapp|reply|letter)\b',
 r'^(?:please\s+)?draft\b.*\b(?:email|message|whatsapp|reply|letter)\b',
)
INTERRUPT_PATTERNS=(r'\bnew\s+task\s*:',r'\bnew\s+request\s*:',r'\bnew\s+instruction\s*:',r'\binstead\s*:',r'\bactually\s*:',r'\bchange\s+of\s+task\s*:')
MULTI_LEXICON={
 '调查':'investigate','调查欺诈':'investigate fraud','欺诈':'fraud','舞弊':'fraud','供应商':'supplier','采购':'procurement','发票':'invoice','重复发票':'duplicate invoice','合同':'contract','审计':'audit','分析':'analyze','审核':'review','库存':'inventory','合规':'compliance','风险':'risk','质量':'quality','主席':'chairman','董事会':'board',
 'जांच':'investigate','धोखाधड़ी':'fraud','आपूर्तिकर्ता':'supplier','चालान':'invoice','अनुबंध':'contract','ऑडिट':'audit','विश्लेषण':'analyze','जोखिम':'risk','वित्तीय':'financial','वित्त':'financial','अनुपालन':'compliance','इन्वेंटरी':'inventory',
 'விசாரணை':'investigate','மோசடி':'fraud','சப்ளையர்':'supplier','விலைப்பட்டியல்':'invoice','ஒப்பந்த':'contract','ஒப்பந்தம்':'contract','தணிக்கை':'audit','பகுப்பாய்வு':'analyze','ஆபத்து':'risk','நிதி':'financial','வெளிப்பாடு':'exposure','ஒழுங்குமுறை':'regulation','இணக்கம்':'compliance','மதிப்பிடவும்':'assess','ஆய்வு':'review','சரக்கு':'inventory','டயாலிசிஸ்':'dialysis'
}
NEG_PHRASES=(
 'irrelevant','unrelated','noise','distraction','hypothetical','quoted','not relevant','not applicable','not needed','not required',
)
HIGH_TERMS=('fraud','kickback','bribery','nominee','beneficial ownership','forensic','investigation','chairman','board decision','release integrity','legal','regulatory')
FORENSIC_TERMS=('fraud','kickback','bribery','nominee','beneficial ownership','duplicate invoice','duplicate invoices','duplicate payments','split po','split pos','preferential treatment','supplier fraud','forensic','misconduct','conflict of interest','related party')


def norm(s):
    s=unicodedata.normalize('NFKC',s or '')
    return re.sub(r'[^a-z0-9]+',' ',s.lower()).strip()

def active_task(task):
    t=unicodedata.normalize('NFKC',task or '').strip()
    cuts=[m.end() for pat in INTERRUPT_PATTERNS for m in re.finditer(pat,t,re.I)]
    if cuts:return t[max(cuts):].strip(),True
    m=list(re.finditer(r'\bstop\s*[:;\-]\s*',t,re.I))
    if m:return t[m[-1].end():].strip(),True
    return t,False

def expand_multilingual(raw):
    return ' '.join(dst for src,dst in MULTI_LEXICON.items() if src in (raw or ''))

def strip_noise(s):
    out=s or ''
    patterns=[
      r'(?:the\s+)?(?:following|next)\s+(?:words?|terms?|text|items?)\s+(?:are|is)\s+(?:irrelevant|unrelated|noise|a\s+distraction)\s*[:\-].*?(?=[.!?]\s|$)',
      r'(?:irrelevant|unrelated|noise|distraction)\s*(?:words?|terms?|text|items?)?\s*[:\-].*?(?=[.!?]\s|$)',
      r'(?:mentioned|included)\s+(?:only|merely)\s+as\s+(?:context|an?\s+example|noise)\s*[:\-].*?(?=[.!?]\s|$)',
      r'\bdo\s+not\s+analyse\s+(?:the\s+)?(?:following|above).*?(?=[.!?]\s|$)'
    ]
    for p in patterns:out=re.sub(p,' ',out,flags=re.I|re.S)
    return re.sub(r'\s+',' ',out).strip()

def communication_only(taskn):
    if not any(re.search(p,taskn,re.I) for p in COMMUNICATION_START):return False
    negverbs=sorted(set(ANALYTICAL+('analysis','audit','test','assessment','investigation','verify')),key=len,reverse=True)
    negpat='|'.join(re.escape(v) for v in negverbs)
    probe=re.sub(r'\b(?:do\s+not|dont|don.t|please\s+do\s+not|without|no(?:\s+(?:the|this|it|that))?)\s+(?:'+negpat+r')\b',' ',taskn,flags=re.I)
    if re.search(r'\b(?:only|just|wording\s+only|communication\s+only)\b',probe,re.I) and not re.search(r'\b(?:and|then)\s+(?:analyse|analyze|assess|review|investigate|calculate|quantify|reconcile|evaluate|research|audit|test|inspect|validate|compare)\b',probe,re.I):return True
    if any(re.search(r'\b'+re.escape(v)+r'\b',probe) for v in ANALYTICAL):return False
    return True

def negated(text,term):
    t=norm(term)
    if not t or t not in text:return False
    # bounded local windows; exact phrases only
    words=text.split(); tw=t.split(); n=len(tw)
    for i in range(len(words)-n+1):
        if words[i:i+n]!=tw:continue
        local=' '.join(words[max(0,i-5):min(len(words),i+n+9)])
        direct=(
          rf'\bnot\s+(?:the\s+)?{re.escape(t)}\b',rf'\bno\s+{re.escape(t)}\b',
          rf'\b{re.escape(t)}\s+(?:is|are|was|were)\s+(?:not\s+)?(?:relevant|applicable|needed|required|a\s+distraction)\b',
          rf'\b(?:ignore|exclude|omit|skip)\s+(?:the\s+)?{re.escape(t)}\b',
          rf'\bdo\s+not\s+(?:load|route|select|use)\s+(?:the\s+)?{re.escape(t)}\b',
          rf'\b(?:previous|prior|old|former|past)\s+{re.escape(t)}\b',
          rf'\b{re.escape(t)}\s+(?:from|in)\s+(?:the\s+)?(?:previous|prior|old|former|past)\b'
        )
        if any(re.search(p,local) for p in direct):return True
        if re.search(rf'\b{re.escape(t)}(?:\s+\w+){{0,7}}\s+(?:is|was)\s+(?:irrelevant|unrelated|hypothetical|quoted|a\s+distraction)\b',local):return True
    return False

def fuzzy_positive(text,term):
    nt=norm(term)
    if not nt or len(nt)<5:return False
    words=text.split()
    if len(words)>300:return False
    tw=nt.split()
    if len(tw)==1:
        threshold=.86 if len(nt)>=7 else .90
        return any(len(w)>=5 and SequenceMatcher(None,w,nt).ratio()>=threshold for w in words)
    n=len(tw)
    return any(SequenceMatcher(None,' '.join(words[i:i+n]),nt).ratio()>=.91 for i in range(len(words)-n+1))

def surge_compact(raw,expanded):
    base=strip_noise(raw); words=norm(base).split()
    if len(words)<=100:return norm(base+' '+expanded)
    first=re.split(r'[.!?\n]',base,maxsplit=1)[0].strip()
    if len(first)>=12:return norm(first+' '+expanded)
    return norm(' '.join(words[:160])+' '+expanded)

class RoutingEngine:
    def __init__(self,root=None):
        self.root=Path(root or Path(__file__).resolve().parents[1])
        self.ontology=yaml_load(self.root/'router/routing-ontology.yaml')
        self.truth=yaml_load(self.root/'router/routing-truth-table.yaml')
        self.policy=yaml_load(self.root/'router/cost-policy.yaml')
        self.idx=json.loads((self.root/'router/capability-index.json').read_text())
        self.contracts=json.loads((self.root/'router/agent-routing-contracts.json').read_text())['agents']
        self.byid={a['id']:a for a in self.idx['agents']}
        self.profiles={p['id']:p for p in self.truth['profiles']}
        self.precedence=sorted(self.profiles.values(),key=lambda p:p.get('precedence',99))
        self.refmeta=self.idx['references']
        self._exact={aid:[norm(k) for k in c['keywords'] if norm(k)] for aid,c in self.contracts.items()}
        self._critical={aid:[norm(k) for k in v] for aid,v in self.truth['critical_single_trigger_rules'].items()}
        self._keyword_rules=self.truth['agent_keyword_rules']

    def has(self,text,term,allow_fuzzy=False):
        t=norm(term)
        if not t:return False
        # Fast exact boundary check. Normalized text contains spaces between tokens, so
        # token/phrase membership can be resolved without compiling a regex for every term.
        padded=' '+text+' '
        exact=(' '+t+' ') in padded
        if not exact:
            # Phrase boundaries across punctuation are already represented as spaces by norm().
            if not allow_fuzzy or not fuzzy_positive(text,t):return False
        return not negated(text,t)

    def profile_hits(self,text):
        hits=[]
        for p in self.precedence:
            any_hits=[x for x in p.get('any',[]) if self.has(text,x,allow_fuzzy=True)]
            all_ok=all(self.has(text,x,allow_fuzzy=True) for x in p.get('all',[]))
            if any_hits and all_ok:hits.append((p,len(set(any_hits)),any_hits))
        return hits

    def classify_intent(self,text,phits):
        if communication_only(text):return 'communication','PROFILE-COMMUNICATION',0.99
        if phits:
            # Highest precedence profile is authoritative for intent; additional profiles are compound modifiers.
            p=phits[0][0]; return p['intent'],p['id'],min(.98,.70+.05*min(phits[0][1],5))
        if any(self.has(text,x) for x in ('research','benchmark','compare options')):return 'research',None,.70
        if any(self.has(text,x) for x in ('remember','recall','memory','knowledge graph')):return 'knowledge',None,.75
        if any(self.has(text,x) for x in ('draft','rewrite','write')) and not any(self.has(text,x) for x in ANALYTICAL):return 'communication',None,.70
        if any(self.has(text,x) for x in ('investigate','investigation','suspected','alleged')):return 'investigation',None,.78
        if any(self.has(text,x) for x in ('audit','control test','reconcile','finding')):return 'assurance',None,.78
        if any(self.has(text,x) for x in ('advise','decision','options','recommend')):return 'advisory',None,.72
        if any(self.has(text,x) for x in SUBSTANTIVE):return 'analysis',None,.60
        return 'explanation',None,.60

    def classify_risk(self,text,intent,phits):
        if intent=='communication':return 'L0'
        if any(self.has(text,x) for x in ('fraud investigation','forensic investigation','kickback','bribery','nominee account','beneficial ownership')):return 'L4'
        if intent in ('investigation','build_qa') and any(self.has(text,x) for x in ('fraud','investigate','release integrity','production release','trusted root')):return 'L4'
        if intent=='advisory' and any(self.has(text,x) for x in ('chairman','board decision','critical decision')):return 'L4'
        if any(self.has(text,x) for x in ('law','regulation','regulatory','legal','cybersecurity','compliance')):return 'L3'
        if intent in ('assurance','advisory','research'):return 'L3'
        if intent=='analysis':return 'L2'
        return 'L1'

    def domain_candidates(self,text,excluded):
        out=[]
        # Critical triggers first. A single high-confidence trigger is sufficient for the minimum specialist.
        for aid,terms in self._critical.items():
            if aid in excluded:continue
            hits=[t for t in terms if self.has(text,t,allow_fuzzy=True)]
            if hits:out.append((aid,100,hits,'critical-trigger'))
        # Exact keyword matching is preferred; fuzzy is only used for terms >=5 chars and bounded inputs.
        for aid,c in self._keyword_rules.items():
            if aid in excluded:continue
            score=0;hits=[]
            for k in c.get('keywords',[]):
                nk=norm(k)
                if not nk or nk in {'die'}:continue
                if self.has(text,nk,allow_fuzzy=False):
                    score += 4 if ' ' in nk else 2;hits.append(k)
                elif len(norm(text).split())<=160 and self.has(text,nk,allow_fuzzy=True):
                    score += 1;hits.append(k+'~fuzzy')
            if score:out.append((aid,score,hits,'domain-keyword'))
        return out

    @lru_cache(maxsize=1024)
    def select(self,task):
        t0=time.perf_counter(); raw,interrupted=active_task(task); taskn=norm(raw); expanded=norm(expand_multilingual(raw)); base=strip_noise(raw); scored=surge_compact(raw,expanded)
        nonlatin=any(ord(c)>127 for c in raw)
        phits=self.profile_hits(scored)
        intent,primary_profile,intent_conf=self.classify_intent(scored,phits)
        if intent=='communication':
            out=self._final(task,raw,interrupted,intent,'communication', 'L0', phits, [('AG-024',99,['communication-only-intent'],'intent-gate')], [], [], intent_conf, t0, ['COMMUNICATION_EXCLUSIVE'])
            return out
        risk=self.classify_risk(scored,intent,phits)
        excluded=set(); reasons=[]
        # Profile-level suppression is semantic and precedes domain selection.
        active_profiles=[p for p,_,_ in phits]
        suppressed_profiles=set()
        for p in active_profiles:
            for sid in p.get('suppress_profiles',[]):
                suppressed_profiles.add(sid);reasons.append('profile-suppression:'+sid)
        # Regulatory research is not automatically forensic/procurement work. Preserve the
        # v11 safety rule: unless investigation/forensic intent is explicit, regulatory intent
        # suppresses unrelated COI, fraud and research specialist lanes.
        forensic_signal=any(self.has(scored,x,allow_fuzzy=True) for x in FORENSIC_TERMS)
        investigative_signal=any(self.has(scored,x,allow_fuzzy=True) for x in ('investigate','investigation','investigating','suspected','alleged','forensic'))
        if any(p.get('id')=='PROFILE-REGULATORY' for p in active_profiles) and not forensic_signal and not investigative_signal:
            for sid in ('PROFILE-COI-INVESTIGATION','PROFILE-FRAUD-PROCUREMENT','PROFILE-RESEARCH'):
                if any(p.get('id')==sid for p in active_profiles):
                    suppressed_profiles.add(sid);reasons.append('conditional-regulatory-suppression:'+sid)
        usable_profiles=[p for p in active_profiles if p.get('id') not in suppressed_profiles]
        for p in active_profiles:
            for sid in p.get('suppress_profiles',[]):
                sp=self.profiles.get(sid)
                if sp: excluded.update(sp.get('mandatory_agents',[]))
        active_mandatory={aid for p in usable_profiles for aid in p.get('mandatory_agents',[])}
        excluded -= active_mandatory
        if usable_profiles and usable_profiles[0]['id'] in ('PROFILE-RESEARCH','PROFILE-MEMORY'): risk='L1'
        if usable_profiles and usable_profiles[0]['id']=='PROFILE-EVIDENCE-LINEAGE': risk='L2'
        if any(p.get('id') in ('PROFILE-RELEASE-QA','PROFILE-SKILL-BUILD') for p in usable_profiles): risk='L3'
        # Explicit negative/irrelevant clauses suppress matching agents but never suppress mandatory control agents.
        for aid,c in self._keyword_rules.items():
            if any(negated(scored,k) for k in c.get('keywords',[])):
                excluded.add(aid);reasons.append('negative-context:'+aid)
        mandatory=[];preferred=[];optional=[];why={}
        # Profile capabilities are mandatory for matching profiles, except where explicitly suppressed.
        for p in usable_profiles:
            for aid in p.get('mandatory_agents',[]):
                if aid not in excluded and aid not in mandatory:
                    mandatory.append(aid);why[aid]='profile:'+p['id']
        domains=self.domain_candidates(scored,excluded)
        for aid,score,hits,reason in domains:
            if aid not in mandatory and aid not in preferred:
                # Strong profile matches define the primary work lane. Other agents enter only
                # when a distinct critical signal is present; broad keyword matches alone do not.
                if phits and reason=='domain-keyword':
                    continue
                preferred.append(aid);why[aid]=reason+':'+','.join(hits[:3])
        # Multilingual safety fallback: recognized non-Latin substantive signal cannot zero-route.
        substantive=any(self.has(scored,x,allow_fuzzy=False) for x in SUBSTANTIVE) or bool(expanded)
        if nonlatin and substantive and not mandatory and not preferred:
            preferred.append('AG-002');why['AG-002']='multilingual-safety-floor'
        # Generic substantive safety floor.
        if substantive and not mandatory and not preferred:
            preferred.append('AG-002');why['AG-002']='substantive-safety-floor'
        # Domain/task role fit: finance/industry/jurisdiction are modifiers, not independent agents.
        # Prefer profile capabilities over broad lexical matches; then narrower domain and lower cost.
        cost={'low':0,'medium':1,'high':2}
        ranked=[]
        for aid in preferred:
            c=self.contracts[aid]; ranked.append((aid,cost.get(c.get('cost_class','medium'),1),why.get(aid,'')))
        ranked.sort(key=lambda x:(-1 if x[0] in mandatory else 0,x[1],x[0]))
        # Additional task-specific cross-domain preferences from active profiles are bounded.
        for p in usable_profiles[1:]:
            for aid in p.get('mandatory_agents',[]):
                if aid not in mandatory and aid not in preferred and aid not in excluded:optional.append(aid);why[aid]='compound-profile:'+p['id']
        high=risk in ('L3','L4')
        max_agents=5 if high else (3 if len(mandatory)+len(preferred)>2 else 2)
        # Global hard cap is non-waivable; demand beyond the cap is represented as deferred/optional workstreams.
        chosen=[]
        for aid in mandatory+preferred+optional:
            if aid in excluded or aid in chosen:continue
            chosen.append(aid)
            if len(chosen)>=max_agents:break
        if not chosen and intent not in ('explanation','retrieval'):
            chosen=['AG-002'];why['AG-002']='controlled-zero-route-safety-floor';reasons.append('ZERO_ROUTE_PREVENTED')
        # Build route entries with reasoned scores, but do not let score determine membership.
        agent_rows=[]
        for aid in chosen:
            score=100 if aid in mandatory else (70 if aid in preferred else 50)
            agent_rows.append((aid,score,[why.get(aid,'bounded-capability-selection')],why.get(aid,'')))
        refs=[]
        for aid in chosen:
            for rid in self.contracts[aid].get('dependencies',[]):
                if rid in self.refmeta and not self.refmeta[rid].get('core') and rid not in refs:refs.append(rid)
        for p,_,_ in phits:
            for rid in p.get('preferred_references',[]):
                if rid in self.refmeta and not self.refmeta[rid].get('core') and rid not in refs:refs.append(rid)
        ref_cap=8 if high else 4; refs=refs[:ref_cap]
        jurisdictions=[j for j in ('india','malaysia','mexico') if self.has(scored,j)]
        industries=[i for i in ('dialysis','stamping','die casting','forging','assembly','gas cylinder','tooling','costing') if self.has(scored,i)]
        mode='forensic' if intent=='investigation' else ('deep' if risk=='L4' or any(p.get('mode')=='deep' for p,_,_ in phits) else ('standard' if chosen else 'economy'))
        conf=min(.99,max(.42,intent_conf + (0.12 if mandatory else 0) + (0.06 if preferred else 0)))
        return self._final(task,raw,interrupted,intent,'task-class',risk,phits,agent_rows,refs,jurisdictions,intent_conf+0.1 if chosen else intent_conf,t0,reasons,industries=industries,mode=mode)

    def _final(self,task,raw,interrupted,intent,task_class,risk,phits,agents,refs,jurisdictions,confidence,t0,reasons,industries=None,mode=None):
        if isinstance(refs,list) and refs and isinstance(refs[0],dict): refrows=refs
        else: refrows=[{'id':r,'name':self.refmeta[r]['name'],'file':self.refmeta[r]['file']} for r in refs if r in self.refmeta and self.refmeta[r].get('file')]
        agentrows=[]
        for item in agents:
            aid,score,hits,why=item
            a=self.byid[aid];agentrows.append({'id':aid,'name':a['name'],'file':a['file'],'score':score,'matched':hits,'reason':why})
        workstreams=build_workstreams(intent,risk,phits,agentrows)
        elapsed=(time.perf_counter()-t0)*1000
        return {'schema_version':'2.0','selector':'gcae-v12.1.0-bottom-up','task':task,'active_task':raw,'interruption_applied':interrupted,
          'intent':intent,'task_class':task_class,'risk_level':risk,'mode':mode or ('standard' if agentrows else 'economy'),
          'confidence':round(min(.99,max(.42,confidence)),2),'profiles':[p['id'] for p,_,_ in phits[:5]],
          'critical_triggers':[{'agent_id':a,'matched':h} for a,h in self._critical_hits(raw)],
          'agents':agentrows,'references':refrows,'jurisdictions':jurisdictions,'industries':industries or [],'workstreams':workstreams,
          'excluded_agents':sorted(set(self.contracts)-{a['id'] for a in agentrows}),
          'route_record':{'gates':['G0','G1','G2','G3','G4','G5','G6','G7','G8','G9','G10','G11'],'reason_codes':reasons,'budget':{'max_agents':5 if risk in ('L3','L4') else (3 if len(agentrows)>2 else 2),'max_references':8 if risk in ('L3','L4') else 4,'selected_agents':len(agentrows),'selected_references':len(refrows)},'latency_ms':round(elapsed,3),'cache_mode':'process-state'},
          'load_policy':{'do_not_load_all_agents':True,'do_not_load_all_references':True,'history_prohibited_by_default':True,'tests_prohibited_by_default':True,'zero_specialist_for_substantive_task_prohibited':True,'negative_context_must_not_activate_specialist':True,'mandatory_before_preferred':True,'score_is_tie_break_only':True},
          'next_action':'Load only selected files; execute workstreams according to dependency order; escalate explicitly if evidence or authority gaps remain.'}
    def _critical_hits(self,raw):
        text=norm(strip_noise(raw)+' '+expand_multilingual(raw));out=[]
        for aid,terms in self._critical.items():
            hits=[t for t in terms if self.has(text,t)]
            if hits:out.append((aid,hits))
        return out


def yaml_load(path):
    import yaml
    return yaml.safe_load(path.read_text())

def build_workstreams(intent,risk,phits,agents):
    # Deterministic bounded workstream labels. No new routing decision occurs here.
    ids=[a['id'] for a in agents]; ws=[]
    if intent=='investigation': ws.append({'id':'WS-01','class':'investigation','status':'primary','agents':[x for x in ids if x=='AG-008']})
    if any(x in ids for x in ('AG-005','AG-019','AG-027','AG-035')): ws.append({'id':'WS-02','class':'financial/exposure','status':'supporting','agents':[x for x in ids if x in ('AG-005','AG-019','AG-027','AG-035')]})
    if any(x in ids for x in ('AG-004','AG-031')): ws.append({'id':'WS-03','class':'regulatory/legal','status':'supporting','agents':[x for x in ids if x in ('AG-004','AG-031')]})
    if any(x in ids for x in ('AG-012','AG-013','AG-014','AG-015','AG-016','AG-017','AG-018','AG-020')): ws.append({'id':'WS-04','class':'operational/industry','status':'supporting','agents':[x for x in ids if x in ('AG-012','AG-013','AG-014','AG-015','AG-016','AG-017','AG-018','AG-020')]})
    if any(x in ids for x in ('AG-026','AG-027','AG-028')): ws.append({'id':'WS-05','class':'advisory/decision','status':'critical-path' if risk=='L4' else 'supporting','agents':[x for x in ids if x in ('AG-026','AG-027','AG-028')]})
    if not ws and ids: ws=[{'id':'WS-01','class':'primary','status':'primary','agents':ids[:3]}]
    return ws[:5]

_ENGINE=None
def get_engine(root=None):
    global _ENGINE
    requested=Path(root).resolve() if root is not None else None
    if _ENGINE is None or (requested is not None and _ENGINE.root.resolve()!=requested):
        _ENGINE=RoutingEngine(root)
    return _ENGINE

def select(task,root=None):return get_engine(root).select(task)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--task',required=True);ap.add_argument('--root',default=None);args=ap.parse_args();print(json.dumps(select(args.task,args.root),indent=2,ensure_ascii=False))
if __name__=='__main__':main()
