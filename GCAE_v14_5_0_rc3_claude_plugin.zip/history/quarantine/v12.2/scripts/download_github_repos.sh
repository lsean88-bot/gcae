#!/usr/bin/env bash
set -euo pipefail
DEST="${1:-./external-research}"
mkdir -p "$DEST"
declare -A REPOS=(
  [xacta-grc]=https://github.com/xactasolutionsai/grc.git
  [auditflow]=https://github.com/Kirk-KV/AuditFlow.git
  [auditai]=https://github.com/dogukancihanbeyoglu/auditai.git
  [grc-automation-toolkit]=https://github.com/Ankit-Uniyal/grc-automation-toolkit.git
  [ciso-assistant-community]=https://github.com/intuitem/ciso-assistant-community.git
  [assuranceos]=https://github.com/Marc-Dvci/AssuranceOS.git
  [grc-engineering-toolkit]=https://github.com/casarezaz/grc-engineering-toolkit.git
  [manufacturing-risk-dashboard]=https://github.com/Nimesh-Tharaka/lean-asset-risk-engine-Dashboard-.git
  [ehs-safety-intelligence]=https://github.com/nawwarah-analyst/ehs-safety-intelligence.git
  [openworkpaper]=https://github.com/Bobby10105/OpenWorkpaper.git
  [intelligent-audit-system]=https://github.com/Ricky-7-Yan/intelligent-audit-system.git
  [auditpilot]=https://github.com/anirudhnshandilya/auditpilot.git
  [ifixai]=https://github.com/ifixai-ai/iFixAi.git
)
for name in "${!REPOS[@]}"; do
  if [ -d "$DEST/$name/.git" ]; then
    git -C "$DEST/$name" fetch --depth 1 origin
    git -C "$DEST/$name" reset --hard origin/HEAD || true
  else
    git clone --depth 1 "${REPOS[$name]}" "$DEST/$name"
  fi
done
printf 'Repositories acquired under %s\n' "$DEST"
