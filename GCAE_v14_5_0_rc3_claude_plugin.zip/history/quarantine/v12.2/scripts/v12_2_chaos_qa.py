import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from runtime.controller import RuntimeController,RuntimeState

def run(label,**kw):
    r=RuntimeController(RuntimeState(label,.5,1.0,12,30,2,max_wall_seconds=900))
    s=r.evaluate(**kw)
    assert s=='STOP',(label,s)
    assert r.s.terminal_reason is not None
    print('PASS',label,s,r.s.terminal_reason)

# Simultaneous failures: first non-waivable reason wins deterministically.
run('simultaneous',cost_usd=1.0,turns=99,tools=99,agents=99,progress=0,evidence_breach=True)
run('unknown-usage',cost_usd=.2,turns=2,tools=2,agents=1,progress=.8,usage_known=False)
run('invalid-counter',cost_usd=.2,turns=-1,tools=2,agents=1,progress=.8)
run('recursive',cost_usd=.2,turns=2,tools=2,agents=1,progress=.8,recursive_delegation=True)
# STOP is terminal and cannot be reset by a later healthy event.
r=RuntimeController(RuntimeState('terminal',.5,1.0,12,30,2))
assert r.evaluate(1.0,2,2,1,.8)=='STOP'
assert r.evaluate(.1,2,2,1,.9)=='STOP'
print('PASS terminal-state-invariant')
print('V12.2 CHAOS QA PASS')
