"""Canonical release-QA entrypoint. Requires an external trusted-root sidecar."""
from pathlib import Path
import argparse,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser(); ap.add_argument('--trusted-root',required=True); ap.add_argument('--archive',required=True); args=ap.parse_args()
subprocess.run([sys.executable,str(ROOT/'scripts/release_qa.py'),'--trusted-root',args.trusted_root,'--archive',args.archive],check=True)
print('CANONICAL RELEASE-QA ENTRYPOINT PASS')
