#!/usr/bin/env python3
"""GCAE v12 demand/workstream engineering.

Consumes one routing decision; it does not perform a second routing pass.
It measures demand, workstream fan-out, context budget, dependency depth and
parallelism opportunity so compound requests do not accidentally become agent storms.
"""
import argparse,json,time
from pathlib import Path
import importlib.util,yaml
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('router',ROOT/'scripts/select_context.py');router=importlib.util.module_from_spec(spec);spec.loader.exec_module(router)

def demand_profile(task,root=None):
    t0=time.perf_counter(); r=router.select(task,root)
    words=len((r.get('active_task') or '').split()); agents=len(r.get('agents',[])); refs=len(r.get('references',[])); ws=r.get('workstreams',[])
    domains=len(r.get('industries',[]))+len(r.get('jurisdictions',[]))
    profile_hits=len(r.get('profiles',[])); risk=r.get('risk_level','L1')
    signals={
      'task_count':1+max(0,len(ws)-1),'agent_fanout':agents,'reference_fanout':refs,
      'workstream_count':len(ws),'word_count':words,'profile_count':profile_hits,'context_domain_count':domains,
      'critical_path_count':sum(1 for w in ws if w.get('status')=='critical-path')
    }
    if risk=='L4': concurrency='bounded-serial-for-critical; parallelize only independent support work'
    elif len(ws)>=3: concurrency='parallelize independent workstreams; merge at evidence/conclusion gate'
    else: concurrency='single-stream'
    return {'routing':r,'demand':{'signals':signals,'risk_tier':risk,'recommended_concurrency':concurrency,'estimated_route_cost':{'agents':agents,'references':refs,'workstreams':len(ws)},'budget_status':{'agents':'within-cap' if agents<=5 else 'exceeded','references':'within-cap' if refs<=8 else 'exceeded','workstreams':'within-cap' if len(ws)<=5 else 'exceeded'},'latency_ms':round((time.perf_counter()-t0)*1000,3)}}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--task',required=True);args=ap.parse_args();print(json.dumps(demand_profile(args.task),indent=2,ensure_ascii=False))
if __name__=='__main__':main()
