param([string]$Destination = "./external-research")
$ErrorActionPreference = "Stop"
New-Item -ItemType Directory -Force -Path $Destination | Out-Null
$repos = @{
  "xacta-grc"="https://github.com/xactasolutionsai/grc.git"
  "auditflow"="https://github.com/Kirk-KV/AuditFlow.git"
  "auditai"="https://github.com/dogukancihanbeyoglu/auditai.git"
  "grc-automation-toolkit"="https://github.com/Ankit-Uniyal/grc-automation-toolkit.git"
  "ciso-assistant-community"="https://github.com/intuitem/ciso-assistant-community.git"
  "assuranceos"="https://github.com/Marc-Dvci/AssuranceOS.git"
  "grc-engineering-toolkit"="https://github.com/casarezaz/grc-engineering-toolkit.git"
  "manufacturing-risk-dashboard"="https://github.com/Nimesh-Tharaka/lean-asset-risk-engine-Dashboard-.git"
  "ehs-safety-intelligence"="https://github.com/nawwarah-analyst/ehs-safety-intelligence.git"
  "openworkpaper"="https://github.com/Bobby10105/OpenWorkpaper.git"
  "intelligent-audit-system"="https://github.com/Ricky-7-Yan/intelligent-audit-system.git"
  "auditpilot"="https://github.com/anirudhnshandilya/auditpilot.git"
  "ifixai"="https://github.com/ifixai-ai/iFixAi.git"
}
foreach ($name in $repos.Keys) {
  $path = Join-Path $Destination $name
  if (Test-Path (Join-Path $path ".git")) { git -C $path fetch --depth 1 origin; git -C $path reset --hard origin/HEAD }
  else { git clone --depth 1 $repos[$name] $path }
}
Write-Host "Repositories acquired under $Destination"
