#!/usr/bin/env python3
import json,subprocess,sys
from pathlib import Path
R=Path(__file__).resolve().parents[1]; cases=json.loads((R/'tests/complex-routing-stress.json').read_text())['cases']; fail=[]
for c in cases:
 p=subprocess.run([sys.executable,str(R/'scripts/select_context.py'),'--task',c['task']],capture_output=True,text=True)
 if p.returncode: fail.append((c['id'],'selector-error')); continue
 r=json.loads(p.stdout); got={x['id'] for x in r['agents']}
 if not set(c['must_include']).issubset(got): fail.append((c['id'],'missed',sorted(set(c['must_include'])-got),sorted(got)))
 if got & set(c['must_exclude']): fail.append((c['id'],'contamination',sorted(got&set(c['must_exclude']))))
 if len(got)>c['max_agents']: fail.append((c['id'],'overload',len(got)))
print(json.dumps({'status':'PASS' if not fail else 'FAIL','cases':len(cases),'failures':fail},indent=2)); sys.exit(1 if fail else 0)
