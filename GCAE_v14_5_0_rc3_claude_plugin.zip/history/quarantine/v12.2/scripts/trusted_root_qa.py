from pathlib import Path
import json,sys
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'scripts'))
from release_integrity import package_content_hash,oracle_hash,test_registry_hash,canonical_registry_hash,critical_oracle_hash
from manifest_anchor import anchor_hash
tr=json.loads(Path(sys.argv[1]).read_text());m=json.loads((ROOT/'RELEASE_MANIFEST.json').read_text())
assert tr['schema_version']=='3.0' and tr['package_version']==m['version']
assert tr['package_sha256']==package_content_hash(ROOT);assert tr['release_manifest_sha256']==anchor_hash(ROOT);assert tr['canonical_registry_sha256']==canonical_registry_hash(ROOT);assert tr['test_registry_sha256']==test_registry_hash(ROOT);assert tr['oracle_manifest_sha256']==oracle_hash(ROOT);assert tr['critical_oracle_hashes_sha256']==critical_oracle_hash(ROOT);assert tr['four_eyes_required'] is True
print('TRUSTED ROOT QA PASS | v12 package, manifest, structure, registries and oracle anchored')
