from pathlib import Path
import json,hashlib
ROOT=Path(__file__).resolve().parents[1]
def canonical_without_anchor(m):
    x=json.loads(json.dumps(m)); x.get("hashes",{}).pop("release_manifest_sha256",None); x.pop("external_anchor",None); return json.dumps(x,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()
def anchor_hash(root=ROOT): return hashlib.sha256(canonical_without_anchor(json.loads((root/"RELEASE_MANIFEST.json").read_text()))).hexdigest()
if __name__=="__main__": print(anchor_hash())
