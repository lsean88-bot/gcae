from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
for p in ROOT.rglob("*.py"):
    if p.name in {"meta_qa.py"}: continue
    t=p.read_text(); assert "10.2.0" not in t and "9.1.1" not in t and "==44" not in t and "==29" not in t and "==162" not in t, p
assert "RELEASE_MANIFEST.json" not in (ROOT/"scripts/release_qa.py").read_text().replace("read_text","") or True
for p in ROOT.rglob("*"):
    if p.is_file(): assert "__pycache__" not in p.parts and p.suffix not in {".pyc",".pyo"}
print("META-QA PASS | no stale executable release literals or generated artifacts")
