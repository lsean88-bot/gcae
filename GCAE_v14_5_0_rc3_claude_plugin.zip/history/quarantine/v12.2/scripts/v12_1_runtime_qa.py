import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from runtime.model_effort_selector import select,next_tier
from runtime.controller import RuntimeController,RuntimeState

def check(name,cond):
    if not cond: raise AssertionError(name)
    print("PASS",name)

for w,e in [("formatting","SONNET_LOW"),("standard_audit","SONNET_MEDIUM"),("complex_reconciliation","SONNET_HIGH"),("investigation","OPUS_MEDIUM"),("forensic_reconstruction","OPUS_HIGH")]:
    check(f"model-effort:{w}",select(w).tier_id==e)
try: select("frontier_exception")
except PermissionError: print("PASS frontier-gate")
else: raise AssertionError("frontier-gate")
check("ladder",next_tier("SONNET_MEDIUM").tier_id=="SONNET_HIGH")
r=RuntimeController(RuntimeState("T",.5,1.0,12,30,2))
check("green",r.evaluate(.20,2,3,1,.9)=="GREEN")
check("amber",r.evaluate(.50,5,5,1,.8)=="AMBER")
check("red",r.evaluate(.76,6,6,1,.2)=="RED")
check("stop-budget",r.evaluate(1.0,6,6,1,.8)=="STOP")
r=RuntimeController(RuntimeState("T2",.5,1,12,30,2))
check("stop-loop",r.evaluate(.10,4,31,1,.8)=="STOP")
print("V12.1 RUNTIME CONTROL QA PASS")
