"""Template only: does not execute a model. Host runtime integration must supply an adapter."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1];REG=json.loads((ROOT/'tests/test-registry.json').read_text());rows=[]
for t in REG['tests']:
 rows.append({'execution_id':None,'package_version':json.loads((ROOT/'RELEASE_MANIFEST.json').read_text())['version'],'package_hash':None,'runtime':None,'model_profile':None,'date':None,'test_id':t['id'],'prompt_hash':None,'response_hash':None,'evaluator':None,'expected_behaviour':None,'observed_behaviour':None,'result':'NOT_EXECUTED','evidence':None,'deviations':None,'disposition':None})
(ROOT/'runtime-results-template.json').write_text(json.dumps({'schema_version':'1.0','status':'TEMPLATE_ONLY','results':rows},indent=2))
print('Created v12 runtime acceptance result template; no runtime behaviour is claimed.')
