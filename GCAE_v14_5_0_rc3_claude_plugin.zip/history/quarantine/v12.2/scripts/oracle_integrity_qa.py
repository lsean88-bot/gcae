from pathlib import Path
import json,hashlib,sys
ROOT=Path(__file__).resolve().parents[1]
def canon(c): return json.dumps({k:v for k,v in c.items() if k!='oracle_hash'},sort_keys=True,separators=(',',':'),ensure_ascii=False)
allcases=[]
for p in (ROOT/'tests').glob('*.json'):
    if p.name in {'test-registry.json','oracle-manifest.json'}: continue
    allcases += json.loads(p.read_text()).get('cases',[])
ora=json.loads((ROOT/'tests/oracle-manifest.json').read_text())
expected=ora['test_oracle_hashes']
assert set(expected)=={c['id'] for c in allcases}
for c in allcases:
    actual=hashlib.sha256(canon(c).encode()).hexdigest(); assert actual==c.get('oracle_hash'),c['id']; assert expected[c['id']]==actual,c['id']
print(f'ORACLE INTEGRITY PASS | tests={len(allcases)} critical={len(ora["critical_test_ids"])}')
