"""Canonical release-QA entrypoint. Requires an external trusted-root sidecar."""
from pathlib import Path
import argparse,json,hashlib,subprocess,sys,os
ROOT=Path(__file__).resolve().parents[1]
os.environ['PYTHONDONTWRITEBYTECODE']='1'

def cleanup():
 import shutil
 for p in ROOT.rglob('__pycache__'):
  if p.is_dir(): shutil.rmtree(p,ignore_errors=True)
 for p in ROOT.rglob('*.pyc'):
  try:p.unlink()
  except FileNotFoundError:pass

def run(name,script):
 cleanup(); print('['+name+']'); subprocess.run([sys.executable,str(ROOT/'scripts'/script)],check=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})

ap=argparse.ArgumentParser(); ap.add_argument('--trusted-root',required=True); ap.add_argument('--archive',required=True); args=ap.parse_args()
for name,script in [('STRUCTURE','structure_qa.py'),('VALIDATE','validate_package.py'),('DEEP','deep_control_plane_qa.py'),('REFERENTIAL','referential_integrity_qa.py'),('ORACLE','oracle_integrity_qa.py'),('SEMANTIC','semantic_control_qa.py'),('META','meta_qa.py'),('ROUTING','routing_v12_architecture_qa.py'),('MUTATION','v12_mutation_test.py')]: run(name,script)
cleanup()
from release_integrity import package_content_hash,manifest_hash,oracle_hash,test_registry_hash,canonical_registry_hash,critical_oracle_hash
from manifest_anchor import anchor_hash
manifest=json.loads((ROOT/'RELEASE_MANIFEST.json').read_text()); tr=json.loads(Path(args.trusted_root).read_text())
ph=package_content_hash(ROOT); ah=anchor_hash(ROOT); oh=oracle_hash(ROOT); th=test_registry_hash(ROOT); ch=canonical_registry_hash(ROOT); coh=critical_oracle_hash(ROOT)
assert manifest['hashes']['package_content_sha256']==ph
assert manifest['hashes']['release_manifest_sha256']==ah
assert tr['schema_version']=='3.0' and tr['package_version']==manifest['version']
for k,v in {'package_sha256':ph,'release_manifest_sha256':ah,'canonical_registry_sha256':ch,'test_registry_sha256':th,'oracle_manifest_sha256':oh,'critical_oracle_hashes_sha256':coh}.items(): assert tr[k]==v,(k,tr[k],v)
assert tr['agent_count']==45 and tr['reference_count']==42 and tr['capability_count']==100 and tr['route_count']==45 and tr['test_count']==900
assert hashlib.sha256(Path(args.archive).read_bytes()).hexdigest()==tr['archive_sha256']
print('TRUSTED ROOT MATCH PASS | v12.1 package + manifest + registry + oracle + structure anchored')
print('RELEASE QA PASS | candidate remains governed by four-eyes and target-runtime gates')
