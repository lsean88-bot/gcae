import os, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; sys.path.insert(0,str(ROOT))
from runtime.claude_capability import validate

checks=[]
def ck(name, ok, detail):
    checks.append((name,ok,detail)); print(('PASS' if ok else 'BLOCK'),name,'-',detail)

ck('api-credential', bool(os.getenv('ANTHROPIC_API_KEY')), 'credential present in environment' if os.getenv('ANTHROPIC_API_KEY') else 'ANTHROPIC_API_KEY not set')
try:
    import anthropic
    ck('anthropic-sdk', True, getattr(anthropic,'__version__','installed'))
except Exception as e:
    ck('anthropic-sdk', False, 'official SDK not installed')
for model in ('claude-sonnet-5-5','claude-opus-5-5'):
    try:
        validate(model,'medium'); ck(f'capability:{model}',True,'medium accepted by package capability registry')
    except Exception as e: ck(f'capability:{model}',False,str(e))

if all(x[1] for x in checks):
    print('TARGET RUNTIME PREFLIGHT READY')
else:
    print('TARGET RUNTIME PREFLIGHT BLOCKED — install/configure the missing runtime prerequisites before live UAT')
    raise SystemExit(2)
