"""Independent QA entrypoint. Uses manifest-derived, version-agnostic controls only."""
from pathlib import Path
import subprocess,sys,os
ROOT=Path(__file__).resolve().parents[1]
for script in ['validate_package.py','referential_integrity_qa.py','oracle_integrity_qa.py','meta_qa.py','semantic_control_qa.py']:
    subprocess.run([sys.executable,str(ROOT/'scripts'/script)],check=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
print('INDEPENDENT QA PASS')
