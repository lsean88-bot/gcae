import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from runtime.model_effort_selector import select,next_tier
from runtime.controller import RuntimeController,RuntimeState

SCENARIOS=[
 ('NMSB_duplicate_billing','investigation','OPUS_MEDIUM'),
 ('Gencor_COI','investigation','OPUS_MEDIUM'),
 ('VAT_refund_history','regulatory_research','SONNET_HIGH'),
 ('tooling_price_inflation','forensic_reconstruction','OPUS_HIGH'),
 ('mixed_manufacturing_audit','complex_finding','SONNET_HIGH'),
 ('urgent_chairman_fraud','investigation','OPUS_MEDIUM'),
 ('simple_email_after_investigation','formatting','SONNET_LOW'),
]
for name,want,tier in SCENARIOS:
    got=select(want).tier_id
    assert got==tier,(name,got,tier)
    print('PASS',name,got)

# Escalation ladder must be monotonic and never oscillate downward.
seq=['SONNET_MEDIUM','SONNET_HIGH','OPUS_MEDIUM','OPUS_HIGH']
for a,b in zip(seq,seq[1:]):
    assert next_tier(a).tier_id==b,(a,b)
print('PASS monotonic-escalation-ladder')

# Boundary storm: repeated calls, tool explosion, scope drift and agent overflow all stop.
for label,args in [
 ('tool-storm',(.10,4,31,1,.8,3,False)),
 ('agent-storm',(.10,4,4,3,.8,0,False)),
 ('scope-drift',(.10,4,4,1,.8,0,True)),
 ('hard-budget',(1.00,4,4,1,.8,0,False)),
 ('no-progress',(.20,4,4,1,.10,0,False)),
]:
    r=RuntimeController(RuntimeState(label,.5,1.0,12,30,2)); state=r.evaluate(*args)
    expected='STOP' if label in {'tool-storm','agent-storm','scope-drift','hard-budget'} else 'RED'
    assert state==expected,(label,state,expected)
    print('PASS',label,state)
print('V12.1 ADAPTIVE ECONOMY STRESS QA PASS')
