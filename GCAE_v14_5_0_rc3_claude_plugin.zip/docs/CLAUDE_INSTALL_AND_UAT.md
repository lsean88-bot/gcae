# GCAE 14.5.0-rc3 — Claude Code Installation & UAT

**Status: release candidate. Not production accepted.** Iron rules: `core/IRON_RULES.md`. The guard, router and tests are verified at unit level against the documented hook protocol. Production acceptance needs the live Claude Code UAT in `tests/live-runtime/LIVE_UAT_T0_T16.md`.

## Prerequisites
- Claude Code with plugin support.
- **Python 3.8 or newer** on PATH as `python3`, `python` or `py -3`. The launcher fails closed (exit 2) if none works.
- **A POSIX shell.** On Windows install Git for Windows: when Git Bash is absent Claude Code runs hooks through PowerShell, the `bash` launcher cannot start, and a hook that cannot start is a non-blocking error, which means the controls are silently off. The skills' heartbeat check (below) is the compensating control.

## Installation
1. Retain the previous plugin package as rollback/reference.
2. Install through Claude Code's plugin flow; choose **Replace existing plugin** only after step 1.
3. Start a fresh Claude Code session in the project directory.
4. Run `/gcae-enterprise-assurance-risk:status`, then `bash "<plugin_root>/hooks/run_guard.sh" status`. Expect `runtime_available: true`, `status: RUNNING` and empty `preflight_problems`. Anything else means the control plane is unavailable: every GCAE skill will refuse to work (by design) and the guard will have stopped the run.
5. Run the smoke tests below, then the live UAT.

## What is enforced mechanically (hooks/gcae_guard.py — the single runtime authority)
| Control | Behaviour |
|---|---|
| Preflight | Required files, skills, release-identity agreement, optional hash manifest; failure = terminal STOP `CONTROL_PLANE_UNAVAILABLE` |
| Fail-closed | Any guard crash, malformed input or lock failure exits 2 (the only blocking code) |
| Terminal STOP | Tools denied, prompts blocked until an explicit human restart |
| Restart | Only a standalone human prompt: `/gcae-enterprise-assurance-risk:restart` or the T10 phrase; max 3 per session; cumulative totals carried; refused after a log-integrity failure |
| Scope | First task fixes the authorised scope; a prompt proposing more (e.g. "also investigate the CEO…") is held until `/gcae-enterprise-assurance-risk:scope approve` or `decline`; destructive tool names stop the run |
| Loops and limits | **Per human instruction** (all reset when you send a new task): exact and normalised repeats (3rd stops), cycles, no-progress (5 identical results), lifetime cap, tool limits (main 60, per sub-agent 40, global 200). A lifetime backstop of 1,000 tool calls per run remains |
| Agents | 5 active max, no nested delegation, duplicate specialist task denied |
| Provider failures | Structured codes only; any `StopFailure` stops; 6 tool failures stop |
| Evidence | Hash-chained `events.jsonl`; state protected from tool writes; deletion detected (`STATE_RESET`) |
| Routing | The deterministic router runs on every task prompt; the decision is logged and given to the model as factual context |
| Confidentiality | Production profile (default) logs prompt **hashes only**; the state directory is private and git-ignored. Set `GCAE_PROFILE=uat` for UAT sessions to also record prompt text as evidence |
| Telemetry | Never fabricated: tokens/model from the transcript, effort and provider-reported values only when supplied; cost is `NOT OBSERVED` unless a provider reports it |

**Not enforceable by hooks (verified only from live transcripts):** whether the model keeps to scope in prose, anomaly-versus-fraud discipline, resisting injected instructions, contradiction handling, regulatory-source judgement. `core/output-templates.md` makes these visible for review.

## Smoke test
- Communication-only: rewrite a supplied email; verify no investigation and a logged `ROUTE intent=communication`.
- Audit: request a finding structure from supplied evidence.
- Investigation: distinguish anomaly / suspicion / allegation / substantiated conclusion.
- Research: ask for authoritative-source verification with conflicts kept visible.
- Status: read-only; unavailable telemetry reads `NOT OBSERVED`.

## Live UAT and evidence
Follow `tests/live-runtime/LIVE_UAT_T0_T16.md`. Run UAT sessions with `GCAE_PROFILE=uat` (records prompt text; production default records hashes only). Set `GCAE_CAPTURE_RAW=1` for the first session only, to confirm real hook payload fields. Afterwards: `bash tools/collect_evidence.sh <project> <plugin_root> <out>` and `python3 tools/grade_uat.py <out> --md grades.md --transcript <session.jsonl>`.

## Pre-live gates (run on your own machine)
`python3 tests/run_all.py` must pass (it fails on any failing test and on zero collected tests); `python3 tests/guard/mutate_guard.py` must report no survivors; `python3 tests/guard/fuzz_guard.py --seeds 1500 --steps 70` must report zero invariant violations.

## If Claude says "A plugin or hook stopped this message"
A hook refused your message. In order of likelihood:
1. **The old v14.4.0 plugin is still installed.** It stops on ordinary tools (the first `Skill`, `ExitPlanMode` or `AskUserQuestion` call) and after 60 tool calls in a whole session, then refuses every later message. Disable or remove it with `/plugin`; keep only one GCAE plugin enabled (two hook sets run in parallel and race on the same state).
2. **GCAE is stopped.** Send `/gcae-enterprise-assurance-risk:status` to see the reason. To continue, send `/gcae-enterprise-assurance-risk:restart` as your whole message, or the sentence "Explicitly restart the GCAE controlled runtime and begin a new controlled session." Both forms work.
3. **The guard cannot start (no Python 3.8+).** Your message is NOT blocked: you see a warning and tool calls are blocked until Python is installed.
4. **Files edited on Windows.** CRLF line endings are tolerated; a real content change in any plugin file stops the run (`CONTROL_PLANE_UNAVAILABLE`).
If none applies, run `bash "<plugin_root>/hooks/run_guard.sh" status` and send me its output.

## Troubleshooting
- **Locked out / repeated STOP:** read `status`. `STATE_RESET`, `LOG_TAMPER` or `CONTROL_PLANE_UNAVAILABLE` need the cause fixed. An administrator can reset by deleting the project `.gcae` directory (this deliberately discards evidence).
- **Hook cannot start:** install Python 3.8+ and, on Windows, Git Bash; disabling the plugin is the only other escape.
- **Deny format:** if a Claude Code version ignores JSON deny output, set `GCAE_DENY_MODE=exit2`.
- State location: `<project>/.gcae`, or `GCAE_STATE_DIR` / `GCAE_RUNTIME_DIR`.
