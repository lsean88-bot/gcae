# v14.4.0 Build Contract

1. Preserve 100 capabilities and 45 agents unless a separately approved equivalence record exists.
2. One authoritative threshold source: `core/policy/execution-thresholds.json`; YAML is a derived human-readable view.
3. One release identity: plugin manifest + release manifest + release identity must match.
4. Runtime STOP is terminal until exact human restart.
5. Provider failure classification trusts only explicit structured error fields or exact enum strings in those fields; no arbitrary content scanning.
6. Scope defaults fail-closed; destructive tools require explicit approval.
7. Dependency graph depth is distinct from runtime delegation depth.
8. Quarantined tests cannot support release acceptance.
9. No fabricated token/cost/model/effort telemetry.
10. Live Claude Code UAT is a mandatory external gate and cannot be simulated by Python.
