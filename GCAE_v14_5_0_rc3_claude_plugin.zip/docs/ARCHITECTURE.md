# GCAE v13.0.0 — Bottom-Up Production Rebuild

## Architecture authority
v13 is rebuilt from a clean package root. Existing specialist agents, references, jurisdictions, industries and evidence assets are imported as a protected payload, while the active control plane is reconstructed from first principles under `core/`.

**Control order:** Invariants → Precedence → Ontology → State Machine → Capability Registry → Dependency Closure → Workstream Planning → Economy → Route QA → Runtime Execution → Evidence/Reporting → Release.

### Key rule
The legacy v12.2 router and scripts are quarantined. They remain available for regression and historical comparison but cannot serve as production routing authority.

### Preservation boundary
No protected specialist/content asset is rewritten merely to achieve architectural cleanliness. Overlap candidates are recorded for controlled future review. No heuristic similarity permits deletion or merging.

### Production boundary
This is a release candidate until live Claude runtime UAT, empirical token/cost measurement, assurance-quality comparison, external trusted-root validation and four-eyes approval are complete.
