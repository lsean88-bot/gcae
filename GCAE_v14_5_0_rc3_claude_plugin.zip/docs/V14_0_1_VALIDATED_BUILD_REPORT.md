# GCAE v14.0.1 Validated Build Report

## Decision

**Build status:** VALIDATED BUILD

**Production status:** NOT ACCEPTED

This build is the reconciled successor to v14.0.0. It is cleared as the canonical development/build baseline after local package, control-plane, routing, mutation, misfire, adversarial, plugin and execution-control validation.

## Defects resolved in this build

1. **Execution-threshold drift:** the execution-safety policy previously stated tool warning/hard-stop thresholds of 20/30 while the runtime hook implemented 40/60. The policy is now aligned to the implemented 40/60 operational defaults.
2. **Package-root integrity:** the plugin archive extraction/build process could leave hidden `.claude-plugin` content below a nested directory. The validated build has `.claude-plugin/plugin.json` at the package root and the archive is built from that canonical root.
3. **Release-manifest file-count drift:** the prior manifest counted 255 files while the canonical package contained 256. The validated build regenerates the count from the complete tree, including hidden plugin metadata.

## Local validation

- v14 skill QA: PASS
- v14 package QA: PASS
- v14 execution-control QA: PASS
- v13 integrity QA: PASS
- v13 bottom-up UAT/controller/structural QA: PASS
- misfire QA: PASS 14/14
- mutation QA: PASS 11/11
- extreme adversarial QA: PASS 14 semantic + 1,000 fuzz + controller boundaries + effort safety
- plugin validation: PASS
- release manifest QA: PASS
- ZIP integrity: PASS

## Runtime gate

Actual execution inside the target Claude runtime remains an external acceptance gate. Local package tests do not substitute for actual Claude model/context/token/tool telemetry, runtime latency, billed/estimated cost, or independent four-eyes approval.

## Operating rule

The validated build is the **build/development baseline**, not a production-accepted release. Any future change must branch from this baseline, pass the release QA suite, and receive a new immutable build identity.
