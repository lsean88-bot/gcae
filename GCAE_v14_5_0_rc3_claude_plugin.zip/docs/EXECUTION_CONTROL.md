# GCAE v14.0.1 — Execution Control Model

## 1. Authority
Native Claude Code controls remain the first execution boundary. GCAE adds assurance-specific controls that Claude does not reliably provide as a domain control plane.

## 2. State
`PLANNED → RUNNING → AMBER → COMPLETED` or `RUNNING/AMBER → STOP`. STOP has no automatic return path.

## 3. Progress
A tool call is not progress. Progress requires a meaningful state change: artifact creation/change, completed builder/QA, validated evidence, reconciliation, decision, or workflow transition.

## 4. Repetition
The controller fingerprints tool name + normalized arguments + execution stage. Repeated identical calls beyond the configured threshold trigger STOP unless the tool is explicitly allow-listed as safely repeatable.

## 5. No progress
Repeated events without a meaningful state transition increment a no-progress counter. The threshold triggers STOP.

## 6. Stop hooks
Stop hooks may finalize or report. They may not create an unbounded continuation loop. At most one controlled continuation is permitted; a second incomplete stop condition is terminal.

## 7. Rate limits
A rate-limit signal opens the circuit. New queued work is not dispatched. Work that never started is marked `SKIPPED_LIMIT`, not `FAILED`. The reset reason is surfaced once per workflow.

## 8. Status
Status must expose state, stage, progress, tools, agents, tasks, last meaningful progress, repetition/no-progress indicators, errors and stop reason. Unknown values remain `UNKNOWN`.
