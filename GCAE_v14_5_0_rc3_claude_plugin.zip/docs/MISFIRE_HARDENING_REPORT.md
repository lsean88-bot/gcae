# GCAE v13.1.2 Misfire Hardening Report

## Corrected
- Quoted evidence no longer drives routing or model escalation.
- Communication-only requests are protected unless substantive action is explicitly requested.
- Compliance/statutory words no longer automatically convert an audit task into research.
- Domain specialists are selected after intent/task classification.
- Risk, retrieval, knowledge and advisory intents are explicitly routable.
- Hard runtime limits now terminate with STOP rather than silently continuing in RED.
- Model-effort selection is quote-safe and intent/risk-aware.

## Known target-runtime boundary
Static tests cannot prove Claude Code hook enforcement. Actual hook firing, tool denial, agent recursion, session persistence and target-runtime behaviour remain live-UAT gates.
