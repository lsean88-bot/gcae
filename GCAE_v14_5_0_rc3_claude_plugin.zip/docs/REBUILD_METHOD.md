# v13 Rebuild Method

1. Freeze v12.2 as regression baseline.
2. Create clean package root.
3. Import protected payload without content mutation.
4. Re-derive canonical control layers from first principles.
5. Make routing intent/work-product based rather than lexical-score authoritative.
6. Make dependencies and workstreams explicit.
7. Put economy/runtime controls outside specialist self-governance.
8. Quarantine historical control implementations.
9. Generate derived indexes/manifests from canonical sources.
10. Run differential regression and adversarial UAT.
11. Perform live target-runtime UAT before production promotion.
