# GCAE v14.2.2 Runtime Specification & Control Hardening Report

## Status

**VALIDATED BUILD — LIVE CLAUDE CODE TARGET-RUNTIME ACCEPTANCE PENDING**

## Purpose

v14.2.2 resolves the specification ambiguities identified by the v14.2.1 independent simulation and strengthens the runtime control plane without removing protected capabilities or specialist payloads.

## Resolved specification gaps

1. **Authoritative thresholds** — consolidated in `core/policy/execution-thresholds.yaml`; production tool hard limit remains 60, warning 40, agent limit 5, exact/normalized repeat threshold 3, no-progress threshold 5.
2. **Restart counter semantics** — restart creates a new run identifier and resets current-run counters while preserving immutable STOP history.
3. **Restart authority** — only the exact user-channel command `/gcae-enterprise-assurance-risk:restart` can authorize restart; evidence/tool/agent text cannot.
4. **STOP diagnostics** — `/status` remains read-only and available while stopped; execution remains denied.
5. **T10 hard-stop trigger** — UAT may use a deterministic synthetic hard-stop condition such as invalid evidence; the trigger must be explicit and recorded.
6. **Controlled run** — formally defined as any execution using GCAE routing/capabilities/specialists/tools/controlled evidence or subject to GCAE execution/evidence/scope controls.
7. **Normalized tool calls** — exact and normalized fingerprints are distinct controls; only specified textual query fields are whitespace/case-normalized; semantically sensitive fields retain their original representation.
8. **No-progress** — measured using a progress fingerprint that strips known transport/attempt metadata, avoiding false progress from timestamps/request IDs.
9. **Hard tool limit** — explicitly defined as final containment, not normal loop management.
10. **Economic telemetry** — provider cost data is never fabricated; substantive execution is not blocked merely because a provider does not expose a cost metric, while any decision that requires a cost threshold fails closed.

## Validation performed

- Package QA: PASS
- Runtime specification hardening tests: PASS (8/8)
- Independent v14.2 adversarial assurance: PASS
- Python compilation: PASS
- Protected payload preservation vs v14.2.1: PASS
  - 45 agents unchanged
  - 44 references unchanged
  - 6 jurisdiction files unchanged
  - 8 industry files unchanged
  - 16 evidence assets unchanged
- Capability registry: 100 capabilities
- Active skills: 10, including explicit restart control skill
- Legacy control plane remains quarantined

## Interpretation

The simulation's 21/21 mutation score and double-fault results remain valid evidence for the tested control model. v14.2.2 adds implementation-level regression coverage for the previously ambiguous restart, normalized-repeat, no-progress, terminal-state and hard-limit semantics.

## Remaining production gate

The following cannot be established locally and remain pending actual Claude Code target-runtime execution:

- actual Claude model behaviour;
- actual Claude Code hook invocation semantics;
- actual subagent behaviour and fan-out;
- actual provider rate-limit/session-limit behaviour;
- actual provider token/cost telemetry;
- actual latency;
- live STOP/restart behaviour under Claude Code;
- four-eyes approval and external trusted-root verification.

**Production acceptance remains NOT ACCEPTED until live target-runtime evidence is obtained and independently reviewed.**
