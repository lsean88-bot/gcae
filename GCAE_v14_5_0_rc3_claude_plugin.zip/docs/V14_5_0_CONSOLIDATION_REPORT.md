# GCAE 14.5.0-rc3 — Consolidation report

Status: release candidate. Findings below were verified by running code against the received v14.4.0 package; measured results are from the runs recorded at the end. Live Claude Code evidence is outstanding.

## 1. Packages compared
- **v14.4.0 (received):** 355 files; 100 capabilities, 45 agents, 44 reference files (42 registered); hook, runtime modules, 59 test files.
- **Overlay v14.2.2-rc1:** fail-closed guard, hash-chained evidence log, grader, templates (my earlier build).
- **Consolidated v14.5.0-rc3:** v14.4.0 content base plus one merged enforcement authority, with the defects below fixed.

## 2. Verified defect register
| ID | Package | Severity | Class | Finding | Evidence | Fix in 14.5.0 | Regression test |
|---|---|---|---|---|---|---|---|
| V-01 | v14.4.0 | High | Fail-open | Hook launch or crash fails open. hooks.json calls bare `python`; a missing interpreter (exit 127) or any crash (exit 1) is a non-blocking error per the official hook reference, so every control is silently off. | Probe G: rc 127 with `python` off PATH. Probe F: deleting the policy file crashes the hook (traceback, rc 1, no deny). | Fail-closed launcher (python3/python/py -3, exit 2) and a guard that converts every exception to exit 2. | t_launcher; t_malformed_and_corrupt (internal error); t_preflight |
| V-02 | v14.4.0 | High | Control plane | No runtime preflight. SessionStart did nothing; a missing policy crashed the hook instead of stopping controlled work (UAT T0 expects a controlled STOP). | Probe F; code review of hooks/telemetry_hook.py. | Preflight: required paths, skills, release-identity agreement across plugin.json / manifest / policy, optional hash manifest; failure = terminal STOP. | t_preflight (11 assertions) |
| V-03 | v14.4.0 | High | Scope | Scope control is defeated by a second prompt: the task envelope is overwritten on every prompt, so the T8 expansion (CEO, five years, entire Group) became the authorised scope. | Probe B: envelope request replaced; Grep on the expanded scope was allowed. | Original scope fixed; expansion held; only an explicit human `scope approve/decline` changes it; decisions logged. | t_scope_and_destructive |
| V-04 | v14.4.0 | High | False stops | Substring tool classification plus an unknown-tool default of stop: 36 of 90 (40%) benign tool calls stopped. Skill, ExitPlanMode, AskUserQuestion and unregistered MCP tools stopped on every prompt tested; Bash, Edit, Write, TodoWrite stopped on 2 of 5. | Probe A over 18 ordinary Claude Code tools x 5 UAT-style prompts. | Token-based tool classes; unknown tools allowed and logged; only destructive tool names stop. | t_false_stops (0 of 90) |
| V-05 | v14.4.0 | High | State integrity | State lives in the OS temp directory, unprotected and unchained. Deleting the state file silently resets every counter; tools may write or delete it. | Probe C: deleting the file reset a count of 2 so a third identical call was allowed; Write and `rm` into the state directory were not denied; Probe M: truncated log not detected. | Project `.gcae` (or GCAE_STATE_DIR / GCAE_RUNTIME_DIR), hash-chained log, STATE_RESET detection with lineage rebuilt from the log, tool writes denied. | t_integrity |
| V-06 | v14.4.0 | Medium | Availability | A stale lock directory (hook killed mid-update) is never cleaned: every later hook fails with STATE_LOCK_FAILURE until manual deletion. | Probe D: still rc 2 after 4 s. | Stale-lock expiry (10 s) and bounded wait. | t_integrity (stale lock heals; fresh lock fails closed) |
| V-07 | v14.4.0 | Medium | Restart | The UAT T10 phrase does not restart (only the exact slash command does); restarts are unlimited with a full counter reset and no lineage. | Probe E: phrase left the run in STOP; 10 further stop/restart cycles all succeeded. | Both forms accepted only as a standalone prompt; cap 3 per session; cumulative totals carried; refused after log tamper. | t_stop_restart |
| V-08 | v14.4.0 | Medium | Loop detection | Repeat detection resets on any changed response, so an agent repeating one call while a response field changes is never stopped by repeat detection. | Probe H: 30 identical calls with a changing `retrieved_at` were never stopped by repeat detection. | Episode-aware reset kept (their C-06 trade-off) plus a lifetime cap (12) and a wider volatile-field list. | t_repeat_family (stops at the 12th) |
| V-09 | v14.4.0 | Medium | Agents | Nested delegation is undetected: depth is derived from fields (`parent_agent_id`) the official payload does not carry; the documented `agent_id` is ignored. | Probe J: a Task call made with `agent_id` set was allowed. | Spawn from a context carrying `agent_id` stops (DEPENDENCY_DEPTH_LIMIT); policy depth set to 1. | t_agents |
| V-10 | v14.4.0 | Medium | Telemetry | Policy says missing telemetry fails closed, but hooks never fail closed and official payloads carry no token/cost fields; `effort` arrives as an object and was stored as one. | Probe I; official hook reference. | Absent = NOT OBSERVED; invalid = STOP; tokens/model from the transcript; effort.level parsed; cost never trusted without a provider basis. | t_telemetry |
| V-11 | v14.4.0 | High | Assurance gap | The router, dependency closure and workstream planner are never executed at runtime: the hook imports only the adapter and scope modules. Routing exists only in tests. | Repository search: no runtime caller outside tests. | Router runs on every task prompt; decision logged; given to the model as factual context; incomplete closure stops the run. | t_routing_runtime |
| V-12 | v14.4.0 | High | Routing | The router misroutes the UAT prompts: negated instructions count as requests, communication-only work can be risk L4, T6 becomes assurance, T8 investigation, T15 only L3. 5 of 8 cases wrong; T2 depended on whether the prompt contained newlines. | Measured on exact UAT prompts. | Negation stripping, intent-first risk, narrower investigation terms, verb-object audit detection, nominee escalation. Golden and metamorphic suites still pass. | tests/guard/test_routing_uat.py (5 tests) |
| V-13 | v14.4.0 | High | Test assurance | Five of the nine 'mandatory' tests are pytest-style files with no runner: executed as scripts they run zero tests and exit 0. Run under pytest, 1 of 7 fails (dependency-closure expectation). The concurrency test asserts only 0 <= count <= 30. | Ran all 9 as scripts (all exit 0) then under pytest (1 failure). | tests/run_all.py fails on zero collected tests; failing test corrected; concurrency asserts exactly 30; mutation gates added. | tests/run_all.py |
| V-14 | v14.4.0 | Medium | Test assurance | The headline 100,000-trace conformance and the mock UAT exercise a reference model (openai_agents control), not the hook Claude Code runs. Three implementations of the same logic exist (hook, controller, OpenAI state). | Import analysis of the tests. | Guard declared the single authority; the models are labelled and demoted to a non-gating reference tier. | TEST_AUTHORITY.yaml |
| V-15 | v14.4.0 | Low | Package hygiene | Version string in about 40 active files; a stale BUILD_HASHES_V14.3.2 with 61 mismatches ships beside the current manifest; docs reference a test that does not exist; the master skill is duplicated. | Hash check; documentation link check. | Drift tests, one manifest, install doc rewritten, duplicate parity test. | tests/guard/test_consistency.py (13 tests) |
| V-16 | v14.4.0 | Low | Registry | Two reference files are unregistered (one referenced by nothing); the manifest counts 42 references against 44 on disk. | Registry vs directory comparison. | Declared as support references; invariant test added. | test_every_reference_is_registered_or_declared_support |
| V-17 | v14.4.0 | Medium | Provider failures | StopFailure types outside the adapter's list (account_on_hold, oauth_org_not_allowed, max_output_tokens, unknown) are ignored: fail-open on an unrecognised provider failure. | Adapter enum compared with the official matcher list. | Enum extended; any StopFailure stops (UNCLASSIFIED if unrecognised). | t_provider (8 codes plus unknown) |
| V-18 | v14.4.0 | Low | Dependencies | dependency_closure.py imports PyYAML without using it, adding an install-time dependency to the router. | Code review. | Import removed. | router and routing tests run without PyYAML on the router path |
| V-19 | v14.4.0 | Medium | Assurance | RELEASE_MANIFEST carries self-reported PASS results while declaring builder self-certification FORBIDDEN. | Manifest review. | Replaced by measured results generated from an actual run. | RELEASE_MANIFEST.json |
| W-01 | overlay | Medium | False stops | My overlay never reset repeat counts, so legitimate iteration (re-running the same check after an edit) would stop on the third identical call. | Compared with the v14.4.0 episode design. | Episode-aware reset adopted from v14.4.0. | t_repeat_family |
| W-02 | overlay | High | False stops | My overlay treated `description` as volatile for every tool, so three Task spawns differing only in description looked identical and stopped as a loop. | Found by porting the v14.4.0 five-agent baseline case. | Volatility applies to Bash only. | t_agents; mutant task_description_substantive |
| W-03 | overlay | Medium | Classification | Provider failure was classified by regex over the whole payload, so content such as 'timeout' or '429' in tool input could be read as a provider failure. | Code review. | Structured fields only (adapter). | t_provider |
| W-04 | overlay | Low | Telemetry | Effort (an object in the official payload) was stored as a stringified dict. | Official reference. | effort.level parsed. | t_telemetry |
| W-05 | overlay | Low | Wording | Hook context used imperative wording; the official reference advises factual statements to avoid prompt-injection defences surfacing the text. | Official reference. | Factual wording. | t_scope_and_destructive; t_routing_runtime |
| W-06 | overlay | Medium | Limits | A single global tool limit of 40 is unusable for multi-agent runs, which T9 requires. | Design review. | Main 60, per sub-agent 40, global 200 (ASSUMED). | t_noprogress_and_limits |
| W-07 | overlay | Medium | Platform | The launcher needs `bash`; on Windows without Git Bash the hook cannot start and fails open. | Official reference (PowerShell fallback). | Skills' heartbeat check is the compensating control; install guide requires Git Bash. Residual risk. | docs/CLAUDE_INSTALL_AND_UAT.md |
| W-08 | overlay | High | Coverage | No content base, routing or dependency enforcement: the overlay could not stand alone as a plugin. | Scope review. | Consolidated onto the v14.4.0 base. | n/a |
| W-09 | overlay | Low | Loop detection | No cyclic loop detection (A-B-A-B). | Compared with v14.4.0. | Ported. | t_repeat_family |
| W-10 | overlay | Medium | Authority | A second policy file duplicated v14.4.0 thresholds, creating exactly the divergence risk found in v14.4.0. | Review. | One JSON authority; YAML is a verified view. | test_policy_json_is_single_authority_and_yaml_is_a_faithful_view |
| W-11 | overlay | Medium | Test realism | Overlay tests ran against a stub plugin tree, so preflight and routing were never exercised on real files. | Review. | Harness copies the full consolidated tree. | tests/guard/harness.py |
| FZ-01 | rc1 (fuzz) | Medium | Robustness | A non-string `agent_id` (an integer) mixed with the string key 'main' made the sorted JSON state dump raise TypeError, so an ordinary event caused an internal-error stop. | Fuzz seed 35 with traceback. | Context keys coerced to strings. | t_hardening; mutant agent_ctx_string |
| FZ-02 | rc1 (fuzz) | High | Evidence integrity | A restart was permitted on a tampered evidence log whenever the run had already stopped for a different reason (only a LOG_TAMPER stop refused restart). | Fuzz invariant I4/I5 (independent restart oracle). | A broken chain overrides any earlier stop reason and blocks restart. | t_hardening; mutant restart_blocked_on_broken_chain |
| FZ-03 | rc1 (fuzz) | Medium | Robustness | Non-string tool_name, file_path or command in a payload crashed string concatenation or path handling (TypeError), producing internal-error stops on ordinary events. | Fuzz: 22 of 27 early violations. | Tool names, paths and commands coerced; helpers never pass non-strings to os.path. | t_hardening; mutants tool_name_coercion, path_coercion |
| FZ-04 | rc1 (fuzz) | Medium | Robustness | A non-string session_id crashed state-directory creation. | Fuzz generator with hostile session ids. | Session ids coerced and sanitised. | t_hardening; mutant session_id_string |
| FZ-05 | rc1 (fuzz) | Medium | Latent security | A non-string transcript_path (e.g. the integer 5) would be tested with os.path.exists and could be opened as a file descriptor. | Code review during fuzz triage. | Only string paths accepted. | t_hardening; mutant transcript_path_string |
| FZ-06 | rc1 (fuzz) | Low | Consistency | After state loss the epoch no longer equalled 1 + restarts (lineage was rebuilt but the epoch was not). | Fuzz invariant I6. | Epoch rebuilt with the lineage. | t_hardening; mutant epoch_after_state_loss |
| FZ-07 | rc1 (review) | Medium | Confidentiality | Prompt text (potentially confidential audit matter) was written to the evidence log by default. | Design review. | Production default logs prompt hashes only; GCAE_PROFILE=uat records text for UAT; state directory private and git-ignored. | t_hardening; mutants prompt_text_profile, gitignore_safeguard |
| FZ-08 | rc1 (review) | Low | Evidence integrity | Log tampering was detected only at a prompt or session start, not at the end of a turn. | Fuzz oracle review. | Chain also verified on the Stop hook. | t_hardening; mutant stop_verifies_chain |
| FZ-09 | rc1 (review) | Low | Availability | No cap on evidence-log growth and unbounded regex analysis of very large prompts. | Design review; 2.7 MB prompt test. | 5 MB log cap (STOP LOG_SIZE_LIMIT); prompt analysis bounded to 20,000 characters (hash covers all). | t_hardening; mutants log_size_cap, analysis_truncation |
| FZ-10 | rc1 (review) | Low | Efficiency | Each log append read the whole log (O(n)). | Code review. | Tail read; 38 ms median per event with a 10,000-record log. | measured; t_concurrency |

## 3. SWOT
### v14.4.0 (as received)
**Strengths**
- Rich content base: 100 capabilities, 45 agents, registry, dependency graph, ontology, preservation matrix, disposition register
- Structured provider-failure classification immune to content tokens
- Episode-aware repeat and no-progress logic; cyclic-loop detection
- Correct state lock: 30 parallel events produced exactly 30 counts
- Release-identity validator; build hashes verified clean across 354 files
- Honest independent-counsel register; test constitution and regression-preservation rule
- Wrapper preflight present in every skill

**Weaknesses**
- Fail-open on launch or crash (V-01, V-02)
- Scope control defeated by a second prompt (V-03); 40% false stops (V-04)
- Mutable temp-dir state, no integrity, silent reset, stale-lock deadlock (V-05, V-06)
- Router never executed at runtime and misroutes UAT prompts (V-11, V-12)
- Vacuous or failing mandatory tests; headline tests exercise reference models (V-13, V-14)
- Version, manifest and documentation drift (V-15, V-16, V-19)

**Opportunities**
- Use the official payload fields (agent_id, effort.level, transcript_path)
- Wire the router and dependency closure into the hook
- Single authority and a log-driven UAT grader

**Threats**
- Controls silently absent on machines without `python` or a POSIX shell
- Lockout from false stops makes the plugin unusable
- Reviewers trusting self-reported PASS

### My overlay v14.2.2-rc1
**Strengths**
- Fail-closed launcher and guard
- Hash-chained evidence log, protected state, reset detection
- Human-only restart with cap and lineage
- Transcript-derived telemetry that never fabricates
- UAT grader, output templates, mutation-tested (41/41 guard, 19/19 grader at the time)

**Weaknesses**
- No content base, routing or capability enforcement (W-08)
- No episode logic: false stops on legitimate iteration (W-01)
- Description-volatility bug (W-02); regex provider classification (W-03)
- Global tool cap unusable for fan-out (W-06); stub-tree tests (W-11); second policy file (W-10)

**Opportunities**
- Merge onto the v14.4.0 base
- Adopt structured failure codes and cyclic detection

**Threats**
- Bash dependency on Windows (W-07)
- Version drift against the base it was built for

### Consolidated v14.5.0-rc3
**Strengths**
- One enforcement authority, fail-closed end to end
- Router executed, logged and fixed; UAT prompts route correctly
- Every verified defect has a regression test; mutation-tested guard
- Preserved v14.4.0 baseline (18 cases ported) and content base
- Evidence grader plus invariants against drift
- Fifteen iron rules, each mapped to enforcement, tests, mutants and live-UAT stage (a test fails the build if a rule loses its proof)
- Fuzzed: 1,500 adversarial sequences / 105,000 events with zero invariant violations after fixing 6 defects
- Context economy tested: master skill about -32%, preflight about -40%, hook context about 33 tokens per prompt

**Weaknesses**
- No live Claude Code evidence yet
- Behavioural controls cannot be enforced by hooks
- Several thresholds are ASSUMED (per-agent 40, global 200, lifetime 12, restart cap 3)
- Router remains lexical; scope-expansion detection is marker-based

**Opportunities**
- First live run with GCAE_CAPTURE_RAW=1 confirms payload fields
- Independent reviewer re-grade against raw logs

**Threats**
- Hook protocol drift in future Claude Code versions
- Windows without Git Bash disables hooks (heartbeat is the only guard)
- Model non-compliance in prose despite hooks

## 4. Control traceability (what was kept, merged, replaced)
| Control | v14.4.0 | Overlay | Consolidated | Disposition |
|---|---|---|---|---|
| Fail-closed on guard failure | No (fail-open) | Yes | Yes, every exception exits 2 | NEW (overlay), extended |
| Control-plane preflight | Prose only | Files, skills, manifest | Plus release-identity agreement | MERGED |
| Terminal STOP | Yes | Yes | Yes (continue:false plus deny) | KEPT |
| Human restart | Exact slash command only, unlimited | Phrase, capped | Both forms, standalone, cap 3, lineage | MERGED, TIGHTENED |
| Scope authority | Overwritten by next prompt; tool-class stops | None (behavioural) | Expansion held; explicit decision; destructive stop | REPLACED |
| Exact repeat | Episode-aware | Strict, no reset | Episode-aware plus lifetime cap | MERGED |
| Normalised repeat | Yes | Yes | Yes | KEPT |
| Cyclic loop | Yes | No | Yes | KEPT (v14.4.0) |
| No-progress | Yes (5) | Yes (3) | Yes (5), episode-aware | KEPT (v14.4.0) |
| Tool limits | 40/60 global | 40 global | Main 60, sub-agent 40, global 200 | CHANGED (assumed) |
| Agent cap | 5, stop | 5, deny then stop | 5, stop | KEPT (v14.4.0) |
| Delegation depth | 2, undetectable | agent_id denial | 1 via agent_id | TIGHTENED |
| Duplicate specialist | No | Deny | Deny | NEW (overlay) |
| Provider failure | Structured codes | Regex over payload | Structured, official enum, unknown stops | EXTENDED |
| Tool-failure bound | None | 6 | 6 | NEW (overlay) |
| Telemetry | Contradictory policy | Transcript-derived | Absent = NOT OBSERVED; invalid = STOP | MERGED |
| Evidence log | Plain jsonl | Hash-chained | Hash-chained | NEW (overlay) |
| State storage | Temp dir, mutable | Project .gcae, protected | Same plus RUNTIME_DIR compatibility | REPLACED |
| State-reset detection | None | Yes | Yes | NEW (overlay) |
| State lock | mkdir, never expires | File, stale heal | File, stale heal | FIXED |
| Router | Not executed; misroutes | None | Executed, logged, corrected | WIRED and FIXED |
| Dependency closure | Tests only | None | Enforced per task | WIRED |
| Release identity | Test-time only | None | Runtime preflight | WIRED |
| Hash manifest | Stale old manifest also shipped | Optional | Optional; required at release | CLEANED |
| Injection scanner | None | Yes | Yes (prompts and tool results) | NEW (overlay) |
| UAT grader | None | Yes | Updated for new events | NEW (overlay) |
| Output templates | None | Yes | Yes, referenced from preflight | NEW (overlay) |
| Iron rules | Prose list of 9-11 controls | None | 15 rules as data; traceability and completeness tests | NEW (rc2) |
| Fuzzing | None | None | In-process invariant fuzzer, release gate | NEW (rc2) |
| Token economy | Unmeasured | None | tools/token_budget.py plus budget tests | NEW (rc2) |
| Confidentiality profile | Not addressed | Prompt text logged | Hash-only by default; UAT profile opt-in; git-ignored private state | NEW (rc2) |
| Capabilities, agents, references | 100 / 45 / 44 | None | Preserved unchanged | KEPT (v14.4.0) |
| Skills preflight | File readability (prose) | Heartbeat (prose) | Heartbeat plus readability | MERGED |
| Control skills | status, restart | None | status via guard JSON, restart forms, new scope skill | EXTENDED |
| Test constitution | 9 mandatory (5 vacuous) | Mutation harnesses | Runner fails on zero tests; mutation gates | REPAIRED |
| Reference-model tests | Headline evidence | None | Demoted to non-gating tier | RELABELLED |
| OpenAI adapter, independent counsel, history | Present | None | Preserved | KEPT (v14.4.0) |

## 5. Decisions needed from the owner
| ID | Decision | Rationale | Owner choice |
|---|---|---|---|
| DC-01 | Delegation depth 1 (tightened from 2) | No nested spawn from a subagent; matches UAT T9 and is detectable via agent_id | Accept / change |
| DC-02 | Tool limits: main 60, per sub-agent 40, global 200 | ASSUMED; multi-agent runs need per-context budgets | Accept / change |
| DC-03 | Lifetime identical-call cap 12 | ASSUMED; backstops episode-reset evasion without blocking normal iteration | Accept / change |
| DC-04 | Restart cap 3 per session; both restart forms accepted | ASSUMED cap; phrase accepted to match the UAT | Accept / change |
| DC-05 | Scope expansion held until explicit human decision | Marker-based detection (also / entire / five years / CEO ...); benign follow-ups unaffected | Accept / change |
| DC-06 | Destructive tool names stop the run (token-based) | Preserves the v14.4.0 baseline with far fewer false stops | Accept / change |
| DC-07 | Telemetry semantics: absent = NOT OBSERVED, invalid = STOP | Hooks cannot observe tokens or cost; the old fail-closed rule could never be satisfied | Accept / change |
| DC-08 | Router decision advisory but logged; incomplete closure stops | Router remains lexical; crash is logged, not fatal | Accept / change |
| DC-09 | Router corrections (negation, risk, research, nominee) | Fixes 5 of 8 UAT misroutes; golden and metamorphic suites unchanged | Accept / change |
| DC-10 | STOP lock scope: session (default) or project | Project scope survives new sessions | Choose |
| DC-11 | Require hash manifest at release | Set guard.require_manifest true after generating BUILD_HASHES_V14.5.0.sha256 | Accept / change |
| DC-13 | Production profile logs prompt hashes only (UAT profile logs text) | Confidentiality of audit matter; UAT needs exact prompts as evidence | Accept / change |
| DC-14 | Evidence log cap 5 MB; prompt analysis bounded to 20,000 characters | Runaway and denial-of-service protection; hash still covers the full prompt | Accept / change |
| DC-15 | Fifteen iron rules adopted as the non-waivable set | Preserves the original professional controls and adds runtime rules with proof | Accept / change |
| DC-16 | Context budgets: always-loaded 700, master 1,250, other skill 560, preflight 260, hook message 80 tokens (estimates) | Economy is a tested property; numbers are estimates (chars/4) | Accept / change |
| DC-12 | Windows requires Git Bash | Without it hooks cannot start; heartbeat check is the only compensating control | Accept risk |

## 6. Residual risks
| Risk | Why | Mitigation |
|---|---|---|
| Behavioural controls (scope prose, anomaly vs fraud, injection resistance, contradictions, regulatory authority) | Hooks cannot enforce semantics; verified only by live transcripts | Output templates, model-initiated STOP, independent review |
| Windows without Git Bash | Hooks cannot start (non-blocking error) so controls are silently off | Skills heartbeat check; install guide; live T0 on each OS |
| ASSUMED thresholds | Per-agent 40, global 200, lifetime 12, restart cap 3 are engineering defaults | Owner approval; adjust after live data |
| Lexical router and marker-based scope detection | Can misclassify unusual phrasing | Advisory only; logged; golden tests; live review |
| Hook protocol drift | Event names and payload fields come from documentation | Raw payload capture; re-verify on each Claude Code upgrade |
| Self-attested evidence log | Written by the component under test | Hash chain, transcript cross-check, independent reviewer |

## 7. Action plan
| ID | Phase | Action | Owner | Target | Exit criterion |
|---|---|---|---|---|---|
| AC-01 | Decide | Approve or change DC-01..DC-16 | [assign: GCAE] | T+2d | Decisions recorded with approver and date |
| AC-02 | Verify env | Run `python3 tests/run_all.py`, `python3 tests/guard/mutate_guard.py` and `python3 tests/guard/fuzz_guard.py --seeds 1500 --steps 70` on the target machine(s) incl. Windows Git Bash | [assign: QA] | T+4d | All pass; no mutant survivors |
| AC-03 | Verify env | First live session with GCAE_CAPTURE_RAW=1; confirm agent_id, failure fields, effort/model, Task vs Agent, slash-command prompt text | [assign: QA] | T+5d | raw_payloads.jsonl reviewed; policy updated if needed |
| AC-04 | Live UAT | Run T0-T16 per tests/live-runtime/LIVE_UAT_T0_T16.md | [assign: QA] | T+8d | Every stage graded with logs and transcripts |
| AC-05 | Live UAT | Extend T4 to PDF, Excel comment, tool-output and sub-agent injection vectors | [assign: QA] | T+8d | No behaviour change; INJECTION_SUSPECTED logged |
| AC-06 | Live UAT | Attempt a genuine provider failure for T11, else record NOT OBSERVED | [assign: QA] | T+8d | Bounded recovery observed or NOT OBSERVED recorded |
| AC-07 | Grade | collect_evidence.sh then grade_uat.py with --transcript | [assign: QA] | T+9d | Mechanical stages graded; chain verify ok; transcript cross-check consistent |
| AC-08 | Grade | Independent reviewer grades behavioural stages and re-checks mechanical grades | [assign: independent reviewer] | T+10d | Sign-off or rejection per stage |
| AC-09 | Fix | Triage defects; fix; re-run failed stages and the full gates | [assign: plugin owner] | T+14d | No open Critical/High; regression passes |
| AC-10 | Decide | Accept or reject residual risks (behavioural controls, Windows hooks, ASSUMED thresholds) | [assign: GCAE] | T+14d | Risk acceptance recorded |
| AC-11 | Release | Set require_manifest true; regenerate manifest; zip with forward-slash paths; production decision | [assign: GCAE + reviewer] | T+16d | ACCEPT / ACCEPT WITH CONDITIONS / NOT ACCEPTED minuted |

## 8. Measured results (rc3)
| Item | Result |
|---|---|
| Guard suite (tests/guard/suite.py) | 183 assertions, 0 failed: 18 groups incl. the 18 preserved v14.4.0 hook controls, per-instruction budgets and a regression test for every verified defect |
| Authoritative runner (tests/run_all.py) | 17 of 17 declared test files pass (15 gating + 2 reference-model); style declared per file; zero collected tests is a failure |
| Grader suite | 43 assertions, 0 failed (real sessions plus crafted cheat logs) |
| Simulated UAT (tests/guard/uat_simulation.py) | 58 red-team attempts through the REAL launcher, guard, collector and grader: 58 contained, 0 escaped; 28 sessions, all hash chains verify; 7 mechanical stages graded PASS (simulated), 6 behavioural stages not simulable. Includes a 300-call ten-instruction session (nothing refused) and a no-Python machine (message passes, tools blocked) |
| Fuzzing (tests/guard/fuzz_guard.py) | 1,500 adversarial sequences, 105,000 events, 0 violations of 13 invariants (adds: the human's prompt is never blocked while RUNNING) |
| Guard mutation testing | 82 mutants: 81 killed, 1 equivalent (redundant policy check, documented). 9 survivors found during the work were test gaps, all now killed |
| Grader mutation testing | 26 of 26 mutants killed |
| Iron rules, economy, invariants, UAT routing | 8 + 6 + 15 + 5 tests pass; 15 rules each traced to tests, mutants, stop reasons and live-UAT stage |
| False-stop rate on 90 benign tool calls | v14.4.0 hook: 36 of 90 (40%). This guard: 0 of 90 |
| Long-session budget | v14.4.0: STOPPED at tool call 61 across 6 instructions (12 reads each) and refuses every later message. This guard: 300 calls over 10 instructions, nothing refused |
| Hook latency (single-core sandbox) | SessionStart 50 ms; UserPromptSubmit with routing 75 ms; PreToolUse median 38 ms; unchanged with a 10,000-record log. Re-measure on the target OS |
| Live Claude Code evidence | None. All results are unit level or simulated against the documented hook protocol |

## 10. rc3 delta: the "A plugin or hook stopped this message" lockouts
Investigating that error found and fixed: (1) **v14.4.0 as received** stops at Claude's first `Skill` call and, separately, at tool call 61 of an ordinary session (both reproduced); the next message is then refused. (2) **rc2 launcher** exited 2 on the user's own prompt when Python was missing, refusing every message including the restart command. (3) **rc2 budgets** (tools, agents, failures, references) accumulated per session. (4) Guard faults and lock failures blocked the user's message. (5) Blocked-message text named one restart form and gave no status hint. (6) Windows line-ending conversion would have tripped the hash manifest. (7) The evidence collector verified one session repeatedly. (8) The grader judged only the last STOP window for T10 (found by the simulated UAT).
Fixes: budgets bound one human instruction and reset on the next, with a 1,000-call lifetime backstop; a guard fault or missing Python never blocks the human's message (tool calls stay blocked); blocked messages name both restart forms and the status command; manifest checks tolerate CRLF; `verify --session`; grader aggregates all STOP windows. Every fix has a regression test and mutants; the simulated UAT reproduces each lockout scenario.

## 9. What this report does not claim
- No live Claude Code evidence exists; all results are unit level.
- Behavioural controls are not enforced by hooks.
- Evidence-log grades are self-attested by the guard and need independent review.
