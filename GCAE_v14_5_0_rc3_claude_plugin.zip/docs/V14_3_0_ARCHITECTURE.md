# GCAE v14.3.0 — Clean Integration & Assurance Architecture

## Objective
Rebuild the control architecture without reducing the approved GCAE capability payload.

## Authoritative flow
Ingress → Task Envelope → Authority/Invariants → Intent → Capability → Dependency Closure → Workstream → Economy → Execution Controller → Evidence/Provenance → Intervention → Work Product.

## Critical controls
- One authoritative execution threshold source.
- Dependency closure is a hard prerequisite for execution.
- Scope is explicit and runtime-enforced.
- Provider failure classification uses structured fields only.
- Exact, normalized and cyclic loops are independently detected.
- Delegation depth and active agents are runtime-enforced.
- STOP is terminal; restart is exact human command only.
- Independent QA is outside the production controller and does not reuse it as its oracle.

## Capability preservation
The baseline registry contains 100 capabilities, including 45 specialist agents and 42 references. The v14.3.0 preservation matrix marks all baseline capabilities PRESERVE pending golden-use-case and regression evidence.

## Acceptance boundary
v14.3.0 is not production accepted until live Claude UAT, real telemetry, independent QA, four-eyes review and trusted-root verification are complete.
