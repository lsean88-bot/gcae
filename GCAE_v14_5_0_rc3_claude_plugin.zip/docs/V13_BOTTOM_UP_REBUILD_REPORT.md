# GCAE v13.0.0 — Bottom-Up Production Rebuild Report

**Build date:** 5 October 2026  
**Baseline:** GCAE v12.2.0 production hardening  
**Status:** Release Candidate — not production accepted

## 1. Executive conclusion

v13 is a clean-root bottom-up reconstruction of the **control architecture**. It is not a continuation of the v12.2 active router. The v12.2 specialist/content payload is preserved as a protected regression asset; the legacy v12.2 router and scripts are quarantined and cannot act as production authority.

## 2. What changed

- Rebuilt active control plane under `core/`.
- Rebuilt deterministic routing ontology and state machine.
- Separated capability identity from routing semantics and execution.
- Made dependency closure explicit and selective.
- Made workstreams first-class and bounded.
- Moved economy/runtime controls outside specialist self-governance.
- Added explicit disposition register: no heuristic deletion/merge.
- Added architecture-review register for overlap/fan-in candidates.
- Quarantined v12.2 routing implementation for regression/history only.
- Rebuilt package entry contract (`SKILL.md`) around the new architecture.

## 3. Preservation result

Protected payload comparison against v12.2:

- 45 agents: **unchanged**
- 42 references: **unchanged**
- jurisdictions: **unchanged**
- industries: **unchanged**
- evidence assets: **unchanged**

No protected content was deleted or rewritten to achieve the architecture rebuild.

## 4. Difficult UAT

18 complex/adversarial scenarios are defined. The current simulated UAT is **PASS** across routing/economy/controller assertions. Scenarios cover duplicate billing, conflict of interest, tooling price inflation, VAT refund reconstruction, Chairman/fraud urgency, compound audits, communication contamination, nested-agent hangs, recursion, tool storms, evidence tampering, scope drift, unknown cost, unjustified expensive-model escalation, contradictory evidence, stale legal sources and release without four-eyes approval.

## 5. Mutation / boundary testing

Eight targeted mutation/boundary checks pass, including communication contamination, recursive delegation, evidence breach, unknown telemetry, hard budget, agent routing boundary and legacy-router quarantine.

## 6. Issue discovered during v13 UAT and resolved

**Issue:** a communication-only request containing quoted fraud language and an explicit instruction not to investigate could be misclassified as substantive because the classifier saw the word `investigate`.

**Resolution:** explicit negation/communication intent is evaluated before substantive keyword escalation. Regression test added.

This is precisely the type of spillover/false-positive routing problem the bottom-up reconstruction is intended to expose.

## 7. Remaining production gate

The package is **not labelled production accepted** because the build environment has not executed against the live Claude target runtime. Static and simulated UAT cannot establish actual token/caching/cost behaviour. Production promotion still requires live runtime UAT, actual telemetry, assurance-quality comparison, external trusted-root verification, four-eyes review and governance approval.

## 8. Production architecture

`Invariants → Precedence → Ontology → State Machine → Capability Registry → Dependency Closure → Workstream Planning → Economy → Route QA → Runtime → Evidence/Reporting → Release`

This is now the authoritative v13 operating model.
