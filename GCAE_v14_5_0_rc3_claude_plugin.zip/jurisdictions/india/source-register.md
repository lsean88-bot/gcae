# India — Authoritative Source Register (starter)

- MCA — Companies Act, filings and corporate law: https://www.mca.gov.in/
- CBIC — GST/customs/excise: https://www.cbic.gov.in/
- Income Tax Department: https://www.incometax.gov.in/
- RBI — foreign exchange/banking: https://www.rbi.org.in/
- DGFT — foreign trade: https://www.dgft.gov.in/
- EPFO — provident fund: https://www.epfindia.gov.in/
- ESIC — employee state insurance: https://www.esic.gov.in/
- BIS — standards/product certification: https://www.bis.gov.in/
- CPCB — environmental requirements: https://cpcb.nic.in/
- Ministry of Labour & Employment: https://labour.gov.in/
- MoHFW — healthcare policy/regulation: https://www.mohfw.gov.in/
- CDSCO — drugs/medical devices where applicable: https://cdsco.gov.in/
- PNGRB / PESO / relevant authority — energy/pressure equipment depending on activity: https://peso.gov.in/

Applicability depends on state, product, entity, turnover, activity, registration and notified requirements. Verify current primary sources before conclusions.
