# Malaysia — Authoritative Source Register (starter)

- SSM — Companies Act / company law / beneficial ownership: https://www.ssm.com.my/
- LHDN / HASiL — income tax and tax administration: https://www.hasil.gov.my/
- Royal Malaysian Customs — customs / SST: https://www.customs.gov.my/
- EPF/KWSP — employee provident fund: https://www.kwsp.gov.my/
- PERKESO — social security / employment insurance: https://www.perkeso.gov.my/
- DOSH/JKKP — occupational safety and health: https://dosh.gov.my/
- DOE/JAS — environmental requirements: https://www.doe.gov.my/
- Ministry of Health / CKAPS — private healthcare facilities/services: https://www.moh.gov.my/
- BOMBA — fire safety: https://www.bomba.gov.my/
- JPJ — road/vehicle requirements where applicable: https://www.jpj.gov.my/
- MIDA — manufacturing approvals/investment facilitation: https://www.mida.gov.my/
- Department of Standards Malaysia — mandatory standards: https://www.jsm.gov.my/
- Personal Data Protection Commissioner — PDPA: https://www.pdp.gov.my/

Always verify the exact instrument and applicability. The Department of Standards Malaysia reports mandatory standards across sectors including mechanical engineering, metallic materials, healthcare facilities/devices and fire safety; treat the register as a discovery source and verify the applicable standard and legal adoption. 
