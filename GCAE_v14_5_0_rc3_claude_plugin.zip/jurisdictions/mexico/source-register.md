# Mexico — Authoritative Source Register (starter)

- SAT — tax administration / CFDI / VAT / income tax: https://www.sat.gob.mx/
- ANAM — customs: https://www.anam.gob.mx/
- IMSS — social security: https://www.imss.gob.mx/
- INFONAVIT — housing contributions: https://www.infonavit.org.mx/
- STPS — labour / occupational safety: https://www.gob.mx/stps
- COFEPRIS — health regulation: https://www.gob.mx/cofepris
- Secretaría de Economía — trade / corporate / investment matters: https://www.gob.mx/se
- Diario Oficial de la Federación — official publication: https://www.dof.gob.mx/
- SEMARNAT — environmental matters: https://www.gob.mx/semarnat
- PROFEPA — environmental enforcement: https://www.gob.mx/profepa
- CONAMER — regulatory improvement / official regulatory information: https://www.gob.mx/conamer

Use the Diario Oficial and competent authority as primary confirmation for current legal requirements. Verify federal/state/municipal applicability and effective dates.
