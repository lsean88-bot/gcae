# Mexico Jurisdiction Knowledge Library

This directory is a controlled source register and research framework, not a static assertion that every legal requirement is captured.

## Required record fields
- authority
- instrument / requirement
- topic
- entity/activity applicability
- jurisdiction/sub-jurisdiction
- effective date
- transition date
- superseded/repealed status
- official source URL
- last verified date
- control implication
- evidence required
- owner
- review frequency

## Research rule
For any current compliance conclusion, verify the primary authority at the time of use. Record retrieval date and applicability.
