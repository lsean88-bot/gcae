# Case register - owner-maintained template

This file is a TEMPLATE. The live register is kept by its owner (the CAE's office) in the restricted repository as `case-register-<YYYY-MM-DD>.md`, never inside this plugin. Each row is stamped with an as-of date. Parties are recorded by role, not name (Rule 36). Amounts are stated with currency, formula reference and the evidence reference (Rule 34).

## Contents
1. Header block
2. Register columns
3. Maintenance rules

## 1. Header block (complete once per register file)
| Field | Value |
|---|---|
| Register owner (role) | [ ] |
| As-of date | [YYYY-MM-DD] |
| Next review date | [YYYY-MM-DD] |
| Storage location (restricted) | [ ] |
| Entity code convention | MKSDL (alias MKSLD in older documents) |

## 2. Register columns
| Col | Field | Notes |
|---|---|---|
| A | Case reference | One per matter |
| B | Entity code | |
| C | Scheme (ACFE branch) | |
| D | Status on the fraud ladder | weakness / indicator / suspicion / allegation / corroborated / substantiated (pending standard-of-proof decision) |
| E | Roles involved | Roles only |
| F | Date opened / source / initial evidence level | |
| G | Related case references | Merge candidates flagged here |
| H | Exposure | Currency, amount, formula ref, conservative vs alternative reading as separate rows |
| I | Evidence index ref | Pointer to the restricted evidence log |
| J | Closure memo ref | Mandatory before status = closed |
| K | Last action and owner | SMART |
| L | As-of date for the row | |

## 3. Maintenance rules
- Update on every status change, not on a calendar only.
- A row without an as-of date is treated as stale and re-verified before use.
- Cases in draft status beyond the owner-set ageing limit are reported to the AC.
- Do not copy register contents into skills, prompts or shared drives.
