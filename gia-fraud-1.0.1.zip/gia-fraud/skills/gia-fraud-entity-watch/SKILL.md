---
name: gia-fraud-entity-watch
description: "Entity-level fraud-watch discipline: presumptive hotspots, entity red flags from the case register, always-run analytics set, single case reference and closure-memo rules, no AI-initiated notification. Use when scoping fraud risk at an entity or opening, merging or checking a case reference. Do NOT use for the investigation (use gia-fraud:gia-fraud-investigation)."
---

# Fraud Watch (entity level)

Method only. Live case facts, amounts, matters and people are NOT held in this skill. They live in an owner-maintained case register in the restricted repository (template: `references/case-register-template.md`). Rules by number are in `gia-core:iron-rules` (Rules 01, 06, 12, 17, 25, 36).

Entity codes: use `MKSDL` for the Mexico manufacturing entity (older documents show the alias `MKSLD`; treat as the same entity and normalise on input).

## 1. Hard gate

Fraud notification to management, the Board, regulators or law enforcement is never an automated or AI-initiated action. This skill supports analysis; the decision to notify, and the act, belong to the human CAE or Board. Prepare the evidence package and a recommendation only. Never represent a matter as sent or decided.

## 2. Presumptive hotspot

Treat procure-to-pay and tooling or die/mold procurement segregation of duties, and pricing approval, as a presumptive high-risk area at any manufacturing entity before entity evidence is reviewed. Prior group engagements point to the same structural weakness across entities; confirm against the case register and test at the entity. A group-wide P2P and pricing-governance standard, if recommended, must be checked for actual implementation at the entity in question.

## 3. Entity red flags (evidenced, not generic)

Source each entity-specific flag from the case register, with the register row and as-of date. A flag without a register row is a generic red flag and belongs in `gia-fraud:gia-fraud-investigation` references/red-flags-master.md. Patterns to look for in the register:
- Fragmented case handling (several overlapping threads with no final status) is itself a governance red flag.
- Allowances or claims paid outside the documented contract terms.
- Contract-labour records altered after the fact (joining dates, base declarations, attendance gaps).
- Payment-voucher process gaps that enable fraud even without a confirmed conspiracy: test authorisation completeness, not intent.
- Weighbridge and scrap reconciliation gaps at metal-processing entities: inherit the precedent, not a fresh risk.

## 4. Always-run analytics (where the domain applies)

| Domain | Objective ID (registry) | Status |
|---|---|---|
| AP invoices Benford screen | B02 | COVERED (FA-B1) |
| Duplicate payment | V02 | COVERED (FA-A3) |
| Round-number clustering | V04 | NO SCRIPT YET |
| Split or threshold avoidance | V03 | PARTIAL (FA-A1, FA-A2) |
| New vendor paid quickly | V05 | NO SCRIPT YET |
| Weekend or holiday payment | none assigned | NO SCRIPT YET |
| Payroll vs statutory headcount | P01 | COVERED (FA-P1) |
| Vendor-employee identity match | V01, V09 | COVERED (FA-V1; identity key varies by country) |
| Scrap delta by press or SKU | none assigned | NO SCRIPT YET |

IDs and status: `gia-fraud:gia-fraud-analytics` references/test-id-registry.md. Run the full applicable set by default for entities with material disbursement, payroll or scrap exposure, not only on suspicion. No effectiveness claim (such as a pass-rate uplift) is made for this set: none is sourced.

## 5. Case management discipline

1. Intake: log trigger (tip, exception, referral, escalation), date, source and initial evidence level (R1-R5) before anything else.
2. One case reference per matter. If a new matter appears related to an open case, merge into the existing reference; verify that each named matter is genuinely distinct before combining figures.
3. Chain of custody for every item (source, date, custody). Verbal evidence (R5) never supports a finding.
4. Routing: matters implicating senior management go to the Board or AC Chair, decided by a human.
5. Closure: every case needs a closure memo before it is marked resolved. A case left in draft status is reported to the AC as an ageing item.
6. Board-facing conclusions: `gia-report-qa:board-brief`.

## 6. Exposure disclosure

Where several readings of an exposure amount are possible, use the conservative reading and show the alternative as a separate flagged item. Build exposure bottom-up from named evidence with the formula shown. Never present an exposure figure without formula and evidence references (Rule 34).

## 7. ABAC context

Regimes by jurisdiction and the ISO 37001 edition: `gia-fraud:gia-fraud-risk-governance` references/jurisdiction-matrix.md (dated, [UNVERIFIED] until validated). Mexico and Malaysia entities are always assessed for ABAC.

## References

| File | Load when |
|---|---|
| `references/case-register-template.md` | Creating or updating the owner-maintained case register |

## Related

`gia-fraud:gia-fraud-investigation` | `gia-fraud:gia-fraud-analytics` | `gia-fraud:gia-fraud-risk-governance` | `gia-core:iron-rules`.
