---
name: gia-fraud-fsf-window-dressing
description: "Tests for financial-statement fraud and period-end manipulation: window dressing, cut-off, pull-forward, cash parking, payable suppression, off-balance-sheet structures (F01-F07, OB1-OB10). Use when planning period-end, revenue recognition, related-party or off-balance-sheet reviews. Do NOT use for process tests such as duplicate payments (use gia-fraud:gia-fraud-analytics)."
---

# Financial-Statement Fraud and Window Dressing

Rule numbers cited are in `gia-core:iron-rules`. All outputs are indicators until corroborated (Rule 17); describe patterns, never motive (Rule 25). No script exists yet for these tests: say "NOT RUN - no script" in the coverage statement unless run manually, and record who ran what (Rule 14).

## 1. Scheme families (classification via the ACFE tree)

Taxonomy: `gia-fraud:gia-fraud-investigation` references/fraud-tree.md, category 3. Families: revenue manipulation, expense and liability manipulation, asset overstatement, window dressing.

### Window dressing - mechanism and detection

| Scheme | Mechanism | Detection |
|---|---|---|
| Cash parking | Cash moved into the entity at period-end and reversed after the reporting date | Bank reconciliation, post-period balance comparison, subsequent-events review (F01; protocol 1) |
| Payable suppression | Key payables paid down at period-end using facilities, re-drawn after | Compare period-end and early post-period payable balances; facility drawdowns (protocol 2) |
| Revenue pull-forward | Invoices raised before delivery; credit notes after period-end | Cut-off test F02, post-period credit-note search F03 (protocol 3) |
| Inventory inflation | Obsolete stock held at full cost | Physical verification, slow-moving and obsolete analysis, net realisable value, F06 |
| Receivable inflation | Disputed or uncollectable debtors not provided | Ageing, subsequent receipts (F04, F05) |
| Related-party suppression | Balances netted or reclassified to avoid disclosure | Related-party register vs GL mapping (OB3) |

### Off-balance-sheet structures

| Structure | Risk | Detection |
|---|---|---|
| SPV | Hidden contingent liabilities | Directors' loan disclosures; related-party notes; OB1, OB2, OB9 |
| Operating lease disguised as service contract | Lease obligation not recognised | Contract substance review against the applicable lease standard; OB4 |
| Factored receivables with recourse | Recourse liability hidden | Factoring agreement review; contingency notes; OB5 |
| Sale-and-leaseback above market | Deferred loss, inflated asset | Price vs valuation at transaction date; OB10 |
| Vendor financing disguised as revenue | Circular cash, inflated revenue | Match receipts and disbursements to the same party; OB6 |
| Undisclosed directors' loans or payables | Hidden related-party dealing | Loan register vs GL vs board minutes; OB7 |

Where an entity carries a directors' payable with no disclosed terms, apply OB3, OB7 and MO-15 in `gia-fraud:gia-fraud-investigation` references/modus-operandi-library.md.

### Revenue recognition red flags

Revenue growth well above peers; DSO spikes at period-end; large credit notes just after year-end; gross margin rising while revenue falls; receivables never ageing; side letters; bill-and-hold; round-trip transactions. Each is an indicator to test, not a conclusion. Do not quote enforcement statistics from memory; benchmark statistics belong in `gia-fraud:gia-fraud-risk-governance` references/acfe-benchmarks.md only.

## 2. Tests (objective IDs; definitions in `gia-fraud:gia-fraud-analytics` references/test-library.md)

| ID | Test | Status |
|---|---|---|
| F01 | Period-end bank balance spike vs prior months | NO SCRIPT YET |
| F02 | Revenue cut-off vs shipment date | NO SCRIPT YET |
| F03 | Post-period credit-note search | NO SCRIPT YET |
| F04 | Receivable ageing migration | NO SCRIPT YET |
| F05 | Subsequent cash receipt match | NO SCRIPT YET |
| F06 | Inventory turnover trend | NO SCRIPT YET |
| F07 | Gross margin by month | NO SCRIPT YET |
| OB1-OB10 | Off-balance-sheet checklist | Manual, `references/window-dressing-protocols.md` |

Protocols (cash parking, payable suppression, revenue pull-forward) and the OB checklist: `references/window-dressing-protocols.md`. Prompt templates for an analytics agent: `references/analytics-prompts.md`. Candidate scripts to build next are tracked in `gia-fraud:gia-fraud-analytics` references/test-id-registry.md.

## 3. Workflow

1. Plan: state the hypothesis, period-ends in scope, populations, thresholds set in advance (Rule 14).
2. Reconcile extracts to the ledger before testing; unreconciled data is a limitation.
3. Run the protocol; quantify the financial impact of each exception on the impact ladder (observed, potential, quantified, corroborated, confirmed).
4. Challenge: separate reviewer argues genuine business explanations (year-end deals, seasonal patterns, facility repayment schedules).
5. Corroborate through an independent channel (bank confirmation, delivery evidence, post-period receipts) before any escalation.
6. Report indicators and coverage; escalation and notification are human decisions (`gia-fraud:gia-fraud-investigation` section 7).

## 4. Limits

- Calendar-driven business practices (genuine year-end promotions, planned repayments) produce the same patterns; every exception lists the innocent explanation to rule out.
- Accounting-standard judgements (consolidation scope, lease classification) are opinions for the audit team and, where needed, external advisers, not outputs of a test.
- Thresholds in the protocols are defaults, not published criteria.

## Related

`gia-fraud:gia-fraud-analytics` | `gia-fraud:gia-fraud-investigation` | `gia-fraud:gia-fraud-risk-governance` | `gia-core:iron-rules`.
