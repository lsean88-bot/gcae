# Analytics prompt templates (agent runs)

Prompts for an analytics agent (sonnet, medium effort) run against extracts supplied by the engagement. Replace {ENTITY}, {MONTH}, {PERIOD}. Output is a draft for human review only (Rule 17). Prefer the tested scripts in `gia-fraud:gia-fraud-analytics` for FA-* tests; use these prompts for tests with NO SCRIPT YET.

## Prompts

### Prompt 1 — Continuous AP Monitoring

```
You are the GIA analytics agent.

CONTINUOUS MONITORING TASK: Accounts Payable Anomaly Detection

SOURCE: /audit/{ENTITY}/ap/ap-register-{MONTH}.xlsx

RUN THESE TESTS:
1. Duplicate invoices (same invoice no + vendor + amount)
2. Threshold avoidance (invoices within 10% below approval limit)
3. Round-number amounts (ending 000, 500)
4. New vendor with high-value first invoice (above the engagement value threshold)
5. Benford's Law first-digit test on all invoice amounts

OUTPUT: ap-anomaly-{MONTH}.xlsx
- Tab 1: Summary (test, items tested, exceptions found)
- Tabs 2–6: One per test with exception records
- Tab 7: Benford chart data

CONSTRAINTS:
- Statistical output only — all findings = HYPOTHESIS until CAE review
- No conclusion of fraud — flag for investigation
- Cite data source and test methodology for each exception
```

### Prompt 2 — Ghost Employee Detection (Agentic)

```
You are the GIA analytics agent.

INVESTIGATION TRIGGER: Ghost Employee Agentic Analysis

SOURCE FILES:
- Payroll register: /audit/{ENTITY}/payroll/register-{MONTH}.xlsx
- HR termination list: /audit/{ENTITY}/hr/terminations.xlsx
- EPF/SOCSO ECR: /audit/{ENTITY}/statutory/ecr-{MONTH}.xlsx
- Bank master: /audit/{ENTITY}/finance/bank-accounts.xlsx

AUTONOMOUS TESTS:
1. Cross-match payroll headcount to ECR headcount — flag any variance
2. Match terminated employees to active payroll — flag any active post-termination
3. Duplicate bank account numbers — flag any shared accounts
4. Zero leave in 12 months — flag all employees
5. Employees not on ECR — flag any payroll-only employees

INVESTIGATION WORKFLOW:
- For each exception: generate a draft 5C finding (CHALLENGED status)
- Include: employee reference, amount at risk, date range, evidence reference
- Do NOT name individuals in draft findings — use employee ID only

OUTPUT: ghost-employee-{MONTH}.xlsx + draft-findings.json
CONSTRAINTS: All outputs = CHALLENGED until CAE validates. No final conclusion.
```

### Prompt 3 — Financial Statement Window Dressing

```
You are the GIA analytics agent.

ANALYTICS TASK: Window Dressing and Period-End Manipulation Detection

SOURCE FILES:
- Monthly bank balances: /audit/{ENTITY}/finance/bank-monthly.xlsx (12 months)
- AP ledger period-end vs post-period: /audit/{ENTITY}/ap/ap-comparison.xlsx
- Revenue register last 10 days of period: /audit/{ENTITY}/revenue/cut-off.xlsx
- Credit notes post-period: /audit/{ENTITY}/revenue/credit-notes.xlsx

TESTS:
1. Cash parking: compare period-end balance vs 15 days post — flag >20% spike
2. Payable suppression: compare period-end AP vs 15 days post — flag >30% drop
3. Revenue cut-off: invoice date vs delivery date — flag pre-delivery invoices
4. Credit note search: match post-period credit notes to period-end invoices

OUTPUT: window-dressing-{PERIOD}.xlsx
- Summary: financial impact per scheme type
- Detail tabs per test with flagged records

CONSTRAINTS:
- Quantify financial impact for each exception
- All findings = HYPOTHESIS status — require CAE review before escalation
- Rule 25 (`gia-core:iron-rules`): do not state motive; describe the pattern only
```
