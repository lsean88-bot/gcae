# Window-dressing detection protocols and off-balance-sheet checklist

Objective IDs F01-F07 are defined in `gia-fraud:gia-fraud-analytics` references/test-library.md. Everything here is NO SCRIPT YET unless the registry says otherwise; run manually or with spreadsheet analytics and state so in the coverage statement. Thresholds (20%, 30%, 15 days) are default review parameters to be set in the test plan. Results are indicators (ladder level: indicator) until corroborated.

## Contents
1. Window-dressing protocols
2. Off-balance-sheet checklist OB1-OB10

## 1. Window-dressing protocols

### Cash Parking Detection Protocol

```
Step 1: Extract bank balance on last 3 business days of each reporting period
Step 2: Extract bank balance on first 3 business days of following period  
Step 3: Compute difference: if Period-End Balance >> Post-Period Balance by >20% → FLAG
Step 4: Cross-reference to bank statement for large same-day in/out transactions
Step 5: Verify against related-party loan schedule (park from director / group company)
Step 6: If corroborated by independent evidence - report as a pattern consistent with window dressing (never as intent)
```

### Payable Suppression Detection Protocol

```
Step 1: Extract AP balances as at period-end
Step 2: Extract AP balances as at 15 days after period-end
Step 3: Flag any decrease >30% in any vendor balance between period-end and 15 days post
Step 4: Cross-reference to payment run: were payments made on period-end date?
Step 5: Cross-reference to subsequent drawdown: were facilities drawn post-period?
Step 6: If corroborated by independent evidence - report as a pattern consistent with liability suppression
```

### Revenue Pull-Forward Detection Protocol

```
Step 1: Extract all invoices in last 10 business days of the period
Step 2: Cross-match to delivery notes and GRNs for the same invoices
Step 3: Flag invoices where invoice date is BEFORE delivery/GRN date
Step 4: Search for credit notes in the 30 days following period-end for the same invoices
Step 5: If credit note exists for a pull-forward invoice -> record as a reversal of the pull-forward invoice (fact), not as intent
Step 6: Compute financial impact: sum all reversed pull-forward invoices
```


## 2. Off-balance-sheet checklist OB1-OB10

| # | Test | Evidence to Request |
|---|------|-------------------|
| OB1 | Map all entities in group structure to consolidation scope | Group structure chart + consolidation workings |
| OB2 | Request disclosure of all entities controlled / significantly influenced (MFRS 127/128) | Directors' statutory disclosure |
| OB3 | Check all related-party balances in notes against GL | Related-party register vs balance sheet notes |
| OB4 | Review all service contracts > 12 months for MFRS 16 / IFRS 16 right-of-use asset | Contract register |
| OB5 | Test all factoring/securitisation arrangements for recourse provisions | Factoring agreements |
| OB6 | Review all vendor financing arrangements for circular cash indicators | Vendor finance terms vs customer terms |
| OB7 | Reconcile directors' loan register to balance sheet | Loan register vs GL vs board minutes |
| OB8 | Check contingent liabilities disclosed vs actual claims register | Legal register vs disclosure |
| OB9 | Verify SPV / subsidiary board composition for control indicators | Corporate registry filings |
| OB10 | Test sale-and-leaseback transactions vs market value at transaction date | Valuation vs transaction price |


