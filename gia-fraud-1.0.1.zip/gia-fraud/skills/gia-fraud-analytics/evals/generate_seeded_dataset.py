#!/usr/bin/env python3
"""Generate a synthetic, seeded dataset with PLANTED schemes and DECOYS plus ground truth.

LIMITATION (read before trusting any score): the planted schemes were authored by the same
party that wrote the detection scripts. A good score proves the scripts do what their author
intended; it does NOT prove they find schemes an adversary would design. Replace/augment with a
dataset authored by someone else (or sanitised historical cases) before relying on results.
"""
import argparse, csv, datetime as dt, json, math, random
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument("--outdir", required=True)
ap.add_argument("--seed", type=int, default=42)
a = ap.parse_args()
R = random.Random(a.seed)
out = Path(a.outdir); out.mkdir(parents=True, exist_ok=True)

def w(name, rows, fields):
    with open(out / name, "w", newline="") as f:
        d = csv.DictWriter(f, fieldnames=fields); d.writeheader(); d.writerows(rows)

FIRST = ["Aiman", "Siti", "Raj", "Mei", "Carlos", "Priya", "Daniel", "Aisha", "Wei", "Lakshmi", "Jose", "Farah"]
LAST = ["Tan", "Lim", "Kumar", "Hassan", "Garcia", "Nair", "Wong", "Ismail", "Lopez", "Raman", "Chen", "Abdullah"]
STREET = ["Jalan Perdana", "Lorong Maju", "Jalan Industri", "Persiaran Utama", "Calle Norte", "Avenida Sur", "Taman Bukit", "Jalan Mawar"]

def addr(i): return f"{R.randint(1, 99)} {STREET[i % len(STREET)]} {i} Selangor {40000 + i}"
def phone(i): return f"+6012{3000000 + i * 7:07d}"
def bank(prefix, i): return f"{prefix}{10000000 + i * 13:010d}"

# ---------------- masters
emps = []
for i in range(1, 301):
    emps.append({"emp_id": f"E{i:04d}", "name": f"{R.choice(FIRST)} {R.choice(LAST)} {i}", "address": addr(1000 + i),
                 "phone": phone(1000 + i), "bank_account": bank("MB", i), "status": "ACTIVE", "termination_date": ""})
term = {}
PROTECTED = {int(x[1:]) - 1 for x in ("E0001", "E0050", "E0060", "E0070", "E0080", "E0105", "E0120", "E0290", "E0291")}
for i in R.sample([k for k in range(1, 300) if k not in PROTECTED], 20):
    m = R.randint(2, 10)
    td = dt.date(2025, m, R.randint(5, 25))
    emps[i]["status"], emps[i]["termination_date"] = "TERMINATED", td.isoformat()
    term[emps[i]["emp_id"]] = td

vendors = []
for i in range(1, 201):
    vendors.append({"vendor_id": f"V{i:04d}", "name": f"Vendor {i} Sdn Bhd", "address": addr(5000 + i),
                    "phone": phone(5000 + i), "bank_account": bank("CI", i), "tax_id": f"TX{i:06d}"})

# ---------------- planted master schemes
def vend(vid):
    return next(v for v in vendors if v["vendor_id"] == vid)
def emp(eid):
    return next(e for e in emps if e["emp_id"] == eid)
vendors.append({"vendor_id": "V0201", "name": "Apex Maintenance Supplies", "address": "88 Jalan Baru 1 Selangor 40100",
                "phone": "+60125550001", "bank_account": emp("E0050")["bank_account"], "tax_id": "TX900201"})  # S1 bank
vendors.append({"vendor_id": "V0202", "name": "Bright Logistics", "address": emp("E0060")["address"],
                "phone": "+60125550002", "bank_account": "CI9990000002", "tax_id": "TX900202"})  # S2a address
vendors.append({"vendor_id": "V0203", "name": "Core Safety Trading", "address": "12 Jalan Lain 2 Selangor 40200",
                "phone": emp("E0070")["phone"], "bank_account": "CI9990000003", "tax_id": "TX900203"})  # S2b phone
vendors.append({"vendor_id": "V0204", "name": "Delta Tooling", "address": "Level 5 Menara A Unit 5-01 Kuala Lumpur",
                "phone": "+60125550004", "bank_account": "CI9990000004", "tax_id": "TX900204"})
emp("E0080")["address"] = "Level 5 Menara A Unit 5-02 Kuala Lumpur"  # D6 building-level decoy
vendors.append({"vendor_id": "V0205", "name": "Echo Packaging A", "address": "5 Jalan X 7 Selangor 40300",
                "phone": "+60125550005", "bank_account": "CI9990000005", "tax_id": "TX900205"})
vendors.append({"vendor_id": "V0206", "name": "Echo Packaging B", "address": "6 Jalan X 8 Selangor 40300",
                "phone": "+60125550006", "bank_account": "CI9990000005", "tax_id": "TX900206"})  # S9 shared bank
for v in ("V0207", "V0208", "V0209", "V0210", "V0211"):
    n = int(v[1:])
    vendors.append({"vendor_id": v, "name": f"Vendor {n} Sdn Bhd", "address": addr(7000 + n), "phone": phone(7000 + n),
                    "bank_account": bank("CI", n), "tax_id": f"TX9{n:05d}"})
w("vendors.csv", vendors, ["vendor_id", "name", "address", "phone", "bank_account", "tax_id"])
w("employees.csv", emps, ["emp_id", "name", "address", "phone", "bank_account", "status", "termination_date"])

# ---------------- payments
APPR = ["AP-A", "AP-B", "AP-C", "AP-D", "AP-E", "AP-F"]
pays, seq = [], 0
def addp(vid, amt, d, inv=None, po=None, appr=None):
    global seq
    seq += 1
    pays.append({"pay_id": f"P{seq:06d}", "vendor_id": vid, "invoice_no": inv or f"INV-{vid[1:]}-{seq:06d}",
                 "amount": f"{amt:.2f}", "pay_date": d.isoformat(), "po_no": po or f"PO{seq:06d}",
                 "approver": appr or R.choice(APPR)})
    return pays[-1]["pay_id"]
D0 = dt.date(2025, 1, 1)
base_vendors = [v["vendor_id"] for v in vendors if v["vendor_id"] not in ("V0201", "V0001", "V0207", "V0208", "V0209", "V0210", "V0211")]
for _ in range(6000):
    amt = math.exp(R.gauss(8.5, 1.4))
    while amt >= 44000:  # clean population kept clear of the 45k-50k band by resampling (no mass point)
        amt = math.exp(R.gauss(8.5, 1.4))
    addp(R.choice(base_vendors), amt, D0 + dt.timedelta(days=R.randint(0, 364)))
truth = {"planted": [], "decoys": [], "benford_cases": []}
# S1 shell vendor paid
for k in range(3):
    addp("V0201", R.uniform(9000, 30000), D0 + dt.timedelta(days=40 + k * 30))
truth["planted"].append({"id": "S1", "desc": "vendor bank account equals employee bank account", "test_id": "FA-V1",
                         "reason_code": "VE-BANK", "match": {"vendor_id": "V0201", "emp_id": "E0050"}})
truth["planted"].append({"id": "S2a", "desc": "vendor address equals employee address", "test_id": "FA-V1",
                         "reason_code": "VE-ADDR", "match": {"vendor_id": "V0202", "emp_id": "E0060"}})
truth["planted"].append({"id": "S2b", "desc": "vendor phone equals employee phone", "test_id": "FA-V1",
                         "reason_code": "VE-PHONE", "match": {"vendor_id": "V0203", "emp_id": "E0070"}})
truth["planted"].append({"id": "S9", "desc": "two vendors share one bank account", "test_id": "FA-V1",
                         "reason_code": "VM-BANK-SHARED", "match": {"vendor_ids": ["V0205", "V0206"]}})
truth["decoys"].append({"id": "D6", "desc": "vendor and employee in same building, different units", "kind": "no_flag_expected",
                        "test_id": "FA-V1", "match": {"vendor_id": "V0204", "emp_id": "E0080"}})
# S3 just-below threshold cluster (same approver)
ids = [addp("V0207", amt, D0 + dt.timedelta(days=100 + i), appr="AP-A")
       for i, amt in enumerate([47500, 48200, 49100, 49900])]
truth["planted"].append({"id": "S3", "desc": "four payments just under 50,000 within 4 days", "test_id": "FA-A1",
                         "reason_code": "JUST-BELOW-CLUSTER", "match": {"pay_ids": ids}})
# D1 legit spaced payments near threshold (weeks apart)
ids = [addp("V0208", amt, D0 + dt.timedelta(days=60 + i * 21)) for i, amt in enumerate([47000, 48800, 49500])]
truth["decoys"].append({"id": "D1", "desc": "near-threshold payments three weeks apart", "kind": "no_flag_expected",
                        "test_id": "FA-A1", "match": {"pay_ids": ids}})
# S4 exact duplicate
addp("V0001", 7200.00, D0 + dt.timedelta(days=30))
orig = next(p for p in pays if p["vendor_id"] == "V0001")
dup = addp("V0001", float(orig["amount"]), dt.date.fromisoformat(orig["pay_date"]) + dt.timedelta(days=20), inv=orig["invoice_no"])
truth["planted"].append({"id": "S4", "desc": "same invoice paid twice", "test_id": "FA-A3", "reason_code": "DUP-EXACT",
                         "match": {"pay_ids": [orig["pay_id"], dup]}})
# S5 near duplicate: single-digit typo, and transposition (same PO)
for vid, i1, i2, sid in (("V0002", "INV-2025-004510", "INV-2025-004511", "S5a"), ("V0003", "INV-2025-004510", "INV-2025-004150", "S5b")):
    amt = round(R.uniform(3000, 20000), 2)
    d = D0 + dt.timedelta(days=150)
    p1 = addp(vid, amt, d, inv=i1, po="PO-NEAR-" + sid)
    p2 = addp(vid, amt, d + dt.timedelta(days=3), inv=i2, po="PO-NEAR-" + sid)
    truth["planted"].append({"id": sid, "desc": "near-duplicate invoice numbers, same amount, same PO", "test_id": "FA-A3",
                             "reason_code": "DUP-NEAR", "match": {"pay_ids": [p1, p2]}})
# D2 same amount, different PO and invoice
p1 = addp("V0209", 8800.00, D0 + dt.timedelta(days=200), inv="INV-A-100", po="PO-X1")
p2 = addp("V0209", 8800.00, D0 + dt.timedelta(days=203), inv="INV-A-101", po="PO-X2")
truth["decoys"].append({"id": "D2", "desc": "same amount, different PO/invoice, 3 days apart", "kind": "no_flag_expected",
                        "test_id": "FA-A3", "match": {"pay_ids": [p1, p2]}})
w("payments.csv", pays, ["pay_id", "vendor_id", "invoice_no", "amount", "pay_date", "po_no", "approver"])

# ---------------- payroll
periods = [f"2025-{m:02d}" for m in range(1, 13)]
def eom(p):
    y, m = map(int, p.split("-")); n = dt.date(y + (m == 12), m % 12 + 1, 1) - dt.timedelta(days=1); return n
payroll, att, hc = [], [], []
emp("E0001")["status"], emp("E0001")["termination_date"] = "TERMINATED", "2025-06-15"
term["E0001"] = dt.date(2025, 6, 15)
ghostC = "E0105"
emp(ghostC)["status"], emp(ghostC)["termination_date"] = "TERMINATED", "2025-04-30"
term[ghostC] = dt.date(2025, 4, 30)
dupA = ("E0290", "E0291")
for p in periods:
    end = eom(p); real = set()
    for e in emps:
        eid = e["emp_id"]; td = term.get(eid)
        if td and end > td.replace(day=28) + dt.timedelta(days=4) and eid != ghostC:  # stop after termination month
            continue
        if eid == ghostC and p < "2025-04":
            pass
        bank_acc = e["bank_account"]
        if eid == dupA[0]:
            bank_acc = emp(dupA[1])["bank_account"]  # S6a ghost paid into another employee's account
        payroll.append({"period": p, "emp_id": eid, "gross": f"{R.uniform(2500, 9000):.2f}", "bank_account": bank_acc,
                        "paid_date": end.isoformat()})
        real.add(eid)
        zero = (eid == "E0120" and p == "2025-06")
        att.append({"period": p, "emp_id": eid, "days_present": 0 if zero else R.randint(17, 23)})
    if p >= "2025-03":  # S6b payee not in master
        payroll.append({"period": p, "emp_id": "E9999", "gross": "4200.00", "bank_account": "XX0000999900", "paid_date": end.isoformat()})
    hc.append({"period": p, "statutory_headcount": len(real)})
w("payroll.csv", payroll, ["period", "emp_id", "gross", "bank_account", "paid_date"])
w("attendance.csv", att, ["period", "emp_id", "days_present"])
w("headcount.csv", hc, ["period", "statutory_headcount"])
w("employees.csv", emps, ["emp_id", "name", "address", "phone", "bank_account", "status", "termination_date"])
truth["planted"] += [
    {"id": "S6a", "desc": "payroll for one employee paid into another employee's account", "test_id": "FA-P1",
     "reason_code": "GH-DUP-BANK", "match": {"emp_ids": ["E0290", "E0291"]}},
    {"id": "S6b", "desc": "payee not in HR master", "test_id": "FA-P1", "reason_code": "GH-NOT-IN-MASTER", "match": {"emp_id": "E9999"}},
    {"id": "S6c", "desc": "terminated employee still paid months later", "test_id": "FA-P1", "reason_code": "GH-PAID-AFTER-TERM",
     "match": {"emp_id": ghostC}},
    {"id": "S6d", "desc": "paid with zero days present", "test_id": "FA-P1", "reason_code": "GH-NO-ATTENDANCE",
     "match": {"emp_id": "E0120", "period": "2025-06"}},
    {"id": "S6e", "desc": "payroll headcount exceeds statutory submission", "test_id": "FA-P1", "reason_code": "GH-HEADCOUNT-GAP",
     "match": {"periods": [f"2025-{m:02d}" for m in range(3, 13)]}, "match_any": True},
]
truth["decoys"].append({"id": "D4", "desc": "final pay in termination month (within grace)", "kind": "no_flag_expected",
                        "test_id": "FA-P1", "reason_code": "GH-PAID-AFTER-TERM", "match": {"emp_id": "E0001"}})

# ---------------- journals
je, n = [], 0
def addj(d, t, amt, user, appr, desc="Accrual"):
    global n
    n += 1
    je.append({"je_id": f"JE{n:06d}", "posting_date": d.isoformat(), "posting_time": t, "amount": f"{amt:.2f}",
               "user": user, "approver": appr, "description": desc})
    return je[-1]["je_id"]
USERS = ["FIN01", "FIN02", "FIN03", "FIN04"]
while n < 3000:
    d = D0 + dt.timedelta(days=R.randint(0, 364))
    if d.weekday() >= 5 or d.day >= 29 or d.day == 1 and False: continue
    if (dt.date(d.year + (d.month == 12), d.month % 12 + 1, 1) - d).days <= 2: continue
    u = R.choice(USERS)
    addj(d, f"{R.randint(9, 17):02d}:{R.randint(0, 59):02d}", math.exp(R.gauss(9, 1.2)) + 0.37, u, R.choice([x for x in USERS if x != u]))
sj = []
for k in range(5):
    sj.append(addj(dt.date(2025, 3 + k, 1) + dt.timedelta(days=(5 - dt.date(2025, 3 + k, 1).weekday()) % 7 + 7 * 0),
                   "23:10", 250000.00, "FIN02", "FIN02"))
truth["planted"].append({"id": "S7a", "desc": "round-sum weekend after-hours self-approved journals", "test_id": "FA-J1",
                         "reason_code": "JE-MULTI", "match": {"je_ids": sj}, "match_any": True})
pe = [addj(dt.date(2025, m, 28 if m == 2 else 30), "10:15", 71234.56, "FIN03", "") for m in (4, 6, 9)]
truth["planted"].append({"id": "S7b", "desc": "large period-end journals with no approver", "test_id": "FA-J1",
                         "reason_code": "JE-MULTI", "match": {"je_ids": pe}, "match_any": True})
rent = [addj(dt.date(2025, m, 5), "10:00", 10000.00, "FIN01", "FIN04", "Monthly rent") for m in range(1, 13)]
truth["decoys"].append({"id": "D5", "desc": "monthly rent journals are round sums", "kind": "flag_expected", "test_id": "FA-J1",
                        "match": {"je_ids": rent}, "match_any": True})
dep = [addj(dt.date(2025, m, 1) + dt.timedelta(days=(5 - dt.date(2025, m, 1).weekday()) % 7), "02:00", 120000.00, "SYSTEM", "")
       for m in range(1, 13)]
truth["decoys"].append({"id": "D3", "desc": "SYSTEM weekend depreciation journals", "kind": "no_flag_expected", "test_id": "FA-J1",
                        "match": {"je_ids": dep}, "match_any": True})
w("journal.csv", je, ["je_id", "posting_date", "posting_time", "amount", "user", "approver", "description"])

# ---------------- benford sets
def bset(name, rows):
    w(name, rows, ["id", "vendor_id", "amount"])
big = lambda: math.exp(R.gauss(8.0, 2.2))
bset("benford_clean.csv", [{"id": i, "vendor_id": f"V{R.randint(1, 150):04d}", "amount": f"{big():.2f}"} for i in range(5000)])
rows = [{"id": i, "vendor_id": f"V{R.randint(1, 150):04d}", "amount": f"{big():.2f}"} for i in range(4500)]
rows += [{"id": 9000 + i, "vendor_id": "V0193", "amount": f"{R.uniform(5000, 9999):.2f}"} for i in range(500)]
bset("benford_tampered.csv", rows)
bset("benford_small.csv", [{"id": i, "vendor_id": "V0001", "amount": f"{big():.2f}"} for i in range(400)])
bset("benford_perdiem.csv", [{"id": i, "vendor_id": "V0002",
                              "amount": f"{R.choice([150.0, 200.0]) if R.random() < 0.85 else big():.2f}"} for i in range(3000)])
truth["benford_cases"] = [
    {"file": "benford_clean.csv", "expect_status": "RUN", "expect_nonconformity": False},
    {"file": "benford_tampered.csv", "expect_status": "RUN", "expect_nonconformity": True, "expect_lead_group": "V0193"},
    {"file": "benford_small.csv", "expect_status": "NOT_APPLICABLE"},
    {"file": "benford_perdiem.csv", "expect_status": "NOT_APPLICABLE"},
]
json.dump(truth, open(out / "ground_truth.json", "w"), indent=2)
print(f"generated: {len(vendors)} vendors, {len(emps)} employees, {len(pays)} payments, {len(payroll)} payroll rows, "
      f"{len(je)} journals; planted={len(truth['planted'])} decoys={len(truth['decoys'])}")
