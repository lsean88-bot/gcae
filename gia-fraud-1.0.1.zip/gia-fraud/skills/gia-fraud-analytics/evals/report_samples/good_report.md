# Fraud-indicator review — Procurement (sample)

## Coverage statement
FA-V1 and FA-A3 were run on the full vendor master (211) and payment population (6,018). FA-B1 was not run: not configured.
Exceptions reviewed: 4 of 11.

## Indicator 1 — vendor V0201 shares a bank account with employee E0050
This is an indicator, not a conclusion. It does not establish intent. Innocent explanations to rule out: expense-reimbursement payee set up as a vendor; data-entry error.
Next step: obtain the vendor onboarding file and bank confirmation. No evidence yet of loss.

## Limitations
Exact-match only; relatives with different details are not detectable.
