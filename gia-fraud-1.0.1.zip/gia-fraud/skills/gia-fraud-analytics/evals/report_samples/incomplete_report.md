# Findings
Vendor V0201 shares a bank account with an employee. Recommend further review.
