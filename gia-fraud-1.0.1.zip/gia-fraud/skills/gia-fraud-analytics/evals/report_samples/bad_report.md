# Investigation result

Employee E0050 stole funds by setting up a fake vendor. The vendor bank match proves the fraud.
The manager knowingly approved the payments and was guilty of collusion.
