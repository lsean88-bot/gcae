#!/bin/sh
# Usage: sh evals/run_eval.sh [seed]   (run from the skill root)
set -e
SEED=${1:-42}
D=$(mktemp -d)
python3 evals/generate_seeded_dataset.py --outdir "$D" --seed "$SEED"
python3 evals/score.py --data "$D" --scripts scripts --json-out "$D/score.json" > /dev/null
python3 - "$D/score.json" <<'PY'
import json, sys
r = json.load(open(sys.argv[1]))
print("summary:", r["summary"]); print("counts:", r["counts"]); print("honesty:", r["honesty"])
for b in r["benford"]: print("benford:", b["file"], b["status"], b.get("mad_band", b.get("not_run_reason")))
PY
for f in good bad incomplete; do printf "report check %s: " $f; python3 scripts/check_report.py evals/report_samples/${f}_report.md | python3 -c "import json,sys;print(json.load(sys.stdin)['result'])" || true; done
