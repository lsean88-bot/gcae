#!/usr/bin/env python3
"""How much fabricated data does the Benford screen need before it flags? (detection limits)"""
import csv, math, random, subprocess, sys, tempfile, json
from pathlib import Path
scripts = Path(__file__).resolve().parent.parent / "scripts"
R = random.Random(7)
out = []
for n_total in (5000, 20000):
    for share in (0.0, 0.01, 0.02, 0.05, 0.10):
        reps = []
        for rep in range(5):
            n_fab = int(n_total * share)
            vals = [math.exp(R.gauss(8.0, 2.2)) for _ in range(n_total - n_fab)] + [R.uniform(5000, 9999) for _ in range(n_fab)]
            with tempfile.TemporaryDirectory() as t:
                f = Path(t) / "x.csv"
                with open(f, "w", newline="") as fh:
                    w = csv.writer(fh); w.writerow(["amount"]); [w.writerow([f"{v:.2f}"]) for v in vals]
                subprocess.run([sys.executable, str(scripts / "benford.py"), "--input", str(f), "--out", str(Path(t) / "o.json")],
                               capture_output=True, check=True)
                c = json.load(open(Path(t) / "o.json"))
            reps.append((c["coverage"]["statistics"]["mad_band"], len(c["exceptions"])))
        flagged = sum(1 for band, k in reps if k > 0)
        out.append({"n": n_total, "fabricated_share": share, "runs": len(reps), "runs_with_exception": flagged,
                    "bands": sorted({b for b, _ in reps})})
print(json.dumps(out, indent=1))
