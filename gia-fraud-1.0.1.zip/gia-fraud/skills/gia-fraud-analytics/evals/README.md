# Seeded-fraud evaluation

Run: `sh evals/run_eval.sh [seed]` from the skill root. Standard library only.

## What it does
`generate_seeded_dataset.py` builds a synthetic population (211 vendors, 300 employees, ~6,000
payments, ~3,500 payroll rows, ~3,000 journals) with 15 planted schemes, 6 decoys, and 4 Benford
populations, plus `ground_truth.json`. `score.py` runs the scripts and reports recall per scheme,
decoy behaviour, unexplained exceptions on clean data, Benford refusal/detection, coverage-honesty
and determinism checks. `benford_sensitivity.py` measures how much fabricated data Benford needs.
`report_samples/` holds a good, a bad and an incomplete report for `check_report.py`.

## Results (seed 42, 2026-10-29)
| Measure | Result |
|---|---|
| Planted schemes detected | 15 / 15 |
| "No-flag" decoys wrongly flagged | 0 / 5 |
| "Flag-expected" decoy (monthly rent, round sums) | flagged 12 times (review burden, expected) |
| Unexplained exceptions on clean data | 7 (seed 42) and 5 (seed 7), all FA-A2 SPLIT-AGGREGATE (the test is noisy) |
| Collateral exceptions on planted entities | 22 (additional indicators on the same entities; not errors) |
| Benford: clean / tampered (10% fabricated) / small / per-diem | conformity / nonconformity with lead vendor found / refused / refused |
| Coverage block on every test; unconfigured tests listed as NOT RUN | yes |
| Identical output on two runs | yes |
| Report checker | good PASS, bad FAIL (2 assertion lines), incomplete FAIL |

Benford detection limit (5 runs per cell, uniform-fabricated values 5,000–9,999 mixed into a wide lognormal population):
flagged in all runs at 10% fabricated; none at 5% or below, at both 5,000 and 20,000 records.

## Changes made because of the evaluation (disclosed)
1. Benford raised per-digit exceptions on clean data (digit 6 at z>1.96 while MAD showed close
   conformity). Digit exceptions are now raised only when MAD is marginal or worse.
2. Near-duplicate similarity default was set to 0.80 (from 0.85) after working out by hand that a
   digit transposition scores about 0.85. That default was chosen with the planted case in view.

## Limitations — read before quoting any number
- **Circular:** the same author wrote the schemes and the detectors. Results show the scripts do
  what was intended, not that they find what an adversary would design.
- One seed, one synthetic population, simple clean-data behaviour. No real-world noise (messy
  addresses, multi-currency, reversals, late postings).
- Decoys are few and obvious. False-positive rates on real ledgers will differ, probably upward.
- Collusion, executive override, bid rigging, scrap diversion, inventory and revenue schemes are
  not tested (no scripts).
- The HubSpot workflow is not exercised here (design only).

## Next evaluation steps
Author a second dataset independently; run on sanitised historical cases; add messy-data variants;
track precision on cleared exceptions over time via `triage.py` history.
