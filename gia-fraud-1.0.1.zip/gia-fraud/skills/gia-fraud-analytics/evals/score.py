#!/usr/bin/env python3
"""Score gia-fraud-analytics output against ground_truth.json.

Reports:
  * recall per planted scheme
  * decoys: 'no_flag_expected' decoys that were flagged (false positives); 'flag_expected' decoys
    flagged (review burden, informational)
  * unexplained exceptions: touch no planted entity and no decoy (false positives on clean data)
  * collateral exceptions: touch a planted entity but are a different indicator (not errors)
  * Benford cases: refusal behaviour and detection
  * honesty checks: every test has a coverage block; unconfigured tests are listed as NOT RUN
  * determinism: two runs give identical exceptions
"""
import argparse, json, subprocess, sys, tempfile
from collections import Counter
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument("--data", required=True)
ap.add_argument("--scripts", required=True)
ap.add_argument("--json-out")
a = ap.parse_args()
data, scripts = Path(a.data), Path(a.scripts)
truth = json.load(open(data / "ground_truth.json"))

def run_all(outdir):
    cfg = {"tests": {
        "FA-V1": {"script": "vendor_employee_match.py", "args": {"--vendors": data / "vendors.csv", "--employees": data / "employees.csv"}},
        "FA-A1": {"script": "threshold_split.py", "args": {"--payments": data / "payments.csv", "--threshold": 50000}},
        "FA-A3": {"script": "duplicate_payments.py", "args": {"--payments": data / "payments.csv"}},
        "FA-J1": {"script": "je_testing.py", "args": {"--journal": data / "journal.csv", "--system-users": "SYSTEM"}},
        "FA-P1": {"script": "payroll_ghost.py", "args": {"--employees": data / "employees.csv", "--payroll": data / "payroll.csv",
                  "--attendance": data / "attendance.csv", "--headcount": data / "headcount.csv"}}}}
    cp = Path(outdir) / "cfg.json"
    json.dump(cfg, open(cp, "w"), default=str)
    r = subprocess.run([sys.executable, str(scripts / "run_all.py"), "--config", str(cp), "--outdir", str(Path(outdir) / "out")],
                       capture_output=True, text=True)
    if r.returncode: sys.exit("run_all failed: " + r.stdout + r.stderr)
    return json.load(open(Path(outdir) / "out" / "findings.json"))

def flat(v):
    if isinstance(v, dict):
        for x in v.values(): yield from flat(x)
    elif isinstance(v, list):
        for x in v: yield from flat(x)
    else:
        yield str(v)

def matches(exc, item):
    if exc["test_id"] != item["test_id"] and not (item["test_id"] == "FA-A1" and exc["test_id"] in ("FA-A1", "FA-A2")):
        return False
    if item.get("reason_code") and item["reason_code"] != "JE-MULTI" and exc["reason_code"] != item["reason_code"]:
        return False
    ids = set(flat(exc["record_ids"]))
    want = list(flat(item["match"]))
    return any(w in ids for w in want) if item.get("match_any") else all(w in ids for w in want)

with tempfile.TemporaryDirectory() as t1, tempfile.TemporaryDirectory() as t2:
    f1, f2 = run_all(t1), run_all(t2)
strip = lambda f: json.dumps(sorted(json.dumps(e, sort_keys=True) for e in f["exceptions"]))
deterministic = strip(f1) == strip(f2)
exceptions = f1["exceptions"]

entities = set()
for p in truth["planted"]:
    entities |= set(flat(p["match"]))
decoy_entities = set()
for d in truth["decoys"]:
    decoy_entities |= set(flat(d["match"]))

res = {"planted": [], "decoys": [], "counts": {}}
for p in truth["planted"]:
    hit = [e for e in exceptions if matches(e, p)]
    items = list(flat(p["match"])) if p.get("match_any") else None
    found_items = sum(1 for w in items if any(w in set(flat(e["record_ids"])) for e in hit)) if items else None
    res["planted"].append({"id": p["id"], "desc": p["desc"], "detected": bool(hit),
                           "items_found": found_items, "items_total": len(items) if items else None,
                           "severity": sorted({e["severity_indicator"] for e in hit})})
for d in truth["decoys"]:
    flagged = [e for e in exceptions if e["test_id"] == d["test_id"] and d["kind"] and
               matches(e, {**d, "reason_code": d.get("reason_code")})]
    ok = (len(flagged) == 0) if d["kind"] == "no_flag_expected" else (len(flagged) > 0)
    res["decoys"].append({"id": d["id"], "desc": d["desc"], "kind": d["kind"], "flagged": len(flagged), "as_expected": ok})

explained, collateral, unexplained = [], [], []
for e in exceptions:
    ids = set(flat(e["record_ids"]))
    if any(matches(e, p) for p in truth["planted"]): explained.append(e)
    elif ids & entities: collateral.append(e)
    elif ids & decoy_entities: explained.append(e)
    else: unexplained.append(e)
res["counts"] = {"total_exceptions": len(exceptions), "explained_by_planted_or_decoy": len(explained),
                 "collateral_on_planted_entities": len(collateral),
                 "unexplained_on_clean_data": len(unexplained),
                 "unexplained_by_reason": dict(Counter(e["reason_code"] for e in unexplained))}

# Benford cases
res["benford"] = []
for c in truth["benford_cases"]:
    with tempfile.TemporaryDirectory() as t:
        o = Path(t) / "b.json"
        subprocess.run([sys.executable, str(scripts / "benford.py"), "--input", str(data / c["file"]),
                        "--group-column", "vendor_id", "--out", str(o)], capture_output=True, text=True, check=True)
        r = json.load(open(o))
    cov = r["coverage"]
    entry = {"file": c["file"], "status": cov["status"], "status_as_expected": cov["status"] == c["expect_status"]}
    if cov["status"] == "RUN":
        stats = cov["statistics"]
        entry.update({"mad": stats["mad"], "mad_band": stats["mad_band"], "chi_square_p": stats["chi_square_p"],
                      "digits_flagged": [e["record_ids"]["digit"] for e in r["exceptions"]]})
        nonconf = stats["mad_band"] == "nonconformity"
        entry["nonconformity_as_expected"] = nonconf == c["expect_nonconformity"]
        if c.get("expect_lead_group"):
            leads = [l["group"] for e in r["exceptions"] for l in e["extra"]["concentration_leads"][:1]]
            entry["lead_group_found"] = c["expect_lead_group"] in leads
    else:
        entry["not_run_reason"] = cov["not_run_reason"]
    res["benford"].append(entry)

# honesty checks
REQ = ("test_id", "script_version", "run_utc", "status", "input_files", "population_tested", "fields_used", "parameters", "limitations",
       "exceptions_found", "exceptions_reviewed")
def cov_complete(c):
    return all(k in c for k in REQ) and c["population_tested"] > 0 and all(f.get("sha256") for f in c["input_files"]) \
        and len(c["limitations"]) > 0 and c["exceptions_found"] == sum(1 for e in f1["exceptions"] if e["test_id"] in ([c["test_id"]] + c.get("covers_tests", [])))
cov_ok = all(cov_complete(c) for c in f1["coverage"])
res["honesty"] = {"every_test_has_coverage_block": cov_ok,
                  "unconfigured_tests_listed_not_run": "FA-B1" in f1["tests_not_run"],
                  "deterministic_across_two_runs": deterministic}

rec = sum(p["detected"] for p in res["planted"]) / len(res["planted"])
res["summary"] = {"planted_recall": round(rec, 3), "planted_detected": sum(p["detected"] for p in res["planted"]),
                  "planted_total": len(res["planted"]),
                  "no_flag_decoys_wrongly_flagged": sum(1 for d in res["decoys"] if d["kind"] == "no_flag_expected" and not d["as_expected"])}
print(json.dumps(res, indent=2))
if a.json_out: json.dump(res, open(a.json_out, "w"), indent=2)
