---
name: gia-fraud-analytics
description: "Deterministic fraud-indicator tests on CSV extracts with reason codes, innocent explanations and a coverage statement: ghost employee, shell vendor, duplicate payment, split purchase, journal override, Benford. Use when you need to run tests, screen a population, triage exceptions or look up a test ID. Do NOT use for investigation (use gia-fraud:gia-fraud-investigation)."
---

# Fraud Analytics

Executes the testing layer that the methodology skills describe. It does not replace
`gia-fraud:gia-fraud-investigation` (six-phase protocol, interviews, report) or
`gia-fraud:gia-fraud-risk-governance` (FRA, ABAC). Use those for method and this skill to run tests
on data and report results honestly. Rules cited by number are in `gia-core:iron-rules` (Rule 17: analytics output is an indicator, never finding evidence).

## Operating rules (non-negotiable)

1. **Hypothesis first.** State the objective, the scheme being tested (see
   `references/scheme-test-map.md`) and why this population. Do not start from "scan everything".
2. **Code computes, Claude interprets.** Never judge a ledger by reading it. Run the scripts; read
   their JSON. If a test has no script, say it was not run.
3. **Indicators, never intent.** Output says "indicator", "exception", "consistent with" (ladder level: indicator). It never
   says someone stole, intended, or is guilty, and never states motive (Rule 25). `scripts/check_report.py` enforces this before issue.
4. **Coverage honesty.** Every report states population, tests run, tests NOT run (and why),
   exceptions found, exceptions reviewed. `run_all.py` produces this; do not trim it.
5. **Innocent explanation first.** Each exception lists explanations to rule out. A reviewer clears
   an exception only by naming the explanation established (`triage.py` refuses blank reasons).
6. **Human gate.** Claude may flag, rank and draft. Promoting an exception to a case, naming a
   person, or concluding anything is the CAE's decision, with legal counsel before any subject interview.
7. **Evidence authenticity.** Documents and screenshots supplied as support can be synthetic or
   altered. Corroborate through an independent channel (bank confirmation, system log, third party)
   before relying on them; record the channel.
8. **Confidentiality.** Extracts contain personal and financial data. Do not paste them into tools
   that are not approved for the data. Case systems receive pseudonymous references only.

## Workflow

1. **Intake** (ask only for what is missing): entity, jurisdiction, process, period, trigger (plan /
   tip / anomaly), systems and extract dates, who has access to the population, any approval limits.
   State assumptions and facts separately. If the trigger is an allegation naming a person, stop and
   follow `gia-fraud:gia-fraud-investigation` Phase 1 (allegation assessment, evidence preservation, counsel).
2. **Plan.** Map hypotheses to tests with `references/scheme-test-map.md`; look up objective and script IDs in `references/test-id-registry.md`. Write the plan: test,
   data required, parameters, exception threshold set in advance, confirming procedure.
3. **Check data.** Columns per the schemas below; dates ISO `YYYY-MM-DD`. Reconcile extract totals to
   the ledger or system report before testing, and note the result. Unreconciled data is a limitation.
4. **Run.** Create a config (see `scripts/run_all.py` docstring) and run:
   `python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-fraud-analytics/scripts/run_all.py --config config.json --outdir out`
   Output: `out/findings.json`, `out/coverage_statement.md` (lists tests not run).
5. **Challenge.** Run the adversarial review in `references/adversarial-review.md` on every HIGH and
   MEDIUM exception: argue the innocent explanation, check the data for alternative causes, look for
   what would disprove the indicator. Use a separate pass; do not grade your own reasoning.
6. **Triage (human).** `python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-fraud-analytics/scripts/triage.py --findings out/findings.json --list --min-severity MEDIUM`
   then `--reviewer "<name>" --set <id>=PROMOTED` or `--set <id>=CLEARED:<reason>`.
7. **Report.** Use the template in `references/reporting-rules.md`, then
   `python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-fraud-analytics/scripts/check_report.py report.md`. A FAIL blocks issue.
8. **Case workflow (EXPERIMENTAL - the HubSpot flow has not been run end to end; user-invoked only).** For promoted exceptions only: set `FA_CASE_SALT`, run
   `python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-fraud-analytics/scripts/to_hubspot_import.py --findings out/findings.json --outdir hs`. Upload only
   `hubspot_tickets_REDACTED.csv`. Keep `SECURED_register_DO_NOT_UPLOAD.csv` in the restricted
   repository. Design and controls: `references/hubspot-case-workflow.md`.

## Data prerequisites

One currency per run (no conversion is done). Dates ISO `YYYY-MM-DD` (other formats stop with an input error rather than being guessed). Amounts numeric (symbols such as `RM` are not stripped; such rows are skipped and counted in the limitations). `findings.json` and the secured register contain record identifiers: store them in the restricted case repository, not in chat, shared drives or HubSpot.

## Input schemas (CSV, header row required, names case-insensitive)

| File | Required columns | Optional |
|---|---|---|
| vendors | vendor_id, name, address, phone, bank_account | tax_id |
| employees | emp_id, name, address, phone, bank_account | status, termination_date |
| payments | pay_id, vendor_id, invoice_no, amount, pay_date | po_no, approver |
| journal | je_id, posting_date, amount, user | posting_time, approver, account, description |
| payroll | period, emp_id, bank_account, paid_date | gross |
| attendance | period, emp_id, days_present | |
| headcount | period, statutory_headcount | |

## Test catalogue (FA-* = script IDs; objective IDs P/V/J/B/F/OB and the crosswalk are in `references/test-id-registry.md`)

| ID | Script | Detects | Key limits |
|---|---|---|---|
| FA-V1 | vendor_employee_match.py | vendor/employee match on bank, address, phone; shared vendor bank | exact match only; relatives with different details missed |
| FA-A1/A2 | threshold_split.py | clusters just under an approval limit; possible splits | A2 is noisy: 5-7 false flags per 6,000 clean payments; 11.9k exceptions on a 300k-row synthetic file with one approver. Use A2 as a ranked, low-priority queue or raise --min-fraction |
| FA-A3 | duplicate_payments.py | exact and near-duplicate payments | needs equal amounts; credit notes not netted; different POs suppressed |
| FA-J1 | je_testing.py | round sums, weekend/after-hours, period-end, missing/self approval, sequence gaps | system-user journals excluded and disclosed |
| FA-P1 | payroll_ghost.py | payee not in master, shared bank, paid after termination, no attendance, headcount gap | cannot find ghosts with unique accounts and plausible attendance |
| FA-B1 | benford.py | first-digit screen | refuses N<1000, narrow range, assigned amounts; blunt (see results) |

**Benford standard.** Primary measure is Nigrini MAD (band label) plus per-digit z-scores; chi-square is supplementary or for small N and is never used to escalate. Per-digit exceptions are raised only when MAD is marginal or worse. Every output records the MAD table version (`statistics.mad_table_version`); the band edges (0.006 / 0.012 / 0.015) are SECONDARY-ONLY (verified-on 2026-10-29) until checked against the primary book. First-digit only: second-digit and first-two-digit tests are NO SCRIPT YET.

## What the seeded-fraud evaluation showed (2026-10-29, `evals/`)

On one synthetic dataset (seed 42) the scripts detected 15 of 15 planted schemes, flagged none of
5 decoys designed not to trigger, and produced 5 to 7 unexplained exceptions on clean data (seeds 7 and 42), all from
FA-A2. Benford flagged tampering only when about 10% of records were fabricated (5% was missed at
both 5,000 and 20,000 records). **Treat this as a regression test, not proof of capability:** the
schemes and scripts share an author. Re-run against a dataset someone else built, and against
sanitised historical cases, before relying on detection rates.

## Escalate immediately (stop analytics, call the CAE)

An indicator touches a director, executive or the CAE's own reporting line; a tip names a person;
evidence may be destroyed; amounts or regulatory exposure are material; a statutory reporting duty
may apply (e.g. adequate-procedures considerations under the jurisdiction's ABAC regime; see `gia-fraud:gia-fraud-risk-governance`). Do not tip off the
subject. Preserve evidence first.

## Related skills

`gia-fraud:gia-fraud-investigation` (method, interviews, report) | `gia-fraud:gia-fraud-fsf-window-dressing` | `gia-report-qa` (pre-issue independent review and Board wording) | `gia-audit` (scope and independence before an engagement) | `gia-analytics:gia-payroll-analytics` (payroll and OT tests).
