#!/usr/bin/env python3
"""Run configured tests, merge results, and write findings.json + coverage_statement.md.

config.json example:
{"tests": {
  "FA-V1": {"script": "vendor_employee_match.py", "args": {"--vendors": "v.csv", "--employees": "e.csv"}},
  "FA-A1": {"script": "threshold_split.py", "args": {"--payments": "p.csv", "--threshold": "50000"}}}}
Tests in the catalogue that are not configured are listed explicitly as NOT RUN.
"""
import argparse, json, subprocess, sys
from pathlib import Path
from common import ALL_TESTS

ap = argparse.ArgumentParser()
ap.add_argument("--config", required=True)
ap.add_argument("--outdir", required=True)
a = ap.parse_args()
cfg = json.load(open(a.config))
out = Path(a.outdir); out.mkdir(parents=True, exist_ok=True)
here = Path(__file__).parent
results, errors = [], []
for tid, t in cfg["tests"].items():
    dest = out / f"{tid}.json"
    cmd = [sys.executable, str(here / t["script"]), "--out", str(dest)]
    for k, v in t["args"].items():
        cmd += [k, str(v)]
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode != 0:
        errors.append({"test_id": tid, "error": (p.stdout + p.stderr).strip()[-600:]})
        continue
    results.append(json.load(open(dest)))

covs, excs, run_ids = [], [], set()
for r in results:
    covs.append(r["coverage"]); excs += r["exceptions"]
    run_ids.add(r["coverage"]["test_id"])
    run_ids.update(r["coverage"].get("covers_tests", []))
not_run = {tid: name for tid, name in ALL_TESTS.items() if tid not in run_ids}
doc = {"coverage": covs, "tests_not_run": not_run, "input_errors": errors, "exceptions": excs}
json.dump(doc, open(out / "findings.json", "w"), indent=2)

L = ["# Coverage statement", "", "Exceptions are INDICATORS requiring review, not conclusions. Exceptions reviewed: 0 (to be updated by the reviewer).", ""]
L += ["| Test | Status | Population | Exceptions | Reviewed |", "|---|---|---|---|---|"]
for c in covs:
    L.append(f"| {c['test_id']} {c['test_name']} | {c['status']} | {c['population_tested']} | {c['exceptions_found']} | {c['exceptions_reviewed']} |")
for tid, nm in not_run.items():
    L.append(f"| {tid} {nm} | NOT RUN (not configured / data not supplied) | - | - | - |")
for e in errors:
    L.append(f"| {e['test_id']} | INPUT ERROR | - | - | - |")
L += ["", "## Limitations declared by each test"]
for c in covs:
    L.append(f"**{c['test_id']}**" + (f" — NOT APPLICABLE: {c['not_run_reason']}" if c["status"] != "RUN" else ""))
    L += [f"- {x}" for x in c["limitations"]]
if errors:
    L += ["", "## Input errors"] + [f"- {e['test_id']}: {e['error']}" for e in errors]
(out / "coverage_statement.md").write_text("\n".join(L) + "\n")
print(f"findings: {len(excs)} exceptions, {len(covs)} tests run, {len(not_run)} not run, {len(errors)} input errors")
