#!/usr/bin/env python3
"""FA-V1: match vendor master to employee master on bank account, address, phone;
also flag one bank account shared by several vendors. Deterministic, full population."""
import argparse
from collections import defaultdict
from common import *

ap = argparse.ArgumentParser()
ap.add_argument("--vendors", required=True)
ap.add_argument("--employees", required=True)
ap.add_argument("--out")
a = ap.parse_args()

vendors = read_csv(a.vendors, ["vendor_id", "name", "address", "phone", "bank_account"])
emps = read_csv(a.employees, ["emp_id", "name", "address", "phone", "bank_account"])

idx = {"bank": defaultdict(list), "addr": defaultdict(list), "phone": defaultdict(list)}
for e in emps:
    if norm_account(e["bank_account"]): idx["bank"][norm_account(e["bank_account"])].append(e["emp_id"])
    if len(norm_text(e["address"])) >= 8: idx["addr"][norm_text(e["address"])].append(e["emp_id"])
    if norm_phone(e["phone"]): idx["phone"][norm_phone(e["phone"])].append(e["emp_id"])

pairs = defaultdict(set)  # (vendor_id, emp_id) -> reason codes
for v in vendors:
    keys = (("bank", norm_account(v["bank_account"]), "VE-BANK"),
            ("addr", norm_text(v["address"]) if len(norm_text(v["address"])) >= 8 else "", "VE-ADDR"),
            ("phone", norm_phone(v["phone"]), "VE-PHONE"))
    for kind, key, code in keys:
        if key:
            for eid in idx[kind].get(key, []):
                pairs[(v["vendor_id"], eid)].add(code)

exc = []
for (vid, eid), codes in sorted(pairs.items()):
    sev = "HIGH" if ("VE-BANK" in codes or len(codes) >= 2) else "MEDIUM"
    for code in sorted(codes):
        exc.append(exception("FA-V1", code, {"vendor_id": vid, "emp_id": eid},
                             f"Vendor {vid} and employee {eid} share the same {code.split('-')[1].lower()} "
                             f"(all matching fields: {sorted(codes)})", sev))

by_bank = defaultdict(list)
for v in vendors:
    b = norm_account(v["bank_account"])
    if b: by_bank[b].append(v)
for b, vs in by_bank.items():
    names = {norm_text(v["name"]) for v in vs}
    if len(vs) > 1 and len(names) > 1:
        exc.append(exception("FA-V1", "VM-BANK-SHARED", {"vendor_ids": [v["vendor_id"] for v in vs]},
                             f"{len(vs)} vendor records with different names share one bank account", "MEDIUM"))

cov = coverage("FA-V1", [(a.vendors, len(vendors)), (a.employees, len(emps))], len(vendors),
               ["vendor_id", "name", "address", "phone", "bank_account", "emp_id"], {}, exc,
               limitations=["Exact match after normalisation; near-identical names/addresses are NOT matched",
                            "Addresses under 8 characters and phones under 9 digits are ignored",
                            "Relatives with different surnames/addresses/accounts are not detectable by this test"])
emit(a.out, cov, exc)
