#!/usr/bin/env python3
"""FA-J1: journal entry indicators. Combines indicators per JE; severity rises with count."""
import argparse, re
from collections import defaultdict
from common import *

ap = argparse.ArgumentParser()
ap.add_argument("--journal", required=True)
ap.add_argument("--round-base", type=float, default=1000)
ap.add_argument("--round-min", type=float, default=5000)
ap.add_argument("--period-end-days", type=int, default=2)
ap.add_argument("--period-end-min", type=float, default=50000)
ap.add_argument("--system-users", default="", help="comma list excluded from weekend/after-hours/round/approver tests")
ap.add_argument("--hours", default="08:00-19:00", help="business hours for after-hours test")
ap.add_argument("--out")
a = ap.parse_args()

rows = read_csv(a.journal, ["je_id", "posting_date", "amount", "user"])
sysu = {u.strip().upper() for u in a.system_users.split(",") if u.strip()}
h0, h1 = [tuple(int(x) for x in t.split(":")) for t in a.hours.split("-")]
has_time = "posting_time" in rows[0] if rows else False
has_appr = "approver" in rows[0] if rows else False

def month_end_gap(d):
    nxt = (d.replace(day=28) + __import__("datetime").timedelta(days=4)).replace(day=1)
    return (nxt - d).days - 1

codes = defaultdict(list)
tested, excluded, bad = 0, 0, 0
ids = []
for r in rows:
    amt = parse_amount(r["amount"])
    if amt is None:
        bad += 1
        continue
    amt = abs(amt)
    if r["user"].upper() in sysu:
        excluded += 1
        continue
    tested += 1
    d = parse_date(r["posting_date"])
    jid = r["je_id"]
    ids.append(jid)
    if amt >= a.round_min and amt % a.round_base == 0:
        codes[jid].append(("JE-ROUND", f"amount {amt:,.2f} is an exact multiple of {a.round_base:,.0f}"))
    if d.weekday() >= 5:
        codes[jid].append(("JE-WEEKEND", f"posted on {d.isoformat()} ({d.strftime('%A')})"))
    if has_time and r.get("posting_time"):
        hh, mm = [int(x) for x in r["posting_time"][:5].split(":")]
        if (hh, mm) < h0 or (hh, mm) > h1:
            codes[jid].append(("JE-AFTERHOURS", f"posted at {r['posting_time'][:5]}"))
    if month_end_gap(d) < a.period_end_days and amt >= a.period_end_min:
        codes[jid].append(("JE-PERIODEND", f"amount {amt:,.2f} posted within last {a.period_end_days} day(s) of month"))
    if has_appr:
        ap_ = r.get("approver", "")
        if not ap_:
            codes[jid].append(("JE-NO-APPROVER", "no approver recorded"))
        elif ap_.upper() == r["user"].upper():
            codes[jid].append(("JE-SELF-APPROVED", f"user and approver are both {r['user']}"))

exc = []
for jid, cl in codes.items():
    names = [c for c, _ in cl]
    score = len(names) + (1 if ("JE-SELF-APPROVED" in names or "JE-NO-APPROVER" in names) else 0)
    sev = "HIGH" if score >= 3 else "MEDIUM" if score == 2 else "LOW"
    exc.append(exception("FA-J1", names[0] if len(names) == 1 else "JE-MULTI", {"je_id": jid},
                         "; ".join(d for _, d in cl), sev,
                         extra={"indicators": names, "innocent_by_indicator": {c: INNOCENT.get(c, []) for c in names}}))
for e in exc:
    if e["reason_code"] == "JE-MULTI":
        e["innocent_explanations_to_rule_out"] = sorted({x for c in e["extra"]["indicators"] for x in INNOCENT.get(c, [])})

# sequence gaps (numeric suffix, single prefix only)
nums = []
for jid in ids:
    m = re.fullmatch(r"([A-Za-z\-_]*)(\d+)", jid)
    if m: nums.append((m.group(1), int(m.group(2))))
if nums and len({p for p, _ in nums}) == 1:
    s = sorted({n for _, n in nums})
    gaps = [(s[i] + 1, s[i + 1] - 1) for i in range(len(s) - 1) if s[i + 1] - s[i] > 1]
    for lo, hi in gaps[:200]:
        exc.append(exception("FA-J1", "JE-SEQ-GAP", {"missing_range": [lo, hi]},
                             f"journal numbers {lo}-{hi} absent from extract", "LOW"))

cov = coverage("FA-J1", [(a.journal, len(rows))], tested,
               ["je_id", "posting_date", "amount", "user"] + (["posting_time"] if has_time else []) + (["approver"] if has_appr else []),
               {k: getattr(a, k) for k in ("round_base", "round_min", "period_end_days", "period_end_min", "system_users", "hours")}, exc,
               limitations=[f"{excluded} system-user journals excluded from all tests (manual override of system accounts is NOT tested)",
                            f"{bad} rows skipped (non-numeric amount)",
                            "after-hours test " + ("run" if has_time else "NOT run: no posting_time column"),
                            "approver tests " + ("run" if has_appr else "NOT run: no approver column"),
                            "Account-pair, description-keyword and user-behaviour baselines are NOT tested"])
emit(a.out, cov, exc)
