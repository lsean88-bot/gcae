#!/usr/bin/env python3
"""Export PROMOTED exceptions as (a) a REDACTED CSV for the HubSpot case workflow and
(b) a SECURED register CSV that maps case refs to record identifiers. The register must NOT be
loaded into HubSpot. HubSpot receives pseudonymous case refs, test/reason codes and counts only.

Requires env FA_CASE_SALT (secret, stored outside HubSpot) so case refs cannot be reversed by
guessing record ids. Refuses to run without it.
"""
import argparse, csv, hashlib, hmac, json, os, sys
from pathlib import Path
from common import exc_id

ap = argparse.ArgumentParser()
ap.add_argument("--findings", required=True)
ap.add_argument("--outdir", required=True)
ap.add_argument("--pipeline", default="Fraud Indicator Cases")
ap.add_argument("--stage", default="1 Intake & triage")
a = ap.parse_args()
salt = os.environ.get("FA_CASE_SALT", "")
if len(salt) < 16:
    sys.exit("REFUSED: set FA_CASE_SALT (>=16 chars, secret, kept outside HubSpot) before exporting")
doc = json.load(open(a.findings))
cov = {}
for c in doc["coverage"]:
    cov[c["test_id"]] = c
    for t in c.get("covers_tests", []): cov[t] = c
out = Path(a.outdir); out.mkdir(parents=True, exist_ok=True)
rows, reg = [], []
for e in doc["exceptions"]:
    if e["status"] != "PROMOTED":
        continue
    xid = exc_id(e)
    ref = "FA-" + hmac.new(salt.encode(), xid.encode(), hashlib.sha256).hexdigest()[:10].upper()
    c = cov[e["test_id"]]
    rows.append({
        "Ticket name": f"{ref} {e['reason_code']}",
        "Pipeline": a.pipeline, "Ticket status": a.stage,
        "Ticket description": (f"Indicator {e['reason_code']} raised by test {e['test_id']}. "
                               f"Identifiers are held in the secured case register under {ref}. "
                               "No personal identifiers, evidence or allegations belong in this record or its notes."),
        "fa_case_ref": ref, "fa_test_id": e["test_id"], "fa_reason_code": e["reason_code"],
        "fa_review_priority": e["severity_indicator"], "fa_population_tested": c["population_tested"],
        "fa_script_version": c["script_version"], "fa_run_utc": c["run_utc"],
        "fa_innocent_explanations_open": "; ".join(e["innocent_explanations_to_rule_out"]),
    })
    reg.append({"fa_case_ref": ref, "exception_id": xid, "test_id": e["test_id"], "reason_code": e["reason_code"],
                "record_ids": json.dumps(e["record_ids"]), "detail": e["detail"],
                "reviewer": e.get("review", {}).get("reviewer", ""), "promoted_utc": e.get("review", {}).get("utc", "")})
def wr(name, data):
    if not data:
        (out / name).write_text(""); return
    with open(out / name, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(data[0])); w.writeheader(); w.writerows(data)
wr("hubspot_tickets_REDACTED.csv", rows)
wr("SECURED_register_DO_NOT_UPLOAD.csv", reg)
print(f"exported {len(rows)} promoted exception(s); HubSpot file has no record identifiers", file=sys.stderr)
