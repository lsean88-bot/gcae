#!/usr/bin/env python3
"""FA-A3: exact and near-duplicate payments."""
import argparse, difflib, re
from collections import defaultdict
from common import *

ap = argparse.ArgumentParser()
ap.add_argument("--payments", required=True)
ap.add_argument("--near-days", type=int, default=7)
ap.add_argument("--similarity", type=float, default=0.80)
ap.add_argument("--out")
a = ap.parse_args()

rows = read_csv(a.payments, ["pay_id", "vendor_id", "invoice_no", "amount", "pay_date"])

def norm_inv(s):
    s = re.sub(r"[^A-Z0-9]", "", (s or "").upper())
    return re.sub(r"(?<![0-9])0+(?=[0-9])", "", s)

pay, bad = [], 0
for r in rows:
    amt = parse_amount(r["amount"])
    if amt is None or amt <= 0 or not r["invoice_no"]:
        bad += 1
        continue
    pay.append({**r, "amt": round(amt, 2), "d": parse_date(r["pay_date"]), "inv": norm_inv(r["invoice_no"])})

by_v = defaultdict(list)
for p in pay: by_v[p["vendor_id"]].append(p)

exc = []
for vid, ps in by_v.items():
    by_amt = defaultdict(list)
    for p in ps:
        by_amt[p["amt"]].append(p)
    for amt, grp in by_amt.items():
        if len(grp) < 2:
            continue
        exact_pairs = set()
        by_inv = defaultdict(list)
        for p in grp:
            by_inv[p["inv"]].append(p)
        for inv, bucket in by_inv.items():
            for i in range(len(bucket)):
                for j in range(i + 1, len(bucket)):
                    key = tuple(sorted((bucket[i]["pay_id"], bucket[j]["pay_id"])))
                    exact_pairs.add(key)
                    exc.append(exception("FA-A3", "DUP-EXACT", {"vendor_id": vid, "pay_ids": list(key)},
                                         f"Same vendor, same normalised invoice number '{inv}', same amount {amt:,.2f}", "HIGH"))
        grp.sort(key=lambda p: p["d"])  # near-duplicates: scan only within the day window
        for i in range(len(grp)):
            j = i + 1
            while j < len(grp) and (grp[j]["d"] - grp[i]["d"]).days <= a.near_days:
                p, q = grp[i], grp[j]
                key = tuple(sorted((p["pay_id"], q["pay_id"])))
                j += 1
                if key in exact_pairs or p["inv"] == q["inv"]:
                    continue
                po1, po2 = p.get("po_no", ""), q.get("po_no", "")
                if po1 and po2 and po1 != po2:
                    continue  # different purchase orders: treated as separate purchases
                if difflib.SequenceMatcher(None, p["inv"], q["inv"]).ratio() >= a.similarity:
                    exc.append(exception("FA-A3", "DUP-NEAR", {"vendor_id": vid, "pay_ids": list(key)},
                                         f"Same amount {amt:,.2f}, invoice numbers '{p['invoice_no']}' vs '{q['invoice_no']}' "
                                         f"within {a.near_days} days", "MEDIUM"))

cov = coverage("FA-A3", [(a.payments, len(rows))], len(pay), ["pay_id", "vendor_id", "invoice_no", "amount", "pay_date", "po_no(optional)"],
               {"near_days": a.near_days, "similarity": a.similarity}, exc,
               limitations=[f"{bad} rows skipped (missing invoice number or non-positive/non-numeric amount)",
                            "Credit notes/reversals are not netted; supply them or review exceptions against them",
                            "Near-duplicates need identical amounts; duplicates with altered amounts are not detected",
                            "Pairs with different PO numbers are suppressed (assumption: separate purchases)"])
emit(a.out, cov, exc)
