#!/usr/bin/env python3
"""FA-A1 / FA-A2: purchases clustered just below an approval threshold, and possible
splits (several payments to one vendor in a short window whose sum crosses the threshold)."""
import argparse
from collections import defaultdict
from common import *

ap = argparse.ArgumentParser()
ap.add_argument("--payments", required=True)
ap.add_argument("--threshold", type=float, required=True)
ap.add_argument("--band", type=float, default=0.10, help="just-below band as fraction of threshold")
ap.add_argument("--window-days", type=int, default=5)
ap.add_argument("--min-count", type=int, default=3, help="payments in band needed for FA-A1")
ap.add_argument("--min-fraction", type=float, default=0.30, help="FA-A2: each payment >= this fraction of threshold")
ap.add_argument("--out")
a = ap.parse_args()

rows = read_csv(a.payments, ["pay_id", "vendor_id", "amount", "pay_date"])
pay = []
bad = 0
for r in rows:
    amt = parse_amount(r["amount"])
    if amt is None or amt <= 0:
        bad += 1
        continue
    pay.append({**r, "amt": amt, "d": parse_date(r["pay_date"])})
by_v = defaultdict(list)
for p in pay: by_v[p["vendor_id"]].append(p)

exc, covered = [], set()
lo = a.threshold * (1 - a.band)
for vid, ps in by_v.items():
    ps.sort(key=lambda p: p["d"])
    inband = [p for p in ps if lo <= p["amt"] < a.threshold]
    i = 0
    while i < len(inband):
        j = i
        while j + 1 < len(inband) and (inband[j + 1]["d"] - inband[i]["d"]).days <= a.window_days:
            j += 1
        cl = inband[i:j + 1]
        if len(cl) >= a.min_count:
            ids = [p["pay_id"] for p in cl]
            covered.update(ids)
            exc.append(exception("FA-A1", "JUST-BELOW-CLUSTER", {"vendor_id": vid, "pay_ids": ids},
                                 f"{len(cl)} payments of {min(p['amt'] for p in cl):,.2f}-{max(p['amt'] for p in cl):,.2f} "
                                 f"within {a.window_days} days, each just under threshold {a.threshold:,.2f}", "HIGH"))
            i = j + 1
        else:
            i += 1
    cand = [p for p in ps if a.min_fraction * a.threshold <= p["amt"] < a.threshold]
    i = 0
    while i < len(cand):
        j = i
        while j + 1 < len(cand) and (cand[j + 1]["d"] - cand[i]["d"]).days <= a.window_days:
            j += 1
        cl = cand[i:j + 1]
        approvers = {p.get("approver", "") for p in cl}
        same_approver = len(approvers) == 1
        if len(cl) >= 2 and sum(p["amt"] for p in cl) >= a.threshold and same_approver \
                and not all(p["pay_id"] in covered for p in cl):
            exc.append(exception("FA-A2", "SPLIT-AGGREGATE", {"vendor_id": vid, "pay_ids": [p["pay_id"] for p in cl]},
                                 f"{len(cl)} payments summing {sum(p['amt'] for p in cl):,.2f} (>= threshold) within "
                                 f"{a.window_days} days, each below threshold", "MEDIUM"))
            i = j + 1
        else:
            i += 1

cov = coverage("FA-A1", [(a.payments, len(rows))], len(pay), ["pay_id", "vendor_id", "amount", "pay_date"],
               {k: getattr(a, k) for k in ("threshold", "band", "window_days", "min_count", "min_fraction")}, exc,
               limitations=[f"{bad} rows skipped (non-numeric or non-positive amounts)",
                            "FA-A2 requires identical approver values across the cluster when an approver column exists; "
                            "if the column is absent all clusters qualify (higher false positives)",
                            "Splits spread beyond the window, or across vendors, are not detected"])
cov["covers_tests"] = ["FA-A1", "FA-A2"]
emit(a.out, cov, exc)
