#!/usr/bin/env python3
"""Pre-issue check for a fraud-indicator report (markdown/text).

Checks (heuristic; a PASS does not prove the report is sound):
  1. Required elements present: coverage statement, tests not run, exceptions reviewed,
     innocent explanations, limitations.
  2. Intent/guilt assertions: lines that state intent or guilt as fact are listed for human review.
Exit code 1 if any required element is missing or any assertion line is found.
"""
import argparse, json, re, sys
ap = argparse.ArgumentParser()
ap.add_argument("report")
a = ap.parse_args()
text = open(a.report, encoding="utf-8").read()
low = text.lower()

required = {
    "coverage statement": r"coverage",
    "tests not run": r"(not run|not tested|tests not run)",
    "exceptions reviewed": r"(exceptions? reviewed|reviewed exceptions)",
    "innocent explanations": r"(innocent|benign|alternative) explanation",
    "limitations": r"limitation",
}
missing = [k for k, pat in required.items() if not re.search(pat, low)]

assertion_patterns = [
    r"\b(is|was|are|were) (guilty|fraudulent)\b",
    r"\bcommitted (the )?fraud\b",
    r"\b(stole|stolen|embezzled|defrauded|misappropriated)\b",
    r"\bfraudulent intent (was|is|has been) (proven|established|confirmed|shown)\b",
    r"\b(proves?|proved|confirm(s|ed)?) (the )?fraud\b",
    r"\bdeliberately (falsified|manipulated|inflated)\b",
    r"\bknowingly\b",
]
flagged = []
for i, line in enumerate(text.splitlines(), 1):
    l = line.lower()
    if re.search(r"\b(no evidence|not (evidence|proof)|cannot (prove|conclude)|does not (prove|establish)|indicator)", l):
        continue
    for pat in assertion_patterns:
        if re.search(pat, l):
            flagged.append({"line": i, "text": line.strip()[:200]})
            break
res = {"missing_required_elements": missing, "assertion_lines_for_review": flagged,
       "result": "PASS" if not missing and not flagged else "FAIL"}
print(json.dumps(res, indent=2))
sys.exit(0 if res["result"] == "PASS" else 1)
