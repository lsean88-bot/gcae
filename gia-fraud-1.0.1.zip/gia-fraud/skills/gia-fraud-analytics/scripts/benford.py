#!/usr/bin/env python3
"""FA-B1: Benford first-digit SCREEN. Refuses populations where the test is not valid.

Refusal rules (documented, parameterised):
  * N < --min-n (default 1000): too small, many false positives (source: ISACA/Miller Kaplan summaries)
  * value range under --min-orders orders of magnitude (default 2): data not spread enough
  * most frequent exact value exceeds --max-repeat-share (default 5%): looks like assigned/capped
    numbers (per diems, fixed fees). The 5% figure is a heuristic of this tool, not a published rule.

Output reports MAD (mean absolute deviation) as the magnitude measure alongside z-scores and
chi-square, because with large N chi-square flags trivially small deviations.
MAD conformity bands (MAD_TABLE below) follow Nigrini's first-digit table (2012 edition).
[SECONDARY-ONLY (verified-on 2026-10-29): confirm against the Nigrini 2012 book before citing in a report.
 The alternative 0.004/0.008/0.012 set conflicts with two sources and is not used.]
The table version in force is written to every output (statistics.mad_table_version), including
NOT_APPLICABLE runs, so a reader can tell which band edges produced the label.
Primary measure: MAD + per-digit z-scores. Chi-square is supplementary (small N or cross-check only).
"""
import argparse, math
from collections import Counter, defaultdict
from common import *

ap = argparse.ArgumentParser()
ap.add_argument("--input", required=True)
ap.add_argument("--column", default="amount")
ap.add_argument("--id-column", default="")
ap.add_argument("--group-column", default="", help="optional (e.g. vendor_id) to list where flagged digits concentrate")
ap.add_argument("--min-n", type=int, default=1000)
ap.add_argument("--min-orders", type=float, default=2.0)
ap.add_argument("--max-repeat-share", type=float, default=0.05)
ap.add_argument("--out")
a = ap.parse_args()

req = [a.column] + ([a.id_column] if a.id_column else []) + ([a.group_column] if a.group_column else [])
rows = read_csv(a.input, req)
vals = []
dropped = 0
for r in rows:
    v = parse_amount(r[a.column])
    if v is None or v <= 0:
        dropped += 1
        continue
    vals.append((v, r))

def first_digit(v):
    s = f"{v:.10e}"
    return int(s[0])

def chi2_sf_df8(x):  # closed form for even df: exp(-x/2) * sum_{k<4} (x/2)^k / k!
    h = x / 2.0
    return math.exp(-h) * sum(h ** k / math.factorial(k) for k in range(4))

MAD_TABLE_VERSION = "Nigrini-2012-first-digit: 0.006 / 0.012 / 0.015 [SECONDARY-ONLY: quoted in arXiv 1311.4787 and 2309.06965; primary book not checked; verified-on 2026-10-29]"
MAD_EDGES = (0.006, 0.012, 0.015)

def band(mad):
    e1, e2, e3 = MAD_EDGES
    return ("close conformity" if mad < e1 else "acceptable conformity" if mad < e2
            else "marginally acceptable" if mad < e3 else "nonconformity")

n = len(vals)
refusals = []
if n < a.min_n:
    refusals.append(f"N={n} is below minimum {a.min_n}")
if n:
    mn, mx = min(v for v, _ in vals), max(v for v, _ in vals)
    orders = math.log10(mx / mn) if mn > 0 else 0
    if orders < a.min_orders:
        refusals.append(f"value range spans only {orders:.1f} orders of magnitude (< {a.min_orders})")
    top_share = Counter(round(v, 2) for v, _ in vals).most_common(1)[0][1] / n
    if top_share > a.max_repeat_share:
        refusals.append(f"most frequent exact value is {top_share:.1%} of records (> {a.max_repeat_share:.0%}): looks like assigned/capped amounts")

exc = []
extra_info = {}
if refusals:
    cov = coverage("FA-B1", [(a.input, len(rows))], n, [a.column], {"min_n": a.min_n, "min_orders": a.min_orders,
                   "max_repeat_share": a.max_repeat_share}, exc, status="NOT_APPLICABLE",
                   not_run_reason="; ".join(refusals),
                   limitations=[f"{dropped} rows dropped (non-numeric or non-positive)"])
    cov["statistics"] = {"mad_table_version": MAD_TABLE_VERSION}
else:
    cnt = Counter(first_digit(v) for v, _ in vals)
    table, mad_sum, flagged = [], 0.0, []
    for d in range(1, 10):
        ep = math.log10(1 + 1 / d)
        ap_ = cnt.get(d, 0) / n
        z = (abs(ap_ - ep) - 1 / (2 * n)) / math.sqrt(ep * (1 - ep) / n)
        mad_sum += abs(ap_ - ep)
        table.append({"digit": d, "expected": round(ep, 4), "actual": round(ap_, 4), "z": round(z, 2)})
        if z > 1.96:
            flagged.append((d, ap_ - ep, z))
    mad = mad_sum / 9
    chi = sum(((cnt.get(d, 0) - n * math.log10(1 + 1 / d)) ** 2) / (n * math.log10(1 + 1 / d)) for d in range(1, 10))
    p = chi2_sf_df8(chi)
    extra_info = {"mad_table_version": MAD_TABLE_VERSION, "digit_table": table, "mad": round(mad, 5), "mad_band": band(mad),
                  "chi_square": round(chi, 2), "chi_square_p": p,
                  "chi_square_role": "supplementary only; not used for escalation"}
    # Only raise digit exceptions when the overall magnitude measure (MAD) is marginal or worse.
    # Per-digit z-scores alone are not enough: with 9 digits tested, ~1 in 2 clean populations
    # will show a digit above z=1.96 by chance (found by the seeded-data eval, 2026-10-29).
    if band(mad) in ("close conformity", "acceptable conformity"):
        flagged = []
        extra_info["digit_exceptions_suppressed"] = "MAD indicates conformity; per-digit z-scores recorded in digit_table only"
    for d, dev, z in flagged:
        leads = []
        if a.group_column:
            g = Counter(r[a.group_column] for v, r in vals if first_digit(v) == d)
            leads = [{"group": k, "records_with_digit": c, "share_of_digit": round(c / cnt[d], 3)} for k, c in g.most_common(5)]
        sev = "MEDIUM" if band(mad) == "nonconformity" else "LOW"
        exc.append(exception("FA-B1", "BEN-DIGIT-DEV", {"digit": d},
                             f"Digit {d}: actual {cnt[d]/n:.1%} vs expected {math.log10(1+1/d):.1%} (z={z:.1f}); "
                             f"overall MAD={mad:.4f} ({band(mad)})", sev, extra={"concentration_leads": leads}))
    cov = coverage("FA-B1", [(a.input, len(rows))], n, [a.column], {"min_n": a.min_n, "min_orders": a.min_orders,
                   "max_repeat_share": a.max_repeat_share}, exc,
                   limitations=[f"{dropped} rows dropped (non-numeric or non-positive)",
                                "Screening only: cannot prove fraud and cannot detect one or two falsified entries",
                                "Concentration leads are targeting hints, not findings",
                                "First-digit test only; second-digit/first-two-digit tests not run"])
    cov["statistics"] = extra_info
emit(a.out, cov, exc)
