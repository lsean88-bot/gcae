#!/usr/bin/env python3
"""Shared helpers for gia-fraud-analytics. Standard library only.

Design rules enforced here:
  * every test emits a coverage block (population, fields, parameters, input hash)
  * every exception carries a reason code and the innocent explanations to rule out
  * severity_indicator is a review-priority hint, never a conclusion about intent
"""
import csv, hashlib, json, re, sys, datetime as dt
from pathlib import Path

VERSION = "0.1.0"

INNOCENT = {
    "VE-BANK": ["Employee reimbursement/expense payee set up as a vendor", "Data-entry error in bank field", "Approved related-party arrangement on file"],
    "VE-ADDR": ["Shared building or business-centre address", "Related party disclosed in a conflict-of-interest declaration", "Stale or copied master data"],
    "VE-PHONE": ["Company switchboard or shared family mobile", "Master-data copy/paste", "Disclosed related party"],
    "VM-BANK-SHARED": ["Group companies banking through one account", "Factoring/collection agent receives payments for several vendors", "Duplicate vendor record for one legal entity"],
    "JUST-BELOW-CLUSTER": ["Recurring legitimate service billed in fixed instalments", "Catalogue price that happens to sit near the limit", "Approval limit not known to requesters"],
    "SPLIT-AGGREGATE": ["Genuinely separate purchases for separate needs", "Framework/call-off orders under one approved contract", "Staggered delivery billed as delivered"],
    "DUP-EXACT": ["Reversal/credit note not matched in the extract", "Invoice re-issued after rejection and first payment recalled", "Data extracted twice"],
    "DUP-NEAR": ["Legitimate repeat order of the same value", "Instalments of equal amounts", "Different PO/delivery not captured in the extract"],
    "JE-ROUND": ["Fixed rent, retainers, accrual standards", "Intercompany recharges at agreed round sums"],
    "JE-WEEKEND": ["Month-end close working weekends", "Time-zone differences in posting timestamps"],
    "JE-AFTERHOURS": ["Close-period overtime", "Shift working or offshore finance team"],
    "JE-PERIODEND": ["Normal period-end accruals and true-ups", "Cut-off corrections approved by controller"],
    "JE-NO-APPROVER": ["Workflow does not record approver for low-risk journals", "Approver field not included in extract"],
    "JE-SELF-APPROVED": ["Small-entity setup with one finance user", "Delegation during leave not recorded"],
    "JE-SEQ-GAP": ["Voided/deleted drafts consuming numbers", "Numbering by batch/ledger"],
    "GH-NOT-IN-MASTER": ["Master extract date earlier than payroll run", "Contract/agency workers paid via payroll outside HR master"],
    "GH-DUP-BANK": ["Spouses/family sharing a joint account", "Agency or cooperative payment account", "Data-entry error"],
    "GH-PAID-AFTER-TERM": ["Final settlement, leave encashment, notice pay", "Termination date keyed late or wrongly"],
    "GH-NO-ATTENDANCE": ["Paid leave, long medical leave, or remote work not captured", "Attendance extract incomplete for the period"],
    "GH-BANK-MISMATCH": ["Employee changed bank account with approved form", "Master not yet updated"],
    "GH-HEADCOUNT-GAP": ["Timing differences in statutory submissions", "Excluded categories (directors, expatriates, interns)"],
    "BEN-DIGIT-DEV": ["Naturally non-conforming process (price points, thresholds)", "Large-N sensitivity: tiny deviations become 'significant'", "Mixed populations combined in one extract"],
}

ALL_TESTS = {
    "FA-V1": "Vendor/employee master match (bank, address, phone) and shared vendor bank accounts",
    "FA-A1": "Purchases just below an approval threshold (clustered by vendor)",
    "FA-A2": "Possible split purchases (sum over threshold, same vendor, short window)",
    "FA-A3": "Duplicate and near-duplicate payments",
    "FA-J1": "Journal entries: round sums, weekend/after-hours, period-end, approval gaps, sequence gaps",
    "FA-P1": "Payroll: ghost-employee indicators (master, bank, termination, attendance, headcount)",
    "FA-B1": "Benford first-digit screen (screening only; refuses invalid populations)",
}


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def read_csv(path, required, optional=()):
    p = Path(path)
    if not p.exists():
        sys.exit(f"INPUT_ERROR: file not found: {path}")
    with open(p, newline="", encoding="utf-8-sig") as f:
        rdr = csv.DictReader(f)
        if rdr.fieldnames is None:
            sys.exit(f"INPUT_ERROR: {path} is empty")
        names = {re.sub(r"[^a-z0-9]+", "_", n.strip().lower()).strip("_"): n for n in rdr.fieldnames}
        missing = [c for c in required if c not in names]
        if missing:
            sys.exit(f"INPUT_ERROR: {path} missing required column(s) {missing}; found {sorted(names)}")
        rows = []
        for raw in rdr:
            rows.append({k: (raw.get(orig) or "").strip() for k, orig in names.items()})
    return rows


def norm_text(s):
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]+", " ", (s or "").lower())).strip()


def norm_account(s):
    return re.sub(r"[\s\-]", "", (s or "")).upper()


def norm_phone(s):
    d = re.sub(r"\D", "", s or "")
    return d[-9:] if len(d) >= 9 else ""


def parse_date(s):
    try:
        return dt.date.fromisoformat((s or "").strip()[:10])
    except ValueError:
        raise SystemExit(f"INPUT_ERROR: dates must be ISO YYYY-MM-DD, got '{s}'")


def parse_amount(s):
    try:
        return float(re.sub(r"[,\s]", "", s))
    except (ValueError, TypeError):
        return None


def exception(test_id, reason_code, record_ids, detail, severity="LOW", extra=None):
    e = {
        "test_id": test_id,
        "reason_code": reason_code,
        "record_ids": record_ids,
        "detail": detail,
        "severity_indicator": severity,  # review-priority hint only, never a conclusion
        "innocent_explanations_to_rule_out": INNOCENT.get(reason_code, []),
        "status": "UNREVIEWED",
    }
    if extra:
        e["extra"] = extra
    return e


def coverage(test_id, inputs, population, fields, params, exceptions, status="RUN",
             not_run_reason=None, limitations=()):
    return {
        "test_id": test_id,
        "test_name": ALL_TESTS.get(test_id, ""),
        "script_version": VERSION,
        "run_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "status": status,
        "not_run_reason": not_run_reason,
        "input_files": [{"path": str(p), "sha256": sha256_file(p), "rows": n} for p, n in inputs],
        "population_tested": population,
        "fields_used": list(fields),
        "parameters": params,
        "exceptions_found": len(exceptions),
        "exceptions_reviewed": 0,
        "limitations": list(limitations),
    }


def emit(out_path, cov, exceptions):
    doc = {"coverage": cov, "exceptions": exceptions}
    if out_path:
        Path(out_path).parent.mkdir(parents=True, exist_ok=True)
        with open(out_path, "w") as f:
            json.dump(doc, f, indent=2)
    print(f"[{cov['test_id']}] status={cov['status']} population={cov['population_tested']} "
          f"exceptions={cov['exceptions_found']}", file=sys.stderr)
    return doc


def exc_id(e):
    """Stable short id for an exception (test + reason + record ids)."""
    raw = json.dumps([e["test_id"], e["reason_code"], e["record_ids"]], sort_keys=True)
    return "X" + hashlib.sha256(raw.encode()).hexdigest()[:8]
