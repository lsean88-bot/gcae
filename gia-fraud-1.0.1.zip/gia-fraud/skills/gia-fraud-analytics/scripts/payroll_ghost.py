#!/usr/bin/env python3
"""FA-P1: ghost-employee indicators from payroll vs HR master, attendance and statutory headcount."""
import argparse
from collections import defaultdict
from common import *

ap = argparse.ArgumentParser()
ap.add_argument("--employees", required=True, help="emp_id,status,termination_date,bank_account")
ap.add_argument("--payroll", required=True, help="period,emp_id,gross,bank_account,paid_date")
ap.add_argument("--attendance", help="period,emp_id,days_present (optional)")
ap.add_argument("--headcount", help="period,statutory_headcount (optional; e.g. EPF/SOCSO submissions)")
ap.add_argument("--grace-days", type=int, default=30)
ap.add_argument("--headcount-tolerance", type=int, default=0)
ap.add_argument("--out")
a = ap.parse_args()

emps = {e["emp_id"]: e for e in read_csv(a.employees, ["emp_id", "bank_account"])}
pr = read_csv(a.payroll, ["period", "emp_id", "bank_account", "paid_date"])
att = read_csv(a.attendance, ["period", "emp_id", "days_present"]) if a.attendance else None
hc = read_csv(a.headcount, ["period", "statutory_headcount"]) if a.headcount else None

exc = []
seen = set()
def add(code, key, rid, detail, sev):
    if (code, key) in seen: return
    seen.add((code, key))
    exc.append(exception("FA-P1", code, rid, detail, sev))

for r in pr:
    e = emps.get(r["emp_id"])
    if e is None:
        add("GH-NOT-IN-MASTER", (r["emp_id"],), {"emp_id": r["emp_id"], "period": r["period"]},
            f"emp {r['emp_id']} paid in {r['period']} but absent from HR master", "HIGH")
        continue
    mb, pb = norm_account(e["bank_account"]), norm_account(r["bank_account"])
    if mb and pb and mb != pb:
        add("GH-BANK-MISMATCH", (r["emp_id"], r["period"]), {"emp_id": r["emp_id"], "period": r["period"]},
            f"payroll bank account differs from master in {r['period']}", "MEDIUM")
    td = e.get("termination_date", "")
    if td and r["paid_date"]:
        if (parse_date(r["paid_date"]) - parse_date(td)).days > a.grace_days:
            add("GH-PAID-AFTER-TERM", (r["emp_id"], r["period"]), {"emp_id": r["emp_id"], "period": r["period"]},
                f"paid {r['paid_date']}, {(parse_date(r['paid_date']) - parse_date(td)).days} days after termination {td} (grace {a.grace_days})", "HIGH")

bank_emps = defaultdict(set)
for r in pr:
    b = norm_account(r["bank_account"])
    if b: bank_emps[b].add(r["emp_id"])
for b, es in bank_emps.items():
    if len(es) > 1:
        add("GH-DUP-BANK", (b,), {"emp_ids": sorted(es)}, f"{len(es)} employees paid into one bank account", "HIGH")

att_periods = set()
if att:
    present = {(x["period"], x["emp_id"]): parse_amount(x["days_present"]) for x in att}
    att_periods = {x["period"] for x in att}
    for r in pr:
        if r["period"] in att_periods:
            dp = present.get((r["period"], r["emp_id"]))
            if dp is None or dp == 0:
                add("GH-NO-ATTENDANCE", (r["emp_id"], r["period"]), {"emp_id": r["emp_id"], "period": r["period"]},
                    f"paid in {r['period']} with " + ("no attendance record" if dp is None else "zero days present"), "MEDIUM")

if hc:
    paid = defaultdict(set)
    for r in pr: paid[r["period"]].add(r["emp_id"])
    for x in hc:
        stat = int(float(x["statutory_headcount"]))
        n = len(paid.get(x["period"], ()))
        if n - stat > a.headcount_tolerance:
            add("GH-HEADCOUNT-GAP", (x["period"],), {"period": x["period"]},
                f"{n} employees paid vs {stat} in statutory submission (gap {n - stat})", "MEDIUM")

cov = coverage("FA-P1", [(a.employees, len(emps)), (a.payroll, len(pr))], len(pr),
               ["emp_id", "bank_account", "paid_date", "termination_date", "period"],
               {"grace_days": a.grace_days, "headcount_tolerance": a.headcount_tolerance}, exc,
               limitations=["attendance test " + (f"run for periods {sorted(att_periods)}" if att else "NOT run: no attendance file"),
                            "headcount test " + ("run" if hc else "NOT run: no statutory headcount file"),
                            "Ghosts with unique bank accounts and plausible attendance are NOT detectable from these data alone",
                            "Physical verification (payout/ID check) is the confirming procedure and is outside this script"])
emit(a.out, cov, exc)
