#!/usr/bin/env python3
"""Human gate: record a reviewer's decision on exceptions in findings.json.

  triage.py --findings out/findings.json --list [--min-severity MEDIUM]
  triage.py --findings out/findings.json --reviewer "Name" --set X1a2b3c4d=PROMOTED --set X5e6f7a8b=CLEARED:legit rent

Statuses: UNREVIEWED (default) | PROMOTED (worth a case) | CLEARED (innocent explanation established; reason required).
Updating a status increments exceptions_reviewed in the matching coverage block, so the coverage
statement stays honest. Only PROMOTED exceptions can be exported to the case workflow.
"""
import argparse, json, datetime as dt
from common import exc_id

ap = argparse.ArgumentParser()
ap.add_argument("--findings", required=True)
ap.add_argument("--list", action="store_true")
ap.add_argument("--min-severity", default="LOW", choices=["LOW", "MEDIUM", "HIGH"])
ap.add_argument("--reviewer")
ap.add_argument("--set", action="append", default=[])
a = ap.parse_args()
doc = json.load(open(a.findings))
rank = {"LOW": 0, "MEDIUM": 1, "HIGH": 2}

if a.list:
    for e in doc["exceptions"]:
        if rank[e["severity_indicator"]] >= rank[a.min_severity]:
            print(f"{exc_id(e)}  {e['severity_indicator']:6} {e['status']:10} {e['test_id']} {e['reason_code']}: {e['detail'][:110]}")
    raise SystemExit(0)

if a.set and not a.reviewer:
    raise SystemExit("--reviewer is required when setting statuses")
by_id = {exc_id(e): e for e in doc["exceptions"]}
cov_by_test = {}
for c in doc["coverage"]:
    cov_by_test[c["test_id"]] = c
    for t in c.get("covers_tests", []): cov_by_test[t] = c
for item in a.set:
    key, _, val = item.partition("=")
    status, _, reason = val.partition(":")
    if key not in by_id: raise SystemExit(f"unknown exception id {key}")
    if status not in ("PROMOTED", "CLEARED"): raise SystemExit("status must be PROMOTED or CLEARED")
    if status == "CLEARED" and not reason.strip(): raise SystemExit("CLEARED requires a reason after ':' (the innocent explanation established)")
    e = by_id[key]
    was_unreviewed = e["status"] == "UNREVIEWED"
    e["status"] = status
    e["review"] = {"reviewer": a.reviewer, "utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "reason": reason.strip()}
    if was_unreviewed: cov_by_test[e["test_id"]]["exceptions_reviewed"] += 1
json.dump(doc, open(a.findings, "w"), indent=2)
print(f"updated {len(a.set)} exception(s)")
