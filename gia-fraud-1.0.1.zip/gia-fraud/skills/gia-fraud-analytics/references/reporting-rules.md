# Reporting rules and template

## Wording
| Use | Never use |
|---|---|
| indicator, exception, consistent with, requires explanation | stole, embezzled, fraudulent intent, guilty, proves fraud |
| "does not establish intent" | "knowingly", "deliberately" (unless a finding of fact, established by evidence and reviewed by counsel) |
| "no evidence yet of loss" / "loss not quantified" | amounts presented as losses before confirmation |

Separate in the text: **facts** (from data, with source), **inferences**, **assumptions**, **open questions**.

## Template (all sections mandatory)
1. **Objective and trigger** — why this was done; who requested it.
2. **Coverage statement** — population per test, extract date and reconciliation result, tests run,
   **tests not run and why**, exceptions found, **exceptions reviewed** (n of N), parameters.
3. **Indicators** — per promoted exception: reason code, facts, priority, **innocent explanations
   considered and which were ruled out or remain open**, confirming procedure and owner.
4. **Cleared exceptions** — count and the explanations established (reviewer, date).
5. **Limitations** — per test (copied from the coverage block) plus data quality issues.
6. **Next steps and decisions needed from the CAE** — including whether to engage counsel.
7. **Evidence authenticity note** — how supplied documents were corroborated.

## Pre-issue check
`python3 ${CLAUDE_PLUGIN_ROOT}/skills/gia-fraud-analytics/scripts/check_report.py report.md` must PASS. It is a heuristic: a pass does not prove the
report is sound. A FAIL blocks issue. Any flagged line is reworded or justified in writing.

## Audience
Board/AC wording: `gia-report-qa:board-brief`. External submissions (regulator, auditor):
`gia-report-qa:gia-external-release`. Do not send exception lists containing personal data outside the
need-to-know group.
