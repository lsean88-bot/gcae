# Test ID registry - objective IDs and script IDs

One registry for every fraud test ID in use. Updated 2026-10-29.

## Contents
1. ID systems and rules
2. Registry: P (payroll)
3. Registry: V (vendor / accounts payable)
4. Registry: J (journal entries)
5. Registry: B (Benford)
6. Registry: F (financial statement) and OB
7. Script reason codes (FA-*)
8. Retired IDs: DA-xx and FRAUD-xxx
9. Gaps to build

## 1. ID systems and rules
| System | Meaning | Where defined |
|---|---|---|
| P01-P08, V01-V08, J01-J07, B01-B05, F01-F07 | Test-objective IDs: what the test is meant to find (35 tests). Granular; cited by the modus-operandi library | `test-library.md` |
| OB1-OB10 | Off-balance-sheet checklist items | `gia-fraud-fsf-window-dressing` references/window-dressing-protocols.md |
| FA-V1, FA-A1, FA-A2, FA-A3, FA-J1, FA-P1, FA-B1 | Script implementation IDs: what the code runs today | `scripts/` |
| Registry-defined new objectives (J08, P09, P10, V09) | Added here where a script detects something the library lacks | this file |
| O01-O05, C01-C05 | Overtime and claims objectives (payroll-analytics) | `gia-analytics:gia-payroll-analytics` references/test-registry.md |

Rules:
1. A report cites the objective ID and, where run, the script ID (for example "V02 via FA-A3").
2. Status values: COVERED (script implements the objective), PARTIAL (script covers part; difference stated), NO SCRIPT YET (objective exists, nothing executes it; the coverage statement must list it as NOT RUN).
3. Script parameters in force are the documented defaults. The library thresholds are review defaults; the values used are recorded in the test plan and the coverage block.

## 2. Registry: P (payroll)
| Objective | Name | Script ID / reason code | Status | Difference or gap |
|---|---|---|---|---|
| P01 | Headcount vs statutory submission | FA-P1 GH-HEADCOUNT-GAP | COVERED | Library "any variance"; script `--headcount-tolerance` default 0 |
| P02 | Duplicate bank account | FA-P1 GH-DUP-BANK | COVERED | |
| P03 | Duplicate ID number | none | NO SCRIPT YET | `gia-payroll-analytics` payroll_tests.py implements it (employee master with id_number) |
| P04 | Terminated but paid | FA-P1 GH-PAID-AFTER-TERM | COVERED | Script grace period `--grace-days` default 30 |
| P05 | Zero leave in 12 months | none | NO SCRIPT YET | Implemented in `gia-payroll-analytics` payroll_tests.py (leave register) |
| P06 | OT on leave days | none | NO SCRIPT YET | Implemented in `gia-payroll-analytics` payroll_tests.py |
| P07 | OT rate recalculation | none | NO SCRIPT YET | Implemented in `gia-payroll-analytics` payroll_tests.py (rate rule parameterised) |
| P08 | Salary to third-party account | FA-P1 GH-BANK-MISMATCH | PARTIAL | Compares payroll bank to master bank |
| P09 (new) | Payee not in HR master | FA-P1 GH-NOT-IN-MASTER | COVERED | Not in the original library |
| P10 (new) | Paid with no attendance record | FA-P1 GH-NO-ATTENDANCE | COVERED | Not in the original library; P05 is zero leave, a different test |

## 3. Registry: V (vendor / accounts payable)
| Objective | Name | Script ID / reason code | Status | Difference or gap |
|---|---|---|---|---|
| V01 | Vendor-employee address match | FA-V1 VE-ADDR | COVERED | Exact match only |
| V02 | Duplicate invoice | FA-A3 DUP-EXACT, DUP-NEAR | COVERED | Needs equal amount; credit notes not netted; near-duplicate extension |
| V03 | Threshold avoidance | FA-A1 JUST-BELOW-CLUSTER; FA-A2 SPLIT-AGGREGATE | PARTIAL | Library says plus or minus 10%; script is below-limit band only (`--band` default 0.10, min count 3); FA-A2 noisy |
| V04 | Round-number invoices | none | NO SCRIPT YET | |
| V05 | New vendor high-value | none | NO SCRIPT YET | Needs vendor creation date |
| V06 | Dormant vendor reactivation | none | NO SCRIPT YET | |
| V07 | Payee name mismatch | none | NO SCRIPT YET | Needs payee name on payment file |
| V08 | Vendor director vs employee name | none | NO SCRIPT YET | No director field in FA-V1 input |
| V09 (new) | Vendor shares bank, phone with employee; shared vendor bank | FA-V1 VE-BANK, VE-PHONE, VM-BANK-SHARED | COVERED | Not in the original library |

## 4. Registry: J (journal entries)
| Objective | Name | Script ID / reason code | Status | Difference or gap |
|---|---|---|---|---|
| J01 | Off-hours entries | FA-J1 JE-AFTERHOURS, JE-WEEKEND | COVERED | Documented default hours 08:00-19:00 (`--hours`) |
| J02 | Round-number JEs | FA-J1 JE-ROUND | PARTIAL | Script: multiple of 1,000 and at least 5,000 per entry; library: share of entries ending 000 |
| J03 | Unusual account pairs | none | NO SCRIPT YET | |
| J04 | Quick reversals | none | NO SCRIPT YET | |
| J05 | Senior-only entries | FA-J1 JE-NO-APPROVER, JE-SELF-APPROVED | PARTIAL | Script is role-generic, not CFO-specific |
| J06 | Period-end concentration | FA-J1 JE-PERIODEND | PARTIAL | Script: per entry, last 2 days, min 50,000 (`--period-end-days`, `--period-end-min`); library variant (b) share of volume not coded |
| J07 | Backdated entries | none | NO SCRIPT YET | Needs creation date |
| J08 (new) | Sequence gaps; multi-indicator entries | FA-J1 JE-SEQ-GAP, JE-MULTI | COVERED | Not in the original library |

## 5. Registry: B (Benford)
| Objective | Name | Script ID | Status | Difference or gap |
|---|---|---|---|---|
| B01 | Payroll net salary | FA-B1 `--column` | COVERED | Refuses N under 1,000, narrow range, assigned amounts |
| B02 | AP invoices | FA-B1 | COVERED | as above |
| B03 | Expense claims | FA-B1 | COVERED | as above |
| B04 | Journal entry amounts | FA-B1 | COVERED | as above |
| B05 | Cash receipts | FA-B1 | COVERED | as above |
| B06 (new) | Second-digit and first-two-digit tests | none | NO SCRIPT YET | First-digit only today |

Standard: MAD band primary, per-digit z-scores, chi-square supplementary. MAD table version is written to every output. Band edges 0.006 / 0.012 / 0.015: SECONDARY-ONLY (verified-on 2026-10-29; primary book not checked).

## 6. Registry: F (financial statement) and OB
| Objective | Name | Status |
|---|---|---|
| F01 | Period-end bank balance spike | NO SCRIPT YET |
| F02 | Revenue cut-off vs shipment | NO SCRIPT YET |
| F03 | Post-period credit-note search | NO SCRIPT YET |
| F04 | Receivable ageing migration | NO SCRIPT YET |
| F05 | Subsequent cash receipt match | NO SCRIPT YET |
| F06 | Inventory turnover trend | NO SCRIPT YET |
| F07 | Gross margin by month | NO SCRIPT YET |
| OB1-OB10 | Off-balance-sheet checklist | Manual checklist (not a script) |
| Scheme-map rows with no objective ID | Bid rigging; price benchmarking; scrap and metal-yield diversion; inventory theft and count manipulation | NO SCRIPT YET |

## 7. Script reason codes (FA-*)
| Script ID | Script | Reason codes |
|---|---|---|
| FA-V1 | vendor_employee_match.py | VE-BANK, VE-ADDR, VE-PHONE, VM-BANK-SHARED |
| FA-A1 | threshold_split.py | JUST-BELOW-CLUSTER |
| FA-A2 | threshold_split.py | SPLIT-AGGREGATE |
| FA-A3 | duplicate_payments.py | DUP-EXACT, DUP-NEAR |
| FA-J1 | je_testing.py | JE-ROUND, JE-WEEKEND, JE-AFTERHOURS, JE-PERIODEND, JE-NO-APPROVER, JE-SELF-APPROVED, JE-SEQ-GAP, JE-MULTI |
| FA-P1 | payroll_ghost.py | GH-HEADCOUNT-GAP, GH-DUP-BANK, GH-PAID-AFTER-TERM, GH-BANK-MISMATCH, GH-NOT-IN-MASTER, GH-NO-ATTENDANCE |
| FA-B1 | benford.py | BEN-DIGIT-DEV |

## 8. Retired IDs
- DA-01 to DA-25 (payroll audit battery) are retired. Mapping is in `gia-analytics:gia-payroll-analytics` references/test-registry.md.
- FRAUD-001 to FRAUD-030 (control-plane regression cases) were behaviour test cases, never detection tests, and were design-only. They are not carried.

## 9. Gaps to build (priority order)
1. V04-V07 (vendor tests) and V08 (director field).
2. J03, J04, J07 (journal tests).
3. F01-F07 and the three window-dressing protocols.
4. B06 second-digit and first-two-digit Benford.
5. Bid-rigging, scrap and yield, inventory tests.
6. Independent (non-author) validation of the FA scripts against a dataset built by someone else.
