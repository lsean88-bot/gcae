# Fraud test library - objective IDs (P / V / J / B / F)

Test-objective IDs. One objective may be served by one or more scripts (FA-*), or by none: see `test-id-registry.md` for the crosswalk and "NO SCRIPT YET" status. Thresholds below are default review parameters; set the values actually used in the test plan before running.

Count: 35 tests = P 8 + V 8 + J 7 + B 5 + F 7. The 10 off-balance-sheet checklist items (OB1-OB10) are in `gia-fraud:gia-fraud-fsf-window-dressing`.

### GROUP 1 — PAYROLL AND GHOST EMPLOYEE

| Test # | Test Name | Method | Exception Threshold |
|--------|-----------|--------|-------------------|
| P01 | Headcount vs ECR | Cross-match payroll register to EPF/SOCSO ECR headcount | Any variance > 0 |
| P02 | Duplicate bank account | Check all employee bank accounts for duplicates | Any duplicate |
| P03 | Duplicate ID number | Check all IC/PAN/Aadhaar for duplicates | Any duplicate |
| P04 | Terminated-but-active | Cross-match termination list to current payroll | Any match |
| P05 | Zero leave — 12 months | Flag employees with no leave taken in 12 months | Any zero |
| P06 | OT on leave days | Cross-match OT register with approved leave register | Any match |
| P07 | OT rate recalculation | Recalculate the OT rate using the divisor and multiplier in the entity policy / statutory register (not held here); compare to paid rate | >2% variance (parameter) |
| P08 | Salary to third-party account | Flag payments where payee account ≠ employee account | Any case |

### GROUP 2 — ACCOUNTS PAYABLE AND VENDOR

| Test # | Test Name | Method | Exception Threshold |
|--------|-----------|--------|-------------------|
| V01 | Vendor-employee address match | Compare vendor master address to employee master address | Any match |
| V02 | Duplicate invoice | Compare invoice number + vendor + amount for duplicates | Any duplicate |
| V03 | Threshold avoidance | Flag invoices just below approval threshold (±10%) | Any concentration |
| V04 | Round-number invoices | Flag amounts ending in 000, 500, or exactly round | >5% of invoices |
| V05 | New vendor high-value | Flag vendors with first invoice above the engagement value threshold within 30 days | Any case |
| V06 | Dormant vendor reactivation | Flag vendors with no activity >12 months suddenly reactivated | Any case |
| V07 | Payee name mismatch | Flag payments where cheque/transfer payee ≠ vendor name | Any case |
| V08 | Vendor-employee name match | Compare vendor director names to employee names | Any match |

### GROUP 3 — JOURNAL ENTRY TESTING

| Test # | Test Name | Method | Exception Threshold |
|--------|-----------|--------|-------------------|
| J01 | Off-hours entries | Flag JEs posted outside business hours; default window = script default 08:00-19:00 (`--hours`), weekends flagged separately | Any case |
| J02 | Round-number JEs | Flag JEs with amounts ending in 000 or 0000 | >10% concentration |
| J03 | Unusual account pairs | Flag account combinations not in standard chart | Any non-standard |
| J04 | Quick reversals | Flag JEs reversed within 3 business days | Any case |
| J05 | Senior-only entries | Flag JEs posted by CFO/Finance Director without reviewer | Any case |
| J06 | Period-end concentration | Two variants: (a) per-entry, last N days (script default N=2, min value 50,000) ; (b) volume share in last 3 business days | (a) any case; (b) >20% volume |
| J07 | Backdated entries | Flag entries where post date > creation date by > 3 days | Any case |

### GROUP 4 — BENFORD'S LAW

| Test # | Test Name | Dataset | Expected Output |
|--------|-----------|---------|----------------|
| B01 | Benford — payroll net salary | All net salary amounts | First-digit frequency vs expected |
| B02 | Benford — AP invoices | All AP invoice amounts | Deviation chart + flagged digits |
| B03 | Benford — expense claims | All claim amounts | Deviation chart + flagged records |
| B04 | Benford — journal entries | All JE debit amounts | Deviation chart + flagged entries |
| B05 | Benford — cash receipts | All cash receipt amounts | Deviation chart + flagged items |

Standard (`scripts/benford.py`): Nigrini MAD band is the primary measure, with per-digit z-scores; chi-square is supplementary or for small N and is not an escalation trigger. Output records the MAD table version. Not suitable for fixed-price, capped or assigned amounts, or populations under the script minimum (refused, not run).

### GROUP 5 — FINANCIAL STATEMENT FRAUD

| Test # | Test Name | Method | Exception Threshold |
|--------|-----------|--------|-------------------|
| F01 | Period-end bank balance spike | Compare Dec/Mar/Jun/Sep bank balance to prior 3 months average | >25% spike |
| F02 | Cut-off test — revenue | Match revenue recorded in last 5 days to goods shipped date | Any pre-shipment |
| F03 | Post-period credit note search | Flag credit notes in 30 days after period-end | >5% of period-end revenue |
| F04 | A/R ageing migration | Check if debtors are being reclassified from old to current | Any reclassification |
| F05 | Subsequent cash receipt match | Match period-end debtors to subsequent receipts | >90 day uncollected at 60 days |
| F06 | Inventory turnover trend | Compare turnover ratio to prior 3 years | >20% slowdown |
| F07 | Gross margin by month | Chart gross margin: unusual spikes at period-end | >5% spike vs annual average |

