# Adversarial review (run on every HIGH and MEDIUM exception)

Purpose: try to break the indicator before a human spends time on it. Run as a separate pass with
this checklist only; do not reuse the reasoning that produced the exception. Prefer a different
subagent context. Where possible, check against the deterministic output and the raw extract rather
than against the first pass's narrative (a model grading its own probes is circular).

For each exception answer, with evidence from the extract:
1. **What exactly fired?** Quote the reason code and fields. Re-derive it by hand from two raw rows.
2. **Is the data right?** Extract date, duplicates in the extract, truncated or mis-keyed fields,
   currency/units, test-environment records.
3. **Innocent explanations.** Go through the listed explanations and any others that fit the business
   (seasonality, contracts, policy, system behaviour). State which are ruled out, which remain, and
   what evidence would settle each.
4. **What would disprove it?** Name the single most informative check (document, confirmation, log).
5. **Is it independent?** Do several indicators come from the same underlying fact (one data
   error producing three flags)? Count independent facts, not flags.
6. **Base rate.** How often does this indicator fire on this population for benign reasons (use the
   cleared-exception history if available)?
7. **Overreach check.** Does any sentence in the write-up say more than the facts support?

Output per exception: `SURVIVES / WEAKENED / REFUTED`, reasons, and the confirming procedure.
Refuted or weakened items go back to the human reviewer; they are not deleted.
