# Scheme → test map

Use to turn a hypothesis into a test plan. "Script" names what exists today. "NO SCRIPT YET" means
the scheme is on the map but cannot be tested by this skill; say so in the coverage statement.
Red-flag and test ideas for procurement follow published practice (vendor/employee master matching,
threshold and split analysis, duplicate-payment tests); manufacturing entries are this author's design
and have not been validated against real cases.

| Scheme (ACFE branch) | How it is typically concealed | Indicators | Script | Data needed | Innocent explanations to rule out | Confirming procedure (outside the script) |
|---|---|---|---|---|---|---|
| Fictitious / shell vendor (Corruption or Asset misappropriation: billing) | Looks like a normal vendor; approvals by one person | Bank/address/phone matches employee; vendor not in approved list; no deliveries | FA-V1 | vendor + employee masters | reimbursement payee; shared building; data error | independent vendor existence check, onboarding file, bank confirmation, goods-receipt evidence |
| Conflict of interest / related vendor | Relative's details differ from employee's | single-source awards; above-market price; vendor recently created | FA-V1 (partial); price benchmarking NO SCRIPT YET | masters + award history | disclosed related party; sole-source justified | COI declarations, tender file, market price comparison |
| Kickback / bid rigging | Quotes arranged; losing bids fabricated | same winner repeatedly; bid patterns; price just under competitors | NO SCRIPT YET | tender and bid data | specialised supplier; framework contract | tender documentation review, bidder address/phone overlap |
| Split purchasing to avoid approval | Several invoices just under limit | clusters under threshold; same approver | FA-A1, FA-A2 | payments, approver | instalments; catalogue pricing; framework orders | purchase requisitions, delivery notes, requester interviews (after counsel) |
| Duplicate / double payment | Re-keyed invoice number, altered format | same vendor+amount; similar invoice numbers | FA-A3 | payments (+ credit notes) | reversals not in extract; recurring same-value orders | bank statement, vendor statement reconciliation |
| Ghost employee | Payee added to payroll; terminated staff kept | payee not in master; shared bank; paid after termination; zero attendance; payroll count above statutory count | FA-P1 | HR master, payroll, attendance, statutory headcount | final settlement; joint accounts; late data entry | unannounced payout/ID verification, HR file check |
| Payroll bank diversion | Bank details changed shortly before pay | master vs payroll bank mismatch | FA-P1 (GH-BANK-MISMATCH) | master + payroll + change log | approved change request | change request form, call-back to employee |
| Management override via journals | Round, late, unapproved, self-approved entries | FA-J1 indicators in combination | FA-J1 | journal with user, approver, time | month-end close practice; fixed rent | support documents, approver confirmation |
| Revenue pull-forward / cash parking / payable suppression (financial statement) | Cut-off manipulation | period-end spikes, credit notes after period | NO SCRIPT YET (FA-J1 period-end only) | sub-ledgers, cut-off data | genuine year-end deals | cut-off testing, delivery evidence, post-period credit notes |
| Scrap / metal-yield diversion (manufacturing) | Yield variance explained as scrap | yield vs standard; scrap sales vs weighbridge; MTC vs receipts | NO SCRIPT YET | BOM, weighbridge, scrap sales, MTC | alloy mix, process loss, re-melt | physical count, weighbridge audit, material balance by lot |
| Inventory theft / count manipulation | Adjustments at count | large adjustments by few users; SLOB write-offs | NO SCRIPT YET | stock adjustment log | genuine damage | recount, CCTV/gate logs (with counsel) |

## Notes
- Executive or owner-level schemes cause larger losses in published benchmarks, and the tests above
  mostly sit at process level. Raise override and tone-at-the-top hypotheses separately.
- Combine indicators: a single indicator is weak; several independent indicators on one entity
  raise review priority (never conclusions).
