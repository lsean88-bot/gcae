# HubSpot-based fraud case workflow (design; NOT tested in a live HubSpot account)

## Contents
- 1. Position
- 2. What was checked in HubSpot documentation (2026-10-29)
- 3. Object choice
- 4. Pipeline stages and gates
- 5. Properties (create as ticket/custom-object properties; no personal data)
- 6. Roles and permissions (principle: least privilege, need-to-know)
- 7. Controls and prohibitions
- 8. Using Claude with this workflow
- 9. Setup checklist and acceptance tests
- 10. Open items


Status: design specification prepared 2026-10-29. Nothing here has been provisioned or tested in
HubSpot. Items marked **VERIFY** must be confirmed in your HubSpot account and with Legal/IT before
live use.

## 1. Position
HubSpot is a CRM built for sales, marketing and service. Use it only as the **workflow and tracking
layer** for fraud-indicator cases. It is not:
- the **evidence store** (use a restricted repository with hashing, access logs and retention rules);
- the **subject register** (names and record identifiers stay in the secured register file);
- a place for **allegations or narrative** (notes and comments are the main leakage path).

## 2. What was checked in HubSpot documentation (2026-10-29)
| Claim | Source type | Status |
|---|---|---|
| Property-level (field-level) view/edit permissions exist in Settings > Users & Teams > Permissions | HubSpot partner/knowledge articles | Documented; confirm availability on your tier — VERIFY |
| Notes/comments have no field-level limits, so text written there is visible to anyone who can see the record | Third-party guide | Treat as a design risk |
| Permissions are set separately per object | Third-party guide | Plan per-object |
| Ticket pipelines can be created on Starter/Pro/Enterprise; custom-object pipelines are Enterprise-only; up to 100 stages | HubSpot developer docs | Documented |
| Sensitive-data properties are Enterprise-only; permitted data types are governed by HubSpot's Sensitive Data terms | HubSpot developer docs | Whether fraud-case content qualifies is NOT established — VERIFY with HubSpot/Legal |
| Audit logs exist (including a pipeline audit-log API) | HubSpot developer docs, guides | Whether **record views** are logged is NOT established — VERIFY |
| A HubSpot connector exists in the Claude connector directory (not installed in this conversation) | Claude registry | Capabilities beyond read tools not confirmed — VERIFY before connecting |

## 3. Object choice
- **Default: Tickets** in a dedicated pipeline ("Fraud Indicator Cases"). Works on lower tiers.
- **Alternative: a custom object** with its own pipeline (Enterprise) for cleaner separation from
  service tickets. Preferable if available.
- Do **not** associate cases with Contacts, Companies or Deals. Associations pull records into
  sales/marketing views, lists and automations.

## 4. Pipeline stages and gates
| # | Stage | Entry gate (record before moving) | Owner |
|---|---|---|---|
| 1 | Intake & triage | exception promoted by CAE delegate; case ref created; Phase-1 allegation assessment due in 3 days where a tip exists | Case Lead |
| 2 | Preliminary assessment | adversarial review result attached (reference only) | Case Lead |
| 3 | Legal engaged & evidence preserved | counsel engaged; evidence-preservation notice issued; evidence hash register updated (reference) | CAE + Legal |
| 4 | Fieldwork & analytics | scope approved by CAE; data requests logged | Investigator |
| 5 | Interviews | **primary evidence secured**; counsel has reviewed the plan | CAE + Legal |
| 6 | Draft conclusion | `check_report.py` PASS; counsel review | CAE |
| 7 | Reported to Audit Committee | AC paper issued | CAE |
| 8 | Remediation tracking | management action plan with SMART actions | Case Lead |
| 9 | Closed — Substantiated / Partially / Unsubstantiated / Referred | closure memo filed in restricted repository | CAE |

Stage 3 before 5 reflects the existing protocol rule that interviews follow securing primary
evidence and counsel involvement. Stage durations beyond the 3-day triage and the 30-day evidence
window in the fraud skills are set by the CAE.

## 5. Properties (create as ticket/custom-object properties; no personal data)
`fa_case_ref` (text, unique) · `fa_test_id` · `fa_reason_code` · `fa_review_priority` (LOW/MEDIUM/HIGH
— a review-priority hint, not a severity of wrongdoing) · `fa_population_tested` (number) ·
`fa_script_version` · `fa_run_utc` · `fa_innocent_explanations_open` (text) · `fa_evidence_hash_ref`
(reference id into the evidence repository, not a file) · `fa_adversarial_result` (SURVIVES/WEAKENED/
REFUTED) · `fa_counsel_engaged` (date) · `fa_legal_hold_issued` (date) · `fa_ac_reported` (date) ·
`fa_closure_outcome`.
Machine-readable list: `hubspot-case-schema.json`.

## 6. Roles and permissions (principle: least privilege, need-to-know)
| Role | Pipeline/properties | Notes |
|---|---|---|
| CAE | full | owns stage gates |
| Case Lead / Investigator | view+edit `fa_` properties in assigned cases | no admin rights |
| Legal counsel | view; edit legal properties | privilege: do not store privileged advice in HubSpot |
| AC secretary | view stage and outcome only | |
| Everyone else (sales, marketing, service) | **no access** to the pipeline or `fa_` properties | test by logging in as such a user |
- Minimise Super Admins; list them in the case governance record.
- Disable ticket creation by email/forms for this pipeline; no external submissions.

## 7. Controls and prohibitions
1. **No notes, comments, emails or attachments on case records.** Case narrative lives in the
   restricted repository. Notes have no field-level protection.
2. **No marketing or sales automation** may touch this pipeline or its properties. Workflows are
   limited to internal notifications to named case staff, containing the case ref only.
3. **Redaction by design.** `to_hubspot_import.py` exports only case ref, codes, counts and open
   explanations. Record identifiers stay in `SECURED_register_DO_NOT_UPLOAD.csv`, keyed by an
   HMAC reference whose salt (`FA_CASE_SALT`) is kept outside HubSpot.
4. **Exports and apps.** Restrict data export permission; review connected apps and their scopes;
   remove any app that can read tickets and is not needed.
5. **Audit-log review** monthly by someone outside the case team; record the review.
6. **Retention and deletion** follow the group policy and legal-hold rules, not HubSpot defaults. VERIFY.
7. **Data protection.** Confirm hosting region, DPA and cross-border transfer position for the
   jurisdictions involved (Malaysia, India, Mexico) with Legal. Not established here.

## 8. Using Claude with this workflow
- The redacted design means Claude needs no personal data to help with case administration.
- If you connect the HubSpot connector: connect as a **least-privilege user**, not an admin; prefer
  read-only; Claude can then see what that user can see. Never connect with an account that can
  see unredacted material. Do not let Claude write stage changes past gates 3 and 5.
- Claude may draft stage-gate checklists and status summaries from the redacted fields; it must not
  infer or add identities.

## 9. Setup checklist and acceptance tests
1. Confirm tier and available features (sections 2, 3). Record the result.
2. Create the pipeline, stages and properties (schema file). Set required-property rules at gates.
3. Create the roles; set property permissions; remove all other access.
4. Disable forms/email-to-ticket for the pipeline; confirm no workflows or sequences reference it.
5. Import a **synthetic** redacted CSV (from the evals) and run these tests:
   - a sales user cannot see the pipeline, any ticket, or any `fa_` property;
   - a user without export rights cannot export;
   - no marketing list can include these records;
   - audit log shows the import and a permission change.
6. Legal sign-off on data-protection and retention. Only then use live exceptions.

## 10. Open items
Tier and feature availability; sensitive-data terms; view-logging; retention; hosting region and
transfers; whether the HubSpot connector supports the writes you want; who owns monthly audit-log
review. Importing via CSV maps columns manually in HubSpot's import tool; the CSV headers here are
friendly names, not verified internal property names.
