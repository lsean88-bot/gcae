---
name: gia-fraud-investigation
description: "Defensible fraud, misconduct or whistleblower investigation: triage, evidence preservation, interviews, fraud-ladder classification, investigation report. Use when a tip, red flag, analytics exception or referral needs investigating, or for a plan, preservation notice or interview plan. Do NOT use for data tests (use gia-fraud:gia-fraud-analytics)."
---

# Fraud Investigation

Method for investigating suspected fraud or misconduct. Rules cited by number live in `gia-core:iron-rules`; evidence levels R1-R5 and the strict R3 test are defined there. This skill never restates them.

## 1. Core principles

| Principle | Application |
|---|---|
| Independence | No investigator has a conflict of interest with the subject or the subject's reporting line |
| Procedural fairness | The subject's rights are preserved throughout: purpose of interview explained, right to representation, opportunity to respond before any adverse conclusion |
| Evidence integrity | Chain of custody from the moment of collection; originals never altered |
| Fact vs inference | Confirmed facts, reasonable inferences and unresolved questions are separated in every document (Rule 12, Rule 37) |
| Legal privilege | Legal counsel engaged early; privilege markings applied from the first working paper |
| Confidentiality (need-to-know) | Access limited to people who need it to act; investigation material kept in a restricted repository, not shared drives |
| Professional scepticism | No conclusion before the evidence is secured and the innocent explanation has been tested; pressure from management never alters a finding (Rule 13) |

## 2. Operating loop (PLAN / VERIFY / EXECUTE / CHECK / LOG)

| Step | Requirement |
|---|---|
| PLAN | State the hypothesis (scheme), scope, and target evidence list before any step |
| VERIFY | Confirm evidence is preserved before approaching any witness or subject |
| EXECUTE | Gather, document, analyse; cite every source with its R-level; fact is not inference is not allegation |
| CHECK | "Would this survive legal challenge?" If not, redo; counsel reviews before any conclusion |
| LOG | Record the scheme, the control gap, the missed red flag and the detection test to add (7-question loop in section 9) via `gia-core:self-learning` |

## 3. Fraud ladder (vocabulary is mandatory)

weakness > indicator > suspicion > allegation > corroborated > substantiated

| Level | Meaning | Allowed wording |
|---|---|---|
| Control weakness | A gap that could allow fraud; no event implied | "control gap" |
| Indicator | A data pattern or red flag consistent with a scheme | "exception", "indicator", "consistent with" |
| Suspicion | Several independent indicators on one process or entity | "warrants inquiry" |
| Allegation | A specific claim by a named source, not yet tested | "alleged by", "reported" |
| Corroborated | Allegation supported by at least one independent R1-R3 source | "evidence is consistent with" |
| Substantiated | Conclusion reached on the standard of proof (open item, section 4) after counsel review | "substantiated" |

Never state or infer motive or intent (Rule 25, Rule 36). An analytics flag, a witness statement or a relationship alone never moves an item above indicator (Rule 17). Containment is not a conclusion.

## 4. Standard of proof - OPEN DEPENDENCY (Legal)

The standard required to classify a finding as substantiated (for disciplinary, civil or referral purposes) has not been decided and differs by jurisdiction and purpose. Owner: Group Legal. Until decided:
- use the ladder vocabulary above and do not use "beyond reasonable doubt", "balance of probabilities" or similar court terms in any deliverable;
- mark every "substantiated" classification "pending counsel review of standard of proof";
- record the dependency in the engagement's open-items list.

## 5. Investigation architecture (10 steps)

PRESERVE > CLASSIFY > HYPOTHESISE > MAP > RECONSTRUCT > TEST > CORROBORATE > QUANTIFY > CONTAIN > CONCLUDE

- **Allegation discipline:** keep weakness, indicator, suspicion, allegation, corroborated and substantiated apart. No anomaly, flag, management assertion, witness statement or relationship becomes a conclusion without corroboration.
- **Relationship and beneficial ownership:** test legal and beneficial ownership, control, nominee arrangements, family relationships, directors, shared addresses, phones, emails, bank accounts, accountants and financing, where lawfully available.
- **Commercial forensics:** onboarding and KYC, RFQ and PO history, pricing, approvals, delivery, quality, duplicate invoices and payments, split transactions, timing, round values, bank changes, credit notes. Run through `gia-fraud:gia-fraud-analytics`.
- **Retrospective documents:** where a document appears created after the event, test metadata, version history, system audit logs, approval chronology, sequence and independent corroboration. A document's existence does not establish when or why it was created.
- **Witness corroboration:** classify statements as first-hand, second-hand or inference; record contradictions; test material statements against independent records; a possible bias does not by itself discount evidence.
- **Population completeness:** do not describe total exposure from a sample unless completeness and selection method are established; reconcile extracts to the ledger, master or bank record.
- **Financial-impact ladder:** report separately observed variance > potential exposure > quantified exposure > corroborated loss > confirmed recoverable or irrecoverable loss. Conflict can exist without loss; loss can exist without proven conflict.
- **Containment vs conclusion:** recusal, segregation, dual approval, access restriction, independent review, enhanced monitoring, controlled reassignment. Do not recommend suspension or termination solely from an unverified allegation.
- **Conclusion content:** evidence basis, corroboration status, limitations, alternative explanations considered, quantified exposure where supportable, unresolved questions, decision owner.

## 6. Six-phase protocol

### Phase 1 - Allegation assessment (days 1-3) [PLAN]
- [ ] Log receipt: date, channel, source, summary, classification rationale.
- [ ] Assess credibility: specific, corroborated, consistent with other data.
- [ ] Classify: fraud, misconduct, ethics violation, policy breach, or unfounded.
- [ ] Estimate materiality: quantifiable exposure, reputational risk, regulatory trigger.
- [ ] Notify Group Legal and HR lead; notify the CEO or AC Chair if material. If the CEO, CFO or a director is implicated, go directly to the AC Chair.
- [ ] Appoint a lead investigator with no conflict.
- [ ] Issue the Evidence Preservation Notice (contents and template: `references/preservation-notice.md`) to IT, Finance and HR. Never skip this step.

### Phase 2 - Evidence gathering (days 4-30) [VERIFY then EXECUTE]
- Documents: contracts, POs, invoices, payment vouchers, bank statements, HR and payroll records, attendance and leave, ERP reports, journal logs, approval trails, email archives (with counsel), asset registers, delivery notes, GRNs.
- Grade every item R1-R5 (`gia-core:iron-rules`). Witness statements are leads, not evidence.
- Run analytics in parallel through `gia-fraud:gia-fraud-analytics` (duplicate payments, vendor-employee match, journal tests, threshold clusters, payroll cross-checks, Benford screen). Outputs are indicators only.
- Log each item in the evidence log (`references/investigation-templates.md`): source, date, obtained by, hash, custodian.

### Phase 3 - Interviews [EXECUTE]
Sequence (fixed): 1) neutral corroborating witnesses; 2) peripheral witnesses; 3) potential co-participants after primary evidence is secured; 4) the subject last, only after all primary evidence is secured and counsel has been consulted.
Rules:
- Two investigators present; one leads, one records verbatim.
- State the purpose and the right to seek representation.
- Open questions first; documents introduced only after open questions are exhausted; never reveal the full evidence set in the first interview.
- Record date, time, place, attendees, key statements verbatim, and observed conduct without interpretation.
- Never promise confidentiality that cannot be guaranteed. Never promise an outcome or immunity.

### Phase 4 - Control-condition analysis (fraud triangle, evidence-based)
Use the triangle to structure the control analysis, not to characterise a person.

| Dimension | Question | Evidence source | In the report |
|---|---|---|---|
| Opportunity | What control gap existed; who had access; structural or deliberate-looking | Control testing, ERP access logs, approval matrix | Stated as a control condition |
| Pressure and rationalisation | Working questions only | HR file, interviews | Investigator's privileged notes only. Never stated as a conclusion about a person (Rule 25, Rule 36) |

Finding classification: use the ladder in section 3. Partial or unsubstantiated outcomes are reported as "corroborated in part" or "not corroborated"; no adverse finding follows from a lack of corroboration.

### Phase 5 - Investigation report
Confidential and privilege-marked. Parties are described by role, not name (Rule 36). Each material statement carries its basis class (Rule 37). A population of 15 or fewer items is named in full; larger populations are summarised with the complete list in an appendix (Rule 33).

| Section | Content |
|---|---|
| 1 Executive summary | Allegation, scope, conclusion on the ladder, exposure on the impact ladder, recommended actions |
| 2 Background and timeline | Context, parties by role, event timeline table |
| 3 Scope and method | Evidence reviewed (R-level), interviews held, analytics applied, limitations |
| 4 Findings of fact | Numbered facts, each tied to an evidence reference; confirmed facts, inferences and unresolved questions kept separate |
| 5 Conclusion | Ladder classification (pending counsel review of standard of proof), quantified exposure, roles implicated |
| 6 Control conditions | COSO component that failed (map in `gia-fraud:gia-fraud-risk-governance`) |
| 7 Recommendations | Immediate (HR and Legal referral, recovery, regulatory notification decision) and systemic (control redesign, policy, training, monitoring); SMART with owner and date |
| 8 Appendices | A evidence index; B interview log; C analytics summary and exception log; D event timeline; E statement basis table |

### Phase 6 - Post-investigation actions
- [ ] Refer to HR and Legal for disciplinary or civil action (CAE recommends; HR, Legal and the Board decide).
- [ ] Decide on regulator or law-enforcement notification: prepare the package and recommendation; a human decides and sends.
- [ ] Issue a remediation plan with SMART actions and named owners.
- [ ] Update the fraud risk assessment and the red flag library.
- [ ] Redacted report to the AC or Board where proceedings are pending.
- [ ] Close the whistleblower case with outcome notification per policy.
- [ ] Complete the 7-question loop (section 9) and log it.

## 7. Escalation and human gate

- Prepare evidence packages and recommendations; never notify management, the Board, regulators or law enforcement, and never describe a matter as reported. A human decides and executes.
- If the CEO, CFO, a director, or the CAE's own reporting line is implicated, route directly to the AC Chair.
- Do not tip off the subject. Preserve evidence first.
- Active investigation material is held apart from the entity's routine engagement files; do not cross-reference it into other contexts until conclusions are confirmed.

## 8. Tone guardrails

Do: be factual, neutral, procedurally fair and defensible; separate fact, inference and allegation; protect the rights of subject, witnesses and complainant; engage counsel before the subject interview; apply the CHECK step before any conclusion.
Do not: call anyone guilty; promise outcomes or immunity; let management pressure shape findings; interview the subject before primary evidence is secured; cite R5 evidence as a basis for any finding; skip the preservation notice; state motive.

## 9. Post-case learning loop (7 questions)

A scheme used (ACFE tree branch) | B control that failed and root cause (COSO component) | C red flag that existed and was missed | D pattern rule to add (`gia-core:self-learning`) | E analytics test that would have detected it earlier (add to `gia-analytics:gia-continuous-assurance`) | F law or regulation triggered (statutory register, `[UNVERIFIED]` until validated) | G SMART remediation action with owner and date.

## References (load when needed)

| File | Load when |
|---|---|
| `references/preservation-notice.md` | Issuing the Evidence Preservation Notice |
| `references/investigation-templates.md` | Evidence log, interview guide, allegation triage form, report template |
| `references/modus-operandi-library.md` | Mapping a suspected scheme to indicators and test IDs |
| `references/red-flags-master.md` | Red flags by domain (indicators only) |
| `references/fraud-tree.md` | ACFE tree taxonomy for classifying a scheme |

## Related

`gia-fraud:gia-fraud-analytics` (run the tests) | `gia-fraud:gia-fraud-risk-governance` (FRA, ABAC, whistleblower standards) | `gia-fraud:gia-fraud-fsf-window-dressing` | `gia-fraud:gia-fraud-entity-watch` (case register discipline) | `gia-report-qa` (report QA and Board wording) | `gia-core:iron-rules`.
