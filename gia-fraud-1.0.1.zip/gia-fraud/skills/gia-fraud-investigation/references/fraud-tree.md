# ACFE Fraud Tree - taxonomy (classification only)

Use to classify the scheme a hypothesis falls under. Prevalence and loss statistics are NOT held here: see `../../gia-fraud-risk-governance/references/acfe-benchmarks.md` (single dated source, [UNVERIFIED]).

### 3.1 ACFE Fraud Tree — Full Taxonomy

**Category 1: Asset Misappropriation**

```
CASH SCHEMES
├── Skimming (revenue before recording)
│   ├── Sales skimming — unrecorded cash sales
│   ├── Receivables lapping — use of customer A payment to cover A/R for customer B
│   └── Unrecorded refunds / voids
├── Cash Larceny (after recording)
│   ├── Petty cash theft
│   ├── Deposit theft
│   └── Till theft
└── Fraudulent Disbursements
    ├── Billing schemes — fictitious vendor, personal purchases
    ├── Payroll fraud — ghost employees, falsified hours, unauthorised raises
    ├── Expense reimbursement — fictitious, inflated, duplicate, personal
    ├── Cheque tampering — forged, altered payee, forged endorsement
    └── Register disbursements — false voids, false refunds

NON-CASH SCHEMES
├── Misuse of company assets (vehicles, equipment, inventory)
├── Inventory theft / stock diversion
└── Intellectual property theft
```

**Category 2: Corruption**

```
BRIBERY
├── Invoice kickbacks — vendor pays back a % to procurement officer
├── Bid rigging — pre-determined award; false competitive tender
├── Facilitation payments — payments to expedite official acts
└── Gifts / entertainment exceeding policy limits

CONFLICTS OF INTEREST
├── Undisclosed vendor relationship (employee owns / has family interest in vendor)
├── Undisclosed customer relationship
└── Usurpation of business opportunity

ECONOMIC EXTORTION
└── Demand for payment to award, retain, or expedite business

ILLEGAL GRATUITIES
└── Payments made after the fact in recognition of favourable action (post-award)
```

**Category 3: Financial Statement Fraud**

```
REVENUE MANIPULATION
├── Premature recognition (bill-and-hold, channel stuffing)
├── Fictitious revenues (phantom sales, round-trip transactions)
├── Side letters negating sale conditions
└── Reversals after period close

EXPENSE / LIABILITY MANIPULATION
├── Capitalise expenses (record as assets to inflate earnings)
├── Conceal liabilities (off-balance sheet vehicles, contingent liabilities)
├── Reserve manipulation (overstate → release to inflate earnings)
└── Period-end cookie jar reserves

ASSET OVERSTATEMENT
├── Inventory overstatement (fictitious stock, mis-counting)
├── Receivables inflation (fictitious debtors, inflated ageing)
└── Asset valuation fraud (overvalued intangibles, goodwill inflation)

WINDOW DRESSING
├── Period-end cash inflation (park cash, draw back after period)
├── Short-term payable reduction (pay down, draw back after period)
├── Round-trip intercompany transactions to inflate revenue
└── Accelerate year-end receipts; defer expenditure to next period
```
