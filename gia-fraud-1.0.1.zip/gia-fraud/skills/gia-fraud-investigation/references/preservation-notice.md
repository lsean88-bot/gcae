# Evidence Preservation Notice - contents and template

Issue in Phase 1, before any witness or subject is approached. Issued by the lead investigator with Group Legal; copy to the CAE.

## Mandatory contents
1. Specific systems and data sets to be preserved (name the ERP modules, mail archives, shared folders, bank portals, HR files, access logs).
2. Instruction that no named record may be deleted, modified or transferred.
3. Named custodians in IT, Finance and HR who confirm receipt in writing.
4. Preservation period: until written release by Group Legal (minimum period per the retention policy and the statutory register for the jurisdiction [UNVERIFIED]).
5. Statement that breach of the notice may itself be a disciplinary matter and may have legal consequences (counsel to settle wording).

## Template
```
EVIDENCE PRESERVATION NOTICE - CONFIDENTIAL / PRIVILEGED
Matter reference: [single case reference]      Date: [ ]
To (custodians by role): IT [ ] | Finance [ ] | HR [ ]
Systems and records to preserve: [list]
Date range: [ ]
Instruction: do not delete, alter, overwrite, archive off-system or transfer the records above. Suspend auto-deletion and log rotation.
Access logs: preserve from [date] to [date].
Acknowledgement: reply to [lead investigator role] within [ ] hours confirming custodian and steps taken.
Release: only by written notice from Group Legal.
Issued by: [lead investigator role]    Approved by: [CAE role / Group Legal role]
```

## Confirmation checklist (VERIFY step)
- [ ] All three custodians have acknowledged in writing
- [ ] Hash or snapshot taken for system extracts (algorithm recorded in the evidence log)
- [ ] Subject's access to the listed systems reviewed with counsel (restriction is containment, not a conclusion)
