# Investigation Templates — CFE Standard

## Contents
- TEMPLATE 1 — ALLEGATION TRIAGE FORM
- TEMPLATE 2 — EVIDENCE LOG (CHAIN OF CUSTODY)
- TEMPLATE 3 — INTERVIEW GUIDE
- TEMPLATE 4 — FRAUD TRIANGLE ANALYSIS
- TEMPLATE 5 — INVESTIGATION CONCLUSION MEMORANDUM

# Group CAE Fraud Risk Governance v2.0 | MKTron GIA
# ──────────────────────────────────────────────────

## TEMPLATE 1 — ALLEGATION TRIAGE FORM

```
ALLEGATION TRIAGE RECORD
Reference: INV-{ENTITY}-{YEAR}-{SEQ}
Date Received: ___________
Channel: [ ] Whistleblower Hotline [ ] Email [ ] Anonymous Note [ ] Management Referral
          [ ] Internal Audit Analytics [ ] External Report [ ] Other: __________

ALLEGATION SUMMARY
Brief description: ________________________________________________
Entity / Location: _______________
Persons implicated (role only at this stage): ______________________
Period of alleged conduct: _______________
Estimated financial exposure: _______________

CLASSIFICATION
[ ] Fraud (ACFE Category): ______________________
[ ] Misconduct / Ethics Violation
[ ] Policy Breach
[ ] Unsubstantiated / Unfounded (document reason)
[ ] Requires further information before classification

CREDIBILITY ASSESSMENT
Specificity: [ ] High (names, dates, amounts) [ ] Medium [ ] Low (vague / anonymous)
Corroboration: [ ] Corroborated by other evidence [ ] Standalone allegation
Consistency: [ ] Consistent with known data patterns [ ] Inconsistent
Overall credibility: [ ] Sufficient to proceed [ ] Monitor and reassess [ ] Close

NOTIFICATIONS REQUIRED
[ ] Group Legal — Date notified: ___________
[ ] CHRO — Date notified: ___________
[ ] CEO — Date notified: ___________
[ ] AC Chair — Date notified: ___________
[ ] MACC / Regulator — Date notified: ___________ (if legally required)

EVIDENCE PRESERVATION NOTICE ISSUED
[ ] IT (email / ERP / access logs) — Date: ___________
[ ] Finance (payment records / bank statements) — Date: ___________
[ ] HR (personnel file) — Date: ___________

INVESTIGATION ASSIGNMENT
Lead Investigator: _______________
Confirmed: No COI with subject: [ ] Yes [ ] No (reassign)
Estimated scope: _______________
Target completion: _______________

CAE Sign-off: _______________  Date: _______________
```

---

## TEMPLATE 2 — EVIDENCE LOG (CHAIN OF CUSTODY)

```
INVESTIGATION EVIDENCE LOG
Investigation Reference: INV-{ENTITY}-{YEAR}-{SEQ}

| Ref | Description | Source | Date Obtained | Obtained By | Format | Evidence Level (R1-R5) | Custodian | Notes |
|-----|------------|--------|--------------|------------|--------|---------|----------|-------|
| E001 | | | | | | | | |
| E002 | | | | | | | | |
| E003 | | | | | | | | |

EVIDENCE LEVEL: R1-R5 per `gia-core:iron-rules` (Evidence Hierarchy; strict R3 test applies).
Record the level for every item. R5 (assertion/verbal) is never cited as a basis for a finding;
a witness statement is a lead to corroborate through an independent channel, not evidence of the fact.

CHAIN OF CUSTODY RULES:
1. Every item logged immediately upon receipt
2. No item removed from evidence log without CAE written authority
3. Digital evidence: SHA-256 hash computed and recorded at collection
4. Physical evidence: sealed in evidence envelope with signature and date
5. Evidence must not be shared outside investigation team without CAE / Legal approval
```

---

## TEMPLATE 3 — INTERVIEW GUIDE

```
INTERVIEW RECORD
Investigation Reference: INV-{ENTITY}-{YEAR}-{SEQ}
Interviewee Role: _______________  (Do NOT record name in draft — use role only)
Date: ___________  Start: _______  End: _______
Location: _______________
Investigators Present:
  Lead: _______________
  Documenter: _______________

OPENING STATEMENT (read verbatim):
"This is a formal interview as part of an internal investigation. The purpose is to gather
information about [general topic — do NOT reveal full allegation]. You are not required to
participate but your cooperation is appreciated. You have the right to seek legal advice before
or during this interview. This interview will be documented. Do you have any questions before
we begin?"

Subject response: _______________________________________________

PHASE 1 — BACKGROUND (open-ended, no documents)
1. Tell me about your role and responsibilities.
   Response: ___________________________________________________

2. Walk me through a typical [week/month/procurement cycle/payroll process].
   Response: ___________________________________________________

3. Who else is involved in [relevant process]?
   Response: ___________________________________________________

PHASE 2 — TOPIC AREA (open-ended — use general terms)
4. Tell me about [topic] during [period].
   Response: ___________________________________________________

5. Are there any issues or concerns you're aware of related to [topic]?
   Response: ___________________________________________________

6. Is there anything unusual you recall about [specific event]?
   Response: ___________________________________________________

PHASE 3 — DOCUMENT INTRODUCTION (only after open questions exhausted)
[Introduce documents one at a time. Record response to each.]

Document E-ref: _________ Description: _______________________
Question: "Can you help me understand this document?"
Response: ___________________________________________________

CLOSING
"Is there anything else you'd like to add that might be relevant?"
Response: ___________________________________________________

"Do you have any questions for us?"
Response: ___________________________________________________

"Thank you for your time. We may need to speak with you again. Please do not discuss the
content of this interview with others."

INVESTIGATOR NOTES (observations on demeanour, inconsistencies, follow-up required):
_______________________________________________________________

FOLLOW-UP REQUIRED:
[ ] Additional documents: _______________
[ ] Re-interview: _______________
[ ] Cross-check with other witness statements: _______________

Sign-off — Lead Investigator: _______________  Date: ___________
Sign-off — Documenter: _______________  Date: ___________
```

---

## TEMPLATE 4 — FRAUD TRIANGLE ANALYSIS

```
FRAUD TRIANGLE ANALYSIS
Investigation Reference: INV-{ENTITY}-{YEAR}-{SEQ}

PRESSURE / MOTIVE
Evidence of financial pressure:
  [ ] Gambling / lifestyle debts (evidence: ________________)
  [ ] Medical expenses (evidence: ________________)
  [ ] Family financial crisis (evidence: ________________)
  [ ] Performance target pressure (evidence: ________________)
  [ ] Career threat / demotion fear (evidence: ________________)
  [ ] Grievance against employer (evidence: ________________)
  [ ] No identified pressure (isolated opportunity)
Summary: __________________________________________________

OPPORTUNITY
Control gap that enabled the fraud:
  Control Environment failure: ________________________________
  Risk Assessment gap: ______________________________________
  Control Activity absent or bypassed: _______________________
  Information gap: ___________________________________________
  Monitoring failure: ________________________________________
  Access control: Was the subject's system access appropriate? [ ] Yes [ ] No
  Segregation: Was adequate SoD in place? [ ] Yes [ ] No
  Collusion involved: [ ] Yes [ ] No — suspected co-conspirators: _______________
Summary: __________________________________________________

RATIONALISATION
Cultural or ethical context:
  [ ] "Everyone does it here" — cultural norm
  [ ] Perceived underpayment / entitlement
  [ ] "I was going to pay it back"
  [ ] "The company won't miss it"
  [ ] Senior management role model (tone at top failure)
  [ ] No documented anti-fraud policy awareness
  [ ] Unable to determine
Summary: __________________________________________________

OVERALL CONCLUSION:
  Fraud Triangle Assessment: [ ] Strong / [ ] Partial / [ ] Weak
  Isolated incident: [ ] Yes [ ] No
  Systemic control failure: [ ] Yes [ ] No
  Organisational culture factor: [ ] Yes [ ] No
```

---

## TEMPLATE 5 — INVESTIGATION CONCLUSION MEMORANDUM

```
INVESTIGATION CONCLUSION MEMORANDUM
CONFIDENTIAL — LEGAL PRIVILEGE MAY APPLY

Reference: INV-{ENTITY}-{YEAR}-{SEQ}
Date: ___________
To: AC Chair / CEO / Legal Counsel
From: Group CAE (role)

1. ALLEGATION
Brief: ___________________________________________________

2. CONCLUSION
[ ] SUBSTANTIATED — evidence sufficient for disciplinary referral
[ ] PARTIALLY SUBSTANTIATED — material gaps; further investigation needed
[ ] UNSUBSTANTIATED — allegation could not be corroborated

3. FINANCIAL EXPOSURE
Confirmed loss: _______________
Potential unrecovered amount: _______________
Estimated total exposure: _______________

4. PARTIES IMPLICATED (by role — not name in initial memo)
Role A: _______________  Degree of involvement: _______________
Role B: _______________  Degree of involvement: _______________

5. KEY FINDINGS OF FACT (numbered; each with evidence reference)
F1: ___________________ (Evidence: E-ref___)
F2: ___________________ (Evidence: E-ref___)
F3: ___________________ (Evidence: E-ref___)

6. RECOMMENDED ACTIONS
Immediate:
  [ ] HR disciplinary referral
  [ ] Suspension pending proceedings
  [ ] Civil recovery action
  [ ] Regulatory notification (MACC / MCMC / SSM): _______________
  [ ] Law enforcement referral

Systemic:
  [ ] Control redesign: _______________
  [ ] Policy revision: _______________
  [ ] Additional monitoring: _______________
  [ ] Training: _______________

7. NEXT STEPS
Action | Owner | Target Date
_______|_______|____________

Prepared by: CAE (role)  |  Reviewed by: GCAE (role)  |  Date: ___________
```
