# Modus Operandi Library & Agentic AI Prompts

## Contents
- MODUS OPERANDI LIBRARY — 20 SCHEMES
- CHARLIE HILLS LOG — MO PATTERN RULES (engagement lessons log)

# Group CAE Fraud Risk Governance v2.0 | MKTron GIA
# ──────────────────────────────────────────────────

## MODUS OPERANDI LIBRARY — 20 SCHEMES

### MO-01: Ghost Employee Payroll

**Description:** Fictitious employees added to payroll register. Salary paid to the insider's own bank account or a co-conspirator's account.

**Who:** Payroll administrator; HR manager; Finance controller (usually collusion of 2+)
**Opportunity required:** Single-person control over payroll master and payment
**Duration:** Often perpetrated for 1–5 years before detection
**Indicators:** EPF ECR headcount < payroll headcount; terminated names still active; duplicate bank accounts; new employee with no HR file

**Detection tests:** P01, P02, P03, P04 (objective IDs; script coverage in `gia-fraud-analytics:references/test-id-registry.md`)
**LOG (Charlie Hills):** When detected, record the rule "HR and payroll system access must be held by different individuals; statutory-headcount cross-match must run monthly" in the engagement lessons log.

---

### MO-02: Vendor Kickback Scheme

**Description:** Procurement officer awards contracts to preferred vendors at inflated prices. Vendor pays back a % to the officer (cash, transfer to family account, gifts, loans forgiven).

**Who:** Procurement officer; supplier relationship manager
**Opportunity required:** Single-person vendor selection and approval; no price benchmarking
**Duration:** Can persist for years across multiple contracts
**Indicators:** Single-source procurement; vendor address matches employee; above-market pricing; lifestyle inconsistency of procurement officer

**Detection tests:** V01, V08, price benchmarking; tender documentation audit
**Key financial test:** Compare vendor price to market rate for same goods/services

---

### MO-03: Invoice Splitting (Below Threshold)

**Description:** A single large purchase is split into multiple smaller invoices to stay below the approval threshold requiring additional authorisation.

**Who:** Operational manager; requestor with purchasing access
**Opportunity required:** Approval threshold not enforced; no aggregate vendor spend monitoring
**Duration:** Often used for a single transaction; may be repeated
**Indicators:** Multiple invoices from same vendor on same day or within 3 days; all just below threshold

**Detection test:** V03 (threshold avoidance test); aggregate spend by vendor per period

---

### MO-04: Fictitious Vendor / Shell Company

**Description:** Employee creates a fictitious vendor (often using a family member's name or a dormant company) and submits invoices for goods or services never provided.

**Who:** Finance, procurement, or IT administrator with access to vendor master
**Opportunity required:** Vendor master creation not independently reviewed; no physical goods receipt verification
**Indicators:** Vendor registered < 30 days before first invoice; mobile number only; no physical address; vendor director name matches employee family name

**Detection tests:** V01, V05, V06, V08; vendor KYC

---

### MO-05: Expense Claim Fraud

**Description:** Employee submits false, inflated, duplicate, or personal expense claims for reimbursement.

**Who:** Any employee with expense claim access
**Sub-types:**
- Personal items (groceries, clothing, family meals)
- Duplicate submission (same receipt, different claim date)
- Inflated amounts (altered receipt)
- Fictitious claims (no receipt)
- Round-number claims (invented amounts)

**Detection tests:** Duplicate test; round-number test; receipt review; category analysis

---

### MO-06: Accounts Receivable Lapping

**Description:** Cash received from Customer A is misappropriated. When Customer B pays, their payment is applied to Customer A's account to cover the shortage. Cycle continues.

**Who:** AR clerk; cashier; credit controller
**Opportunity required:** Single person handles cash receipts AND applies to ledger
**Indicators:** Unusual timing of receipts posted; customer complaints about statements; AR not reconciling to cash book

**Detection test:** Match receipts to specific invoices by invoice number (not batch); customer statement review

---

### MO-07: Skimming — Cash Sales

**Description:** Cash sales are not recorded in the system. Cash is pocketed before entry.

**Who:** Point-of-sale staff; cashier; sales clerk
**Opportunity:** No independent cash count; no receipt reconciliation; high cash volume
**Indicators:** Revenue per unit declining vs prior periods; cash variance in daily banking

**Detection:** Revenue per employee trend; daily banking vs theoretical revenue; Benford on cash receipts

---

### MO-08: Asset Misappropriation — Inventory Diversion

**Description:** Physical stock is removed from warehouse and sold or used personally. GRN/delivery notes are manipulated.

**Who:** Warehouse manager; logistics supervisor
**Opportunity:** No CCTV; no independent cycle count; delivery notes not reconciled
**Indicators:** Physical count variance > 2% vs ERP; negative inventory lines; delivery notes without GRN

**Detection:** Physical count vs ERP; delivery note vs GRN; scrap rate analysis; vehicle log

---

### MO-09: Payroll Rate Manipulation

**Description:** Employee's payroll record is altered to inflate salary, OT rate, or allowances without HR authorisation.

**Who:** Payroll administrator; HR with payroll access
**Opportunity:** No segregation between HR records and payroll system
**Indicators:** Salary change without approved HR documentation; OT rate exceeds contractual rate

**Detection:** Payroll change log audit; recalculate OT rate for all employees; match HR file to payroll rate

---

### MO-10: Bid Rigging

**Description:** Tender process is predetermined. Winning vendor is selected before the formal process begins. Other bids are solicited as "cover bids" to appear competitive.

**Who:** Procurement manager; tender committee member; senior management
**Indicators:** Always the same vendor wins; bid documents prepared on similar software/template; losing bids submitted late; prices suspiciously close; winning vendor has relationship with evaluator

**Detection:** Tender file audit; document metadata analysis; vendor relationship declarations; price analysis

---

### MO-11: Journal Entry Manipulation

**Description:** Unauthorised journal entries are used to reclassify expenses, inflate revenue, suppress liabilities, or conceal misappropriated funds.

**Who:** Finance controller; CFO; accountant with unrestricted journal access
**Indicators:** Off-hours entries; round numbers; unusual account pairs; quick reversals; entries by senior finance without reviewer

**Detection tests:** J01–J07 (see analytics library)

---

### MO-12: Window Dressing — Cash Parking

**Description:** At the period-end date, the company temporarily receives large cash deposits (from a related party, director loan, or bank facility). After the reporting date, the cash is returned. The balance sheet shows a much stronger cash position than reality.

**Who:** CFO; Finance Director; related parties
**Indicators:** Bank balance spike on last 3 days of period; normalises in first week of next period; corresponding loan drawdown after period-end

**Detection:** Month-by-month bank balance trend; subsequent period bank statement; related-party loan register

---

### MO-13: Revenue Pull-Forward / Channel Stuffing

**Description:** Revenue is recognised before goods are delivered or services are rendered. At period-end, invoices are issued for work not yet completed. Credit notes are issued after the period closes.

**Who:** Sales director; Finance director; CEO
**Indicators:** DSO spike at period-end; large credit notes in Q1 of next period; invoices pre-date delivery notes

**Detection:** Cut-off test; subsequent credit note search; DSO trend; invoice-to-GRN matching

---

### MO-14: Off-Balance Sheet Liability Concealment

**Description:** Material liabilities are structured as operating arrangements, contingent obligations, or related-party balances that do not appear on the consolidated balance sheet.

**Who:** CFO; Finance director; legal counsel (sometimes external advisors)
**Structures used:** SPV loans; recourse factoring; disguised operating leases; vendor financing; undisclosed guarantees
**Indicators:** Unusual service contracts > 12 months with fixed minimum payments; factoring agreements with recourse; directors' payables with no disclosed terms

**Detection:** Off-balance sheet checklist OB1–OB10 (see analytics library)

---

### MO-15: Directors' Loan / Related-Party Concealment

**Description:** Large loans to or from directors or related parties are not disclosed in financial statements or are misclassified to avoid disclosure requirements.

**Who:** CFO; Finance director; Company Secretary
**Indicators:** Directors' payable balance with no documented terms (set the materiality trigger per engagement); intercompany balance not in consolidation schedule; informal loans to directors without board approval

**Detection:** Directors' loan register vs balance sheet; Board minutes review; cross-check to related-party disclosure in financial statements

**Application:** where an entity carries a directors' payable with no disclosed terms, apply this MO framework and the off-balance-sheet checklist (OB1-OB10 in `gia-fraud-fsf-window-dressing`).

---

### MO-16: ABAC — Kickback via Third-Party Intermediary

**Description:** Instead of direct bribery, payment is made through a "consultant" or "agent" who then passes the payment to the intended recipient. Structured to create deniability.

**Who:** Procurement; Business Development; Senior Management
**Red flags:** Agent fee > 5% of contract value; agent provided by customer/official; agent has no evident skills matching the fee; payment to agent in third country

**Detection:** Agent / consultant payment schedule; due diligence on agents; contract vs deliverable review

---

### MO-17: Inventory Valuation Fraud

**Description:** Obsolete, slow-moving, or damaged inventory is carried at full cost without write-down. Alternatively, inventory counts are inflated.

**Who:** Finance controller; Warehouse manager; Operations
**Indicators:** SLOB ratio rising; inventory turnover declining; no provision movement for years; physical count consistently higher than cycle count expectations

**Detection:** SLOB analysis; provision movement review; net realisable value testing; independent physical count

---

### MO-18: Payable Suppression at Period-End

**Description:** Key supplier payables are paid down at year-end using credit facilities, making the balance sheet appear to have lower debt. Funds are redrawn in January.

**Who:** CFO; Finance Director; Treasury
**Indicators:** AP balance drops significantly on period-end date; credit facility drawdown spikes in first week of next period

**Detection:** Compare period-end AP to post-period AP; bank drawdown timeline; supplier statements

---

### MO-19: Abuse of Power — Management Override

**Description:** A senior manager or executive uses their position to force approval of irregular transactions, suppress audit findings, intimidate staff, or extract personal benefit through control over others.

**Who:** CEO; CFO; Department Head; Entity MD
**This is NOT always financial fraud — it includes:** Intimidation of whistleblowers; forced falsification of records; suppression of audit access; coercion of subordinates

**Red flags:** Restricted audit access; staff fear of raising concerns; HR complaints suppressed; internal complaints ignored; CAE scope limitation requests

**Charlie Hills CHECK:** "Would a senior Board member or regulator be comfortable with this behaviour?" — If no → escalate to AC Chair independently of management

---

### MO-20: Misappropriation of Petty Cash / Corporate Card

**Description:** Corporate card is used for personal expenditure. Petty cash is not reconciled. Receipts are altered or fabricated.

**Who:** Any cardholder; petty cash custodian
**Indicators:** Personal purchases on corporate card; petty cash replenishment frequency high; receipts rounded; no supporting documentation for cash disbursements

**Detection:** Corporate card statement review by category; petty cash count vs book; receipt authenticity assessment

---

## CHARLIE HILLS LOG — MO PATTERN RULES (engagement lessons log)

After each investigation, add a specific rule based on the MO identified (generic, no case facts):

```
TEMPLATE:
[MO-XX] CONFIRMED — {ENTITY} — {DATE}
Scheme: {brief description}
Control gap: {what was absent}
New rule: {actionable prevention instruction}
Detection test added: {test reference added to monitoring schedule}
```

Example (illustrative template, not a real case):
```
[MO-XX] CONFIRMED — {ENTITY CODE} — {YYYY-MM}
Scheme: ghost payees on payroll for several months; salary to an account linked to an approver
Control gap: no monthly statutory-headcount vs payroll cross-match; single-person payroll access
New rule: statutory headcount vs payroll headcount reconciled by Finance (not HR) monthly by a fixed day
Detection test added: P01 added to the monthly monitoring schedule (gia-analytics:gia-continuous-assurance)
```
