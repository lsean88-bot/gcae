# Red Flag Library — Master Reference

## Contents
- PROCUREMENT & VENDOR FRAUD
- PAYROLL FRAUD
- EXPENSE CLAIMS FRAUD
- FINANCIAL STATEMENT FRAUD
- JOURNAL ENTRY RED FLAGS (JE TESTING)
- CASH AND BANKING
- MANAGEMENT BEHAVIOUR

# gia-fraud-investigation reference | red flags are indicators, never conclusions (see ladder in SKILL.md)
# ──────────────────────────────────────────────────

## PROCUREMENT & VENDOR FRAUD

| Red Flag | Scheme Indicator | Test |
|----------|-----------------|------|
| Vendor address matches employee home/bank address | Ghost vendor / kickback | Vendor master vs employee master address match |
| Vendor incorporated < 30 days before first invoice | Fictitious vendor | Vendor registration date vs first invoice date |
| Round-number invoices (MYR10,000.00, INR100,000.00) | Fabricated invoice | Round-number test on AP ledger |
| Invoices split just below approval threshold | Threshold avoidance | Invoice series analysis; approver bypass detection |
| Single-source procurement without documented justification | Bid rigging | Tender records; supplier evaluation scores |
| Rapid escalation from new vendor to high-volume orders | Kickback relationship | Vendor history; relationship timeline |
| No physical address; mobile number only vendor | Fictitious / shell vendor | Vendor KYC; SSM/ROC verification |
| Vendor director shares surname with procurement officer | COI — undisclosed | COI declaration vs vendor registry |
| Goods never physically received; GRN signed remotely | Fictitious delivery | GRN to physical count; warehouse receipt |
| Invoice amount changed between PO and payment | Alteration fraud | 3-way match: PO vs GRN vs Invoice vs Payment |
| Same invoice number submitted twice | Duplicate payment | Duplicate invoice test in AP ledger |
| Cheque payable to individual, not company | Misappropriation | Payee name analysis on payment run |
| Payment to dormant vendor reactivated without HR/finance approval | Shell vendor reactivation | Vendor change log; approval workflow |

## PAYROLL FRAUD

| Red Flag | Scheme Indicator | Test |
|----------|-----------------|------|
| Employee terminated but still receiving salary | Ghost employee | Termination list vs payroll register |
| Two employees sharing the same bank account number | Ghost / collusion | Bank account duplicate check |
| Employee with no leave taken in 12 months | Control owner covering fraud | Zero-leave analysis |
| Salary changed without HR authorisation | Unauthorised modification | Payroll change log vs HR approval records |
| New employee added to payroll without HR paperwork | Ghost employee | HR file vs payroll register completeness |
| OT hours claimed on approved leave days | OT fraud | OT register vs leave register cross-match |
| OT amount exceeds Basic/2 (implies >100% OT rate) | Inflated OT rate | OT rate recalculation test |
| Employee on payroll but not on EPF/SOCSO/ESIC | Ghost / off-books payroll | ECR headcount vs payroll register |
| Payroll processed by same person who approves it | Segregation failure | Process walkthrough; access matrix |
| Salary paid to foreign account with no documentation | Misappropriation | Foreign payment analysis |
| Contractor on payroll (permanent-style payment) | Misclassification / regularisation | Contract type vs payroll classification |

## EXPENSE CLAIMS FRAUD

| Red Flag | Scheme Indicator | Test |
|----------|-----------------|------|
| Personal items claimed (groceries, clothing, private fuel) | Personal expense claim | Receipt categorisation review |
| Same receipt submitted twice (different claim dates) | Duplicate claim | Duplicate amount + vendor + date test |
| Claim on public holiday or weekend with no business justification | Fictitious claim | Calendar match to claimed dates |
| No receipt for claim above policy threshold | Unsupported claim | Receipt completeness check |
| Round-number claims (MYR500.00, INR5,000.00) | Fabricated claim | Round-number test on claims register |
| Vendor name matches employee name | Self-billing | Vendor name vs employee name check |
| Multiple claims to same vendor in same period | Possible splitting | Aggregate by vendor per employee per month |
| Meals for > 10 people on a single receipt | Entertainment inflation | Attendee list vs headcount vs claim amount |

## FINANCIAL STATEMENT FRAUD

| Red Flag | Scheme Indicator | Test |
|----------|-----------------|------|
| Revenue growth materially exceeds industry peers | Fictitious revenue | Peer benchmarking; days sales outstanding trend |
| Days sales outstanding spiking at period-end | Revenue pull-forward / channel stuffing | DSO trend analysis; subsequent cash receipt test |
| Large credit notes in the period after year-end | Revenue reversal (pull-forward) | Post-period credit note search |
| Gross margin rising while revenue falls | Expense suppression / inventory inflation | Vertical analysis; COGS component breakdown |
| Receivable balances not ageing (always "current") | A/R lapping | Debtor ageing detail; receipt matching |
| Inventory rising faster than COGS | Inventory inflation | Inventory turnover ratio; SLOB analysis |
| Depreciation rate declining without policy change | Asset life manipulation | Fixed asset policy vs actual rates applied |
| Unusual year-end adjusting journals by CFO/Finance Director | Manual override | JE testing: late entries by senior management |
| Bank balance spikes at year-end; normalises in January | Cash parking / window dressing | Month-by-month bank balance trend |
| Off-balance sheet entities not in consolidated group | Hidden liabilities | Related party register; group structure map |
| Directors' loans / payables with no disclosed terms | Related-party concealment | Board minutes; loan agreement review |
| Prior-year adjustment without Board approval or audit note | Restatement concealment | PY adjustment vs board minutes vs audit file |

## JOURNAL ENTRY RED FLAGS (JE TESTING)

| Red Flag | Scheme |
|----------|--------|
| Posted outside business hours (midnight–5am; weekends) | Concealment |
| Round number (exactly MYR100,000.00) | Fabricated |
| Reverse within 3 business days | Temporary manipulation |
| Posted directly by CFO / Finance Director without reviewer | Override |
| Unusual account pair (e.g. Cash DR / Suspense CR) | Asset movement |
| Exceeds individual's system authorisation level | Access control failure |
| Backdated (entry date vs created date mismatch) | Period manipulation |
| Posted to rarely-used accounts | Hiding |
| Memo field blank or generic ("adjustment", "correction") | Concealment |

## CASH AND BANKING

| Red Flag | Scheme |
|----------|--------|
| Bank reconciliation items outstanding > 60 days | Larceny / concealment |
| Stale cheques > 6 months unclaimed | Potential misappropriation |
| Negative book balance at any time | System error or deliberate |
| Payments to personal accounts without board authority | Misappropriation |
| Round-number wire transfers to related parties | Undisclosed transfers |
| Multiple petty cash replenishments in short period | Cash skimming |
| Missing bank statements for any period | Evidence destruction |

## MANAGEMENT BEHAVIOUR

| Red Flag | Hypothesis to test (indicator only; never a statement of intent or motive) |
|----------|------------|
| Restricts audit access to specific staff, systems, or documents | Concealment |
| Insists on being present during all subordinate interviews | Intimidation |
| Refuses to take mandatory leave | Fear of relief uncovering fraud |
| Lifestyle (property, vehicles, travel) inconsistent with salary | Proceeds of fraud |
| Control override with no documentation | Abuse of power |
| Resistance to segregation of duties changes | Needs the control gap |
| Unusual personal relationships with vendors or customers | Undisclosed COI |
| Aggressive response to audit observations | Pressure |
| Last-minute changes to financial data before audit | Manipulation |
| Requests verbal discussions rather than email | Evidence avoidance |
| Reluctance to document decisions | Decision rationale not evidenced; test approval trail |
| Unusual related-party transactions | Undisclosed or non-arm's-length dealing; test against related-party register |
