---
name: gia-fraud-risk-governance
description: "Fraud-risk governance: annual fraud risk assessment and heat map, COSO fraud principles, ABAC programme review against ISO 37001, whistleblower standards, remediation mapping. Use when asked for FRA, ABAC, adequate-procedures, whistleblower channel or anti-fraud policy reviews. Do NOT use for investigating an allegation (use gia-fraud:gia-fraud-investigation)."
---

# Fraud Risk Governance

Rules by number are in `gia-core:iron-rules`. Statutory figures (penalties, thresholds, effective dates) are never held in this skill: read the jurisdiction's `statutory-register-<juris>.md` (owned by `gia-audit`); anything not yet verified there is quoted as [UNVERIFIED] (Rules 02, 03).

## 1. Governance ownership model (roles)

| Layer | Owner (role) | Responsibility |
|---|---|---|
| Board / AC | AC Chair | Fraud risk appetite; oversight of CAE independence |
| EXCO | CEO, CFO | Tone at the top; resource the compliance function |
| Internal audit | Group CAE | Fraud risk assessment; investigation authority; AC reporting |
| Legal | Group Legal | Privilege; referrals; regulatory notification decisions |
| HR | CHRO | Whistleblower protection; disciplinary process |
| Line management | Entity MDs | First-line prevention; control ownership |

Three lines: 1st (operations) prevents through controls, limits and segregation of duties; 2nd (risk and compliance) detects through monitoring and the ABAC programme; 3rd (GIA) assures, assesses fraud risk, investigates and reports to the AC.

## 2. COSO fraud risk management principles

| Principle | Core requirement | Audit evidence |
|---|---|---|
| P1 Governance | Board or AC owns fraud risk governance; explicit fraud risk policy | Charter, policy, minutes |
| P2 Risk assessment | Identify, assess and prioritise fraud scenarios across all units each year | FRA file (section 3) |
| P3 Control activities | Preventive and detective controls for each high-residual scenario | Control matrix mapped to scenarios |
| P4 Investigation | Documented, defensible investigation protocol | `gia-fraud:gia-fraud-investigation` |
| P5 Monitoring and reporting | Continuous monitoring, periodic re-assessment, AC reporting | `gia-analytics:gia-continuous-assurance`, AC pack |

Edition and publication details: record the edition actually used in the engagement file [UNVERIFIED until checked against the publisher].

## 3. Annual fraud risk assessment (7 steps)

| Step | Action | Output |
|---|---|---|
| 1 Identify | List fraud scenarios per process and entity, starting from the ACFE tree (`gia-fraud:gia-fraud-investigation` references/fraud-tree.md) | Scenario register |
| 2 Assess inherent risk | Likelihood and impact per scenario, on the entity ERM scale | Inherent rating |
| 3 Map controls | Link each scenario to existing preventive and detective controls | Control map |
| 4 Evaluate effectiveness | Rate each control Strong, Adequate, Weak or None, with the evidence for the rating (design, then operation; Rules 10, 21) | Effectiveness rating |
| 5 Rate residual risk | Combine inherent rating with effectiveness (matrix below) | Residual rating |
| 6 Prioritise | High residual scenarios go to audit coverage, monitoring or targeted inquiry; the rest to routine cycle | Response list |
| 7 Report | Heat map and recommended responses to the AC; changes since last year | AC paper |

Residual matrix (calibrate to the entity ERM scale before use; illustrative defaults):

| Inherent \ Effectiveness | Strong | Adequate | Weak | None |
|---|---|---|---|---|
| High | Medium | High | High | High |
| Medium | Low | Medium | High | High |
| Low | Low | Low | Medium | Medium |

Rules: fraud risk is documented in every engagement scope (Rule 11). Management-override and tone-at-the-top scenarios are assessed separately from process-level scenarios. Document population, basis and rationale for every rating (Rule 14). Heat map and register layout: `references/fra-register-template.md`.

## 4. Anti-fraud policy set (every entity should evidence)

Anti-fraud policy (Board-approved, published, acknowledged by staff) | ABAC policy aligned to ISO 37001 and the local regime | Whistleblower policy (anonymous channel, non-retaliation, timely acknowledgement) | Conflict-of-interest declaration (annual; management and procurement) | Gifts, entertainment and hospitality register (threshold set by entity policy; any statutory figure from the register).

## 5. ABAC framework

- Jurisdiction regimes and the key provision of each: `references/jurisdiction-matrix.md` (dated; penalties by register).
- Review checklist (ISO 37001 clauses, adequate procedures, gifts, third parties, training, monitoring, investigation readiness): `references/abac-checklist.md`.
- Malaysia corporate liability (MACC s.17A): adequate-procedures defence assessed against the five T.R.U.S.T principles.

| T.R.U.S.T | What to look for in evidence |
|---|---|
| Top-level commitment | Board or AC anti-corruption statement; CEO annual pledge; ABAC policy approved by directors |
| Risk assessment | Annual ABAC risk assessment covering all entities and third parties; high-risk country mapping |
| Undertake control measures | Gifts register; hospitality limits; third-party due diligence; tender controls; COI declarations |
| Systematic review | Annual ABAC audit; periodic monitoring reports to the AC; ISO 37001 gap assessment |
| Training and communication | Annual training for all staff; enhanced training for procurement, finance and senior management |

FCPA vs UK Bribery Act differences (scope, facilitation payments, corporate offence, reach) and the ISO 37001 edition in force (2025, verified) are held in the jurisdiction matrix with their verification status. Do not rely on memory for enforcement status (Rule 02).

## 6. Whistleblower programme standards

| Standard | Requirement |
|---|---|
| Channel | Anonymous option (email, hotline or web form) |
| Acknowledgement | Within 48 hours (policy target; confirm against local law via the register) |
| Outcome notice | Within 90 days of closing |
| Non-retaliation | Enforced; breaches investigated as separate matters |
| Independence | Managed by the CAE or an external provider, not HR or line management |
| Escalation | Any allegation implicating the C-suite or Board goes directly to the AC Chair |

## 7. Control remediation after a case (COSO map)

| COSO component | Gap type | Remediation priority |
|---|---|---|
| Control environment | Tone failure; override culture | AC intervention; leadership accountability |
| Risk assessment | Scenario never assessed | Update the FRA (section 3) |
| Control activities | Segregation gap; no independent review | Redesign approval matrix and system controls |
| Information and communication | Evidence loss; restricted access | IT forensics; access log review; hardening |
| Monitoring | No continuous monitoring | Add tests to `gia-analytics:gia-continuous-assurance` |

## 8. Benchmarks and statistics

All prevalence, loss and detection statistics sit in one place: `references/acfe-benchmarks.md`, dated and marked [UNVERIFIED]. Do not quote a statistic from any other file or from memory.

## References

| File | Load when |
|---|---|
| `references/fra-register-template.md` | Building the FRA register and heat map |
| `references/jurisdiction-matrix.md` | ABAC regimes by jurisdiction |
| `references/abac-checklist.md` | ISO 37001 and adequate-procedures audit |
| `references/acfe-benchmarks.md` | Any fraud statistic |

## Related

`gia-fraud:gia-fraud-investigation` | `gia-fraud:gia-fraud-analytics` | `gia-core:iron-rules` | `gia-audit` (statutory register, engagement planning).
