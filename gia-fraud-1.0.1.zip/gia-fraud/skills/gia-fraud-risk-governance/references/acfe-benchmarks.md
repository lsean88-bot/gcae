# ACFE benchmarks - single dated reference

Status: [UNVERIFIED - validator to confirm 2026 edition]
Compiled: 2026-10-29. This file replaces the earlier-edition figures previously embedded in several skills. No figure is quoted from memory.

## Contents
1. Rules of use
2. Figures to be filled by the validator
3. Retired figures

## 1. Rules of use
- This is the only place in `gia-fraud` where a prevalence, median-loss or detection-method statistic may appear.
- Quote a figure only with its edition and verification status. If the status is [UNVERIFIED], say so in the deliverable or omit the figure.
- Benchmarks are context for a risk narrative. They are never evidence about the entity and never support a finding.

## 2. Figures (ACFE Occupational Fraud 2026: A Report to the Nations, 14th edition)
Verified-on 2026-10-29 (`build/VALIDATED_FACTS.md` row 9). Case and country counts are verified on acfe.com; every other figure is SECONDARY-ONLY (ACFE Mexico Spanish PDF; Accounting Today) and must be checked against the English ACFE PDF before it is quoted in a final report. Status shown per row. Overall status: [UNVERIFIED - validator to confirm 2026 edition against the English primary PDF].

| Metric | Value | Edition | Verified on | Status |
|---|---|---|---|---|
| Usable cases | 2,402 | 2026 | 2026-10-29 | VERIFIED (acfe.com) |
| Countries and territories | 143 | 2026 | 2026-10-29 | VERIFIED (acfe.com) |
| Cases investigated | Jan 2024 to Sep 2025 | 2026 | 2026-10-29 | SECONDARY-ONLY |
| Share asset misappropriation | 90% | 2026 | 2026-10-29 | SECONDARY-ONLY |
| Share corruption | 45% | 2026 | 2026-10-29 | SECONDARY-ONLY |
| Share financial statement fraud | 6% | 2026 | 2026-10-29 | SECONDARY-ONLY (shares exceed 100%: cases can involve several schemes) |
| Median loss, all cases | $104,000 | 2026 | 2026-10-29 | SECONDARY-ONLY |
| Mean loss | $1,457,000 | 2026 | 2026-10-29 | SECONDARY-ONLY |
| Share detected by tip | 43% | 2026 | 2026-10-29 | SECONDARY-ONLY |
| Total losses | over $3.4bn | 2026 | 2026-10-29 | SECONDARY-ONLY (one source only) |
| Estimated share of revenue lost | 5% | 2026 | 2026-10-29 | SECONDARY-ONLY |
| Median loss by scheme category; median duration | not captured | 2026 | n/a | NOT FOUND |

When quoting: "per the ACFE 2026 Report to the Nations (secondary source; primary not yet checked)".

## 3. Retired figures
Figures attributed to the earlier (2024) edition (scheme shares, median losses by category, tip share) and the "2024 RTN" figures in the payroll audit skill are retired. Do not reinstate them.
