# ABAC jurisdiction matrix

Status: structure only; provisions and penalties are read from `statutory-register-<juris>.md` (owned by `gia-audit`). Matrix last reviewed 2026-10-29. Every provision and penalty row is [UNVERIFIED] until the register entry carries a verified-on date.

## Contents
1. Regimes
2. FCPA vs UK Bribery Act
3. ISO 37001 edition
4. Entity-to-regime applicability

## 1. Regimes
| Jurisdiction | Regime | Key concept to test | Penalty / effective date |
|---|---|---|---|
| Malaysia | MACC Act 2009, s.17A | Corporate liability for gratification by an associated person; adequate-procedures defence (T.R.U.S.T) | Register: Malaysia |
| USA | FCPA | Foreign-official bribery; books and records | Register: USA (applies only where a US nexus exists) |
| UK | Bribery Act 2010 | All bribery incl. commercial; s.7 failure to prevent | Register: UK (applies only where a UK nexus exists) |
| Mexico | General Law of Administrative Responsibilities (LGRA) and related federal anti-corruption and AML laws | Corporate integrity programme; sanctions on legal entities | Register: Mexico |
| India | Prevention of Corruption Act 1988 (as amended); PMLA | Bribery of public servants, demand and supply side; money laundering | Register: India |
| International | ISO 37001 ABMS | Management-system benchmark for "adequate procedures" | Edition: section 3 |

## 2. FCPA vs UK Bribery Act (structure)
| Dimension | FCPA | UK Bribery Act |
|---|---|---|
| Scope | Foreign officials | Domestic and foreign; public and commercial |
| Facilitation payments | Narrow exception - confirm with counsel | No exception |
| Corporate offence | Via accounting and agency provisions | s.7 failure to prevent |
| Reach | US persons and issuers | UK persons and those carrying on business in the UK |
| Enforcement posture | Changes over time - check current DOJ guidance; do not rely on memory | Check current SFO guidance |

## 3. ISO 37001 edition
Edition in force: ISO 37001:2025 (VERIFIED on the ISO catalogue page, 2026-10-29; the 2016 page shows it as revised by the 2025 edition; Amd 1:2024 withdrawn). Publication month and any transition deadline for the 2016 edition are NOT FOUND: do not state them. Cite "ISO 37001:2025" in new work.

## 4. Entity applicability
Applicable regime per entity is decided at planning from the entity's jurisdiction, ownership and trading nexus. Mexico and Malaysia entities are always assessed for ABAC. Record the decision and rationale in the engagement scope.
