# ABAC Compliance Audit Checklist
# ISO 37001:2025 + MACC Section 17A + FCPA + UK Bribery Act
# Group CAE Fraud Risk Governance v2.0 | MKTron GIA
# ──────────────────────────────────────────────────

## SECTION A — Governance and Policy (MACC T.R.U.S.T — Principle T & R)

| # | Audit Test | Evidence Required | Risk if Absent |
|---|-----------|-----------------|---------------|
| A1 | Anti-Fraud Policy Board-approved and published | Board minutes + signed policy | No legal defence under MACC s.17A |
| A2 | ABAC Policy aligned to MACC s.17A and ISO 37001 | Policy document + review date | Corporate liability exposure |
| A3 | Whistleblower Policy operational with anonymous channel | Channel test + acknowledgement log | Deterrence failure; complaints suppressed |
| A4 | COI Declaration signed by all management and procurement staff (annual) | Signed declarations register | Undisclosed COI = bid rigging risk |
| A5 | Gifts, Entertainment and Hospitality Register maintained | Register with approval evidence | Illegal gratuities; MACC exposure |
| A6 | Gifts threshold defined and enforced (threshold per entity policy; any statutory figure per the statutory register) | Policy + register threshold | Facilitation payment risk |
| A7 | Board/AC Anti-Corruption Statement issued and communicated | Statement + distribution evidence | Tone at top failure |
| A8 | CEO Annual Integrity Pledge to all staff | Pledge + distribution record | Cultural compliance failure |

## SECTION B — Risk Assessment (MACC T.R.U.S.T — Principle R)

| # | Audit Test | Evidence Required | Risk if Absent |
|---|-----------|-----------------|---------------|
| B1 | Annual fraud risk assessment completed and documented | FRA document + sign-off date | COSO P2 failure; MACC defence gap |
| B2 | ABAC risk assessment covers all entities including third parties | Risk register with entity coverage | Third-party liability under MACC s.17A |
| B3 | High-risk countries / counterparties identified and flagged | Risk matrix with country ratings | FCPA / UKBA extraterritorial exposure |
| B4 | Fraud risk scenarios mapped to ACFE Fraud Tree categories | Risk register with Fraud Tree reference | Incomplete risk coverage |
| B5 | Residual fraud risk rated after control effectiveness assessment | Heat map with residual ratings | No prioritisation; resource misalignment |

## SECTION C — Control Measures (MACC T.R.U.S.T — Principle U)

| # | Audit Test | Evidence Required | Risk if Absent |
|---|-----------|-----------------|---------------|
| C1 | Third-party due diligence process documented and operational | Process document + due diligence files | MACC s.17A — associated person liability |
| C2 | Vendor screening against debarment / sanctions lists | Screening tool + last run date | Sanctions exposure |
| C3 | Tender process requires minimum 3 competitive bids above threshold | Tender policy + recent tender files | Bid rigging risk |
| C4 | Payment approvals have adequate segregation (requestor ≠ approver ≠ payer) | Access matrix + payment samples | Misappropriation risk |
| C5 | Vendor master changes require dual authorisation | Change log + approval evidence | Ghost vendor creation risk |
| C6 | Journal entry approval by independent reviewer | JE workflow + sample review | Journal manipulation risk |
| C7 | Anti-bribery clause in all material contracts | Contract samples + clause checklist | No contractual protection |
| C8 | Cash transactions above threshold require documented approval | Cash policy + sample vouchers | Cash fraud exposure |
| C9 | Bank signatories require dual signatures above defined threshold | Bank mandate + sample payments | Misappropriation risk |
| C10 | Hospitality expenditure approved in advance by line superior | Approval forms + register | Kickback concealment |

## SECTION D — Monitoring and Review (MACC T.R.U.S.T — Principle S)

| # | Audit Test | Evidence Required | Risk if Absent |
|---|-----------|-----------------|---------------|
| D1 | Annual ABAC audit completed by GIA with findings reported to AC | Audit report + AC minutes | MACC s.17A defence weakness |
| D2 | Whistleblower volume and status tracked and reported to AC quarterly | Tracking log + AC papers | Pattern indicators missed |
| D3 | COI declarations reviewed for material undisclosed conflicts | Review records | Undisclosed COI undetected |
| D4 | Gifts register reviewed quarterly; threshold breaches escalated | Review records + escalation evidence | Illegal gratuity concealment |
| D5 | Third-party due diligence refreshed annually for high-risk vendors | Re-screening records | Stale due diligence |
| D6 | Investigation outcomes tracked and control remediation verified | Remediation tracker | Control gaps persist post-investigation |
| D7 | Continuous monitoring tests (Benford, duplicate, threshold avoidance) running | Monitoring reports + exception logs | Detection gap |
| D8 | Fraud risk assessment updated after each investigation | Updated FRA with new scheme entry | New schemes not reflected |

## SECTION E — Training and Communication (MACC T.R.U.S.T — Principle T)

| # | Audit Test | Evidence Required | Risk if Absent |
|---|-----------|-----------------|---------------|
| E1 | Annual ABAC training delivered to all staff | Training records + attendance log | MACC adequate procedures gap |
| E2 | Enhanced training for procurement, finance, and senior management | Enhanced training records | High-risk roles undertrained |
| E3 | Training covers MACC s.17A, gifts policy, whistleblower channel, COI | Training content review | Key provisions not communicated |
| E4 | ABAC policy communicated externally to key vendors and contractors | Communication records | Third-party MACC exposure |
| E5 | New joiner ABAC induction within 30 days of start | Induction records | Gap between hire and training |
| E6 | Training effectiveness tested (assessment or attestation) | Test/attestation records | Training delivered but not understood |

## SECTION F — Investigation Readiness

| # | Audit Test | Evidence Required | Risk if Absent |
|---|-----------|-----------------|---------------|
| F1 | Documented investigation procedure exists | Procedure document | Ad-hoc investigation = legal risk |
| F2 | Investigation lead identified with no COI requirement | Role definition | Conflicted investigation |
| F3 | Legal counsel engagement protocol documented | Protocol + legal contact list | Privilege not protected |
| F4 | Evidence preservation procedure documented | Procedure + IT escalation contact | Evidence loss |
| F5 | Whistleblower outcome notification SLA defined (≤90 days) | Policy + sample notifications | Trust breakdown |
| F6 | Investigation report template covers all CFE requirements | Template review | Legally defective report |

## MACC Section 17A - Penalty and Defence Summary

Penalty amounts, imprisonment terms, effective dates and enforcement history are statutory data.
They are NOT held in this skill. Read them from `gia-audit:gia-pack-malaysia` references/statutory-register-malaysia.md
(owned by the audit suite, refreshed by `gia-core`/`gia-audit` statutory-freshness controls).
Until the register entry is marked verified, quote any figure as [UNVERIFIED].

| Element | Position |
|---|---|
| Corporate liability | Arises where an associated person gives gratification for the organisation's benefit |
| Personal liability of directors/management | Deemed liability unless due diligence is proved (confirm wording in the register) |
| Defence | Adequate Procedures per the T.R.U.S.T principles; burden on the organisation |
| Penalty quantum / enforcement dates | See statutory register [UNVERIFIED until validator fills] |
