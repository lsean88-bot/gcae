# FRA register and heat map - template

## Register columns (one row per scenario)
| Col | Field | Notes |
|---|---|---|
| A | Scenario ID | FRA-<ENTITY CODE>-<nn> |
| B | Process | e.g. procure-to-pay, payroll, treasury, inventory, revenue |
| C | Scheme (ACFE branch) | From `fraud-tree.md` |
| D | Who could do it (role) | Role, not name |
| E | Likelihood (1-5) | Entity ERM scale |
| F | Impact (1-5) | Entity ERM scale |
| G | Inherent rating | Formula from E, F |
| H | Controls mapped | Control IDs from the RACM |
| I | Effectiveness | Strong / Adequate / Weak / None |
| J | Evidence for I | Design / operating evidence reference with R-level |
| K | Residual rating | Matrix in SKILL.md section 3 |
| L | Test ID(s) | P/V/J/B/F/OB from `gia-fraud-analytics` test-id-registry; "NO SCRIPT YET" where none |
| M | Response | Audit, monitor, inquire, accept |
| N | Owner and date | SMART |

## Heat map
Grid of inherent likelihood (rows) by impact (columns) with scenario counts and IDs in cells; second grid for residual. Present with a legend and the count of scenarios. Profile B (Board/AC) version: no cell-level row references; one page.

## Statement basis (Rule 37)
Add a sheet classing each rating basis: verified from source file / supplied by others / audit inference (rationale and limits) / proposal.
