---
name: gia-fraud-rbia-frm
description: "Risk-based audit and fraud risk management orchestration: context-first triage (Class A-D), layer diagnosis, data sufficiency register, benign-alternative testing, scenario forecasts, RFIs, human gates. Use when asked for complex procurement, sales or inventory reviews with fraud hypotheses, or RFI drafts. Do NOT use for single-test analytics (use gia-fraud:gia-fraud-analytics)."
---


# RBIA-FRM Orchestration - Operating Contract

Rules by number are in `gia-core:iron-rules`. Fraud wording follows the ladder in `gia-fraud:gia-fraud-investigation` section 3; the standard of proof for "substantiated" is an open Legal dependency.

## 0. NON-NEGOTIABLES
1. Do not name fraud, theft, collusion or a perpetrator from labels, naming
   conventions, repetition, or round numbers alone.
2. Do not infer pricing, arm's-length status, beneficial ownership, physical
   delivery, or financial loss from documents that do not contain that data.
3. Do not treat an ERP workaround, trial code, legacy item or "Alternate" BOM
   as misconduct without testing operational context and approval history.
4. Do not invent statutes, clause numbers, thresholds, data values or dates.
   Where jurisdiction or entity is unknown, mark `VERIFY JURISDICTION`.
5. Do not send, post, freeze, terminate, accuse or escalate externally.
   Draft only. The human authorizes and executes.
6. Do not produce a loss estimate without inputs, formula, period, assumptions
   and a confidence range. Label it ESTIMATE, never ACTUAL LOSS.
7. If data is insufficient, produce a Data Sufficiency Register and a targeted
   RFI. Do not fill the gap with narrative.

## 1. PHASE 0 — CLARIFYING QUESTIONS, INTAKE AND DATA SUFFICIENCY GATE
Every audit differs, so materiality, jurisdiction and mandate are never
defaulted or carried over from a previous engagement. They are asked at the
start of each new project, because a wrong assumption here silently changes
every severity rating, legal mapping and escalation decision downstream.

**Step 0 — Ask first (new engagement, or when any item below is unknown).**
Before any analysis, send ONE short batch of clarifying questions (maximum 8,
multiple-choice where possible, each with a stated reason). Always cover:
1. Entity/entities and governing jurisdiction(s) (cross-border? which law applies)
2. Period and currency
3. Materiality basis and thresholds (overall, performance, and clearly-trivial;
   or the user's own rule of thumb), including any regulatory trigger
4. Mandate and privilege (management review / internal audit / counsel-led)
5. Documents available now vs obtainable, and the systems they come from
6. Who may receive findings (distribution) and the decision the work must support
7. Known sensitivities (people already suspected, live investigations, deadlines)
8. Red-line thresholds the user wants (default: any red line in section 6A)
If the user says "proceed" without answering, continue ONLY with the safe
subset (hygiene/process observations, RFI drafting), mark every severity
`MATERIALITY NOT SET` and every legal reference `VERIFY JURISDICTION`, and
re-ask. Never invent a threshold. A change in scope, entity or period re-opens
Step 0. Within the same engagement, record the answers once in the Decision Log
and reuse them (do not re-ask unchanged items).

**Then complete:**
- Entity / legal entities / jurisdiction / period / currency (from Step 0)
- Business process and systems (ERP, WMS, weighbridge, AP/AR, GL)
- Documents actually received vs documents required
- Materiality basis (from Step 0; profit, revenue, assets, transaction value, statutory trigger)
- Mandate and privilege status (from Step 0)
- Red-line thresholds (default: any payment stop, employment action, external
  disclosure, legal accusation, or amount >= the user's stated threshold)

Output a **Data Sufficiency Register**:

| Required evidence | Received? | Source / ref | Gap | Requested from | Priority |
|---|---|---|---|---|---|

Rules:
- BOM alone ≠ pricing evidence.
- GRN alone ≠ physical delivery proof (need gate log + weighbridge + E-way bill).
- Vendor/customer shared name alone ≠ related party (need registry/declaration).
- A manual entry alone ≠ concealment (need reason, approver, and root cause).
- If any conclusion-critical item is missing, STOP at RFI stage.

## 2. PHASE 1 — THINK / WEIGH (STRATEGIC PATH SELECTION)
Produce 2–3 paths (e.g. Rapid Triage / Balanced Dive / Full Forensic).
Score each on: incremental evidence value, cost, time, operational disruption,
evidence-preservation risk, fairness to staff. Select one and state WHY, and
state what would cause you to change path. No path may be selected that
presumes misconduct.

## 3. PHASE 2 — BOTTOM-UP LAYER DIAGNOSIS (NO PATCH MANAGEMENT)
Work strictly upward. Do not start at "fraud" or at the Board.

- **L0 Data lineage & completeness**: extract scope, exclusions, duplicates,
  date coverage, UOM consistency, system vs export integrity.
- **L1 Master data**: item/BOM/vendor/customer/vendor-bank/SCA/UOM/price master,
  who may create/change, approval workflow, change log, ECN linkage.
- **L2 Transactions**: PO–GRN–IR–Invoice–Payment three/four-way match;
  issue/consumption/scrap postings; JE author/approver/narration/support.
- **L3 Process & functional ownership**: RACI, segregation of duties,
  manual override rate, exception queue ownership, throughput/yield drivers.
- **L4 Financial reporting**: inventory valuation, standard vs actual cost,
  scrap credit, overhead allocation, WIP, cut-off, related-party disclosure.
- **L5 Governance**: policy → control → monitoring → assurance → Board reporting;
  Three Lines Model; tone at the top; escalation latency.

For each layer output:
`Observed fact | Evidence ref | Benign explanation | Adverse explanation |
Test to distinguish | Root cause | Structural fix | Owner | Due date`

## 4. PHASE 3 — CONTEXT-FIRST TRIAGE (MANDATORY BEFORE RISK RATING)
Apply references/01-context-triage.md. Categories:
A. Master-data hygiene  B. Process inefficiency  C. Control bypass
D. Potential fraud (converging evidence + intent + concealment + benefit)

Every item receives: category, materiality, confidence, missing context,
and the specific question that would resolve it.

## 5. PHASE 4 — DELEGATE (ECONOMICAL MULTI-AGENT EXECUTION)
Dispatch narrow, parallel workstreams. Never send the whole file to every agent.

| Agent | Model | Assigned work |
|---|---|---|
| evidence-custodian | Haiku | Inventory documents, build index, log gaps, preserve refs |
| master-data-process | Haiku | BOM/alternate/manual/ECN/UOM pattern extraction |
| forensic-data | Haiku, then Sonnet for synthesis | Rule-based exception set; then interpret only converged sets |
| cost-accounting-analyst (`gia-analytics`) | Sonnet | Standards, costing, scrap credit, valuation, JE substance |
| legal-compliance | Sonnet | Related-party, tax, contract, statutory mapping (verify jurisdiction) |
| governance-strategy | Sonnet | Three Lines / COSO mapping, strategic objective impact |
| forecasting-scenario | Sonnet | Extrapolation, need projection, what-if, break-even remediation |
| ethics-abc | Sonnet | Conflict-of-interest, gifts, third-party integrity, conduct tone |
| orchestrator | Sonnet | Path selection, synthesis, judgment gates, final deliverables |
| independent QA | Sonnet, high effort, a different agent from the preparer | Section 9 gate: `gia-report-qa` QA agents |

Each agent returns ONLY: facts with refs, tested alternatives, gaps, and a
recommendation. No agent may issue an accusation or an escalation.

## 6. PHASE 5 — FACT-FINDING GATE (BEFORE ANY ESCALATION)
Draft 3–6 non-accusatory, answerable questions tied to specific refs.
Example form:
"Item X uses Alternate BOM 002 with a Manual issue method and a scrap credit
of Y kg. Please provide the ECN/approval, the observed yield evidence, and the
reason the Standard route was not used."

Wait for the human to supply the response, or record "no response by deadline"
as the finding. Absence of a response is a documentation finding, not proof of guilt.

## 6A. RED-LINE GATE FORMAT (WHENEVER A REQUEST TOUCHES A RED LINE)
Red lines: payment/order stop, employment action, external or regulatory
report, naming a perpetrator, Audit Committee/Board escalation, engaging
external counsel/forensics, disclosure outside the organisation. The human
must be able to decide in one read, so never act, and never just refuse.
Present each halt exactly as:
- **Context** (facts and evidence status, with refs)
- **Recommendation** (including any less drastic, time-boxed option such as
  evidence preservation)
- **Cost-benefit** (what the action protects vs what it disrupts)
- **Risk of inaction**
- **Required human decision**: APPROVE / MODIFY / ABORT / ESCALATE
Then supply the draft wording or instruction for the human to authorise and
execute. A freeze is time-boxed preservation, never the remediation plan.

## 7. PHASE 6 — FORECAST / EXTRAPOLATE / WHAT-IF
Use references/04-forecast-and-scenarios.md.
- Extrapolate only a measured base rate over a stated horizon; show formula.
- Always show all three scenarios (status quo, partial control, structural
  fix). If the user supplied no inputs for one (e.g. partial-control
  effectiveness), do not drop it: show the formula, apply a clearly labelled
  ILLUSTRATIVE assumption (e.g. 50% reduction) as a placeholder, and list the
  input the user must confirm. Labelled assumptions are allowed; silent ones are not.
- Separate recurring run-rate from one-off items.
- Provide Low / Base / High ranges with the driver of each.
- Model: status quo, partial fix, structural fix; include residual risk,
  remediation cost, benefit, payback, and implementation effort.
- State explicitly what the model cannot predict.

## 8. PHASE 7 — SYNTHESIS AND MIND MAP
Produce:
1. Executive conclusion with confidence and evidence sufficiency status.
2. Findings in IIA 5C format (Condition, Criteria, Cause, Consequence,
   Corrective Action) with SMART owners and dates.
3. CFE Fraud Tactics Mind Map **as hypothesis branches**, labelled
   `TESTED / PARTIALLY TESTED / UNTESTED`, not as established facts.
4. Bottom-up remediation architecture (L1→L5), not temporary freezes.
5. Decision log: options weighed, chosen path, gate approvals.

## 9. PHASE 8 - INDEPENDENT QA (PASS/FAIL BEFORE RELEASE)
Run the 12-item Quality Gate (Rule 09) and independent QA through `gia-report-qa`, by an agent that did not prepare the work. Fraud add-ons in this skill (all must also hold):
- Every claim has a reference or is labelled GAP.
- Every risk has a category and materiality basis.
- At least two benign explanations were tested for each adverse hypothesis.
- No unsupported legal citation, loss figure or named perpetrator.
- Insufficient evidence produces an RFI only, never a conclusion.
- A Class D classification shows at least three independent evidence types (`config/controls.json`).
- Recommendations are structural, owned, measurable, dated.
- Tone is objective; privilege and confidentiality markings are correct.
- Critical actions carry an explicit human approval gate.

## 9A. MODEL AND EFFORT POLICY (Rule 32)
Follow `gia-core:model-effort-routing`. The planner tier plans and decides; it does not execute without user approval. Execution is delegated:
- Haiku, low effort: indexing, extraction, deterministic row flags, table formatting, checklist population.
- Sonnet, medium effort: triage, accounting and legal mapping, synthesis, scenario modelling.
- Sonnet, high effort: QA, statutory validation, fraud wording, Board or regulator-facing drafting, contested evidence, Class D hypotheses, reconciliation across more than three sources, or QA rework twice.
- Never down-shift on red-line decisions, quantification, legal mapping or the final QA gate. Pre-filter cheaply, then spend effort on exceptions.
- QA is always a different agent from the preparer. Log model, effort and trigger in the Decision Log.
- No model identifiers are hard-coded; use the aliases `sonnet` and `haiku` in agent files.
- Re-compute every figure in code and re-check the hardest claims against source rows before release.

## 9B. ENFORCEMENT (OPT-IN HARD CONTROLS)
Instructions can be bypassed, so the plugin ships an enforcement gate. It is OPT-IN for a fraud engagement because its matcher runs on every tool call and would affect other suites:
- To enable: copy `hooks/hooks.rbia-optin.json` to `hooks/hooks.json`, and set `RBIA_APPROVAL_KEY_FILE` outside the agent's reach (`references/ENFORCEMENT.md`). To disable: remove `hooks/hooks.json`.
- `scripts/enforce_gate.py` blocks external or irreversible actions (email, messaging, ticketing and ERP or payment writes, HTTP writes, destructive shell commands) unless a valid, unexpired, human-issued approval token exists in `config/approvals/`. Fail-closed on any parse or verification problem.
- Only the human creates a token (`scripts/approve.py`: action, scope, approver, expiry, hash of the exact draft). Claude never creates, edits or copies a token and never routes around a block: report it and ask.
- Every decision is appended to `audit-log/enforcement.jsonl`.
- These controls protect the Claude host only. ERP, bank and e-mail systems must enforce segregation of duties and approvals on their own side.

## 10. OUTPUT ORDER (DEFAULT)
1. Sufficiency status  2. Judgment + confidence  3. Evidence table
4. Triage  5. Root cause by layer  6. Scenarios  7. Structural remediation
8. Mind map  9. RFI or escalation draft (only if gate criteria met)  10. QA scorecard (from `gia-report-qa`)
