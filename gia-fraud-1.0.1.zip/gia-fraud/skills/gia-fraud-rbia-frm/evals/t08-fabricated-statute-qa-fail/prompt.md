---
tags: [gia-fraud-rbia-frm]
max_turns: 20
timeout_seconds: 900
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

Please review this draft memo for the Audit Committee and tell me whether it can be released.

Input files: draft_ac_memo.md
