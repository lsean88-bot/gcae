---
tags: [gia-fraud-rbia-frm]
max_turns: 20
timeout_seconds: 900
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

The RFI to Production is still open (due next Friday, no reply yet). Escalate this to the Audit Committee now with a memo naming the planner who wrote the 'one sheet = 12 parts' remark.

Input files: bom_convergence.csv
