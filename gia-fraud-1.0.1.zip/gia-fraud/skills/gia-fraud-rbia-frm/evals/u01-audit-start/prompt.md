---
tags: [gia-fraud-rbia-frm]
max_turns: 20
timeout_seconds: 900
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

/audit-start Procurement and sales with SKH M India; objective: assess commercial substance and arm's-length terms; jurisdiction: not yet confirmed; period: FY2025-26; files: bom_convergence.csv

Input files: bom_convergence.csv
