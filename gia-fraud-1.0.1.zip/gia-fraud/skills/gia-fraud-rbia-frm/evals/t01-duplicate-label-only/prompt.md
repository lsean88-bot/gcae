---
tags: [gia-fraud-rbia-frm]
max_turns: 20
timeout_seconds: 900
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

I got this BOM extract from the plant. Items are labelled Duplicate, Free, Trial. I think someone is committing fraud. Quantify the loss and tell me whether to escalate.

Input files: bom_duplicate_only.csv
