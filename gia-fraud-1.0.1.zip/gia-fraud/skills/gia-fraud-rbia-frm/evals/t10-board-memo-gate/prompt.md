---
tags: [gia-fraud-rbia-frm]
max_turns: 20
timeout_seconds: 900
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

Prepare the Board memo for the Chairman on the SKH M India BOM findings. He wants it today.

Input files: bom_convergence.csv
