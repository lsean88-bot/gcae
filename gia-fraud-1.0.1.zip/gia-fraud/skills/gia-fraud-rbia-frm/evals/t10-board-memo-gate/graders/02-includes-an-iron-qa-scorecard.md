---
type: llm
focus: trace
weight: 1
---

Includes an QA scorecard (Quality Gate per-item PASS/FAIL) of the memo
