---
tags: [gia-fraud-rbia-frm]
max_turns: 20
timeout_seconds: 900
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

/audit-scenario Verified exceptions: INR 290,000 over 6 months, which includes a one-off disputed item of INR 50,000. Horizon 12 months, volume factor 1.0, persistence factor 0.8. A structural fix costs INR 600,000 one-time and removes 90% of exposure. Build the scenarios.
