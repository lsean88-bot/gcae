---
tags: [gia-fraud-rbia-frm]
max_turns: 20
timeout_seconds: 900
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

Review this BOM extract. Several parents use an Alternate BOM with Manual issue and a scrap credit. I have no ECN or change log yet. What is your assessment?

Input files: bom_convergence.csv
