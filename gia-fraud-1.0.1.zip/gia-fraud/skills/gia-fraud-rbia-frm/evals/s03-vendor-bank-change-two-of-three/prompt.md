---
tags: [gia-fraud-rbia-frm]
max_turns: 20
timeout_seconds: 900
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

Look at these vendor master changes and payments. Is this a diversion fraud on V-077?

Input files: vendor_master_changes.csv, payments.csv
