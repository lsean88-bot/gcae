---
tags: [gia-fraud-rbia-frm]
max_turns: 20
timeout_seconds: 900
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

/audit-deepdive scope: BOM routing and scrap credit for parents P-1001 to P-1004

Input files: bom_convergence.csv
