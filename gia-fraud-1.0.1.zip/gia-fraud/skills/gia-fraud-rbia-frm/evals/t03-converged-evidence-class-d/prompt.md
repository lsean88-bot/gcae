---
tags: [gia-fraud-rbia-frm]
max_turns: 20
timeout_seconds: 900
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

We now have the BOM extract plus the BOM change log, the authorised-users list, weighbridge scrap tickets and the scrap credit postings for P-1001. Assess it and tell me what happens next.

Input files: bom_convergence.csv, bom_change_log.csv, authorised_users.csv, weighbridge_scrap.csv, scrap_credit_postings.csv
