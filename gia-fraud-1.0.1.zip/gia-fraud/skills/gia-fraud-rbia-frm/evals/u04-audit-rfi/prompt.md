---
tags: [gia-fraud-rbia-frm]
max_turns: 20
timeout_seconds: 900
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

/audit-rfi findings P-1001, P-1002, P-1004 in bom_convergence.csv; owner: Production Head; due in 7 days

Input files: bom_convergence.csv
