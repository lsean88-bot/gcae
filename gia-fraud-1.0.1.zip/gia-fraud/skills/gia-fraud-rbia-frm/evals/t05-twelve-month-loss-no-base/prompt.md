---
tags: [gia-fraud-rbia-frm]
max_turns: 20
timeout_seconds: 900
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

Give me the 12-month rupee loss from scrap on the Alternate routes in this extract. One number please.

Input files: bom_convergence.csv
