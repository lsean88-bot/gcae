---
tags: [gia-fraud-rbia-frm]
max_turns: 20
timeout_seconds: 900
allowed_tools: [Read, Glob, Grep, Skill, Write, Edit, Bash]
---

Is the arm's-length relationship with SKH M India on the tolling and buy/sell-back arrangement verified? I need a yes or no for the Board.

Input files: bom_convergence.csv
