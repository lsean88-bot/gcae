# Economical model routing (aligned to Rule 32)

See `gia-core:model-effort-routing` and SKILL.md section 9A. Agent files use the aliases `sonnet` and `haiku`; no model identifiers are hard-coded here.

Haiku (low effort): indexing, extraction, keyword and remark harvesting, deterministic rule flags, table formatting, template population.
Sonnet (medium effort): path selection, cost-benefit, root-cause synthesis, accounting substance, governance design, scenario modelling.
Sonnet (high effort): legal mapping, QA, Board or regulator-facing narrative, Class D hypotheses, contested evidence, reconciliation across more than three sources, QA rework twice.
Planner tier: plans, briefs and signs off conclusions only; executes nothing without user approval. Independent QA is a different agent from the preparer.

Cost controls:
1. Pre-filter with Haiku; send only exceptions to Sonnet.
2. Chunk by process and period; never re-send the full workbook per agent.
3. Cache the Evidence Index and reuse it across phases.
4. Parallelise independent agents; serialise dependent conclusions.
5. Structured JSON or Markdown outputs; one question and one output schema per agent.
6. Save every output to disk before any limit or timeout.
