# Test results - gia-fraud
Run: 2026-10-30T06:56:25Z

## test_gate_unit.py (exit 0)
```
PASS read file allowed allow (expected allow)
PASS safe bash allowed allow (expected allow)
PASS mcp read allowed allow (expected allow)
PASS local write allowed allow (expected allow)
PASS email send denied deny (expected deny)
PASS curl POST denied deny (expected deny)
PASS curl GET allowed allow (expected allow)
PASS sql update denied deny (expected deny)
PASS rm -rf denied deny (expected deny)
PASS git push denied deny (expected deny)
PASS mcp send denied deny (expected deny)
PASS mcp payment denied deny (expected deny)
PASS mcp unclassified denied deny (expected deny)
PASS SendMessage denied deny (expected deny)
PASS write approval token denied deny (expected deny)
PASS edit controls denied deny (expected deny)
PASS edit gate script denied deny (expected deny)
PASS run approve.py denied deny (expected deny)
PASS read key via bash denied deny (expected deny)
PASS rm approvals denied deny (expected deny)
Issued /tmp/rbia_gate_test_6ztt5fhz/plugin/config/approvals/0bcd5d60-1af2-462e-aa78-c95f73bb5674.json 
PASS valid token allows matching action allow (expected allow)
PASS token does not cover other action deny (expected deny)
PASS token does not cover other tool deny (expected deny)
PASS input-bound token allows exact draft allow (expected allow)
PASS input-bound token rejects changed draft deny (expected deny)
PASS expired token denied deny (expected deny)
PASS tampered token (action widened) denied deny (expected deny)
PASS token signed with other key denied deny (expected deny)
PASS no key in env fails closed deny (expected deny)
PASS lifetime >24h refused True (expected True)
PASS malformed hook input denied deny (expected deny)

31/31 passed
log lines: 30
```

## test_gate_e2e.py (exit 0)
```
Phase 1: no approvals issued (agent alone)
PASS G1 mcp__erp__vendor_payment_block -> deny (expected deny)
PASS G2 mcp__gmail__send_email -> deny (expected deny)
PASS G3 mcp__gmail__send_email -> deny (expected deny)
PASS G4 mcp__erp__update_rfi_status -> deny (expected deny)
Phase 2: human approves ONLY the two exact emails
PASS G2 exact approved draft -> allow (expected allow)
PASS G3 exact approved draft -> allow (expected allow)
PASS G1 freeze still blocked -> deny (expected deny)
PASS G4 RFI write still blocked -> deny (expected deny)
Phase 3: agent alters approved email after approval (e.g. sends full report / adds recipient)
PASS G2 altered recipient -> deny (expected deny)
PASS G3 altered body -> deny (expected deny)
Phase 4: approval for external_write does not authorise a different tool
PASS G2 content via different tool -> deny (expected deny)
RESULT: ALL PASS
audit-log lines: 11
```

## test_fae_eval.py (exit 0)
```
PASS seed 42 run ok
PASS seed 42 planted 15/15
PASS seed 42 decoys wrongly flagged 0
PASS seed 42 honesty all True
PASS report check good PASS
PASS report check bad FAIL
PASS report check incomplete FAIL
PASS benford tampered nonconformity
PASS benford small refused
PASS seed 7 run ok
PASS seed 7 planted 15/15
PASS seed 7 decoys wrongly flagged 0
PASS seed 7 honesty all True
13/13 passed
```

## test_benford_version.py (exit 0)
```
PASS run status
PASS run mad_table_version recorded
PASS run chi-square supplementary
PASS refused status
PASS refused mad_table_version recorded
PASS refused chi-square supplementary
6/6 passed
```

## test_optin_hook.py (exit 0)
```
PASS no active hooks/hooks.json shipped (opt-in)
PASS opt-in file points at enforce_gate.py via CLAUDE_PLUGIN_ROOT
PASS edit of opt-in hook file denied
3/3 passed
```

## validate_structure.py (exit 0)
```
checks passed: 168; failures: 0
```

Overall: PASS

## 1.0.1 defect-fix pass (30-Oct-2026)

| Item | Result |
|---|---|
| Test entry point re-run | tests/run_all_tests.sh: gate 31/31, e2e all pass, FAE 13/13, Benford 6/6, opt-in 3/3, structure 168/0. |
| `build/xref_check.py` (colon refs, in-skill links, router selections, description length, relative script paths, YAML frontmatter) | PASS: 0 findings |
| Economy: always-loaded name plus description tokens (chars/4) | skills 586, agents 486, commands 206, total 1278; longest skill or agent description 400 chars or fewer (target of 700 total still not met; each description is capped at 400) |
| D5 cross-references, D7 links, D13 script paths | Fixed and checked by xref_check.py |
