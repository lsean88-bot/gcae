#!/bin/sh
# Run from anywhere. Writes tests/RESULTS.md from real output (exit code recorded per test).
D=$(cd "$(dirname "$0")/.." && pwd)
OUT="$D/tests/RESULTS.md"
T=$(mktemp)
FAIL=0
{
echo "# Test results - gia-fraud"
echo "Run: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
for t in test_gate_unit.py test_gate_e2e.py test_fae_eval.py test_benford_version.py test_optin_hook.py; do
  python3 -I "$D/tests/$t" > "$T" 2>&1; rc=$?
  [ $rc -ne 0 ] && FAIL=1
  echo; echo "## $t (exit $rc)"; echo '```'; tail -40 "$T"; echo '```'
done
python3 -I "$D/../validate_structure.py" "$D" > "$T" 2>&1; rc=$?
[ $rc -ne 0 ] && FAIL=1
echo; echo "## validate_structure.py (exit $rc)"; echo '```'; tail -40 "$T"; echo '```'
echo; echo "Overall: $([ $FAIL -eq 0 ] && echo PASS || echo FAIL)"
} > "$OUT"
rm -f "$T"
grep -E "passed|RESULT|checks passed|^FAIL|^## |Overall" "$OUT"
exit $FAIL
