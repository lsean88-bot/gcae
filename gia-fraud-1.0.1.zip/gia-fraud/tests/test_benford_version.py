"""Benford output must record the MAD table version, in both RUN and NOT_APPLICABLE paths,
and chi-square must be labelled supplementary."""
import json, subprocess, sys, tempfile, random, csv, pathlib
S = pathlib.Path(__file__).resolve().parent.parent / "skills" / "gia-fraud-analytics" / "scripts" / "benford.py"
d = tempfile.mkdtemp(prefix="benf_")
random.seed(5)
def write(name, vals):
    p = pathlib.Path(d) / name
    with open(p, "w", newline="") as f:
        w = csv.writer(f); w.writerow(["id", "amount"])
        for i, v in enumerate(vals): w.writerow([i, f"{v:.2f}"])
    return p
big = write("big.csv", [10 ** random.uniform(1, 5) for _ in range(3000)])
small = write("small.csv", [10 ** random.uniform(1, 5) for _ in range(200)])
res = []
for name, p, want in (("run", big, "RUN"), ("refused", small, "NOT_APPLICABLE")):
    out = pathlib.Path(d) / f"{name}.json"
    r = subprocess.run([sys.executable, str(S), "--input", str(p), "--out", str(out)], capture_output=True, text=True, cwd=str(S.parent))
    doc = json.load(open(out))
    cov = doc["coverage"]
    ok_status = cov["status"] == want
    ok_ver = "mad_table_version" in cov.get("statistics", {}) and "Nigrini" in cov["statistics"]["mad_table_version"]
    ok_chi = want != "RUN" or cov["statistics"].get("chi_square_role", "").startswith("supplementary")
    res.append((name + " status", ok_status)); res.append((name + " mad_table_version recorded", ok_ver)); res.append((name + " chi-square supplementary", ok_chi))
for n, v in res: print("PASS" if v else "FAIL", n)
print(f"{sum(v for _, v in res)}/{len(res)} passed")
sys.exit(0 if all(v for _, v in res) else 1)
