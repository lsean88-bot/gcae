"""Hook is opt-in: no active hooks.json shipped; opt-in file valid; control-plane tamper of the opt-in file is denied."""
import json, os, subprocess, sys, pathlib
R = pathlib.Path(__file__).resolve().parent.parent
res = []
res.append(("no active hooks/hooks.json shipped (opt-in)", not (R / "hooks" / "hooks.json").exists()))
d = json.load(open(R / "hooks" / "hooks.rbia-optin.json"))
cmd = d["hooks"]["PreToolUse"][0]["hooks"][0]["command"]
res.append(("opt-in file points at enforce_gate.py via CLAUDE_PLUGIN_ROOT", "${CLAUDE_PLUGIN_ROOT}/scripts/enforce_gate.py" in cmd))
env = dict(os.environ, CLAUDE_PLUGIN_ROOT=str(R)); env.pop("RBIA_APPROVAL_KEY", None)
inp = {"tool_name": "Edit", "tool_input": {"file_path": str(R / "hooks" / "hooks.rbia-optin.json"), "old_string": "a", "new_string": "b"}}
r = subprocess.run([sys.executable, "-I", str(R / "scripts" / "enforce_gate.py")], input=json.dumps(inp), capture_output=True, text=True, env=env)
res.append(("edit of opt-in hook file denied", '"deny"' in r.stdout))
# cleanup audit log lines written by this test run
log = R / "audit-log" / "enforcement.jsonl"
if log.exists(): log.unlink()
for n, v in res: print("PASS" if v else "FAIL", n)
print(f"{sum(v for _, v in res)}/{len(res)} passed")
sys.exit(0 if all(v for _, v in res) else 1)
