"""Seeded-fraud regression: expect 15/15 planted detected, 0 no-flag decoys wrongly flagged,
coverage honesty, determinism, report checker good=PASS bad/incomplete=FAIL. Seeds 42 and 7."""
import subprocess, sys, pathlib, re
SK = pathlib.Path(__file__).resolve().parent.parent / "skills" / "gia-fraud-analytics"
res = []
for seed in ("42", "7"):
    r = subprocess.run(["sh", "evals/run_eval.sh", seed], cwd=SK, capture_output=True, text=True)
    o = r.stdout
    res.append((f"seed {seed} run ok", r.returncode == 0))
    res.append((f"seed {seed} planted 15/15", "'planted_detected': 15" in o and "'planted_total': 15" in o))
    res.append((f"seed {seed} decoys wrongly flagged 0", "'no_flag_decoys_wrongly_flagged': 0" in o))
    res.append((f"seed {seed} honesty all True", all(f"'{k}': True" in o for k in ("every_test_has_coverage_block", "unconfigured_tests_listed_not_run", "deterministic_across_two_runs"))))
    if seed == "42":
        res.append(("report check good PASS", "report check good: PASS" in o))
        res.append(("report check bad FAIL", "report check bad: FAIL" in o))
        res.append(("report check incomplete FAIL", "report check incomplete: FAIL" in o))
        res.append(("benford tampered nonconformity", "benford_tampered.csv RUN nonconformity" in o))
        res.append(("benford small refused", "benford_small.csv NOT_APPLICABLE" in o))
for n, v in res: print("PASS" if v else "FAIL", n)
print(f"{sum(v for _, v in res)}/{len(res)} passed")
sys.exit(0 if all(v for _, v in res) else 1)
