# Changelog

## 1.0.1 (30-Oct-2026), QA defect fixes (D5, D7, D9 to D15)

- Cross-references: every `gia-*:<name>` now resolves to a built skill, agent or command (short blueprint names replaced with built names).
- Descriptions of all skills and agents are 400 characters or fewer, trigger words first, with the Do NOT use clause kept (one redirect where space was short); all quoted so frontmatter parses as YAML.
- Script paths in skills, commands and agents use `${CLAUDE_PLUGIN_ROOT}/skills/<skill>/scripts/...`.
- Dangling in-skill links fixed or removed; empty directories and caches deleted.
- Wording: scheme noun in the modus operandi library made neutral.
- `references/ENFORCEMENT.md` test commands point to the plugin tests folder.
- Always-loaded name plus description tokens (chars/4): skills 586, agents 486, commands 206, total 1278.

## 1.0.0 - 2026-10-29
Initial consolidated release.
- Built from: fraud analytics plugin (scripts, evals, agents, commands), the Group CAE fraud investigation skill (split in three), the Group CAE fraud v1 skill (unique content migrated), the RBIA/FRM plugin v2.2.0 (skill, agents, commands, enforcement hook, tests), the entity fraud-watch skill, and the GCAE investigation agent (ladder and 10-step chain).
- Added: test ID registry (P/V/J/B/F/OB to FA-*), fraud test library (35 tests, count corrected from "25"), single dated ACFE benchmarks reference, jurisdiction matrix (structure only), FRA register template, preservation notice, fraud tree reference, case register template.
- Changed: Benford output records the MAD table version; chi-square supplementary only; per-digit +/-3/2/1.5% bands removed. Evidence grades E1-E5 replaced by R1-R5. Standard of proof moved to an open Legal dependency with ladder vocabulary. Model routing aligned to Rule 32 (sonnet or haiku, no model IDs). Enforcement hook made opt-in. Case facts and personal names removed from method content.
- Removed: Iron QA agent (use gia-report-qa), financial-cost-accounting agent (moved to gia-analytics), unsupported statistics, motive column in red-flag table.
