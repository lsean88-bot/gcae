---
description: Build a hypothesis-driven fraud-indicator test plan from a scenario
argument-hint: <entity / process / period / trigger>
---
Use the gia-fraud-analytics skill. From the scenario in $ARGUMENTS: state facts vs assumptions, list what is missing and ask for it, then map hypotheses to tests using references/scheme-test-map.md. Output the plan (test, data required, parameters, pre-set exception threshold, confirming procedure) and list schemes that cannot be tested (no script). If the trigger names a person, stop and recommend the allegation-assessment steps in cae-fraud-investigation instead.
