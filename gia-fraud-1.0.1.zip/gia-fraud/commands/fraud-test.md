---
description: Run the fraud-indicator tests on CSV extracts and produce the coverage statement
argument-hint: <paths to extracts and config>
---
Use the fraud-data-analyst agent to run ${CLAUDE_PLUGIN_ROOT}/skills/gia-fraud-analytics/scripts/run_all.py on the extracts in $ARGUMENTS, then the fraud-adversarial-reviewer agent on HIGH and MEDIUM exceptions. Present: coverage statement (including tests not run), exception counts, adversarial results, and the triage list command. Do not conclude on intent. Stop for human triage.
