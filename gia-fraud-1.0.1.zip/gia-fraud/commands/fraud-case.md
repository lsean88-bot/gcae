---
description: EXPERIMENTAL (untried end to end). Export promoted exceptions to the redacted HubSpot case workflow
argument-hint: <findings.json>
---
Use the gia-fraud-analytics skill. Confirm that exceptions in $ARGUMENTS have been triaged by a named reviewer and that FA_CASE_SALT is set outside HubSpot. Run ${CLAUDE_PLUGIN_ROOT}/skills/gia-fraud-analytics/scripts/to_hubspot_import.py. Confirm that the HubSpot CSV contains no record identifiers (grep for ids), that the secured register is stored outside HubSpot, and walk through the acceptance tests in references/hubspot-case-workflow.md section 9. Refuse if the case-governance prerequisites in that document are not recorded as done.
