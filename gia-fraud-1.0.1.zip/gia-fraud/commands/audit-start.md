---
description: Start an engagement with clarifying questions, intake, data sufficiency gate and strategic path selection.
argument-hint: "[objective + documents + jurisdiction + period]"
---
Activate skills/gia-fraud-rbia-frm. Execute Phase 0 (Step 0 first) and Phase 1 only.
If materiality basis, jurisdiction, mandate/privilege, period/currency or
distribution are not stated in the arguments, ask them first as ONE short batch
(max 8, multiple-choice where possible, with the reason for each) and wait.
Never default them. If the user says proceed without answering, run the safe
subset only and mark MATERIALITY NOT SET / VERIFY JURISDICTION.
After the answers: objective restatement, Data Sufficiency Register, three paths
with cost-benefit scoring, selected path, model/effort plan, and the first
delegation plan. Do not conclude anything until evidence sufficiency is established.
