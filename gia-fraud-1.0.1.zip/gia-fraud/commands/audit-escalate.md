---
description: Test escalation eligibility, then draft a privileged Audit Committee memo or forensic SOW.
argument-hint: "[evidence status]"
---
First run the Escalation Eligibility checklist in skills/gia-fraud-rbia-frm/references/06-report-and-rfi-templates.md (preconditions also listed in config/controls.json). If fact-
finding is incomplete, return an RFI instead of an escalation. If eligible,
draft memo/SOW with evidence refs, quantification status, counsel routing,
privilege marking and a human approval gate. QA must PASS before release.
