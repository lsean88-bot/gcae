# Migration map - gia-fraud

Status key: PORTED = unique strength carried into the destination; REDIRECT = byte-identical or subset duplicate, replaced by a stub; MERGED; DROPPED (reason).

## Skills
| Old skill | Destination | Status |
|---|---|---|
| fraud-analytics-engine (plugin copy) | `gia-fraud:gia-fraud-analytics` | PORTED (scripts, evals, references, SKILL as-is plus fixes) |
| fraud-analytics-engine (loose copy) | `gia-fraud:gia-fraud-analytics` | REDIRECT (duplicate minus evals) |
| cae-fraud-investigation (mktron-hybrid) | `gia-fraud-investigation`, `gia-fraud-risk-governance`, `gia-fraud-fsf-window-dressing`, `gia-fraud-analytics` references/test-library.md | PORTED (split; section map below) |
| cae-fraud-investigation (mktron-composed-layers) | same | REDIRECT (byte-identical) |
| group-cae-fraud-v2 | same | REDIRECT (name line and banner only differ) |
| group-cae-fraud (v1) | `gia-fraud-investigation`, `gia-fraud-risk-governance` | MERGED, then RETIRE. Repoint inbound references before retiring (persona, fleet roster, fraud coordinator, performance analytics, cost accounting, data reconciliation, payroll audit) |
| investigation (GCAE stub) | `gia-fraud-investigation` | MERGED (AG-008 content only); stub RETIRE |
| rbia-frm-mastermind v2.2.0 | `gia-fraud-rbia-frm` | PORTED |
| rbia-frm-mastermind (loose copy) | `gia-fraud:gia-fraud-rbia-frm` | REDIRECT (broken refs) |
| cae-fraud-watch | `gia-fraud-entity-watch` | MERGED (method only; case facts removed) |

## Unique strengths
| Strength | Source | Destination | Status |
|---|---|---|---|
| Principles table: procedural fairness, need-to-know confidentiality, professional scepticism (+4 shared) | group-cae-fraud v1 :27-37 | gia-fraud-investigation section 1 | PORTED |
| Annual FRA 7 steps, effectiveness scale, residual rating, AC heat map | group-cae-fraud v1 :159-167 | gia-fraud-risk-governance section 3 and fra-register-template.md | PORTED |
| Red flags: reluctance to document decisions; unusual related-party transactions | group-cae-fraud v1 :180 | gia-fraud-investigation references/red-flags-master.md | PORTED |
| Charlie Hills PLAN/VERIFY/EXECUTE/CHECK/LOG | cae-fraud-investigation | gia-fraud-investigation section 2 | PORTED (LOG routed to gia-core:self-learning) |
| Six-phase protocol, preservation notice, interview rules, report structure, tone guardrails | cae-fraud-investigation | gia-fraud-investigation sections 6, 8; references/preservation-notice.md | PORTED (interview sequence: four tiers plus counsel before subject) |
| Fraud ladder, 10-step chain, beneficial ownership, retrospective documents, impact ladder, containment | GCAE AG-008 | gia-fraud-investigation sections 3, 5 | PORTED |
| COSO FRMG principles, three lines, policy set, T.R.U.S.T, whistleblower standards, COSO remediation map | cae-fraud-investigation Pillars 1, 2, 5 | gia-fraud-risk-governance | PORTED |
| ABAC checklist, jurisdiction matrix, FCPA vs UKBA | cae-fraud-investigation | gia-fraud-risk-governance references | PORTED (penalties and dates moved out to the statutory register) |
| ACFE fraud tree taxonomy | cae-fraud-investigation 3.1 | gia-fraud-investigation references/fraud-tree.md | PORTED (statistics removed) |
| Window dressing, off-balance-sheet, revenue recognition red flags | cae-fraud-investigation 3.2 | gia-fraud-fsf-window-dressing | PORTED |
| P/V/J/B/F tests, OB checklist, window-dressing protocols, prompts | financial-fraud-analytics.md | test-library.md; window-dressing-protocols.md; analytics-prompts.md | PORTED (header corrected to 35 tests) |
| Modus-operandi library, red-flags master, investigation templates | cae-fraud-investigation references | gia-fraud-investigation references | PORTED (case example and names removed) |
| Continuous monitoring schedule | cae-fraud-investigation 5.2 | gia-analytics:gia-continuous-assurance | PORTED (other plugin) |
| 7-question post-case loop | cae-fraud-investigation 5.4 | gia-fraud-investigation section 9 | PORTED |
| 8 rules, 7 scripts, triage, check_report, HubSpot export, seeded eval | fraud analytics plugin | gia-fraud-analytics | PORTED |
| Phase 0 clarifying questions, Class A-D triage, L0-L5 diagnosis, red-line gate, scenarios | rbia-frm-mastermind | gia-fraud-rbia-frm | PORTED |
| Enforcement gate, HMAC approval tokens, audit log, 20 evals | rbia-frm-mastermind | gia-fraud-rbia-frm; scripts/; tests/ | PORTED (opt-in) |
| Hard no-notification gate, single case reference, closure memo, conservative exposure | cae-fraud-watch | gia-fraud-entity-watch | PORTED |
| Evidence grades E1-E5 | cae-fraud-investigation | none | DROPPED (R1-R5 canonical) |
| Benford +/-3/2/1.5% bands, chi-square p<0.05 escalation | cae-fraud-investigation, v1, payroll audit | none | DROPPED (unsourced; replaced by MAD standard) |
| "Beyond reasonable doubt" for substantiated | cae-fraud-investigation :440 | open Legal dependency | DROPPED |
| ACFE 2024 statistics, SEC enforcement share, "significantly reduces false positives", "96% vs 75% pass rate" | various | none (benchmarks file holds placeholders) | DROPPED (stale or unsourced) |
| Agentic AI four agent types table | cae-fraud-investigation 3.5 | none | DROPPED (descriptive, no operating content); human-in-the-loop principle PORTED to analytics rules |
| Iron QA gate agent and its 10 rules | rbia | `gia-report-qa` | REPLACED (rbia add-ons kept in SKILL section 9) |
| Entity case facts, named matters, amounts | cae-fraud-watch, modus-operandi library, cae-fraud-investigation | owner-maintained case register template | REMOVED from method |

## Components
| Old | New | Status |
|---|---|---|
| fraud-data-analyst, fraud-adversarial-reviewer, fraud-evidence-reviewer | same names | PORTED (model sonnet, effort noted) |
| fraud-analyst (entity group plugin) | fraud-data-analyst + gia-fraud-entity-watch | MERGED |
| beta-analyst (fraud tests) | fraud-data-analyst (integrity checks first); recon part to gia-analytics:recon-analyst | MERGED |
| fraud-investigation-coordinator | fraud-coordinator | PORTED (always-route-to-Board replaced by human-gated routing) |
| rbia agents (orchestrator, forensic-data, evidence-custodian, master-data-process, forecasting-scenario, ethics-abc, legal-compliance, governance-strategy) | same (orchestrator renamed rbia-orchestrator) | PORTED (aliases sonnet and haiku) |
| rbia financial-cost-accounting | gia-analytics:cost-accounting-analyst | MOVED |
| rbia iron-qa-gate | gia-report-qa | REPLACED |
| GCAE fraud AG-008 | gia-fraud-investigation content | HARVESTED (agent dropped) |
| commands fraud-plan, fraud-test, fraud-case | same | PORTED (fraud-case experimental) |
| commands audit-start, -deepdive, -mindmap, -rfi, -scenario, -escalate | same | PORTED |
| hook enforce_gate + approve.py + controls.json | scripts/, config/, hooks/hooks.rbia-optin.json | PORTED (opt-in; one regex extended to protect the opt-in hook file) |

## Section map - cae-fraud-investigation (599 lines)
Charlie Hills and architecture: investigation s2. Pillar 1: risk-governance s1-4. Pillar 2: risk-governance s5 and references. 3.1: fraud-tree.md. 3.2: fsf skill. 3.3-3.4: modus-operandi-library and red-flags-master. 3.5: dropped/ported as above. 3.6 Benford: analytics. Pillar 4: investigation s6. Pillar 5: risk-governance s6-7, investigation s9, continuous-assurance.

## Decisions still needed (owner)
Standard of proof (Group Legal); verify ACFE 2026 figures, Benford MAD table, ISO 37001 edition, ABAC penalties (statutory validator); confirm entity code MKSDL; independent validation of FA scripts; HubSpot flow sign-off.
