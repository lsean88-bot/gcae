# gia-fraud

Fraud investigation, fraud risk governance and tested fraud-indicator analytics for Group Internal Audit. Version 1.0.0.

## Skills (6)
| Skill | Use for |
|---|---|
| `gia-fraud-investigation` | Allegation triage, preservation, evidence, interviews, fraud ladder, investigation report |
| `gia-fraud-risk-governance` | Annual fraud risk assessment, COSO principles, ABAC review, whistleblower standards |
| `gia-fraud-analytics` | Seven tested scripts (vendor, threshold, duplicate, journal, payroll, Benford), triage, report check, test ID registry |
| `gia-fraud-fsf-window-dressing` | Financial-statement fraud, cut-off, window dressing, off-balance-sheet checklist |
| `gia-fraud-rbia-frm` | RBIA/FRM orchestration, context-first triage, red-line gates, scenario forecast |
| `gia-fraud-entity-watch` | Case register discipline, always-run analytics, hard no-notification gate |

## Agents (12) and commands (9)
Agents: fraud-data-analyst, fraud-adversarial-reviewer, fraud-evidence-reviewer, fraud-coordinator, rbia-orchestrator, forensic-data, evidence-custodian, master-data-process, forecasting-scenario, ethics-abc, legal-compliance, governance-strategy. All pinned to sonnet or haiku; reviewers are read-only.
Commands: /fraud-plan, /fraud-test, /fraud-case (experimental), /audit-start, /audit-deepdive, /audit-mindmap, /audit-rfi, /audit-scenario, /audit-escalate.

## Enforcement hook (opt-in)
`hooks/hooks.rbia-optin.json` is not active by default because its matcher covers every tool call. To enable for a fraud engagement, copy it to `hooks/hooks.json` and set `RBIA_APPROVAL_KEY_FILE` outside the agent's reach (`skills/gia-fraud-rbia-frm/references/ENFORCEMENT.md`).

## Tests
`sh tests/run_all_tests.sh` runs the seeded-fraud evaluation (15/15 planted, 0 of 5 decoys flagged), the enforcement gate tests (31 unit, end-to-end), Benford version check, hook opt-in check and structure validation. Results: `tests/RESULTS.md`.

## Standards applied
Evidence R1-R5 and rules by number: `gia-core:iron-rules`. Fraud ladder: weakness, indicator, suspicion, allegation, corroborated, substantiated; never motive. No statutory figures inline: read the jurisdiction statutory register. Test IDs: P/V/J/B/F/OB objectives and FA-* script IDs via one registry.

## Open dependencies
1. Standard of proof for "substantiated": Group Legal decision pending.
2. ABAC penalties: [UNVERIFIED] until the validator fills them; ACFE 2026 figures and Benford MAD bands are secondary-only (checked 2026-10-29); ISO 37001:2025 verified.
3. Independent (non-author) validation of the FA scripts has not been done; the seeded evaluation is a regression test only.
4. The HubSpot case workflow has not been run end to end.
5. Entity code: MKSDL (alias MKSLD); Owner to confirm.

## Cross-suite
`gia-core` (iron rules, routing, self-learning), `gia-audit` (statutory registers), `gia-analytics` (continuous assurance, payroll tests), `gia-report-qa` (QA, Board wording).
