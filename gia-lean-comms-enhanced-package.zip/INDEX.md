# GIA enhanced package: index (v1.4.0)

Start with `gia-lean-comms/ACTION_PLAN.md`, then `UAT_REPORT.md`. To rehearse the whole plan on your own copy first:
`bash gia-lean-comms/tests/rehearse_action_plan.sh`.

| Path | What |
|---|---|
| `gia-lean-comms/` | The plugin: skill, 14 scripts, seed fixtures, 20 trigger evals, templates, 217 tests, 10 applied patches, 4 owner-decision patches, the rehearsal evidence (`action-results/`), plan, critique, live-verification guide, report |
| `gia-lean-comms.skill` | Upload-ready skill alone (passes the strict claude.ai validator); excludes tests, patches, evals |
| `patched-skills/` | Full copies of the 6 portfolio skills the 10 applied patches touch (`sp-global_funding-digest` goes back to `sp-global:funding-digest`) |
| `SHA256SUMS` | `sha256sum -c SHA256SUMS` |

The 4 owner-decision patches are NOT applied in these folders. Your registry and baseline are created on your machine by
`portfolio_gates.sh --bootstrap` and live in `~/.gia-lean-comms`. Requires Python 3.7+ with PyYAML, bash, GNU `date`, `patch`.
