"""Tests for retire_copy, verify_actions and the gates runner's --roots option. Every safety rule in
retire_copy's docstring has a test; the whole-token and ignore tests come from real blockers seen when
the tool was first run on the actual portfolio (a bare name matched inside the canonical's prefixed name;
raw evidence logs and fixtures were counted as live references)."""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SC = ROOT / "skills" / "gia-lean-comms" / "scripts"
MOUNTED = Path("/mnt/skills/plugins/skill-factory").is_dir()
sys.path.insert(0, str(SC))
import registry_check as rc  # noqa: E402
import retire_copy as rt  # noqa: E402


def skill(root, name, body="body\n"):
    d = Path(root, name)
    (d / "data").mkdir(parents=True, exist_ok=True)
    (d / "SKILL.md").write_text(f"---\nname: {name.split(':')[-1]}\ndescription: d\n---\n{body}")
    (d / "data" / "x.txt").write_text(f"data of {name}\n")
    return d


class World:
    """canonical `loop` + stale `mk:loop`, a clean third skill, and a registry declaring them."""

    def __init__(self, status="stale_copy"):
        self.t = tempfile.TemporaryDirectory()
        b = Path(self.t.name)
        self.u, self.p, self.arch, self.state = b / "user", b / "plugins", b / "archive", b / "state"
        self.u.mkdir(); self.p.mkdir(); self.state.mkdir()
        skill(self.u, "loop", "canonical\n")
        skill(self.p, "mk:loop", "stale ancestor\n")
        skill(self.p, "other", "unrelated\n")
        self.roots = [str(self.u), str(self.p)]
        self.reg = self.state / "reg.json"
        self.reg.write_text(json.dumps({"collisions": [{
            "base": "loop", "status": status, "evidence": {}, "owner_action": "",
            "canonical": {"path": "user/loop", "role": "canonical", "sha256": rc.sha(self.u / "loop")},
            "others": [{"path": "plugins/mk:loop", "role": "stale", "sha256": rc.sha(self.p / "mk:loop")}]}],
            "aliases": [], "content_duplicates": [], "superseded": []}))

    def run(self, *a):
        return subprocess.run([sys.executable, str(SC / "retire_copy.py"), *a, "--registry", str(self.reg),
                               "--roots", *self.roots], capture_output=True, text=True)

    def close(self):
        self.t.cleanup()


class RetireCopy(unittest.TestCase):
    def setUp(self):
        self.w = World()
        self.addCleanup(self.w.close)

    def apply(self, *extra):
        return self.w.run("apply", "--yes", "--archive", str(self.w.arch), *extra)

    def manifest(self):
        return next(self.w.arch.glob("*/MANIFEST.json"))

    def test_plan_changes_nothing_and_lists_the_candidate(self):
        before = rc.sha(self.w.p / "mk:loop")
        r = self.w.run("plan")
        self.assertEqual(r.returncode, 0, r.stdout)
        self.assertIn("[RETIRE] loop", r.stdout)
        self.assertTrue((self.w.p / "mk:loop").exists())
        self.assertEqual(rc.sha(self.w.p / "mk:loop"), before)
        self.assertFalse(self.w.arch.exists())

    def test_apply_needs_yes_and_an_archive(self):
        self.assertEqual(self.w.run("apply", "--archive", str(self.w.arch)).returncode, 1)
        self.assertEqual(self.w.run("apply", "--yes").returncode, 1)
        self.assertTrue((self.w.p / "mk:loop").exists())

    def test_archive_inside_a_root_is_refused(self):
        r = self.w.run("apply", "--yes", "--archive", str(self.w.u / "arch"))
        self.assertEqual(r.returncode, 1)
        self.assertIn("outside every skills root", r.stdout)
        self.assertTrue((self.w.p / "mk:loop").exists())

    def test_apply_moves_never_deletes_and_records_whole_folder_hashes(self):
        orig_tree = rt.tree_hash(self.w.p / "mk:loop")
        self.assertEqual(self.apply().returncode, 0)
        self.assertFalse((self.w.p / "mk:loop").exists())
        man = json.loads(self.manifest().read_text())
        moved = man["moved"][0]
        self.assertEqual(moved["tree_sha256"], orig_tree)
        self.assertEqual(rt.tree_hash(moved["to"]), orig_tree)
        self.assertTrue((Path(moved["to"]) / "data" / "x.txt").exists())          # subfolders came along

    def test_canonical_is_never_touched(self):
        before = rt.tree_hash(self.w.u / "loop")
        self.apply()
        self.assertEqual(rt.tree_hash(self.w.u / "loop"), before)

    def test_registry_drops_the_retired_copy_and_declares_an_alias_so_citations_still_resolve(self):
        self.apply()
        reg = json.loads(self.w.reg.read_text())
        self.assertEqual(reg["collisions"], [])
        self.assertIn(["mk:loop", "loop"], [a["names"] for a in reg["aliases"]])
        self.assertTrue(Path(str(self.w.reg) + ".bak").exists())

    def test_rollback_restores_the_folder_and_registry_byte_for_byte(self):
        orig_tree, orig_reg = rt.tree_hash(self.w.p / "mk:loop"), self.w.reg.read_text()
        self.apply()
        r = subprocess.run([sys.executable, str(SC / "retire_copy.py"), "rollback", str(self.manifest()), "--yes"],
                           capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stdout)
        self.assertEqual(rt.tree_hash(self.w.p / "mk:loop"), orig_tree)
        self.assertEqual(self.w.reg.read_text(), orig_reg)

    def test_rollback_is_blocked_if_the_archive_was_modified(self):
        self.apply()
        man = json.loads(self.manifest().read_text())
        Path(man["moved"][0]["to"], "SKILL.md").write_text("tampered")
        r = subprocess.run([sys.executable, str(SC / "retire_copy.py"), "rollback", str(self.manifest()), "--yes"],
                           capture_output=True, text=True)
        self.assertEqual(r.returncode, 1)
        self.assertIn("modified", r.stdout)

    def test_rollback_without_manifest_is_incomplete(self):
        r = subprocess.run([sys.executable, str(SC / "retire_copy.py"), "rollback", "/nope.json"], capture_output=True, text=True)
        self.assertEqual(r.returncode, 2)

    def test_a_stale_copy_changed_since_declared_is_blocked(self):
        skill(self.w.p, "mk:loop", "edited after the declaration\n")
        r = self.w.run("plan")
        self.assertIn("changed since it was declared", r.stdout)
        self.assertEqual(self.apply().returncode, 1)
        self.assertTrue((self.w.p / "mk:loop").exists())

    def test_a_changed_canonical_is_blocked(self):
        skill(self.w.u, "loop", "canonical edited\n")
        self.assertIn("canonical copy changed", self.w.run("plan").stdout)

    def test_a_path_bearing_reference_blocks_until_repointed_or_acknowledged(self):
        ref = self.w.p / "other" / "SKILL.md"
        ref.write_text("---\nname: other\ndescription: d\n---\nRead `mk:loop`'s data/x.txt first.\n")
        r = self.w.run("plan")
        self.assertIn("[BLOCKED]", r.stdout)
        self.assertEqual(self.apply().returncode, 1)
        ref.write_text("---\nname: other\ndescription: d\n---\nRead `loop`'s data/x.txt first.\n")   # repointed
        self.assertEqual(self.apply().returncode, 0)

    def test_acknowledging_references_is_recorded_in_the_manifest(self):
        (self.w.p / "other" / "SKILL.md").write_text("---\nname: other\ndescription: d\n---\nSee `mk:loop` data/x.txt\n")
        self.assertEqual(self.apply("--accept-refs", "loop").returncode, 0)
        moved = json.loads(self.manifest().read_text())["moved"][0]
        self.assertEqual(len(moved["acknowledged_references"]), 1)

    def test_plain_name_mentions_do_not_block(self):
        (self.w.p / "other" / "SKILL.md").write_text("---\nname: other\ndescription: d\n---\nUse the mk:loop skill.\n")
        self.assertEqual(self.w.run("plan").returncode, 0)

    def test_bare_name_does_not_match_inside_a_prefixed_canonical_name(self):
        """Real bug: stale bare `x` is a substring of canonical `ns:x`; references to the canonical must not block."""
        with tempfile.TemporaryDirectory() as d:
            pb, plain = rt.references("loop", [d], Path(d, "nope"))
            self.assertEqual((pb, plain), ([], []))
            Path(d, "f.md").write_text("see `ns:loop` data/x.txt and ns:loop/references/y.md\n")
            self.assertEqual(rt.references("loop", [d], Path(d, "nope")), ([], []))
            Path(d, "g.md").write_text("see `loop` data/x.txt\n")
            self.assertEqual(len(rt.references("loop", [d], Path(d, "nope"))[0]), 1)

    def test_raw_evidence_logs_and_seed_fixtures_are_ignored_by_default(self):
        for rel in ("references/drift-check-2026-09-27.md", "references/seed/baseline.seed.txt"):
            f = self.w.p / "other" / rel
            f.parent.mkdir(parents=True, exist_ok=True)
            f.write_text("mk:loop/references/x.md and mk:loop data/x.txt\n")
        self.assertEqual(self.w.run("plan").returncode, 0)

    def test_needs_merge_review_requires_an_explicit_acknowledgement(self):
        w = World(status="needs_merge_review")
        self.addCleanup(w.close)
        r = w.run("plan")
        self.assertIn("needs_merge_review", r.stdout)
        self.assertEqual(w.run("apply", "--yes", "--archive", str(w.arch)).returncode, 1)
        self.assertTrue((w.p / "mk:loop").exists())
        self.assertEqual(w.run("apply", "--yes", "--archive", str(w.arch), "--merge-reviewed", "loop").returncode, 0)
        self.assertTrue(json.loads(next(w.arch.glob("*/MANIFEST.json")).read_text())["moved"][0]["merge_reviewed"])

    def test_only_stale_roles_are_candidates(self):
        reg = json.loads(self.w.reg.read_text())
        reg["collisions"][0]["others"][0]["role"] = "launcher"
        self.w.reg.write_text(json.dumps(reg))
        self.assertIn("0 stale copy", self.w.run("plan").stdout)

    def test_missing_registry_is_incomplete(self):
        self.w.reg.unlink()
        self.assertEqual(self.w.run("plan").returncode, 2)


class VerifyActions(unittest.TestCase):
    def setUp(self):
        self.w = World()
        self.addCleanup(self.w.close)

    def verify(self, *a):
        return subprocess.run([sys.executable, str(SC / "verify_actions.py"), "--roots", *self.w.roots,
                               "--registry", str(self.w.reg), *a], capture_output=True, text=True)

    def test_clean_state_passes_every_check(self):
        r = self.verify()
        self.assertEqual(r.returncode, 0, r.stdout)
        self.assertIn("checks passed", r.stdout)

    def test_after_retirement_the_archive_and_registry_are_verified(self):
        self.w.run("apply", "--yes", "--archive", str(self.w.arch))
        man = next(self.w.arch.glob("*/MANIFEST.json"))
        r = self.verify("--manifest", str(man))
        self.assertEqual(r.returncode, 0, r.stdout)
        self.assertIn("archived intact", r.stdout)

    def test_a_tampered_archive_fails_verification(self):
        self.w.run("apply", "--yes", "--archive", str(self.w.arch))
        man = next(self.w.arch.glob("*/MANIFEST.json"))
        moved = json.loads(man.read_text())["moved"][0]
        Path(moved["to"], "data", "x.txt").write_text("changed")
        r = self.verify("--manifest", str(man))
        self.assertEqual(r.returncode, 1)
        self.assertIn("FAIL  retired folders are archived intact", r.stdout)

    def test_a_modified_canonical_fails_verification(self):
        skill(self.w.u, "loop", "silently edited\n")
        r = self.verify()
        self.assertEqual(r.returncode, 1)
        self.assertIn("FAIL  every declared canonical copy", r.stdout)

    def test_stray_orig_backups_fail_verification(self):
        (self.w.p / "other" / "SKILL.md.orig").write_text("x")
        self.assertEqual(self.verify().returncode, 1)

    def test_missing_registry_is_incomplete(self):
        self.w.reg.unlink()
        self.assertEqual(self.verify().returncode, 2)

    def test_claude_md_promotion_is_checked(self):
        md = Path(self.w.t.name, "CLAUDE.md")
        md.write_text("# rules\n")
        self.assertEqual(self.verify("--claude-md", str(md)).returncode, 1)
        md.write_text("A skipped check is not a pass.\n")
        self.assertEqual(self.verify("--claude-md", str(md)).returncode, 0)

    def test_expect_s1_fails_when_the_supplement_is_absent(self):
        for n in ("cae-fieldwork-engine", "cae-cowork-ai-plugin"):
            skill(self.w.u, n, "no supplement here\n")
        r = self.verify("--expect-s1")
        self.assertEqual(r.returncode, 1)
        self.assertIn("FAIL  both v6 engine copies carry", r.stdout)


@unittest.skipUnless(MOUNTED, "portfolio not mounted")
class GatesRunnerRoots(unittest.TestCase):
    def test_roots_option_scans_those_roots_not_the_default_mount(self):
        w = World()
        self.addCleanup(w.close)
        with tempfile.TemporaryDirectory() as st:
            env = dict(os.environ, GIA_STATE_DIR=st)
            boot = subprocess.run(["bash", str(SC / "portfolio_gates.sh"), "--roots", " ".join(w.roots), "--bootstrap", "--yes"],
                                  capture_output=True, text=True, env=env)
            self.assertEqual(boot.returncode, 0, boot.stdout[-500:])
            reg = json.loads(Path(st, "portfolio-registry.json").read_text())
            self.assertEqual([c["base"] for c in reg["collisions"]], ["loop"])     # only OUR roots were scanned
            again = subprocess.run(["bash", str(SC / "portfolio_gates.sh"), "--roots", " ".join(w.roots)],
                                   capture_output=True, text=True, env=env)
            self.assertEqual(again.returncode, 0, again.stdout[-600:])
            self.assertIn("3 skills", again.stdout.replace("skills scanned", "skills"))


class ApplyPatchesLeavesNoPollution(unittest.TestCase):
    """verify_actions.py found that apply_patches.sh left SKILL.md.orig files inside the skill folders."""

    def test_backups_go_to_the_state_dir_not_beside_the_skill(self):
        with tempfile.TemporaryDirectory() as d:
            root, state = Path(d, "root"), Path(d, "state")
            f = root / "plugins" / "foo" / "SKILL.md"
            f.parent.mkdir(parents=True)
            f.write_text("line1\nline2\nline3\n")
            patches = Path(d, "patches")
            patches.mkdir()
            new = Path(d, "new.md")
            new.write_text("line1\nLINE-TWO\nline3\n")
            diff = subprocess.run(["diff", "-u", "--label", "a/plugins/foo/SKILL.md", "--label", "b/plugins/foo/SKILL.md", str(f), str(new)],
                                  capture_output=True, text=True).stdout
            (patches / "01.patch").write_text(diff)
            env = dict(os.environ, GIA_STATE_DIR=str(state))
            ap = ROOT / "portfolio-patches" / "apply_patches.sh"
            r = subprocess.run(["bash", str(ap), str(root), "--dir", str(patches)], capture_output=True, text=True, env=env)
            self.assertEqual(r.returncode, 0, r.stdout)
            self.assertEqual(f.read_text(), "line1\nLINE-TWO\nline3\n")
            self.assertEqual(list(root.rglob("*.orig")), [])
            backups = list(state.rglob("SKILL.md"))
            self.assertEqual(len(backups), 1)
            self.assertEqual(backups[0].read_text(), "line1\nline2\nline3\n")      # the ORIGINAL content
            rv = subprocess.run(["bash", str(ap), str(root), "--dir", str(patches), "--revert"], capture_output=True, text=True, env=env)
            self.assertEqual(rv.returncode, 0)
            self.assertEqual(f.read_text(), "line1\nline2\nline3\n")


class SelfHostedAudit(unittest.TestCase):
    """The plugin installed inside a skills root must not fail its own audit. Before: the deep audit read
    candidate-location strings in scripts as broken citations."""

    def test_code_paths_are_not_citations_by_default_but_can_be_opted_in(self):
        import interop_check
        with tempfile.TemporaryDirectory() as d:
            sd = skill(d, "s")
            (sd / "scripts").mkdir()
            (sd / "scripts" / "find.sh").write_text("for d in /mnt/skills/user/nowhere/scripts/x.sh /opt/y; do :; done\n")
            (sd / "references").mkdir()
            names = interop_check.index([d])
            self.assertEqual(interop_check.audit_citations(names, [d], deep=True), [])
            f = interop_check.audit_citations(names, [d], deep=True, include_code=True)
            self.assertEqual([x["kind"] for x in f], ["broken_path"])
            (sd / "references" / "n.md").write_text("run /mnt/skills/user/nowhere/scripts/x.sh")
            self.assertEqual(len(interop_check.audit_citations(names, [d], deep=True)), 1)      # docs still checked

    def test_this_plugin_audited_as_a_skills_root_has_zero_errors(self):
        r = subprocess.run([sys.executable, str(SC / "interop_check.py"), "--roots", str(ROOT / "skills"),
                            "--audit-citations", "--deep", "--json"], capture_output=True, text=True)
        errors = [x for x in json.loads(r.stdout)["dangling_citations"] if x["severity"] == "error"]
        self.assertEqual(errors, [], errors)
        self.assertEqual(r.returncode, 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
