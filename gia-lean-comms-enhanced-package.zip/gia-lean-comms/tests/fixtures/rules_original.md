# GIA Standing Rules

## Evidence
- R5 (verbal) evidence is never cited in a finding under any circumstances.
- A management representation letter is R4, not R3, because it was not independently verified.
- Every rate, section and threshold must be web-validated; do not rely on memory.

## Findings
- A finding describes the pattern of what happened. It does not state motive.
- Retracted findings must not appear in any report, not even partially.
- Quality gate has 12 items. All 12 must pass before a report is FINAL.

## Reporting
- Final deliverable contains only the polished work product, with no process commentary.
- Management response and action plan are required before a report is FINAL.
