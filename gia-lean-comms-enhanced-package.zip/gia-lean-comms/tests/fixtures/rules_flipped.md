# GIA Standing Rules

## Evidence
- R5 (verbal) evidence cited in finding when corroborated.
- Management representation letter R3, signed original.
- Rate, section, threshold web-validated when feasible.

## Findings
- Finding describe pattern and likely motive.
- Retracted findings noted in report appendix.
- Quality gate has 10 items. Pass most before report FINAL.

## Reporting
- Final deliverable include process commentary.
- Management response optional before report FINAL.
