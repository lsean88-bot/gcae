# GIA Standing Rules

## Evidence
- R5 (verbal) evidence never cited in a finding, under any circumstances.
- Management representation letter is R4, not R3: not independently verified.
- Every rate, section, threshold must be web-validated; do not rely on memory.

## Findings
- Finding describes pattern of what happened. Does not state motive.
- Retracted findings must not appear in any report, not even partially.
- Quality gate has 12 items. All 12 must pass before report FINAL.

## Reporting
- Final deliverable contains only polished work product, no process commentary.
- Management response and action plan required before report FINAL.
