#!/usr/bin/env bash
# Rehearsal of ACTION_PLAN.md D0-D6 on a FULL COPY of your portfolio. Nothing in the source roots is changed.
# Run it BEFORE acting for real:  bash tests/rehearse_action_plan.sh
#   SRC_USER / SRC_PLUGINS   source skill roots to copy (default /mnt/skills/user, /mnt/skills/plugins)
#   WORK                     scratch folder (default /tmp/gia-rehearsal)
# It uses the plugin's seed registry as the "reviewed registry"; with your own installation use your own
# (bash portfolio_gates.sh --bootstrap, then review). Output ends with PRE/POST verification and a rollback drill.
set -u
PK="$(cd "$(dirname "$0")/.." && pwd)"; SRC_USER="${SRC_USER:-/mnt/skills/user}"; SRC_PLUGINS="${SRC_PLUGINS:-/mnt/skills/plugins}"; WORK="${WORK:-/tmp/gia-rehearsal}"; S=$PK/skills/gia-lean-comms/scripts; AP=$PK/portfolio-patches/apply_patches.sh
R=$WORK/copy; ST=$WORK/state; ARCH=$WORK/archive
rm -rf "$WORK"; mkdir -p "$WORK";  mkdir -p $R/user $R/plugins $ST
cp -a "$SRC_USER"/. $R/user/; for d in "$SRC_PLUGINS"/*/; do n=$(basename "$d"); [ "$n" = gia-lean-comms ] && continue; cp -a "$d" "$R/plugins/$n"; done
export GIA_STATE_DIR=$ST; ROOTS="$R/user $R/plugins"
PRE_N=$(( $(ls "$SRC_USER" | wc -l) + $(find "$SRC_PLUGINS" -mindepth 1 -maxdepth 1 -type d ! -name gia-lean-comms | wc -l) ))
echo "### 0. rehearsal copy: $(ls $R/user | wc -l) user skills + $(ls $R/plugins | wc -l) plugin skills (originals untouched)"
cp $PK/skills/gia-lean-comms/references/seed/portfolio-registry.seed.json $ST/portfolio-registry.json   # the REVIEWED registry (what D0 + your review produces)
bash $S/portfolio_gates.sh --roots "$ROOTS" --write-baseline >/dev/null 2>&1
echo; echo "### D0. state: your reviewed registry in the state dir; baseline for the PRE-action state"
bash $S/portfolio_gates.sh --roots "$ROOTS" | sed -n '/--- 1/,$p' | grep -E "scanned|skills|gap|Registry|RESULT|PASS|FAIL" | sed 's/^/  PRE  /' | cut -c1-150
cp $ST/baseline.txt $WORK/baseline_pre.txt
echo; echo "### PRE-STATE verification (expect: gate gaps present, nothing retired)"
python3 $S/verify_actions.py --roots $ROOTS --expect-s1 2>&1 | sed 's/^/  /' | cut -c1-160

cp $ST/baseline.txt $WORK/baseline_pre.txt 2>/dev/null
echo; echo "### D1 + D2 prerequisites: apply the 4 owner-decision patches (S1 x2, repoint x2) to the rehearsal copy"
bash $AP $R --dir $PK/decision-patches | sed 's/^/  /'
echo; echo "### registry follows the approved change: --refresh (dry run, then --yes)"
python3 $S/registry_check.py --roots $ROOTS --refresh | sed 's/^/  /'
python3 $S/registry_check.py --roots $ROOTS --refresh --yes | tail -1 | sed 's/^/  /'
echo; echo "### D2-D4 retirement PLAN"
python3 $S/retire_copy.py plan --roots $ROOTS --accept-refs pune-india-ops-audit --merge-reviewed akos-enterprise-orchestrator | sed 's/^/  /' | cut -c1-170
echo; echo "### D2-D4 retirement APPLY (archive outside the skills roots)"
python3 $S/retire_copy.py apply --yes --archive $ARCH --roots $ROOTS --accept-refs pune-india-ops-audit --merge-reviewed akos-enterprise-orchestrator | sed 's/^/  /' | cut -c1-190
MAN=$(ls $ARCH/*/MANIFEST.json); echo "  manifest: $MAN"
echo; echo "### POST-STATE verification (every post-condition of the plan)"
python3 $S/verify_actions.py --roots $ROOTS --expect-s1 --manifest $MAN | sed 's/^/  /' | cut -c1-160
echo; echo "### POST-STATE gates (fresh baseline = the new accepted state)"
bash $S/portfolio_gates.sh --roots "$ROOTS" --write-baseline >/dev/null 2>&1
bash $S/portfolio_gates.sh --roots "$ROOTS" | sed -n '/--- 1/,$p' | grep -E "scanned|skills|gap|Registry|Citation|RESULT|PASS|FAIL" | sed 's/^/  /' | cut -c1-150
cp $ST/baseline.txt $WORK/baseline_post.txt; cp $ST/portfolio-registry.json $WORK/registry_post.json
echo; echo "### BEFORE vs AFTER"
echo "  drift finding lines : $(grep -c '^drift:' $WORK/baseline_pre.txt) -> $(grep -c '^drift:' $WORK/baseline_post.txt)"
echo "  gate gaps           : $(grep -c '^gate:' $WORK/baseline_pre.txt) -> $(grep -c '^gate:' $WORK/baseline_post.txt)"
echo "  skill folders       : $PRE_N -> $(( $(ls $R/user | wc -l) + $(ls $R/plugins | wc -l) ))"
echo "  declared collisions : 5 -> $(python3 -c "import json;print(len(json.load(open('$WORK/registry_post.json'))['collisions']))")"
echo; echo "### ROLLBACK DRILL: undo everything retired, prove byte-exact, then re-apply"
python3 $S/retire_copy.py rollback $MAN --yes | sed 's/^/  /' | cut -c1-150
for f in "plugins/mktron-sentinel:self-learning-loop" plugins/pune-india-ops-audit "plugins/akos-enterprise-orchestrator:akos-enterprise-orchestrator"; do diff -rq "$SRC_PLUGINS/${f#plugins/}" "$R/$f" >/dev/null 2>&1 && echo "  byte-identical to the ORIGINAL: $f" || echo "  DIFFERS: $f"; done
python3 $S/retire_copy.py apply --yes --archive ${ARCH}2 --roots $ROOTS --accept-refs pune-india-ops-audit --merge-reviewed akos-enterprise-orchestrator >/dev/null 2>&1; echo "  re-applied: $(ls $R/plugins | wc -l) plugin folders remain"
MAN2=$(ls ${ARCH}2/*/MANIFEST.json); python3 $S/verify_actions.py --roots $ROOTS --expect-s1 --manifest $MAN2 | tail -1 | sed 's/^/  final verify: /'
cp $MAN2 $WORK/MANIFEST.json
