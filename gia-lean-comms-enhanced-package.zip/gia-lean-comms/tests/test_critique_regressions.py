"""Regression tests for defects found by the 2026-10-03 critique of this package. Each test
fails against the code as it was before the fix."""
import io
import json
import multiprocessing as mp
import shutil
import sys
import tempfile
import types
import unittest
from contextlib import redirect_stdout
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SC = ROOT / "skills" / "gia-lean-comms" / "scripts"
REG = ROOT / "skills" / "gia-lean-comms" / "references" / "seed" / "portfolio-registry.seed.json"
MOUNTED = Path("/mnt/skills/plugins/skill-factory").is_dir()
sys.path.insert(0, str(SC))
import registry_check  # noqa: E402
import review_log  # noqa: E402
import zone_guard  # noqa: E402


class ZoneGuardFailsClosed(unittest.TestCase):
    """Before: 15 of 28 audit-related filenames were classed LEAN (non-English names and any
    .csv/.txt/.json/.yaml file), contradicting the documented 'fails closed'."""

    PROTECTED = [
        "审计发现登记册.csv", "调查报告.txt", "发现_草稿.json", "管理层回复.yaml", "舉報記錄.csv",
        "hallazgos_auditoria.csv", "informe_fraude.txt", "respuesta_gerencia.json",
        "penemuan_audit.csv", "laporan_siasatan.txt", "maklum_balas_pengurusan.json",
        "findings_register.csv", "fraud_notes.txt", "payroll_evidence.json",
        "Q3_notes.csv", "interviews.txt", "ghost_employee_list.csv", "data.csv", "export.json", "notes.txt",
        "CLAUDE.MD", "claude.md", "SKILL.MD", "C:\\audit\\IAR_final.docx",
        "/home/u/audit-evidence/parse.py", "/home/u/board/export.sh", "审计报告.py",
    ]

    def test_audit_related_names_and_data_files_are_protected(self):
        leaks = [p for p in self.PROTECTED if zone_guard.classify(path=p)[0] != "PROTECTED"]
        self.assertEqual(leaks, [])

    def test_code_and_run_logs_are_still_lean(self):
        for p in ("run_uat.sh", "scripts/parse.py", "debug.log", "build.js"):
            self.assertEqual(zone_guard.classify(path=p)[0], "LEAN", p)

    def test_data_file_is_lean_only_with_an_explicit_working_chatter_purpose(self):
        self.assertEqual(zone_guard.classify(path="notes.txt")[0], "PROTECTED")
        self.assertEqual(zone_guard.classify(path="notes.txt", purpose="debug the test run output")[0], "LEAN")

    def test_non_english_purposes_are_protected(self):
        for purp in ("整理审计发现登记册", "resumir los hallazgos para la junta", "compile bukti siasatan"):
            self.assertEqual(zone_guard.classify(purpose=purp)[0], "PROTECTED", purp)


class RegistryPortability(unittest.TestCase):
    """Before: entries were located as <root basename>/<folder>, so identical content under
    differently named roots produced a false 'declared_missing' error for every entry; and hashes
    of CRLF checkouts never matched."""

    def test_relabelled_roots_still_resolve(self):
        with tempfile.TemporaryDirectory() as d:
            a, b = Path(d, "claude-skills"), Path(d, "plugin-cache")
            a.mkdir(); b.mkdir()
            (a / "foo").mkdir(); (a / "foo" / "SKILL.md").write_text("---\nname: foo\ndescription: d\n---\none\n")
            (b / "mk:foo").mkdir(); (b / "mk:foo" / "SKILL.md").write_text("---\nname: foo\ndescription: d\n---\ntwo\n")
            h = registry_check.sha
            reg = {"collisions": [{"base": "foo", "status": "stale_copy", "evidence": {}, "owner_action": "",
                                   "canonical": {"path": "user/foo", "role": "canonical", "sha256": h(a / "foo")},
                                   "others": [{"path": "plugins/mk:foo", "role": "stale", "sha256": h(b / "mk:foo")}]}]}
            self.assertEqual([f for f in registry_check.check(reg, [str(a), str(b)]) if f["severity"] == "error"], [])

    def test_hash_is_stable_across_line_endings(self):
        with tempfile.TemporaryDirectory() as d:
            lf, crlf = Path(d, "lf"), Path(d, "crlf")
            for p in (lf, crlf):
                p.mkdir()
            (lf / "SKILL.md").write_bytes(b"---\nname: x\n---\nline\nline2\n")
            (crlf / "SKILL.md").write_bytes(b"---\r\nname: x\r\n---\r\nline\r\nline2\r\n")
            self.assertEqual(registry_check.sha(lf), registry_check.sha(crlf))

    def test_content_change_is_still_detected(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d, "x"); p.mkdir()
            (p / "SKILL.md").write_text("a\n"); h1 = registry_check.sha(p)
            (p / "SKILL.md").write_text("b\n")
            self.assertNotEqual(h1, registry_check.sha(p))

    @unittest.skipUnless(MOUNTED, "portfolio not mounted")
    def test_shipped_registry_passes_on_a_relabelled_copy_of_the_real_portfolio(self):
        reg = json.loads(REG.read_text())
        with tempfile.TemporaryDirectory() as d:
            a, b = Path(d, "claude-skills"), Path(d, "plugin-cache")
            a.mkdir(); b.mkdir()
            entries = [e for c in reg["collisions"] for e in [c["canonical"]] + c["others"]]
            entries += [x for d in reg.get("content_duplicates", []) for x in (d["a"], d["b"])]
            for e in entries:
                top, _, name = e["path"].partition("/")
                if not (( a if top == "user" else b) / name).exists():
                    shutil.copytree(f"/mnt/skills/{top}/{name}", (a if top == "user" else b) / name)
            errors = [f for f in registry_check.check(reg, [str(a), str(b)]) if f["severity"] == "error"]
            self.assertEqual(errors, [])


def _writer(args):
    d, wid, iters = args
    review_log.guard_status = lambda o, c: ("REVIEW", ["x"])      # isolate the critical section
    ns = types.SimpleNamespace(original=f"{d}/o.txt", copy=f"{d}/c.txt", reviewer=f"Reviewer {wid}",
                               decision="approve", note="", log=f"{d}/l.jsonl")
    refused = 0
    with redirect_stdout(io.StringIO()):
        for _ in range(iters):
            refused += (review_log.cmd_record(ns) != 0)
    return refused


class SignoffLogUnderContention(unittest.TestCase):
    """Before: read-then-append was unlocked. 8 writers x 150 attempts broke the hash chain at
    entry 29 and then every later write was refused, so one collision made every approval
    unverifiable."""

    def test_concurrent_writers_never_fork_the_chain(self):
        with tempfile.TemporaryDirectory() as d:
            Path(d, "o.txt").write_text("a")
            Path(d, "c.txt").write_text("b")
            procs, iters = 8, 40
            with mp.Pool(procs) as pool:
                refused = sum(pool.map(_writer, [(d, w, iters) for w in range(procs)]))
            entries = review_log.read_log(f"{d}/l.jsonl")
            ok, bad = review_log.chain_ok(entries)
            self.assertTrue(ok, f"chain broken at entry {bad}")
            self.assertEqual(len(entries), procs * iters)
            self.assertEqual(refused, 0)

    def test_lock_times_out_instead_of_hanging(self):
        import os
        with tempfile.TemporaryDirectory() as d:
            log = os.path.join(d, "l.jsonl")
            with review_log.locked(log):
                started = __import__("time").time()
                with self.assertRaises(TimeoutError):
                    # a second holder in the same process opens its own descriptor, so flock blocks
                    with review_log.locked(log, timeout=0.3):
                        pass
                self.assertLess(__import__("time").time() - started, 3)



# ====================================================================== v1.3 additions
import subprocess  # noqa: E402

import gate_audit  # noqa: E402


def _skill(root, name, body="body\n"):
    d = Path(root, name)
    d.mkdir(parents=True, exist_ok=True)
    (d / "SKILL.md").write_text(f"---\nname: {name.split(':')[-1]}\ndescription: d\n---\n{body}")
    return d


class NearDuplicatesUnderDifferentNames(unittest.TestCase):
    """Before: the registry only compared skills with the SAME folder name, so six near-identical
    pairs with different names (including the v6 engine installed twice) were invisible."""

    BODY = " ".join(f"word{i}" for i in range(400)) + "\n"

    def setUp(self):
        self.t = tempfile.TemporaryDirectory()
        self.u = Path(self.t.name, "user")
        self.u.mkdir()
        _skill(self.u, "alpha", self.BODY)
        _skill(self.u, "beta", self.BODY + "extra line\n")
        self.roots = [str(self.u)]

    def tearDown(self):
        self.t.cleanup()

    def reg(self, **kw):
        return {"collisions": [], "content_duplicates": kw.get("dups", []), "superseded": kw.get("sup", [])}

    def entry(self, name):
        return {"path": f"user/{name}", "sha256": registry_check.sha(self.u / name)}

    def test_undeclared_pair_is_an_error(self):
        errs = [f for f in registry_check.check(self.reg(), self.roots) if f["severity"] == "error"]
        self.assertEqual([e["kind"] for e in errs], ["undeclared_duplicate"])

    def test_declared_pair_passes(self):
        d = {"a": self.entry("alpha"), "b": self.entry("beta"), "min_similarity": 0.9}
        self.assertEqual([f for f in registry_check.check(self.reg(dups=[d]), self.roots) if f["severity"] == "error"], [])

    def test_divergence_below_the_floor_is_an_error(self):
        d = {"a": self.entry("alpha"), "b": self.entry("beta"), "min_similarity": 0.9}
        _skill(self.u, "beta", "completely different text " * 200)
        kinds = {f["kind"] for f in registry_check.check(self.reg(dups=[d]), self.roots)}
        self.assertIn("duplicate_diverged", kinds)

    def test_editing_only_one_copy_warns_but_does_not_fail(self):
        d = {"a": self.entry("alpha"), "b": self.entry("beta"), "min_similarity": 0.9}
        _skill(self.u, "alpha", self.BODY + "a small edit\n")
        fs = registry_check.check(self.reg(dups=[d]), self.roots)
        self.assertEqual([f for f in fs if f["severity"] == "error"], [])
        self.assertIn("duplicate_changed", {f["kind"] for f in fs})

    def test_dissimilar_skills_are_not_flagged(self):
        _skill(self.u, "gamma", "unrelated " * 300)
        errs = [f for f in registry_check.check(self.reg(dups=[{"a": self.entry("alpha"), "b": self.entry("beta")}]),
                                                self.roots) if f["severity"] == "error"]
        self.assertEqual(errs, [])

    def test_superseded_skill_is_reported_as_info(self):
        sup = [{"skill": "alpha", "superseded_by": "beta", "basis": "declared"}]
        fs = registry_check.check(self.reg(dups=[{"a": self.entry("alpha"), "b": self.entry("beta")}], sup=sup), self.roots)
        self.assertIn(("superseded_installed", "info"), {(f["kind"], f["severity"]) for f in fs})

    def test_accepted_collision_is_not_an_open_owner_action(self):
        _skill(self.u, "foo", "one\n")
        p = Path(self.t.name, "plugins")
        p.mkdir()
        _skill(p, "mk:foo", "two\n")
        reg = {"collisions": [{"base": "foo", "status": "distinct_roles", "accepted": True, "owner_action": "none needed",
                               "canonical": {"path": "user/foo", "role": "master", "sha256": registry_check.sha(self.u / "foo")},
                               "others": [{"path": "plugins/mk:foo", "role": "launcher", "sha256": registry_check.sha(p / "mk:foo")}]}]}
        fs = registry_check.check(reg, [str(self.u), str(p)])
        self.assertNotIn("open_owner_action", {f["kind"] for f in fs if f.get("base") == "foo"})


class TwoGateAudit(unittest.TestCase):
    """The first version measured each gate in isolation and over-stated the gap. Coverage is now
    per skill, across every gate that must pass before FINAL."""

    TEN = ("## 10-Item Quality Gate\n\n| 1 | named evidence or web-validated portal |\n| 2 | rate web-validated source URL |\n"
           "| 3 | no duplicate findings |\n| 4 | no retracted draft text |\n| 5 | correct Act effective date jurisdiction |\n"
           "| 6 | risk colour rated |\n| 7 | SMART |\n| 8 | version sign-off |\n| 9 | appendix |\n| 10 | disclaimer |\n")
    CONV = ("### 30-Item QA Checklist \u2014 6 Groups\n\n**Content (1\u20133):** one \u00b7 two \u00b7 deficiency aggregation summary present\n\n"
            "**More (4\u20135):** four \u00b7\nfive\n")

    def audit(self, body):
        with tempfile.TemporaryDirectory() as d:
            _skill(d, "s", body)
            rows = gate_audit.audit([d])
            return rows, gate_audit.per_skill(rows)

    def test_single_gate_alone_misses_two_concepts(self):
        _, sk = self.audit(self.TEN)
        self.assertEqual(next(iter(sk.values()))["union_missing"], ["aggregation", "deficiency_classification"])

    def test_second_gate_covers_aggregation_but_not_classification(self):
        _, sk = self.audit(self.TEN + "\n" + self.CONV.replace("30-Item", "5-Item"))
        self.assertEqual(next(iter(sk.values()))["union_missing"], ["deficiency_classification"])

    def test_grouped_items_are_counted_across_wrapped_lines(self):
        rows, _ = self.audit(self.CONV.replace("30-Item", "5-Item"))
        self.assertEqual((rows[0]["asserted"], rows[0]["enumerated"], rows[0]["count_consistent"]), (5, 5, True))

    def test_group_that_contradicts_its_own_range_is_flagged(self):
        rows, _ = self.audit("### 5-Item QA Checklist\n\n**Group (1\u20135):** a \u00b7 b \u00b7 c\n")
        self.assertFalse(rows[0]["count_consistent"])
        self.assertTrue(rows[0]["group_range_mismatches"])

    def test_registry_marks_superseded_skills_as_legacy_not_gaps(self):
        with tempfile.TemporaryDirectory() as d:
            _skill(d, "old", self.TEN)
            reg = Path(d, "r.json")
            reg.write_text(json.dumps({"superseded": [{"skill": "old"}]}))
            r = subprocess.run([sys.executable, str(SC / "gate_audit.py"), "--roots", d, "--registry", str(reg), "--strict"],
                               capture_output=True, text=True)
            self.assertEqual(r.returncode, 0, r.stdout)
            self.assertIn("[LEGACY]", r.stdout)
            r2 = subprocess.run([sys.executable, str(SC / "gate_audit.py"), "--roots", d, "--strict"], capture_output=True, text=True)
            self.assertEqual(r2.returncode, 1)


@unittest.skipUnless(MOUNTED, "portfolio not mounted")
class DecisionPatches(unittest.TestCase):
    """Owner-decision patches are validated here but are never applied to the live mount."""

    DP_ALL = ROOT / "decision-patches"
    AP = ROOT / "portfolio-patches" / "apply_patches.sh"
    FILES = ["user/cae-fieldwork-engine", "plugins/cae-cowork-ai-plugin"]

    @classmethod
    def setUpClass(cls):
        # S1 tests use only the two S1 patches (01, 02); the repoint patches have their own test below
        cls._tmp = tempfile.TemporaryDirectory()
        cls.DP = Path(cls._tmp.name)
        for p in sorted(cls.DP_ALL.glob("0[12]_*.patch")):
            shutil.copy(p, cls.DP / p.name)

    @classmethod
    def tearDownClass(cls):
        cls._tmp.cleanup()

    def mount(self, d):
        for f in self.FILES:
            top, _, name = f.partition("/")
            shutil.copytree(f"/mnt/skills/{f}", Path(d, top, name))
        return d

    def apply(self, d, *a):
        return subprocess.run(["bash", str(self.AP), d, "--dir", str(self.DP), *a], capture_output=True, text=True)

    def test_live_mount_is_not_patched_by_default(self):
        r = subprocess.run(["bash", str(self.AP), "/mnt/skills", "--dir", str(self.DP_ALL), "--check"], capture_output=True, text=True)
        self.assertEqual(r.stdout.count("needed"), len(list(self.DP_ALL.glob("*.patch"))), r.stdout)
        self.assertNotIn("already", r.stdout)

    def test_patch_closes_exactly_the_documented_gap(self):
        with tempfile.TemporaryDirectory() as d:
            self.mount(d)
            roots = [f"{d}/user", f"{d}/plugins"]
            before = gate_audit.per_skill(gate_audit.audit(roots))
            self.assertEqual({k: v["union_missing"] for k, v in before.items()},
                             {"plugins/cae-cowork-ai-plugin": ["deficiency_classification"],
                              "user/cae-fieldwork-engine": ["deficiency_classification"]})
            self.assertEqual(self.apply(d).returncode, 0)
            after = gate_audit.per_skill(gate_audit.audit([f"{d}/user", f"{d}/plugins"]))
            self.assertTrue(all(v["union_missing"] == [] for v in after.values()), after)

    def test_gate_counts_and_sync_are_preserved_and_revert_is_exact(self):
        with tempfile.TemporaryDirectory() as d:
            self.mount(d)
            self.apply(d)
            rows = gate_audit.audit([f"{d}/user", f"{d}/plugins"])
            self.assertEqual(sorted((r["asserted"], r["enumerated"]) for r in rows),
                             [(10, 10), (10, 10), (30, 30), (30, 30)])
            self.assertGreaterEqual(registry_check.similarity(f"{d}/user/cae-fieldwork-engine",
                                                              f"{d}/plugins/cae-cowork-ai-plugin"), 0.9)
            self.assertEqual(self.apply(d, "--revert").returncode, 0)
            for f in self.FILES:
                self.assertEqual(Path(d, f, "SKILL.md").read_bytes(), Path("/mnt/skills", f, "SKILL.md").read_bytes())

    def test_patch_text_makes_no_claim_about_tool_behaviour(self):
        text = "".join(p.read_text() for p in self.DP_ALL.glob("0[12]_*.patch"))
        self.assertIn("whether or not your build of the tool also checks it", text)
        self.assertNotIn("does not check", text)

    def test_patch_adds_no_new_drift_finding(self):
        D = "/mnt/skills/plugins/iron-rules-governance/scripts/check-governance-drift.sh"

        def findings(scope):
            out = subprocess.run(["bash", D, scope], capture_output=True, text=True).stdout
            lines = [l.replace(scope, "<s>") for l in out.splitlines() if l.startswith("    ")]
            return sorted(set(lines))
        with tempfile.TemporaryDirectory() as d1, tempfile.TemporaryDirectory() as d2:
            for d in (d1, d2):
                for f in self.FILES:
                    shutil.copytree(f"/mnt/skills/{f}", Path(d, f.partition("/")[2]))
            # apply to d2 using a mount-shaped view
            with tempfile.TemporaryDirectory() as m:
                self.mount(m)
                self.apply(m)
                for f in self.FILES:
                    shutil.copy(Path(m, f, "SKILL.md"), Path(d2, f.partition("/")[2], "SKILL.md"))
            import re
            norm = lambda L: [re.sub(r":\d+:", "::", x) for x in L]  # noqa: E731
            self.assertEqual(norm(findings(d1)), norm(findings(d2)))


class LiveVerifyScriptLogic(unittest.TestCase):
    """live_verify.sh needs the real `claude` CLI to measure triggering, which a sandbox lacks. These
    tests drive the SCRIPT with a stub `claude` and a stub runner to prove its decision logic:
    it never reports success unless the criterion was actually met."""

    SCRIPT = SC / "live_verify.sh"

    def run_script(self, results, runner_exit=0, with_claude=True):
        import os
        with tempfile.TemporaryDirectory() as d:
            runner = Path(d, "sc", "scripts")
            runner.mkdir(parents=True)
            Path(runner, "__init__.py").write_text("")
            payload = json.dumps({"skill_name": "x", "results": results, "summary": {}})
            Path(runner, "run_eval.py").write_text(
                f"import sys\nprint({payload!r})\nsys.exit({runner_exit})\n")
            bindir = Path(d, "bin")
            bindir.mkdir()
            if with_claude:
                Path(bindir, "claude").write_text("#!/bin/sh\nexit 0\n")
                Path(bindir, "claude").chmod(0o755)
            env = dict(os.environ, SKILL_CREATOR=str(Path(d, "sc")),
                       PATH=f"{bindir}:/usr/bin:/bin" if with_claude else "/usr/bin:/bin")
            Path(d, "e.json").write_text("[]")
            return subprocess.run(["bash", str(self.SCRIPT), "--skill-path", d, "--evals", str(Path(d, "e.json"))],
                                  capture_output=True, text=True, env=env)

    @staticmethod
    def rows(pos_pass, pos, neg_pass, neg):
        return ([{"should_trigger": True, "pass": i < pos_pass} for i in range(pos)] +
                [{"should_trigger": False, "pass": i < neg_pass} for i in range(neg)])

    def test_no_claude_cli_is_incomplete_not_pass(self):
        r = self.run_script(self.rows(10, 10, 10, 10), with_claude=False)
        self.assertEqual(r.returncode, 2, r.stdout)
        self.assertIn("INCOMPLETE", r.stdout)

    def test_criterion_met(self):
        r = self.run_script(self.rows(9, 10, 10, 10))
        self.assertEqual(r.returncode, 0, r.stdout)
        self.assertIn("MET", r.stdout)

    def test_low_recall_fails(self):
        self.assertEqual(self.run_script(self.rows(7, 10, 10, 10)).returncode, 1)

    def test_false_triggers_fail(self):
        self.assertEqual(self.run_script(self.rows(10, 10, 8, 10)).returncode, 1)

    def test_runner_crash_is_incomplete(self):
        self.assertEqual(self.run_script(self.rows(10, 10, 10, 10), runner_exit=3).returncode, 2)

    def test_empty_results_never_pass(self):
        self.assertNotEqual(self.run_script([]).returncode, 0)


class RegistryRefresh(unittest.TestCase):
    """After an approved change to a registered skill the registry must be re-anchored through a
    reviewed step, not by hand-editing hashes."""

    def setUp(self):
        self.t = tempfile.TemporaryDirectory()
        self.u, self.p = Path(self.t.name, "user"), Path(self.t.name, "plugins")
        self.u.mkdir()
        self.p.mkdir()
        _skill(self.u, "foo", "one\n")
        _skill(self.p, "mk:foo", "two\n")
        h = registry_check.sha
        self.regp = Path(self.t.name, "reg.json")
        self.regp.write_text(json.dumps({"collisions": [{"base": "foo", "status": "stale_copy", "evidence": {}, "owner_action": "",
            "canonical": {"path": "user/foo", "role": "canonical", "sha256": h(self.u / "foo")},
            "others": [{"path": "plugins/mk:foo", "role": "stale", "sha256": h(self.p / "mk:foo")}]}]}))
        self.roots = [str(self.u), str(self.p)]

    def tearDown(self):
        self.t.cleanup()

    def run_rc(self, *a):
        return subprocess.run([sys.executable, str(SC / "registry_check.py"), "--registry", str(self.regp),
                               "--roots", *self.roots, *a], capture_output=True, text=True)

    def test_dry_run_reports_but_does_not_write(self):
        _skill(self.u, "foo", "one, approved edit\n")
        before = self.regp.read_text()
        r = self.run_rc("--refresh")
        self.assertEqual(r.returncode, 0)
        self.assertIn("would update", r.stdout)
        self.assertIn("Dry run", r.stdout)
        self.assertEqual(self.regp.read_text(), before)
        self.assertEqual(self.run_rc().returncode, 1)          # still stale until refreshed

    def test_yes_re_anchors_keeps_a_backup_and_the_gate_passes(self):
        _skill(self.u, "foo", "one, approved edit\n")
        before = self.regp.read_text()
        r = self.run_rc("--refresh", "--yes")
        self.assertEqual(r.returncode, 0, r.stdout)
        self.assertEqual(Path(str(self.regp) + ".bak").read_text(), before)
        self.assertEqual(self.run_rc().returncode, 0)

    def test_nothing_to_refresh_is_clean(self):
        self.assertIn("nothing to refresh", self.run_rc("--refresh").stdout)

    def test_missing_skill_cannot_be_refreshed_and_nothing_is_written(self):
        shutil.rmtree(self.p / "mk:foo")
        before = self.regp.read_text()
        r = self.run_rc("--refresh", "--yes")
        self.assertEqual(r.returncode, 1)
        self.assertIn("MISSING", r.stdout)
        self.assertEqual(self.regp.read_text(), before)
        self.assertFalse(Path(str(self.regp) + ".bak").exists())


@unittest.skipUnless(MOUNTED, "portfolio not mounted")
class AllDecisionPatches(unittest.TestCase):
    """All four owner-decision patches (S1 x2, repoint x2) apply cleanly together and revert exactly."""

    def test_four_patches_apply_revert_and_repoints_remove_the_prefixed_name(self):
        dp = ROOT / "decision-patches"
        ap = ROOT / "portfolio-patches" / "apply_patches.sh"
        patches = sorted(dp.glob("*.patch"))
        self.assertEqual(len(patches), 4)
        with tempfile.TemporaryDirectory() as m, tempfile.TemporaryDirectory() as st:
            env = dict(os.environ, GIA_STATE_DIR=st)
            targets = []
            for p in patches:
                f = [ln for ln in p.read_text().splitlines() if ln.startswith("+++ b/")][0][6:].split("\t")[0]
                targets.append(f)
                Path(m, f).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy(f"/mnt/skills/{f}", Path(m, f))
            r = subprocess.run(["bash", str(ap), m, "--dir", str(dp)], capture_output=True, text=True, env=env)
            self.assertEqual(r.returncode, 0, r.stdout)
            self.assertEqual(r.stdout.count("APPLIED"), 4)
            for f in targets[2:]:
                self.assertNotIn("mktron-sentinel:self-learning-loop", Path(m, f).read_text(), f)
            self.assertEqual(list(Path(m).rglob("*.orig")), [])
            rv = subprocess.run(["bash", str(ap), m, "--dir", str(dp), "--revert"], capture_output=True, text=True, env=env)
            self.assertEqual(rv.returncode, 0)
            for f in targets:
                self.assertEqual(Path(m, f).read_bytes(), Path("/mnt/skills", f).read_bytes(), f)


@unittest.skipUnless(MOUNTED, "portfolio not mounted")
class ActionPlanD1Workflow(unittest.TestCase):
    """The exact command sequence in ACTION_PLAN.md decision D1, run end to end on temp copies."""

    def test_apply_refresh_and_gates_end_to_end(self):
        ap = ROOT / "portfolio-patches" / "apply_patches.sh"
        s1 = tempfile.TemporaryDirectory()
        self.addCleanup(s1.cleanup)
        for p in sorted((ROOT / "decision-patches").glob("0[12]_*.patch")):
            shutil.copy(p, Path(s1.name, p.name))
        dp = Path(s1.name)
        full = json.loads(REG.read_text())
        pair = [d for d in full["content_duplicates"] if "cae-fieldwork-engine" in d["a"]["path"]][0]
        with tempfile.TemporaryDirectory() as m:
            for f in ("user/cae-fieldwork-engine", "plugins/cae-cowork-ai-plugin"):
                shutil.copytree(f"/mnt/skills/{f}", Path(m, f))
            regp = Path(m, "reg.json")
            regp.write_text(json.dumps({"collisions": [], "content_duplicates": [pair], "superseded": []}))
            roots = [f"{m}/user", f"{m}/plugins"]

            def rc(*a):
                return subprocess.run([sys.executable, str(SC / "registry_check.py"), "--registry", str(regp),
                                       "--roots", *roots, *a], capture_output=True, text=True)
            self.assertEqual(rc().returncode, 0)                                   # 1. clean before
            applied = subprocess.run(["bash", str(ap), m, "--dir", str(dp)], capture_output=True, text=True)
            self.assertEqual(applied.returncode, 0, applied.stdout)                # 2. apply the decision patch
            after = rc()
            self.assertEqual(after.returncode, 0)                                  # 3. still no error...
            self.assertIn("duplicate_changed", rc("--json").stdout)                #    ...but it notices the change
            dry = rc("--refresh")
            # 4. exactly the two hashes: both copies changed identically, so their similarity is unchanged
            self.assertEqual(dry.stdout.count("would update"), 2, dry.stdout)
            self.assertNotIn("similarity", dry.stdout)
            self.assertEqual(rc().returncode, 0)                                   #    dry run wrote nothing
            self.assertEqual(rc("--refresh", "--yes").returncode, 0)               # 5. re-anchor after review
            self.assertNotIn("duplicate_changed", rc("--json").stdout)             # 6. no warning remains
            self.assertIn("nothing to refresh", rc("--refresh").stdout)
            gaps = [k for k, v in gate_audit.per_skill(gate_audit.audit(roots)).items() if v["union_missing"]]
            self.assertEqual(gaps, [])                                             # 7. the gate gap is closed


import os  # noqa: E402

import gia_state  # noqa: E402


class StateDirectory(unittest.TestCase):
    """Site state (registry, baseline) lives in a state directory that a plugin update cannot replace.
    Before: both defaulted to paths inside the plugin folder and were anchored to one sandbox."""

    def with_env(self, **env):
        old = {k: os.environ.get(k) for k in ("GIA_STATE_DIR", "GIA_REGISTRY", "GIA_BASELINE")}
        for k in old:
            os.environ.pop(k, None)
        os.environ.update(env)
        self.addCleanup(lambda: [os.environ.pop(k, None) if v is None else os.environ.__setitem__(k, v) for k, v in old.items()])

    def test_precedence_explicit_then_env_file_then_state_dir(self):
        self.with_env(GIA_STATE_DIR="/s", GIA_REGISTRY="/r.json")
        self.assertEqual(str(gia_state.registry_path("/explicit.json")), "/explicit.json")
        self.assertEqual(str(gia_state.registry_path()), "/r.json")
        os.environ.pop("GIA_REGISTRY")
        self.assertEqual(str(gia_state.registry_path()), "/s/portfolio-registry.json")
        self.assertEqual(str(gia_state.baseline_path()), "/s/baseline.txt")

    def test_default_is_outside_the_plugin_folder(self):
        self.with_env()
        for p in (gia_state.registry_path(), gia_state.baseline_path()):
            self.assertNotIn(str(ROOT), str(p))

    def test_no_registry_is_incomplete_never_the_seed(self):
        with tempfile.TemporaryDirectory() as d:
            r = subprocess.run([sys.executable, str(SC / "registry_check.py")], capture_output=True, text=True,
                               env=dict(os.environ, GIA_STATE_DIR=d))
            self.assertEqual(r.returncode, 2)
            self.assertIn("--bootstrap", r.stdout)

    def test_missing_registry_is_incomplete_for_the_other_audits_too(self):
        for script, extra in (("gate_audit.py", []), ("interop_check.py", ["--audit-citations"])):
            r = subprocess.run([sys.executable, str(SC / script), "--registry", "/nope.json", *extra],
                               capture_output=True, text=True)
            self.assertEqual(r.returncode, 2, script)

    def test_seed_files_are_documented_fixtures(self):
        self.assertTrue((ROOT / "skills" / "gia-lean-comms" / "references" / "seed" / "README.md").exists())
        self.assertFalse((ROOT / "skills" / "gia-lean-comms" / "references" / "portfolio-registry.json").exists())
        self.assertFalse((ROOT / "skills" / "gia-lean-comms" / "references" / "baseline.txt").exists())


class Bootstrap(unittest.TestCase):
    BODY = " ".join(f"word{i}" for i in range(400)) + "\n"

    def setUp(self):
        self.t = tempfile.TemporaryDirectory()
        self.u, self.p = Path(self.t.name, "user"), Path(self.t.name, "plugins")
        self.u.mkdir()
        self.p.mkdir()
        _skill(self.u, "foo", "one\n")
        _skill(self.p, "mk:foo", "two\n")
        _skill(self.u, "alpha", self.BODY)
        _skill(self.u, "beta", self.BODY + "extra\n")
        self.roots = [str(self.u), str(self.p)]
        self.reg = Path(self.t.name, "state", "reg.json")

    def tearDown(self):
        self.t.cleanup()

    def rc(self, *a):
        return subprocess.run([sys.executable, str(SC / "registry_check.py"), "--registry", str(self.reg),
                               "--roots", *self.roots, *a], capture_output=True, text=True)

    def test_dry_run_writes_nothing(self):
        r = self.rc("--bootstrap")
        self.assertEqual(r.returncode, 0)
        self.assertIn("Dry run", r.stdout)
        self.assertFalse(self.reg.parent.exists())

    def test_yes_writes_an_unreviewed_registry_that_then_passes(self):
        self.assertEqual(self.rc("--bootstrap", "--yes").returncode, 0)
        reg = json.loads(self.reg.read_text())
        self.assertEqual([c["base"] for c in reg["collisions"]], ["foo"])
        self.assertEqual(reg["collisions"][0]["status"], "unreviewed")
        self.assertEqual(len(reg["content_duplicates"]), 1)
        self.assertEqual(self.rc().returncode, 0)

    def test_bootstrap_makes_no_canonical_choice(self):
        self.rc("--bootstrap", "--yes")
        c = json.loads(self.reg.read_text())["collisions"][0]
        self.assertEqual({c["canonical"]["role"], c["others"][0]["role"]}, {"unreviewed"})
        self.assertIn("Unreviewed", c["owner_action"])

    def test_change_after_bootstrap_is_caught(self):
        self.rc("--bootstrap", "--yes")
        _skill(self.u, "foo", "one, edited\n")
        r = self.rc()
        self.assertEqual(r.returncode, 1)
        self.assertIn("registry_stale", r.stdout)

    def test_a_new_collision_after_bootstrap_is_caught(self):
        self.rc("--bootstrap", "--yes")
        _skill(self.u, "gamma", "three\n")
        _skill(self.p, "mk:gamma", "four\n")
        self.assertIn("undeclared_collision", self.rc().stdout)

    def test_refuses_to_overwrite_then_force_keeps_a_backup(self):
        self.rc("--bootstrap", "--yes")
        self.assertEqual(self.rc("--bootstrap", "--yes").returncode, 1)
        self.assertEqual(self.rc("--bootstrap", "--yes", "--force").returncode, 0)
        self.assertTrue(Path(str(self.reg) + ".bak").exists())


@unittest.skipUnless(MOUNTED, "portfolio not mounted")
class NewInstallationJourney(unittest.TestCase):
    G = SC / "portfolio_gates.sh"

    def gates(self, state, *a):
        return subprocess.run(["bash", str(self.G), *a], capture_output=True, text=True,
                              env=dict(os.environ, GIA_STATE_DIR=str(state)))

    def test_first_run_is_incomplete_and_says_what_to_do(self):
        with tempfile.TemporaryDirectory() as d:
            r = self.gates(Path(d, "s"))
            self.assertEqual(r.returncode, 2, r.stdout)
            self.assertIn("--bootstrap", r.stdout)

    def test_journey_dry_run_accept_then_clean_run(self):
        with tempfile.TemporaryDirectory() as d:
            st = Path(d, "state")
            dry = self.gates(st, "--bootstrap")
            self.assertEqual(dry.returncode, 0, dry.stdout)
            self.assertFalse(st.exists())
            yes = self.gates(st, "--bootstrap", "--yes")
            self.assertEqual(yes.returncode, 0, yes.stdout[-500:])
            self.assertIn("ACCEPTED:", yes.stdout)
            self.assertNotIn("NEW:", yes.stdout)
            self.assertTrue(Path(st, "portfolio-registry.json").exists() and Path(st, "baseline.txt").exists())
            again = self.gates(st)
            self.assertEqual(again.returncode, 0, again.stdout[-600:])
            self.assertIn("PASS", again.stdout)

    def test_the_seed_is_never_used_implicitly(self):
        with tempfile.TemporaryDirectory() as d:
            r = self.gates(Path(d, "s"))
            self.assertEqual(r.returncode, 2)
            self.assertNotIn("PASS", r.stdout)


if __name__ == "__main__":
    unittest.main(verbosity=2)
