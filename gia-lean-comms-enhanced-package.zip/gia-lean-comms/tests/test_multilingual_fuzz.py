"""Multilingual unit tests and a generator-driven property fuzz for meaning_guard.

Why generator-driven: an earlier fuzz located the numbers it mutated with the guard's OWN regexes,
so it shared the guard's blind spot (amounts glued to a currency code were invisible to both) and
could never fail. Here the texts are built from structured segments whose values the generator
knows, so the oracle is independent of the guard:

  * CHANGE   one segment's value -> the guard must not PASS, and must FAIL for hard classes
  * RESTYLE  every segment is re-rendered with the same values in a different but equivalent style
             (RM1,700 / RM 1700.00, 5% / 5 percent, Rule 9 / Rule 09, R5 / R 5, twenty-five / 25,
             full-width digits, extra whitespace) -> the guard must PASS

Seeds are fixed, so a failure is reproducible.
"""
import random
import subprocess
import sys
import unittest
from pathlib import Path

SC = Path(__file__).resolve().parent.parent / "skills" / "gia-lean-comms" / "scripts"
sys.path.insert(0, str(SC))
import meaning_guard as mg  # noqa: E402


def status(o, c):
    errors, warnings = mg.compare(o, c)
    return "FAIL" if errors else ("REVIEW" if warnings else "PASS")


class Multilingual(unittest.TestCase):
    MUST_NOT_PASS = [
        ("Chinese must-not -> may", "第三方证据不得引用于调查结论。", "第三方证据可引用于调查结论。"),
        ("Traditional Chinese", "口頭證據禁止用於審計發現。", "口頭證據用於審計發現。"),
        ("Malay tidak boleh -> boleh", "Bukti lisan tidak boleh digunakan.", "Bukti lisan boleh digunakan."),
        ("Spanish nunca -> debe", "La evidencia nunca debe citarse.", "La evidencia debe citarse."),
        ("Spanish sin dropped", "Informe sin hallazgos retirados.", "Informe con hallazgos retirados."),
        ("currency RM -> USD", "Threshold is RM1,700 per month.", "Threshold is USD1,700 per month."),
        ("currency symbol", "Penalty of ₹5,000.", "Penalty of $5,000."),
        ("magnitude lakh -> crore", "Exposure of 5 lakh.", "Exposure of 5 crore."),
        ("magnitude million -> billion", "Loss of 2 million.", "Loss of 2 billion."),
        ("full-width digits 150 -> 15", "金额为１５０万。", "金额为１５万。"),
        ("number after Chinese char", "罚款RM1,700。", "罚款RM1,800。"),
        ("clause number after Chinese", "第3条规定不得转让", "第5条规定不得转让"),
        ("before -> after", "Approve before posting.", "Approve after posting."),
        ("Chinese before -> after", "付款之前必须批准。", "付款之后必须批准。"),
        ("Spanish antes -> despues", "Aprobar antes del pago.", "Aprobar despues del pago."),
        ("Malay sebelum -> selepas", "Lulus sebelum pembayaran.", "Lulus selepas pembayaran."),
        ("amount glued to currency", "Fine USD100.", "Fine USD900."),
        ("single digit glued", "Fine RM5.", "Fine RM6."),
        ("identifier", "Run test TP05.", "Run test TP06."),
        ("quarter", "Due in Q3.", "Due in Q4."),
        ("clause letter", "See clause 7(b).", "See clause 7(c)."),
        ("version", "Use v2.1 rules.", "Use v2.2 rules."),
        ("month", "Due on 5 March.", "Due on 5 May."),
        ("roman numeral section", "Section IV applies.", "Section V applies."),
        ("roman numeral article", "Article XII applies.", "Article XIII applies."),
        ("spelled number", "Limit is twenty days.", "Limit is thirty days."),
        ("status antonym", "The control is effective.", "The control is ineffective."),
        ("pass/fail", "The test passed.", "The test failed."),
    ]
    MUST_PASS = [
        ("full-width equals ASCII", "金额为150万。证据不得引用。", "金额为１５０万。证据不得引用。"),
        ("whitespace only", "Evidence  must not\nbe cited.", "Evidence must not be cited."),
        ("filler words", "The finding is really quite clear.", "Finding clear."),
        ("identical Chinese", "证据不得引用。", "证据不得引用。"),
        ("percent word", "Rate is 5 percent.", "Rate is 5%."),
        ("thousands separator", "Limit 1,700.", "Limit 1700."),
        ("trailing .00", "Fine RM1,700.00", "Fine RM1,700"),
        ("space after currency", "Fine RM 1,700.", "Fine RM1,700."),
        ("leading zero rule", "Per Rule 9.", "Per Rule 09."),
        ("rank spacing", "Evidence R5.", "Evidence R 5."),
        ("spelled vs digits", "Within twenty-five days.", "Within 25 days."),
    ]
    # Documented blind spots. These PASS today. If one starts being caught, this test fails so the
    # docs (SKILL.md, the guard's docstring, the report) are updated rather than left stale.
    KNOWN_BLIND = [
        ("subject/object swap", "The CFO approves the CEO's expenses.", "The CEO approves the CFO's expenses."),
        ("entity swap", "MKPC reported the fraud.", "MKAPL reported the fraud."),
        ("ordering of ordinary verbs", "Approve the payment, then post it.", "Post the payment, then approve it."),
        ("Tamil negation", "இது அனுமதிக்கப்படவில்லை", "இது அனுமதிக்கப்படுகிறது"),
        ("Hindi negation", "यह अनुमत नहीं है", "यह अनुमत है"),
    ]

    def test_meaning_changes_are_not_passes(self):
        for label, o, c in self.MUST_NOT_PASS:
            self.assertNotEqual(status(o, c), "PASS", label)

    def test_meaning_preserving_edits_pass(self):
        for label, o, c in self.MUST_PASS:
            self.assertEqual(status(o, c), "PASS", label)

    def test_known_blind_spots_are_still_documented_blind_spots(self):
        for label, o, c in self.KNOWN_BLIND:
            self.assertEqual(status(o, c), "PASS", f"{label} is now caught: update the documented limits")

    def test_hard_failures_vs_review(self):
        self.assertEqual(status("Fine RM100.", "Fine USD100."), "FAIL")
        self.assertEqual(status("Pay before audit.", "Pay after audit."), "REVIEW")
        self.assertEqual(status("必须批准。", "可以批准。"), "REVIEW")

    def test_order_change_with_identical_tokens_is_review(self):
        self.assertEqual(status("Pay 3 days before 5 days after.", "Pay 5 days before 3 days after."), "REVIEW")
        self.assertEqual(status("Due 03/10/2026.", "Due 10/03/2026."), "REVIEW")

    def test_broken_pipe_is_not_a_traceback(self):
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            a, b = Path(d, "a.txt"), Path(d, "b.txt")
            a.write_text("must not R1 5 " * 50)
            b.write_text("may R2 6 " * 50)
            r = subprocess.run(["bash", "-c", f"{sys.executable} {SC / 'meaning_guard.py'} {a} {b} | head -c 1"],
                               capture_output=True, text=True)
            self.assertNotIn("Traceback", r.stderr)


# ------------------------------------------------------------------ generator
NEGS = {"en": ["must not", "never", "cannot", "without", "only", "unless"],
        "ms": ["tidak boleh", "tanpa", "hanya", "jangan"],
        "es": ["nunca debe", "sin", "solo", "excepto"],
        "zh": ["不得", "禁止", "没有", "仅", "除非"]}
FILLER = {"en": "really quite basically", "ms": "sangat", "es": "muy", "zh": ""}
CURRENCIES = ["RM", "USD", "INR", "MXN", "EUR"]
MAGS = ["lakh", "crore", "million", "billion"]
MONTHS = ["March", "May", "July", "October", "December"]
DIRS = [("before", "after"), ("above", "below"), ("higher", "lower"), ("effective", "ineffective"),
        ("之前", "之后"), ("以上", "以下"), ("antes", "despu\u00e9s"), ("sebelum", "selepas")]
MODALS = [("must", "may"), ("必须", "可选"), ("debe", "puede"), ("mesti", "boleh")]
COLOURS = ["\U0001F534", "\U0001F7E0", "\U0001F7E1", "\U0001F7E2"]
WORDS = dict(enumerate(
    "zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen "
    "sixteen seventeen eighteen nineteen".split()))
TENS = {2: "twenty", 3: "thirty", 4: "forty", 5: "fifty", 6: "sixty", 7: "seventy", 8: "eighty", 9: "ninety"}


def words(n):
    if n < 20:
        return WORDS[n]
    return TENS[n // 10] + ("" if n % 10 == 0 else "-" + WORDS[n % 10])


def gen_segments(rng):
    lang = rng.choice(list(NEGS))
    segs = []
    for _ in range(rng.randint(3, 7)):
        kind = rng.choice(["neg", "amount", "number", "pct", "rank", "rule", "ident", "colour", "cls",
                           "month", "version", "dir", "modal"])
        if kind == "neg":
            v = rng.choice(NEGS[lang])
        elif kind == "amount":
            v = (rng.choice(CURRENCIES), rng.randint(2, 4999), rng.choice([None, None, rng.choice(MAGS)]))
        elif kind == "number":
            v = (rng.randint(2, 98), rng.choice(["days", "items", "files"]))
        elif kind == "pct":
            v = rng.randint(2, 98)
        elif kind == "rank":
            v = rng.randint(1, 5)
        elif kind == "rule":
            v = rng.randint(1, 30)
        elif kind == "ident":
            v = (rng.choice(["TP", "E", "Q", "RC"]), rng.randint(1, 20))
        elif kind == "colour":
            v = rng.choice(COLOURS)
        elif kind == "cls":
            v = rng.choice(["CD", "SD", "MW"])
        elif kind == "month":
            v = rng.choice(MONTHS)
        elif kind == "version":
            v = f"v{rng.randint(1, 9)}.{rng.randint(0, 9)}"
        elif kind == "dir":
            a, b = rng.choice(DIRS)
            v = (a, b, rng.randint(0, 1))
        else:
            a, b = rng.choice(MODALS)
            v = (a, b, 0)
        segs.append((kind, v))
    return lang, segs


def render_seg(kind, v, st):
    if kind == "neg":
        return f"item {v} posted"
    if kind == "amount":
        cur, n, mag = v
        num = f"{n:,}" if st["comma"] and n >= 1000 else str(n)
        if st["dec"]:
            num += ".00"
        sep = " " if st["space"] else ""
        return f"fine {cur}{sep}{num}" + (f" {mag}" if mag else "")
    if kind == "number":
        n, unit = v
        return f"within {words(n) if st['words'] else n} {unit}"
    if kind == "pct":
        return f"rate {v}{' percent' if st['pctword'] else '%'}"
    if kind == "rank":
        return "evidence R" + (" " if st["space"] else "") + str(v)
    if kind == "rule":
        return f"per Rule {v:02d}" if (st["zero"] and v < 10) else f"per Rule {v}"
    if kind == "ident":
        p, n = v
        return f"run {p}{n:02d}" if (st["zero"] and n < 10) else f"run {p}{n}"
    if kind == "colour":
        return f"rated {v}"
    if kind == "cls":
        return f"classified {v}"
    if kind == "month":
        return f"due in {v}"
    if kind == "version":
        return f"use {v} build"
    if kind == "dir":
        a, b, pick = v
        return f"approve {(a, b)[pick]} posting"
    a, b, pick = v
    return f"owner {(a, b)[pick]} respond"


def make_style(rng):
    return {"comma": rng.random() < .5, "dec": rng.random() < .3, "space": rng.random() < .5,
            "words": rng.random() < .5, "pctword": rng.random() < .5, "zero": rng.random() < .5}


def render(lang, segs, styles, extra=None):
    sep = "。" if lang == "zh" else ". "
    text = sep.join(render_seg(k, v, styles[i]) for i, (k, v) in enumerate(segs)) + sep
    if extra and "fullwidth" in extra:
        text = "".join(chr(ord(c) + 0xFEE0) if "0" <= c <= "9" and extra["fullwidth"][i % len(extra["fullwidth"])] else c
                       for i, c in enumerate(text))
    if extra and extra.get("ws"):
        text = text.replace(" ", "  ")
    if extra and extra.get("filler") and FILLER[lang]:
        text = FILLER[lang] + " " + text
    return text


def changed(kind, v, rng):
    """A new value for a segment that changes its meaning, plus the status the guard must give."""
    if kind == "neg":
        return None, "FAIL"
    if kind == "amount":
        cur, n, mag = v
        what = rng.choice(["n", "cur", "mag"])
        if what == "n":
            return (cur, n + 1, mag), "FAIL"
        if what == "cur":
            return (rng.choice([c for c in CURRENCIES if c != cur]), n, mag), "FAIL"
        return (cur, n, rng.choice([m for m in MAGS if m != mag])), "FAIL"
    if kind == "number":
        return (v[0] + 1, v[1]), "FAIL"
    if kind == "pct":
        return v + 1, "FAIL"
    if kind == "rank":
        return v % 5 + 1, "FAIL"
    if kind == "rule":
        return v + 1, "FAIL"
    if kind == "ident":
        return (v[0], v[1] + 1), "FAIL"
    if kind == "colour":
        return rng.choice([c for c in COLOURS if c != v]), "FAIL"
    if kind == "cls":
        return rng.choice([c for c in ("CD", "SD", "MW") if c != v]), "FAIL"
    if kind == "month":
        return rng.choice([m for m in MONTHS if m != v]), "FAIL"
    if kind == "version":
        return f"v{int(v[1]) % 9 + 1}.{v[3]}", "FAIL"
    a, b, pick = v
    return (a, b, 1 - pick), "REVIEW"


class PropertyFuzz(unittest.TestCase):
    N = 3000

    def test_changing_a_segment_is_never_a_pass_and_hard_classes_fail(self):
        rng, per_kind = random.Random(20261003), {}
        for i in range(self.N):
            lang, segs = gen_segments(rng)
            styles = [make_style(rng) for _ in segs]
            j = rng.randrange(len(segs))
            kind, v = segs[j]
            nv, expect = changed(kind, v, rng)
            new_segs, new_styles = list(segs), list(styles)
            if nv is None:
                del new_segs[j], new_styles[j]
            else:
                new_segs[j] = (kind, nv)
            before, after = render(lang, segs, styles), render(lang, new_segs, new_styles)
            got = status(before, after)
            per_kind[kind] = per_kind.get(kind, 0) + 1
            self.assertEqual(got, expect, f"#{i} {kind}: wanted {expect}, got {got}\n  {before!r}\n  {after!r}")
        for kind in ("neg", "amount", "number", "pct", "rank", "rule", "ident", "colour", "cls", "month",
                     "version", "dir", "modal"):
            self.assertGreater(per_kind.get(kind, 0), 80, f"too few {kind} cases")

    def test_restyling_with_equivalent_forms_always_passes(self):
        rng = random.Random(77)
        for i in range(self.N):
            lang, segs = gen_segments(rng)
            s1 = [make_style(rng) for _ in segs]
            s2 = [make_style(rng) for _ in segs]
            extra = {"fullwidth": [rng.random() < .5 for _ in range(7)], "ws": rng.random() < .4,
                     "filler": rng.random() < .4}
            before, after = render(lang, segs, s1), render(lang, segs, s2, extra)
            self.assertEqual(status(before, after), "PASS", f"#{i}\n  {before!r}\n  {after!r}")

    def test_identity_and_no_crash_on_arbitrary_unicode(self):
        rng = random.Random(5)
        alphabet = [chr(c) for c in list(range(32, 127)) + list(range(0x4E00, 0x4E60)) + [0x1F534, 0x20B9, 0xFF11, 0x0301]]
        for _ in range(500):
            t = "".join(rng.choice(alphabet) for _ in range(rng.randint(0, 200)))
            self.assertEqual(status(t, t), "PASS")
            status(t, t[::-1])  # must not raise

    def test_empty_inputs(self):
        self.assertEqual(status("", ""), "PASS")
        self.assertEqual(status("must not", ""), "FAIL")


if __name__ == "__main__":
    unittest.main(verbosity=2)
