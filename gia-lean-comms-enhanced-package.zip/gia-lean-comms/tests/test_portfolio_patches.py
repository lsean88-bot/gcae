"""Regression tests for the portfolio patches (2026-10-02) and the v1.1 plugin features.

Each test would have FAILED against the original defect. Portfolio tests skip when the
skill mount is absent (e.g. running on a laptop).
"""
import json
import re
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SC = ROOT / "skills" / "gia-lean-comms" / "scripts"
SKILL = ROOT / "skills" / "gia-lean-comms"

# These tests check that the overlap SCANNER RUNS and that skips are reported (not that gia-lean-comms itself
# is overlap-free: when the plugin is installed in a skills root, the scanner correctly sees the installed copy
# as a near-duplicate of a candidate). So they probe with a skill whose description is unique.
import tempfile as _tf  # noqa: E402
_PROBE_TMP = _tf.TemporaryDirectory()
PROBE = Path(_PROBE_TMP.name, "probe-unique-zq")
PROBE.mkdir()
(PROBE / "SKILL.md").write_text(
    "---\nname: probe-unique-zq\ndescription: 'Quarterly zebra migration planner for lighthouse keepers. "
    "Trigger on: zebra lighthouse migration, penguin ferry timetable.'\n---\n# probe\n")   # quoted: a colon in a plain scalar is invalid YAML
PLUG = Path("/mnt/skills/plugins")
MOUNTED = PLUG.is_dir() and (PLUG / "skill-factory").is_dir()
sys.path.insert(0, str(SC))
import interop_check  # noqa: E402
import meaning_guard  # noqa: E402

PREFLIGHT = PLUG / "skill-factory" / "scripts" / "run_preflight.py"
DRIFT = PLUG / "iron-rules-governance" / "scripts" / "check-governance-drift.sh"
CRITIQUE = PLUG / "independent-critique" / "scripts" / "run_critique.py"


def sh(*cmd):
    return subprocess.run([str(c) for c in cmd], capture_output=True, text=True)


@unittest.skipUnless(MOUNTED, "portfolio not mounted")
class PreflightPatch(unittest.TestCase):
    def test_default_autodetects_sprawl_watch_and_is_complete(self):
        r = sh(sys.executable, PREFLIGHT, "--skill", PROBE)
        d = json.loads(r.stdout)
        self.assertEqual(r.returncode, 0, r.stdout)
        self.assertIs(d["checks"]["portfolio_overlap"]["pass"], True)
        self.assertTrue(d["overall_complete"])

    def test_explicit_dir_and_script_file_both_accepted(self):
        for p in (PLUG / "skill-sprawl-watch", PLUG / "skill-sprawl-watch" / "scripts" / "scan_overlap.py"):
            d = json.loads(sh(sys.executable, PREFLIGHT, "--skill", PROBE, "--sprawl-watch-path", p).stdout)
            self.assertIs(d["checks"]["portfolio_overlap"]["pass"], True, p)

    def test_skipped_check_is_incomplete_not_pass(self):
        r = sh(sys.executable, PREFLIGHT, "--skill", SKILL, "--sprawl-watch-path", "/nope")
        d = json.loads(r.stdout)
        self.assertEqual(r.returncode, 2)
        self.assertFalse(d["overall_complete"])
        self.assertIn("INCOMPLETE", d["note"])

    def test_explicit_wrong_path_never_falls_back_silently(self):
        d = json.loads(sh(sys.executable, PREFLIGHT, "--skill", SKILL, "--sprawl-watch-path", "/nope").stdout)
        self.assertIsNone(d["checks"]["portfolio_overlap"]["pass"])

    def test_allow_skip_returns_zero(self):
        r = sh(sys.executable, PREFLIGHT, "--skill", SKILL, "--sprawl-watch-path", "/nope", "--allow-skip")
        self.assertEqual(r.returncode, 0)

    def test_structural_failure_is_exit_1(self):
        with tempfile.TemporaryDirectory() as d:
            Path(d, "SKILL.md").write_text("no frontmatter\n")
            self.assertEqual(sh(sys.executable, PREFLIGHT, "--skill", d).returncode, 1)


@unittest.skipUnless(MOUNTED, "portfolio not mounted")
class CritiquePatch(unittest.TestCase):
    def test_default_critique_does_not_skip_overlap(self):
        with tempfile.TemporaryDirectory() as d:
            out = Path(d, "c.md")
            sh(sys.executable, CRITIQUE, "--skill", PROBE, "--out", out)
            text = out.read_text()
            self.assertNotIn("SKIPPED", text)
            self.assertNotIn("INCOMPLETE", text)
            self.assertIn("No overlap flags", text)


@unittest.skipUnless(MOUNTED, "portfolio not mounted")
class DocPatches(unittest.TestCase):
    def test_skill_factory_has_no_prefixed_script_path(self):
        t = (PLUG / "skill-factory" / "SKILL.md").read_text()
        self.assertNotIn("mktron-sentinel:skill-factory/scripts", t)
        self.assertIn("scripts/run_preflight.py", t)

    def test_every_mnt_skills_path_in_patched_docs_exists(self):
        for f in [PLUG / "skill-factory" / "SKILL.md",
                  PLUG / "sp-global:funding-digest" / "SKILL.md",
                  PLUG / "iron-rules-governance" / "references" / "scheduled-automation.md"]:
            for raw in re.findall(r"/mnt/skills/[A-Za-z0-9_.:/-]+", f.read_text()):
                p = interop_check.clean_path(raw)
                if Path(p).suffix:
                    self.assertTrue(Path(p).exists(), f"{f.name} -> {p}")

    def test_scheduled_automation_points_at_real_script(self):
        t = (PLUG / "iron-rules-governance" / "references" / "scheduled-automation.md").read_text()
        self.assertNotIn("/mnt/skills/user/iron-rules-governance", t)
        self.assertTrue(DRIFT.exists())


@unittest.skipUnless(MOUNTED, "portfolio not mounted")
class DriftPatch(unittest.TestCase):
    def test_no_arg_covers_the_whole_portfolio(self):
        r = sh("bash", DRIFT)
        m = re.search(r"Skills in scope: (\d+)", r.stdout)
        self.assertIsNotNone(m)
        self.assertGreater(int(m.group(1)), 100)

    def test_no_arg_has_no_phantom_missing_file_findings(self):
        r = sh("bash", DRIFT)
        self.assertNotIn("charlie-hills-code/SKILL.md not found", r.stdout)
        self.assertNotIn("SKIPPED", r.stdout)

    def test_partial_scope_can_never_exit_clean(self):
        r = sh("bash", DRIFT, "/mnt/skills/user")
        self.assertNotEqual(r.returncode, 0)
        self.assertIn("SKIPPED", r.stdout)

    def test_skipped_without_findings_is_exit_2(self):
        with tempfile.TemporaryDirectory() as d:
            # Minimal conforming charlie-hills-code satisfies Check 4;
            # no iron-rules-governance => Check 6 SKIPPED, nothing else raises a finding.
            ch = Path(d, "charlie-hills-code")
            ch.mkdir()
            ch.joinpath("SKILL.md").write_text(
                "---\nname: charlie-hills-code\ndescription: x\n---\n" +
                "".join(f"## Phase {i} \u2014 {n}\n\n" for i, n in
                        enumerate(["Plan", "Verify", "Execute", "Check", "Log"], 1)))
            r = sh("bash", DRIFT, d)
            self.assertEqual(r.returncode, 2, r.stdout)
            self.assertIn("INCOMPLETE", r.stdout)

    def test_findings_plus_skipped_is_exit_1_with_note(self):
        with tempfile.TemporaryDirectory() as d:
            Path(d, "only").mkdir()
            Path(d, "only", "SKILL.md").write_text("---\nname: only\ndescription: x\n---\n")
            r = sh("bash", DRIFT, d)
            self.assertEqual(r.returncode, 1, r.stdout)
            self.assertIn("also SKIPPED", r.stdout)

    def test_bad_directory_is_exit_2(self):
        self.assertEqual(sh("bash", DRIFT, "/nope").returncode, 2)

    def test_script_is_read_only(self):
        text = DRIFT.read_text()
        for bad in (" rm -rf /", "sed -i", "> /mnt"):
            self.assertNotIn(bad, text)


@unittest.skipUnless(MOUNTED, "portfolio not mounted")
class PortfolioGate(unittest.TestCase):
    def test_zero_error_findings_portfolio_wide(self):
        r = sh(sys.executable, SC / "interop_check.py", "--audit-citations", "--deep",
               "--ignore", "*/references/drift-check-*.md", "--json")
        d = json.loads(r.stdout)
        errors = [x for x in d["dangling_citations"] if x["severity"] == "error"]
        self.assertEqual(errors, [], errors)
        self.assertEqual(r.returncode, 0)


class AuditFeatures(unittest.TestCase):
    def roots(self, d):
        for n in ["alpha", "mktron-sentinel:beta"]:
            Path(d, n).mkdir()
            Path(d, n, "SKILL.md").write_text("---\nname: x\n---\n")
        return [d]

    def test_grep_style_suffix_is_stripped(self):
        self.assertEqual(interop_check.clean_path("/mnt/skills/plugins/a/SKILL.md:161:gate"),
                         "/mnt/skills/plugins/a/SKILL.md")
        self.assertEqual(interop_check.clean_path("/mnt/skills/plugins/a/SKILL.md."),
                         "/mnt/skills/plugins/a/SKILL.md")

    def test_prefixed_directory_name_survives_cleaning(self):
        self.assertEqual(interop_check.clean_path("/mnt/skills/plugins/mktron-sentinel:beta/SKILL.md"),
                         "/mnt/skills/plugins/mktron-sentinel:beta/SKILL.md")

    def test_prefix_mismatch_is_info_and_does_not_fail(self):
        with tempfile.TemporaryDirectory() as d:
            roots = self.roots(d)
            Path(d, "alpha", "SKILL.md").write_text("see `mktron-sentinel:alpha`")
            f = interop_check.audit_citations(interop_check.index(roots), roots)
            self.assertEqual([x["severity"] for x in f], ["info"])
            self.assertEqual(sh(sys.executable, SC / "interop_check.py", "--roots", *roots,
                                "--audit-citations").returncode, 0)

    def test_broken_path_is_error_and_fails(self):
        with tempfile.TemporaryDirectory() as d:
            roots = self.roots(d)
            Path(d, "alpha", "SKILL.md").write_text("run /mnt/skills/plugins/zzz/none.py")
            self.assertEqual(sh(sys.executable, SC / "interop_check.py", "--roots", *roots,
                                "--audit-citations").returncode, 1)

    def test_deep_scans_references_but_shallow_does_not(self):
        with tempfile.TemporaryDirectory() as d:
            roots = self.roots(d)
            Path(d, "alpha", "references").mkdir()
            Path(d, "alpha", "references", "n.md").write_text("see /mnt/skills/plugins/zzz/none.py")
            names = interop_check.index(roots)
            self.assertEqual(interop_check.audit_citations(names, roots, deep=False), [])
            self.assertEqual(len(interop_check.audit_citations(names, roots, deep=True)), 1)

    def test_ignore_glob_skips_evidence_logs(self):
        with tempfile.TemporaryDirectory() as d:
            roots = self.roots(d)
            Path(d, "alpha", "references").mkdir()
            Path(d, "alpha", "references", "drift-check-1.md").write_text("/mnt/skills/plugins/zzz/none.py")
            names = interop_check.index(roots)
            self.assertEqual(interop_check.audit_citations(
                names, roots, deep=True, ignore=("*/references/drift-check-*.md",)), [])

    def test_bare_names_flagged_only_with_option_and_context(self):
        with tempfile.TemporaryDirectory() as d:
            roots = self.roots(d)
            Path(d, "alpha", "SKILL.md").write_text(
                "Use the `ghost-skill` skill here.\nA `plain-code-token` with no keyword.\n")
            names = interop_check.index(roots)
            self.assertEqual(interop_check.audit_citations(names, roots), [])
            f = interop_check.audit_citations(names, roots, include_bare=True)
            self.assertEqual([x["cites"] for x in f], ["ghost-skill"])


class ShowLines(unittest.TestCase):
    def test_show_lines_points_at_changed_text(self):
        o, c = "Line one.\nApprove before posting.\n", "Line one.\nApprove after posting.\n"
        e, w = meaning_guard.compare(o, c)
        out = meaning_guard.show_lines(o, c, e + w)
        self.assertTrue(any("original line 2" in x and "before" in x for x in out))
        self.assertTrue(any("rewritten line 2" in x and "after" in x for x in out))

    def test_show_lines_cli_flag(self):
        with tempfile.TemporaryDirectory() as d:
            a, b = Path(d, "a.txt"), Path(d, "b.txt")
            a.write_text("Approve before posting."); b.write_text("Approve after posting.")
            r = sh(sys.executable, SC / "meaning_guard.py", a, b, "--show-lines")
            self.assertEqual(r.returncode, 3)
            self.assertIn("original line 1", r.stdout)


if __name__ == "__main__":
    unittest.main(verbosity=2)
