import json, subprocess, sys, tempfile, unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SC = ROOT / "skills" / "gia-lean-comms" / "scripts"
FX = Path(__file__).resolve().parent / "fixtures"
sys.path.insert(0, str(SC))
import meaning_guard, zone_guard, interop_check  # noqa: E402


def run(script, *args):
    return subprocess.run([sys.executable, str(SC / script), *args], capture_output=True, text=True)


class MeaningGuard(unittest.TestCase):
    def test_flipped_rewrite_fails(self):
        r = run("meaning_guard.py", str(FX / "rules_original.md"), str(FX / "rules_flipped.md"), "--json")
        self.assertEqual(r.returncode, 1)
        classes = {e["class"] for e in json.loads(r.stdout)["errors"]}
        self.assertIn("negation_net_loss", classes)
        self.assertIn("evidence_rank", classes)
        self.assertIn("number", classes)

    def test_faithful_lean_rewrite_passes(self):
        r = run("meaning_guard.py", str(FX / "rules_original.md"), str(FX / "rules_lean_ok.md"))
        self.assertEqual(r.returncode, 0, r.stdout)

    def test_identical_passes(self):
        r = run("meaning_guard.py", str(FX / "rules_original.md"), str(FX / "rules_original.md"))
        self.assertEqual(r.returncode, 0)

    def test_single_dropped_not_is_caught(self):
        e, _ = meaning_guard.compare("Do not cite R5 evidence.", "Do cite R5 evidence.")
        self.assertTrue(any(x["class"] == "negation_net_loss" for x in e))

    def test_negation_reword_is_review_not_fail(self):
        e, w = meaning_guard.compare("It doesn't add new infrastructure.", "No new infrastructure.")
        self.assertFalse(e)
        self.assertTrue(any(x["class"] == "negation_reworded" for x in w))

    def test_review_exit_code_is_3(self):
        with tempfile.TemporaryDirectory() as d:
            a, b = Path(d, "a.txt"), Path(d, "b.txt")
            a.write_text("It must not be cited."); b.write_text("It never be cited.")
            self.assertEqual(run("meaning_guard.py", str(a), str(b)).returncode, 3)

    def test_list_numerals_are_not_numbers(self):
        e, _ = meaning_guard.compare("1. Check A\n2. Check B", "- Check A\n- Check B")
        self.assertFalse(e)

    def test_direction_flip_is_review(self):
        e, w = meaning_guard.compare("Approved before posting, above the limit.",
                                     "Approved after posting, below the limit.")
        self.assertFalse(e)
        self.assertTrue(any(x["class"] == "direction_quantifier" for x in w))

    def test_manifest_has_no_unverified_keys(self):
        m = json.loads((ROOT / ".claude-plugin" / "plugin.json").read_text())
        self.assertEqual(set(m) - {"name", "version", "description", "author"}, set())

    def test_number_words_equal_digits(self):
        e, _ = meaning_guard.compare("Two years and three PRs.", "2 years and 3 PRs.")
        self.assertFalse(e)

    def test_number_word_change_still_caught(self):
        e, _ = meaning_guard.compare("Two years.", "3 years.")
        self.assertTrue(any(x["class"] == "number" for x in e))

    def test_trailing_comma_not_part_of_number(self):
        e, _ = meaning_guard.compare("Due 11, 2026.", "Due 11 2026.")
        self.assertFalse(e)

    def test_number_change_caught(self):
        e, _ = meaning_guard.compare("Threshold is 12.5% over 30 days.", "Threshold is 15% over 30 days.")
        self.assertTrue(any(x["class"] == "number" for x in e))

    def test_risk_colour_and_class_caught(self):
        e, _ = meaning_guard.compare("\U0001F534 MW identified", "\U0001F7E1 SD identified")
        classes = {x["class"] for x in e}
        self.assertTrue({"risk_colour", "deficiency_class"} <= classes)

    def test_rule_ref_caught(self):
        e, _ = meaning_guard.compare("Per Rule 06 and RACM-04.", "Per Rule 09 and RACM-04.")
        self.assertTrue(any(x["class"] == "rule_ref" for x in e))

    def test_modal_change_is_warning_not_error(self):
        e, w = meaning_guard.compare("Owner must respond.", "Owner may respond.")
        self.assertFalse(e)
        self.assertTrue(w)

    def test_filler_and_articles_ignored(self):
        e, w = meaning_guard.compare("The finding is really quite basically clear.", "Finding clear.")
        self.assertFalse(e)


class ZoneGuard(unittest.TestCase):
    def test_protected_paths(self):
        for p in ["IAR_MKPC_final.docx", "board-paper.md", "/x/CLAUDE.md", "skills/foo/SKILL.md",
                  "management_response.xlsx", "memory/profile.md", "fraud-investigation-notes.md"]:
            self.assertEqual(zone_guard.classify(path=p)[0], "PROTECTED", p)

    def test_lean_paths(self):
        for p in ["run_uat.sh", "debug.log", "scripts/parse.py"]:
            self.assertEqual(zone_guard.classify(path=p)[0], "LEAN", p)

    def test_ambiguous_fails_closed(self):
        self.assertEqual(zone_guard.classify(path="notes.docx")[0], "PROTECTED")
        self.assertEqual(zone_guard.classify(purpose="tidy this up")[0], "PROTECTED")

    def test_protected_beats_lean_extension(self):
        self.assertEqual(zone_guard.classify(path="findings_register.csv")[0], "PROTECTED")

    def test_purpose_working_chatter_is_lean(self):
        self.assertEqual(zone_guard.classify(purpose="debug the test run output")[0], "LEAN")

    def test_purpose_finding_is_protected(self):
        self.assertEqual(zone_guard.classify(purpose="status of the R3 evidence for a finding")[0], "PROTECTED")

    def test_exit_codes(self):
        self.assertEqual(run("zone_guard.py", "--path", "x.log").returncode, 0)
        self.assertEqual(run("zone_guard.py", "--path", "CLAUDE.md").returncode, 2)


class CompressGate(unittest.TestCase):
    def test_protected_path_blocked_even_if_meaning_ok(self):
        r = run("compress_gate.py", str(FX / "rules_original.md"), str(FX / "rules_original.md"))
        # fixture name contains 'rules_original.md' => ambiguous => fail closed
        self.assertEqual(r.returncode, 2)

    def test_lean_file_with_safe_copy_passes(self):
        with tempfile.TemporaryDirectory() as d:
            a, b = Path(d, "notes.log"), Path(d, "notes_c.log")
            a.write_text("The check is not optional. Run 3 times.")
            b.write_text("Check not optional. Run 3 times.")
            self.assertEqual(run("compress_gate.py", str(a), str(b)).returncode, 0)

    def test_gate_returns_3_on_review(self):
        with tempfile.TemporaryDirectory() as d:
            a, b = Path(d, "notes.log"), Path(d, "notes_c.log")
            a.write_text("It doesn't add new infrastructure.")
            b.write_text("No new infrastructure.")
            self.assertEqual(run("compress_gate.py", str(a), str(b)).returncode, 3)

    def test_lean_file_with_flipped_copy_blocked(self):
        with tempfile.TemporaryDirectory() as d:
            a, b = Path(d, "notes.log"), Path(d, "notes_c.log")
            a.write_text("The check is not optional. Run 3 times.")
            b.write_text("Check optional. Run 2 times.")
            self.assertEqual(run("compress_gate.py", str(a), str(b)).returncode, 1)

    def test_gate_never_modifies_files(self):
        with tempfile.TemporaryDirectory() as d:
            a, b = Path(d, "notes.log"), Path(d, "notes_c.log")
            a.write_text("keep 1"); b.write_text("keep 1")
            run("compress_gate.py", str(a), str(b))
            self.assertEqual((a.read_text(), b.read_text()), ("keep 1", "keep 1"))


class InteropCheck(unittest.TestCase):
    def make_roots(self, d):
        for n in ["alpha", "mktron-sentinel:beta", "gamma"]:
            Path(d, n).mkdir()
            Path(d, n, "SKILL.md").write_text("---\nname: x\n---\n")
        return [d]

    def test_resolution_variants(self):
        with tempfile.TemporaryDirectory() as d:
            names = interop_check.index(self.make_roots(d))
            self.assertIsNotNone(interop_check.resolve("alpha", names))
            self.assertIsNotNone(interop_check.resolve("mktron-sentinel:alpha", names))
            self.assertIsNotNone(interop_check.resolve("beta", names))
            self.assertIsNotNone(interop_check.resolve("mktron-sentinel:beta", names))
            self.assertIsNone(interop_check.resolve("nope", names))

    def test_required_missing_exits_1(self):
        with tempfile.TemporaryDirectory() as d:
            roots = self.make_roots(d)
            c = Path(d, "c.json")
            c.write_text(json.dumps({"dependencies": [{"name": "zzz", "role": "r", "required": True}]}))
            r = run("interop_check.py", "--roots", *roots, "--contract", str(c))
            self.assertEqual(r.returncode, 1)

    def test_optional_missing_exits_0(self):
        with tempfile.TemporaryDirectory() as d:
            roots = self.make_roots(d)
            c = Path(d, "c.json")
            c.write_text(json.dumps({"dependencies": [{"name": "zzz", "role": "r", "required": False}]}))
            self.assertEqual(run("interop_check.py", "--roots", *roots, "--contract", str(c)).returncode, 0)

    def test_audit_finds_prefix_mismatch_and_ignores_noise(self):
        with tempfile.TemporaryDirectory() as d:
            roots = self.make_roots(d)
            Path(d, "alpha", "SKILL.md").write_text(
                "see `mktron-sentinel:alpha` and ratio `16:9` and xml `w:id` and `mktron-sentinel:ghost`")
            f = interop_check.audit_citations(interop_check.index(roots), roots)
            kinds = {(x["cites"], x["kind"]) for x in f}
            self.assertIn(("mktron-sentinel:alpha", "prefix_mismatch"), kinds)
            self.assertIn(("mktron-sentinel:ghost", "dangling"), kinds)
            self.assertFalse(any(x["cites"] in ("16:9", "w:id") for x in f))

    def test_audit_finds_broken_path(self):
        with tempfile.TemporaryDirectory() as d:
            roots = self.make_roots(d)
            Path(d, "alpha", "SKILL.md").write_text("run /mnt/skills/plugins/zzz-nonexistent/scripts/x.py now")
            f = interop_check.audit_citations(interop_check.index(roots), roots)
            self.assertTrue(any(x["kind"] == "broken_path" for x in f))

    def test_shipped_contract_resolves_in_real_portfolio(self):
        if not Path("/mnt/skills/plugins").is_dir():
            self.skipTest("portfolio not mounted")
        r = run("interop_check.py", "--contract", str(ROOT / "skills/gia-lean-comms/references/interop.json"))
        self.assertEqual(r.returncode, 0, r.stdout)


if __name__ == "__main__":
    unittest.main(verbosity=2)
