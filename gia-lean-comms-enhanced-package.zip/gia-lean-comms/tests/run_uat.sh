#!/usr/bin/env bash
# Reproducible UAT for gia-lean-comms v1.4 and the portfolio patches. Run with: bash tests/run_uat.sh
# Exit 0 only if every stage passes. Portfolio stages report SKIP (and exit 2, INCOMPLETE) when the
# mount is absent: a skipped stage is not a pass.
set -u
HERE="$(cd "$(dirname "$0")/.." && pwd)"
SC="$HERE/skills/gia-lean-comms/scripts"
# The seed registry and baseline describe the sandbox this package was verified in. They are fixtures
# passed explicitly, never implicit defaults (a real installation uses its own state directory).
SEEDREG="$HERE/skills/gia-lean-comms/references/seed/portfolio-registry.seed.json"
SEEDBASE="$HERE/skills/gia-lean-comms/references/seed/baseline.seed.txt"
PLUG=/mnt/skills/plugins
FAILS=0; SKIPS=0
stage(){ echo; echo "=== $1"; }
ok(){ echo "  PASS: $1"; }
bad(){ echo "  FAIL: $1"; FAILS=$((FAILS+1)); }
skip(){ echo "  SKIP: $1"; SKIPS=$((SKIPS+1)); }
expect(){ local want="$1" label="$2"; shift 2; "$@" >/tmp/gl_out.txt 2>&1; local got=$?
  [ "$got" -eq "$want" ] && ok "$label (exit $got)" || { bad "$label (wanted $want, got $got)"; tail -5 /tmp/gl_out.txt | sed 's/^/      /'; }; }
suite(){ python3 "$HERE/tests/$1" >/tmp/gl_$1.txt 2>&1 && ok "$1: $(grep -E '^Ran ' /tmp/gl_$1.txt)" || { bad "$1"; tail -15 /tmp/gl_$1.txt; }; }

stage "1. test suites"
suite test_guards.py; suite test_portfolio_patches.py; suite test_v12.py
suite test_multilingual_fuzz.py; suite test_critique_regressions.py; suite test_retire_actions.py

stage "2. headline scenario: validator-passing meaning flip is blocked"
expect 1 "flipped rewrite -> FAIL" python3 "$SC/meaning_guard.py" "$HERE/tests/fixtures/rules_original.md" "$HERE/tests/fixtures/rules_flipped.md"
expect 0 "faithful lean rewrite -> PASS" python3 "$SC/meaning_guard.py" "$HERE/tests/fixtures/rules_original.md" "$HERE/tests/fixtures/rules_lean_ok.md"
printf 'Approve before posting.' >/tmp/gl_a.txt; printf 'Approve after posting.' >/tmp/gl_b.txt
expect 3 "before->after flip -> REVIEW" python3 "$SC/meaning_guard.py" /tmp/gl_a.txt /tmp/gl_b.txt

stage "2b. engine red-team (flips that used to pass silently, and noise that used to fail)"
mg(){ printf '%s' "$1" >"$T/a.txt"; printf '%s' "$2" >"$T/b.txt"; python3 "$SC/meaning_guard.py" "$T/a.txt" "$T/b.txt" >/dev/null 2>&1; }
T=$(mktemp -d); trap 'rm -rf "$T"' EXIT
mg "Fine USD100." "Fine USD900."; [ $? -eq 1 ] && ok "USD100 -> USD900 is a FAIL" || bad "glued amount slipped through"
mg "Run test TP05." "Run test TP06."; [ $? -eq 1 ] && ok "identifier TP05 -> TP06 is a FAIL" || bad "identifier slipped through"
mg "第三方证据不得引用。" "第三方证据可引用。"; [ $? -ne 0 ] && ok "Chinese must-not -> may is not a PASS" || bad "Chinese flip slipped through"
mg "The control is effective." "The control is ineffective."; [ $? -eq 3 ] && ok "effective -> ineffective is a REVIEW" || bad "antonym slipped through"
mg "Rate is 5 percent. Fine RM 1,700.00" "Rate is 5%. Fine RM1700"; [ $? -eq 0 ] && ok "faithful restyle is a PASS (no noise)" || bad "false alarm on a faithful rewrite"

stage "3. zone guard fails closed (including non-English names and data files)"
expect 2 "CLAUDE.md protected" python3 "$SC/zone_guard.py" --path CLAUDE.md
expect 2 "ambiguous -> protected" python3 "$SC/zone_guard.py" --path mystery.docx
expect 2 "Chinese audit register .csv protected" python3 "$SC/zone_guard.py" --path 审计发现登记册.csv
expect 2 "generic notes.txt protected (data file)" python3 "$SC/zone_guard.py" --path notes.txt
expect 2 "Spanish hallazgos .json protected" python3 "$SC/zone_guard.py" --path hallazgos_auditoria.json
expect 0 "log -> lean" python3 "$SC/zone_guard.py" --path run.log

stage "4. human sign-off flow (temp files)"
printf "It doesn't add new infrastructure." >"$T/o.log"; printf 'No new infrastructure.' >"$T/c.log"
expect 3 "REVIEW without sign-off is not a pass" python3 "$SC/compress_gate.py" "$T/o.log" "$T/c.log"
expect 2 "automated reviewer name refused" python3 "$SC/review_log.py" record "$T/o.log" "$T/c.log" --reviewer Claude --decision approve --log "$T/l.jsonl"
expect 0 "human approval recorded" python3 "$SC/review_log.py" record "$T/o.log" "$T/c.log" --reviewer "Reviewer One" --decision approve --log "$T/l.jsonl"
expect 0 "gate passes with recorded approval" python3 "$SC/compress_gate.py" "$T/o.log" "$T/c.log" --signoff "$T/l.jsonl"
echo "edit" >>"$T/c.log"; expect 3 "editing the copy voids the approval" python3 "$SC/compress_gate.py" "$T/o.log" "$T/c.log" --signoff "$T/l.jsonl"

stage "5. trigger vocabulary (lexical proxy, not a measurement)"
expect 0 "no vocabulary gaps or over-trigger risks on 20 evals" python3 "$SC/trigger_proxy.py" --skill "$HERE/skills/gia-lean-comms" --evals "$HERE/evals/trigger_evals.json"

if [ -d "$PLUG/skill-factory" ]; then
  stage "6. interop contract and portfolio hygiene gates"
  expect 0 "dependency contract resolves" python3 "$SC/interop_check.py" --contract "$HERE/skills/gia-lean-comms/references/interop.json"
  expect 0 "0 citation errors portfolio-wide (--deep, evidence logs ignored, aliases)" python3 "$SC/interop_check.py" --audit-citations --deep --ignore '*/references/drift-check-*.md' --registry "$SEEDREG"
  expect 0 "registry: no undeclared collision, undeclared duplicate or stale declaration" python3 "$SC/registry_check.py" --registry "$SEEDREG"
  expect 0 "all skills valid for Claude Code" python3 "$SC/validate_portfolio.py"
  expect 0 "gate audit runs (registry-aware)" python3 "$SC/gate_audit.py" --registry "$SEEDREG"
  python3 "$SC/gate_audit.py" --registry "$SEEDREG" | grep -c '^  \[GAP\]' | grep -qx 2 && ok "exactly the 2 documented v6 gaps remain (classification only)" || bad "gate gap set changed"

  stage "7. preflight semantics: a skipped check is not a pass"
  PF="$PLUG/skill-factory/scripts/run_preflight.py"
  # A unique probe skill: when gia-lean-comms is itself installed in a skills root, the scanner correctly sees the
  # installed copy as a near-duplicate of the candidate, so the candidate under test must be distinct.
  PROBE="$T/probe-unique-zq"; mkdir -p "$PROBE"
  printf -- "---\nname: probe-unique-zq\ndescription: 'Quarterly zebra migration planner for lighthouse keepers. Trigger on: zebra lighthouse migration.'\n---\n# probe\n" >"$PROBE/SKILL.md"
  expect 0 "default auto-detects overlap scanner" python3 "$PF" --skill "$PROBE"
  expect 2 "explicit wrong scanner path -> INCOMPLETE" python3 "$PF" --skill "$PROBE" --sprawl-watch-path /nope
  expect 0 "--allow-skip accepts it knowingly" python3 "$PF" --skill "$PROBE" --sprawl-watch-path /nope --allow-skip
  expect 0 "this skill's own structure is valid (installed copy ignored)" python3 /mnt/skills/examples/skill-creator/scripts/quick_validate.py "$HERE/skills/gia-lean-comms"

  stage "8. governance drift check"
  D="$PLUG/iron-rules-governance/scripts/check-governance-drift.sh"
  bash "$D" >/tmp/gl_d.txt 2>&1; n=$(sed -n 's/^Skills in scope: //p' /tmp/gl_d.txt)
  [ "${n:-0}" -gt 100 ] && ok "no-arg scope covers $n skills" || bad "no-arg scope only $n skills"
  c4=$(sed -n '/--- Check 4/,/--- Check 5/p' /tmp/gl_d.txt | grep -c clean); [ "$c4" -ge 1 ] && ok "Check 4 (Charlie Hills phases) now clean" || bad "Check 4 not clean"
  c6=$(sed -n '/--- Check 6/,/=== Summary/p' /tmp/gl_d.txt | grep -c clean); [ "$c6" -ge 1 ] && ok "Check 6 (self-consistency) clean" || bad "Check 6 not clean"
  bash "$D" /mnt/skills/user >/dev/null 2>&1; [ $? -ne 0 ] && ok "3-skill scope can no longer exit clean" || bad "partial scope exited 0"
  expect 2 "bad directory" bash "$D" /nope

  stage "9. combined gates runner"
  G="$SC/portfolio_gates.sh"
  expect 0 "seed state: nothing new, every gate ran" bash "$G" --registry "$SEEDREG" --baseline "$SEEDBASE"
  DRIFT_SCRIPT=/nope bash "$G" --registry "$SEEDREG" --baseline "$SEEDBASE" >/dev/null 2>&1; [ $? -eq 2 ] && ok "missing drift script -> INCOMPLETE (2)" || bad "missing drift script"
  mkdir -p "$T/s/x"; printf -- '---\nname: x\ndescription: y\n---\n## 11-Item Quality Gate\n' >"$T/s/x/SKILL.md"
  bash "$G" --registry "$SEEDREG" --baseline "$SEEDBASE" --skills-dir "$T/s" >/dev/null 2>&1; [ $? -eq 1 ] && ok "new finding -> FAIL (1)" || bad "new finding not caught"

  stage "9a. new-installation journey (isolated state dir; the seed is NOT used implicitly)"
  export GIA_STATE_DIR="$T/state"
  expect 2 "first run with no state -> INCOMPLETE, not a pass" bash "$G"
  bash "$G" --bootstrap >/dev/null 2>&1; [ $? -eq 0 ] && [ ! -d "$T/state" ] && ok "bootstrap dry run writes nothing" || bad "dry run wrote state"
  expect 0 "bootstrap --yes writes registry and baseline" bash "$G" --bootstrap --yes
  [ -f "$T/state/portfolio-registry.json" ] && [ -f "$T/state/baseline.txt" ] && ok "state files are in the state dir, not the plugin folder" || bad "state files missing"
  expect 0 "next run against your own state: nothing new" bash "$G"
  expect 1 "bootstrap refuses to overwrite an existing registry" python3 "$SC/registry_check.py" --bootstrap --yes
  unset GIA_STATE_DIR

  stage "9b. live verification refuses to pass without the claude CLI"
  # Run with a PATH that cannot see the CLI, so the refusal is tested even on a machine that has it installed.
  if [ -z "$(PATH=/usr/bin:/bin command -v claude 2>/dev/null)" ]; then
    expect 2 "live_verify.sh reports INCOMPLETE, never PASS (CLI hidden from PATH)" env PATH=/usr/bin:/bin bash "$SC/live_verify.sh"
  else skip "claude is in /usr/bin and cannot be hidden: run live_verify.sh yourself"; fi

  stage "9c. owner-decision patches: validated, never applied by default"
  AP="$HERE/portfolio-patches/apply_patches.sh"; DP="$HERE/decision-patches"; ND=$(ls "$DP"/*.patch | wc -l)
  bash "$AP" /mnt/skills --check --dir "$DP" | grep -c '^needed' | grep -qx "$ND" && ok "live mount untouched: all $ND decision patches still 'needed'" || bad "decision patch state on live mount"
  M="$T/dmount"; mkdir -p "$M"
  for p in "$DP"/*.patch; do f=$(sed -n '2s#^+++ b/\([^[:space:]]*\).*#\1#p' "$p"); mkdir -p "$M/$(dirname "$f")"; cp "/mnt/skills/$f" "$M/$f"; done
  expect 0 "apply decision patches to temp copies" bash "$AP" "$M" --dir "$DP"
  python3 "$SC/gate_audit.py" --roots "$M/user" "$M/plugins" | grep -c '\[GAP\]' | grep -qx 0 && ok "gap closed on the patched copies" || bad "gap not closed"
  expect 0 "revert decision patches" bash "$AP" "$M" --dir "$DP" --revert
  same=1; for p in "$DP"/*.patch; do f=$(sed -n '2s#^+++ b/\([^[:space:]]*\).*#\1#p' "$p"); cmp -s "$M/$f" "/mnt/skills/$f" || same=0; done
  [ $same -eq 1 ] && ok "revert restores originals byte for byte" || bad "revert not exact"

  stage "9d. the whole action plan, rehearsed on a full copy of the portfolio"
  WORK="$T/rehearsal" bash "$HERE/tests/rehearse_action_plan.sh" >"$T/reh.log" 2>&1
  [ $? -eq 0 ] && ok "rehearsal script completed" || bad "rehearsal script failed"
  grep -q "7/9 checks passed" "$T/reh.log" && ok "pre-state: exactly the 2 documented gaps fail (7/9)" || bad "pre-state differs"
  [ "$(grep -c '12/12 checks passed' "$T/reh.log")" -ge 2 ] && ok "post-state and post-rollback re-apply: 12/12" || bad "post-state not 12/12"
  [ "$(grep -c 'byte-identical to the ORIGINAL' "$T/reh.log")" -eq 3 ] && ok "rollback restored all 3 retired copies byte-identical" || bad "rollback not exact"
  grep -q "gate gaps           : 2 -> 0" "$T/reh.log" && ok "quality-gate gaps 2 -> 0" || bad "gate gaps not closed"
  [ -z "$(find "$T/rehearsal" -name '*.orig' 2>/dev/null)" ] && ok "no .orig files left in the rehearsal copy" || bad ".orig pollution"

  stage "9e. real Claude Code CLI (informational: not counted, covered by LIVE_VERIFICATION.md)"
  CLAUDE_CLI="${CLAUDE_BIN:-$(command -v claude 2>/dev/null)}"
  if [ -n "$CLAUDE_CLI" ] && [ -x "$CLAUDE_CLI" ]; then
    "$CLAUDE_CLI" plugin validate "$HERE" >"$T/cc.txt" 2>&1; grep -qi "validation passed" "$T/cc.txt" && echo "  INFO: claude plugin validate -> passed" || { echo "  FAIL: claude plugin validate"; cat "$T/cc.txt"; FAILS=$((FAILS+1)); }
  else echo "  INFO: Claude Code CLI not installed here; plugin loading not re-verified (see LIVE_VERIFICATION.md L1)"; fi

  stage "10. patch round-trip on temp copies (revert -> check -> apply -> byte-equal to live)"
  AP="$HERE/portfolio-patches/apply_patches.sh"; NP=$(ls "$HERE"/portfolio-patches/*.patch | wc -l)
  C="$T/copy"; mkdir -p "$C"
  for p in "$HERE"/portfolio-patches/*.patch; do
    f=$(sed -n '2s#^+++ b/\([^[:space:]]*\).*#\1#p' "$p"); mkdir -p "$C/$(dirname "$f")"; cp "/mnt/skills/$f" "$C/$f"
  done
  expect 0 "revert on copies" bash "$AP" "$C" --revert
  bash "$AP" "$C" --check | grep -c '^needed' | grep -qx "$NP" && ok "all $NP patches needed after revert" || bad "check after revert"
  expect 0 "apply on copies" bash "$AP" "$C"
  same=1; for p in "$HERE"/portfolio-patches/*.patch; do f=$(sed -n '2s#^+++ b/\([^[:space:]]*\).*#\1#p' "$p"); cmp -s "$C/$f" "/mnt/skills/$f" || same=0; done
  [ $same -eq 1 ] && ok "patched copies byte-identical to live files" || bad "patched copies differ from live"
  expect 0 "idempotent re-apply" bash "$AP" "$C"
  bash "$AP" /mnt/skills --check | grep -c '^already' | grep -qx "$NP" && ok "live mount reports all $NP patches already applied" || bad "live mount not fully patched"
else
  stage "6-10. portfolio stages"; skip "portfolio not mounted; stages 6-10 not run (this is NOT a pass)"
fi

echo; if [ $FAILS -eq 0 ] && [ $SKIPS -eq 0 ]; then echo "UAT RESULT: PASS"; exit 0
elif [ $FAILS -eq 0 ]; then echo "UAT RESULT: INCOMPLETE ($SKIPS stage(s) skipped, 0 failed)"; exit 2
else echo "UAT RESULT: FAIL ($FAILS)"; exit 1; fi
