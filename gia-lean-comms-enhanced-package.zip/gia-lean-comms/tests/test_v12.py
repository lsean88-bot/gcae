"""v1.2 tests: registry, gate audit, validator, sign-off log, gates runner, pre-commit,
trigger proxy, and the patched governance content. Mount-dependent tests skip (not pass)
when the portfolio is absent."""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SKILL = ROOT / "skills" / "gia-lean-comms"
SC = SKILL / "scripts"
PLUG = Path("/mnt/skills/plugins")
SEED = Path(__file__).resolve().parent.parent / "skills" / "gia-lean-comms" / "references" / "seed"
SEED_REG, SEED_BASE = SEED / "portfolio-registry.seed.json", SEED / "baseline.seed.txt"
MOUNTED = (PLUG / "skill-factory").is_dir()
sys.path.insert(0, str(SC))
import gate_audit, interop_check, registry_check, validate_portfolio  # noqa: E402


def sh(*cmd, env=None, cwd=None):
    e = dict(os.environ, **(env or {}))
    return subprocess.run([str(c) for c in cmd], capture_output=True, text=True, env=e, cwd=cwd)


def skill(root, name, body="body\n", desc="d"):
    d = Path(root, name)
    d.mkdir(parents=True, exist_ok=True)
    (d / "SKILL.md").write_text(f"---\nname: {name.split(':')[-1]}\ndescription: {desc}\n---\n{body}")
    return d


class Registry(unittest.TestCase):
    def setUp(self):
        self.t = tempfile.TemporaryDirectory()
        self.u, self.p = Path(self.t.name, "user"), Path(self.t.name, "plugins")
        self.u.mkdir(); self.p.mkdir()
        self.roots = [str(self.u), str(self.p)]
        self.reg = Path(self.t.name, "reg.json")

    def tearDown(self):
        self.t.cleanup()

    def write_reg(self, collisions, aliases=()):
        self.reg.write_text(json.dumps({"collisions": collisions, "aliases": list(aliases)}))

    def run_check(self, *extra):
        return sh(sys.executable, SC / "registry_check.py", "--registry", self.reg, "--roots", *self.roots, *extra)

    def decl(self, a, b, role_b="stale"):
        return {"base": "foo", "status": "stale_copy",
                "canonical": {"path": a, "role": "canonical", "sha256": registry_check.sha(self.t.name + "/" + a)},
                "others": [{"path": b, "role": role_b, "sha256": registry_check.sha(self.t.name + "/" + b)}],
                "evidence": {}, "owner_action": ""}

    def test_undeclared_divergent_collision_is_error(self):
        skill(self.u, "foo", "one\n"); skill(self.p, "mk:foo", "two\n"); self.write_reg([])
        r = self.run_check()
        self.assertEqual(r.returncode, 1, r.stdout)
        self.assertIn("undeclared_collision", r.stdout)

    def test_identical_mirrors_are_fine(self):
        skill(self.u, "foo", "same\n"); skill(self.p, "mk:foo", "same\n"); self.write_reg([])
        # names differ in frontmatter only by folder; make bytes identical
        (self.p / "mk:foo" / "SKILL.md").write_bytes((self.u / "foo" / "SKILL.md").read_bytes())
        self.assertEqual(self.run_check().returncode, 0)

    def test_declared_collision_passes(self):
        skill(self.u, "foo", "one\n"); skill(self.p, "mk:foo", "two\n")
        self.write_reg([self.decl("user/foo", "plugins/mk:foo")])
        self.assertEqual(self.run_check().returncode, 0)

    def test_changed_copy_makes_declaration_stale(self):
        skill(self.u, "foo", "one\n"); skill(self.p, "mk:foo", "two\n")
        self.write_reg([self.decl("user/foo", "plugins/mk:foo")])
        (self.u / "foo" / "SKILL.md").write_text("---\nname: foo\ndescription: d\n---\nCHANGED\n")
        r = self.run_check()
        self.assertEqual(r.returncode, 1)
        self.assertIn("registry_stale", r.stdout)

    def test_declared_path_missing_is_error(self):
        skill(self.u, "foo", "one\n"); skill(self.p, "mk:foo", "two\n")
        d = self.decl("user/foo", "plugins/mk:foo")
        shutil.rmtree(self.p / "mk:foo")
        skill(self.p, "other")
        self.write_reg([d])
        self.assertIn("declared_missing", self.run_check().stdout)

    def test_unreadable_registry_is_incomplete_exit_2(self):
        self.reg.write_text("{not json")
        self.assertEqual(self.run_check().returncode, 2)

    def test_cites_stale_copy_is_warning_only(self):
        skill(self.u, "foo", "one\n"); skill(self.p, "mk:foo", "two\n")
        skill(self.p, "citer", "uses `mk:foo` here\n")
        self.write_reg([self.decl("user/foo", "plugins/mk:foo")])
        r = self.run_check()
        self.assertEqual(r.returncode, 0)
        self.assertIn("cites stale copy", r.stdout)

    def test_init_lists_collisions_with_overlap(self):
        skill(self.u, "foo", "one\nshared\n"); skill(self.p, "mk:foo", "two\nshared\n")
        out = json.loads(sh(sys.executable, SC / "registry_check.py", "--roots", *self.roots, "--init").stdout)
        self.assertEqual(out[0]["base"], "foo")
        self.assertIn("overlap_vs_first", out[0]["others"][0])

    def test_alias_suppresses_prefix_mismatch(self):
        skill(self.u, "alpha", "see `mk:alpha`\n"); skill(self.p, "mk:beta")
        names = interop_check.index(self.roots)
        f = interop_check.audit_citations(names, self.roots)
        self.assertEqual([x["kind"] for x in f], ["prefix_mismatch"] if "mk:alpha" not in names else [])
        reg = Path(self.t.name, "r2.json")
        reg.write_text(json.dumps({"aliases": [{"names": ["mk:alpha", "alpha"]}]}))
        self.assertEqual(interop_check.audit_citations(names, self.roots, aliases=interop_check.alias_set(reg)), [])


class GateAudit(unittest.TestCase):
    def audit(self, body):
        with tempfile.TemporaryDirectory() as d:
            skill(d, "s", body)
            return gate_audit.audit([d])

    FULL = ("| 1 | Every finding has named evidence file or web-validated portal |\n"
            "| 2 | Every rate web-validated source URL |\n| 3 | Correct Act effective date jurisdiction |\n"
            "| 4 | No duplicate findings |\n| 5 | No retracted draft text |\n| 6 | Risk colour rated |\n"
            "| 7 | CD / SD / MW deficiency classification |\n| 8 | Aggregation assessment |\n"
            "| 9 | SMART |\n| 10 | Version sign-off |\n| 11 | Document appendix |\n| 12 | Disclaimer |\n")

    def test_complete_gate_has_no_gaps(self):
        r = self.audit("## Quality Gate — 12 items\n\n" + self.FULL)[0]
        self.assertEqual((r["asserted"], r["enumerated"], r["missing_concepts"]), (12, 12, []))

    def test_ten_item_gate_missing_two_concepts(self):
        body = "\n".join(l for l in self.FULL.splitlines() if "CD / SD" not in l and "Aggregation" not in l)
        r = self.audit("## 10-Item CAE Quality Gate\n\n" + body + "\n")[0]
        self.assertEqual(r["missing_concepts"], ["aggregation", "deficiency_classification"])

    def test_count_mismatch_detected(self):
        r = self.audit("## 12-Item Quality Gate\n\n" + "\n".join(self.FULL.splitlines()[:11]) + "\n")[0]
        self.assertFalse(r["count_consistent"])

    def test_checkbox_marker_items_and_decorative_headings(self):
        body = ("## ═══════\n## MODULE 10 — QUALITY GATE (3-ITEM)\n## ═══════\n\n"
                "☐  01  evidence\n☐  02  duplicate\n☐  03  disclaimer\n")
        r = self.audit(body)[0]
        self.assertEqual((r["asserted"], r["enumerated"]), (3, 3))

    def test_no_gate_no_rows(self):
        self.assertEqual(self.audit("# nothing\ntext\n"), [])

    def test_strict_exit_code(self):
        with tempfile.TemporaryDirectory() as d:
            skill(d, "s", "## 10-Item Quality Gate\n| 1 | evidence |\n")
            self.assertEqual(sh(sys.executable, SC / "gate_audit.py", "--roots", d).returncode, 0)
            self.assertEqual(sh(sys.executable, SC / "gate_audit.py", "--roots", d, "--strict").returncode, 1)


class ValidatePortfolio(unittest.TestCase):
    def val(self, fm_text, body="x\n"):
        with tempfile.TemporaryDirectory() as d:
            sd = Path(d, "s"); sd.mkdir()
            (sd / "SKILL.md").write_text(f"---\n{fm_text}\n---\n{body}")
            return validate_portfolio.validate(sd)

    def test_valid(self):
        r = self.val("name: ok\ndescription: fine")
        self.assertEqual((r["errors"], r["warns"], r["upload_only"]), ([], [], []))

    def test_code_only_key_is_warning_and_upload_blocker(self):
        r = self.val("name: ok\ndescription: fine\nargument-hint: x\ntags: [a]")
        self.assertEqual(r["errors"], [])
        self.assertEqual(len(r["upload_only"]), 2)

    def test_missing_name_is_warning_not_error(self):
        r = self.val("description: fine")
        self.assertEqual(r["errors"], [])
        self.assertTrue(r["upload_only"])

    def test_errors(self):
        self.assertTrue(self.val("name: ok\ndescription: " + "x" * 1100)["errors"])
        self.assertTrue(self.val("name: ok\ndescription: 'a <b> c'")["errors"])
        self.assertTrue(self.val("name: Bad_Name\ndescription: d")["errors"])
        self.assertTrue(self.val("name: ok")["errors"])
        self.assertTrue(self.val("name: ok\ndescription: bad: colon: yaml: [")["errors"])

    def test_no_frontmatter(self):
        with tempfile.TemporaryDirectory() as d:
            sd = Path(d, "s"); sd.mkdir(); (sd / "SKILL.md").write_text("no fm")
            self.assertTrue(validate_portfolio.validate(sd)["errors"])

    def test_exit_codes(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(sh(sys.executable, SC / "validate_portfolio.py", "--roots", d).returncode, 2)
            skill(d, "good", desc="fine")
            self.assertEqual(sh(sys.executable, SC / "validate_portfolio.py", "--roots", d).returncode, 0)
            Path(d, "bad").mkdir(); Path(d, "bad", "SKILL.md").write_text("nope")
            self.assertEqual(sh(sys.executable, SC / "validate_portfolio.py", "--roots", d).returncode, 1)

    @unittest.skipUnless(Path("/mnt/skills/examples/skill-creator/scripts/quick_validate.py").exists() and MOUNTED, "no mount")
    def test_upload_verdict_matches_skill_creator_validator_on_real_portfolio(self):
        sys.path.insert(0, "/mnt/skills/examples/skill-creator/scripts")
        import quick_validate
        strict_bad = set()
        rows = json.loads(sh(sys.executable, SC / "validate_portfolio.py", "--json").stdout)["detail"]
        for k in rows:
            root, name = k.split("/", 1)
            ok, _ = quick_validate.validate_skill(f"/mnt/skills/{root}/{name}")
            if not ok:
                strict_bad.add(k)
        mine = {k for k, v in rows.items() if v["errors"] or v["upload_only"]}
        self.assertEqual(mine, strict_bad)


class ReviewLog(unittest.TestCase):
    def setUp(self):
        self.t = tempfile.TemporaryDirectory()
        d = Path(self.t.name)
        self.o, self.c, self.log = d / "n.log", d / "n_c.log", d / "log.jsonl"
        self.o.write_text("It doesn't add new infrastructure.")
        self.c.write_text("No new infrastructure.")
        self.rl = lambda *a: sh(sys.executable, SC / "review_log.py", *a)

    def tearDown(self):
        self.t.cleanup()

    def rec(self, name="Reviewer One", decision="approve"):
        return self.rl("record", self.o, self.c, "--reviewer", name, "--decision", decision, "--log", self.log)

    def test_record_and_verify(self):
        self.assertEqual(self.rec().returncode, 0)
        self.assertEqual(self.rl("verify", self.o, self.c, "--log", self.log).returncode, 0)

    def test_automated_reviewer_refused(self):
        for n in ("Claude", "assistant", "AI", "x"):
            self.assertEqual(self.rec(n).returncode, 2, n)
        self.assertFalse(self.log.exists())

    def test_fail_cannot_be_signed_off(self):
        self.c.write_text("Check optional. Run 2 times.")
        self.o.write_text("The check is not optional. Run 3 times.")
        self.assertEqual(self.rec().returncode, 1)

    def test_pass_needs_no_signoff(self):
        self.c.write_text(self.o.read_text())
        r = self.rec()
        self.assertEqual(r.returncode, 0)
        self.assertIn("Nothing to sign", r.stdout)
        self.assertFalse(self.log.exists())

    def test_reject_does_not_verify(self):
        self.rec(decision="reject")
        self.assertEqual(self.rl("verify", self.o, self.c, "--log", self.log).returncode, 1)

    def test_change_voids_approval(self):
        self.rec()
        self.c.write_text("No new infrastructure. Plus more.")
        self.assertEqual(self.rl("verify", self.o, self.c, "--log", self.log).returncode, 1)

    def test_tampering_breaks_chain(self):
        self.rec()
        e = json.loads(self.log.read_text())
        e["reviewer"] = "Someone Else"
        self.log.write_text(json.dumps(e) + "\n")
        self.assertEqual(self.rl("audit", "--log", self.log).returncode, 1)
        self.assertEqual(self.rl("verify", self.o, self.c, "--log", self.log).returncode, 1)
        self.assertEqual(self.rec("Reviewer Two").returncode, 1)  # refuses to append to a broken log

    def test_chain_links_entries(self):
        self.rec(); self.rec("Reviewer Two", "reject")
        a, b = [json.loads(l) for l in self.log.read_text().splitlines()]
        self.assertEqual(b["prev_hash"], a["entry_hash"])
        self.assertEqual(self.rl("audit", "--log", self.log).returncode, 0)

    def test_latest_decision_wins(self):
        self.rec(decision="approve"); self.rec("Reviewer Two", "reject")
        self.assertEqual(self.rl("verify", self.o, self.c, "--log", self.log).returncode, 1)

    def test_gate_passes_review_only_with_signoff(self):
        gate = lambda *a: sh(sys.executable, SC / "compress_gate.py", *a).returncode
        self.assertEqual(gate(self.o, self.c), 3)
        self.rec()
        self.assertEqual(gate(self.o, self.c, "--signoff", self.log), 0)
        self.assertEqual(gate(self.o, self.c), 3)
        self.assertEqual(gate(self.o, self.c, "--signoff"), 64)


class Robustness(unittest.TestCase):
    def test_validator_without_pyyaml_is_incomplete(self):
        with tempfile.TemporaryDirectory() as d:
            skill(d, "good", desc="fine")
            code = ("import sys; sys.modules['yaml']=None; sys.path.insert(0, %r); import validate_portfolio as v; "
                    "sys.exit(v.main(['--roots', %r]))" % (str(SC), d))
            r = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True)
            self.assertEqual(r.returncode, 2, r.stdout + r.stderr)
            self.assertIn("INCOMPLETE", r.stdout)

    def test_review_log_reports_guard_crash_as_incomplete(self):
        with tempfile.TemporaryDirectory() as d:
            o, c = Path(d, "o.txt"), Path(d, "c.txt")
            o.write_bytes(b"\xff\xfe not utf8"); c.write_text("x")
            r = sh(sys.executable, SC / "review_log.py", "record", o, c, "--reviewer", "Reviewer One",
                   "--decision", "approve", "--log", Path(d, "l.jsonl"))
            self.assertEqual(r.returncode, 2, r.stdout + r.stderr)
            self.assertNotIn("Traceback", r.stderr)

    def test_acknowledged_and_former_names_are_suppressed_for_bare_check(self):
        with tempfile.TemporaryDirectory() as d:
            skill(d, "alpha", "Use the `ghost-skill` skill, the `old-name` skill, and the `real-miss` skill.\n")
            reg = Path(d, "r.json")
            reg.write_text(json.dumps({"acknowledged_uninstalled": ["ghost-skill"], "former_names": {"old-name": "alpha"}}))
            names = interop_check.index([d])
            f = interop_check.audit_citations(names, [d], include_bare=True, acknowledged=interop_check.acknowledged_set(reg))
            self.assertEqual([x["cites"] for x in f], ["real-miss"])

    def test_shipped_registry_makes_bare_check_clean_on_mount(self):
        if not MOUNTED:
            self.skipTest("no mount")
        r = sh(sys.executable, SC / "interop_check.py", "--audit-citations", "--include-bare", "--registry",
               SEED_REG)
        self.assertIn("Citation findings: 0", r.stdout)


class TriggerProxy(unittest.TestCase):
    def test_shipped_description_has_no_gaps_or_risks(self):
        r = sh(sys.executable, SC / "trigger_proxy.py", "--skill", SKILL, "--evals", ROOT / "evals" / "trigger_evals.json")
        self.assertEqual(r.returncode, 0, r.stdout)

    def test_gap_and_risk_are_detected(self):
        with tempfile.TemporaryDirectory() as d:
            skill(d, "s", desc="'Handles payroll calculations. Trigger on: payroll run'")
            ev = Path(d, "e.json")
            ev.write_text(json.dumps([{"query": "compress my notes file", "should_trigger": True},
                                      {"query": "run the payroll run tonight", "should_trigger": False}]))
            r = sh(sys.executable, SC / "trigger_proxy.py", "--skill", Path(d, "s"), "--evals", ev)
            self.assertEqual(r.returncode, 1)
            self.assertIn("GAP", r.stdout)
            self.assertIn("RISK", r.stdout)

    def test_unquoted_colon_in_description_is_incomplete_not_silently_ok(self):
        with tempfile.TemporaryDirectory() as d:
            skill(d, "s", desc="Handles payroll. Trigger on: payroll run")
            ev = Path(d, "e.json"); ev.write_text("[]")
            self.assertEqual(sh(sys.executable, SC / "trigger_proxy.py", "--skill", Path(d, "s"), "--evals", ev).returncode, 2)

    def test_unreadable_inputs_incomplete(self):
        self.assertEqual(sh(sys.executable, SC / "trigger_proxy.py", "--skill", "/nope", "--evals", "/nope").returncode, 2)

    def test_eval_set_is_balanced_and_well_formed(self):
        ev = json.loads((ROOT / "evals" / "trigger_evals.json").read_text())
        self.assertEqual(sum(e["should_trigger"] for e in ev), 10)
        self.assertEqual(sum(not e["should_trigger"] for e in ev), 10)
        self.assertTrue(all(set(e) == {"query", "should_trigger"} for e in ev))


@unittest.skipUnless(MOUNTED, "portfolio not mounted")
class GatesRunner(unittest.TestCase):
    """The seed registry and baseline describe THIS sandbox, so these tests pass them explicitly
    (they are fixtures, never implicit defaults). The tmp state dir keeps the user's ~ untouched."""
    G = SC / "portfolio_gates.sh"
    SEEDED = ["--registry", str(SEED_REG), "--baseline", str(SEED_BASE)]

    def test_missing_drift_script_is_incomplete(self):
        r = sh("bash", self.G, *self.SEEDED, env={"DRIFT_SCRIPT": "/nope"})
        self.assertEqual(r.returncode, 2, r.stdout)
        self.assertIn("INCOMPLETE", r.stdout)

    def test_new_finding_fails(self):
        with tempfile.TemporaryDirectory() as d:
            skill(d, "x", "## 11-Item Quality Gate\nAll 11 must pass.\n")
            r = sh("bash", self.G, *self.SEEDED, "--skills-dir", d)
            self.assertEqual(r.returncode, 1, r.stdout)
            self.assertIn("NEW:", r.stdout)

    def test_baseline_roundtrip_passes_and_unknown_option_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            b = Path(d, "base.txt")
            self.assertEqual(sh("bash", self.G, "--registry", str(SEED_REG), "--baseline", b, "--write-baseline").returncode, 0)
            self.assertTrue(b.read_text().startswith("# portfolio_gates baseline"))
            r = sh("bash", self.G, "--registry", str(SEED_REG), "--baseline", b)
            self.assertEqual(r.returncode, 0, r.stdout[-600:])
            self.assertIn("PASS", r.stdout)
        self.assertEqual(sh("bash", self.G, "--bogus").returncode, 64)

    def test_missing_baseline_warns_and_counts_everything_as_new(self):
        r = sh("bash", self.G, "--registry", str(SEED_REG), "--baseline", "/nope/base.txt")
        self.assertEqual(r.returncode, 1)
        self.assertIn("no baseline", r.stdout)

    def test_seed_state_gives_pass_on_the_sandbox_it_was_written_for(self):
        r = sh("bash", self.G, *self.SEEDED)
        self.assertEqual(r.returncode, 0, r.stdout[-800:])

    def test_runner_does_not_modify_skill_files(self):
        before = sh("bash", "-c", "find /mnt/skills/plugins -name SKILL.md -newer /etc/hostname | wc -l").stdout
        sh("bash", self.G, *self.SEEDED)
        after = sh("bash", "-c", "find /mnt/skills/plugins -name SKILL.md -newer /etc/hostname | wc -l").stdout
        self.assertEqual(before, after)


@unittest.skipUnless(shutil.which("git"), "git not installed")
class PreCommit(unittest.TestCase):
    def setUp(self):
        self.t = tempfile.TemporaryDirectory()
        self.r = Path(self.t.name)
        for c in (["init", "-q"], ["config", "user.email", "t@t"], ["config", "user.name", "t"]):
            sh("git", *c, cwd=self.r)
        hook = self.r / ".git" / "hooks" / "pre-commit"
        shutil.copy(ROOT / "templates" / "pre-commit.sh", hook)
        hook.chmod(0o755)
        self.env = {"GIA_LEAN_COMMS": str(SKILL), "GIA_SKILLS_ROOT": str(self.r / "skills")}

    def tearDown(self):
        self.t.cleanup()

    def commit(self, msg="m"):
        sh("git", "add", "-A", cwd=self.r)
        return sh("bash", ".git/hooks/pre-commit", cwd=self.r, env=self.env), sh("git", "commit", "-q", "-m", msg, cwd=self.r, env=self.env)

    def test_valid_skill_commit_allowed(self):
        skill(self.r / "skills", "good", desc="fine")
        _, c = self.commit()
        self.assertEqual(c.returncode, 0, c.stdout + c.stderr)

    def test_broken_path_citation_blocks_commit(self):
        skill(self.r / "skills", "bad", "run /mnt/skills/plugins/zzz-none/scripts/x.py\n", desc="fine")
        h, c = self.commit()
        self.assertNotEqual(c.returncode, 0)
        self.assertIn("BLOCKED", h.stdout + c.stdout + c.stderr)

    def test_invalid_frontmatter_blocks_commit(self):
        d = self.r / "skills" / "bad"; d.mkdir(parents=True); (d / "SKILL.md").write_text("no frontmatter")
        _, c = self.commit()
        self.assertNotEqual(c.returncode, 0)

    def test_non_skill_change_skips_gates(self):
        (self.r / "README.md").write_text("hi")
        h, c = self.commit()
        self.assertEqual(c.returncode, 0)
        self.assertNotIn("running gates", h.stdout)

    def test_missing_plugin_is_incomplete_not_pass(self):
        skill(self.r / "skills", "good", desc="fine")
        self.env["GIA_LEAN_COMMS"] = "/nope"
        _, c = self.commit()
        self.assertNotEqual(c.returncode, 0)


@unittest.skipUnless(MOUNTED, "portfolio not mounted")
class PatchedContent(unittest.TestCase):
    def test_charlie_hills_has_all_five_phase_headers_and_original_content(self):
        t = (PLUG / "charlie-hills-code" / "SKILL.md").read_text()
        for i, n in enumerate(["Plan", "Verify", "Execute", "Check", "Log"], 1):
            self.assertIn(f"## Phase {i} \u2014 {n}", t)
        for kept in ("### 1. Plan Node Default", "### 6. Autonomous Bug Fixing", "## Task Management Protocol",
                     "## Self-Check Before Marking Anything Done"):
            self.assertIn(kept, t)
        self.assertIn("one self-learning mechanism, not two", t.replace("\n", " "))

    def test_drift_check_4_and_6_clean(self):
        out = sh("bash", PLUG / "iron-rules-governance" / "scripts" / "check-governance-drift.sh").stdout
        for n in (4, 6):
            seg = out.split(f"--- Check {n}:")[1].split("--- Check")[0]
            self.assertIn("clean", seg, f"check {n}")

    def test_governance_register_names_and_counts(self):
        t = (PLUG / "iron-rules-governance" / "SKILL.md").read_text()
        self.assertEqual(t.count("- [ ]"), 12)
        self.assertIn("Quality Gate \u2014 12 items", t)
        self.assertIn("Resolved 2026-10-03", t)
        self.assertNotIn("`cae-audit-cowork-plugin-v5`, `cae-report-conversion`", t)
        flat = t.replace("\n", " ")
        self.assertIn("overstated the gap", flat)            # the register admits its first measurement was wrong
        self.assertIn("except **CD / SD / MW classification**", flat)
        self.assertIn("and **not applied**", flat)
        self.assertNotIn("go FINAL without either", flat)    # the retracted claim must not return
        self.assertTrue((PLUG / "cae-cowork-plugin-v5").is_dir())

    def test_raw_evidence_log_untouched(self):
        t = (PLUG / "iron-rules-governance" / "references" / "drift-check-2026-09-27.md").read_text()
        self.assertIn("cae-audit-cowork-plugin-v5", t)

    def test_path_bearing_citations_point_at_canonical_copy(self):
        for f in ("skill-factory", "skill-sprawl-watch", "independent-critique"):
            for line in (PLUG / f / "SKILL.md").read_text().splitlines():
                if "mktron-sentinel:self-learning-loop" in line:
                    self.assertNotIn("data/lessons", line)
                    self.assertNotIn("log_lesson.py", line)
        for p in ("data/lessons_promoted.md", "scripts/log_lesson.py"):
            self.assertTrue((PLUG / "self-learning-loop" / p).exists(), p)
            self.assertFalse((PLUG / "mktron-sentinel:self-learning-loop" / p).exists(), p)

    def test_live_registry_has_no_errors(self):
        self.assertEqual(sh(sys.executable, SC / "registry_check.py", "--registry", SEED_REG).returncode, 0)

    def test_every_registry_collision_matches_live_content(self):
        reg = json.loads(SEED_REG.read_text())
        self.assertEqual(len(reg["collisions"]), 5)
        for c in reg["collisions"]:
            for e in [c["canonical"]] + c["others"]:
                top, _, name = e["path"].partition("/")
                self.assertEqual(registry_check.sha(Path("/mnt/skills", top, name)), e["sha256"], e["path"])

    def test_gate_audit_reproduces_documented_finding(self):
        """Per SKILL across all its gates (not per section): the v6 engine and its duplicate lack only
        CD/SD/MW classification; v5 (older, predates the feature) lacks classification and aggregation."""
        rows = gate_audit.audit(["/mnt/skills/user", "/mnt/skills/plugins"])
        sk = gate_audit.per_skill(rows)
        for k in ("user/cae-fieldwork-engine", "plugins/cae-cowork-ai-plugin"):
            self.assertEqual(sk[k]["union_missing"], ["deficiency_classification"], k)
            self.assertEqual(len(sk[k]["gates"]), 2, k)
        self.assertEqual(sk["plugins/cae-cowork-plugin-v5"]["union_missing"], ["aggregation", "deficiency_classification"])
        self.assertEqual(sk["plugins/iron-rules-governance"]["union_missing"], [])
        sec = {(r["skill"], r["asserted"]): r for r in rows}
        self.assertEqual(sec[("user/cae-fieldwork-engine", 10)]["enumerated"], 10)
        self.assertEqual(sec[("user/cae-fieldwork-engine", 30)]["enumerated"], 30)

    def test_all_edited_skills_still_valid(self):
        for s in ("skill-factory", "independent-critique", "skill-sprawl-watch", "charlie-hills-code",
                  "iron-rules-governance", "sp-global:funding-digest"):
            self.assertEqual(validate_portfolio.validate(PLUG / s)["errors"], [], s)


if __name__ == "__main__":
    unittest.main(verbosity=2)
