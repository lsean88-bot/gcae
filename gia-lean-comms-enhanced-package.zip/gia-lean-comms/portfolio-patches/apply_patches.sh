#!/usr/bin/env bash
# Apply (or check / revert) the 2026-10-02 portfolio patches.
# Usage: apply_patches.sh [SKILLS_ROOT] [--check | --revert] [--dir PATCH_DIR]
#   --dir selects another folder of .patch files, e.g. ../decision-patches (owner-decision patches,
#   never applied by default).
#   SKILLS_ROOT defaults to /mnt/skills. Patch paths are relative to it (plugins/<skill>/...).
# Idempotent: an already-applied patch is reported and skipped; a patch whose target file has
# diverged is reported as CONFLICT and left untouched. Exit 0 = all applied/already applied,
# 1 = at least one CONFLICT or missing file. Backups of each file are written OUTSIDE the skills root,
# to $GIA_STATE_DIR/patch-backups/<timestamp>/ (default ~/.gia-lean-comms), never as .orig files beside
# the skill: stray .orig files in a skills folder were a defect found by verify_actions.py.
set -u
ROOT="/mnt/skills"; MODE="apply"; HERE="$(cd "$(dirname "$0")" && pwd)"; PDIR=""
while [ $# -gt 0 ]; do
  case "$1" in
    --check) MODE="check" ;;
    --revert) MODE="revert" ;;
    --dir) PDIR="${2:-}"; shift ;;
    *) ROOT="$1" ;;
  esac
  shift
done
PDIR="${PDIR:-$HERE}"
BK="${GIA_STATE_DIR:-$HOME/.gia-lean-comms}/patch-backups/$(date -u +%Y%m%dT%H%M%SZ)"
if [ ! -d "$PDIR" ]; then echo "patch directory not found: $PDIR"; exit 64; fi
BAD=0
for p in "$PDIR"/*.patch; do
  name="$(basename "$p")"
  target="$(sed -n '2s#^+++ b/\([^[:space:]]*\).*#\1#p' "$p")"
  if [ ! -f "$ROOT/$target" ]; then echo "MISSING   $name -> $ROOT/$target"; BAD=1; continue; fi
  if patch -p1 -d "$ROOT" --dry-run -s -R < "$p" >/dev/null 2>&1; then
    if [ "$MODE" = "revert" ]; then patch -p1 -d "$ROOT" -s -R < "$p" && echo "REVERTED  $name"; else echo "already   $name"; fi
  elif patch -p1 -d "$ROOT" --dry-run -s < "$p" >/dev/null 2>&1; then
    case "$MODE" in
      apply) mkdir -p "$BK/$(dirname "$target")" && cp -p "$ROOT/$target" "$BK/$target" \
               && patch -p1 -d "$ROOT" -s < "$p" && echo "APPLIED   $name" ;;
      check) echo "needed    $name" ;;
      revert) echo "not applied $name" ;;
    esac
  else
    echo "CONFLICT  $name (target differs from both original and patched; not touched)"; BAD=1
  fi
done
exit $BAD
