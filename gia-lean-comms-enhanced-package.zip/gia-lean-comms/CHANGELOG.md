# Changelog

## 1.4.0 (2026-10-10): the action plan, executed on a rehearsal copy
Added: `retire_copy.py` (safe, reversible retirement with hash pre-checks, whole-token reference matching, evidence-log
ignores, review acknowledgements, manifest, byte-exact rollback), `verify_actions.py` (every post-condition of the plan),
`tests/rehearse_action_plan.sh` (the whole plan on a full copy), `action-results/`, `templates/promote_claude_md.sh` +
`CLAUDE.gia-additions.md` (D6), decision patches 03-04 (repoint two references), `portfolio_gates.sh --roots`.
Fixed: `apply_patches.sh` left `.orig` files inside skill folders (caught by `verify_actions.py`); backups now go to the state dir.
Verified for real: `claude plugin validate` passes; the plugin loads as `gia-lean-comms@skills-dir` (CLI v2.1.296).
Corrected plan: D2 needed two reference repoints first; D3 and D4 needed explicit acknowledgements. Tests 185 -> 217; UAT checks 60 -> 68.

## 1.3.0 (2026-10-07): critique round
Fixed (found by an adversarial critique of v1.2; each has a regression test that fails on the old code):
- Meaning guard rewritten: amounts glued to currency codes, identifiers, versions, clause refs, Roman
  numerals and months are now seen; English, Malay, Spanish and Chinese packs; NFKC; spelled-out numbers;
  `5 percent` = `5%`; `1,700` = `1700`; ordering check. Evasions passing silently 15/20 -> 5/20;
  glued amounts missed 9/10 -> 0; false alarms on faithful rewrites 9/17 -> 0.
- Zone guard failed open on 15 of 28 realistic filenames; data files are no longer lean by extension and
  Chinese, Spanish and Malay names are protected.
- Registry found skills by this container's folder names (false errors elsewhere) and hashed raw bytes
  (CRLF broke it): now locates by folder name and hashes line-ending-normalised content.
- Sign-off log forked its hash chain under contention: now serialised by a file lock.
- An overstated quality-gate finding is corrected everywhere; coverage is measured per skill across all gates.
Added: near-duplicate detection under different names; superseded declarations; `registry_check --refresh`;
`gate_audit` two-gate parsing and `--registry`; `live_verify.sh`; `decision-patches/` (owner decisions, never
applied by default); generator-driven fuzz with an independent oracle; `ACTION_PLAN.md`, `CRITIQUE.md`,
`LIVE_VERIFICATION.md`; `ruff.toml`. Tests 123 -> 185. Lessons 7-11 added to the proposal.
Production hardening: registry and baseline moved out of the plugin folder into a state directory (a plugin update replaced them; they were also anchored to one sandbox); `registry_check --bootstrap` and `portfolio_gates.sh --bootstrap` for a new installation (dry run by default, accepts the state as unreviewed, alerts on change); a missing state file is INCOMPLETE, never silently the seed; seed files kept as documented fixtures.
Process: the stale package was rebuilt; a duplicate-row mistake in the raw lessons store was repaired.

## 1.2.0 (2026-10-03)
Registry, gate audit, validator, sign-off log, gates runner with dated baseline, pre-commit hook, trigger evals.

## 1.1.0 (2026-10-02)
`interop_check` deep/ignore/severity/bare modes; `meaning_guard --show-lines`; first 6 patches.

## 1.0.0 (2026-10-02)
`zone_guard`, `meaning_guard` (PASS/REVIEW/FAIL), `compress_gate`, `interop_check`, interop contract.
