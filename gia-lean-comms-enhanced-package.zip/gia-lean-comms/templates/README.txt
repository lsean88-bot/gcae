Copy caveman.json to <workspace>/.caveman.json for GIA engagement folders.

Effect (verified by running caveman v2.3.1 hooks, 2026-10-02): with defaultMode "off",
the HOOKS ignore natural-language triggers ("talk like caveman", "less tokens");
only an explicit /caveman <level> command activates.

NOT covered: caveman's SKILL.md description says it auto-triggers on "be brief" and
"less tokens". That path is separate from the hooks and was not tested. In GIA
workspaces, do not install the caveman skill, or rely on gia-lean-comms' protected
zones as binding regardless.
