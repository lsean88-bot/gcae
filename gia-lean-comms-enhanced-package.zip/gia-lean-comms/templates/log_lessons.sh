#!/usr/bin/env bash
# Replays the 2026-10-03 UAT lessons into the self-learning-loop RAW store (not promoted).
# Usage: bash log_lessons.sh [path/to/log_lesson.py]
L="${1:-/mnt/skills/plugins/self-learning-loop/scripts/log_lesson.py}"
C="gia-lean-comms UAT and portfolio patching, 2026-10-03"
python3 "$L" --category tooling-hygiene --context "$C" \
  --trigger "Preflight and the governance drift check silently skipped a check and still exited clean, so a skip read as a pass." \
  --correction "Any gate that cannot run must exit non-zero as INCOMPLETE and name what did not run."
python3 "$L" --category verification --context "$C" \
  --trigger "Documented that caveman defaultMode off makes natural-language triggers inert, but it only governs hooks, not the skill description." \
  --correction "Test a control at the layer it claims to cover before documenting its coverage."
python3 "$L" --category verification --context "$C" \
  --trigger "Shipped checks with no positive control, so nothing proved they could fail." \
  --correction "Break the thing on purpose and confirm the gate fails before trusting it."
python3 "$L" --category analysis-accuracy --context "$C" \
  --trigger "Called a prefixed skill name and a same-name skill pair defects/duplicates without checking the other deployment layout or content." \
  --correction "Compare content and check each layout first: the pairs were distinct roles or a stale ancestor, and canonical was bare for one and prefixed for another."
python3 "$L" --category evidence-integrity --context "$C" \
  --trigger "A path audit flagged a raw historical drift log, which is R2 evidence and must not be edited to pass." \
  --correction "Exempt raw evidence logs explicitly (an ignore option); never rewrite them."
python3 "$L" --category tooling-hygiene --context "$C" \
  --trigger "Strict skill validator encodes claude.ai upload rules and flagged 52 Claude Code skills as invalid." \
  --correction "Validate per deployment target and report code-valid and upload-ready separately."
python3 "$L" --category verification --context "gia-lean-comms critique round, 2026-10-07" \
  --trigger "A fuzz whose mutator locates tokens with the system-under-test's own regex shares its blind spots and cannot fail (amounts glued to a currency code were invisible to both)." \
  --correction "Derive mutations from the generator's own structured values, and run the fuzz against the old code as a positive control."
python3 "$L" --category analysis-accuracy --context "gia-lean-comms critique round, 2026-10-07" \
  --trigger "Measured a quality gate in isolation and over-stated the gap; the skill runs two gates before FINAL." \
  --correction "Measure coverage per skill across every gate that must pass before the outcome, and say when a first measurement is corrected."
python3 "$L" --category verification --context "gia-lean-comms critique round, 2026-10-07" \
  --trigger "A control documented as 'fails closed' failed open on 15 of 28 realistic filenames (non-English names, data extensions)." \
  --correction "Test every control against inputs in each language and file type in use, not only the author's."
python3 "$L" --category tooling-hygiene --context "gia-lean-comms critique round, 2026-10-07" \
  --trigger "Registry hashed raw bytes and keyed entries by this environment's folder names, so CRLF checkouts and any other layout produced false errors." \
  --correction "Hash line-ending-normalised content and locate items by name, then test on a relabelled layout."
python3 "$L" --category verification --context "gia-lean-comms critique round, 2026-10-07" \
  --trigger "An unlocked read-then-append on a hash chain looked safe in a low-contention test but forked under real contention and poisoned every later write." \
  --correction "Treat a clean low-contention run as weak evidence; stress the critical section directly and serialise it with a lock."
