<!-- gia-lean-comms lessons v1 (promoted per ACTION_PLAN D6; remove this whole block to undo) -->
## GIA engineering lessons (promoted from UAT, October 2026)

Scope: project and engineering conventions. A portfolio-wide rule (an Iron Rule, evidence grade, or quality-gate
change) is not written here unprompted; it goes through `self-learning-loop` and AKOS Module 7 and needs the
owner's explicit go-ahead.

1. **A skipped check is not a pass.** Any gate that cannot run reports INCOMPLETE (non-zero) and names what did not
   run. (Seen: a preflight overlap check and the governance drift check both skipped silently; the drift check
   scanned 3 of 146 skills.)
2. **Test a control at the layer it claims to cover.** (Seen: a hook default does not govern a skill-description
   trigger; a validator checked structure, not meaning.)
3. **Give every gate a positive control.** Break the thing on purpose and confirm the gate fails before trusting it.
4. **A fuzz or test must not find its targets with the code under test.** Derive mutations from the generator's own
   structured values. (Seen: a fuzz that used the guard's regex shared its blind spot and could not fail.)
5. **Test every "fails closed" control with every language and file type in use**, not only the author's. (Seen: it
   failed open on 15 of 28 realistic filenames.)
6. **Do not hash raw bytes or key by environment-specific folder names.** Hash line-ending-normalised content and
   locate items by name; then test on a relabelled layout and a CRLF checkout.
7. **Never compress `CLAUDE.md`.** A rewrite cannot be proven equivalent.
<!-- /gia-lean-comms lessons v1 -->
