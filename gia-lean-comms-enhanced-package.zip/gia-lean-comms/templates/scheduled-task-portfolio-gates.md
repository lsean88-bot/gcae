# Scheduled task: portfolio gates (paste into Cowork)

Prepared per `automated-action-engine` conventions: self-contained, explicit output
destination, no external communication. **This file does not create a scheduled task.**
Creating one needs your own setup step in Cowork (`/schedule`, or Scheduled > New task).
Suggested cadence: weekly, Monday morning. Suggested home: a Cowork Project, so run-to-run
context persists.

**Precondition:** run `portfolio_gates.sh --bootstrap --yes` once by hand first (see `ACTION_PLAN.md`, D0). Without
state the script exits 2 (INCOMPLETE) by design, so a schedule created before bootstrapping only ever reports that.

## Prompt to paste

You are running the GIA portfolio hygiene check. Do not edit, move or delete any skill file.

1. Run: `bash <gia-lean-comms>/skills/gia-lean-comms/scripts/portfolio_gates.sh`
   (use the folder where the gia-lean-comms skill is installed).
2. Record the exit code. Meaning: 0 = nothing new and every gate ran; 1 = a new finding or
   error; 2 = a gate could not run. Exit 2 is NOT a pass; report which gate did not run.
3. Save the full output as `portfolio-gates-YYYY-MM-DD.md` in the project's output folder.
4. Write a summary at the top of that file:
   - the exit code and one-line meaning,
   - every NEW finding with the file it names,
   - the totals of known baseline findings (they stay visible every run),
   - the baseline date, and a warning if it is more than 90 days old.
5. If the exit code is 1 or 2, put "ACTION NEEDED" as the first line. Do not attempt any fix.
   Do not send any email or message; a person reads the file.
6. Never write or update the baseline. Only the owner re-baselines, after reviewing findings.
