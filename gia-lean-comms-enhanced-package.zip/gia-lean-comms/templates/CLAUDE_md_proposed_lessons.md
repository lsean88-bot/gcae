# Proposed additions for CLAUDE.md (PROPOSED, not applied to CLAUDE.md)

Status 2026-10-07: lessons 1-6 (UAT round) and 7-11 (critique round) were logged to the
self-learning-loop RAW store
(`templates/log_lessons.sh` replays them in your environment). They are not promoted to any
rule. CLAUDE.md itself was not edited: it is not accessible from this sandbox.

Source: UAT and critique of gia-lean-comms and the portfolio, 2-7 October 2026. Each line below recurred
at least twice in this one session. Approve, edit or reject; nothing here has been written
to CLAUDE.md, `iron-rules-governance` or any lessons log.

1. A skipped check is not a pass. Any gate that cannot run must report INCOMPLETE
   (non-zero) and name what did not run. (Seen: preflight overlap check, governance drift
   self-check, both silently skipped; the drift check scanned 3 of 146 skills.)
2. Test a control at the layer it claims to cover. (Seen: caveman `defaultMode: off`
   governs hooks, not skill-description triggers; a validator checked structure, not meaning.)
3. Give every new gate a positive control: break the thing on purpose and confirm the gate
   fails. (Seen: reverting the patches made the UAT fail 13 tests and 6 stages.)
4. Before documenting a finding as a defect, check whether the name or path is valid in the
   other deployment layout. (Seen: a `mktron-sentinel:` prefix is a valid invocation name
   but a wrong folder path; reclassified P3 from defect to naming decision.)
5. Never edit raw evidence logs to make an audit pass; exempt them explicitly instead.
   (Seen: the 27 Sept drift-check log is R2 evidence; `--ignore` was added.)
6. In this sandbox, run shell scripts with `bash script.sh`; the outputs mount is noexec.
7. Derive mutations from the generator's own structured values, and run the fuzz against the old code as a positive control. (Seen: a fuzz whose mutator locates tokens with the system-under-test's own regex shares its blind spots and cannot fail (amounts glued to a currency code were invisible to both).)
8. Measure coverage per skill across every gate that must pass before the outcome, and say when a first measurement is corrected. (Seen: measured a quality gate in isolation and over-stated the gap; the skill runs two gates before FINAL.)
9. Test every control against inputs in each language and file type in use, not only the author's. (Seen: a control documented as 'fails closed' failed open on 15 of 28 realistic filenames (non-English names, data extensions).)
10. Hash line-ending-normalised content and locate items by name, then test on a relabelled layout. (Seen: registry hashed raw bytes and keyed entries by this environment's folder names, so CRLF checkouts and any other layout produced false errors.)
11. Treat a clean low-contention run as weak evidence; stress the critical section directly and serialise it with a lock. (Seen: an unlocked read-then-append on a hash chain looked safe in a low-contention test but forked under real contention and poisoned every later write.)
