#!/usr/bin/env bash
# Merge templates/CLAUDE.gia-additions.md into a CLAUDE.md. Idempotent and reversible.
# Usage: bash promote_claude_md.sh /path/to/CLAUDE.md
# - creates the file if it does not exist; keeps a .bak copy of an existing one
# - does nothing if the marked block is already present
# - undo: delete everything between the two gia-lean-comms comment markers, or restore the .bak
set -u
TARGET="${1:-}"; HERE="$(cd "$(dirname "$0")" && pwd)"; BLOCK="$HERE/CLAUDE.gia-additions.md"
[ -n "$TARGET" ] || { echo "usage: promote_claude_md.sh /path/to/CLAUDE.md"; exit 64; }
[ -f "$BLOCK" ] || { echo "missing $BLOCK"; exit 2; }
if [ -f "$TARGET" ] && grep -q 'gia-lean-comms lessons v1' "$TARGET"; then echo "already present: nothing to do"; exit 0; fi
[ -f "$TARGET" ] && cp -p "$TARGET" "$TARGET.bak"
{ [ -f "$TARGET" ] && [ -s "$TARGET" ] && printf '\n'; cat "$BLOCK"; } >> "$TARGET"
echo "promoted the lessons into $TARGET"
