#!/usr/bin/env bash
# Git pre-commit hook for a repository of skills. Install:
#   cp templates/pre-commit.sh .git/hooks/pre-commit && chmod +x .git/hooks/pre-commit
# Blocks the commit if a staged change touches a skill and any gate below fails.
# Env: GIA_LEAN_COMMS = path to the gia-lean-comms skill folder (default: ./gia-lean-comms/skills/gia-lean-comms)
#      GIA_SKILLS_ROOT = folder holding the skills to check (default: ./skills)
set -u
REPO="$(git rev-parse --show-toplevel)"
LC="${GIA_LEAN_COMMS:-$REPO/gia-lean-comms/skills/gia-lean-comms}"
ROOT="${GIA_SKILLS_ROOT:-$REPO/skills}"
S="$LC/scripts"
if [ ! -d "$S" ]; then echo "pre-commit: INCOMPLETE, gia-lean-comms not found at $LC (a skipped check is not a pass)"; exit 1; fi
if ! git diff --cached --name-only | grep -Eq '(^|/)(SKILL\.md|scripts/|references/)'; then exit 0; fi
FAIL=0
echo "pre-commit: skill files changed, running gates on $ROOT"
python3 "$S/validate_portfolio.py" --roots "$ROOT" || FAIL=1
python3 "$S/interop_check.py" --roots "$ROOT" --audit-citations --deep || FAIL=1
[ $FAIL -ne 0 ] && { echo "pre-commit: BLOCKED. Fix the findings above, or commit with --no-verify knowingly."; exit 1; }
echo "pre-commit: gates passed"; exit 0
