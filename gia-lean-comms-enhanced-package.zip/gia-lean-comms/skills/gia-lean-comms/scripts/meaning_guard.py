#!/usr/bin/env python3
"""meaning_guard: detect meaning-critical changes between an original text and a
compressed/rewritten version.

Compares the meaning-critical tokens in both texts. Three outcomes:
  FAIL   (exit 1)  a token with no legitimate synonym changed: numbers (incl. amounts glued to a
                   currency code, e.g. USD100), currency, magnitude (lakh/crore/million),
                   identifiers (TP05, E12, Q3, Form16A), versions (v2.1), clause refs (7(b)),
                   calendar months, R1-R5, rule refs, CD/SD/MW, risk colours, statute refs;
                   OR the total count of negations/restrictors went DOWN
  REVIEW (exit 3)  negation wording changed with no net loss, modals changed (must -> may),
                   direction/status/quantifier words changed (before -> after, valid -> invalid,
                   passed -> failed, half -> quarter), CJK numerals changed, or every token
                   matches but their ORDER changed (a person must read it)
  PASS   (exit 0)  nothing meaning-critical changed
Articles and filler are ignored.

Languages: English, Malay, Spanish and Chinese (simplified and traditional). Full-width digits
fold via Unicode NFKC; spelled-out numbers up to 99 become digits; "5 percent" equals "5%";
"1,700.00", "1700" and "1,700" are the same amount; "Rule 9" equals "Rule 09".
Matching is by count, so ordinary compounds that contain a term appear equally in both texts and
cancel out.

KNOWN LIMITS: a token guard cannot see a change carried by ordinary words (who did what to
whom, entity names, most verbs, an unlisted antonym), has no morphology for other languages
(Tamil, Hindi), and cannot judge sense. Measured 2026-10-03 on a red-team battery: it is a
trip-wire, not proof. Keep it on Zone L content and read every REVIEW.
"""
import argparse
import contextlib
import json
import re
import sys
import unicodedata
from collections import Counter
from pathlib import Path

# ------------------------------------------------------------------ language packs
NEG_EN = (r"\b(?:not|never|no|none|nothing|neither|nor|cannot|can't|won't|don't|doesn't|"
          r"isn't|aren't|wasn't|weren't|without|only|except|unless)\b")
NEG_MS = r"\b(?:tidak|bukan|jangan|tanpa|tiada|hanya|kecuali|belum|tak)\b"
NEG_ES = (r"\b(?:nunca|jam[aá]s|ning[uú]n|ninguna?|nada|nadie|tampoco|sin|s[oó]lo|solamente|"
          r"excepto|salvo)\b")
NEG_ZH = ("(?:不得|不可|不能|不应|不應|不要|并非|並非|绝不|絕不|从不|從不|没有|沒有|禁止|除非|除外|"
          "只有|不|没|沒|无|無|非|未|勿|别|別|仅|僅|只)")
NEG_RE = re.compile("|".join([NEG_EN, NEG_MS, NEG_ES, NEG_ZH]), re.I)

MODAL = re.compile(
    r"\b(?:must|shall|should|may|might|required|optional|mandatory|mesti|perlu|wajib|boleh|hendaklah|"
    r"debe|deben|deber[aá]n?|deber[ií]a|puede|pueden|podr[aá]|obligatorio|opcional|requerido)\b"
    r"|必须|必須|应当|應當|应该|應該|可选|可選|强制|強制|必要|须|須|应|應|可以", re.I)

DIRECTION = re.compile(
    r"\b(?:before|after|prior|until|above|below|over|under|exceed(?:s|ed)?|increase[sd]?|"
    r"decrease[sd]?|higher|lower|more|less|greater|fewer|minimum|maximum|least|most|"
    r"all|any|every|each|both|either|approved?|reject(?:ed)?|allowed?|prohibited|permitted|yes|"
    r"effective|ineffective|valid|invalid|adequate|inadequate|compliant|non-?compliant|"
    r"pass(?:ed|es)?|fail(?:ed|s|ure)?|significant|insignificant|material|immaterial|minor|major|"
    r"critical|high|low|authori[sz]ed|unauthori[sz]ed|legal|illegal|complete[d]?|incomplete|"
    r"open|closed|resolved|unresolved|confirmed|unconfirmed|substantiated|unsubstantiated|"
    r"rose|rise[sn]?|fell|falls?|fallen|gain(?:ed|s)?|lost|loss(?:es)?|profit|surplus|deficit|"
    r"half|quarter|third|twice|double|triple|"
    r"sebelum|selepas|melebihi|meningkat|menurun|kurang|semua|setiap|dibenarkan|"
    r"antes|despu[eé]s|exceder?|aumento|disminuci[oó]n|mayor|menor|m[aá]s|menos|todos?|todas?|"
    r"cualquier|cada|ambos|aprobado|rechazado|permitido|prohibido)\b"
    r"|之前|以前|之后|之後|以后|以後|以上|以下|超过|超過|增加|减少|減少|高于|高於|低于|低於|更多|更少|"
    r"所有|任何|每个|每個|批准|核准|拒绝|拒絕|允许|允許", re.I)

CJK_NUMERAL = re.compile(r"[〇零一二三四五六七八九十百千万萬亿億]")

_CUR = r"RM|MYR|USD|INR|MXN|MXP|EUR|SGD|GBP|CNY|RMB|Rs\.?"
# Digits are matched when not glued to ordinary letters/digits, OR when directly after a
# currency code (USD100, RM5). A plain \w lookbehind would hide every amount in Chinese text and
# every amount glued to a currency code.
_AFTER_CUR = "".join(f"|(?<={c})" for c in ("RM", "MYR", "USD", "INR", "MXN", "MXP", "EUR", "SGD",
                                               "GBP", "CNY", "RMB", "Rs", r"Rs\.", r"\bR"))
NUMBER = re.compile(r"(?:(?<![A-Za-z0-9_.])" + _AFTER_CUR + r")[$€£₹¥]?\d[\d,]*(?:\.\d+)?%?")
PATTERNS = {
    "number": NUMBER,
    "currency": re.compile(r"(?<![A-Za-z])(?:" + _CUR + r")(?![A-Za-z])|[$€£₹¥]"),
    "magnitude": re.compile(
        r"\b(?:lakhs?|crores?|thousand|hundred|million|billion|trillion|millones|mil|ribu|juta|bilion)\b",
        re.I),
    # Identifiers: TP05, E12, Q3, Form16A. Excludes currency-glued amounts (RM5, USD100: the number
    # and currency classes own those) and R1-R5 (the evidence_rank class owns those), so the same
    # text written "RM 5" or "R 5" is not seen as a change.
    "identifier": re.compile(
        r"\b(?!(?:RM|MYR|USD|INR|MXN|MXP|EUR|SGD|GBP|CNY|RMB|Rs)\d)(?!R[1-5]\b)"
        r"[A-Za-z]{1,5}[-_]?\d{1,4}[A-Za-z]?\b"),
    # Versions: v2.1, or dotted numbers with two or more dots (1.2.3). A single-dot number is a
    # decimal and belongs to the number class; matching it here broke 1,700.00 vs 1,700.
    "version": re.compile(r"\bv\d+(?:\.\d+){1,3}\b|\b\d+(?:\.\d+){2,3}\b", re.I),
    "clause_ref": re.compile(r"\b\d+\s?\([a-z0-9]{1,3}\)", re.I),
    # Roman-numeral references: Section IV, Article XII, Schedule II.
    "roman_ref": re.compile(
        r"\b(?:Section|Article|Clause|Part|Schedule|Chapter|Annex|Appendix|Paragraph|Regulation)\s+"
        r"[IVXLCDM]{1,7}\b", re.I),
    "calendar": re.compile(
        r"\b(?:january|february|march|april|june|july|august|september|october|november|december|"
        r"jan|feb|apr|jun|jul|aug|sept?|oct|nov|dec|"
        r"enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|octubre|noviembre|diciembre|"
        r"januari|februari|julai|ogos|oktober|disember)\b", re.I),
    "evidence_rank": re.compile(r"\bR\s?[1-5]\b"),
    "rule_ref": re.compile(r"\b(?:RACM|RC|RULE|Rule)[\s-]?\d{1,2}\b"),
    "deficiency_class": re.compile(r"\b(?:CD|SD|MW)\b"),
    "risk_colour": re.compile("[\U0001F534\U0001F7E0\U0001F7E1\U0001F7E2]"),
    "statute_ref": re.compile(r"\b(?:s\.|ss\.|sec(?:tion)?\.?\s*)\s*\d+[A-Za-z]?(?:\(\d+\))?", re.I),
}
ERROR_CLASSES = list(PATTERNS)  # every PATTERNS class is a hard FAIL when its tokens change

NUMBER_WORDS = {w: str(i) for i, w in enumerate(
    "zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen "
    "sixteen seventeen eighteen nineteen".split())}
NUMBER_WORDS.update({"twenty": "20", "thirty": "30", "forty": "40", "fifty": "50", "sixty": "60",
                     "seventy": "70", "eighty": "80", "ninety": "90"})
_TENS = {k: int(v) for k, v in NUMBER_WORDS.items() if int(v) >= 20}
_UNITS = {k: int(v) for k, v in NUMBER_WORDS.items() if 1 <= int(v) <= 9}
TENS_COMPOUND = re.compile(r"\b(" + "|".join(_TENS) + r")[-\s](" + "|".join(_UNITS) + r")\b", re.I)
NUMBER_WORD_RE = re.compile(r"\b(" + "|".join(NUMBER_WORDS) + r")\b", re.I)
PERCENT_WORD = re.compile(r"(\d)\s*(?:per\s?cent|percent|pct\.?)(?![A-Za-z])", re.I)
LIST_MARKER = re.compile(r"(?m)^[ \t]*(?:\d+[.)]|[-*+])[ \t]+")


def prep(text):
    """Canonical working text. Line count is preserved so line numbers stay meaningful.
    NFKC folds full-width digits; spaces and tabs collapse; list markers go; percent words and
    spelled-out numbers become digits."""
    t = unicodedata.normalize("NFKC", text)
    t = re.sub(r"[ \t]+", " ", t)
    t = LIST_MARKER.sub("", t)
    t = PERCENT_WORD.sub(r"\1%", t)
    t = TENS_COMPOUND.sub(lambda m: str(_TENS[m.group(1).lower()] + _UNITS[m.group(2).lower()]), t)
    return NUMBER_WORD_RE.sub(lambda m: NUMBER_WORDS[m.group(1).lower()], t)


def canon(cls, tok):
    """Canonical form of a matched token for comparison."""
    t = tok.lower().replace(" ", "")
    if cls == "number":
        t = t.replace(",", "")
        sign = t[0] if t and t[0] in "$€£₹¥" else ""
        pct = "%" if t.endswith("%") else ""
        core = t.lstrip("$€£₹¥").rstrip("%")
        ip, _, fp = core.partition(".")
        ip = ip.lstrip("0") or "0"
        fp = fp.rstrip("0")
        return sign + ip + ("." + fp if fp else "") + pct
    if cls in ("identifier", "evidence_rank", "rule_ref"):
        return re.sub(r"(?<=\D)0+(?=\d)", "", t.replace("-", "").replace("_", ""))
    if cls == "version":
        return t.lstrip("v")
    return t


def class_tokens(text, cls, pat):
    return [(m.start(), cls, canon(cls, m.group(0))) for m in pat.finditer(text)]


def analyse(text):
    t = prep(text)
    per, seq = {}, []
    for cls, pat in PATTERNS.items():
        items = class_tokens(t, cls, pat)
        per[cls] = Counter(x[2] for x in items)
        seq += items
    for cls, pat in (("negation", NEG_RE), ("modal", MODAL), ("direction_quantifier", DIRECTION),
                     ("cjk_numeral", CJK_NUMERAL)):
        items = [(m.start(), cls, m.group(0).lower()) for m in pat.finditer(t)]
        per[cls] = Counter(x[2] for x in items)
        seq += items
    seq.sort(key=lambda x: (x[0], x[1]))
    return per, [(c, tok) for _, c, tok in seq]


def compare(orig, comp):
    (po, so), (pc, sc) = analyse(orig), analyse(comp)
    errors, warnings = [], []
    for cls in ERROR_CLASSES:
        a, b = po[cls], pc[cls]
        if a != b:
            errors.append({"class": cls, "dropped": dict(a - b), "added": dict(b - a)})
    na, nb = po["negation"], pc["negation"]
    if sum(nb.values()) < sum(na.values()):
        errors.append({"class": "negation_net_loss", "dropped": dict(na - nb), "added": dict(nb - na),
                       "count": [sum(na.values()), sum(nb.values())]})
    elif na != nb:
        warnings.append({"class": "negation_reworded", "dropped": dict(na - nb), "added": dict(nb - na),
                         "count": [sum(na.values()), sum(nb.values())]})
    for cls in ("modal", "direction_quantifier", "cjk_numeral"):
        a, b = po[cls], pc[cls]
        if a != b:
            warnings.append({"class": cls, "dropped": dict(a - b), "added": dict(b - a)})
    if not errors and not warnings and so != sc:
        warnings.append({"class": "critical_order", "dropped": {}, "added": {},
                         "note": "every critical token matches but their order changed"})
    return errors, warnings


# ------------------------------------------------------------------ human-review aid
_CLASS_OF = {"negation_net_loss": "negation", "negation_reworded": "negation"}


def lines_for(text, cls, token):
    """First line of `text` holding `token` of class `cls` (works on the prepared text)."""
    if cls in PATTERNS:
        pat = PATTERNS[cls]
    else:
        pat = {"negation": NEG_RE, "modal": MODAL, "direction_quantifier": DIRECTION,
               "cjk_numeral": CJK_NUMERAL}[cls]
    for i, line in enumerate(prep(text).splitlines(), 1):
        for m in pat.finditer(line):
            got = canon(cls, m.group(0)) if cls in PATTERNS else m.group(0).lower()
            if got == token:
                return i, line.strip()[:150]
    return None


def show_lines(orig, comp, items):
    out = []
    for it in items:
        cls = _CLASS_OF.get(it["class"], it["class"])
        if cls == "critical_order":
            out.append("    [critical_order] every token matches but their order changed: read both texts")
            continue
        for tok in it["dropped"]:
            hit = lines_for(orig, cls, tok)
            if hit:
                out.append(f"    [{it['class']}] original line {hit[0]} has {tok!r}: {hit[1]}")
        for tok in it["added"]:
            hit = lines_for(comp, cls, tok)
            if hit:
                out.append(f"    [{it['class']}] rewritten line {hit[0]} has {tok!r}: {hit[1]}")
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("original")
    ap.add_argument("compressed")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--show-lines", action="store_true",
                    help="print the first original/rewritten line behind each changed token")
    ns = ap.parse_args(argv)
    o = Path(ns.original).read_text(encoding="utf-8")
    c = Path(ns.compressed).read_text(encoding="utf-8")
    errors, warnings = compare(o, c)
    status = "FAIL" if errors else ("REVIEW" if warnings else "PASS")
    result = {"status": status, "pass": status == "PASS", "errors": errors, "warnings": warnings}
    if ns.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(status if status == "PASS" else f"{status}: meaning-critical tokens changed")
        for e in errors:
            print(f"  [{e['class']}] dropped={e['dropped']} added={e['added']}")
        for w in warnings:
            print(f"  (review) [{w['class']}] dropped={w['dropped']} added={w['added']}")
        if ns.show_lines:
            for line in show_lines(o, c, errors + warnings):
                print(line)
    return {"PASS": 0, "FAIL": 1, "REVIEW": 3}[status]


if __name__ == "__main__":
    try:
        sys.exit(main())
    except BrokenPipeError:  # output piped to head/less and closed early: not an error
        with contextlib.suppress(OSError):
            sys.stdout.close()
        sys.exit(141)
