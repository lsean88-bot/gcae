#!/usr/bin/env python3
"""gia_state: where site-specific state lives, kept apart from the plugin's code.

The plugin folder is REPLACED on every update, so anything an owner has reviewed and accepted (the
skill registry, the findings baseline) must not live there. State goes in a state directory:

    explicit option  >  environment variable  >  <state dir>/<file>

    GIA_STATE_DIR   state directory      (default: ~/.gia-lean-comms)
    GIA_REGISTRY    registry file        (default: <state dir>/portfolio-registry.json)
    GIA_BASELINE    findings baseline    (default: <state dir>/baseline.txt)

The registry and baseline shipped under references/seed/ are anchored to ONE installation's content.
They are test fixtures and worked examples; they are never used implicitly. A missing state file is
reported as INCOMPLETE (exit 2), never silently replaced by the seed.

Run `python3 gia_state.py` to print the resolved locations.
"""
import os
import sys
from pathlib import Path

REGISTRY_NAME = "portfolio-registry.json"
BASELINE_NAME = "baseline.txt"


def state_dir():
    return Path(os.environ.get("GIA_STATE_DIR") or Path.home() / ".gia-lean-comms")


def registry_path(explicit=None):
    return Path(explicit or os.environ.get("GIA_REGISTRY") or state_dir() / REGISTRY_NAME)


def baseline_path(explicit=None):
    return Path(explicit or os.environ.get("GIA_BASELINE") or state_dir() / BASELINE_NAME)


def main():
    print(f"state dir : {state_dir()}")
    for label, p in (("registry  ", registry_path()), ("baseline  ", baseline_path())):
        print(f"{label}: {p}  [{'present' if p.exists() else 'MISSING'}]")
    return 0


if __name__ == "__main__":
    sys.exit(main())
