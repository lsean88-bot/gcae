#!/usr/bin/env python3
"""review_log: record and verify a HUMAN sign-off on a compression that meaning_guard marked REVIEW.

  record   ORIGINAL COPY --reviewer NAME --decision approve|reject [--note TEXT] --log FILE
  verify   ORIGINAL COPY --log FILE       exit 0 only if the latest entry for exactly these two
                                          file contents is an approval

Design:
- Entries are JSON lines. Each stores SHA-256 of the original and of the rewritten copy, so an
  approval is void the moment either file changes.
- Entries are hash-chained (each carries the previous entry's hash), so editing or deleting an
  earlier entry is detectable: `verify` fails and `audit` reports the break.
- Only REVIEW outcomes can be signed. FAIL cannot be overridden by a sign-off; PASS needs none.
- A sign-off records who decided and when. It is NOT authentication: anyone with write access
  can type any name. Claude and other automated agents must never record an approval on their
  own; a reviewer name that looks automated is refused.
"""
import argparse
import contextlib
import hashlib
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
REFUSED_REVIEWERS = {"claude", "assistant", "ai", "model", "bot", "gpt", "llm", "agent", "system", "auto"}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def entry_hash(e):
    body = {k: v for k, v in e.items() if k != "entry_hash"}
    return hashlib.sha256(json.dumps(body, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


@contextlib.contextmanager
def locked(log_path, timeout=30.0):
    """Exclusive lock around read-then-append. Without it, two writers can both read the same
    last hash and append, forking the chain (measured: a 1,200-attempt contention test broke it at
    entry 29 and made every later approval unverifiable)."""
    lock_path = str(log_path) + ".lock"
    fd = os.open(lock_path, os.O_CREAT | os.O_RDWR)
    deadline = time.time() + timeout
    try:
        try:
            import fcntl
            while True:
                try:
                    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except OSError:
                    if time.time() > deadline:
                        raise TimeoutError("could not lock the sign-off log") from None
                    time.sleep(0.005)
        except ImportError:  # Windows
            import msvcrt
            while True:
                try:
                    msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
                    break
                except OSError:
                    if time.time() > deadline:
                        raise TimeoutError("could not lock the sign-off log") from None
                    time.sleep(0.005)
        yield
    finally:
        os.close(fd)


def read_log(path):
    p = Path(path)
    if not p.exists():
        return []
    return [json.loads(ln) for ln in p.read_text(encoding="utf-8").splitlines() if ln.strip()]


def chain_ok(entries):
    prev = "0" * 64
    for i, e in enumerate(entries):
        if e.get("prev_hash") != prev or e.get("entry_hash") != entry_hash(e):
            return False, i
        prev = e["entry_hash"]
    return True, None


def guard_status(orig, comp):
    r = subprocess.run([sys.executable, str(HERE / "meaning_guard.py"), orig, comp, "--json"],
                       capture_output=True, text=True)
    try:
        d = json.loads(r.stdout)
        return d["status"], sorted({x["class"] for x in d["errors"] + d["warnings"]})
    except (ValueError, KeyError):
        return "ERROR", [(r.stderr or r.stdout).strip()[:200]]


def cmd_record(ns):
    if ns.reviewer.strip().lower() in REFUSED_REVIEWERS or len(ns.reviewer.strip()) < 2:
        print(f"REFUSED: reviewer {ns.reviewer!r} looks automated or empty. A person must sign.")
        return 2
    status, classes = guard_status(ns.original, ns.copy)
    if status == "ERROR":
        print(f"INCOMPLETE: meaning_guard could not run ({classes[0]}). Not signing.")
        return 2
    if status == "FAIL":
        print("REFUSED: meaning_guard says FAIL. A sign-off cannot override a failed check.")
        return 1
    if status == "PASS":
        print("Nothing to sign: meaning_guard says PASS.")
        return 0
    with locked(ns.log):
        return _append(ns, status, classes)


def _append(ns, status, classes):
    entries = read_log(ns.log)
    ok, bad = chain_ok(entries)
    if not ok:
        print(f"REFUSED: existing log is broken at entry {bad}; investigate before appending.")
        return 1
    e = {"ts": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "reviewer": ns.reviewer.strip(),
         "decision": ns.decision, "note": ns.note or "", "original": str(ns.original),
         "original_sha256": sha(ns.original), "copy_sha256": sha(ns.copy),
         "guard_status": status, "classes": classes,
         "prev_hash": entries[-1]["entry_hash"] if entries else "0" * 64}
    e["entry_hash"] = entry_hash(e)
    with open(ns.log, "a", encoding="utf-8") as f:
        f.write(json.dumps(e, ensure_ascii=False) + "\n")
    print(f"RECORDED {ns.decision} by {e['reviewer']} at {e['ts']}")
    return 0


def cmd_verify(ns):
    entries = read_log(ns.log)
    ok, bad = chain_ok(entries)
    if not ok:
        print(f"INVALID: log chain broken at entry {bad}")
        return 1
    o, c = sha(ns.original), sha(ns.copy)
    mine = [e for e in entries if e["original_sha256"] == o and e["copy_sha256"] == c]
    if not mine:
        print("NO SIGN-OFF for these exact file contents (a changed file voids earlier approvals)")
        return 1
    last = mine[-1]
    print(f"{last['decision'].upper()} by {last['reviewer']} at {last['ts']}")
    return 0 if last["decision"] == "approve" else 1


def cmd_audit(ns):
    entries = read_log(ns.log)
    ok, bad = chain_ok(entries)
    print(f"{len(entries)} entries; chain " + ("intact" if ok else f"BROKEN at entry {bad}"))
    return 0 if ok else 1


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("record", "verify"):
        p = sub.add_parser(name)
        p.add_argument("original")
        p.add_argument("copy")
        p.add_argument("--log", required=True)
        if name == "record":
            p.add_argument("--reviewer", required=True)
            p.add_argument("--decision", choices=["approve", "reject"], required=True)
            p.add_argument("--note")
    sub.add_parser("audit").add_argument("--log", required=True)
    ns = ap.parse_args(argv)
    return {"record": cmd_record, "verify": cmd_verify, "audit": cmd_audit}[ns.cmd](ns)


if __name__ == "__main__":
    sys.exit(main())
