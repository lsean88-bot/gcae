#!/usr/bin/env python3
"""registry_check: enforce the portfolio registry.

Findings (severity):
  undeclared_collision  error  two or more skill folders share a base name, their SKILL.md
                               differ, and the registry does not declare the pair
  registry_stale        error  a declared copy's SKILL.md hash no longer matches the registry:
                               the declaration was made against different content, re-review it
  declared_missing      error  a path the registry names does not exist in these roots
  undeclared_duplicate  error  two skills with DIFFERENT names have near-identical content
                               (Jaccard >= 0.9 on 8-word shingles) and the registry does not declare
                               the pair. The same-name check cannot see these
  duplicate_diverged    error  a declared duplicate pair has drifted apart (similarity fell below
                               its floor): decide which copy is right
  duplicate_changed     warn   a declared duplicate changed since declared but is still similar:
                               confirm the edit was applied to both copies
  cites_stale_copy      warn   a skill cites a copy the registry marks stale, by its
                               namespaced name (e.g. `mktron-sentinel:self-learning-loop`)
  superseded_installed  info   a skill the registry declares superseded is still installed
  open_owner_action     info   declared collision whose owner_action is still outstanding

Exit 0 = no errors, 1 = errors, 2 = registry missing/unreadable (INCOMPLETE: not a pass).
`--init` prints a registry stub for undeclared collisions, with hashes and overlap evidence.
`--bootstrap` writes a first registry for a NEW installation that declares every divergent same-name
pair and near-duplicate it finds as "unreviewed", anchored to current content. It accepts today's state
and alerts on change; it does not decide which copy is canonical. Dry run unless `--yes`; refuses to
overwrite an existing registry without `--force`. The registry lives in the state directory
(see gia_state.py), not in the plugin folder, so a plugin update cannot overwrite it.
`--refresh` re-anchors the registry to current content AFTER you have reviewed and approved a change
to a registered skill (for example after applying a decision patch). It is a dry run that lists what
would change; add `--yes` to write (a .bak copy is kept). Never refresh to silence a finding you have
not reviewed: a refreshed registry certifies the current content as the declared content.
Registry paths look like "plugins/foo", but only the FOLDER NAME ("foo") is used to find a skill:
the leading "plugins/" is informational. Skills are located in whichever --roots contain that folder
name, so the registry works in layouts such as ~/.claude/skills or a plugin cache, not only under
/mnt/skills. When several roots hold the folder, the root named like the registry prefix wins,
then any copy whose hash matches.
"""
import argparse
import contextlib
import hashlib
import json
import sys
from pathlib import Path

import gia_state

DEFAULT_ROOTS = ["/mnt/skills/user", "/mnt/skills/plugins", "/mnt/skills/examples", "/mnt/skills/public"]


def sha(p):
    """SHA-256 of SKILL.md with CRLF folded to LF, so a Windows checkout (git autocrlf) hashes
    the same as the Linux copy the registry was written against."""
    data = Path(p, "SKILL.md").read_bytes().replace(b"\r\n", b"\n")
    return hashlib.sha256(data).hexdigest()


def scan(roots):
    """base name -> list of (relative_path, abs_path)."""
    by = {}
    for r in roots:
        rp = Path(r)
        if not rp.is_dir():
            continue
        for d in sorted(rp.iterdir()):
            if d.is_dir() and (d / "SKILL.md").exists():
                base = d.name.split(":", 1)[1] if ":" in d.name else d.name
                by.setdefault(base, []).append((f"{rp.name}/{d.name}", d))
    return by


def shingles(path, k=8):
    text = " ".join(Path(path, "SKILL.md").read_text(encoding="utf-8", errors="replace").lower().split())
    w = text.split()
    return {" ".join(w[i:i + k]) for i in range(max(1, len(w) - k + 1))}


def similarity(a, b):
    sa, sb = shingles(a), shingles(b)
    return len(sa & sb) / len(sa | sb) if sa and sb else 0.0


def near_duplicates(roots, threshold=0.9):
    """Pairs of skills with different folder names whose content is near-identical."""
    items = []
    for r in roots:
        for d in sorted(Path(r).iterdir()) if Path(r).is_dir() else []:
            if d.is_dir() and (d / "SKILL.md").exists():
                sh = shingles(d)
                if sh:
                    items.append((d.name, d, sh))
    out = []
    for i, (na, pa, sa) in enumerate(items):
        for nb, pb, sb in items[i + 1:]:
            base = lambda n: n.split(":", 1)[-1]  # noqa: E731
            if base(na) == base(nb):
                continue                      # same-base pairs belong to the collision check
            if min(len(sa), len(sb)) / max(len(sa), len(sb)) < threshold:
                continue                      # J can never reach the threshold: skip cheaply
            j = len(sa & sb) / len(sa | sb)
            if j >= threshold:
                out.append((round(j, 2), na, nb, pa, pb))
    return sorted(out, reverse=True)


def refresh(reg, roots, apply):
    """List (and, when apply is true, make) hash and similarity updates. Returns (changes, missing)."""
    changes, missing = [], []

    def upd(entry):
        p = locate(entry, roots)
        if p is None:
            missing.append(entry["path"])
            return None
        h = sha(p)
        if h != entry["sha256"]:
            changes.append(f"{entry['path']}: {entry['sha256'][:12]} -> {h[:12]}")
            if apply:
                entry["sha256"] = h
        return p

    for c in reg.get("collisions", []):
        for e in [c["canonical"]] + c.get("others", []):
            upd(e)
    for d in reg.get("content_duplicates", []):
        pa, pb = upd(d["a"]), upd(d["b"])
        if pa is not None and pb is not None:
            sim = round(similarity(pa, pb), 2)
            if sim != d.get("similarity_when_declared"):
                changes.append(f"similarity {d['a']['path']} ~ {d['b']['path']}: {d.get('similarity_when_declared')} -> {sim}")
                if apply:
                    d["similarity_when_declared"] = sim
    return changes, missing


def bootstrap_registry(roots, threshold=0.9):
    """A registry that accepts the CURRENT state as 'unreviewed'. No canonical choice is made."""
    def entry(path_str, p):
        return {"path": path_str, "role": "unreviewed", "sha256": sha(p)}
    by = scan(roots)
    collisions = []
    for base, items in sorted(by.items()):
        if len(items) > 1 and len({sha(p) for _, p in items}) > 1:
            first = items[0]
            collisions.append({
                "base": base, "status": "unreviewed",
                "canonical": entry(first[0], first[1]),
                "others": [entry(r, p) for r, p in items[1:]],
                "evidence": {"overlap_vs_first": [uniq_lines(first[1], p) for _, p in items[1:]]},
                "owner_action": "Unreviewed: decide which copy is canonical and which is stale, then edit this entry."})
    dups = []
    for j, na, nb, pa, pb in near_duplicates(roots, threshold):
        dups.append({"a": {"path": f"{pa.parent.name}/{na}", "sha256": sha(pa)},
                     "b": {"path": f"{pb.parent.name}/{nb}", "sha256": sha(pb)},
                     "similarity_when_declared": j, "min_similarity": round(max(0.5, j - 0.05), 2),
                     "relationship": "unreviewed",
                     "owner_action": "Unreviewed: keep both (drift is now detected) or retire one."})
    return {"schema_version": 1, "declared": "bootstrap", "purpose": "Bootstrap registry: accepts the state found at "
            "install time as UNREVIEWED and alerts on change. Review each entry.",
            "collisions": collisions, "content_duplicates": dups, "duplicate_threshold": threshold,
            "aliases": [], "superseded": [], "acknowledged_uninstalled": [], "former_names": {}}


def bootstrap(ns):
    reg = bootstrap_registry(ns.roots)
    target = Path(ns.registry)
    print(f"Bootstrap would declare as UNREVIEWED: {len(reg['collisions'])} divergent same-name pair(s) and "
          f"{len(reg['content_duplicates'])} near-duplicate pair(s), anchored to current content.")
    for c in reg["collisions"]:
        print(f"  same-name : {c['base']}  ({c['canonical']['path']} + {len(c['others'])} other)")
    for d in reg["content_duplicates"]:
        print(f"  duplicate : {d['a']['path']} ~ {d['b']['path']}  (similarity {d['similarity_when_declared']})")
    if not ns.yes:
        print(f"Dry run. Nothing written. Target: {target}\n"
              "This ACCEPTS today's state. Review what is listed above first, then re-run with --yes.")
        return 0
    if target.exists() and not ns.force:
        print(f"REFUSED: {target} already exists. Use --force to replace it (a .bak copy is kept).")
        return 1
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        Path(str(target) + ".bak").write_text(target.read_text(encoding="utf-8"), encoding="utf-8")
    target.write_text(json.dumps(reg, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Registry written to {target}")
    return 0


def uniq_lines(a, b):
    la = {x.strip() for x in Path(a, "SKILL.md").read_text(encoding="utf-8", errors="replace").splitlines() if x.strip()}
    lb = {x.strip() for x in Path(b, "SKILL.md").read_text(encoding="utf-8", errors="replace").splitlines() if x.strip()}
    return {"a_only_lines": len(la - lb), "b_only_lines": len(lb - la), "shared_lines": len(la & lb)}


def locate(entry, roots):
    """Find a registered skill folder by name across roots (layout-independent)."""
    top, _, name = entry["path"].partition("/")
    cands = [Path(r) / name for r in roots if (Path(r) / name / "SKILL.md").exists()]
    if not cands:
        return None
    for c in cands:
        if c.parent.name == top:
            return c
    for c in cands:
        if sha(c) == entry["sha256"]:
            return c
    return cands[0]


def check(reg, roots):
    by = scan(roots)
    findings = []
    declared_bases = {c["base"]: c for c in reg.get("collisions", [])}

    # 1. every divergent collision must be declared
    for base, items in sorted(by.items()):
        if len(items) < 2:
            continue
        if len({sha(p) for _, p in items}) == 1:
            continue  # identical mirrors are fine
        if base not in declared_bases:
            findings.append({"kind": "undeclared_collision", "severity": "error", "base": base,
                             "paths": [r for r, _ in items]})

    # 2. declared entries must exist and still match their anchored hash
    for base, c in declared_bases.items():
        for entry in [c["canonical"]] + c.get("others", []):
            rel = entry["path"]
            p = locate(entry, roots)
            if p is None:
                findings.append({"kind": "declared_missing", "severity": "error", "base": base, "path": rel})
            elif sha(p) != entry["sha256"]:
                findings.append({"kind": "registry_stale", "severity": "error", "base": base, "path": rel,
                                 "detail": "SKILL.md changed since the registry was written; re-review the declaration"})
        if c.get("owner_action") and not c.get("accepted"):
            findings.append({"kind": "open_owner_action", "severity": "info", "base": base,
                             "status": c["status"], "action": c["owner_action"]})

    # 2b. near-identical skills under DIFFERENT names
    declared_dups = reg.get("content_duplicates", [])
    pair_key = lambda a, b: frozenset((a["path"].partition("/")[2], b["path"].partition("/")[2]))  # noqa: E731
    declared_pairs = {pair_key(d["a"], d["b"]) for d in declared_dups}
    collision_names = {e["path"].partition("/")[2] for c in declared_bases.values()
                       for e in [c["canonical"]] + c.get("others", [])}
    for j, na, nb, _pa, _pb in near_duplicates(roots, reg.get("duplicate_threshold", 0.9)):
        if frozenset((na, nb)) in declared_pairs or (na in collision_names and nb in collision_names):
            continue
        findings.append({"kind": "undeclared_duplicate", "severity": "error", "similarity": j, "a": na, "b": nb})
    for d in declared_dups:
        pa, pb = locate(d["a"], roots), locate(d["b"], roots)
        if pa is None or pb is None:
            findings.append({"kind": "declared_missing", "severity": "error", "base": "duplicate pair",
                             "path": d["a"]["path"] if pa is None else d["b"]["path"]})
            continue
        sim = similarity(pa, pb)
        if sim < d.get("min_similarity", 0.9):
            findings.append({"kind": "duplicate_diverged", "severity": "error", "a": d["a"]["path"],
                             "b": d["b"]["path"], "similarity": round(sim, 2)})
        elif sha(pa) != d["a"]["sha256"] or sha(pb) != d["b"]["sha256"]:
            findings.append({"kind": "duplicate_changed", "severity": "warn", "a": d["a"]["path"],
                             "b": d["b"]["path"], "similarity": round(sim, 2)})
        if d.get("owner_action"):
            findings.append({"kind": "open_owner_action", "severity": "info", "base": f"{d['a']['path']} ~ {d['b']['path']}",
                             "status": "content_duplicate", "action": d["owner_action"]})

    # 2c. superseded skills that are still installed
    for sup in reg.get("superseded", []):
        if any((Path(r) / sup["skill"] / "SKILL.md").exists() for r in roots):
            findings.append({"kind": "superseded_installed", "severity": "info", "skill": sup["skill"],
                             "superseded_by": sup["superseded_by"], "basis": sup["basis"]})

    # 3. citations of a stale copy by namespaced name
    stale_names = set()
    for c in declared_bases.values():
        for o in c.get("others", []):
            if o["role"].startswith("stale"):
                stale_names.add(o["path"].split("/", 1)[1])
    stale_names = {n for n in stale_names if ":" in n}
    for r in roots:
        for sk in sorted(Path(r).glob("*/SKILL.md")):
            text = sk.read_text(encoding="utf-8", errors="replace")
            for n in sorted(stale_names):
                if n in text and sk.parent.name != n:
                    findings.append({"kind": "cites_stale_copy", "severity": "warn", "in": str(sk), "cites": n})
    return findings


def init_stub(roots):
    by = scan(roots)
    out = []
    for base, items in sorted(by.items()):
        if len(items) > 1 and len({sha(p) for _, p in items}) > 1:
            first = items[0]
            out.append({"base": base, "status": "TODO", "canonical": {"path": first[0], "role": "TODO", "sha256": sha(first[1])},
                        "others": [{"path": r, "role": "TODO", "sha256": sha(p),
                                    "overlap_vs_first": uniq_lines(first[1], p)} for r, p in items[1:]],
                        "evidence": {}, "owner_action": "TODO"})
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--registry", default=None, help="registry file (default: $GIA_REGISTRY or <state dir>/portfolio-registry.json)")
    ap.add_argument("--roots", nargs="+", default=DEFAULT_ROOTS)
    ap.add_argument("--init", action="store_true")
    ap.add_argument("--refresh", action="store_true")
    ap.add_argument("--bootstrap", action="store_true")
    ap.add_argument("--force", action="store_true", help="with --bootstrap: overwrite an existing registry")
    ap.add_argument("--yes", action="store_true", help="with --refresh: write the changes")
    ap.add_argument("--json", action="store_true")
    ns = ap.parse_args(argv)
    ns.registry = str(gia_state.registry_path(ns.registry))
    if ns.init:
        print(json.dumps(init_stub(ns.roots), indent=2))
        return 0
    if ns.bootstrap:
        return bootstrap(ns)
    if not Path(ns.registry).exists():
        print(f"INCOMPLETE: no registry at {ns.registry}. A check that cannot run is not a pass.\n"
              f"  New installation? Review, then run:  registry_check.py --bootstrap --yes\n"
              f"  Existing registry elsewhere?         set GIA_REGISTRY or pass --registry")
        return 2
    try:
        reg = json.loads(Path(ns.registry).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as e:
        print(f"INCOMPLETE: registry unreadable ({e}). A check that cannot run is not a pass.")
        return 2
    if ns.refresh:
        changes, missing = refresh(reg, ns.roots, ns.yes)
        for m in missing:
            print(f"  MISSING (cannot re-anchor): {m}")
        for c in changes:
            print(f"  {'UPDATED' if ns.yes else 'would update'}: {c}")
        if not changes and not missing:
            print("Registry already matches current content; nothing to refresh.")
        elif ns.yes and not missing:
            Path(str(ns.registry) + ".bak").write_text(Path(ns.registry).read_text(encoding="utf-8"), encoding="utf-8")
            Path(ns.registry).write_text(json.dumps(reg, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
            print(f"Registry rewritten ({len(changes)} change(s)); previous version kept as {ns.registry}.bak")
        elif changes and not ns.yes:
            print("Dry run. Re-run with --yes ONLY after you have reviewed these changes.")
        return 1 if missing else 0
    findings = check(reg, ns.roots)
    errors = [f for f in findings if f["severity"] == "error"]
    if ns.json:
        print(json.dumps({"errors": len(errors), "findings": findings}, indent=2))
    else:
        print(f"Registry check: {len(errors)} error(s), "
              f"{sum(f['severity'] == 'warn' for f in findings)} warning(s), "
              f"{sum(f['severity'] == 'info' for f in findings)} open owner action(s)")
        for f in findings:
            if f["kind"] == "open_owner_action":
                print(f"  [info] {f['base']} ({f['status']}): {f['action']}")
            elif f["kind"] == "superseded_installed":
                print(f"  [info] superseded but installed ({f['basis']}): {f['skill']} -> {f['superseded_by']}")
            elif f["kind"] == "cites_stale_copy":
                print(f"  [warn] {f['in']} cites stale copy `{f['cites']}`")
            else:
                print(f"  [{f['severity']}:{f['kind']}] " + ", ".join(f"{k}={v}" for k, v in f.items() if k not in ("kind", "severity")))
    return 1 if errors else 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except BrokenPipeError:  # output piped to head/less and closed early: not an error
        with contextlib.suppress(OSError):
            sys.stdout.close()
        sys.exit(141)
