#!/usr/bin/env python3
"""retire_copy: retire declared STALE skill copies safely and reversibly.

  plan      list what would be retired and what blocks it            (default, writes nothing)
  apply     retire the candidates                                    (needs --yes)
  rollback  put everything back from a manifest                      (needs --yes)

Safety rules, all enforced here:
- Only entries the registry marks role "stale*" can be retired, never a canonical copy.
- The stale copy and its canonical copy must STILL match the hashes they were declared against.
  A changed copy is blocked: the declaration is out of date and must be reviewed first.
- A reference that names the stale copy together with a path inside it (e.g. `name`'s data/x.md)
  blocks retirement: repoint it first, or, after reading each one and confirming it resolves to the
  canonical copy, acknowledge them with --accept-refs BASE (recorded in the manifest). Names match as
  whole tokens only (the bare name `x` does not match inside `ns:x`). Raw evidence logs
  (drift-check-*.md) and seed fixtures are ignored by default; add more with --ignore GLOB. Plain name mentions are allowed and are recorded as aliases
  of the canonical copy so the citation audit still resolves them.
- A collision with status "needs_merge_review" is skipped unless you pass --merge-reviewed BASE,
  your explicit statement that you have read the lines that exist only in the stale copy.
- Nothing is deleted. The folder is MOVED to an archive outside every skills root, with a manifest
  of whole-folder hashes, so `rollback` restores it byte for byte.
- The registry is rewritten only on `apply`, and a .bak copy is kept.

Exit: 0 ok/plan clean, 1 blocked or failed, 2 INCOMPLETE (registry or manifest missing).
"""
import argparse
import fnmatch
import hashlib
import json
import re
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

import gia_state
import registry_check as rc

TEXT_EXT = (".md", ".py", ".sh", ".json", ".txt", ".js", ".yaml", ".yml")
PATH_BEARING = re.compile(r"\b(?:data|scripts|references|assets)/[\w./-]+")
DEFAULT_IGNORE = ("*/references/drift-check-*.md", "*/references/seed/*")


def tree_hash(folder):
    h = hashlib.sha256()
    for p in sorted(Path(folder).rglob("*")):
        if p.is_file() and "__pycache__" not in p.parts:
            h.update(str(p.relative_to(folder)).encode())
            h.update(hashlib.sha256(p.read_bytes()).digest())
    return h.hexdigest()


def references(name, roots, skip, ignore=DEFAULT_IGNORE):
    """(path-bearing, plain) lines that mention a skill folder name as a WHOLE token, outside the
    folder itself and outside ignored evidence/fixture files."""
    pb, plain = [], []
    token = re.compile(r"(?<![\w:.-])" + re.escape(name) + r"(?![\w-])")
    for r in roots:
        rp = Path(r)
        if not rp.is_dir():
            continue
        for f in rp.rglob("*"):
            if not f.is_file() or f.suffix not in TEXT_EXT or skip in f.parents or "__pycache__" in f.parts:
                continue
            if any(fnmatch.fnmatch(str(f), g) for g in ignore):
                continue
            try:
                lines = f.read_text(encoding="utf-8", errors="replace").splitlines()
            except OSError:
                continue
            for i, line in enumerate(lines, 1):
                if token.search(line):
                    (pb if PATH_BEARING.search(line) else plain).append(f"{f}:{i}")
    return pb, plain


def candidates(reg, roots, merge_reviewed, accept_refs=(), ignore=DEFAULT_IGNORE):
    out = []
    for c in reg.get("collisions", []):
        for o in c.get("others", []):
            if not o["role"].startswith("stale"):
                continue
            item = {"base": c["base"], "status": c["status"], "entry": o, "canonical": c["canonical"], "blocks": []}
            if c["status"] == "needs_merge_review" and c["base"] not in merge_reviewed:
                item["blocks"].append("needs_merge_review: read the lines only in this copy, then pass --merge-reviewed " + c["base"])
            stale, canon = rc.locate(o, roots), rc.locate(c["canonical"], roots)
            if stale is None:
                item["blocks"].append("stale copy not found in these roots")
            elif rc.sha(stale) != o["sha256"]:
                item["blocks"].append("stale copy changed since it was declared: re-review, then registry_check --refresh")
            if canon is None:
                item["blocks"].append("canonical copy not found")
            elif rc.sha(canon) != c["canonical"]["sha256"]:
                item["blocks"].append("canonical copy changed since it was declared: re-review, then registry_check --refresh")
            item["path"] = stale
            if stale is not None:
                name = stale.name
                item["name"] = name
                item["pathbearing"], item["plain"] = references(name, roots, stale, ignore)
                item["accepted_refs"] = c["base"] in accept_refs and bool(item["pathbearing"])
                if item["pathbearing"] and c["base"] not in accept_refs:
                    item["blocks"].append(f"{len(item['pathbearing'])} reference(s) name it together with a path inside it: repoint first")
            out.append(item)
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("action", choices=["plan", "apply", "rollback"])
    ap.add_argument("manifest", nargs="?", help="rollback: the manifest written by apply")
    ap.add_argument("--registry")
    ap.add_argument("--roots", nargs="+", default=rc.DEFAULT_ROOTS)
    ap.add_argument("--archive", help="folder OUTSIDE every root to move retired copies into")
    ap.add_argument("--merge-reviewed", action="append", default=[], metavar="BASE")
    ap.add_argument("--accept-refs", action="append", default=[], metavar="BASE",
                    help="you read every path-bearing reference to this copy and each resolves to the canonical one")
    ap.add_argument("--ignore", action="append", default=[], metavar="GLOB")
    ap.add_argument("--yes", action="store_true")
    ns = ap.parse_args(argv)
    if ns.action == "rollback":
        return rollback(ns)
    regp = gia_state.registry_path(ns.registry)
    if not regp.exists():
        print(f"INCOMPLETE: no registry at {regp}.")
        return 2
    reg = json.loads(regp.read_text(encoding="utf-8"))
    cands = candidates(reg, ns.roots, set(ns.merge_reviewed), set(ns.accept_refs), DEFAULT_IGNORE + tuple(ns.ignore))
    ok = [c for c in cands if not c["blocks"]]
    print(f"{len(cands)} stale copy(ies) declared; {len(ok)} can be retired now, {len(cands) - len(ok)} blocked")
    for c in cands:
        mark = "RETIRE" if not c["blocks"] else "BLOCKED"
        print(f"  [{mark}] {c['base']}: {c['entry']['path']}  (canonical {c['canonical']['path']})")
        for b in c["blocks"]:
            print(f"      - {b}")
        for ref in c.get("pathbearing", [])[:4]:
            print(f"      reference: {ref}" + ("  (acknowledged)" if c.get("accepted_refs") else ""))
        if not c["blocks"]:
            print(f"      plain name mentions covered by the alias: {len(c.get('plain', []))}")
    if ns.action == "plan":
        print("Plan only. Nothing was changed. Use `apply --yes --archive DIR` to retire the RETIRE entries.")
        return 1 if (cands and not ok) else 0
    if not ns.yes:
        print("REFUSED: apply needs --yes.")
        return 1
    if not ns.archive:
        print("REFUSED: apply needs --archive DIR (outside every skills root).")
        return 1
    arch = Path(ns.archive).resolve()
    if any(Path(r).resolve() in arch.parents or Path(r).resolve() == arch for r in ns.roots):
        print("REFUSED: the archive must be outside every skills root.")
        return 1
    if not ok:
        print("Nothing to retire.")
        return 1 if cands else 0
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    dest_root = arch / stamp
    dest_root.mkdir(parents=True)
    moved = []
    for c in ok:
        src = Path(c["path"])
        dst = dest_root / f"{src.parent.name}__{src.name.replace(':', '_')}"
        th = tree_hash(src)
        shutil.move(str(src), str(dst))
        assert tree_hash(dst) == th, "archive copy does not match the original"
        moved.append({"from": str(src), "to": str(dst), "tree_sha256": th, "base": c["base"],
                      "registry_path": c["entry"]["path"], "canonical": c["canonical"]["path"],
                      "acknowledged_references": c.get("pathbearing", []) if c.get("accepted_refs") else [],
                      "merge_reviewed": c["base"] in ns.merge_reviewed})
        print(f"  moved {src}  ->  {dst}")
    # registry: drop retired others, drop emptied collisions, add aliases for the retired names
    Path(str(regp) + ".bak").write_text(regp.read_text(encoding="utf-8"), encoding="utf-8")
    gone = {m["registry_path"] for m in moved}
    for col in list(reg["collisions"]):
        col["others"] = [o for o in col["others"] if o["path"] not in gone]
        if not col["others"]:
            reg["collisions"].remove(col)
    for m in moved:
        a = m["registry_path"].split("/", 1)[1]
        b = m["canonical"].split("/", 1)[1]
        reg.setdefault("aliases", []).append({"names": [a, b], "note": f"retired {stamp}: {a} was a stale copy of {b}"})
    regp.write_text(json.dumps(reg, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    manifest = dest_root / "MANIFEST.json"
    manifest.write_text(json.dumps({"retired_at": stamp, "registry": str(regp),
                                    "registry_backup": str(regp) + ".bak", "moved": moved}, indent=2) + "\n", encoding="utf-8")
    print(f"Manifest: {manifest}\nUndo: retire_copy.py rollback {manifest} --yes")
    return 0


def rollback(ns):
    if not ns.manifest or not Path(ns.manifest).exists():
        print("INCOMPLETE: give the MANIFEST.json written by apply.")
        return 2
    man = json.loads(Path(ns.manifest).read_text(encoding="utf-8"))
    problems = []
    for m in man["moved"]:
        if not Path(m["to"]).exists():
            problems.append(f"archived copy missing: {m['to']}")
        elif tree_hash(m["to"]) != m["tree_sha256"]:
            problems.append(f"archived copy was modified: {m['to']}")
        if Path(m["from"]).exists():
            problems.append(f"destination already exists: {m['from']}")
    for p in problems:
        print("  BLOCKED:", p)
    if problems:
        return 1
    if not ns.yes:
        print(f"Plan: restore {len(man['moved'])} folder(s) and the registry. Add --yes.")
        return 0
    for m in man["moved"]:
        shutil.move(m["to"], m["from"])
        assert tree_hash(m["from"]) == m["tree_sha256"]
        print(f"  restored {m['from']}")
    bak = Path(man["registry_backup"])
    if bak.exists():
        Path(man["registry"]).write_text(bak.read_text(encoding="utf-8"), encoding="utf-8")
        print(f"  registry restored from {bak}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
