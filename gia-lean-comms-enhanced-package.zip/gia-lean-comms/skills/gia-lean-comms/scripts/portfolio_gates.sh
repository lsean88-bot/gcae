#!/usr/bin/env bash
# portfolio_gates.sh: run every portfolio gate once and give ONE honest exit code.
# Run with: bash portfolio_gates.sh [--roots "DIR DIR"] [--skills-dir DIR] [--registry FILE] [--baseline FILE]
#                                   [--bootstrap [--yes] [--force]] [--write-baseline] [--max-baseline-age DAYS]
#
# STATE lives in a state directory, not in the plugin folder (a plugin update replaces that folder):
#   $GIA_STATE_DIR (default ~/.gia-lean-comms) holds portfolio-registry.json and baseline.txt.
#   First run on a new installation:  --bootstrap (dry run), review, then --bootstrap --yes.
# The files under references/seed/ are fixtures from one sandbox, never used implicitly.
#
# Gates (each prints its own result):
#   1 governance drift check   findings compared with the baseline: only NEW findings fail
#   2 citation audit (deep)    broken paths / dangling names: any error fails
#   3 portfolio registry       undeclared collisions, stale declarations: any error fails
#   4 skill validation         Claude Code validity: any error fails
#   5 quality-gate audit       gaps compared with the baseline: only NEW gaps fail
#
# Exit codes:  0 = nothing new and every gate ran
#              1 = a new finding or an error
#              2 = INCOMPLETE: a gate could not run (a skipped gate is not a pass)
#
# The baseline records findings the owner already knows about, so a scheduled run alerts on
# change rather than failing forever. Known findings are STILL counted and printed every run,
# and the baseline's age is shown, so it cannot quietly become permission to ignore them.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
STATE_DIR="${GIA_STATE_DIR:-$HOME/.gia-lean-comms}"
REGISTRY="${GIA_REGISTRY:-$STATE_DIR/portfolio-registry.json}"
BASELINE="${GIA_BASELINE:-$STATE_DIR/baseline.txt}"
EXPLICIT=0; BOOT=0; YES=0; FORCE=0; ROOTS_ARG=()
SKILLS_DIR=""
WRITE=0
MAX_AGE=90
while [ $# -gt 0 ]; do
  case "$1" in
    --skills-dir) SKILLS_DIR="${2:-}"; shift ;;
    --baseline) BASELINE="${2:-}"; EXPLICIT=1; shift ;;
    --registry) REGISTRY="${2:-}"; EXPLICIT=1; shift ;;
    --roots) read -r -a ROOTS_ARG <<<"${2:-}"; shift ;;
    --bootstrap) BOOT=1 ;;
    --yes) YES=1 ;;
    --force) FORCE=1 ;;
    --write-baseline) WRITE=1 ;;
    --max-baseline-age) MAX_AGE="${2:-90}"; shift ;;
    *) echo "unknown option: $1"; exit 64 ;;
  esac
  shift
done

NEW=0; INCOMPLETE=0
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
# --roots: every python gate gets them; the drift check scans a merged view of the same roots
RARGS=(); if [ ${#ROOTS_ARG[@]} -gt 0 ]; then
  RARGS=(--roots "${ROOTS_ARG[@]}")
  if [ -z "$SKILLS_DIR" ]; then
    SKILLS_DIR="$TMP/merged"; mkdir -p "$SKILLS_DIR"
    for r in "${ROOTS_ARG[@]}"; do for d in "$r"/*/; do [ -f "${d}SKILL.md" ] && [ ! -e "$SKILLS_DIR/$(basename "$d")" ] && ln -s "${d%/}" "$SKILLS_DIR/$(basename "$d")"; done; done
  fi
fi
say() { printf '%s\n' "$*"; }

find_drift() {
  # An explicit DRIFT_SCRIPT is authoritative: never silently fall back to another copy.
  if [ -n "${DRIFT_SCRIPT:-}" ]; then [ -f "$DRIFT_SCRIPT" ] && { echo "$DRIFT_SCRIPT"; return 0; }; return 1; fi
  for d in "" /mnt/skills/plugins/iron-rules-governance/scripts/check-governance-drift.sh \
           /mnt/skills/user/iron-rules-governance/scripts/check-governance-drift.sh \
           "$HOME/.claude/skills/iron-rules-governance/scripts/check-governance-drift.sh"; do
    [ -n "$d" ] && [ -f "$d" ] && { echo "$d"; return 0; }
  done
  return 1
}
normalise() { sed -E 's#/tmp/tmp\.[A-Za-z0-9]+/#<skills>/#g; s#:[0-9]+:#::#g; s#^=== .*##; s#^Scanning:.*##; s#^Scope:.*##; s#^Skills in scope:.*##' | grep -E '^    ' | sort -u; }

# --- first-run guard and bootstrap
if [ $BOOT -eq 1 ]; then
  BARGS=("${RARGS[@]}" --registry "$REGISTRY" --bootstrap); [ $YES -eq 1 ] && BARGS+=(--yes); [ $FORCE -eq 1 ] && BARGS+=(--force)
  say "=== Bootstrap (accepts the CURRENT state as known; review it first) ==="
  python3 "$HERE/registry_check.py" "${BARGS[@]}" || exit $?
  if [ $YES -eq 1 ]; then WRITE=1; mkdir -p "$(dirname "$BASELINE")"; else
    say; say "Dry run: no registry or baseline was written. Re-run with --bootstrap --yes to accept this state."; exit 0; fi
elif [ $EXPLICIT -eq 0 ] && [ ! -f "$REGISTRY" ] && [ ! -f "$BASELINE" ]; then
  say "INCOMPLETE: no state found in $STATE_DIR (first run on this installation)."
  say "  1. bash portfolio_gates.sh --bootstrap          # dry run: shows what would be accepted"
  say "  2. review it, then:  bash portfolio_gates.sh --bootstrap --yes"
  say "A check that cannot run is not a pass."; exit 2
fi

LBL="NEW"; [ $WRITE -eq 1 ] && LBL="ACCEPTED"
say "=== Portfolio gates $(date -u +%Y-%m-%dT%H:%MZ) ==="

# --- 1. drift
say; say "--- 1. Governance drift check"
DRIFT="$(find_drift)" || DRIFT=""
if [ -z "$DRIFT" ]; then say "  INCOMPLETE: check-governance-drift.sh not found"; INCOMPLETE=$((INCOMPLETE+1))
else
  if [ -n "$SKILLS_DIR" ]; then bash "$DRIFT" "$SKILLS_DIR" >"$TMP/drift.txt" 2>&1; else bash "$DRIFT" >"$TMP/drift.txt" 2>&1; fi
  RC=$?
  if [ $RC -eq 2 ]; then say "  INCOMPLETE: drift script exit 2 ($(grep -E 'INCOMPLETE|not a directory' "$TMP/drift.txt" | head -1))"; INCOMPLETE=$((INCOMPLETE+1))
  else
    normalise <"$TMP/drift.txt" >"$TMP/drift.norm"
    grep '^drift: ' "$BASELINE" 2>/dev/null | sed 's/^drift: //' | sort -u >"$TMP/drift.base"
    comm -13 "$TMP/drift.base" "$TMP/drift.norm" >"$TMP/drift.new"
    K=$(wc -l <"$TMP/drift.norm" | tr -d ' '); N=$(wc -l <"$TMP/drift.new" | tr -d ' ')
    say "  $(sed -n 's/^Skills in scope: //p' "$TMP/drift.txt") skills scanned; $K finding line(s) total, $N new vs baseline"
    [ "$N" -gt 0 ] && { sed "s/^/    $LBL: /" "$TMP/drift.new" | head -15; NEW=$((NEW+N)); }
  fi
fi

# --- 2. citation audit
say; say "--- 2. Citation audit (deep)"
python3 "$HERE/interop_check.py" "${RARGS[@]}" --audit-citations --deep --ignore '*/references/drift-check-*.md' --registry "$REGISTRY" >"$TMP/cite.txt" 2>&1; RC=$?
say "  $(grep -E '^Citation findings' "$TMP/cite.txt" || echo 'no output')"
if [ $RC -ne 0 ]; then grep 'error:' "$TMP/cite.txt" | sed 's/^/    /' | head -10; NEW=$((NEW+1)); fi

# --- 3. registry
say; say "--- 3. Portfolio registry"
python3 "$HERE/registry_check.py" "${RARGS[@]}" --registry "$REGISTRY" >"$TMP/reg.txt" 2>&1; RC=$?
say "  $(head -1 "$TMP/reg.txt")"
if [ $RC -eq 2 ]; then INCOMPLETE=$((INCOMPLETE+1)); elif [ $RC -ne 0 ]; then grep 'error' "$TMP/reg.txt" | sed 's/^/    /' | head -10; NEW=$((NEW+1)); fi

# --- 4. validation
say; say "--- 4. Skill validation (Claude Code target)"
python3 "$HERE/validate_portfolio.py" "${RARGS[@]}" >"$TMP/val.txt" 2>&1; RC=$?
say "  $(head -1 "$TMP/val.txt")"
if [ $RC -eq 2 ]; then INCOMPLETE=$((INCOMPLETE+1)); elif [ $RC -ne 0 ]; then grep 'error' "$TMP/val.txt" | sed 's/^/    /' | head -10; NEW=$((NEW+1)); fi

# --- 5. quality-gate audit
say; say "--- 5. Quality-gate audit"
python3 "$HERE/gate_audit.py" "${RARGS[@]}" --registry "$REGISTRY" >"$TMP/gate.txt" 2>&1
grep '\[GAP\]' "$TMP/gate.txt" | sed -E 's/\(line [0-9]+\)/(line N)/g' | sort -u >"$TMP/gate.norm"
grep '^gate: ' "$BASELINE" 2>/dev/null | sed 's/^gate: //' | sort -u >"$TMP/gate.base"
comm -13 "$TMP/gate.base" "$TMP/gate.norm" >"$TMP/gate.new"
N=$(wc -l <"$TMP/gate.new" | tr -d ' '); K=$(wc -l <"$TMP/gate.norm" | tr -d ' ')
say "  $K gap(s) total, $N new vs baseline"
[ "$N" -gt 0 ] && { sed "s/^/    $LBL: /" "$TMP/gate.new"; NEW=$((NEW+N)); }

# --- baseline write / age
if [ $WRITE -eq 1 ]; then
  { echo "# portfolio_gates baseline, written $(date -u +%F). Known findings accepted by the owner; they are still reported every run."
    sed 's/^/drift: /' "$TMP/drift.norm"; sed 's/^/gate: /' "$TMP/gate.norm"; } >"$BASELINE"
  say; say "Baseline written: $BASELINE"; exit 0
fi
if [ -f "$BASELINE" ]; then
  BD="$(sed -n '1s/.*written \([0-9-]*\).*/\1/p' "$BASELINE")"
  if [ -n "$BD" ]; then
    BTS="$(date -u -d "$BD" +%s 2>/dev/null)"
    if [ -z "$BTS" ]; then
      say; say "Baseline: $BD (age unknown: this system's date lacks GNU -d; re-review it manually)"
    else
      AGE=$(( ( $(date -u +%s) - BTS ) / 86400 ))
      say; say "Baseline: $BD (${AGE} days old; accepted known findings are still listed above as totals)"
      [ "$AGE" -gt "$MAX_AGE" ] && say "  WARNING: baseline older than $MAX_AGE days. Re-review the known findings."
    fi
  fi
else
  say; say "WARNING: no baseline file at $BASELINE; every finding counts as new"
fi

say; say "=== RESULT ==="
if [ $NEW -gt 0 ]; then say "FAIL: $NEW new finding(s) or error(s)"; exit 1
elif [ $INCOMPLETE -gt 0 ]; then say "INCOMPLETE: $INCOMPLETE gate(s) could not run. This is not a pass."; exit 2
else say "PASS: nothing new, every gate ran"; exit 0; fi
