#!/usr/bin/env python3
"""zone_guard: classify a path and/or purpose text as PROTECTED or LEAN. Fails closed.

Exit 0 = LEAN, exit 2 = PROTECTED. Anything ambiguous is PROTECTED.
"""
import argparse
import json
import re
import sys
from pathlib import Path

# Multilingual stems (Chinese, Spanish, Malay). Added after UAT showed 15 of 28 audit-related
# filenames fail open: every non-English name with a data extension was classed LEAN.
PROTECTED_INTL = re.compile(
    r"(审计|審計|发现|發現|报告|報告|调查|調查|证据|證據|舞弊|欺诈|欺詐|管理层|管理層|回复|回覆|董事会|董事會|"
    r"工作底稿|底稿|整改|行动计划|行動計劃|举报|舉報|合规|合規|"
    r"hallazgo|informe|auditor[ií]a|evidencia|fraude|investigaci[oó]n|gerencia|respuesta|"
    r"junta|denuncia|papeles[-_ ]de[-_ ]trabajo|plan[-_ ]de[-_ ]acci[oó]n|"
    r"penemuan|laporan|siasatan|bukti|penipuan|pengurusan|maklum[-_ ]balas|"
    r"lembaga|aduan|kertas[-_ ]kerja|pematuhan)", re.I)
PROTECTED_NAMES = re.compile(
    r"(skill\.md|claude\.md|memory|lessons|iron-rules|governance|finding|\biar\b|iar[-_]|report|"
    r"board|audit[-_ ]?committee|\bac[-_ ]?paper|chairman|workpaper|racm|rcm|"
    r"management[-_ ]?response|action[-_ ]?plan|regulator|submission|statutory|filing|"
    r"representation|memo|investigation|fraud|whistle|disciplin|legal|contract|evidence|5c)",
    re.I,
)
PROTECTED_PURPOSE = re.compile(
    r"(finding|audit report|board|audit committee|chairman|regulator|external auditor|"
    r"submission|management response|action plan|\br[1-5]\b|evidence|fraud|whistle|legal|"
    r"disciplin|recommendation|iron rule|quality gate|statut|citation|workpaper)",
    re.I,
)
# Only code and run logs are lean by extension. Data and text files (.csv .json .yaml .txt)
# are where audit evidence lives, so they are NOT lean on extension alone: they stay ambiguous
# and therefore PROTECTED unless the caller supplies a working-chatter purpose.
LEAN_EXT = {".py", ".js", ".mjs", ".sh", ".log"}
LEAN_PURPOSE = re.compile(
    r"(tool[- ]call|progress|status|debug|uat|test run|script|stack trace|file operation|"
    r"scaffold|query|clarif)",
    re.I,
)


def classify(path=None, purpose=None):
    reasons, protected, lean = [], False, False
    if path:
        p = Path(path)
        full = str(p).replace("\\", "/")
        hit = PROTECTED_NAMES.search(full) or PROTECTED_INTL.search(full)
        if hit:
            protected = True
            reasons.append(f"path matches protected pattern: {hit.group(0)!r}")
        elif p.suffix.lower() in LEAN_EXT:
            lean = True
            reasons.append(f"extension {p.suffix} is code/data")
    if purpose:
        hit = PROTECTED_PURPOSE.search(purpose) or PROTECTED_INTL.search(purpose)
        if hit:
            protected = True
            reasons.append(f"purpose matches protected pattern: {hit.group(0)!r}")
        elif LEAN_PURPOSE.search(purpose):
            lean = True
            reasons.append("purpose is working chatter")
    if protected:
        return "PROTECTED", reasons
    if lean:
        return "LEAN", reasons
    return "PROTECTED", reasons + ["ambiguous: fail closed"]


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--path")
    ap.add_argument("--purpose")
    ap.add_argument("--json", action="store_true")
    ns = ap.parse_args(argv)
    if not ns.path and not ns.purpose:
        ap.error("give --path and/or --purpose")
    zone, reasons = classify(ns.path, ns.purpose)
    if ns.json:
        print(json.dumps({"zone": zone, "reasons": reasons}, indent=2))
    else:
        print(zone)
        for r in reasons:
            print("  -", r)
    return 0 if zone == "LEAN" else 2


if __name__ == "__main__":
    sys.exit(main())
