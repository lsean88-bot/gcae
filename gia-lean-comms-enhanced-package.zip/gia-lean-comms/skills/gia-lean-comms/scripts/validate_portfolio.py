#!/usr/bin/env python3
"""validate_portfolio: structural validation of every skill, aware of the deployment target.

skill-creator's quick_validate.py encodes the claude.ai / Skills API UPLOAD rules, which
reject any frontmatter key outside {name, description, license, allowed-tools, metadata,
compatibility}. Claude Code loads skills from the filesystem and accepts more. Running the
strict rule across a Claude Code portfolio reports hundreds of non-errors and hides real ones
(measured 2026-10-03: 52 of 146 skills 'invalid', almost all for Claude Code-only keys).

Per skill this reports two independent verdicts:
  code_ok     valid for Claude Code: real checks only (frontmatter parses, description present
              and <=1024 chars with no angle brackets, name kebab-case <=64 if present)
  upload_ok   valid for claude.ai / Skills API upload: the strict rule, including key allow-list,
              mandatory name, and a single SKILL.md per skill

Severity: error (fails code_ok), warn (Claude Code-only key, missing name, nested SKILL.md),
and an upload-only list so you know which skills could not be uploaded as they stand.
Exit 0 = no code_ok errors, 1 = errors, 2 = no skills found (INCOMPLETE).
"""
import argparse
import contextlib
import json
import re
import sys
from pathlib import Path

try:
    import yaml
except ImportError:  # pragma: no cover
    yaml = None

DEFAULT_ROOTS = ["/mnt/skills/user", "/mnt/skills/plugins"]
UPLOAD_KEYS = {"name", "description", "license", "allowed-tools", "metadata", "compatibility"}
CODE_ONLY_KEYS = {"argument-hint", "user-invocable", "disable-model-invocation", "tags", "version",
                  "model", "context", "agent", "hooks", "when_to_use", "arguments", "paths"}
SKIP_PARTS = {"__pycache__", "node_modules", "evals"}


def frontmatter(text):
    m = re.match(r"^---\n(.*?)\n---", text, re.DOTALL)
    if not m:
        return None, "No YAML frontmatter" if not text.startswith("---") else "Invalid frontmatter block"
    if yaml is None:
        return None, "PyYAML not installed"
    try:
        fm = yaml.safe_load(m.group(1))
    except yaml.YAMLError as e:
        return None, f"Invalid YAML: {str(e).splitlines()[0]}"
    return (fm, None) if isinstance(fm, dict) else (None, "Frontmatter is not a mapping")


def nested_skill_mds(d):
    return [p for p in d.rglob("SKILL.md")
            if p != d / "SKILL.md" and not any(part in SKIP_PARTS for part in p.relative_to(d).parts[:-1])]


def validate(d):
    errors, warns, upload_only = [], [], []
    text = (d / "SKILL.md").read_text(encoding="utf-8", errors="replace")
    fm, err = frontmatter(text)
    if err:
        return {"errors": [err], "warns": [], "upload_only": []}
    desc, name = fm.get("description"), fm.get("name")
    if desc is None or not str(desc).strip():
        errors.append("missing description")
    else:
        desc = str(desc).strip()
        if not isinstance(fm["description"], str):
            errors.append(f"description must be a string, got {type(fm['description']).__name__}")
        if "<" in desc or ">" in desc:
            errors.append("description contains angle brackets")
        if len(desc) > 1024:
            errors.append(f"description {len(desc)} chars (max 1024)")
    if name is None:
        warns.append("no name: field (Claude Code uses the folder name)")
        upload_only.append("missing name (required for upload)")
    else:
        n = str(name).strip()
        if not re.match(r"^[a-z0-9-]+$", n) or n.startswith("-") or n.endswith("-") or "--" in n:
            errors.append(f"name {n!r} is not kebab-case")
        elif len(n) > 64:
            errors.append(f"name {len(n)} chars (max 64)")
    extra = set(fm) - UPLOAD_KEYS
    for k in sorted(extra & CODE_ONLY_KEYS):
        warns.append(f"Claude Code-only key: {k}")
        upload_only.append(f"key {k} rejected on upload")
    for k in sorted(extra - CODE_ONLY_KEYS):
        warns.append(f"unrecognised key: {k}")
        upload_only.append(f"key {k} rejected on upload")
    nested = nested_skill_mds(d)
    if nested:
        warns.append(f"{len(nested)} nested SKILL.md (Claude Code loads them; upload rejects)")
        upload_only.append("nested SKILL.md")
    return {"errors": errors, "warns": warns, "upload_only": upload_only}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--roots", nargs="+", default=DEFAULT_ROOTS)
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--list-upload-blockers", action="store_true")
    ns = ap.parse_args(argv)
    if yaml is None:
        print("INCOMPLETE: PyYAML is not installed (pip install pyyaml); a check that cannot run is not a pass.")
        return 2
    rows = {}
    for r in ns.roots:
        for d in sorted(Path(r).glob("*/")):
            if (d / "SKILL.md").exists():
                rows[f"{Path(r).name}/{d.name}"] = validate(d)
    if not rows:
        print("INCOMPLETE: no skills found; a check that cannot run is not a pass.")
        return 2
    code_bad = {k: v for k, v in rows.items() if v["errors"]}
    upload_bad = {k: v for k, v in rows.items() if v["errors"] or v["upload_only"]}
    if ns.json:
        print(json.dumps({"skills": len(rows), "code_errors": len(code_bad), "upload_blocked": len(upload_bad),
                          "detail": rows}, indent=2))
    else:
        print(f"{len(rows)} skills: {len(rows) - len(code_bad)} valid for Claude Code, "
              f"{len(code_bad)} with errors; {len(rows) - len(upload_bad)} upload-ready, "
              f"{len(upload_bad)} blocked from claude.ai upload")
        for k, v in code_bad.items():
            print(f"  [error] {k}: {'; '.join(v['errors'])}")
        if ns.list_upload_blockers:
            for k, v in upload_bad.items():
                if not v["errors"]:
                    print(f"  [upload] {k}: {'; '.join(v['upload_only'])}")
    return 1 if code_bad else 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except BrokenPipeError:  # output piped to head/less and closed early: not an error
        with contextlib.suppress(OSError):
            sys.stdout.close()
        sys.exit(141)
