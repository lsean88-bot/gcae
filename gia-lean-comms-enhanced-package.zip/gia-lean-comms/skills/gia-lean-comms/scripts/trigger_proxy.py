#!/usr/bin/env python3
"""trigger_proxy: LEXICAL coverage check of a skill description against a trigger eval set.

THIS IS NOT A MEASUREMENT OF REAL TRIGGERING. Whether Claude loads a skill depends on the
model and the full skill list. skill-creator's run_eval.py measures that, and needs the
`claude` CLI. This script only answers two cheap questions:

  1. For each should-trigger query, does the description contain at least one distinctive
     phrase or two content words that also appear in the query? Zero overlap means the
     description cannot be what attracts it: a vocabulary GAP.
  2. For each should-not query, does the description overlap on two or more content words?
     That is a RISK of over-triggering.

Exit 0 = no gaps and no risks, 1 = gaps or risks, 2 = inputs unreadable (INCOMPLETE).
"""
import argparse
import json
import re
import sys
from pathlib import Path

STOP = set("""a an and are as at be but by can do does for from has have how i if in into is it its
me my no not of on or our so that the their them then there these they this to up us was we what
when where which who will with would you your all any also been being both each more most other
some such than too very just about over under again after before""".split())


def words(text):
    return {w for w in re.findall(r"[a-z][a-z0-9.\-]{2,}", text.lower()) if w not in STOP}


def description(skill_md):
    t = Path(skill_md).read_text(encoding="utf-8")
    m = re.match(r"^---\n(.*?)\n---", t, re.DOTALL)
    if not m:
        raise ValueError("no frontmatter")
    import yaml
    return str(yaml.safe_load(m.group(1)).get("description", ""))


def phrases(desc):
    m = re.search(r"Trigger on:(.*)$", desc, re.S | re.I)
    return [p.strip().lower() for p in re.split(r",| or ", m.group(1)) if p.strip()] if m else []


def analyse(desc, evals):
    dw, ph = words(desc), phrases(desc)
    rows = []
    for e in evals:
        q = e["query"].lower()
        qw = words(q)
        phrase_hits = [p for p in ph if p and p in q]
        word_hits = sorted(qw & dw)
        rows.append({"query": e["query"], "should_trigger": e["should_trigger"],
                     "phrase_hits": phrase_hits, "word_hits": word_hits,
                     "gap": e["should_trigger"] and not phrase_hits and len(word_hits) < 2,
                     "risk": (not e["should_trigger"]) and (bool(phrase_hits) or len(word_hits) >= 2)})
    return rows


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--skill", required=True, help="path to the skill folder")
    ap.add_argument("--evals", required=True)
    ap.add_argument("--json", action="store_true")
    ns = ap.parse_args(argv)
    try:
        desc = description(Path(ns.skill) / "SKILL.md")
        evals = json.loads(Path(ns.evals).read_text(encoding="utf-8"))
    except Exception as e:  # noqa: BLE001
        print(f"INCOMPLETE: {e}")
        return 2
    rows = analyse(desc, evals)
    gaps = [r for r in rows if r["gap"]]
    risks = [r for r in rows if r["risk"]]
    if ns.json:
        print(json.dumps({"gaps": len(gaps), "risks": len(risks), "rows": rows}, indent=2))
    else:
        print(f"{len(rows)} queries: {len(gaps)} vocabulary gap(s), {len(risks)} over-trigger risk(s)  [lexical proxy, not a measurement]")
        for r in gaps:
            print(f"  GAP  (should trigger, little overlap): {r['query']}")
        for r in risks:
            print(f"  RISK (should NOT trigger, overlaps {r['phrase_hits'] or r['word_hits']}): {r['query']}")
    return 1 if (gaps or risks) else 0


if __name__ == "__main__":
    sys.exit(main())
