#!/usr/bin/env python3
"""gate_audit: find every 'N-item ... gate' section in the portfolio, count its enumerated
items, and test which of the canonical Quality Gate concepts it covers (Rule 09 / Rule 30).

Why: the governance drift check flags gate counts that are not 12, but cannot say whether
a different count is a harmless variant or a gate that lets a report go FINAL while skipping
a canonical check.

CORRECTION 2026-10-03: the first version of this tool measured each gate section alone and
concluded a report could reach FINAL without CD/SD/MW classification or aggregation. That
overstated it. The v6 skills run TWO gates before FINAL (a 10-item fieldwork gate and a 30-item
report-conversion QA whose item 28 checks that an aggregation summary is present). Coverage is
therefore computed per SKILL, across all of its gates ("union"). Measured result: the current
v6 engine's residual gap is CD/SD/MW classification only; aggregation is covered, though the
conversion gate checks presence of a summary, not completion of the assessment. The older
10-item skills (v3/v4/v5) predate the CD/SD/MW feature and are superseded by v6.

Concept coverage is a keyword proxy over the section text. It shows what the written gate
mentions, not what any tool enforces. Report-only by default; --strict exits 1 on any gap.
"""
import argparse
import contextlib
import json
import re
import sys
from pathlib import Path

DEFAULT_ROOTS = ["/mnt/skills/user", "/mnt/skills/plugins"]

CONCEPTS = {
    "evidence": r"named evidence|evidence file|portal",
    "rates_validated": r"web-validated|validated rates|source url",
    "act_date_jurisdiction": r"expired law|correct act|effective date|jurisdiction|wrong .{0,12}law",
    "duplicates_merged": r"duplicate",
    "no_retracted_or_drafts": r"retracted|draft|comment text|internal cae note",
    "risk_rating": r"risk colou?r|rated|rating",
    "deficiency_classification": r"\bCD\s*/?\s*SD\s*/?\s*MW\b|deficiency classification",
    "aggregation": r"aggregat",
    "smart_recommendations": r"\bSMART\b",
    "version_signoff": r"version|sign-?off",
    "reference_appendix": r"appendix",
    "disclaimer": r"disclaimer",
}
HEAD = re.compile(r"^(#{1,6})\s+(.*)$")
GATE_HEAD = re.compile(
    r"(\d+)[- ]?item[^\n]{0,40}(?:gate|qa checklist)|gate[^\n]{0,40}\((\d+)[- ]?item|quality gate\s*[—-]\s*(\d+)\s*items",
    re.I)
GROUP_PARA = re.compile(r"\*\*[^*]*?\((\d+)[–-](\d+)\):?\*\*:?\s*(.*)", re.S)
ITEM = re.compile(r"^\s*(?:\|\s*\d+\s*\||- \[[ xX]\]|\d+[.)]\s|\u2610\s+\d+)")


def grouped_items(body):
    """Count items in 'bold group (a-b): x · y · z' paragraphs (the 30-item QA layout), and note
    any group whose entry count disagrees with its own declared range."""
    total, mismatches = 0, []
    for para in re.split(r"\n\s*\n", "\n".join(body)):
        m = GROUP_PARA.match(para.strip())
        if not m:
            continue
        lo, hi = int(m.group(1)), int(m.group(2))
        n = len([x for x in re.split(r"\s·\s", re.sub(r"\s*\n\s*", " ", m.group(3))) if x.strip()])
        total += n
        if n != hi - lo + 1:
            mismatches.append(f"({lo}-{hi}) lists {n}")
    return total, mismatches


def sections(path):
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    i = 0
    while i < len(lines):
        m = HEAD.match(lines[i])
        if m and GATE_HEAD.search(m.group(2)):
            level, j = len(m.group(1)), i + 1
            while j < len(lines):
                h = HEAD.match(lines[j])
                if h and len(h.group(1)) <= level and re.search(r"\w", h.group(2)):
                    break  # decorative '## =====' lines are not headings
                j += 1
            body = lines[i:j]
            g = GATE_HEAD.search(m.group(2))
            asserted = int(next(x for x in g.groups() if x))
            yield i + 1, asserted, body
            i = j
        else:
            i += 1


def audit(roots):
    rows = []
    for r in roots:
        for sk in sorted(Path(r).glob("*/SKILL.md")):
            for lineno, asserted, body in sections(sk):
                text = "\n".join(body)
                enumerated = sum(1 for ln in body if ITEM.match(ln))
                group_note = []
                if enumerated == 0:
                    enumerated, group_note = grouped_items(body)
                covered = {k for k, rx in CONCEPTS.items() if re.search(rx, text, re.I)}
                rows.append({"skill": f"{sk.parent.parent.name}/{sk.parent.name}", "line": lineno,
                             "asserted": asserted, "enumerated": enumerated,
                             "count_consistent": asserted == enumerated and not group_note,
                             "group_range_mismatches": group_note,
                             "covered": sorted(covered),
                             "missing_concepts": sorted(set(CONCEPTS) - covered)})
    return rows


def per_skill(rows):
    """Coverage across ALL gates of a skill: what a report must pass before FINAL."""
    out = {}
    for r in rows:
        e = out.setdefault(r["skill"], {"gates": [], "covered": set()})
        e["gates"].append(f"{r['asserted']}-item (line {r['line']})")
        e["covered"] |= set(r["covered"])
    return {k: {"gates": v["gates"], "union_missing": sorted(set(CONCEPTS) - v["covered"])}
            for k, v in sorted(out.items())}


def superseded_names(registry_path):
    if not registry_path:
        return set()
    return {s["skill"] for s in json.loads(Path(registry_path).read_text(encoding="utf-8")).get("superseded", [])}


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--roots", nargs="+", default=DEFAULT_ROOTS)
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--strict", action="store_true")
    ap.add_argument("--registry", help="portfolio-registry.json: skills it lists as superseded are reported as LEGACY, not as gaps")
    ns = ap.parse_args(argv)
    if ns.registry and not Path(ns.registry).exists():
        print(f"INCOMPLETE: registry not found at {ns.registry}. A check that cannot run is not a pass.")
        return 2
    rows = audit(ns.roots)
    skills = per_skill(rows)
    legacy = superseded_names(ns.registry)
    status = {}
    for k, v in skills.items():
        name = k.split("/", 1)[1]
        count_bad = any(not r["count_consistent"] for r in rows if r["skill"] == k)
        status[k] = "LEGACY" if name in legacy else ("GAP" if (v["union_missing"] or count_bad) else "OK")
    gaps = [k for k, st in status.items() if st == "GAP"]
    if ns.json:
        print(json.dumps({"gates": rows, "skills": {k: {**v, "status": status[k]} for k, v in skills.items()},
                          "with_gaps": len(gaps)}, indent=2))
    else:
        print(f"{len(rows)} gate section(s) in {len(skills)} skill(s); "
              f"{len(gaps)} skill(s) with a gap, {sum(s == 'LEGACY' for s in status.values())} legacy (superseded)")
        for r in rows:
            note = "" if r["count_consistent"] else "  COUNT MISMATCH " + "; ".join(r["group_range_mismatches"])
            print(f"  gate  {r['skill']}:{r['line']} asserts {r['asserted']}, enumerates {r['enumerated']}{note}")
        print("Per skill, across all its gates (what must pass before FINAL):")
        for k, v in skills.items():
            tag = {"OK": "[OK ]", "GAP": "[GAP]", "LEGACY": "[LEGACY]"}[status[k]]
            tail = ("covers every canonical concept" if not v["union_missing"]
                    else "missing: " + ", ".join(v["union_missing"]))
            print(f"  {tag} {k}: {' + '.join(v['gates'])} -> {tail}")
        print("Note: keyword proxy over written text. It shows what a gate mentions, not what any tool enforces.")
    return 1 if (ns.strict and gaps) else 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except BrokenPipeError:  # output piped to head/less and closed early: not an error
        with contextlib.suppress(OSError):
            sys.stdout.close()
        sys.exit(141)
