#!/usr/bin/env python3
"""interop_check: verify skill names resolve across skill roots.

--contract FILE      check each dependency in an interop.json contract
--audit-citations    scan every SKILL.md for skill citations that do not resolve exactly
                     (dangling name, prefix mismatch, or broken /mnt/skills path)
--deep               also scan references/ and other DOCUMENTATION files (.md .json .txt), not just SKILL.md
--include-code       with --deep, also scan code (.py .sh .js). Off by default: scripts legitimately list
                     candidate locations to search, so a path string in code is not a citation (installed in a
                     skills root, this plugin's own scripts used to fail its own audit)
--registry FILE      portfolio-registry.json: names listed under "aliases" are declared
                     equivalent, so their prefix mismatches are not reported
--ignore GLOB        skip files whose path matches (repeatable); use for raw historical
                     evidence logs that must not be edited, e.g. '*/references/drift-check-*.md'
--include-bare       also check bare backticked kebab-case names on lines that mention a
                     skill or plugin (heuristic; reported as severity "info")

Severity: broken_path and dangling are "error" (exit 1). prefix_mismatch and bare_unresolved
are "info": a prefixed name can be a valid plugin invocation name even when the folder
on disk has no prefix, so it is reported, never failed.

Names resolve with or without a namespace prefix: mktron-sentinel:skill-factory
resolves to a directory named skill-factory OR mktron-sentinel:skill-factory.
"""
import argparse
import contextlib
import fnmatch
import json
import os
import re
import sys
from pathlib import Path

DEFAULT_ROOTS = ["/mnt/skills/user", "/mnt/skills/plugins", "/mnt/skills/examples", "/mnt/skills/public"]
CITE = re.compile(r"`([a-z0-9][a-z0-9-]*:[a-z0-9][a-z0-9-]*)`")
SKIP_PREFIXES = ("http", "https", "git", "node", "python", "mailto")


def index(roots):
    names = {}
    for r in roots:
        rp = Path(r)
        if not rp.is_dir():
            continue
        for d in rp.iterdir():
            if d.is_dir() and (d / "SKILL.md").exists():
                names.setdefault(d.name, str(d))
    return names


def resolve(name, names):
    if name in names:
        return names[name]
    if ":" in name:
        bare = name.split(":", 1)[1]
        if bare in names:
            return names[bare]
    else:
        for k, v in names.items():
            if k.endswith(":" + name):
                return v
    return None


def check_contract(path, names):
    contract = json.loads(Path(path).read_text(encoding="utf-8"))
    rows, missing_required = [], []
    for dep in contract["dependencies"]:
        found = resolve(dep["name"], names)
        rows.append({"name": dep["name"], "role": dep["role"],
                     "required": dep["required"], "resolved": found})
        if not found and dep["required"]:
            missing_required.append(dep["name"])
    return rows, missing_required


def namespaces(names):
    return {k.split(":", 1)[0] for k in names if ":" in k}


PATH_CITE = re.compile(r"/mnt/skills/[A-Za-z0-9_.:/-]+")
BARE_CITE = re.compile(r"`([a-z][a-z0-9]*(?:-[a-z0-9]+)+)`")
DOC_EXT = (".md", ".json", ".txt")
CODE_EXT = (".py", ".sh", ".js")
TEXT_EXT = DOC_EXT + CODE_EXT


def iter_files(roots, deep, ignore=(), include_code=False):
    for r in roots:
        rp = Path(r)
        if not rp.is_dir():
            continue
        if not deep:
            for f in sorted(rp.glob("*/SKILL.md")):
                if not any(fnmatch.fnmatch(str(f), g) for g in ignore):
                    yield f
            continue
        for dp, dn, fn in os.walk(rp):
            dn[:] = [d for d in dn if d not in ("node_modules", ".git", "__pycache__")]
            for f in sorted(fn):
                full = str(Path(dp, f))
                if f.endswith(TEXT_EXT if include_code else DOC_EXT) and not any(fnmatch.fnmatch(full, g) for g in ignore):
                    yield Path(dp, f)


def clean_path(raw):
    """Drop grep-style ':63:text' suffixes and trailing punctuation from a matched path."""
    raw = re.sub(r":\d+.*$", "", raw)
    return raw.rstrip(".:,;)`'\"")


def alias_set(registry_path):
    if not registry_path:
        return set()
    reg = json.loads(Path(registry_path).read_text(encoding="utf-8"))
    return {n for a in reg.get("aliases", []) for n in a["names"]}


def acknowledged_set(registry_path):
    if not registry_path:
        return set()
    reg = json.loads(Path(registry_path).read_text(encoding="utf-8"))
    return set(reg.get("acknowledged_uninstalled", [])) | set(reg.get("former_names", {}))


def audit_citations(names, roots, deep=False, include_bare=False, ignore=(), aliases=frozenset(), acknowledged=frozenset(),
                    include_code=False):
    """Findings, each with a severity:
    dangling         error  namespaced name (namespace known to the portfolio) resolves to nothing
    broken_path      error  a literal /mnt/skills/... file path in the text does not exist
    prefix_mismatch  info   resolves only after stripping/adding its namespace prefix
    bare_unresolved  info   (--include-bare) backticked kebab name on a skill/plugin line, no match
    Only namespaces that exist in the portfolio count as skill citations, which excludes
    aspect ratios (16:9), XML attributes (w:id) and search operators (in:sent).
    """
    known_ns = namespaces(names)
    findings = []
    for f in iter_files(roots, deep, ignore, include_code):
        try:
            text = f.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        for cited in sorted(set(CITE.findall(text))):
            if cited.startswith(SKIP_PREFIXES) or cited.split(":", 1)[0] not in known_ns:
                continue
            if cited in names or cited in aliases:
                continue
            kind = "prefix_mismatch" if resolve(cited, names) else "dangling"
            findings.append({"in": str(f), "cites": cited, "kind": kind,
                             "severity": "info" if kind == "prefix_mismatch" else "error"})
        for raw in sorted(set(PATH_CITE.findall(text))):
            path = clean_path(raw)
            if any(c in path for c in "*<>{}$") or not Path(path).suffix:
                continue
            if not Path(path).exists():
                findings.append({"in": str(f), "cites": path, "kind": "broken_path", "severity": "error"})
        if include_bare:
            for line in text.splitlines():
                if not re.search(r"\b(skill|plugin)s?\b", line, re.I):
                    continue
                for cited in BARE_CITE.findall(line):
                    if cited in acknowledged:
                        continue
                    if resolve(cited, names) is None and (Path(f).parent / cited).exists() is False:
                        findings.append({"in": str(f), "cites": cited, "kind": "bare_unresolved", "severity": "info"})
    seen, out = set(), []
    for x in findings:
        k = (x["in"], x["cites"], x["kind"])
        if k not in seen:
            seen.add(k)
            out.append(x)
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--roots", nargs="+", default=DEFAULT_ROOTS)
    ap.add_argument("--contract")
    ap.add_argument("--audit-citations", action="store_true")
    ap.add_argument("--deep", action="store_true")
    ap.add_argument("--include-code", action="store_true")
    ap.add_argument("--include-bare", action="store_true")
    ap.add_argument("--ignore", action="append", default=[])
    ap.add_argument("--registry")
    ap.add_argument("--json", action="store_true")
    ns = ap.parse_args(argv)
    if not ns.contract and not ns.audit_citations:
        ap.error("give --contract and/or --audit-citations")
    if ns.registry and not Path(ns.registry).exists():
        print(f"INCOMPLETE: registry not found at {ns.registry}. A check that cannot run is not a pass.")
        return 2
    names = index(ns.roots)
    out, rc = {"skills_indexed": len(names)}, 0
    if ns.contract:
        rows, missing = check_contract(ns.contract, names)
        out["contract"] = rows
        if missing:
            rc = 1
            out["missing_required"] = missing
    if ns.audit_citations:
        out["dangling_citations"] = audit_citations(names, ns.roots, ns.deep, ns.include_bare, tuple(ns.ignore),
                                                  alias_set(ns.registry), acknowledged_set(ns.registry), ns.include_code)
        if any(x["severity"] == "error" for x in out["dangling_citations"]):
            rc = 1
    if ns.json:
        print(json.dumps(out, indent=2))
    else:
        print(f"Indexed {len(names)} skills")
        for r in out.get("contract", []):
            tag = "OK     " if r["resolved"] else ("MISSING" if r["required"] else "absent ")
            print(f"  {tag} {r['name']:<50} {r['role']}")
        if "missing_required" in out:
            print("FAIL: required dependency missing:", out["missing_required"])
        if ns.audit_citations:
            print(f"Citation findings: {len(out['dangling_citations'])}")
            for d in out["dangling_citations"]:
                print(f"  [{d['severity']}:{d['kind']}] {d['in']} -> {d['cites']}")
    return rc


if __name__ == "__main__":
    try:
        sys.exit(main())
    except BrokenPipeError:  # output piped to head/less and closed early: not an error
        with contextlib.suppress(OSError):
            sys.stdout.close()
        sys.exit(141)
