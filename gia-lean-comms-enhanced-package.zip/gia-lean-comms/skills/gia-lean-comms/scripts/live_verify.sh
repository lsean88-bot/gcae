#!/usr/bin/env bash
# live_verify.sh: the checks that CANNOT run in a sandbox without the `claude` CLI.
# Run with: bash live_verify.sh [--skill-path DIR] [--evals FILE] [--runs N]
# Exit 0 = every live check ran and met its criterion; 1 = a criterion failed;
#      2 = INCOMPLETE (no `claude` CLI or no skill-creator runner): this is NOT a pass.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
SKILL="$HERE/.."; EVALS="$HERE/../../../evals/trigger_evals.json"; RUNS=3
RUNNER="${SKILL_CREATOR:-/mnt/skills/examples/skill-creator}"
while [ $# -gt 0 ]; do
  case "$1" in
    --skill-path) SKILL="${2:-}"; shift ;;
    --evals) EVALS="${2:-}"; shift ;;
    --runs) RUNS="${2:-3}"; shift ;;
    *) echo "unknown option: $1"; exit 64 ;;
  esac
  shift
done
if ! command -v claude >/dev/null 2>&1; then
  echo "INCOMPLETE: the 'claude' CLI is not installed here. Live trigger measurement was NOT run."
  echo "This is not a pass. See LIVE_VERIFICATION.md for the manual procedure."; exit 2
fi
if [ ! -f "$RUNNER/scripts/run_eval.py" ]; then
  echo "INCOMPLETE: skill-creator's run_eval.py not found at $RUNNER (set SKILL_CREATOR)."; exit 2
fi
OUT="$(mktemp)"; ERR="$(mktemp)"; trap 'rm -f "$OUT" "$ERR"' EXIT
( cd "$RUNNER" && python3 -m scripts.run_eval --eval-set "$EVALS" --skill-path "$SKILL" --runs-per-query "$RUNS" ) >"$OUT" 2>"$ERR"
RC=$?
cat "$OUT"; [ -s "$ERR" ] && { echo "--- runner stderr ---"; cat "$ERR"; }
[ $RC -ne 0 ] && { echo "INCOMPLETE: run_eval exited $RC; results above are not trustworthy."; exit 2; }
python3 - "$OUT" <<'PY'
import json, re, sys
t = open(sys.argv[1], encoding="utf-8").read()
m = re.search(r"\{.*\}", t, re.S)
try:
    d = json.loads(m.group(0))
except Exception:
    print("INCOMPLETE: could not parse run_eval output."); sys.exit(2)
res = d.get("results", [])
tp = sum(1 for r in res if r.get("should_trigger") and r.get("pass"))
pos = sum(1 for r in res if r.get("should_trigger")); neg = sum(1 for r in res if not r.get("should_trigger"))
tn = sum(1 for r in res if not r.get("should_trigger") and r.get("pass"))
print(f"\nshould-trigger passed: {tp}/{pos}   should-NOT-trigger passed: {tn}/{neg}")
ok = pos and neg and tp / pos >= 0.8 and tn / neg >= 0.9
print("LIVE TRIGGER CRITERION (>=80% recall, >=90% on negatives):", "MET" if ok else "NOT MET")
sys.exit(0 if ok else 1)
PY
