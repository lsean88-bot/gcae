#!/usr/bin/env python3
"""compress_gate: zone check on ORIGINAL, then meaning check ORIGINAL vs COPY.

Exit 0 only if both pass cleanly, OR the meaning check is REVIEW and `--signoff LOG` holds a
valid human approval for exactly these two file contents (see review_log.py). Exit 3 = REVIEW
with no valid sign-off. Exit 1 = meaning FAIL (never overridable). Exit 2 = protected zone.
Never writes or replaces any file.
"""
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).parent


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    signoff = None
    if "--signoff" in argv:
        i = argv.index("--signoff")
        signoff = argv[i + 1] if i + 1 < len(argv) else None
        del argv[i:i + 2]
    if len(argv) != 2 or ("--signoff" in sys.argv and signoff is None):
        print("usage: compress_gate.py ORIGINAL COMPRESSED_COPY [--signoff LOG]")
        return 64
    orig, comp = argv
    z = subprocess.run([sys.executable, str(HERE / "zone_guard.py"), "--path", orig],
                       capture_output=True, text=True)
    print(z.stdout.strip())
    if z.returncode != 0:
        print("GATE FAIL: zone is PROTECTED or ambiguous; do not compress")
        return 2
    m = subprocess.run([sys.executable, str(HERE / "meaning_guard.py"), orig, comp],
                       capture_output=True, text=True)
    print(m.stdout.strip())
    if m.returncode == 3:
        if signoff:
            v = subprocess.run([sys.executable, str(HERE / "review_log.py"), "verify", orig, comp, "--log", signoff],
                               capture_output=True, text=True)
            print(v.stdout.strip())
            if v.returncode == 0:
                print("GATE PASS: REVIEW outcome carries a recorded human approval (keep the original recoverable)")
                return 0
        print("GATE REVIEW: wording of negations/modals changed; a person must confirm before replacing")
        return 3
    if m.returncode != 0:
        print("GATE FAIL: meaning-critical tokens changed; keep the original")
        return 1
    print("GATE PASS: safe to replace (keep the original recoverable)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
