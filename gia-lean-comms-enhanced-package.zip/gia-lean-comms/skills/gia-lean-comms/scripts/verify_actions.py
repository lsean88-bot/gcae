#!/usr/bin/env python3
"""verify_actions: check every post-condition of ACTION_PLAN.md against a skills root.

Run it after you act (and on a rehearsal copy before you do). Each check prints PASS or FAIL.

  --roots R...        skills roots (default: /mnt/skills/user /mnt/skills/plugins)
  --registry FILE     your registry (default: state directory)
  --manifest FILE     MANIFEST.json written by retire_copy apply: also verifies the archive
  --expect-s1         also require the supplementary classification check in the v6 engine copies
  --claude-md FILE    also verify that the promoted lessons are present in your CLAUDE.md

Exit 0 only if every check passed, 1 if any failed, 2 if the registry is missing (INCOMPLETE).
"""
import argparse
import json
import sys
from pathlib import Path

import gate_audit
import gia_state
import interop_check
import registry_check as rc
import retire_copy
import validate_portfolio
import zone_guard

S1_MARK = "Supplementary check S1"


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--roots", nargs="+", default=rc.DEFAULT_ROOTS[:2])
    ap.add_argument("--registry")
    ap.add_argument("--manifest")
    ap.add_argument("--expect-s1", action="store_true")
    ap.add_argument("--claude-md")
    ns = ap.parse_args(argv)
    regp = gia_state.registry_path(ns.registry)
    if not regp.exists():
        print(f"INCOMPLETE: no registry at {regp}")
        return 2
    reg = json.loads(regp.read_text(encoding="utf-8"))
    results = []

    def check(label, ok, detail=""):
        results.append(ok)
        print(f"  {'PASS' if ok else 'FAIL'}  {label}" + (f"  [{detail}]" if detail and not ok else ""))

    # 1. registry
    errs = [f for f in rc.check(reg, ns.roots) if f["severity"] == "error"]
    check("registry: no undeclared collision or duplicate, no stale or missing declaration", not errs, str(errs[:2]))
    # 2. canonical copies unchanged
    bad = []
    for c in reg.get("collisions", []):
        p = rc.locate(c["canonical"], ns.roots)
        if p is None or rc.sha(p) != c["canonical"]["sha256"]:
            bad.append(c["base"])
    check("every declared canonical copy is present and unmodified", not bad, str(bad))
    # 3. duplicate pairs still in sync
    dd = []
    for d in reg.get("content_duplicates", []):
        pa, pb = rc.locate(d["a"], ns.roots), rc.locate(d["b"], ns.roots)
        if pa is None or pb is None or rc.similarity(pa, pb) < d.get("min_similarity", 0.9):
            dd.append(d["a"]["path"])
    check("every declared near-duplicate pair is present and still similar", not dd, str(dd))
    # 4. citations
    names = interop_check.index(ns.roots)
    cites = [f for f in interop_check.audit_citations(names, ns.roots, deep=True,
             ignore=("*/references/drift-check-*.md",), aliases=frozenset(interop_check.alias_set(regp)))
             if f["severity"] == "error"]
    check("no broken path or dangling skill citation (deep)", not cites, str(cites[:2]))
    # 5. validity
    invalid = []
    for r in ns.roots:
        for d in sorted(Path(r).glob("*/")):
            if (d / "SKILL.md").exists() and validate_portfolio.validate(d)["errors"]:
                invalid.append(d.name)
    check("every skill is valid for Claude Code", not invalid, str(invalid[:3]))
    # 6. gate coverage
    legacy = {s["skill"] for s in reg.get("superseded", [])}
    sk = gate_audit.per_skill(gate_audit.audit(ns.roots))
    gaps = {k: v["union_missing"] for k, v in sk.items() if v["union_missing"] and k.split("/", 1)[1] not in legacy}
    if ns.expect_s1:
        check("no live skill is missing a canonical quality-gate concept", not gaps, str(gaps))
        v6 = [p for r in ns.roots for p in (Path(r) / "cae-fieldwork-engine", Path(r) / "cae-cowork-ai-plugin") if (p / "SKILL.md").exists()]
        check("both v6 engine copies carry the supplementary check S1",
              len(v6) == 2 and all(S1_MARK in (p / "SKILL.md").read_text(encoding="utf-8") for p in v6), f"{len(v6)} copies found")
    else:
        print(f"  INFO  gate coverage gaps in live skills: {sorted(gaps)}")
    # 7. archive
    if ns.manifest:
        man = json.loads(Path(ns.manifest).read_text(encoding="utf-8"))
        absent = all(not Path(m["from"]).exists() for m in man["moved"])
        intact = all(Path(m["to"]).exists() and retire_copy.tree_hash(m["to"]) == m["tree_sha256"] for m in man["moved"])
        check("retired folders are gone from the skills roots", absent)
        check("retired folders are archived intact (whole-folder hash)", intact)
        retired_in_reg = [c["base"] for c in reg.get("collisions", []) for o in c["others"] if o["path"] in {m["registry_path"] for m in man["moved"]}]
        check("registry no longer lists the retired copies as collisions", not retired_in_reg, str(retired_in_reg))
    # 8. leftovers and policy
    left = [str(p) for r in ns.roots for p in Path(r).rglob("*.orig")]
    check("no .orig backup files left in the skills roots", not left, str(left[:2]))
    check("CLAUDE.md remains PROTECTED (never compressed)", zone_guard.classify(path="CLAUDE.md")[0] == "PROTECTED")
    if ns.claude_md:
        text = Path(ns.claude_md).read_text(encoding="utf-8")
        check("CLAUDE.md contains the promoted lessons", "skipped check is not a pass" in text.lower())
    n_fail = results.count(False)
    print(f"\n{len(results) - n_fail}/{len(results)} checks passed")
    return 1 if n_fail else 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except BrokenPipeError:
        sys.exit(141)
