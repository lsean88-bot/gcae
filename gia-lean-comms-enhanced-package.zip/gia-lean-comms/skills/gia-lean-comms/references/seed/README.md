# Seed files: fixtures, not defaults

`portfolio-registry.seed.json` and `baseline.seed.txt` were written against ONE installation (a sandbox
with 146 skills). They are used by the test suite and the UAT as worked examples, and as a template for
the format. **They are never used implicitly.** On a new installation run:

    bash skills/gia-lean-comms/scripts/portfolio_gates.sh --bootstrap          # dry run: shows what would be accepted
    bash skills/gia-lean-comms/scripts/portfolio_gates.sh --bootstrap --yes    # writes YOUR registry and baseline

Your files go in the state directory (`~/.gia-lean-comms` by default, or `$GIA_STATE_DIR`), which survives
plugin updates. Run `python3 skills/gia-lean-comms/scripts/gia_state.py` to see the resolved paths.
