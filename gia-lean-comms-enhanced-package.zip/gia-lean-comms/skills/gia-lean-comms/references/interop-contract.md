# Interop contract: gia-lean-comms

Machine-checked by `scripts/interop_check.py --contract references/interop.json`.
Required dependencies must resolve or the check exits 1. Optional ones report `absent`.

## Hand-offs

| When | This skill does | Other skill owns |
|---|---|---|
| Any deliverable in Zone P | Switches lean off; no lean style in the document | `group-cae-reporting` / `group-cae-external-reporting` own the QA gate; `iron-rules-governance` Rule 29 owns "no process commentary" |
| User corrects lean behaviour, or a compression mistake recurs | Logs it via `self-learning-loop` | AKOS Module 7 owns promotion; a portfolio-wide rule is *proposed* to `iron-rules-governance` and needs explicit go-ahead |
| Request could match several persona skills | Does not route | `mktron-sentinel:skill-registry-navigator` |
| Multi-workstream job with subagents | Lean state is **not** inherited by any subagent's deliverable | `mktron-sentinel:orchestration-protocol` |
| Editing this skill | Follows build path | `skill-factory` → `skill-sprawl-watch` → `independent-critique` |
| Coding, debugging, UAT runs | Lean allowed (Zone L) | `charlie-hills-code`, `debugger` own the workflow |

## Invariants other skills can rely on

1. Lean mode never starts without an explicit request.
2. Zone classification fails closed.
3. No file is replaced by this skill's scripts; they only report pass/fail.
4. This skill defines no Iron Rule, evidence grade, report structure or Kaizen mechanism.

## Portfolio issue register (final state, v1.3)

Point-in-time for one mount: re-run `portfolio_gates.sh` before relying on it. Applied fixes are in
`portfolio-patches/` (10 patches). Owner-decision changes are in `decision-patches/` (2 patches,
**not applied**). Both use `bash portfolio-patches/apply_patches.sh [ROOT] [--check|--revert] [--dir DIR]`.

### Resolved and verified
| ID | Issue | Resolution |
|---|---|---|
| P1 | `skill-factory` cited a non-existent preflight path | Patched |
| P2 | Overlap check silently skipped by default; a skip read as a pass | Patched: auto-detect, explicit path authoritative, skip = exit 2 |
| P3 | Prefixed `independent-critique` citation | Declared an alias in the registry |
| P4 | `funding-digest` cited a missing `pptxgenjs.md` | Patched |
| P5 | Drift check scanned 3 of 146 skills; scheduled-task doc used the same wrong path | Patched |
| P6 | Four path-bearing citations named the stale `self-learning-loop` copy, which lacks those paths | Repointed to the canonical copy |
| G1, G1b | Drift Check 4 vs `charlie-hills-code`; two self-update descriptions | Additive Phase 1-5 mapping and a scope sentence; Check 4 now clean |
| G2 | Register named a folder that does not exist | Corrected after verification; the raw 27 Sept log left untouched as evidence |
| G3 | Same-name skill pairs | 5 pairs declared, hash-anchored and enforced |
| G3b | **Near-identical skills under different names** (invisible to a name-based check; includes the v6 engine installed twice) | 5 pairs found (similarity 0.92-0.98), declared, and enforced: an undeclared new pair or a pair drifting below 0.9 now fails |
| G4 | Cited-but-uninstalled and illustrative names | Acknowledged; bare-name heuristic reports 0 |
| V1 | 52 of 146 skills "invalid" | A target mismatch: 146/146 valid for Claude Code, 94 upload-ready, 52 blocked from claude.ai upload |
| L1 | Launcher / master name collision | **Accepted, no rename**: different documents; plugin skills are namespaced; trigger overlap is low |
| S1 | Superseded skills still installed | Declared (v4, v5 by their own v6 metadata; v3 inferred); reported as info and as LEGACY, never as gaps |

### Corrected claim (stated so it cannot return)
My first gate finding said three skills could reach FINAL without CD/SD/MW classification **or**
aggregation. That was wrong: it read each gate in isolation. The v6 skills run two gates (ten-item
fieldwork; 30-item conversion QA whose item 28 checks an aggregation summary is present).
Measured per skill, the current engine lacks **only CD/SD/MW classification as a gate item**.

### Open: needs the owner
| ID | Item | Prepared |
|---|---|---|
| Q1 | CD/SD/MW classification is not a gate item in `user/cae-fieldwork-engine` or its duplicate `cae-cowork-ai-plugin` | `decision-patches/` adds one supplementary check S1 to both, with no claim about tool behaviour. Validated on temp copies: gap closed, gate counts intact, no new drift line, copies stay in sync, revert exact. A change to `generateReport()` is not visible from the skill folders |
| Q2 | 43 known drift lines (unnamespaced rule lists, R1-R5 tables, gate-count mentions) | Recorded in the baseline (your state directory; the sandbox's is `references/seed/baseline.seed.txt`) so a schedule alerts on change only |
| O1 | Retire or merge stale copies: prefixed `self-learning-loop` (never keep two lesson stores), bare `pune-india-ops-audit` v1.0, AKOS plugin copy (22 of 24 only-here lines are older wording or have equivalents; 2 are content: a Kaizen pipeline line, and a routing row naming a twenty-seven-item gate that governance deliberately reconciled away, so do **not** merge that one) | Registry owner actions |
| O2 | Keep or retire each near-duplicate pair | The registry now fails on drift, so keeping both is safe |
| O3 | Promote the logged lessons | Done as a rehearsal: `templates/promote_claude_md.sh` merges the 7 promoted rules; 11 are logged, the rest stay proposals |
