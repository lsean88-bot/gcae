---
name: gia-lean-comms
description: >
  Bounded brevity layer and portfolio hygiene tools for GIA work. Lean, low-token working
  chatter (tool narration, progress, debug and UAT output) with hard protection for audit
  deliverables and governance files, which never get compressed. Guards: zone_guard (protected
  or lean), meaning_guard (did a compression change a negation, number, rank or rule
  reference), review_log (record who reviewed and approved a compressed file). Portfolio
  gates: broken or dangling cross-references between skills, skills that share a name,
  validate skills for Claude Code versus claude.ai upload, quality-gate gap audit, governance
  drift. Explicit activation only. Trigger on: lean mode, terse mode, token economy, compress
  CLAUDE.md or a memory file safely, is it safe to compress, caveman safe, approve a
  compressed file, broken cross-references between skills, skills share a name, portfolio
  gates, skill drift, validate skills.
---

# GIA Lean Comms

A narrow layer, not a new engine. It exists because brevity tools built for coding
sessions (e.g. caveman) are unsafe against audit content: UAT showed the caveman
compress validator reports `is_valid: True` on a rewrite that flips "never cited" to
"cited when corroborated", changes R4→R3, and makes the management response optional.
It checks structure, not meaning. This skill adds the missing guards and the boundaries.

## What it does NOT do (deliberately)

- Define Iron Rules, evidence grades or the Quality Gate → `iron-rules-governance` owns these.
- Run self-learning/Kaizen → AKOS Module 7 (`akos-enterprise-orchestrator`) owns it.
- Route or orchestrate other skills → `mktron-sentinel:skill-registry-navigator`,
  `mktron-sentinel:orchestration-protocol`.
- Replace the 13-section report structure or any reporting skill's own QA gate.

Token economy is a communication preference, not an audit control (the portfolio
already decided this when it declined to make it an Iron Rule). Treat it that way.

## Activation: explicit only

Lean mode starts only on an explicit request ("lean mode on", `/caveman lite`). Never
infer it from "be brief" or "shorter". Default level when on: **lite** (no filler, full
sentences kept). `full`/`ultra` are for pure engineering/UAT chatter only.

**What `defaultMode: "off"` does and does not cover (verified 2026-10-02, caveman v2.3.1).**
`templates/caveman.json` sets caveman's *hook* default to off: the hooks then ignore natural
language such as "talk like caveman" or "less tokens" (confirmed by running the hook), and only
an explicit `/caveman <level>` activates. It does **not** govern caveman's *skill description*,
which itself says it auto-triggers on "be brief" and "less tokens". Whether Claude loads that
skill on such a phrase was not tested here. In GIA workspaces either do not install the
caveman skill, or treat Zone P below as binding even when it loads. Never rely on the hook
setting alone.

## Zones

Run `scripts/zone_guard.py` when unsure. It fails closed: ambiguous means PROTECTED. Only code
and run logs (`.py .js .sh .log`) are lean by extension. Data and text files (`.csv .json .yaml .txt`)
are where audit evidence lives, so they stay PROTECTED unless you state a working-chatter purpose.
Protected names are recognised in English, Chinese, Spanish and Malay. (An earlier version
failed open on 15 of 28 audit-related filenames; that is fixed and regression-tested.)

| Zone | Content | Lean allowed? |
|---|---|---|
| **P (protected)** | Findings, 5C drafts, IARs, Board/AC/Chairman papers, regulator/external-auditor/lender submissions, management responses and action plans, anything graded R1–R5, any rate/section/threshold/Act citation, fraud, whistleblower, legal, disciplinary, SMART recommendations, humanised leadership reports, memory/CLAUDE.md, SKILL.md, governance files | **No. Full prose, normal structure.** |
| **L (lean)** | Tool-call narration, progress/status lines, debug and UAT output, explaining scripts, file operations, query chatter, clarifying questions | Yes |
| **S (suspend)** | Security warnings, irreversible actions, ordering-sensitive multi-step instructions, user confusion or repeated question | Drop lean for that passage, resume after |

A lean session that then drafts a Zone P deliverable writes the deliverable in normal
professional prose. The final document never carries lean style or process commentary
(Iron Rule 29).

## Meaning-critical tokens (never dropped, never added)

`meaning_guard.py` compares what a rewrite keeps. **FAIL** (a token with no legitimate synonym
changed): numbers, including amounts glued to a currency code (`USD100`, `RM5`); currency and
magnitude (lakh, crore, million); identifiers (`TP05`, `E12`, `Q3`, `Form16A`); versions
(`v2.1`); clause references (`7(b)`); calendar months; R1-R5; rule references; CD/SD/MW; risk
colours; section and Act references; or any net loss of negations. **REVIEW** (a person reads
it): reworded negations, modals (must to may), direction and status words (before/after,
valid/invalid, passed/failed, half/quarter), CJK numerals, and a changed ORDER of otherwise
identical tokens (this is what catches `03/10/2026` vs `10/03/2026`).

Handled as equal, so they do not raise false alarms: `5 percent` and `5%`; `1,700`, `1700` and
`1,700.00`; `RM 1,700` and `RM1,700`; `Rule 9` and `Rule 09`; `R5` and `R 5`; `twenty-five` and
`25`; full-width digits; extra whitespace. Languages: English, Malay, Spanish, Chinese.

Measured limits (a lexical trip-wire, not proof). It is **blind** to who-did-what-to-whom
(`CFO approves CEO's` vs `CEO approves CFO's`), entity names (`MKPC` vs `MKAPL`), the order of
ordinary verbs (`approve then post` vs `post then approve`), unlisted antonyms, and Tamil and
Hindi. On a 20-case red-team list it lets 5 pass silently (the old engine let 15), and flags 0 of 17
faithful rewrites (the old engine flagged 9). These are pinned by tests so the documentation cannot go stale.
Keep it on Zone L content and read every REVIEW.

## Compressing a file safely (the only supported path)

Never run `caveman-compress` in place on audit or governance content. If a file is
Zone L and compression is genuinely wanted:

1. `python3 scripts/zone_guard.py --path FILE`: must print `LEAN`.
2. Compress a **copy**, not the original.
3. `python3 scripts/meaning_guard.py ORIGINAL COPY --show-lines`: exit 0 to proceed. Exit 3 (REVIEW): show a person the listed lines first. Exit 1 (FAIL): do not replace the original.
4. Only then replace. Keep the original recoverable.

`scripts/compress_gate.py ORIGINAL COPY [--signoff LOG]` runs steps 1 and 3 together. A REVIEW
outcome passes only when `LOG` holds a recorded human approval for exactly those two file
contents (`scripts/review_log.py record|verify|audit`). Approvals are hash-chained and void if
either file changes; a FAIL can never be signed off. **Claude must never record an approval
itself**: the reviewer is the person, and an automated-looking name is refused. A sign-off is a
record of who decided and when, not authentication. Writes are serialised by a file lock (an
unlocked version forked the chain under contention and made every later approval unverifiable).
CLAUDE.md, memory files and SKILL.md are Zone P: never compress them.

## Interop contract

Dependencies and hand-offs are machine-checked: `python3 scripts/interop_check.py --contract
references/interop.json`. Names resolve with or without the `mktron-sentinel:` prefix. See
`references/interop-contract.md` for the hand-off table and the issue register.

## Portfolio tools (all report-only; none edit a skill)

| Script | Answers |
|---|---|
| `portfolio_gates.sh` | One run of every gate below plus the governance drift check. Exit 0 nothing new, 1 new finding, 2 a gate could not run. Compares against a dated baseline so a schedule alerts on change; known findings are still counted every run |
| `interop_check.py --audit-citations --deep --ignore GLOB --registry FILE` | Broken `/mnt/skills` paths and dangling names. `--include-bare` adds a heuristic (info only) |
| `registry_check.py` | Near-identical skills under **different** names (similarity 0.9+), which the same-name check cannot see; skills the registry declares superseded but still installed. Also: same-name skills with different content that the registry does not declare; declarations made against content that has since changed; skills citing a stale copy. `--init` drafts entries |
| `validate_portfolio.py` | Valid for Claude Code, and separately upload-ready for claude.ai. The strict upload rule alone wrongly flags Claude Code-only keys |
| `gate_audit.py --registry FILE` | Every written quality gate (including grouped 30-item checklists), and per SKILL across all its gates which canonical concepts are still missing. Superseded skills report as LEGACY, not as gaps |
| `trigger_proxy.py --evals evals/trigger_evals.json` | Lexical vocabulary check of this description. Not a trigger measurement |
| `retire_copy.py plan\|apply\|rollback` | Retires a declared **stale** skill copy safely: hash pre-checks, blocks on path-bearing references and unreviewed merge, moves (never deletes) to an archive with a whole-folder-hash manifest, rolls back byte-exact. Plan only unless `--yes` |
| `verify_actions.py` | Every post-condition of the action plan against any skills root; exit 0 only if all pass |
| `live_verify.sh` | The checks a sandbox cannot run: real trigger measurement through skill-creator's runner. Exit 2 (INCOMPLETE) without the `claude` CLI; never a pass by default |
| `registry_check.py --refresh [--yes]` | After you review and approve a change to a registered skill, re-anchors the registry to its new content. Dry run unless `--yes`; keeps a `.bak` |

## State: kept apart from the plugin's code

The registry (which copy of a same-name or near-identical skill is canonical, which are superseded) and
the findings baseline are **site state**. They live in a state directory (`~/.gia-lean-comms`, or
`$GIA_STATE_DIR`), because the plugin folder is replaced on every update. The files under
`references/seed/` describe the one sandbox this package was verified in; they are fixtures and are
never used implicitly. A missing state file is INCOMPLETE (exit 2), never silently the seed.

First run on a new installation: `bash scripts/portfolio_gates.sh --bootstrap` (dry run: lists what
would be accepted), review it, then `--bootstrap --yes`. That records today's state as **unreviewed**
and alerts on any change; it does not decide which copy is canonical. `python3 scripts/gia_state.py`
shows the resolved paths. Retiring a stale copy is the owner's packaging decision; these tools never do it.

Applied portfolio fixes are in `portfolio-patches/`. Changes that need an owner's decision are in
`decision-patches/` and are **never applied by default**; both use `apply_patches.sh [ROOT]
[--check|--revert] [--dir PATCH_DIR]`. To run on a schedule, paste
`templates/scheduled-task-portfolio-gates.md` into Cowork.

Standing principle, learned in UAT: **a skipped check is not a pass.** Preflight, the drift
check, the gates runner and every checker here exit 2 (INCOMPLETE) when a check could not run.

## Build and change path for this skill

Per portfolio practice: `skill-factory` preflight → `skill-sprawl-watch` target scan →
`independent-critique` pass → log recurring mistakes via `self-learning-loop`. A proposed
new portfolio-wide rule from this work is *proposed* to `iron-rules-governance`, with an
explicit go-ahead required, never written as a standing rule from here.
