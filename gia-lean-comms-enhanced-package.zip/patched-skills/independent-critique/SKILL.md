---
name: independent-critique
description: >
  Runs a genuinely separate, adversarial QA pass over a finished artifact — a newly built or
  edited GIA skill, or an audit deliverable such as a report, RACM, or findings register —
  modelled on the segregation-of-duties discipline this practice already applies to audit
  conclusions (the preparer and the reviewer are never the same unreviewed step). Use this
  whenever mktron-sentinel:skill-factory hands off a draft skill, whenever asked to review,
  critique, QA, or sanity-check a completed skill or audit deliverable before it ships, or
  whenever asked for an independent or adversarial second opinion rather than a summary of
  what was just built. Trigger on: critique this, QA this, review this before I send it,
  independent review, second opinion, sanity-check, is this actually good, find problems with
  this, adversarial review, before finalizing.
---

# Independent Critique

The single rule this skill exists to enforce: **the same pass that built something does
not get to grade it as finished.** `kaizen-critique.md` already demonstrated what this
looks like in practice — it found four real, specific, evidence-cited defects in this
library's own recent work (a length-limit violation reintroduced after a fix, a capability
documented in a skill's body but missing from its description, an ambiguous trigger
overlap, a stale cross-reference) rather than producing a summary that agreed with itself.
This skill turns that one-off practice into a repeatable one.

## What "independent" means here, concretely

This sandbox cannot literally spawn a separate subagent process for this (no Task tool,
no `claude -p` CLI). Independence here means a **discipline**, not a different process:

1. **Re-read the artifact fresh.** Don't rely on your own summary of what you just built —
   open the actual file(s) again as if you were seeing them for the first time.
2. **Start from the empirical output, not your intent.** Run
   `scripts/run_critique.py` first and treat its structural/overlap findings as ground
   truth before reasoning about anything else — don't reason your way around a FAIL.
3. **Cite evidence for every finding**, the way `kaizen-critique.md`'s four findings each
   name the specific file, line, and query that exposes the problem. A critique finding
   without a citation is an opinion, not a finding.
4. **Never soften a finding to avoid friction with your own prior work.** If the honest
   read is "Fail" or "Pass with fixes," say that — the same standard this library expects
   management to meet when responding to an audit finding applies to the audit function's
   own tooling.
5. **State what you didn't check.** Every critique names at least one thing it couldn't
   verify (per `run_critique.py`'s own output: the real trigger-eval loop needs Claude
   Code and didn't run here). A critique that claims total coverage is itself a finding.

## Two modes

### Mode A — Critiquing a skill (the skill-factory hand-off case)
```bash
python3 scripts/run_critique.py --skill /path/to/skill --out /path/to/report.md
```
This runs the real preflight checks and writes a report skeleton with the empirical
sections filled in and the reasoning sections explicitly marked `FILL IN`. Completing
those sections — actually reasoning about trigger ambiguity, redundancy judgement calls,
and coverage gaps — is not optional and is not something the script does for you. See
`references/skill-critique-standard.md` for the full standard, with kaizen-critique.md's
four real findings as worked examples of what a completed finding looks like.

### Mode B — Critiquing an audit deliverable (report, RACM, findings register)
There is no script for this mode — the artifact being reviewed is prose/spreadsheet
content, not a structured skill file, so the check is inherently a reasoning task. Apply
the same five-point discipline above, using the RBIA methodology's own severity vocabulary
(`mktron-grc-function/references/rbia-methodology.md` §10 and §12) so a critique finding is
classified with the same rigour as an audit finding would be — a critique that says
"reporting could be tighter" is not actionable; a critique that says "Finding F-2026-07's
Effect is stated as a range but the workpaper only supports the lower bound, which is a
Condition/Effect mismatch, not a materiality judgement call" is. See
`references/deliverable-critique-standard.md`.

## What happens to what this finds

- **Structural/empirical failures** — fix and re-run preflight (see `skill-factory`).
- **A finding that represents a generalizable mistake** (not a one-off typo) — log it via
  `self-learning-loop`'s `scripts/log_lesson.py` so the next build checks
  for it before it happens again, not after.
- **A genuine portfolio duplicate or unresolved supersession claim** — flag it to the
  person for a decision. This skill's job is to surface it clearly, cited, with the actual
  evidence — not to resolve it unilaterally.

## Reference

- `references/skill-critique-standard.md` — the standard for Mode A, with worked examples
- `references/deliverable-critique-standard.md` — the standard for Mode B
- `/mnt/skills/examples/skill-creator/agents/grader.md` — the closest analogue this library
  already has for what a rigorous, non-self-serving grading pass looks like; read it for the
  grading mentality even though its actual CLI dispatch mechanism can't run here
