# Deliverable Critique Standard (Mode B)

For critiquing an audit report, RACM, risk register, or findings register before it goes
out — not a skill file. There is no automatable structural check for this mode (the
artifact is prose/spreadsheet content, not a validated schema), so the discipline is
entirely in how the finding is stated. Use the same vocabulary the deliverable itself is
supposed to use, so a critique finding is exactly as defensible as an audit finding.

## Reuse the RBIA methodology's own classification, don't invent a parallel one

See `mktron-grc-function/references/rbia-methodology.md` §10 (deficiency classification)
and §12 (the five-component finding structure). A critique of an audit report should be
*written like* an audit finding:

| Component | Applied to a critique of a deliverable |
|---|---|
| Condition | What the deliverable actually says/shows — quote or cite the specific section |
| Criteria | What it should say per the methodology, the report structure standard, or internal consistency with the deliverable's own evidence |
| Cause | Why the gap likely happened (rushed synthesis, evidence not re-checked after a later edit, severity applied inconsistently across similar findings) |
| Effect | What happens if this ships as-is — a specific, not generic, consequence (e.g. "the AC will read this Effect statement as covering the full population when the workpaper only supports the sampled subset") |
| Recommendation | The specific edit, not "tighten the language" |

## Concrete examples of the difference

**Not a finding:** "The reporting section could be more polished."

**A finding:** "Finding F-2026-07's Effect statement quantifies exposure at the full
population's transaction value, but §11.2's workpaper reference shows the sample was 25
of 340 transactions with 1 exception — the Effect as written implies a tested conclusion
about the whole population, which is a Condition/Effect mismatch, not a materiality
judgement call. Either extend testing to support the population-wide figure or restate
Effect as bounded to the tested sample with an extrapolation caveat."

**Not a finding:** "Severity ratings seem a bit inconsistent."

**A finding:** "Findings F-03 and F-11 describe functionally identical control gaps (no
segregation of duties between vendor-master maintenance and payment approval, in two
different entities) but are rated Medium and High respectively, with no stated basis for
the difference — per §12.2, severity should be applied consistently across similar
findings; either the difference is justified by a fact not stated in either finding
(state it) or one of the two ratings needs to change."

## What this mode does NOT do

- Does not re-perform the underlying audit testing — it critiques whether the *reporting*
  of the testing is internally consistent and evidence-supported, not whether the sample
  size or testing approach itself was adequate (that's a methodology question for
  `super-grc-audit-plugin-l99`'s own QA gate, not this skill).
- Does not change severity ratings, findings, or conclusions unilaterally — per this
  library's segregation-of-duties principle (never touch a conclusion cell without
  confirmation), a Mode B critique proposes a change and states why; the person or the
  original preparer applies it.
