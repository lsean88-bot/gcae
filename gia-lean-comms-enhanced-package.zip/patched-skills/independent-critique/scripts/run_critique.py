#!/usr/bin/env python3
"""
run_critique.py — runs the empirical checks a skill critique needs, and emits a markdown
report SKELETON with the reasoning sections explicitly marked as not-yet-filled.

This script does NOT produce a finished critique on its own. It deliberately stops short
of the reasoning work (trigger-ambiguity analysis, redundancy judgement calls, "is this
actually a problem") — that part requires reading the artifact and thinking about it, the
same way kaizen-critique.md's own findings 1-4 were reasoned, not computed. A critique
report that only contains this script's output has not been critiqued; it has only been
scanned.

Usage:
    python3 run_critique.py --skill /path/to/skill --out /path/to/report.md
"""
import argparse
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
def find_preflight_script():
    """Search plausible locations for skill-factory's run_preflight.py, rather than
    assuming one hardcoded sibling path. Found via isolation testing 2026-08-09: the
    original single hardcoded path assumed all mktron-sentinel skills stay co-located
    under one shared plugin tree -- true in this sandbox, not guaranteed once skills are
    uploaded independently to claude.ai (no plugin bundling there) or installed
    separately in Claude Code. Returns the first path that exists, or None."""
    candidates = [
        HERE.parent.parent / "mktron-sentinel:skill-factory" / "scripts" / "run_preflight.py",
        HERE.parent.parent / "skill-factory" / "scripts" / "run_preflight.py",
        Path.home() / ".claude" / "skills" / "skill-factory" / "scripts" / "run_preflight.py",
        Path.home() / ".claude" / "skills" / "mktron-sentinel:skill-factory" / "scripts" / "run_preflight.py",
    ]
    for c in candidates:
        if c.exists():
            return c
    return None


FACTORY_PREFLIGHT = find_preflight_script()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--skill", required=True)
    parser.add_argument("--out", required=True, help="Path to write the report skeleton")
    parser.add_argument("--creator-path", default="/mnt/skills/examples/skill-creator")
    parser.add_argument("--roots", nargs="+", default=["/mnt/skills/user", "/mnt/skills/plugins"])
    args = parser.parse_args()

    skill_path = Path(args.skill).resolve()

    if FACTORY_PREFLIGHT is None:
        # Degrade, don't crash: skill-factory's preflight script isn't reachable from
        # here (e.g. this skill was uploaded to claude.ai independently, with no
        # guaranteed co-location). Produce a report that says so honestly and continues
        # with reasoning-only sections, rather than producing nothing at all.
        preflight = {
            "checks": {
                "structural_validity": {"pass": None, "message": "SKIPPED -- skill-factory's run_preflight.py not found at any known location. Install skill-factory alongside this skill, or run quick_validate.py directly, for the structural check."},
                "portfolio_overlap": {"pass": None, "message": "SKIPPED -- same reason", "flags": []},
            }
        }
    else:
        result = subprocess.run(
            ["python3", str(FACTORY_PREFLIGHT), "--skill", str(skill_path),
             "--creator-path", args.creator_path, "--roots", *args.roots],
            capture_output=True, text=True,
        )
        try:
            preflight = json.loads(result.stdout)
        except json.JSONDecodeError:
            preflight = {"error": "could not parse preflight output", "raw": result.stdout, "stderr": result.stderr}

    structural = preflight.get("checks", {}).get("structural_validity", {})
    overlap = preflight.get("checks", {}).get("portfolio_overlap", {})
    flags = overlap.get("flags", [])

    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    lines = []
    lines.append(f"# Independent Critique — {skill_path.name}")
    lines.append(f"\n**Date:** {ts}  \n**Subject:** `{skill_path}`  \n**Method:** empirical checks (this script) + reasoned pass (fill in below)\n")
    lines.append("## What could and couldn't actually run\n")
    lines.append("Empirical (`quick_validate.py` + `scan_overlap.py`, real output, ran against this skill):\n")
    lines.append(f"- Structural validity: **{'PASS' if structural.get('pass') else 'FAIL' if structural.get('pass') is False else 'SKIPPED'}** — {structural.get('message', 'n/a')}")
    lines.append(f"- Portfolio overlap ({len(flags)} flag(s) at default threshold): {overlap.get('message', 'n/a')}")
    if preflight.get("overall_complete") is False:
        lines.append("- **INCOMPLETE:** " + ", ".join(preflight.get("skipped_checks", [])) +
                     " did not run. A skipped check is not a pass; resolve before relying on this critique.")
    if flags:
        for f in flags:
            lines.append(f"  - `{f['skill_a']}` <-> `{f['skill_b']}` (score {f['score']}) — shared: {', '.join(f['shared_terms'])}")
    lines.append(
        "\nNot able to run in this environment: `run_eval.py`/`run_loop.py` (the real "
        "trigger-eval loop, requires the `claude` CLI) and subagent-dispatched "
        "`grader`/`comparator`/`analyzer` prompts. Manual trigger-reasoning below is a "
        "substitute for the reasoning, not a substitute for the empirical measurement — "
        "flag it as such, don't present it as equivalent.\n"
    )
    lines.append("## Structural findings (empirical)\n")
    lines.append("_(from the run above — no further action needed unless FAIL)_\n")
    lines.append("## Trigger-reasoning findings — FILL IN\n")
    lines.append(
        "For each plausible query that should or shouldn't trigger this skill, reason "
        "through whether the frontmatter `description` (not the body — the body isn't "
        "consulted before the skill is chosen) actually contains the matching vocabulary. "
        "Cite the specific query and the specific gap, the way kaizen-critique.md's "
        "Findings 1-4 do. Do not simply restate the empirical section above.\n"
    )
    lines.append("- [ ] Finding 1 — \n")
    lines.append("## Redundancy / consistency findings — FILL IN\n")
    lines.append(
        "If any overlap flag above is real (not just shared boilerplate vocabulary), state "
        "explicitly whether it's a documented, intentional relationship (supersession, "
        "narrower-scope variant) or an unresolved duplicate. Do not resolve it yourself — "
        "flag it for the person's decision, per skill-sprawl-watch's own rule.\n"
    )
    lines.append("## What I'd flag if I were grading this the way grader.md asks a grader to — FILL IN\n")
    lines.append(
        "State plainly what in this critique is measured vs reasoned, and name at least one "
        "coverage gap this critique itself did not check.\n"
    )
    lines.append("## Recommendation — FILL IN\n")
    lines.append("Pass / Pass with fixes / Fail — and why, in one sentence.\n")
    lines.append(f"\n---\n*Generated by independent-critique/scripts/run_critique.py on {ts}. "
                  f"Empirical sections above are real tool output; all FILL IN sections must be "
                  f"completed by an independent reasoning pass before this is a finished critique.*")

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"Report skeleton written to {out_path}")
    print(f"Structural: {'PASS' if structural.get('pass') else 'FAIL'} | Overlap flags: {len(flags)}")


if __name__ == "__main__":
    main()
