# The Charlie Hills Protocol

Cited by name as a standing requirement across `racm-ecosystem`, `cae-audit-cowork-plugin`,
`cae-audit-cowork-plugin-v4`, `cae-cowork-ai-plugin`, `cae-cowork-plugin-v5`,
`cae-report-conversion`, `cae-command-centre`, `debugger`, `group-cae-fraud-v2`,
`mac-audit-constitution-l99`, and `super-grc-audit-plugin-l99`.

## Why this reference exists

Before 27 July 2026, the skill that owned the name (`charlie-hills-code`) didn't define
the 5-phase cycle those 11 skills all assumed it meant — it defined a different, unrelated
6-step structure. This file is the condensed version for anyone who needs the cycle without
pulling in the full coding-focused skill.

**Correction, 27 September 2026:** the line above used to end "`charlie-hills-code` was
rewritten to actually match." Re-checked against the live file this session (Rule 27 — don't
carry forward a prior claim without re-verifying it) and that isn't true: `charlie-hills-code`
still defines its own 6-item "Workflow Orchestration" list and a separate 6-step "Task
Management Protocol," not the bare Plan/Verify/Execute/Check/Log structure below. Whether
commit `509900c` was reverted, never actually applied, or the claim was wrong from the start
wasn't established this session. Treat this file's 5-phase summary as this skill's own
canonical framing, not as a confirmed restatement of what `charlie-hills-code` currently
says — see the Open Findings Register in the main `SKILL.md` for the recommended resolution.

## The 5 phases

**PLAN** — Enter plan mode for anything non-trivial (3+ steps or an architectural
decision). Write the plan down before acting. If something goes sideways mid-task, stop
and re-plan immediately rather than pushing through.

**VERIFY** — Confirm the plan itself with whoever needs to sign off — not just that a plan
exists. Before committing to an approach, ask whether there's a more elegant way. Do this
before executing, not just before presenting.

**EXECUTE** — Do the work. Offload research and parallel exploration where possible to
keep focus on the core task. Track progress as items complete, not only at the end.
Simplicity first: touch the minimum necessary, find root causes rather than patching
symptoms, avoid introducing side effects.

**CHECK** — Never mark something complete without proving it works: run the test, check
the log, demonstrate the behaviour. Ask honestly whether this would pass a senior
reviewer's approval — not rhetorically.

**LOG** — Document what was actually done, not just that it's done. If a correction came
in during the work, record the lesson so the same mistake isn't repeated. If a pattern
recurred, update whatever standing instructions apply so it's caught automatically next
time.

## Known limitation

As of 28 July 2026, no artifact produced by following this cycle (a task log, a lessons
file, a standing-instructions update) has been found anywhere in the environment this
reconciliation was performed in. This reference describes what the protocol says, not
evidence that it has been run end-to-end and proven in practice.

**27 September 2026 addendum:** the destination for a Log-phase artifact is now specified
concretely — see "Self-Learning Loop" in the main `SKILL.md`, which routes a lesson to
either an engagement's own `LESSONS_LEARNED.md` (via AKOS Module 7) or to this file's Rule
list directly, depending on scope. Rules 27–29 there are the first rules to have actually
travelled that path. That closes the "where would it go" gap this note originally flagged —
it does not yet establish that the Log phase is being run reliably every time it should be;
that still needs to be observed over more sessions before it's fair to call it proven.
