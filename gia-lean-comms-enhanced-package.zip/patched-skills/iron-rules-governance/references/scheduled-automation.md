# Scheduled Automation — Governance Drift Check

**What this is:** a ready-to-paste Claude Cowork scheduled-task configuration. I can't
register a live recurring schedule from this chat surface — Cowork's scheduling is set up
in its own UI — so this is the exact configuration to paste in there, not a claim that
it's already running.

**Correction added 9 August 2026 — read before using the config below.** This doc
originally assumed a Cowork scheduled task would see the same `/mnt/skills/user`
filesystem this conversation used. That's not confirmed, and there's a specific reason to
doubt it by default: Cowork and cloud sessions load skills from the skills enabled on your
claude.ai account (managed via Customize in the Desktop app or claude.ai's skill
settings), not from a machine-local path the way Claude Code's CLI does — and a cloud
session's *additional* project-level access comes from a cloned repository's own
`.claude/skills/`, not from an arbitrary `/mnt/...` path. I don't have direct confirmation
of what filesystem a Cowork scheduled task's bash environment actually has mounted. Before
relying on the weekly schedule below, run it manually once and confirm the script path
resolves — if it doesn't, the two likely fixes are (a) enabling `iron-rules-governance` as
an account-level skill so Cowork loads it and can locate its own `scripts/` folder, or (b)
pointing the task at a copy of the script committed to whichever repository your Cowork
session actually has checked out. Don't assume either fix without testing — that's exactly
the kind of unverified claim this whole reconciliation has been correcting.

## Recommended cadence

**Weekly**, not daily. The drift found this session accumulated over roughly two weeks of
active skill development across multiple sessions — weekly is frequent enough to catch it
before a third or fourth "independent QA pass" is needed, without adding noise for a
portfolio that doesn't change every day.

## Task configuration

**Name:** `GIA Governance Drift Check`

**Schedule:** Weekly, Monday 08:00 (adjust to your timezone/working pattern)

**Prompt to paste as the task instruction:**

```
Run the governance drift-check script:

  /mnt/skills/plugins/iron-rules-governance/scripts/check-governance-drift.sh

Report the exit code and full output. If the exit code is non-zero (findings present):
- List each finding in plain language, one line each
- For each, state which skill/file it's in and what the mismatch is
- Do NOT attempt to fix anything automatically — this is a report-only task
- Flag clearly if any finding looks like it could be new content from a skill built
  since the last run, versus a regression in something already reconciled

If the exit code is 0 (clean), report that plainly in one line — no need for detail.

This is a recurring maintenance check for the GIA skill portfolio's shared governance
content (Iron Rules, evidence hierarchy, quality gate, Charlie Hills protocol). Context:
see /mnt/skills/plugins/iron-rules-governance/SKILL.md if you need to understand what any
finding means.
```

## What this catches, and what it doesn't

**Catches:** the exact category of drift found this session — colliding rule numbers,
unenumerated-but-asserted counts, phase-name regressions in `charlie-hills-code`, stray
evidence-hierarchy tables. Deterministic, so it catches these reliably regardless of which
session or which skill introduced them.

**Doesn't catch:** semantic duplication like today's example, where a skill re-derives the
same *principle* under different wording without colliding on a number or a specific
count. That needs a human (or a differently-designed check) reading for meaning, not
pattern-matching text. Worth being direct about that limit rather than implying this one
script is a complete solution — it isn't, and claiming otherwise would be the same kind of
overclaim this whole reconciliation has been correcting.

## Extending the script later

When a new skill gets reconciled into the canonical numbering, add it to
`CANONICAL_RULE_HOLDERS` or `NAMESPACED_HOLDERS` near the top of
`check-governance-drift.sh` — that's the one place the allowlist lives. If a new
quality-gate variant gets genuinely verified (fully enumerated, confirmed non-duplicate),
add its item count to `KNOWN_QUALITY_GATE_COUNTS` the same way.
