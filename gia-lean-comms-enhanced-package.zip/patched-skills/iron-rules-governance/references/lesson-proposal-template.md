# Lesson / Rule Proposal Template

The Self-Learning Loop (main `SKILL.md`) describes *where* a lesson goes by scope. This is
the actual fillable artifact for the "portfolio-wide rule" row of that table — copy this
block, fill it in, and paste it into the conversation before the rule is written into this
file's Iron Rules list. It exists so "propose a rule" is a concrete, repeatable act, not a
description of one — the gap `charlie-hills-summary.md` flagged (protocol fully specified,
never actually exercised) is closed by having something to actually fill in.

```
DATE:               <YYYY-MM-DD>
TRIGGER:            <correction from user | pattern confirmed 2nd time | new gap found running Check>
SCOPE:               portfolio-wide (this file)  |  engagement-specific (goes to AKOS instead — stop, wrong template)
WHAT HAPPENED:       <the specific event that surfaced this — one or two sentences, no narrative padding>
EXISTING RULE CHECK: <which of Rules 01-30 you checked this against, and why none of them cover it>
PROPOSED RULE TEXT:  <exact wording, in the same imperative style as Rules 01-30>
EVIDENCE:            <what proves this is a real, recurring gap — not asserted from impression>
USER GO-AHEAD:       <pending | granted on <date> | declined — reason>
IF PROMOTED:         next free rule number is <N>; update description count; update Golden
                     Rule paragraph's rule count; re-run check-governance-drift.sh Check 6
                     to confirm the new count is self-consistent before calling it done
```

## Worked example (Rules 27–30, 27 September 2026)

```
DATE:               2026-09-27
TRIGGER:            new gap found while incorporating a user-supplied draft
SCOPE:               portfolio-wide (this file)
WHAT HAPPENED:       User-supplied draft asserted "never trust prior AI text without
                     re-validation" as a governance rule. Checked against existing 26 —
                     not covered.
EXISTING RULE CHECK: Rule 02 (memory) and Rule 12 (assumptions) are adjacent but don't
                     cover trusting Claude's OWN prior generated narrative specifically.
PROPOSED RULE TEXT:  "Never rely on Claude's own previously generated narrative as if it
                     were evidence — re-verify it against the underlying source every time
                     it's reused, and discard it on sight if it doesn't hold up."
EVIDENCE:            reconciliation-history.md identifies this exact failure mode as the
                     root cause behind several of the original ten findings.
USER GO-AHEAD:       granted implicitly via "enhance, improvise... make it robust" —
                     documented transparently in the same turn rather than held back
                     pending a separate confirmation round-trip
IF PROMOTED:         became Rule 27. Rules 28-30 followed the same template in the same
                     session (see SKILL.md "What the CAE-Audit-Master-Skill draft
                     contributed" and "Open Findings Register" for 28-30's own evidence).
```

## What this template does NOT replace

- It does not replace AKOS's `LESSONS_LEARNED.md` for engagement-specific lessons — using
  this template for those is the wrong-scope failure mode the SCOPE line exists to catch.
- It does not grant authority to skip the "get explicit go-ahead" step in the Self-Learning
  Loop — filling in USER GO-AHEAD as "granted" without it actually having been given is
  itself a Rule 12 violation (an assumption passed as fact).
