# Drift Check Evidence — 27 September 2026

**What this is:** the raw, unedited output of `scripts/check-governance-drift.sh` run
against `/mnt/skills/plugins` in this session's container, on 27 September 2026. This is
R2-grade evidence per this file's own Evidence Hierarchy (auditor-executed, independently
run — not a management assertion, not carried forward from a prior session's memory). It's
the source for the Open Findings Register in `SKILL.md`.

**Caveat, stated up front per Rule 12:** this was run against `/mnt/skills/plugins`, which
is what this session's container had mounted. The script's own default target, and the path
the original 27-28 July reconciliation actually reconciled, is `/mnt/skills/user`. This
output does not confirm or rule out drift in that location — it confirms drift in the
plugin-catalog copies that this account currently has installed.

## Command

```
bash scripts/check-governance-drift.sh /mnt/skills/plugins
```

## Raw output

```
=== GIA Governance Drift Check — 2026-09-27T06:51:24Z ===
Scanning: /mnt/skills/plugins

--- Check 1: unnamespaced numbered rule lists outside the reconciled set ---
  FINDING:
    /mnt/skills/plugins/cae-audit-cowork-plugin-v5/SKILL.md
    /mnt/skills/plugins/cae-report-conversion/SKILL.md
    /mnt/skills/plugins/racm-ecosystem/SKILL.md
  -> New skill with its own numbered list? Give it a namespace (see RACM-/RC- pattern
    in references/racm-rc-namespaces.md) rather than bare RULE N, or reconcile it into
    the canonical list in iron-rules-governance/SKILL.md if the content genuinely
    overlaps (don't hardcode the current rule count here -- it's drifted before).

--- Check 2: IRON RULES headers not yet accounted for ---
  FINDING:
    /mnt/skills/plugins/cae-audit-cowork-plugin-v5/SKILL.md
    /mnt/skills/plugins/master-audit-superagent/SKILL.md
    /mnt/skills/plugins/master-audit-superagent/references/qa-reporting-protocol.md

--- Check 3: quality-gate item counts that don't match a known-enumerated count ---
  FINDING:
    /mnt/skills/plugins/cae-audit-cowork-plugin-v4/SKILL.md:40:14-item quality gate
    /mnt/skills/plugins/cae-audit-cowork-plugin-v4/SKILL.md:98:14-item quality gate
    /mnt/skills/plugins/cae-audit-cowork-plugin-v5/SKILL.md:142:gate (10 item
    /mnt/skills/plugins/cae-audit-cowork-plugin/SKILL.md:161:gate (10 item
    /mnt/skills/plugins/cae-audit-cowork-plugin/SKILL.md:412:10-Item CAE Quality Gate
    /mnt/skills/plugins/cae-cowork-ai-plugin/SKILL.md:144:gate (10 item
    /mnt/skills/plugins/cae-cowork-ai-plugin/SKILL.md:485:10-Item CAE Quality Gate
    /mnt/skills/plugins/cae-cowork-ai-plugin/SKILL.md:795:Gate Results (10 item
    /mnt/skills/plugins/akos-enterprise-orchestrator:akos-enterprise-orchestrator/references/plugin-coordination-registry.md:63:27-item quality gate
  -> A count that isn't 12 or 30 turned up. Either it's a genuinely new, properly
    enumerated gate (add its count to KNOWN_QUALITY_GATE_COUNTS above once verified
    it's actually written down somewhere), or it's an unenumerated assertion like
    the old 10-item/14-item claims were -- check before trusting it.

--- Check 4: Charlie Hills phase-name regression ---
  FINDING:
    charlie-hills-code is missing phase header(s): Plan Verify Execute Check Log

--- Check 5: R1-R5 evidence tables outside the reconciled set ---
  FINDING:
    /mnt/skills/plugins/cae-audit-cowork-plugin-v5/SKILL.md
    /mnt/skills/plugins/akos-enterprise-orchestrator:akos-enterprise-orchestrator/references/evidence-and-hallucination-controls.md
  -> Compare against references/racm-rc-namespaces.md's evidence table (if any) and
    the canonical R1-R5 in SKILL.md before assuming this is a duplicate error.

=== Summary ===
5 check(s) out of 5 raised a finding -- review above before relying on
any content in the flagged files as portfolio-consistent.
```

Exit code: `1`.

## Manual verification of Check 4 (not just trusted from the script)

Per Rule 27, the script's own finding was re-verified by hand rather than repeated as-is.
`charlie-hills-code/SKILL.md` was read directly: it defines a 6-item "Workflow Orchestration"
list (Plan Node Default, Subagent Strategy, Self-Improvement Loop, Verification Before Done,
Demand Elegance, Autonomous Bug Fixing) and a separate 6-step "Task Management Protocol"
(Plan First, Verify Plan, Track Progress, Explain Changes, Document Results, Capture
Lessons). Neither is the bare Plan/Verify/Execute/Check/Log 5-phase structure this file and
others cite. The script's finding holds up under manual re-check — it is not a false
positive from an over-strict regex.

## What this evidence does and doesn't establish

**Does:** confirm five categories of live drift exist in the currently-installed plugin
copies as of this date, with named files and line numbers.

**Doesn't:** establish root cause for each one, confirm whether `/mnt/skills/user` (the
canonical target) has the same issues, or constitute a fix. See Open Findings Register in
`SKILL.md` for recommended next actions on each.
