# RACM and RC Namespaces

Both lists below are deliberately separate from the main 25 Iron Rules — the content is
genuinely engagement-specific, not general audit governance. Both used to collide
number-for-number with the general list (same numbers, unrelated content) before the
27–28 July 2026 reconciliation gave each its own prefix.

## RACM-01 – RACM-12 (control-matrix work — `racm-ecosystem`)

```
RACM-01  Every key control must have a named owner — no anonymous controls
RACM-02  Every control description must state WHAT, WHEN, WHO, and HOW
RACM-03  Risk rating must reflect inherent risk — not residual (record both)
RACM-04  COSO component must be assigned — "Unknown" is not acceptable
RACM-05  ToD must precede ToE — never test operating effectiveness of a
          poorly designed control (garbage in, garbage out)
RACM-06  Deficiency classification must follow the SD/MW/MN framework —
          no "management judgement" overrides without documented rationale
RACM-07  All deficiencies must have a management response before report issuance
RACM-08  Red flags must be investigated and closed or accepted — never ignored
RACM-09  Version snapshot before any bulk change or AC presentation
RACM-10  ICAI GN four areas (ELC, SoD, Physical Verification, Cross-Division)
          must be explicitly addressed in any ICFR opinion
RACM-11  Automated controls cannot be relied upon if ITGC is ineffective
          (same substance as canonical Rule 23 — cite either, they agree)
RACM-12  Follow the Charlie Hills protocol (Plan → Verify → Execute → Check → Log)
          for every RACM action
```

## RC-01 – RC-12 (report conversion/migration work — `cae-report-conversion`)

```
RC-01:  No finding without named source reference — traceable to source report
RC-02:  No content creation — every element must exist in the source
RC-03:  Risk ratings preserved exactly — no upgrades or downgrades
RC-04:  Management responses verbatim — no paraphrasing
RC-05:  Missing content → Exception Log — never reconstruct
RC-06:  Editorial changes only → Migration Change Log
RC-07:  File naming: underscores only — no asterisks, spaces, or special characters
RC-08:  QA checklist (30 items) must fully pass before Final status
RC-09:  Exception Log must be empty of unresolved Critical items before Final
RC-10:  BLUF ≤5 sentences; Executive Summary ≤1 page
RC-11:  Follow the Charlie Hills protocol (Plan → Verify → Execute → Check → Log) every time
RC-12:  Disclaimer on every page footer — professional IA report, not CA/legal opinion
```

Neither list overlaps with the other. RACM-11 is the only line item in either list that
maps onto the general 25 (→ canonical Rule 23).
