---
name: iron-rules-governance
description: "The single source of truth for the GIA portfolio's Golden Rule, Iron Rules (30 rules), Evidence Hierarchy (R1-R5), 12-item Quality Gate, and Charlie Hills protocol — and the pointer to where the portfolio's actual self-learning/Kaizen mechanism lives. ALWAYS consult this skill before citing an \"Iron Rule\" or \"the Golden Rule,\" grading evidence R1-R5, checking quality-gate status, referencing \"the Charlie Hills protocol,\" or deciding where a correction, lesson, or recurring pattern should be recorded — in ANY audit, risk, compliance, fraud, RACM, or report-conversion task, across any MKTron entity or any other engagement. Also use whenever a rule number looks ambiguous, when reconciling a skill against portfolio governance, or when asked \"what does Iron Rule N mean,\" \"what's the Golden Rule,\" or \"where does self-learning / CLAUDE.md / Kaizen live.\" Supersedes every other skill's own copy of this content — see the Provenance section below for exactly what it replaces.\n"
---

# Iron Rules Governance

The canonical governance reference for the GIA skill portfolio. If another skill's own
text disagrees with this document, **this document wins** — the other skill's copy is
stale and should be corrected to point here.

## The Golden Rule

> **Ground truth outranks narrative — always re-derive, never re-trust.** Every claim in a
> deliverable must trace to verifiable ground truth (named evidence, a web-validated
> primary source, or the user's own explicit correction) at the moment of output — not to
> what an earlier draft, an earlier session, or Claude's own prior reasoning already
> concluded. Discard drifted content on sight rather than patching around it.

The 30 Iron Rules, the Evidence Hierarchy, and the Quality Gate below are this one
principle applied to specific decision points — which source counts, when a finding is
final, when a control passes. If a real situation isn't covered by a numbered rule, apply
the Golden Rule directly rather than waiting for a rule to exist for it — then propose the
new rule (see **Self-Learning Loop** below) so it's covered next time.

## Iron Rules 01–30

```
RULE 01: No finding without named evidence (R1-R4) or web-validated government portal URL
RULE 02: No rate, section, threshold, or effective date from memory — web-validate every time
RULE 03: Correct Act + correct effective date + correct jurisdiction — verify all three always
RULE 04: Retracted findings NEVER appear in any report — not even partially
RULE 05: Duplicate findings MUST be merged — never counted or reported separately
RULE 06: R5 (verbal) evidence is NEVER cited in a finding under any circumstances
RULE 07: Every finding title is self-explanatory (WHO | WHAT breach | WHICH law/standard)
RULE 08: Every recommendation is SMART — Specific, Measurable, Achievable, Relevant, Time-bound
RULE 09: Quality gate must fully pass (all 12 items — see below) before any report is FINAL
RULE 10: Design deficiency vs operating effectiveness failure — always explicitly distinguished
RULE 11: Fraud risk must be formally considered and documented in every engagement scope
RULE 12: No assumption passed as fact — ever; label all assumptions explicitly
RULE 13: Professional skepticism maintained under all stakeholder pressure — always
RULE 14: Population, sample, test procedure, result, and conclusion documented for every test
RULE 15: All deficiencies aggregated before final classification (CD → SD → MW)
RULE 16: IPPF Topical Requirements (Cyber, 3P, Resilience) applied where scope warrants
RULE 17: AI/ML analytics outputs are INDICATORS only — never cited as finding evidence
RULE 18: Before raising any finding, cross-check against all active workstreams for duplicates
RULE 19: Management response and action plan required before report is FINAL
RULE 20: A portfolio-wide rule/lesson gets written here (not invented as a local fix)
         whenever a pattern recurs twice or a new rule is confirmed — see Self-Learning Loop
RULE 21: ToD (test of design) must PASS before ToE (test of operating effectiveness) commences
RULE 22: A single walkthrough transaction trace is NOT a ToE sample — never conflate the two
RULE 23: ITGC must be confirmed effective before any reliance is placed on automated controls
RULE 24: Escalation triggers require immediate action — deferral is never acceptable
RULE 25: A finding describes the pattern of what happened — it does NOT state motive
RULE 26: Follow-up audit must be planned and tracked for every engagement with Critical
         or High/Medium findings — risk-based timing, per GIAS Standard 15.2
RULE 27: Never rely on Claude's own previously generated narrative as if it were evidence —
         re-verify it against the underlying source every time it's reused, and discard it
         on sight if it doesn't hold up (the Golden Rule, applied to Claude's own drift)
RULE 28: User-supplied ground truth — an explicit correction, a highlighted annotation, a
         raw source file — outranks any prior AI narrative, draft, or assumption in a conflict
RULE 29: A final deliverable contains only the polished work product — no process narration
         or "here's what I fixed" commentary inside the document itself (this does not apply
         to Self-Learning Loop logging, which is a different document for a different reader,
         and it never licenses omitting anything Rule 04 or Rule 19 requires to be shown)
RULE 30: Any count this file (or any skill) asserts about itself — a rule count, an item
         count, a phase count — must match what's actually enumerated. Verify with
         `scripts/check-governance-drift.sh`'s self-consistency check before citing a
         number; never carry one forward from memory or from what a prior version said
```

## Evidence Hierarchy (R1–R5)

| Rank | Definition | Citable in a finding? |
|---|---|---|
| **R1** | Government portal, gazette, or regulator's official download/certificate — external source, entity had no hand in producing it | ✅ Strongest |
| **R2** | System-of-record export (ERP/HRMS/banking-generated report) **or** an auditor-prepared, independently executed reconciliation | ✅ Strong |
| **R3** | A signed original document or physical record **that has also been independently verified or corroborated by someone outside the audited party** | ✅ Acceptable — conditional |
| **R4** | Management-provided copy/scan; a signed/original document **not** independently verified (rep letter, internally-drafted board paper, MIS report); or informal-but-documented items (email, minutes, chat log) | ⚠️ Corroborate before relying on it |
| **R5** | Verbal statement or unverified claim | ❌ Never cite, under any circumstances |

**The R3 test:** signed + original is necessary but not sufficient. If it wasn't also
independently verified, it's R4, not R3 — a management representation letter is a signed
original document and still doesn't qualify for R3.

## Quality Gate — 12 items (Rule 09)

- [ ] Every finding has named evidence file (R1–R4) or web-validated portal URL — no R5
- [ ] Every rate / section / threshold web-validated — source URL recorded in finding
- [ ] Correct Act + correct effective date + correct jurisdiction — all three verified
- [ ] No duplicate findings (merged where same issue; all evidence consolidated)
- [ ] No retracted, draft, or internal CAE note text in the final report
- [ ] All findings rated with risk colour 🔴🟡🟢
- [ ] Deficiency classification (CD / SD / MW) documented and defensible
- [ ] Aggregation assessment completed — all related deficiencies reviewed together
- [ ] All recommendations are SMART — named owner and target date present
- [ ] Report is version-controlled — version number, date, classification, CAE sign-off
- [ ] Document reference appendix lists all evidence reviewed
- [ ] Disclaimer present: professional IA report — not a statutory audit, CA certificate, or legal opinion

(Item 5 above and Rule 29 are the same discipline seen twice, deliberately — the gate
checks the artifact, Rule 29 checks the drafting habit that produces it.)

## Not the same thing: "Quality Gate" vs "Quality Assurance Gate"

**8 August 2026, stage 3 check.** `group-cae-reporting` and `group-cae-external-reporting`
each have their own "Independent Quality Assurance Gate" — a 4-to-5-pass *review process*
(independent read, proofread, internal consistency, zero-fabrication, and for the internal
skill, a humanised-voice check) applied before a Board/AC paper or an external-facing
document is released. That is genuinely different from Rule 09's 12-item gate above, which
is a *checklist of required end-states* for an audit report going FINAL — different
document types, different mechanism (sequential review passes vs. a pass/fail checklist),
not a collision. No merge needed. Flagged here only so "the quality gate" isn't assumed to
mean one specific thing portfolio-wide — say which skill's gate you mean if it's ambiguous
from context.

Two engagement types have their own numbered rules because the content is genuinely
domain-specific, not because anyone forgot to reconcile them:

- **RACM work** (control matrices) → `RACM-01`–`RACM-12`. See `references/racm-rc-namespaces.md`.
- **Report conversion/migration work** → `RC-01`–`RC-12`. See `references/racm-rc-namespaces.md`.

If you're doing RACM or report-conversion work, consult both this file AND that reference
— the 30 rules above still apply in general; the RACM/RC rules add engagement-specific
requirements on top.

## The Charlie Hills protocol

Cited across the portfolio as a standing workflow requirement: **Plan → Verify → Execute
→ Check → Log.** Full detail (phase-by-phase, with the coding-specific version) lives in
the `charlie-hills-code` skill and `references/charlie-hills-summary.md` here. Short form:

1. **Plan** — write the plan before acting on anything non-trivial
2. **Verify** — check the plan itself, not just that one exists; look for a more elegant approach before committing
3. **Execute** — do the work; track progress as you go, not just at the end
4. **Check** — prove it's correct before calling it done; never assume
5. **Log** — document what changed and why; capture any lesson that would prevent a repeat
   mistake, and write it to the actual location in **Self-Learning Loop** below — not just
   into the conversation, where it evaporates at session end

**27 September 2026 — do not treat this as settled without reading Open Findings Register
below first.** Running Check (step 4, above) against the live `charlie-hills-code` file
this session found it does *not* actually implement this 5-phase structure, contradicting
this section's own framing and a specific "already fixed" claim in
`references/reconciliation-history.md`. Applying Rule 27 to this file's own prior content:
that claim is retracted, not repeated. Detail in Open Findings Register.

## Open Findings Register

Live, evidence-backed findings from actually running `scripts/check-governance-drift.sh`
against `/mnt/skills/plugins` on 27 September 2026 (full output:
`references/drift-check-2026-09-27.md` — R2 evidence, auditor-executed, not asserted from
memory, per Rule 01). Risk-rated per Quality Gate item 6. None of these are fixed by this
update — that would mean editing other skills outside this one's explicit scope — they're
recorded here so they're not lost, per Rule 20.

🔴 **`charlie-hills-code` does not implement the Plan→Verify→Execute→Check→Log cycle this
file (and ~10 others) attribute to it.** The live skill defines a different, still-coherent
6-item "Workflow Orchestration" list plus a 6-step "Task Management Protocol" — not wrong,
just not what everyone else's citation assumes. `reconciliation-history.md`'s claim that
commit `509900c` already "rewrote charlie-hills-code around the 5-phase cycle" does not
hold against the live file — same root cause reconciliation-history.md's own finding 10
already named (a written record claiming a fix that the live source doesn't reflect).
**Recommendation:** decide whether `charlie-hills-code` gets rewritten to match this
summary, or this summary gets rewritten to match `charlie-hills-code`'s actual (richer)
content — both are defensible, this file shouldn't pick unilaterally. Owner: you. Target:
before the next skill cites "the 5-phase Charlie Hills cycle" and gets it from either source.

✅ **Resolved 2026-10-03 (owner-authorised, additive).** `charlie-hills-code` now carries an
explicit `## Phase 1 — Plan` to `## Phase 5 — Log` mapping onto its existing items. Its
original content was kept, not rewritten, because the live skill is richer than this
summary. Drift Check 4 now passes. The "already fixed in commit 509900c" claim in
`reconciliation-history.md` stays retracted; it was false when written.

🔴 **`charlie-hills-code` carries its own independent "CLAUDE.md Self-Update Rule"** (trigger
conditions nearly identical to AKOS Module 7's promotion criteria) — a second, uncoordinated
self-learning/Kaizen description, the exact duplication risk this update just steered this
file away from creating a third copy of. **Recommendation:** reconcile `charlie-hills-code`'s
rule to point at AKOS Module 7 (or vice versa) the same way this file's Self-Learning Loop
now points at it, rather than three skills each partially describing the same mechanism.

✅ **Resolved 2026-10-03 (owner-authorised, additive).** `charlie-hills-code`'s CLAUDE.md
Self-Update Rule now states its scope: project and codebase conventions only. Portfolio-wide
patterns go through `self-learning-loop` and AKOS Module 7, which need the owner's go-ahead.

🟡 **Quality-gate item counts that don't match the canonical 12 (or RC's 30) are still live**
in `cae-audit-cowork-plugin` (10), `cae-audit-cowork-plugin-v4` (14, twice), `cae-cowork-plugin-v5` (cited as `cae-audit-cowork-plugin-v5` in the 27 Sept raw log; same skill, same 10-item-gate finding, verified 2026-10-03)
(10), `cae-cowork-ai-plugin` (10, three places), and `akos-enterprise-orchestrator`'s
`plugin-coordination-registry.md` (27). Same pattern the 8 August 2026 pass already fixed
once — it has recurred, which by Rule 20's own trigger ("recurs twice") is itself now a
standing pattern worth a permanent fix, not a repeat one-off cleanup.

**Update 2026-10-03, measured twice; the first measurement overstated the gap (corrected here).**
Measured with `gate_audit.py` (`gia-lean-comms`), a keyword proxy over the written gate text.
The first pass read each gate section alone and concluded a report could reach FINAL without
CD / SD / MW classification or the aggregation assessment. That was wrong for the current engine:
the v6 skills run two gates before FINAL, a fieldwork gate and a report-conversion QA whose
item 28 checks that an aggregation summary is present. Measured per skill across both,
`cae-fieldwork-engine` (user copy) and its near-duplicate `cae-cowork-ai-plugin` cover every
canonical concept except **CD / SD / MW classification**, which neither gate lists. Rule 14 and
the aggregation function cover the process; no gate item checks the classification itself.
`cae-cowork-plugin-v5` and `cae-audit-cowork-plugin-v4` are versions the v6 frontmatter says it
supersedes, and plain `cae-audit-cowork-plugin` (v3) predates them; their gates match the
versions they describe, so they are legacy rather than deficient. Proposed fix, an owner
decision and **not applied**: one supplementary check, S1, in the two v6 copies, drafted as a
patch that makes no claim about what the tool enforces. Whether `generateReport()` itself should
check classification cannot be seen from the skill folders and is for the tool's owner.

🟡 **Unnamespaced bare `RULE N:` lists** are still live in `cae-cowork-plugin-v5`,
`cae-report-conversion`, and `racm-ecosystem` — the latter two should be RC-/RACM-only per
their own namespace (see `references/racm-rc-namespaces.md`), so a bare list surviving
alongside the namespaced one needs a look, not an assumption either way.

🟢 **R1–R5-shaped evidence tables in `cae-cowork-plugin-v5` and AKOS's
`evidence-and-hallucination-controls.md`** — informational only. AKOS's own docs say to
defer to this file, so this is likely a compliant pointer, not a competing definition, but
it wasn't opened and read this session to confirm that rather than assume it.

**Not investigated this session, flagged only:** whether the same drift exists in
`/mnt/skills/user` (the path this skill's own script and prior reconciliation actually
target) — this run scanned `/mnt/skills/plugins` instead, since that's what's mounted in
this session's container. Re-run against `/mnt/skills/user` before treating this register
as covering the whole portfolio.

## Self-Learning Loop — where a lesson actually goes

**This skill does not define its own Kaizen engine, and deliberately doesn't.** The
portfolio already has one: `akos-enterprise-orchestrator`, Module 7 — Self-Learning Kaizen
Engine — and AKOS's own non-negotiable coordination rule is explicit that content-governance
skills (this one included) must never re-derive the orchestration/memory mechanics it
already owns. Writing a second, competing description of "how self-learning works" in this
file would recreate the exact drift this skill exists to stop — two skills, two slightly
different accounts of the same mechanism, silently diverging the next time either gets
edited. So here is where each kind of lesson goes, not a second engine:

| Scope | Where it's written |
|---|---|
| A correction, workaround, or recurring pattern tied to one engagement/entity (e.g. an MKAPL Pune finding pattern, a Sathya payroll quirk) | That engagement's `LESSONS_LEARNED.md` / `PROJECT_MEMORY.md`, per AKOS Module 7 |
| A new or corrected rule, evidence-grading call, or quality-gate item meant to apply **portfolio-wide**, to every engagement | **This file** — propose the exact rule text, get your explicit go-ahead, then it's added here directly. This is what Rule 20 means by "written here," and it's the mechanism this session's Rules 27–29 came through |
| A skill-specific behavioural fix (wrong prompt, missed step, bad template) that isn't a governance rule | The owning skill's own file, via AKOS's normal promotion path |

**Promotion trigger** (owned by AKOS Module 7, repeated here only because Rule 20 depends
on it): propose a rule immediately when a correction reveals one is missing; propose
promoting a pattern to a standing rule after the user has confirmed it a second time.
**Always state the proposed rule and get an explicit go-ahead before writing it as a
standing rule** — recording a lesson is fine unprompted; changing standing behaviour
portfolio-wide is not.

**Honesty check, carried forward from `references/charlie-hills-summary.md`:** as of the
last reconciliation, the Log phase had never actually produced an artifact anywhere in the
portfolio — it was fully specified and unexercised. Rules 27–29 are the first rules to
travel this path for real. That's one data point that the mechanism works, not proof it's
now self-sustaining — the next real test is whether a rule gets proposed here the *next*
time a pattern actually recurs, without being asked to.

## What the CAE-Audit-Master-Skill draft contributed — and what didn't make it in

You supplied a five-item draft this session. Disposition of each, so the reasoning is
auditable rather than asserted:

1. *"Zero hallucination — never trust prior AI text without re-validation."* → **Added as
   Rule 27.** Genuinely new: Rule 02 already covers not trusting *memory*, and Rule 12
   already covers not asserting *assumptions* — neither covers the specific failure of
   trusting Claude's own earlier drift, which `references/reconciliation-history.md`
   identifies as the actual root cause behind several of the ten findings in the original
   reconciliation.
2. *"Ground truth supremacy — user annotations override AI narrative."* → **Added as Rule
   28.** Also genuinely new; the closest existing rule (12) is about assumptions, not about
   ranking a user's correction above the AI's own prior output.
3. *"Absolute token economy — no filler, no padding."* → **Not added as an Iron Rule.**
   This is a communication-discipline preference, not an audit-integrity control, and this
   list exists specifically to hold discrete, verifiable governance content (see
   Provenance). It's a legitimate preference — the right home for it is your own standing
   style preferences, not a numbered rule sitting next to "no R5 evidence in a finding."
4. *"No meta-commentary in outputs."* → **Added as Rule 29,** narrowed to *final
   deliverables* specifically — it doesn't reach the Self-Learning Loop's own logging,
   which is commentary by definition, for a different document and a different reader.
5. *"Value-addition perspective over fault-finding."* → **Not added as a numbered rule.**
   This is already covered by your own standing persona/reporting-style preferences
   (optimistic, collaborative, value-add framing). Adding it here too would be the same
   "two places, one meaning" drift this skill's own provenance history exists to stop —
   just one skill later.

Two more pieces of the draft were **not merged in at all**:

- Its **Agentic Orchestration Protocol** (an Opus-orchestrator / Sonnet-Haiku execution
  team, with routing tags) restates ground AKOS already owns — "how work is sequenced
  across the skill ecosystem" is explicitly outside this skill's scope (see AKOS's own
  `does_not_supersede` metadata). One tag in the draft, `/independent-qa`, was checked
  against both the account's plugin catalog and its skill catalog this session (searched,
  not assumed) — **confirmed it doesn't exist under this or any related name.** The
  checking function it implies is currently performed by the 12-item Quality Gate plus
  human review, not a dedicated agent. Treat `/independent-qa` as aspirational until
  someone actually builds it; nothing should route to it in the meantime.
- Its **4-section "Standard Output Structure"** conflicts with your own standing
  13-section reporting structure (Executive Summary → Background → ... → Conclusion).
  Two competing "the" report structures is the exact failure mode findings 4–5 in
  `references/reconciliation-history.md` document (three incompatible evidence-hierarchy
  definitions; three asserted quality-gate sizes). Your 13-section structure stays
  canonical here; nothing in this update overrides it. A genuinely shorter preview/quick-take
  format would be a separate, deliberately-scoped document type, not a default replacement.

## Provenance — what this replaces

This skill is the packaged, standalone form of a reconciliation completed 27–28 July 2026
against nine skills that each carried their own drifting copy of this content:
`super-grc-audit-plugin-l99`, `mac-audit-constitution-l99`, `cae-audit-cowork-plugin`,
`cae-audit-cowork-plugin-v4`, `cae-cowork-plugin-v5`, `cae-cowork-ai-plugin`,
`audit-risk-ecosystem`, `group-cae-fraud-v2`. Full findings, decisions, and commit history
are in `references/reconciliation-history.md`. If you're auditing this skill itself for
staleness later, that file is where the "was this actually verified against source, or
just asserted" answer lives.

**8 August 2026 update:** a deterministic drift-check script (`scripts/check-governance-
drift.sh`) found residual drift the manual reconciliation above had missed — stale
10/14-item quality-gate references still live in four skills, and a fully-enumerated
20-rule block in `cae-cowork-ai-plugin` that the original investigation never located
(it had reported that skill as *not* enumerating its rules — that was incorrect). Fixed;
Rule 26 added as a result. See `reconciliation-history.md` for detail.

**27 September 2026 update:** incorporated a user-supplied draft ("CAE-Audit-Master-Skill")
after checking it against Rules 01–26 and against AKOS Module 7 rather than merging it in
wholesale — see "What the CAE-Audit-Master-Skill draft contributed" above for the
item-by-item disposition. Added Rules 27–29 and "The Golden Rule" as a capstone statement
of the principle those rules (and the 26 before them) already implement. Did **not** rename
"Iron Rules" to "Golden Rules" — roughly a dozen other skills cite "Iron Rule N" by that
exact term, and renumbering or renaming out from under them is precisely the kind of break
this file exists to prevent (see commit history below). Did **not** add a second
self-learning mechanism — added the Self-Learning Loop section pointing to AKOS Module 7
instead, plus a scope table for where a lesson should actually be written. In the course of
this update, also found and fixed one small live instance of the exact drift this file
warns about: `scripts/check-governance-drift.sh` still referred to "the canonical 25" in
its own hint text, three rules and one prior update behind the file it was checking.

**27 September 2026, same-day follow-up pass — "resolve open items, harden the mechanism."**
Confirmed `/independent-qa` doesn't exist anywhere in the catalog (searched, not assumed) —
see updated disposition above. Confirmed the 4-section output structure stays out (decision,
not left open). Added **Rule 30** (self-consistency of any count this file asserts about
itself) after that exact failure mode recurred live: ran `check-governance-drift.sh` for
real against `/mnt/skills/plugins` (Charlie Hills "Check" step, not skipped) and it found
five categories of active drift, written up in the new **Open Findings Register** above with
full evidence in `references/drift-check-2026-09-27.md`. The most material of those:
`charlie-hills-code` does not actually implement the 5-phase cycle this file attributes to
it, and `reconciliation-history.md`'s claim that it was already fixed doesn't survive
re-verification — that claim is corrected in both files rather than repeated. Also added
Check 6 (self-consistency) to `scripts/check-governance-drift.sh`, and
`references/lesson-proposal-template.md` as the actual artifact the Self-Learning Loop
writes to, so "propose a rule" is a fillable template, not just a described process. None of
the five newly-found findings were fixed at their source this session — that means editing
other live skills, which is a bigger, separately-scoped action than "edit iron-rules-
governance," and Rule 09's own discipline (nothing goes FINAL, including a fix, without the
gate) argues against rushing it in the same pass that found it.

## Commit history (`/mnt/skills/user`, chronological)

```
ff9cadc Add canonical Iron Rules + Evidence Hierarchy + Quality Gate reference doc
312b740 super-grc-audit-plugin-l99: add Rules 21-25, merge Evidence Hierarchy R3 test
f79090c mac-audit-constitution-l99: de-frame from competing MASTER status
0a52b0f cae-audit-cowork-plugin: pointer note to canonical doc
d0eefcf cae-audit-cowork-plugin-v4: renumber Lineage-2 rules to canonical
2c0feac cae-cowork-plugin-v5: merge Evidence Grading table (incomplete — see 6a0ac8c)
c049ce6 cae-cowork-ai-plugin: fix Rule 11/Rule 02 duplication, Panel 15 pointer
f4fd714 audit-risk-ecosystem: renumber to canonical, fix quality gate count
2c8264d group-cae-fraud-v2: renumber no-motive rule to canonical Rule 25
509900c charlie-hills-code realign; racm-ecosystem RACM-01-12 namespace
6a0ac8c cae-cowork-plugin-v5 complete fix; cae-report-conversion RC-01-12 namespace
2f18e45 cae-audit-cowork-plugin-v4: pointer note on redundant Finding Iron Rules restatement
```
