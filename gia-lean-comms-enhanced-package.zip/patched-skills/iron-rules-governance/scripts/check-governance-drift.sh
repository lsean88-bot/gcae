#!/usr/bin/env bash
#
# check-governance-drift.sh — GIA Skill Portfolio Governance Drift Check
#
# Deterministic, dependency-free (bash + grep + find only) checks for the kind of
# cross-skill drift found and fixed during the 27-28 July 2026 Iron Rules reconciliation:
# colliding rule numbers, unenumerated-but-asserted item counts, and stale phase names.
# This does NOT replace human judgement or a full independent QA pass — it catches the
# mechanical, pattern-level regressions cheaply and repeatably, so the next drift doesn't
# take five rounds of manual grep to find the way this one did.
#
# Usage:   ./check-governance-drift.sh [path-to-skills-dir]
# Default: with no argument, scans EVERY skill root that exists (/mnt/skills/user,
#          /mnt/skills/plugins, ~/.claude/skills) merged into one view. Patched 2026-10-02:
#          the old default was /mnt/skills/user alone, which holds 3 skills, so the
#          scheduled check silently skipped its own self-consistency check and reported
#          phantom findings. An explicit directory argument is still honoured as-is.
# Exit:    0 = clean (all 6 checks ran, no findings)
#          1 = findings present
#          2 = error, or INCOMPLETE (no findings but a check was SKIPPED: not a pass)
#          Safe to use as a CI/pre-commit/scheduled-task gate.
#
# Portable by design: no python, no external packages, nothing beyond what any Claude
# Code, Cowork, or plain bash environment already has.

set -uo pipefail
# Deliberately NOT `set -e` — grep returning 1 (no match) is an expected, normal outcome
# throughout this script, not a failure condition.

SKILLS_DIR="${1:-}"
FINDINGS=0
SECTION=0
SKIPPED=0
SCOPE_NOTE=""

if [ -z "$SKILLS_DIR" ]; then
  UNION_TMP="$(mktemp -d)"
  trap 'rm -rf "$UNION_TMP"' EXIT
  ROOTS_USED=""
  for root in /mnt/skills/user /mnt/skills/plugins "$HOME/.claude/skills"; do
    [ -d "$root" ] || continue
    ROOTS_USED="$ROOTS_USED $root"
    for d in "$root"/*/; do
      [ -f "${d}SKILL.md" ] || continue
      n="$(basename "$d")"
      [ -e "$UNION_TMP/$n" ] || ln -s "${d%/}" "$UNION_TMP/$n"
    done
  done
  SKILLS_DIR="$UNION_TMP"
  SCOPE_NOTE="merged roots:$ROOTS_USED (skill folder names are real; the leading path in findings below is a temporary merged view)"
fi

pass() { echo "  clean"; }
fail() { FINDINGS=$((FINDINGS+1)); echo "  FINDING:"; }
section() { SECTION=$((SECTION+1)); echo "--- Check ${SECTION}: $1 ---"; }

if [ ! -d "$SKILLS_DIR" ]; then
  echo "ERROR: '$SKILLS_DIR' is not a directory." >&2
  exit 2
fi

echo "=== GIA Governance Drift Check — $(date -u +%Y-%m-%dT%H:%M:%SZ) ==="
echo "Scanning: $SKILLS_DIR"
[ -n "$SCOPE_NOTE" ] && echo "Scope:    $SCOPE_NOTE"
echo "Skills in scope: $(ls -d "$SKILLS_DIR"/*/ 2>/dev/null | wc -l)"
echo

# ---------------------------------------------------------------------------
# Allowlist — skills already reconciled into the canonical numbering, or given
# their own deliberate namespace. Update this list when a skill is newly
# reconciled; that's the ONE place drift-check maintenance should happen.
# ---------------------------------------------------------------------------
CANONICAL_RULE_HOLDERS="iron-rules-governance|super-grc-audit-plugin-l99|mac-audit-constitution-l99|cae-audit-cowork-plugin/|cae-audit-cowork-plugin-v4|cae-cowork-ai-plugin|cae-cowork-plugin-v5|audit-risk-ecosystem|group-cae-fraud-v2"
NAMESPACED_HOLDERS="racm-ecosystem|cae-report-conversion"
KNOWN_QUALITY_GATE_COUNTS="12|30"  # 12 = canonical Rule 09; 30 = RC-08 (report-conversion QA checklist)

# ---------------------------------------------------------------------------
section "unnamespaced numbered rule lists outside the reconciled set"
# ---------------------------------------------------------------------------
# A bare "RULE 01:" / "RULE 12:" style line, in a file that isn't one of the
# already-reconciled canonical holders, is exactly the pattern that hid
# racm-ecosystem and cae-report-conversion from the first two sweeps.
HITS=$(grep -rlE "^RULE [0-9]+:|^RULE [0-9]+ " "$SKILLS_DIR"/*/SKILL.md "$SKILLS_DIR"/*/references/*.md 2>/dev/null \
       | grep -Ev "$CANONICAL_RULE_HOLDERS" || true)
if [ -n "$HITS" ]; then
  fail
  echo "$HITS" | sed 's/^/    /'
  echo "  → New skill with its own numbered list? Give it a namespace (see RACM-/RC- pattern"
  echo "    in references/racm-rc-namespaces.md) rather than bare RULE N, or reconcile it into"
  echo "    the canonical list in iron-rules-governance/SKILL.md if the content genuinely"
  echo "    overlaps (don't hardcode the current rule count here — it's drifted before)."
else
  pass
fi
echo

# ---------------------------------------------------------------------------
section "IRON RULES headers not yet accounted for"
# ---------------------------------------------------------------------------
# Catches the exact miss that hid racm-ecosystem: an all-caps section header
# using "IRON RULES" that a case-sensitive search for "Iron Rule" won't match.
HITS=$(grep -rliE "^#+.*iron rules" "$SKILLS_DIR"/*/SKILL.md "$SKILLS_DIR"/*/references/*.md 2>/dev/null \
       | grep -Ev "$CANONICAL_RULE_HOLDERS|$NAMESPACED_HOLDERS" || true)
if [ -n "$HITS" ]; then
  fail
  echo "$HITS" | sed 's/^/    /'
else
  pass
fi
echo

# ---------------------------------------------------------------------------
section "quality-gate item counts that don't match a known-enumerated count"
# ---------------------------------------------------------------------------
# Flags any "N-item ... gate" or "gate ... N item" claim where N isn't one of
# the counts that's actually enumerated somewhere (12, 30). This is the check
# that would have caught the 10-item and 14-item claims immediately instead
# of requiring a manual search that came up empty.
HITS=$(grep -rnoiE "[0-9]+-item[a-z ]*gate|gate[a-z ]*\([0-9]+ item" "$SKILLS_DIR"/*/SKILL.md "$SKILLS_DIR"/*/references/*.md 2>/dev/null \
       | grep -v "reconciliation-history.md" \
       | grep -Eiv "($KNOWN_QUALITY_GATE_COUNTS)-item|\(($KNOWN_QUALITY_GATE_COUNTS) item" || true)
if [ -n "$HITS" ]; then
  fail
  echo "$HITS" | sed 's/^/    /'
  echo "  → A count that isn't 12 or 30 turned up. Either it's a genuinely new, properly"
  echo "    enumerated gate (add its count to KNOWN_QUALITY_GATE_COUNTS above once verified"
  echo "    it's actually written down somewhere), or it's an unenumerated assertion like"
  echo "    the old 10-item/14-item claims were — check before trusting it."
else
  pass
fi
echo

# ---------------------------------------------------------------------------
section "Charlie Hills phase-name regression"
# ---------------------------------------------------------------------------
# Regression check on the specific fix made 27 July: charlie-hills-code must
# still define all 5 phases the other 11 citing skills assume it means.
CH_FILE="$SKILLS_DIR/charlie-hills-code/SKILL.md"
if [ -f "$CH_FILE" ]; then
  MISSING=""
  for PHASE in Plan Verify Execute Check Log; do
    grep -qiE "^## Phase [0-9]+ — ${PHASE}" "$CH_FILE" || MISSING="$MISSING $PHASE"
  done
  if [ -n "$MISSING" ]; then
    fail
    echo "    charlie-hills-code is missing phase header(s):$MISSING"
  else
    pass
  fi
else
  fail
  echo "    charlie-hills-code/SKILL.md not found at $CH_FILE"
fi
echo

# ---------------------------------------------------------------------------
section "R1-R5 evidence tables outside the reconciled set"
# ---------------------------------------------------------------------------
# A new "| R1 |...| R5 |"-style table outside the already-merged canonical
# hierarchy is exactly how the three-way evidence-hierarchy split happened.
HITS=$(grep -rlE "^\| ?R1 ?\|" "$SKILLS_DIR"/*/SKILL.md "$SKILLS_DIR"/*/references/*.md 2>/dev/null \
       | grep -Ev "$CANONICAL_RULE_HOLDERS" || true)
if [ -n "$HITS" ]; then
  fail
  echo "$HITS" | sed 's/^/    /'
  echo "  → Compare against references/racm-rc-namespaces.md's evidence table (if any) and"
  echo "    the canonical R1-R5 in SKILL.md before assuming this is a duplicate error."
else
  pass
fi
echo

# ---------------------------------------------------------------------------
section "self-consistency: asserted counts vs actually-enumerated content (Rule 30)"
# ---------------------------------------------------------------------------
# This is the check born from the "canonical 25" bug found 27 Sept 2026: a count
# asserted in a heading/description drifting silently away from the content it
# describes. Checks iron-rules-governance's own file against itself.
IRG_FILE="$SKILLS_DIR/iron-rules-governance/SKILL.md"
if [ -f "$IRG_FILE" ]; then
  SELF_FINDING=0

  ASSERTED_RULES=$(grep -oE "Iron Rules \(([0-9]+) rules\)" "$IRG_FILE" | grep -oE "[0-9]+" | head -1)
  ACTUAL_RULES=$(grep -cE "^RULE [0-9]+:" "$IRG_FILE")
  if [ -n "$ASSERTED_RULES" ] && [ "$ASSERTED_RULES" != "$ACTUAL_RULES" ]; then
    [ "$SELF_FINDING" -eq 0 ] && fail
    SELF_FINDING=1
    echo "    description asserts $ASSERTED_RULES Iron Rules; $ACTUAL_RULES are actually enumerated"
  fi

  ASSERTED_GATE=$(grep -oE "^## Quality Gate — ([0-9]+) items" "$IRG_FILE" | grep -oE "[0-9]+" | head -1)
  ACTUAL_GATE=$(grep -cE "^- \[ \]" "$IRG_FILE")
  if [ -n "$ASSERTED_GATE" ] && [ "$ASSERTED_GATE" != "$ACTUAL_GATE" ]; then
    [ "$SELF_FINDING" -eq 0 ] && fail
    SELF_FINDING=1
    echo "    heading asserts $ASSERTED_GATE Quality Gate items; $ACTUAL_GATE checkbox lines found"
  fi

  if [ "$SELF_FINDING" -eq 1 ]; then
    echo "  → Rule 30 violation inside the canonical file itself — fix here first, before"
    echo "    anything downstream cites a number from it."
  else
    pass
  fi
else
  SKIPPED=$((SKIPPED+1))
  echo "  SKIPPED — $IRG_FILE not found under $SKILLS_DIR (can't self-check a file that isn't there)"
fi
echo

# ---------------------------------------------------------------------------
echo "=== Summary ==="
if [ "$FINDINGS" -eq 0 ] && [ "$SKIPPED" -gt 0 ]; then
  echo "INCOMPLETE: no findings, but $SKIPPED check(s) were SKIPPED. A skipped check is not a pass."
  echo "Re-run with a scope that contains iron-rules-governance, or fix the path."
  exit 2
elif [ "$FINDINGS" -eq 0 ]; then
  echo "No findings across $SECTION checks."
  exit 0
else
  [ "$SKIPPED" -gt 0 ] && echo "Note: $SKIPPED check(s) were also SKIPPED, so coverage is incomplete."
  echo "$FINDINGS check(s) out of $SECTION raised a finding — review above before relying on"
  echo "any content in the flagged files as portfolio-consistent."
  exit 1
fi
