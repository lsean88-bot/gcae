---
name: skill-sprawl-watch
description: >
  Scans the GIA skill/plugin portfolio for description/trigger overlap between skills —
  catching duplicate or near-duplicate capabilities before they cause mis-routing, wasted
  build effort, or two skills silently drifting apart. Use this whenever a new skill is
  drafted or an existing one's description is edited (run it against the target before
  finalizing), whenever mktron-sentinel:skill-factory or mktron-sentinel:independent-critique
  needs an overlap check, whenever a QAIP tooling-hygiene pass is run (see
  qaip-self-assessment's tooling-qaip-checklist.md, which references this skill by name), or
  when asked to check for redundant or duplicate skills, sprawl, or portfolio hygiene. This
  closes a real gap — this skill was referenced by name in three other places in the library
  as something that flags new-skill additions proactively, but did not actually exist as
  working code until 2026-08-06.
---

# Skill Sprawl Watch

Detects overlapping trigger vocabulary between skills in the portfolio, using each
skill's own frontmatter `description:` field — not commentary or analysis written about
it. This distinction matters: an earlier, undocumented attempt at this exact tool failed
silently (reported zero overlaps against an obviously-duplicate synthetic test skill)
because it indexed audit commentary about skills instead of their own text. See
`self-learning-loop`'s `data/lessons_promoted.md` items 2–4 for the full
account — read that before modifying `scripts/scan_overlap.py`, not just this file.

## What it actually does

`scripts/scan_overlap.py` is real, tested Python (not a described-but-unbuilt convention).
It:
1. Walks one or more root directories for every `SKILL.md` file.
2. Parses each one's YAML frontmatter properly (`yaml.safe_load` after a narrow,
   non-greedy `---`-delimited match) and extracts the `description:` field only.
3. Tokenizes each description, strips a stopword list of terms so common across this
   *specific* library (audit, risk, compliance, governance, IIA, COSO, GIA, MKTron, etc.)
   that they carry no discriminating signal on their own — per the tooling-hygiene
   checklist's own warning that "'audit' alone will match nearly everything."
4. Computes **two** complementary scores between every pair (or between one target skill
   and every other, if `--target` is given) — Jaccard similarity (symmetric, good when
   both descriptions are similar length) and containment (`shared / min(len_a, len_b)`,
   robust to length asymmetry) — and flags a pair if *either* crosses its threshold,
   citing **both scores and which one triggered the flag**, plus the actual shared terms.

**Why two scores, not one (added 2026-08-08):** the first execution-validation test run
against this tool used a deliberately near-duplicate draft skill and found Jaccard alone
*missed it* — scored 0.27, under the 0.30 default — because the existing skill's
description was over twice as long, diluting the union. Containment on the same pair was
0.73 (73% of the new draft's distinctive vocabulary was already in the existing skill) —
an unambiguous real duplicate that a single symmetric-similarity score hid. Re-run against
the full real portfolio after adding containment: zero new false-positive flags, only the
genuinely-missed case newly caught.

## How to run it

**Check a single new/edited skill against the whole portfolio** (the common case —
run this before finalizing any skill draft):
```bash
python3 scripts/scan_overlap.py --roots /mnt/skills/user /mnt/skills/plugins \
  --target /path/to/draft-skill/SKILL.md --threshold 0.30
```

**Full portfolio sweep** (QAIP tooling-hygiene cycle, or a periodic health check):
```bash
python3 scripts/scan_overlap.py --roots /mnt/skills/user /mnt/skills/plugins --threshold 0.30
```

Add `--json` for machine-readable output when another skill (e.g. `independent-critique`)
needs to consume the result programmatically rather than read the text report.

## Reading the output

- **Score is a starting point, not a verdict.** A 0.30+ Jaccard score means "go read both
  descriptions and decide," not "one of these must be deleted." Two skills covering the
  same jurisdiction from different angles (e.g. an HR audit skill and a full ops audit
  skill for the same city) may legitimately both exist if one explicitly supersedes or
  narrows the other — check whether that relationship is documented, per
  `tooling-qaip-checklist.md` item 3, before concluding it's a problem.
- **Two entries with the identical skill name is not a scoring edge case — it's a genuine
  duplicate skill folder.** If a flag shows the same `name:` on both sides, that means two
  separate `SKILL.md` files declare that name (e.g. one under `/mnt/skills/user/`, one
  under `/mnt/skills/plugins/`) — report this distinctly from an ordinary two-skill
  overlap, since the fix (consolidate to one canonical copy) is different from the fix for
  two genuinely different skills that happen to share vocabulary.
- **Never resolve a flagged duplicate unilaterally.** This skill detects; it does not
  decide which of two overlapping skills should be archived, renamed, or merged — that's
  the person's call, the same discipline this library already applies to audit findings
  (a control deficiency gets reported and remediated by agreement, not silently patched by
  whoever found it).

## Known limitation

Both scores are lexical heuristics, not semantic understanding — two skills that overlap
in *meaning* but use different vocabulary (a description that says "sampling
methodology" vs one that says "test of operating effectiveness sample sizing") will not
be caught by either metric. This is a first-pass filter meant to catch the common case
(near-identical, copy-pasted, or substantially-reused description language, regardless
of how differently the two descriptions are padded or elaborated), not a substitute for
`independent-critique`'s reasoned trigger-ambiguity review, which can catch what neither
lexical metric can.

## Reference

- `references/library-scan-baseline.md` — the first real full-portfolio sweep run at
  build time (2026-08-06), kept as a dated baseline so a future sweep can show whether
  sprawl is growing or shrinking, not just a point-in-time snapshot.
