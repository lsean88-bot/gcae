# Library Overlap Scan — Baseline (2026-08-06, updated 2026-08-08)

First real run of `scripts/scan_overlap.py` against the full portfolio
(`/mnt/skills/user` + `/mnt/skills/plugins`, threshold 0.30). Kept as a dated baseline so
a future sweep can show whether sprawl is trending up or down, per
`tooling-qaip-checklist.md` item 6's requirement that a QAIP show trend, not just a
snapshot.

**2026-08-08 update:** the `akos-enterprise-orchestrator` duplicate flagged in the
original baseline below was consolidated — the plugins-directory copy was a diverged v1.0
snapshot with no unique content (confirmed by diff before retirement), retired to a stub,
canonical copy kept at `/mnt/skills/user/akos-enterprise-orchestrator`. Re-run confirmed
the flag is gone: 6 flags remain (down from 7), none involving AKOS.

## Flags (empirical — this is the scanner's real output, not a reasoned critique)

| Score | Skill A | Skill B | Shared terms (sample) | Likely explanation |
|---|---|---|---|---|
| 0.70 | `pune-hr-audit` | `chennai-hr-audit` | statutory section numbers, acts, years | Two city-specific HR skills sharing statutory citation vocabulary — expected; both are legacy per their own descriptions, each superseded by the corresponding `*-india-ops-audit` skill |
| 0.62 | `pune-india-ops-audit` | `chennai-india-ops-audit` | acts, years, amendment dates | Same pattern one layer up — both current, city-specific, expected to share Indian statutory vocabulary |
| 0.60 | `my-mkpc-mfg-audit` | `my-mfg-diecast-stamping-audit` | IATF/OSHA/EPF section numbers | Two Malaysia die-casting/stamping skills — worth checking whether one supersedes the other or whether the split (entity-specific vs generic Malaysia die-casting) is intentional and documented |
| 0.51 | `group-cae-core` | `group-cae` | CAE-persona framework vocabulary | Two CAE-persona skills — check `skill-registry-navigator` for whether these are meant to be the same routing target under two names |
| 0.40 | `my-healthcare-clinical-dialysis-audit` | `my-hc-dialysis-audit` | dialysis/PHFSA statutory vocabulary | Two dialysis-audit skills — same pattern as the die-casting pair above |
| 0.33 | `my-mkpc-mfg-audit` | `my-erawan-lmw-audit` | Malaysian statutory section numbers | Lower score, likely just shared Malaysian regulatory citation vocabulary rather than a real capability overlap |

**Resolved since the original baseline:** `akos-enterprise-orchestrator` <->
`akos-enterprise-orchestrator` (0.52, same declared name in two locations) —
consolidated 2026-08-08, see update note above.

## What this baseline does NOT tell you

- Whether any of the above is a *problem* — several of these pairs may be intentional
  (a legacy skill kept for fallback, a deliberately narrower entity-specific skill next to
  a broader one). This scanner flags candidates for review; `skill-registry-navigator` and
  the person decide what, if anything, changes.
- Semantic overlap that doesn't share vocabulary (see this skill's "Known limitation").

## Re-running this baseline

```bash
python3 scripts/scan_overlap.py --roots /mnt/skills/user /mnt/skills/plugins --threshold 0.30 --json
```
Compare the new flag list against this table at the next QAIP tooling-hygiene cycle.
