---
name: charlie-hills-code
description: >
  Applies Charlie Hills' engineering workflow rules, orchestration patterns, and coding standards
  when working on any code, bug fix, architecture decision, or technical task. ALWAYS use for
  any coding request, bug report, refactor, feature build, or technical planning task. Enforces
  plan-first execution, self-improvement loop, autonomous bug fixing, elegance checks, and
  task file discipline. Trigger on ANY technical task — code, bugs, tests, CI, architecture,
  implementation, review, or technical decision.
---

# Charlie Hills — Code & Engineering Workflow Skill

## Workflow Orchestration

### 1. Plan Node Default
- Enter plan mode for ANY non-trivial task (3+ steps or architectural decisions)
- If something goes sideways: STOP and re-plan immediately. Do not keep pushing.
- Use plan mode for verification steps, not just building
- Write detailed specs upfront to reduce ambiguity
- Write plan to `tasks/todo.md` with checkable items before touching any code
- Check in with user before starting implementation

### 2. Subagent Strategy
- Use subagents liberally to keep the main context window clean
- Offload research, exploration, and parallel analysis to subagents
- For complex problems: throw more compute at it via subagents
- One task per subagent for focused execution

### 3. Self-Improvement Loop — CRITICAL
- After ANY correction from the user: update `tasks/lessons.md` with the pattern
- Write rules for yourself that prevent the same mistake recurring
- Ruthlessly iterate on these lessons until mistake rate drops
- Review `tasks/lessons.md` at session start for the relevant project
- **When you identify a recurring pattern in the work: update `CLAUDE.md` immediately so the rule persists across all future sessions — do not wait to be told**

### 4. Verification Before Done
- Never mark a task complete without proving it works
- Diff behaviour between main and your changes when relevant
- Ask yourself: "Would a staff engineer approve this?"
- Run tests, check logs, demonstrate correctness before closing

### 5. Demand Elegance (Balanced)
- For non-trivial changes: pause and ask "is there a more elegant way?"
- If a fix feels hacky: "Knowing everything I know now, implement the elegant solution"
- Skip this for simple, obvious fixes — do not over-engineer
- Challenge your own work before presenting it

### 6. Autonomous Bug Fixing
- When given a bug report: just fix it. No hand-holding required.
- Point at logs, errors, failing tests — then resolve them
- Zero context switching required from the user
- Go fix failing CI tests without being told how

---

## Task Management Protocol

Execute in this order for every non-trivial task:

1. **Plan First** — Write plan to `tasks/todo.md` with checkable items
2. **Verify Plan** — Check in before starting implementation
3. **Track Progress** — Mark items complete as you go
4. **Explain Changes** — High-level summary at each step
5. **Document Results** — Add review section to `tasks/todo.md`
6. **Capture Lessons** — Update `tasks/lessons.md` after any correction

---

## Portfolio phase mapping: Plan → Verify → Execute → Check → Log

The portfolio's Charlie Hills protocol is defined in `iron-rules-governance`. This skill's six
workflow items and six-step protocol above are its coding-specific form. Nothing above was
removed or reworded; this mapping was added 2026-10-03 so the two stay consistent.

## Phase 1 — Plan
Workflow item 1 (Plan Node Default); protocol step 1 (Plan First).

## Phase 2 — Verify
Protocol step 2 (Verify Plan); workflow item 5 (Demand Elegance), which is the portfolio's
"look for a more elegant approach before committing".

## Phase 3 — Execute
Protocol steps 3 and 4 (Track Progress, Explain Changes); workflow items 2 (Subagent
Strategy) and 6 (Autonomous Bug Fixing).

## Phase 4 — Check
Workflow item 4 (Verification Before Done) and the Self-Check list at the end of this file.

## Phase 5 — Log
Protocol steps 5 and 6 (Document Results, Capture Lessons); workflow item 3 (Self-Improvement
Loop). Where a lesson goes: a project convention to `CLAUDE.md`; an engagement-specific
lesson to `tasks/lessons.md`; a portfolio-wide pattern to `self-learning-loop` and AKOS
Module 7.

---

## Core Principles

- **Simplicity First**: Make every change as simple as possible. Impact minimal code.
- **No Laziness**: Find root causes. No temporary fixes. Senior developer standards.
- **Minimal Impact**: Changes should only touch what is necessary. Avoid introducing bugs.

---

## CLAUDE.md Self-Update Rule

When you recognise a pattern that keeps recurring — a mistake type, a workflow shortcut that works,
a project-specific convention — update `CLAUDE.md` directly without waiting to be asked.

**Trigger conditions for a CLAUDE.md update:**
- A correction from the user that reveals a rule you were missing
- A pattern you have now seen 2+ times in this codebase
- A project convention discovered during execution (file structure, naming, test approach)
- A tool or library preference the user has confirmed

**How to update:**
1. Add the rule under the relevant section in `CLAUDE.md`
2. State it as a clear, actionable instruction (not an observation)
3. Tell the user: "I've added this to CLAUDE.md so it applies from here on."

**Scope:** this rule covers project and codebase conventions. A portfolio-wide pattern (an Iron
Rule, evidence grade or quality-gate change) is not written to `CLAUDE.md` unprompted: log it
via `self-learning-loop` and promote it under AKOS Module 7 and `iron-rules-governance`, which
require the owner's explicit go-ahead. This keeps one self-learning mechanism, not two.

---

## Self-Check Before Marking Anything Done
- [ ] Plan was written to `tasks/todo.md` before implementation started?
- [ ] Tests pass / logs clean / behaviour demonstrated?
- [ ] "Would a staff engineer approve this?" — honest answer is yes?
- [ ] Any correction received this session → `tasks/lessons.md` updated?
- [ ] Any recurring pattern identified → `CLAUDE.md` updated?
- [ ] Minimal code touched — no side-effects introduced?
