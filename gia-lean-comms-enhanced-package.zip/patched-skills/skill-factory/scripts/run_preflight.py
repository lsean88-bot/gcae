#!/usr/bin/env python3
"""
run_preflight.py — orchestrates the real, automatable checks before handing a skill draft
to independent-critique. Does NOT replace independent-critique's reasoned pass; it just
makes sure the empirical checks always run first, in the same order, so critique time is
spent on judgement calls rather than re-discovering a length-limit violation by hand.

Runs, in order:
  1. skill-creator's quick_validate.py (structural validity — frontmatter, naming, length)
  2. skill-sprawl-watch's scan_overlap.py, targeted at the draft (overlap vs portfolio)

Exit codes:
    0  every check ran and nothing failed
    1  a check FAILED (or the overlap scanner crashed)
    2  INCOMPLETE: nothing failed but at least one check was SKIPPED. A skipped check is
       not a pass. Pass --allow-skip to accept this knowingly (e.g. a sandbox with no
       sprawl scanner). Added 2026-10-02: the overlap check used to be silently skipped
       by default because the sibling-skill lookup assumed a "mktron-sentinel:" folder name.

Usage:
    python3 run_preflight.py --skill /path/to/draft-skill \
        --creator-path /mnt/skills/examples/skill-creator \
        --roots /mnt/skills/user /mnt/skills/plugins
"""
import argparse
import json
import subprocess
import sys
from pathlib import Path


def find_sprawl_watch(explicit=None):
    """Locate skill-sprawl-watch. Accepts the skill DIRECTORY or the scan_overlap.py file
    itself, and tries every layout this portfolio is known to use: bare folder name,
    "mktron-sentinel:"-prefixed folder name, and the common install roots. Returns the
    skill directory or None."""
    here = Path(__file__).resolve().parent.parent.parent
    names = ["skill-sprawl-watch", "mktron-sentinel:skill-sprawl-watch"]
    cands = []
    if explicit:
        # An explicit path is authoritative: never silently fall back to a different copy.
        p = Path(explicit)
        c = p.parent.parent if p.suffix == ".py" else p
        return c if (c / "scripts" / "scan_overlap.py").exists() else None
    for n in names:
        cands += [here / n, Path("/mnt/skills/plugins") / n, Path("/mnt/skills/user") / n,
                  Path.home() / ".claude" / "skills" / n]
    for c in cands:
        if (c / "scripts" / "scan_overlap.py").exists():
            return c
    return None


def run(cmd):
    result = subprocess.run(cmd, capture_output=True, text=True)
    return result.returncode, result.stdout.strip(), result.stderr.strip()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--skill", required=True, help="Path to the draft skill folder")
    parser.add_argument("--creator-path", default="/mnt/skills/examples/skill-creator",
                         help="Path to skill-creator (for quick_validate.py)")
    parser.add_argument("--sprawl-watch-path", default=None,
                         help="skill-sprawl-watch directory (or its scan_overlap.py). "
                              "Default: auto-detected across known layouts")
    parser.add_argument("--allow-skip", action="store_true",
                         help="Exit 0 even if a check was SKIPPED (default: exit 2)")
    parser.add_argument("--roots", nargs="+",
                         default=["/mnt/skills/user", "/mnt/skills/plugins",
                                  "/mnt/skills/examples", "/mnt/skills/public"],
                         help="Directories to search for SKILL.md files (default: everywhere "
                              "a skill could plausibly live, per lesson logged 2026-08-08 — "
                              "a narrower default silently missed a possible collision with "
                              "skill-creator itself, which lives under /mnt/skills/examples)")
    parser.add_argument("--threshold", type=float, default=0.30)
    args = parser.parse_args()

    skill_path = Path(args.skill).resolve()
    skill_md = skill_path / "SKILL.md"

    report = {"skill": str(skill_path), "checks": {}}
    overall_pass = True

    # --- Check 1: structural validity ---
    validate_script = Path(args.creator_path) / "scripts" / "quick_validate.py"
    if validate_script.exists():
        rc, out, err = run(["python3", str(validate_script), str(skill_path)])
        report["checks"]["structural_validity"] = {
            "pass": rc == 0, "message": out or err,
        }
        if rc != 0:
            overall_pass = False
    else:
        report["checks"]["structural_validity"] = {
            "pass": None, "message": f"quick_validate.py not found at {validate_script} — SKIPPED",
        }

    # --- Check 2: portfolio overlap ---
    sprawl_dir = find_sprawl_watch(args.sprawl_watch_path)
    scan_script = (sprawl_dir or Path(args.sprawl_watch_path or "skill-sprawl-watch")) / "scripts" / "scan_overlap.py"
    if sprawl_dir is None:
        report["checks"]["portfolio_overlap"] = {
            "pass": None,
            "message": f"SKIPPED -- skill-sprawl-watch's scan_overlap.py not found "
                       f"(looked for bare and 'mktron-sentinel:' folder names, "
                       f"explicit path: {args.sprawl_watch_path!r}). This is NOT a pass. "
                       f"Pass --sprawl-watch-path with the skill-sprawl-watch directory.",
        }
    elif skill_md.exists():
        rc, out, err = run([
            "python3", str(scan_script),
            "--roots", *args.roots, str(skill_path),
            "--target", str(skill_md),
            "--threshold", str(args.threshold),
            "--json",
        ])
        if rc == 3:
            # scan_overlap.py's own crash-detection wrapper (added the same day as this
            # check, for the same reason) -- rc 3 is unique to a genuine unhandled crash,
            # never a graceful exit. rc 0 = success (with or without flags). rc 1 = a
            # graceful guarded exit (e.g. fewer than 2 valid skills found) -- also fine.
            report["checks"]["portfolio_overlap"] = {
                "pass": None,
                "message": f"scan_overlap.py CRASHED (exit {rc}) -- overlap check did NOT run. "
                           f"Treat this the same as a FAIL, not a clean pass.",
                "stderr": err[-2000:] if err else "(no stderr captured)",
            }
            overall_pass = False
        else:
            if rc == 1 and not out.strip():
                # A graceful exit 1 with nothing on stdout means the check genuinely didn't
                # run (e.g. the target's own description couldn't be loaded at all) -- not
                # the same as running cleanly and finding zero flags. Found via UAT
                # 2026-08-08 as a smaller residual case of the same reporting-accuracy
                # family as the rc==3 crash fix above.
                report["checks"]["portfolio_overlap"] = {
                    "pass": None,
                    "message": "Overlap check did not run — target's own description could "
                               "not be loaded (see structural_validity for why).",
                    "stderr": err.strip() if err else "(no stderr captured)",
                }
            else:
                try:
                    overlap_data = json.loads(out) if out else {"flags": []}
                except json.JSONDecodeError:
                    overlap_data = {"flags": [], "raw_error": err or out}
                flags = overlap_data.get("flags", [])
                report["checks"]["portfolio_overlap"] = {
                    "pass": len(flags) == 0,
                    "flags": flags,
                    "message": f"{len(flags)} overlap flag(s) at threshold {args.threshold}" if flags
                               else "No overlap flags",
                }
            # Overlap flags are advisory (a human judgement call, per skill-sprawl-watch's own
            # SKILL.md), not an automatic fail — don't set overall_pass=False here.
    else:
        report["checks"]["portfolio_overlap"] = {
            "pass": None,
            "message": f"scan_overlap.py or {skill_md} not found — SKIPPED",
        }

    skipped = [name for name, c in report["checks"].items() if c.get("pass") is None]
    report["overall_structural_pass"] = overall_pass
    report["overall_complete"] = not skipped
    report["skipped_checks"] = skipped
    report["note"] = (
        "This is the EMPIRICAL preflight only. It does not replace independent-critique's "
        "reasoned trigger-ambiguity review, nor skill-creator's live eval loop (which needs "
        "Claude Code / the `claude` CLI and cannot run in this sandbox). Overlap flags above "
        "are advisory — read them, don't auto-fail on them."
    )

    if skipped:
        report["note"] = ("INCOMPLETE: skipped " + ", ".join(skipped) +
                          ". A skipped check is not a pass. " + report["note"])
    print(json.dumps(report, indent=2))
    if not overall_pass:
        sys.exit(1)
    sys.exit(0 if (not skipped or args.allow_skip) else 2)


if __name__ == "__main__":
    main()
