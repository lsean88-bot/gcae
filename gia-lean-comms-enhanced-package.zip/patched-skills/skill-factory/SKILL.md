---
name: skill-factory
description: >
  Workflow for creating a new GIA skill or improving an existing one, wired into this
  library's own quality mechanisms rather than run as a one-off. Use this whenever asked to
  build a new skill, turn a workflow into a skill, add a capability to the GIA library, or
  fix/improve an existing skill's structure or trigger description. Runs skill-creator's
  real structural validator and skill-sprawl-watch's real overlap scanner before handing the
  draft to mktron-sentinel:independent-critique for a separate reasoned pass, and checks
  self-learning-loop's promoted lessons before starting so past build mistakes (a YAML
  frontmatter colon bug, an indexing-the-wrong-field bug, a silently-broken regex) don't get
  repeated. Trigger on: new skill, build a skill, create a skill, turn this into a skill,
  improve this skill, fix this skill's description, skill triggering, skill packaging.
---

# Skill Factory

This wraps `skill-creator` (the general-purpose skill-authoring methodology) with three
things specific to this library: a mandatory pre-check of prior lessons, a mandatory
overlap scan against the other ~55 skills already in the portfolio, and a mandatory
hand-off to an independent critique pass before anything is packaged. It does not
duplicate skill-creator's own content (progressive disclosure, the eval-loop mechanics,
description-optimization) — read that skill directly for the parts of the methodology
this one doesn't repeat.

## The workflow

### 0. Check prior lessons before starting
Read `self-learning-loop`'s `data/lessons_promoted.md` — specifically the
"Coding / scripting" and "Methodology / audit work" sections — before drafting anything.
This is not optional ceremony: this exact plugin's own build caught a real YAML bug on its
first test run (see lesson logged 2026-08-06) that this step would have prevented if it had
existed beforehand.

### 1. Capture intent
Same four questions skill-creator asks: what should this skill do, when should it trigger,
what's the expected output format, does it need test cases. If this conversation already
contains the workflow to capture (the person said "turn this into a skill"), extract
answers from the conversation history first.

### 2. Draft the SKILL.md
Follow skill-creator's anatomy (frontmatter + body, progressive disclosure via
`references/`/`scripts/`/`assets/`, <500 lines in the body). **Use YAML block-scalar style
(`description: >` followed by indented lines) for the description field**, not a plain
inline scalar — a plain scalar breaks on the first bare colon, which a GIA-style
description (full of "Trigger on: X, Y, Z" phrasing) will very likely contain.

### 3. Run the real preflight checks
```bash
# run from the skill-factory folder (in the sandbox mount: /mnt/skills/plugins/skill-factory)
python3 scripts/run_preflight.py --skill /path/to/draft-skill
```
Exit 0 = every check ran and passed; 1 = a check failed; **2 = incomplete, a check was
skipped, which is not a pass** (use `--allow-skip` only if you accept that knowingly).
This runs, in order: skill-creator's `quick_validate.py` (structural validity) and
skill-sprawl-watch's `scan_overlap.py` (portfolio collision check), and returns a single
JSON report. Fix any structural failure before proceeding — don't hand a structurally
invalid draft to critique, that wastes the critique pass on something a script already
caught.

### 4. Hand off to independent-critique
Explicitly invoke `mktron-sentinel:independent-critique` on the draft once preflight
passes. This is a genuinely separate pass, not a formality — see that skill's own SKILL.md
for why the separation matters and what it actually checks that preflight doesn't.

### 5. Address critique findings, re-run preflight if anything changed
Any edit to the description or structure invalidates the previous preflight run — length
limits and overlap scores are re-checked, not assumed to still hold (see
`lessons_promoted.md` item 5 — this is a documented recurring mistake in this exact
library, not a hypothetical).

### 6. Register and package
- Add an entry to `mktron-grc-function/references/full-library-directory.md` — this is the
  single canonical map; don't create a second one.
- Package via skill-creator's `package_skill.py` if a distributable `.skill` file is
  needed: `python3 -m scripts.package_skill /path/to/skill-folder` (run from inside
  skill-creator's own directory, since it does a relative import).

### 7. Log what was learned
If anything caught during this process (preflight, critique, or the person's own
correction) represents a mistake likely to recur — not a one-off typo — log it via
`self-learning-loop`'s `scripts/log_lesson.py`. Don't wait for a quarterly
consolidation to write down something you already know is generalizable.

## What this workflow does NOT cover

The actual empirical trigger-eval loop (`run_eval.py` / `run_loop.py`, which shells out to
the `claude` CLI to test real trigger behaviour across many phrasings) needs Claude Code and
cannot run in a claude.ai sandbox. Preflight + critique are real substitutes for a *first*
pass, not a replacement for that loop on anything high-stakes — if Claude Code is available,
still run the real eval loop before finalizing a skill that many people will rely on.

## Reference

- Read `/mnt/skills/examples/skill-creator/SKILL.md` directly for the full authoring
  methodology (anatomy, progressive disclosure, description-writing guidance, packaging
  details) — this skill assumes that content rather than restating it.
