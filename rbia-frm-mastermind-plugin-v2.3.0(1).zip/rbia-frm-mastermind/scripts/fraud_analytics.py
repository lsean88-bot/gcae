#!/usr/bin/env python3
"""RBIA-FRM fraud analytics toolkit (Python standard library only).

Deterministic, reproducible tests that output LEADS with exact row references, denominators
and input-file hashes. A flag is never a conclusion: confirm with context, benign-alternative
tests and corroboration (SKILL.md Phase 3).

Usage:  python3 -I scripts/fraud_analytics.py <test> [options]   (add --out result.json to save)
Tests:  profile duplicates benford splits round sequence blanks calendar overlap sod recon je ratevar
Row numbers are file line numbers (header = line 1).
"""
import argparse, csv, hashlib, json, math, re, sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from difflib import SequenceMatcher
from pathlib import Path

LEAD = ("LEAD, NOT A CONCLUSION: confirm with context, benign-alternative tests and corroboration "
        "before any classification. Amounts across different tests overlap and are NOT additive.")


# ----------------------------------------------------------------------------- helpers
def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def read(path):
    raw = open(path, "rb").read()
    for enc in ("utf-8-sig", "cp1252"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            text = None
    if text is None:
        sys.exit(f"ERROR: cannot decode {path}; re-export as UTF-8")
    import io
    try:
        dialect = csv.Sniffer().sniff(text[:20000], delimiters=",;\t|")
        delim = dialect.delimiter
    except csv.Error:
        delim = ","
    rd = csv.reader(io.StringIO(text, newline=""), delimiter=delim)
    try:
        header = next(rd)
    except StopIteration:
        return [], []
    header = [h.strip() for h in header]
    if len(set(header)) != len(header):
        sys.exit(f"ERROR: duplicate column headers in {path}: {header}")
    rows, prev = [], rd.line_num
    for rec in rd:
        start = prev + 1
        prev = rd.line_num
        if not any(c.strip() for c in rec):
            continue
        d = {h: (rec[i] if i < len(rec) else "") for i, h in enumerate(header)}
        d["_row"] = start
        d["_short_or_long"] = len(rec) != len(header)
        rows.append(d)
    READ_WARN[path] = {"delimiter": delim, "rows_with_wrong_field_count": sum(1 for r in rows if r["_short_or_long"])}
    return header, rows


READ_WARN = {}


def need(header, *cols):
    for c in cols:
        if c and c not in header:
            sys.exit(f"ERROR: column '{c}' not found. Available columns: {header}")


UNPARSED = Counter()


def num(s):
    if s is None:
        return None
    t = str(s).strip().replace(",", "")
    if t == "":
        return None
    neg = t.startswith("(") and t.endswith(")")
    t = t.strip("()")
    if t.endswith("-") and not neg:
        neg, t = True, t[:-1]
    try:
        v = float(t)
    except ValueError:
        UNPARSED["numeric"] += 1
        return None
    if math.isnan(v) or math.isinf(v):
        UNPARSED["numeric"] += 1
        return None
    return -v if neg else v


DATE_FORMATS = ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%d-%b-%Y", "%Y-%m")


def dt(s):
    t = str(s or "").strip()
    if not t:
        return None
    if "T" in t and re.match(r"\d{4}-\d{2}-\d{2}T", t):
        t = t.replace("T", " ")
        t = re.sub(r"(Z|[+-]\d{2}:?\d{2})$", "", t).split(".")[0]
    for f in DATE_FORMATS:
        try:
            return datetime.strptime(t, f)
        except ValueError:
            pass
    UNPARSED["date"] += 1
    return None


def date_only(s):
    t = str(s or "").strip()
    return not re.search(r"\d{1,2}:\d{2}", t)


def norm(s):
    import unicodedata
    t = unicodedata.normalize("NFKC", str(s or "")).casefold()
    return "".join(ch for ch in t if ch.isalnum())


TOOL_VERSION = "2.3.0"


def emit(a, test, files, params, population, exceptions, extra=None, status="OK"):
    defaults_used = []
    if PARSER is not None:
        for act in PARSER._subparsers._group_actions[0].choices[a.cmd]._actions:
            if act.dest in ("help", "limit", "out") or act.default in (None, False):
                continue
            if not any(o in sys.argv for o in act.option_strings):
                defaults_used.append({act.dest: act.default})
    try:
        script_hash = sha256(__file__)
    except OSError:
        script_hash = None
    res = {"test": test, "status": status, "tool_version": TOOL_VERSION, "script_sha256": script_hash,
           "command_line": sys.argv[1:], "files": {p: sha256(p) for p in files}, "params": params,
           "defaults_used_CONFIRM_WITH_USER": defaults_used,
           "input_quality": {"read": READ_WARN, "unparsed_values": dict(UNPARSED)},
           "population": population, "exception_count": len(exceptions),
           "exceptions": exceptions[: a.limit], "truncated": max(0, len(exceptions) - a.limit),
           "note": LEAD, "run_utc": datetime.now(timezone.utc).isoformat()}
    if extra:
        res.update(extra)
    s = json.dumps(res, indent=2, ensure_ascii=False)
    print(s)
    if a.out:
        Path(a.out).write_text(s, encoding="utf-8")
        print(f"# output sha256: {sha256(a.out)}", file=sys.stderr)
    return res


PARSER = None


def chi2_sf_df8(x):
    h = x / 2.0
    return math.exp(-h) * sum(h ** k / math.factorial(k) for k in range(4))


# ----------------------------------------------------------------------------- tests
def t_profile(a):
    h, rows = read(a.file)
    cols, empty = {}, []
    for c in h:
        vals = [r[c] for r in rows]
        nb = [v for v in vals if str(v).strip() != ""]
        d = {"non_blank": len(nb), "blank": len(vals) - len(nb), "distinct": len(set(nb))}
        nn = [x for x in (num(v) for v in nb) if x is not None]
        if nb and len(nn) / len(nb) >= 0.9:
            d.update({"numeric": True, "sum": round(sum(nn), 2), "min": min(nn), "max": max(nn)})
        dd = [x for x in (dt(v) for v in nb) if x]
        if nb and len(dd) / len(nb) >= 0.9:
            d.update({"date": True, "min_date": str(min(dd)), "max_date": str(max(dd))})
        if not nb:
            empty.append(c)
        cols[c] = d
    seen = Counter(tuple(r[c] for c in h) for r in rows)
    dupes = [{"values": list(k), "count": v} for k, v in seen.items() if v > 1]
    emit(a, "profile", [a.file], {}, {"rows": len(rows), "columns": len(h)}, dupes,
         {"columns": cols, "all_blank_columns": empty,
          "control_total_hint": "Record row count and numeric sums; compare to the source-system report before any test."})


def t_duplicates(a):
    h, rows = read(a.file)
    keys = a.key.split(",")
    need(h, *keys, a.amount, a.party, a.date)
    g = defaultdict(list)
    for r in rows:
        g[tuple(norm(r[k]) for k in keys)].append(r)
    ex = []
    for k, v in g.items():
        if len(v) > 1 and any(k):
            item = {"type": "exact_key", "key": {kk: v[0][kk] for kk in keys}, "rows": [r["_row"] for r in v]}
            if a.amount:
                amts = [num(r[a.amount]) or 0 for r in v]
                item["amounts"] = amts
                item["repeat_value_potentially_duplicated"] = round(sum(amts[1:]), 2)
            ex.append(item)
    if a.amount and a.party and a.date:
        byp = defaultdict(list)
        for r in rows:
            byp[norm(r[a.party])].append(r)
        for p, lst in byp.items():
            for i in range(len(lst)):
                for j in range(i + 1, len(lst)):
                    x, y = lst[i], lst[j]
                    if tuple(norm(x[k]) for k in keys) == tuple(norm(y[k]) for k in keys):
                        continue
                    ax, ay = num(x[a.amount]), num(y[a.amount])
                    dx, dy = dt(x[a.date]), dt(y[a.date])
                    if None in (ax, ay, dx, dy) or ax == 0:
                        continue
                    if abs(ax - ay) <= a.tol_pct / 100 * abs(ax) and abs((dx - dy).days) <= a.days:
                        ex.append({"type": "near_duplicate", "party": x[a.party], "rows": [x["_row"], y["_row"]],
                                   "amounts": [ax, ay], "days_apart": abs((dx - dy).days)})
    emit(a, "duplicates", [a.file], {"key": keys, "amount": a.amount, "tol_pct": a.tol_pct, "days": a.days},
         {"rows": len(rows)}, ex)


def t_benford(a):
    h, rows = read(a.file)
    need(h, a.col)
    vals = [abs(v) for v in (num(r[a.col]) for r in rows) if v not in (None, 0)]
    reasons = []
    n = len(vals)
    if n < a.min_n:
        reasons.append(f"population too small (n={n} < {a.min_n})")
    if vals and min(vals) > 0 and max(vals) / min(vals) < 100:
        reasons.append(f"range spans fewer than 2 orders of magnitude (max/min={max(vals) / min(vals):.1f})")
    if vals:
        top, cnt = Counter(vals).most_common(1)[0]
        if cnt / n > 0.20:
            reasons.append(f"dominant repeated value {top} ({cnt / n:.0%}): likely fixed-price or system-set amounts")
    fd = [int(str(f"{v:.10e}")[0]) for v in vals]
    if len(set(fd)) < 7 and n >= 1:
        reasons.append(f"only {len(set(fd))} distinct leading digits present")
    if reasons:
        emit(a, "benford", [a.file], {"col": a.col, "min_n": a.min_n}, {"n": n}, [],
             {"result": "NOT_APPLICABLE: no statistic reported because it would be an artefact",
              "reasons": reasons, "use_instead": "rate vs contract, quantity vs gate log, invoice vs payment, duplicates, recon"},
             status="NOT_APPLICABLE")
        return
    cnt = Counter(fd)
    exp = {d: math.log10(1 + 1 / d) for d in range(1, 10)}
    obs = {d: cnt.get(d, 0) / n for d in range(1, 10)}
    chi2 = sum(((cnt.get(d, 0) - exp[d] * n) ** 2) / (exp[d] * n) for d in range(1, 10))
    p = chi2_sf_df8(chi2)
    mad = sum(abs(obs[d] - exp[d]) for d in range(1, 10)) / 9
    label = ("close conformity" if mad <= 0.006 else "acceptable conformity" if mad <= 0.012 else
             "marginally acceptable" if mad <= 0.015 else "NONCONFORMITY")
    dev = sorted(((d, obs[d] - exp[d]) for d in range(1, 10)), key=lambda x: -abs(x[1]))[:3]
    emit(a, "benford", [a.file], {"col": a.col, "min_n": a.min_n}, {"n": n},
         [{"digit": d, "observed": round(obs[d], 4), "expected": round(exp[d], 4)} for d, _ in dev] if label == "NONCONFORMITY" else [],
         {"chi_square_df8": round(chi2, 3), "p_value": round(p, 6), "MAD": round(mad, 5), "mad_conformity_nigrini": label,
          "interpretation": "Nonconformity directs where to look (digit/segment drill-down); it is not evidence of fraud. "
                            "Thresholds are conventional (Nigrini); verify against your methodology."})


def t_splits(a):
    h, rows = read(a.file)
    need(h, a.party, a.amount, a.date)
    byp = defaultdict(list)
    for r in rows:
        v, d = num(r[a.amount]), dt(r[a.date])
        if v is not None and d and 0 < v < a.threshold:
            byp[norm(r[a.party])].append((d, v, r))
    ex = []
    for p, lst in byp.items():
        lst.sort(key=lambda x: x[0])
        used = set()
        for i in range(len(lst)):
            if i in used:
                continue
            win = [j for j in range(i, len(lst)) if (lst[j][0] - lst[i][0]).days <= a.days]
            if len(win) >= 2 and sum(lst[j][1] for j in win) >= a.threshold:
                used.update(win)
                ex.append({"party": lst[i][2][a.party], "rows": [lst[j][2]["_row"] for j in win],
                           "amounts": [lst[j][1] for j in win], "sum": round(sum(lst[j][1] for j in win), 2),
                           "window_days": a.days, "threshold": a.threshold})
    emit(a, "splits", [a.file], {"threshold": a.threshold, "days": a.days}, {"rows": len(rows)}, ex)


def t_round(a):
    h, rows = read(a.file)
    need(h, a.amount)
    vals = [(num(r[a.amount]), r["_row"]) for r in rows]
    vals = [(v, rn) for v, rn in vals if v not in (None, 0)]
    n = len(vals)
    shares, flagged_base = {}, None
    for b in sorted((int(x) for x in a.bases.split(",")), reverse=True):
        c = sum(1 for v, _ in vals if abs(v) % b == 0)
        s = c / n if n else 0
        shares[b] = {"count": c, "share": round(s, 4), "expected_if_random": round(1 / b, 4)}
        if flagged_base is None and n >= 30 and c >= 5 and s >= 0.05 and s >= 5 / b:
            flagged_base = b
    ex = [{"row": rn, "amount": v} for v, rn in vals if flagged_base and abs(v) % flagged_base == 0]
    emit(a, "round", [a.file], {"amount": a.amount, "bases": a.bases}, {"n": n}, ex,
         {"shares": shares, "flagged_base": flagged_base,
          "caveat": "Round amounts are normal for contract fees, fixed allowances and deposits; check the payment type first."})


def t_sequence(a):
    h, rows = read(a.file)
    need(h, a.col)
    groups = defaultdict(list)
    for r in rows:
        m = re.search(r"(\d+)\D*$", str(r[a.col]))
        if m:
            groups[str(r[a.col])[: m.start(1)]].append((int(m.group(1)), r["_row"]))
    ex = []
    for pre, lst in groups.items():
        lst.sort()
        nums = [x for x, _ in lst]
        dup = [k for k, c in Counter(nums).items() if c > 1]
        gaps = []
        for x, y in zip(nums, nums[1:]):
            if y - x > 1:
                gaps.append([x + 1, y - 1])
        coded = bool(nums) and all(len(str(x)) >= 6 and 1990 <= x // (10 ** (len(str(x)) - 4)) <= 2100 for x in nums)
        if coded:
            gaps = []
        if dup or gaps:
            ex.append({"prefix": pre, "count": len(nums), "duplicates": dup[:20], "gap_ranges": gaps[:30],
                       "missing_numbers": sum(g[1] - g[0] + 1 for g in gaps)})
    emit(a, "sequence", [a.file], {"col": a.col}, {"rows": len(rows)}, ex,
         {"period_coded_prefixes_gap_check_skipped": [pre for pre, lst in groups.items() if lst and all(len(str(x)) >= 6 and 1990 <= x // (10 ** (len(str(x)) - 4)) <= 2100 for x, _ in lst)], "caveat": "Month-coded or year-coded numbers (e.g. INV-202604) produce false gaps; interpret by numbering convention."})


def t_blanks(a):
    h, rows = read(a.file)
    need(h, a.col, a.amount)
    sel = rows
    if a.where:
        k, v = a.where.split("=", 1)
        need(h, k)
        sel = [r for r in rows if str(r[k]).strip() == v]
    ex = [{"row": r["_row"], **({"amount": num(r[a.amount])} if a.amount else {}),
           "id": r.get(h[0])} for r in sel if str(r[a.col]).strip() == ""]
    tot = round(sum(e.get("amount") or 0 for e in ex), 2) if a.amount else None
    emit(a, "blanks", [a.file], {"col": a.col, "where": a.where}, {"rows_tested": len(sel)}, ex, {"total_amount": tot})


def t_calendar(a):
    h, rows = read(a.file)
    need(h, a.date, a.amount)
    wk = {int(x) for x in a.weekend.split(",")}
    hol = {x.strip() for x in a.holidays.split(",") if x.strip()}
    ex = []
    for r in rows:
        d = dt(r[a.date])
        if not d:
            continue
        why = []
        if d.weekday() in wk:
            why.append("weekend")
        if d.strftime("%Y-%m-%d") in hol:
            why.append("holiday")
        if ("%H" in "".join(DATE_FORMATS)) and (d.hour or d.minute) and (d.hour >= a.after or d.hour < a.before):
            why.append("off-hours")
        if why:
            ex.append({"row": r["_row"], "date": str(d), "reasons": why, **({"amount": num(r[a.amount])} if a.amount else {})})
    emit(a, "calendar", [a.file], {"weekend_days(Mon=0)": sorted(wk), "after": a.after, "before": a.before},
         {"rows": len(rows)}, ex, {"caveat": "Set --weekend for the jurisdiction (e.g. 4,5 where Fri-Sat is the weekend) and list public holidays."})


def t_overlap(a):
    ha, ra = read(a.a_file)
    hb, rb = read(a.b_file)
    need(ha, a.a_col)
    need(hb, a.b_col)
    bmap = defaultdict(list)
    for r in rb:
        if norm(r[a.b_col]):
            bmap[norm(r[a.b_col])].append(r)
    ex, seen, blank_a = [], set(), []
    for r in ra:
        k = norm(r[a.a_col])
        if not k:
            blank_a.append(r["_row"])
            continue
        if a.unmatched:
            if k not in bmap:
                ex.append({"a_row": r["_row"], "a_value": r[a.a_col], "issue": "not found in B"})
            continue
        if k in bmap:
            ex.append({"type": "exact", "a_row": r["_row"], "a_value": r[a.a_col], "b_rows": [x["_row"] for x in bmap[k]]})
        elif a.fuzzy and len(ra) * len(bmap) <= 2_000_000:
            for kb, lst in bmap.items():
                s = SequenceMatcher(None, k, kb).ratio()
                if s >= a.fuzzy:
                    ex.append({"type": "fuzzy", "similarity": round(s, 3), "a_row": r["_row"], "a_value": r[a.a_col],
                               "b_value": lst[0][a.b_col], "b_rows": [x["_row"] for x in lst]})
    emit(a, "overlap", [a.a_file, a.b_file], {"a_col": a.a_col, "b_col": a.b_col, "fuzzy": a.fuzzy, "unmatched": a.unmatched},
         {"a_rows": len(ra), "b_rows": len(rb)}, ex,
         {"blank_a_rows_not_tested": blank_a[:50], "blank_a_count": len(blank_a),
          "caveat": "Name/address similarity alone does not establish a related party or conflict: confirm with registry, declarations and bank data."})


def t_sod(a):
    ha, ra = read(a.a_file)
    hb, rb = read(a.b_file)
    need(ha, a.a_key, a.a_actor, a.a_date)
    need(hb, a.b_key, a.b_actor, a.b_date)
    idx = defaultdict(list)
    for r in ra:
        idx[norm(r[a.a_key])].append(r)
    ex = []
    for r in rb:
        for x in idx.get(norm(r[a.b_key]), []):
            if norm(x[a.a_actor]) and norm(x[a.a_actor]) == norm(r[a.b_actor]):
                item = {"entity": r[a.b_key], "actor": r[a.b_actor], "a_row": x["_row"], "b_row": r["_row"]}
                if a.a_date and a.b_date:
                    d1, d2 = dt(x[a.a_date]), dt(r[a.b_date])
                    if d1 and d2:
                        if date_only(x[a.a_date]) or date_only(r[a.b_date]):
                            d1, d2 = d1.replace(hour=0, minute=0, second=0), d2.replace(hour=0, minute=0, second=0)
                        gap = (d2 - d1).total_seconds() / 86400
                        if a.days is not None and not (0 <= gap <= a.days):
                            continue
                        item["days_between"] = round(gap, 2)
                    else:
                        item["date_unparsed"] = True
                ex.append(item)
    by_actor = Counter(e["actor"] for e in ex)
    emit(a, "sod", [a.a_file, a.b_file], {"a": [a.a_key, a.a_actor], "b": [a.b_key, a.b_actor], "days": a.days},
         {"a_rows": len(ra), "b_rows": len(rb)}, ex, {"by_actor": dict(by_actor),
         "caveat": "Same user on incompatible steps is a control-design lead; verify the system role/permission matrix and compensating approvals."})


def t_recon(a):
    ha, ra = read(a.a_file)
    hb, rb = read(a.b_file)
    keys = a.keys.split(",")
    need(ha, *keys, a.a_val)
    need(hb, *keys, a.b_val)
    A, B = defaultdict(float), defaultdict(float)
    for r in ra:
        A[tuple(norm(r[k]) for k in keys)] += num(r[a.a_val]) or 0
    for r in rb:
        B[tuple(norm(r[k]) for k in keys)] += num(r[a.b_val]) or 0
    label = {tuple(norm(r[k]) for k in keys): tuple(r[k] for k in keys) for r in ra + rb}
    ex, tot, gross, pos, neg_ = [], 0.0, 0.0, [], []
    for k in sorted(set(A) | set(B)):
        av, bv = A.get(k), B.get(k)
        if av is None or bv is None:
            ex.append({"key": label[k], "status": "A_ONLY" if bv is None else "B_ONLY", "a": av, "b": bv})
            continue
        diff = av - bv
        pct = (diff / bv * 100) if bv else None
        if (bv == 0 and av != 0) or (bv != 0 and abs(diff) > a.tol_pct / 100 * abs(bv)):
            ex.append({"key": label[k], "status": "DIFF", "a": round(av, 2), "b": round(bv, 2), "diff": round(diff, 2),
                       "diff_pct_of_b": None if pct is None else round(pct, 1)})
            tot += diff
            gross += abs(diff)
            (pos if diff > 0 else neg_).append(diff)
    emit(a, "recon", [a.a_file, a.b_file], {"keys": keys, "a_val": a.a_val, "b_val": a.b_val, "tol_pct": a.tol_pct},
         {"a_keys": len(A), "b_keys": len(B)}, ex, {"net_difference_over_exceptions": round(tot, 2), "gross_absolute_difference": round(gross, 2),
         "a_greater_than_b_total": round(sum(pos), 2), "a_less_than_b_total": round(sum(neg_), 2),
         "a_only_keys": sum(1 for e in ex if e["status"] == "A_ONLY"), "b_only_keys": sum(1 for e in ex if e["status"] == "B_ONLY"),
         "caveat": "Treat B as the independent source. A difference is an unreconciled quantity until UOM, timing, cut-off and conversion are explained."})


def t_je(a):
    h, rows = read(a.file)
    need(h, a.prepared, a.approved, a.support, a.narr, a.amount, a.date)
    kw = [k.strip().lower() for k in a.keywords.split(",") if k.strip()]
    tests = defaultdict(list)
    for r in rows:
        amt = num(r[a.amount]) or 0
        tag = []
        if norm(r[a.prepared]) and norm(r[a.prepared]) == norm(r[a.approved]):
            tag.append("self_approved")
        if not norm(r[a.approved]):
            tag.append("no_approver")
        if not norm(r[a.support]):
            tag.append("no_support_ref")
        if amt and abs(amt) % a.round_base == 0:
            tag.append("round_amount")
        if any(k in str(r[a.narr]).lower() for k in kw):
            tag.append("adjustment_keyword")
        d = dt(r[a.date])
        if d and d.weekday() in (5, 6):
            tag.append("weekend")
        for t in tag:
            tests[t].append({"row": r["_row"], "amount": amt, "narration": r[a.narr]})
    summary = {t: {"count": len(v), "amount_sum": round(sum(x["amount"] for x in v), 2)} for t, v in tests.items()}
    multi = Counter(x["row"] for v in tests.values() for x in v)
    ex = [{"row": rn, "flags": [t for t, v in tests.items() if any(x["row"] == rn for x in v)]} for rn, c in multi.items() if c >= 2]
    emit(a, "je", [a.file], {"round_base": a.round_base, "keywords": kw}, {"rows": len(rows)}, ex,
         {"flag_summary(not additive)": summary, "exceptions_note": "exceptions = entries with 2 or more flags",
          "caveat": "Self-approval can be a small-entity reality; check delegation of authority and compensating review."})


def t_ratevar(a):
    hi, ri = read(a.inv_file)
    hc, rc = read(a.contract_file)
    need(hi, a.party, a.rate, a.qty)
    need(hc, a.c_party, a.c_rate)
    crate = {}
    multi = set()
    for r in rc:
        k = norm(r[a.c_party])
        v = num(r[a.c_rate])
        if k in crate and crate[k] != v:
            multi.add(k)
        crate.setdefault(k, v)
    ex, tot, over, under, nocontract = [], 0.0, 0.0, 0.0, []
    for r in ri:
        k, ir, q = norm(r[a.party]), num(r[a.rate]), num(r[a.qty])
        if k not in crate:
            nocontract.append(r["_row"])
        if k in crate and ir is not None and q is not None and crate[k] is not None and abs(ir - crate[k]) > 0.005:
            var = (ir - crate[k]) * q
            tot += var
            if var > 0:
                over += var
            else:
                under += var
            ex.append({"row": r["_row"], "invoice_rate": ir, "contract_rate": crate[k], "qty": q, "variance_vs_contract": round(var, 2)})
    emit(a, "ratevar", [a.inv_file, a.contract_file], {"party": a.party}, {"invoices": len(ri)}, ex,
         {"net_variance_vs_contract": round(tot, 2), "overcharge_total": round(over, 2), "undercharge_total": round(under, 2),
          "invoice_rows_with_no_contract_rate": nocontract[:50], "no_contract_count": len(nocontract),
          "parties_with_multiple_contract_rates": sorted(multi),
          "caveat": "Variance is against the supplied price list only. Check amendments, escalation clauses, change orders and the signed agreement before calling it an overcharge."})


# ----------------------------------------------------------------------------- CLI
def build():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--limit", type=int, default=200)
    common.add_argument("--out")

    def add(name, fn, *args):
        s = sub.add_parser(name, parents=[common])
        for spec in args:
            flags, kw = spec[0], spec[1]
            s.add_argument(*flags if isinstance(flags, tuple) else (flags,), **kw)
        s.set_defaults(fn=fn)

    F = lambda **k: (("--file",), dict(required=True, **k))
    add("profile", t_profile, F())
    add("duplicates", t_duplicates, F(), ("--key", dict(required=True)), ("--amount", dict()), ("--party", dict()),
        ("--date", dict()), ("--tol-pct", dict(type=float, default=0.0)), ("--days", dict(type=int, default=7)))
    add("benford", t_benford, F(), ("--col", dict(required=True)), ("--min-n", dict(type=int, default=300)))
    add("splits", t_splits, F(), ("--party", dict(required=True)), ("--amount", dict(required=True)), ("--date", dict(required=True)),
        ("--threshold", dict(type=float, required=True)), ("--days", dict(type=int, default=7)))
    add("round", t_round, F(), ("--amount", dict(required=True)), ("--bases", dict(default="1000,100")))
    add("sequence", t_sequence, F(), ("--col", dict(required=True)))
    add("blanks", t_blanks, F(), ("--col", dict(required=True)), ("--amount", dict()), ("--where", dict()))
    add("calendar", t_calendar, F(), ("--date", dict(required=True)), ("--amount", dict()), ("--weekend", dict(default="5,6")),
        ("--holidays", dict(default="")), ("--after", dict(type=int, default=20)), ("--before", dict(type=int, default=6)))
    add("overlap", t_overlap, ("--a-file", dict(required=True)), ("--a-col", dict(required=True)), ("--b-file", dict(required=True)),
        ("--b-col", dict(required=True)), ("--fuzzy", dict(type=float, default=0.0)), ("--unmatched", dict(action="store_true")))
    add("sod", t_sod, ("--a-file", dict(required=True)), ("--a-key", dict(required=True)), ("--a-actor", dict(required=True)),
        ("--a-date", dict()), ("--b-file", dict(required=True)), ("--b-key", dict(required=True)), ("--b-actor", dict(required=True)),
        ("--b-date", dict()), ("--days", dict(type=float, default=None)))
    add("recon", t_recon, ("--a-file", dict(required=True)), ("--b-file", dict(required=True)), ("--keys", dict(required=True)),
        ("--a-val", dict(required=True)), ("--b-val", dict(required=True)), ("--tol-pct", dict(type=float, default=10.0)))
    add("je", t_je, F(), ("--prepared", dict(required=True)), ("--approved", dict(required=True)), ("--support", dict(required=True)),
        ("--narr", dict(required=True)), ("--amount", dict(required=True)), ("--date", dict(required=True)),
        ("--round-base", dict(type=float, default=10000)),
        ("--keywords", dict(default="adjust,cleanup,clean up,reclass,write-off,write off,plug,correction,true-up")))
    add("ratevar", t_ratevar, ("--inv-file", dict(required=True)), ("--party", dict(required=True)), ("--rate", dict(required=True)),
        ("--qty", dict(required=True)), ("--contract-file", dict(required=True)), ("--c-party", dict(required=True)),
        ("--c-rate", dict(required=True)))
    return p


if __name__ == "__main__":
    PARSER = build()
    args = PARSER.parse_args()
    args.fn(args)
