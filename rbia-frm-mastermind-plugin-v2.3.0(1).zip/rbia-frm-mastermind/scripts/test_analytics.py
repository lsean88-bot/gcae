#!/usr/bin/env python3
"""Tests fraud_analytics.py against the pilot dataset (planted findings) and synthetic Benford populations.
Run: python3 -I scripts/test_analytics.py   (exit 0 = all pass)"""
import csv, json, math, pathlib, random, subprocess, sys, tempfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
TOOL = str(ROOT / "scripts" / "fraud_analytics.py")
D = ROOT / "skills" / "rbia-frm-mastermind" / "evals" / "pilot-simulation" / "data"
res = []


def run(*args):
    r = subprocess.run([sys.executable, "-I", TOOL, *args], capture_output=True, text=True)
    if r.returncode != 0:
        return {"_error": r.stderr.strip()}
    return json.loads(r.stdout)


def t(name, cond, detail=""):
    res.append(cond)
    print(("PASS " if cond else "FAIL ") + name + (f"  [{detail}]" if detail else ""))


f = lambda n: str(D / n)

# 1 duplicate payment of one invoice
r = run("duplicates", "--file", f("payments.csv"), "--key", "Invoice_No", "--amount", "Amount_INR")
ex = [e for e in r["exceptions"] if e["key"]["Invoice_No"] == "SKH-INV-202511"]
t("duplicates: finds invoice paid twice", len(ex) == 1 and abs(ex[0]["repeat_value_potentially_duplicated"] - 373583) < 1, str(ex[:1]))
# 2 missing GRN
r = run("blanks", "--file", f("tolling_invoices.csv"), "--col", "GRN_No", "--amount", "Amount_INR")
t("blanks: invoice without GRN", r["exception_count"] == 1 and abs(r["total_amount"] - 410560) < 1, f"{r['exception_count']} {r['total_amount']}")
# 3 Benford refuses fixed-rate invoices
r = run("benford", "--file", f("tolling_invoices.csv"), "--col", "Amount_INR")
t("benford: NOT_APPLICABLE on 12 fixed-rate invoices, no p-value", r["status"] == "NOT_APPLICABLE" and "p_value" not in r, "; ".join(r.get("reasons", [])))
# 4 SoD: bank change then same user releases payment within 30 days
r = run("sod", "--a-file", f("vendor_master_changes.csv"), "--a-key", "Vendor", "--a-actor", "Changed_By", "--a-date", "Changed_On",
        "--b-file", f("payments.csv"), "--b-key", "Vendor", "--b-actor", "Released_By", "--b-date", "Paid_On", "--days", "30")
t("sod: same user changed bank and released payment", r["exception_count"] >= 1 and set(r["by_actor"]) == {"AP02"}, str(r["by_actor"]))
# 5 SoD: vendor creator also releases payments
r = run("sod", "--a-file", f("vendor_master.csv"), "--a-key", "Vendor_ID", "--a-actor", "Created_By",
        "--b-file", f("payments.csv"), "--b-key", "Vendor", "--b-actor", "Released_By")
t("sod: vendor creator also releases payments", r["exception_count"] > 0 and "AP01" in r["by_actor"], str(r["by_actor"]))
# 6 JE: self-approved, no support
r = run("je", "--file", f("journal_entries.csv"), "--prepared", "Prepared_By", "--approved", "Approved_By", "--support", "Support_Ref",
        "--narr", "Narration", "--amount", "Debit_INR", "--date", "Date")
fs = r["flag_summary(not additive)"]
t("je: 3 self-approved entries totalling 2.1M", fs["self_approved"]["count"] == 3 and fs["self_approved"]["amount_sum"] == 2100000, str(fs.get("self_approved")))
t("je: 3 entries with no support reference", fs["no_support_ref"]["count"] == 3)
# 7 rate variance vs contract
r = run("ratevar", "--inv-file", f("tolling_invoices.csv"), "--party", "Vendor", "--rate", "Rate_INR_per_KG", "--qty", "Qty_KG",
        "--contract-file", f("contract_price_list.csv"), "--c-party", "Vendor", "--c-rate", "Rate_INR_per_KG")
t("ratevar: 7 invoices, variance 235,886", r["exception_count"] == 7 and abs(r["net_variance_vs_contract"] - 235886) < 1, str(r["net_variance_vs_contract"]))
# 8 recon: scrap posted vs weighbridge
r = run("recon", "--a-file", f("scrap_postings.csv"), "--b-file", f("weighbridge_scrap.csv"), "--keys", "Month,Parent",
        "--a-val", "Posted_Scrap_KG", "--b-val", "Weighbridge_KG")
parents = {e["key"][1] for e in r["exceptions"]}
t("recon: only P-1003 exceeds tolerance, net gap 65,107 kg", parents == {"P-1003"} and abs(r["net_difference_over_exceptions"] - 65107) < 1,
  f"{parents} {r['net_difference_over_exceptions']}")
# 9 payments to account not on vendor master
r = run("overlap", "--a-file", f("payments.csv"), "--a-col", "Bank_Account", "--b-file", f("vendor_master.csv"), "--b-col", "Bank_Account", "--unmatched")
t("overlap: payment to bank account not on vendor master", {e["a_value"] for e in r["exceptions"]} == {"XXXX9999"} and len(r["exceptions"]) == 2, str(r["exceptions"][:2]))
# 10 calendar: Saturday payment after bank change
r = run("calendar", "--file", f("payments.csv"), "--date", "Paid_On", "--amount", "Amount_INR")
t("calendar: PAY-5199 date flagged as weekend", any("2026-02-28" in e["date"] for e in r["exceptions"]))
# 11 profile
r = run("profile", "--file", f("payments.csv"))
t("profile: row count and hashes reported", r["population"]["rows"] > 12 and len(list(r["files"].values())[0]) == 64)
# 12 sequence
r = run("sequence", "--file", f("payments.csv"), "--col", "Payment_No")
t("sequence: runs and reports gap ranges", r["status"] == "OK" and r["exception_count"] >= 1)

# 13-15 synthetic: Benford conforming / manipulated / narrow
random.seed(7)
tmp = pathlib.Path(tempfile.mkdtemp(prefix="rbia_an_"))


def write(name, vals):
    p = tmp / name
    with open(p, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["amt"])
        for v in vals:
            w.writerow([round(v, 2)])
    return str(p)


good = [10 ** random.uniform(1, 5) for _ in range(3000)]
r = run("benford", "--file", write("good.csv", good), "--col", "amt")
t("benford: natural population conforms", r["status"] == "OK" and r["MAD"] < 0.006 and r["p_value"] > 0.01, f"MAD={r.get('MAD')} p={r.get('p_value')}")
bad = good[:2100] + [random.uniform(450, 499) for _ in range(900)]
r = run("benford", "--file", write("bad.csv", bad), "--col", "amt")
t("benford: planted manipulation detected", r["status"] == "OK" and r["mad_conformity_nigrini"] == "NONCONFORMITY" and r["p_value"] < 0.001, f"MAD={r.get('MAD')}")
narrow = [random.uniform(300, 480) for _ in range(500)]
r = run("benford", "--file", write("narrow.csv", narrow), "--col", "amt")
t("benford: narrow-range population refused", r["status"] == "NOT_APPLICABLE")

# 16-17 splits, round, near-duplicates
p = tmp / "tx.csv"
with open(p, "w", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["vendor", "amount", "date"])
    for row in [["A", 9000, "2026-01-02"], ["A", 8500, "2026-01-04"], ["B", 9500, "2026-01-02"], ["B", 9500, "2026-02-20"],
                ["C", 10000, "2026-01-05"], ["C", 20000, "2026-01-06"]] + [["D", 1000 * (i + 1), "2026-01-0" + str(i % 9 + 1)] for i in range(40)]:
        w.writerow(row)
r = run("splits", "--file", str(p), "--party", "vendor", "--amount", "amount", "--date", "date", "--threshold", "10000", "--days", "7")
flagged = {e["party"] for e in r["exceptions"]}
t("splits: A flagged (17,500 in 2 days); B (50 days apart) and C (not below threshold) not flagged",
  "A" in flagged and "B" not in flagged and "C" not in flagged, str(sorted(flagged)))
r = run("round", "--file", str(p), "--amount", "amount")
t("round: concentration flagged", r["flagged_base"] == 1000, str(r["shares"]))
r = run("duplicates", "--file", str(p), "--key", "vendor,date", "--amount", "amount", "--party", "vendor", "--date", "date", "--tol-pct", "0", "--days", "3")
t("duplicates: near-duplicate (same vendor, amount, within 3 days) found", any(e["type"] == "near_duplicate" for e in r["exceptions"]) or r["exception_count"] >= 1)

# 18 bad column fails loudly
rr = subprocess.run([sys.executable, "-I", TOOL, "blanks", "--file", f("payments.csv"), "--col", "NoSuchCol"], capture_output=True, text=True)
t("bad column name fails loudly with available columns", rr.returncode != 0 and "Available columns" in rr.stderr)

# 19-26 regression: edge cases found in independent CFE review
tmp = pathlib.Path(tempfile.mkdtemp())
def w(name, text):
    p = tmp / name
    p.write_text(text, encoding="utf-8")
    return str(p)
a1 = w("chg.csv", "Vendor,User,At\nV1,AP02,2026-03-01 17:52:00\n")
b1 = w("pay.csv", "Vendor,User,Paid\nV1,AP02,2026-03-01\nV9,AP02,notadate\n")
r = run("sod", "--a-file", a1, "--a-key", "Vendor", "--a-actor", "User", "--a-date", "At",
        "--b-file", b1, "--b-key", "Vendor", "--b-actor", "User", "--b-date", "Paid", "--days", "3")
t("sod: same-day change-then-pay (timestamp vs date-only) is flagged", len(r["exceptions"]) == 1, str(r["exceptions"]))
cn1 = w("cn1.csv", "Vendor,Amt\n\u6797\u6c0f\u8d38\u6613,100\n")
cn2 = w("cn2.csv", "Vendor,Amt\n\u6797\u6c0f\u8d38\u6613,100\n")
r = run("overlap", "--a-file", cn1, "--a-col", "Vendor", "--b-file", cn2, "--b-col", "Vendor")
t("overlap: non-Latin names match", r["exception_count"] == 1, str(r.get("exceptions")))
z1 = w("z1.csv", "K,V\nA,0\nB,10\n"); z2 = w("z2.csv", "K,V\nA,0\nB,10\n")
r = run("recon", "--a-file", z1, "--b-file", z2, "--keys", "K", "--a-val", "V", "--b-val", "V", "--tol-pct", "0")
t("recon: 0 vs 0 and equal values not flagged", r["exception_count"] == 0, str(r["exceptions"]))
sh = w("short.csv", 'ID,Amt,Note\n1,5\n2,6,"multi\nline"\n3,7,x\n')
r = run("blanks", "--file", sh, "--col", "Note")
rows = sorted(e["row"] for e in r["exceptions"])
t("blanks: short row counted blank and multi-line row numbering correct", rows == [2], str(rows))
r = run("profile", "--file", sh)
t("profile: reports rows with wrong field count", r["input_quality"]["read"][sh]["rows_with_wrong_field_count"] == 1)
sq = w("seq.csv", "Inv\nSKH-INV-202512\nSKH-INV-202601\nSKH-INV-202602\n")
r = run("sequence", "--file", sq, "--col", "Inv")
t("sequence: period-coded numbers produce no false gap", r["exception_count"] == 0, str(r["exceptions"]))
r = run("recon", "--a-file", z1, "--b-file", z2, "--keys", "K", "--a-val", "V", "--b-val", "V")
t("defaults used are disclosed", any("tol_pct" in d for d in r["defaults_used_CONFIRM_WITH_USER"]) and bool(r["script_sha256"]))

n = sum(res)
print(f"\n{n}/{len(res)} passed")
sys.exit(0 if n == len(res) else 1)
