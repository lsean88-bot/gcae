"""Anchored text edits to LIVE skills, verified at apply time against the user's own files.

Each transform takes (text, ctx) and returns new text, returns `text` unchanged when already applied, or raises
EditError(reason) when its preconditions do not hold. EditError means SKIPPED: nothing is forced.
"""
from __future__ import annotations

import re


class EditError(Exception):
    pass


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", s.strip())


def _namespace_texts(doc: str, prefix: str) -> dict[str, str]:
    """{'RACM-01': 'first-line text', ...} from racm-rc-namespaces.md (first line of each item only)."""
    out = {}
    for line in doc.splitlines():
        m = re.match(rf"^({prefix}-\d{{2}}):?\s{{1,}}(.*\S)\s*$", line)
        if m:
            out[m.group(1)] = m.group(2)
    return out


# ---- E1 / E2: apply the 27-28 July namespaces inside the skills --------------------------------
def make_namespace_transform(prefix: str, old_pat: str, new_label, label_width: str):
    def transform(text: str, ctx: dict) -> str:
        doc = ctx.get("namespace_doc")
        if not doc:
            raise EditError("racm-rc-namespaces.md not found (iron-rules-governance not installed)")
        ns = _namespace_texts(doc, prefix)
        if len(ns) != 12:
            raise EditError(f"namespace document defines {len(ns)} {prefix}- items, expected 12")
        lines = text.split("\n")
        idx = [i for i, l in enumerate(lines) if re.match(old_pat, l)]
        if not idx:
            if any(l.startswith(f"{prefix}-") for l in lines):
                return text                                  # already applied
            raise EditError("no bare RULE lines found")
        if len(idx) != 12:
            raise EditError(f"found {len(idx)} bare RULE lines, expected 12")
        stray = len(re.findall(r"\bRULE \d+", text)) - len(idx)
        if stray:
            raise EditError(f"{stray} other 'RULE n' mention(s) would be left pointing at renamed items; edit manually")
        bad, paraphrased = [], []
        for i in idx:
            m = re.match(old_pat, lines[i])
            key = f"{prefix}-{int(m.group(1)):02d}"
            rest = _norm(lines[i][m.end():])
            want = _norm(ns[key])
            if rest == want:
                continue
            wa, wb = set(re.findall(r"\w+", rest.lower())), set(re.findall(r"\w+", want.lower()))
            overlap = len(wa & wb) / max(1, len(wa | wb))
            (paraphrased if overlap >= 0.5 else bad).append((key, rest, want, overlap))
        if bad or len(paraphrased) > 2:
            shown = "; ".join(f"{k}: skill {r[:45]!r} vs approved {w[:45]!r}" for k, r, w, _ in (bad + paraphrased)[:3])
            raise EditError("text differs materially from the approved namespace document: " + shown)
        for k, r, w, ov in paraphrased:      # same position, clear paraphrase: rename the label, keep the skill's own wording
            ctx.setdefault("notes", []).append(
                f"{k}: wording differs from the approved text (word overlap {ov:.0%}); label renamed, wording left as is "
                f"(skill: {r[:60]!r} | approved: {w[:60]!r})")
        for i in idx:
            m = re.match(old_pat, lines[i])
            lines[i] = new_label(int(m.group(1))) + label_width + lines[i][m.end():]
        return "\n".join(lines)
    return transform


t_racm = make_namespace_transform("RACM", r"^RULE (\d{2})  ", lambda n: f"RACM-{n:02d}", "  ")
t_rc = make_namespace_transform("RC", r"^RULE (\d{1,2}):\s+", lambda n: f"RC-{n:02d}:", "  ")


# ---- E3: cae-cowork-ai-plugin quality gate 10 -> canonical 12 ----------------------------------
OLD_GATE = """### 10-Item CAE Quality Gate (all must pass for FINAL)

| # | Check | Group |
|---|-------|-------|
| 1 | Every finding has named evidence or web-validated portal data | Evidence |
| 2 | Every rate web-validated — source URL in Validated Rates Log | Evidence |
| 3 | No duplicate findings — all duplicates merged | Finding Quality |
| 4 | No retracted/draft/CAE-comment text in final report | Finding Quality |
| 5 | No wrong or expired law applied to any finding | Finding Quality |
| 6 | All findings rated with risk colour (CRITICAL/HIGH/MEDIUM/LOW) | Risk |
| 7 | All recommendations SMART — named owner + target date | Risk |
| 8 | Report with version, date, classification, CAE sign-off | Standards |
| 9 | Document reference appendix complete | Standards |
| 10 | Disclaimer present (not statutory audit, not legal opinion) | Standards |
"""
NEW_GATE = """### 12-Item CAE Quality Gate (all must pass for FINAL)

Aligned to the canonical gate (`iron-rules-governance`, Rule 09) on 3 Oct 2026. Items 7 and 8 are the two checks the
earlier 10-item list lacked; the plugin's own QA array must list the same 12 (Rule 30: the asserted count equals the enumerated count).

| # | Check | Group |
|---|-------|-------|
| 1 | Every finding has a named evidence file (R1–R4) or web-validated portal URL — no R5 | Evidence |
| 2 | Every rate / section / threshold web-validated — source URL in Validated Rates Log and recorded in the finding | Evidence |
| 3 | Correct Act + correct effective date + correct jurisdiction — all three verified; no wrong or expired law | Finding Quality |
| 4 | No duplicate findings — all duplicates merged, evidence consolidated | Finding Quality |
| 5 | No retracted/draft/CAE-comment text in final report | Finding Quality |
| 6 | All findings rated with risk colour (CRITICAL/HIGH/MEDIUM/LOW) | Risk |
| 7 | Deficiency classification (CD / SD / MW) documented and defensible | Risk |
| 8 | Aggregation assessment completed — all related deficiencies reviewed together (see Rule 14) | Risk |
| 9 | All recommendations SMART — named owner + target date | Risk |
| 10 | Report version-controlled — version, date, classification, CAE sign-off | Standards |
| 11 | Document reference appendix lists all evidence reviewed | Standards |
| 12 | Disclaimer present (professional IA report — not a statutory audit, CA certificate, or legal opinion) | Standards |
"""


def t_v6_gate(text: str, ctx: dict) -> str:
    if "### 12-Item CAE Quality Gate" in text and OLD_GATE not in text:
        return text
    if text.count(OLD_GATE) != 1:
        raise EditError("the 10-item gate table is not present exactly once in its expected form")
    for old in ("RULE 09  CAE quality gate (10 items) must FULLY pass before report is FINAL",
                "10. CAE Quality Gate Results (10 items + score)"):
        if text.count(old) != 1:
            raise EditError(f"anchor not found exactly once: {old[:50]!r}")
    text = text.replace(OLD_GATE, NEW_GATE)
    text = text.replace("RULE 09  CAE quality gate (10 items) must FULLY pass before report is FINAL",
                        "RULE 09  CAE quality gate (12 items, the canonical gate) must FULLY pass before report is FINAL")
    text = text.replace("10. CAE Quality Gate Results (10 items + score)", "10. CAE Quality Gate Results (12 items + score)")
    return text


# ---- E4: master-audit-superagent gets its own namespace for its local rule list --------------------
def _replace_once(text, old, new, already):
    if already in text and old not in text:
        return text
    if text.count(old) != 1:
        raise EditError(f"anchor not found exactly once: {old[:55]!r}")
    return text.replace(old, new)


def t_mas_skill(text, ctx):
    return _replace_once(
        text, "## Iron Rules (apply in every phase, no exception)",
        "## Master-Agent Operating Rules, namespace MAS (apply in every phase, no exception)\n\n"
        "> These are this skill's own operating rules. They are distinct from the canonical 30 Iron Rules in\n"
        "> `iron-rules-governance`, which also apply.",
        "## Master-Agent Operating Rules, namespace MAS")


def t_mas_protocol(text, ctx):
    text = _replace_once(text, "## 11. Iron Rules (absolute, no exception)",
                         "## 11. MAS Operating Rules (absolute, no exception)",
                         "## 11. MAS Operating Rules")
    return _replace_once(text, "## 12. Golden Rules", "## 12. MAS Golden Rules", "## 12. MAS Golden Rules")


# ---- E5: legacy banner in the description of superseded skills ------------------------------------
BANNER = "LEGACY, superseded (see cae-cowork-ai-plugin). "


def t_legacy(text: str, ctx: dict) -> str:
    if not ctx.get("superseder_installed"):
        raise EditError("cae-cowork-ai-plugin (the declared successor) is not installed; not marking legacy")
    if BANNER in text[:2500]:
        return text
    m = re.match(r"^(---\s*\n(?:.*\n)*?description:\s*>\n  )", text)
    if not m:
        raise EditError("description is not in the expected folded '>' form")
    new = text[:m.end()] + BANNER + text[m.end():]
    fm = re.match(r"^---\s*\n(.*?)\n---", new, re.S).group(1)
    d = re.search(r"^description:\s*>\n((?:[ ]{2}.*\n?)+)", fm + "\n", re.M).group(1)
    if len(re.sub(r"\s+", " ", d).strip()) > 1024:
        raise EditError("banner would push the description over the 1024-character limit")
    return new
