# Assurance and Improvement Reporting Model

Use this model for reports, submissions and briefings to regulators, external auditors,
Boards, Audit Committees, management and other stakeholders. Its purpose is to express
assurance work with constructive leadership, recognisable achievement and practical
Kaizen. It does not alter audit evidence, professional judgement, legal obligations or
the distinction between an observed current state and a planned future state.

## 1. Reporting principles

1. **Evidence first, people always.** State only what the evidence supports; describe
   processes and conditions, never assign personal blame.
2. **Start with contribution.** Lead with the business purpose, validated strengths,
   progress since the prior review and the assurance already obtained.
3. **Every observation becomes a pathway.** Pair each validated current-state result
   with its risk context, improvement opportunity, accountable owner, target date,
   success measure and closure evidence.
4. **Separate three time horizons.** Clearly label: `Validated current state`,
   `Action in progress`, and `Target state / forecast`. A forecast is never a fact.
5. **Balance is complete, not selective.** Show strengths and improvement priorities;
   do not suppress a matter that is material to a regulator, external auditor or other
   decision maker.
6. **Use calibrated assurance.** State scope, period, population or sample, evidence
   basis, limitations and confidence. Do not imply assurance beyond the work performed.

## 2. Required report architecture

1. **Leadership message:** purpose, collaboration and the value protected or created.
2. **Validated achievements:** controls, practices, remediation progress and evidence.
3. **Current assurance view:** scope, methodology, evidence, confidence and boundaries.
4. **Priority improvement opportunities:** factual current state, practical opportunity
   and expected benefit; order by stakeholder relevance and impact.
5. **Kaizen delivery plan:** owner, action, date, measure, dependency and closure proof.
6. **Outlook:** clearly-labelled best-case target scenario, dependencies and next review.
7. **Appendix:** evidence register, detailed test results and regulatory cross-references.

## 3. Approved status language

| Use | Meaning |
|---|---|
| **Operating as evidenced** | The stated design or operation is supported for the defined scope and period. |
| **Established** | Design elements are documented and linked to the relevant risk and objective. |
| **Evidence collection in progress** | The conclusion is pending further evidence; no outcome is implied. |
| **Enhancement opportunity identified** | A specific improvement can strengthen resilience, consistency, coverage or traceability. |
| **Improvement action in progress** | A named owner is progressing an agreed action; cite the plan and current evidence. |
| **Ready with completion plan** | Core requirements are met and remaining actions are owned, dated and tracked. |

Avoid labels that collapse different states into one pessimistic conclusion, such as
`tested — deficient`, `failure`, `fault`, `blame`, or `reject`. Where a statutory,
professional or external-audit term is required, retain that term in the technical
appendix and pair it in the leadership narrative with the evidence, action owner and
improvement path.

## 4. Observation-to-opportunity template

| Element | Required content |
|---|---|
| Achievement / current assurance | Validated strength or the exact evidenced current state. |
| Evidence boundary | Source, period, population or sample, reviewer and confidence. |
| Improvement opportunity | Specific process or control enhancement; no personal attribution. |
| Value expected | Resilience, timeliness, coverage, traceability, compliance confidence or decision quality. |
| Kaizen commitment | Owner, action, target date, success measure and closure evidence. |
| Outlook | Best-case target scenario, explicitly labelled as a forecast and linked to dependencies. |

## 5. Model narrative

> The review confirmed [validated strength] for [scope and period], supported by
> [evidence reference]. To build further resilience and consistency, management and
> assurance partners have agreed [improvement action], owned by [owner] for [date].
> Success will be demonstrated through [measure and closure evidence]. Subject to the
> stated dependencies, the best-case target is [forecast]; this is a forward-looking
> objective rather than a conclusion about the current state.

## 6. Release checks

- Every stated achievement has an evidence reference and defined scope.
- Every technical conclusion retains its required professional or regulatory meaning.
- Every improvement opportunity has an owner, action, date, measure and closure proof.
- Every best-case scenario is labelled as a forecast with dependencies.
- The executive summary contains both validated strengths and priority improvement work.
- Language focuses on systems, evidence, partnership and outcomes, never personal blame.
