# Tool & MCP Usage Policy

Read this when deciding which tool to reach for during an AKOS-orchestrated
engagement. This governs tool selection discipline, not the tools' own mechanics.

## Table of Contents
1. Decision order
2. File/document creation
3. Web search & validation
4. Visual output
5. MCP connectors
6. What never gets automated

---

## 1. Decision Order

1. **Is there already a shared-state file for this engagement?** (Project Memory,
   Knowledge Graph) — read it before reaching for any other tool.
2. **Does a specific MKTRON GIA skill own this content?** Route there
   (`references/plugin-coordination-registry.md`) before improvising a general
   answer.
3. **Does the task need current/external information?** Web search — see Section 3.
4. **Does the task need a deliverable file?** Use the matching format skill
   (`docx`/`xlsx`/`pptx`/`pdf`) — see Section 2.
5. **Does the task need a visual?** See Section 4.
6. **Is there a connected MCP tool that fits?** See Section 5.

---

## 2. File / Document Creation

| Deliverable | Tool |
|---|---|
| Audit report, board paper, formal Word document | `docx` skill |
| RACM, working papers, trackers | `xlsx` skill |
| Board/EXCO deck | `pptx` skill |
| Fillable forms, official PDF output | `pdf` skill |
| Project Memory / Knowledge Graph files | Direct markdown/JSON per this skill's schemas |
| HTML audit report (MKTRON template) | `cae-report-conversion` |

Always check Module 9 Quality Gates have passed *before* formatting — formatting is
the last step in a chain, not a substitute for the QA gate.

---

## 3. Web Search & Validation

Use web search (not memory) for:
- Any statutory rate, threshold, or effective date (Section 4 of
  `references/evidence-and-hallucination-controls.md`).
- Current holders of a regulatory/government position relevant to a jurisdiction.
- Any "is this still in force" question about a law or policy already in Project
  Memory that's more than a few months old.

Do **not** web search for:
- Content that already lives in a domain skill's reference material (check the skill
  first).
- Facts specific to MKTRON itself — those come from the engagement's own documents,
  never from the public web.

---

## 4. Visual Output

| Need | Tool |
|---|---|
| Risk heat map, KPI dashboard | `canvas-design`, `data:build-dashboard`, or the `visualize` tool |
| Process/architecture/relationship diagram | `visualize` tool (diagram module) |
| Knowledge Graph visual | `visualize` tool (diagram module), rendered from `KNOWLEDGE_GRAPH.json` |
| Quick inline chart during analysis | `visualize` tool (chart module) |

Never fabricate data for a visual — every number or node shown must trace back to
Project Memory or the Knowledge Graph.

---

## 5. MCP Connectors

If the user has connectors available for their document/email/calendar systems
(Google Drive, Gmail, Slack, etc.), prioritise those over asking the user to paste
content manually — but always confirm before taking any action that sends, modifies,
or deletes on the user's behalf. Reading is default-on; writing externally requires
explicit confirmation, consistent with general tool-use discipline.

---

## 6. What Never Gets Automated

- Sending a Board/AC communication externally without the user's explicit review and
  send action.
- Deleting or overwriting any file in an engagement's evidence folder.
- Any action that would alter a Confirmed Fact, control design, or audit conclusion
  without a logged Decisions Register entry (Module 11).
