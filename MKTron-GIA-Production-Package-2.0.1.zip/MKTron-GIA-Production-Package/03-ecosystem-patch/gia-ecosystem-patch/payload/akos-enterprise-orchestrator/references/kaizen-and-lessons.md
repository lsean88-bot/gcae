# Kaizen Self-Learning Engine — Retrospective, Lessons, and Prompt Evolution

Read this when actually running a retrospective, writing a lesson, or versioning a
prompt/template. SKILL.md Modules 7 and 8 give the summary; this file gives the exact
formats.

## Table of Contents
1. Retrospective questions
2. Lessons Learned record format
3. Domain categories
4. Promotion rules (lesson → standing rule)
5. Prompt/template version-control format

---

## 1. Retrospective Questions (run after every task of consequence)

- What worked? What failed?
- What required manual correction from the user?
- What caused ambiguity or rework?
- Which questions were unnecessary? Which should have been asked earlier?
- Which template, prompt, or approach produced a better result this time?
- Is this the first time this issue occurred, or has it recurred? (check the error
  pattern library below before answering)

---

## 2. Lessons Learned Record Format

```
Domain           : [one of the categories in Section 3]
Situation        : [what was happening]
Problem          : [what went wrong or could be improved]
Root Cause       : [why it happened, not just what happened]
Resolution       : [how it was fixed this time]
Recommendation   : [what to do differently going forward]
Preventive Action: [concrete step that stops recurrence]
Reusable Pattern : [Yes/No — would this apply beyond this engagement?]
Confidence       : [100%/High/Medium/Low — per Module 10]
Evidence         : [session/date/deliverable this came from]
```

---

## 3. Domain Categories

Internal Audit · ICFR · Risk · Manufacturing · SAP · Finance · Governance ·
Healthcare · India · Malaysia · Mexico · Quality · Engineering

File each lesson under the domain(s) it actually applies to — a lesson can belong to
more than one (e.g., an ICFR lesson from a Malaysia manufacturing engagement files
under both ICFR and Malaysia).

---

## 4. Promotion Rules — Lesson → Standing Rule

Promote a lesson from the log into a standing rule (this skill's own future revision,
or an engagement-level `CLAUDE.md`/memory file) when:

- A correction reveals a missing rule → promote immediately, don't wait for
  recurrence.
- A workflow shortcut is confirmed twice by the user → promote after the 2nd
  confirmation.
- A document naming or referencing pattern is specific to this engagement → promote
  once established.
- A recurring gap in how documents are used appears twice → promote after the 2nd
  occurrence.
- An error pattern recurs 2+ times in any form → promote and add it to the error
  pattern library below.

**Always confirm with the user before the promotion takes effect.** Logging a lesson
in `LESSONS_LEARNED.md` doesn't need sign-off — it's just a record. Promoting it to a
standing rule changes future behaviour across engagements, so state the proposed
rule plainly and wait for a go-ahead rather than silently starting to apply it.

### Starter Error Pattern Library (extend this as real patterns emerge)

| Pattern | Standing Rule |
|---|---|
| Classifying a document without enough evidence to answer the checklist in `knowledge-graph-schema.md` §3 | Raise it as an Outstanding Question instead of guessing |
| Overwriting a Project Memory row instead of superseding it | Always append a new dated row; mark the old one Superseded |
| Reorganising a folder before explaining the taxonomy rationale | Draft the Decisions Register entry first, get sign-off, then move files |
| Treating a workstream blocker as a dead end | Reallocate or request the missing evidence per Module 3 rather than stalling silently |
| Assigning 100% confidence to a repeated but unverified claim | Confidence rises only with new evidence, never with repetition |

---

## 5. Prompt / Template Version-Control Format

Every revision to a prompt, skill, or template (audit report, RCM, board paper,
checklist, SOP, dashboard) records:

```
Version         : [e.g. v1.0 -> v1.1]
Problem Addressed: [what wasn't working]
Improvement      : [what changed]
Expected Benefit : [why this should help]
Regression Risk  : [what could break or get worse]
Validation Status: [Untested / Tested on N cases / Confirmed by user]
Approval Status  : [Draft / Approved]
Date             : [ISO date]
```

Never delete a prior version outright — retire it (mark it superseded, keep it
retrievable) so the full history of the engagement's methodology stays intact. This
mirrors the versioning discipline already used across this skill ecosystem, e.g.
GCAP v7.0 → v7.1 and Super GRC L99 v3.0 → v4.0.
