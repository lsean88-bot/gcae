# Audit Universe & ICFR/RACM Builder

Read this when constructing or maintaining the Group Audit Universe, or building a
Risk and Control Matrix. Complements `cae-command-centre` (which hosts the live Audit
Universe tab) and the entity-specific audit skills (which own the actual control
content) — this file governs the *structural* discipline for building both.

## Table of Contents
1. Audit Universe construction rules
2. Audit Universe entry schema
3. RACM construction rules
4. RACM row schema
5. COSO 2013 (17 Principles) mapping discipline
6. Linking Universe → RACM → Findings in the Knowledge Graph

---

## 1. Audit Universe Construction Rules

1. Every one of the nine MKTRON entities (Section 1 of
   `references/taxonomy-and-metadata-standards.md`) must appear in the universe, even
   if some processes within it haven't yet been risk-assessed — an absent entity is
   a coverage gap, not a "not applicable."
2. Inherent risk ratings must cite their evidence source (prior audit results,
   industry benchmark, management representation) — an unsupported rating fails
   Module 9's "evidence support" gate.
3. Cycle length (annual/biennial/triennial) is a Decisions Register entry, with the
   rationale for why that process warrants that cycle.
4. Re-score inherent risk whenever a material change occurs (new regulation, new
   system, prior period material weakness) — don't let ratings go stale silently.

---

## 2. Audit Universe Entry Schema

| Field | Description |
|---|---|
| Entity | Section 1 code |
| Process/Sub-process | e.g. "Contract Labour Engagement", "AR/Billing" |
| Inherent Risk Rating | High/Medium/Low, with evidence source |
| Last Audited | Date, or "Never audited" |
| Cycle | Annual/Biennial/Triennial, with rationale |
| Owner | Process owner at the entity |
| Regulatory Sensitivity | Which frameworks apply (links to Regulatory Specialist output) |
| Knowledge Graph Node ID | For traceability |

---

## 3. RACM Construction Rules

1. Every control needs: objective, description, type (preventive/detective),
   frequency, owner, and the specific risk it mitigates — a control without a
   mapped risk is a structural gap, not a valid row.
2. Every risk needs at least one mapped control, or an explicit "unmitigated risk"
   flag — never leave a risk row silently uncovered.
3. Assertions covered (existence, completeness, valuation, rights & obligations,
   presentation & disclosure) must be explicit per control — this is what makes the
   RACM usable for SOX 302/404 ICFR testing, not just a risk list.
4. Follow the precedent scale already established (the MKAPL RACM: ~2,000 rows, 18
   process areas, 30 columns) as the reference density for a full-entity RACM — don't
   under-scope a "quick" RACM that can't actually support ICFR testing.

---

## 4. RACM Row Schema

| Field | Description |
|---|---|
| Process Area | One of the 18(+) standard process areas |
| Risk ID | Links to Knowledge Graph Risk node |
| Risk Description | |
| Control ID | Links to Knowledge Graph Control node |
| Control Description | |
| Control Type | Preventive / Detective |
| Control Frequency | Continuous / Daily / Weekly / Monthly / Quarterly / Annual |
| Control Owner | |
| COSO Principle(s) | 1–17 (Section 5) |
| Assertions Covered | Existence / Completeness / Valuation / Rights & Obligations / Presentation & Disclosure |
| Testing Approach | ToD / ToE methodology reference |
| Design Assessment | Established / Enhancement opportunity identified / Evidence collection in progress |
| Operating Assessment | Operating as evidenced / Improvement action in progress / Evidence collection in progress |
| Assessment Basis | Scope, period, population/sample, evidence reference and reviewer |
| Improvement Commitment | Action, accountable owner, target date, success measure and closure evidence |
| Evidence Reference | Evidence Register ID |

---

## 5. COSO 2013 (17 Principles) Mapping Discipline

Map every control to at least one of the 17 Principles across the five components
(Control Environment: 1–5; Risk Assessment: 6–9; Control Activities: 10–12;
Information & Communication: 13–15; Monitoring Activities: 16–17). A control that
can't be mapped to any principle is either mis-scoped or the RACM's process taxonomy
has a gap — flag it as an Outstanding Question rather than forcing a mapping that
doesn't fit.

---

## 6. Linking Universe → RACM → Findings in the Knowledge Graph

```
Audit Universe Entry --scoped_by--> Audit Programme --tests--> RACM Row (Control)
--mitigates--> Risk --informs--> Assurance & Improvement Record --reported_in--> Audit Report
```

Every RACM row that produces a finding should carry a `tested_by` edge back to the
specific audit engagement that tested it — this is what lets `cae-command-centre`
correctly roll up "which controls have never actually been tested" as a coverage gap
at the Group Dashboard level, rather than just showing what's in the RACM on paper.
