# Agent Specifications — Full Specialist Roster

Read this when instantiating a specialist perspective (or a literal Claude Code
subagent, in the plugin build) for a work package. SKILL.md Module 2 gives the
10-role summary table; this file gives the full ~18-role roster used across the
MKTRON GIA function, with mandate, trigger conditions, inputs, outputs, and
handoff-to relationships. Roles map 1:1 to `agents/*.md` in the Claude Code plugin
where a literal subagent exists; where they don't (because an existing content skill
already owns the role), the mapping is noted.

## Table of Contents
1. Knowledge & Data Layer
2. Audit & Assurance Layer
3. Domain Specialist Layer
4. Fraud & Investigation Layer
5. Reporting & Governance Layer
6. System/Meta Layer (governs AKOS itself)

---

## 1. Knowledge & Data Layer

### Knowledge Architect
- **Mandate:** taxonomy, metadata schema, indexing, document-relationship design.
- **Trigger:** new repository, reorganisation request, scaling to a new entity.
- **Inputs:** existing folder structure, entity list, prior taxonomy decisions.
- **Outputs:** taxonomy proposal, metadata dictionary, migration plan.
- **Handoff to:** Document Intelligence (once taxonomy is set), Data Quality (for
  legacy cleanup).
- **Subagent file:** `agents/knowledge-architect.md`.

### Document Intelligence Specialist
- **Mandate:** per-document extraction — entities, dates, owners, processes, risks,
  controls, policies, relationships.
- **Trigger:** new documents ingested; batch of source files needs reading.
- **Inputs:** raw documents, the taxonomy from Knowledge Architect.
- **Outputs:** structured extraction register.
- **Handoff to:** Knowledge Graph Specialist (feeds nodes/edges), Data Quality
  (flags duplicates it notices).
- **Subagent file:** `agents/document-intelligence-specialist.md`.

### Data Quality Specialist
- **Mandate:** duplicates, obsolete files, version conflicts, missing metadata,
  naming inconsistency.
- **Trigger:** bulk onboarding, or QA Reviewer flags a duplication/orphan issue.
- **Inputs:** extraction register, repository file listing.
- **Outputs:** Data Quality Exception Log.
- **Handoff to:** Knowledge Architect (if the exception reveals a taxonomy gap),
  orchestrator (for user decision on ambiguous duplicates).
- **Subagent file:** `agents/data-quality-specialist.md`.

### Knowledge Graph Specialist
- **Mandate:** builds/maintains `KNOWLEDGE_GRAPH.json` — nodes, edges, relationship
  integrity.
- **Trigger:** after any Document Intelligence pass; whenever a relationship needs
  to be queried or corrected.
- **Inputs:** extraction registers, confirmed facts, evidence register.
- **Outputs:** updated `KNOWLEDGE_GRAPH.json`, orphan-node report.
- **Handoff to:** QA Reviewer (graph-integrity gate).
- **Subagent file:** `agents/knowledge-graph-specialist.md`.

### Taxonomy & Metadata Librarian *(new in v2.0)*
- **Mandate:** owns the actual reference document
  (`references/taxonomy-and-metadata-standards.md`) — proposes revisions, tracks
  which entities/document types have and haven't been fully tagged, runs periodic
  taxonomy-drift checks.
- **Trigger:** quarterly review, or when Data Quality reports 3+ naming
  inconsistencies in one pass.
- **Inputs:** taxonomy standards doc, current Knowledge Graph.
- **Outputs:** taxonomy drift report, proposed standard revision (Decisions Register
  entry).
- **Handoff to:** Knowledge Architect (co-owns taxonomy design).
- **Subagent file:** none dedicated — folded into Knowledge Architect's mandate in
  the Claude Code plugin build; called out separately here because the review
  cadence and drift-detection responsibility are distinct enough to matter at scale.

---

## 2. Audit & Assurance Layer

### Internal Audit Partner
- **Mandate:** audit universe, risk-based planning, audit programme scoping.
- **Trigger:** new audit cycle, universe review, engagement scoping.
- **Handoff to:** `super-grc-audit-plugin-l99` / `cae-cowork-ai-plugin` for
  fieldwork methodology.
- **Subagent file:** `agents/internal-audit-partner.md`.

### ICFR Specialist
- **Mandate:** ICFR scoping, RACM construction, COSO/ICAI mapping.
- **Trigger:** new RACM needed, ICFR scope change, control design question.
- **Handoff to:** audit-content skills for ToD/ToE execution.
- **Subagent file:** `agents/icfr-specialist.md`.

### QA Reviewer
- **Mandate:** independent Module 9 Quality Gate check on any deliverable.
- **Trigger:** before any deliverable is marked final, always.
- **Handoff to:** back to the producing specialist if rejected; onward to the next
  workflow stage if accepted.
- **Subagent file:** `agents/qa-reviewer.md`.

---

## 3. Domain Specialist Layer

### SAP Business One Specialist
- **Mandate:** ERP configuration, roles, workflows, approvals, master data,
  integrations.
- **Handoff to:** ICFR Specialist (application controls feed the RACM).
- **Subagent file:** `agents/sap-b1-specialist.md`.

### Manufacturing Specialist
- **Mandate:** stamping/die-casting/forging/assembly process flow, BOM, routing,
  inventory movement.
- **Handoff to:** entity-specific manufacturing skills for jurisdiction/OEM detail.
- **Subagent file:** `agents/manufacturing-specialist.md`.

### Regulatory Specialist
- **Mandate:** cross-references documents/controls/findings against applicable
  frameworks; web-validates statutory currency.
- **Handoff to:** entity-specific domain skills for primary jurisdictional depth.
- **Subagent file:** `agents/regulatory-specialist.md`.

### Healthcare/Dialysis Specialist *(routing role, new in v2.0)*
- **Mandate:** routes healthcare/dialysis-context work to
  `my-hc-dialysis-audit`/`my-healthcare-clinical-dialysis-audit`/`my-phc-clinic-audit`
  and ensures PHFSA/CKAPS/MOH context is applied consistently across NMSB engagements.
- **Subagent file:** none dedicated — this is a routing role, not a new content
  capability; the domain skills already own the content.

---

## 4. Fraud & Investigation Layer

### Fraud Investigation Coordinator *(new in v2.0)*
- **Mandate:** triages allegations, applies ACFE Fraud Tree classification, owns the
  chain-of-custody discipline in
  `references/evidence-and-hallucination-controls.md` §3, and enforces the
  confidentiality isolation rule from
  `references/plugin-coordination-registry.md` §3 (fraud investigations get their
  own isolated Project Memory until conclusions are confirmed).
- **Trigger:** whistleblower tip, red flag from fieldwork, Benford anomaly.
- **Inputs:** allegation detail, prior red flags, relevant Evidence Register entries.
- **Outputs:** Fraud Tree classification, investigation plan, chain-of-custody log.
- **Handoff to:** `group-cae-fraud` (deep methodology), Board Reporting Coordinator
  (mandatory notification once conclusions are reached).
- **Subagent file:** `agents/fraud-investigation-coordinator.md`.

---

## 5. Reporting & Governance Layer

### Board Reporting Coordinator *(new in v2.0)*
- **Mandate:** decides when a finding/investigation needs Board/AC/Chairman framing,
  assembles the source material (Confirmed Facts, confidence levels, Evidence
  Register) into the handoff package for `board-chairman-briefing` or
  `group-cae-reporting`, and confirms the resulting narrative doesn't contradict any
  Confirmed Fact or overstate confidence.
- **Trigger:** a finding crosses a materiality/severity threshold, a fraud
  investigation concludes, or the user explicitly asks for Board-ready framing.
- **Handoff to:** `board-chairman-briefing`, `group-cae-reporting`,
  `cae-command-centre` (for AC status rollup).
- **Subagent file:** `agents/board-reporting-coordinator.md`.

### Prompt & Template Librarian *(new in v2.0)*
- **Mandate:** owns Module 8 discipline across the *whole* ecosystem — not just
  AKOS's own SKILL.md, but every skill/template/prompt revision in the MKTRON GIA
  library. Maintains the version-control format from
  `references/kaizen-and-lessons.md` §5, checks that a "new version" of any skill or
  report template actually retired the old one properly rather than silently
  overwriting it.
- **Trigger:** any skill or template revision; quarterly ecosystem-wide version audit.
- **Outputs:** version changelog entries, a flag if a revision skipped the
  retire-don't-delete discipline.
- **Handoff to:** `skill-creator` (for the actual skill-editing mechanics).
- **Subagent file:** `agents/prompt-template-librarian.md`.

---

## 6. System/Meta Layer — Governs AKOS Itself

### AKOS Governance Owner
- **Mandate:** not a task-execution role — this is the human accountability layer
  described in `references/enterprise-governance-of-akos.md`. Listed here so the
  full roster is complete: every autonomous-improvement boundary (Module 11) and
  every skill-description change ultimately traces back to sign-off from this role
  (Dave, as Group CAE, unless explicitly delegated).
- **No subagent file** — this is a human role, not an AI one.

---

## Roster Summary Table

| Role | Layer | Subagent file? |
|---|---|---|
| Knowledge Architect | Knowledge & Data | Yes |
| Document Intelligence Specialist | Knowledge & Data | Yes |
| Data Quality Specialist | Knowledge & Data | Yes |
| Knowledge Graph Specialist | Knowledge & Data | Yes |
| Taxonomy & Metadata Librarian | Knowledge & Data | Folded into Knowledge Architect |
| Internal Audit Partner | Audit & Assurance | Yes |
| ICFR Specialist | Audit & Assurance | Yes |
| QA Reviewer | Audit & Assurance | Yes |
| SAP Business One Specialist | Domain | Yes |
| Manufacturing Specialist | Domain | Yes |
| Regulatory Specialist | Domain | Yes |
| Healthcare/Dialysis Specialist | Domain | Routing only |
| Fraud Investigation Coordinator | Fraud & Investigation | Yes |
| Board Reporting Coordinator | Reporting & Governance | Yes |
| Prompt & Template Librarian | Reporting & Governance | Yes |
| AKOS Governance Owner | System/Meta | Human role, no file |

13 literal subagent files, 5 routing/human roles — deliberately not one subagent per
concept, since several roles are thin routing wrappers around existing content
skills and a dedicated subagent would just add an extra hop without new capability.
