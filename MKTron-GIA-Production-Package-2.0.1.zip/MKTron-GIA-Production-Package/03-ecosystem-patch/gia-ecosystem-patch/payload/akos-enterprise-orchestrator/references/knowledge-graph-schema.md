# Enterprise Knowledge Graph — Node & Relationship Schema

Read this when actually building or updating `KNOWLEDGE_GRAPH.json` for an engagement.
SKILL.md Module 5 gives the summary; this file gives the exact taxonomy.

## Table of Contents
1. Node types
2. Relationship types
3. Auto-classification checklist for new documents
4. JSON schema
5. Worked examples

---

## 1. Node Types

| Category | Examples |
|---|---|
| Document | Report, SOP, policy, contract, email, minutes, ERP export, invoice |
| Structure | Folder, entity, division, company, department, plant, country |
| Process | Process, sub-process, system, database |
| Governance | Risk, control, policy, procedure, regulation, committee, meeting, decision |
| Assurance | Audit, issue, recommendation, project |
| People | Employee, role, vendor, customer |
| Evidence | Evidence item (cross-references the Evidence Register in Project Memory) |

Every node gets: `id`, `type`, `label`, `entity` (which MKTRON company it belongs to,
or "Group" if cross-entity), `created_date`, `confidence` (Module 10 scale),
`source_location` (original file path — never lose this per Behavioural Rule 2).

---

## 2. Relationship Types

Use directed, labelled edges. Common relationship verbs:

`supports` · `mitigates` · `affects` · `tested_by` · `references` · `reported_in` ·
`owns` · `uses` · `contains` · `implements` · `supersedes` · `depends_on` ·
`belongs_to` · `governs` · `relates_to`

Example chains (illustrative — build the actual chain from what the documents show,
never invent a relationship that isn't evidenced):

```
Policy --supports--> Control --mitigates--> Risk --affects--> Financial Statement
Assertion --tested_by--> Audit Programme --references--> Working Papers --reported_in--> Audit Report

Entity --owns--> Process --uses--> SAP Business One --contains--> Configuration
--implements--> Control --tested_by--> ICFR
```

---

## 3. Auto-Classification Checklist — Run for Every New Document

When a new document enters the repository, determine and record before filing it:

- [ ] What is it? (node type)
- [ ] Who owns it?
- [ ] Which process does it relate to?
- [ ] Which entity/division/plant?
- [ ] Which country/jurisdiction?
- [ ] Which risks does it touch?
- [ ] Which controls does it evidence?
- [ ] Which audit/engagement does it belong to?
- [ ] Which regulation does it map to?
- [ ] Which project?
- [ ] Which SOP governs it?
- [ ] Which findings does it support or contradict?
- [ ] Which prior document(s) does it relate to?
- [ ] What does it supersede, if anything?
- [ ] What depends on it?

If two or more answers are uncertain, this is an Outstanding Question in Project
Memory — don't guess the classification (Behavioural Rule 7).

---

## 4. JSON Schema

```json
{
  "engagement": "string",
  "last_updated": "ISO-8601 date",
  "nodes": [
    {
      "id": "string (stable, e.g. DOC-MKAPL-0142)",
      "type": "Document|Folder|Entity|Division|Company|Department|Process|SubProcess|Risk|Control|Policy|Procedure|Regulation|Audit|Issue|Recommendation|Project|Plant|Country|System|Database|Vendor|Customer|Employee|Role|Committee|Meeting|Decision|Evidence",
      "label": "string",
      "entity": "string (MKAPL-JD|MKAPL-ST|MKAPL-DC|MKSDL|NMSB|MABI|MKPC|Fleet Parade|SAPL|Group)",
      "created_date": "ISO-8601 date",
      "confidence": "100%|High|Medium|Low",
      "source_location": "string (original file path)"
    }
  ],
  "edges": [
    {
      "from": "node id",
      "to": "node id",
      "relationship": "supports|mitigates|affects|tested_by|references|reported_in|owns|uses|contains|implements|supersedes|depends_on|belongs_to|governs|relates_to",
      "evidence": "string",
      "confidence": "100%|High|Medium|Low"
    }
  ]
}
```

---

## 5. Worked Example

```json
{
  "engagement": "MKAPL Diecast Contract Labour Audit",
  "last_updated": "2026-07-18",
  "nodes": [
    {"id": "POL-CLD-01", "type": "Policy", "label": "Contract Labour Engagement Policy",
     "entity": "MKAPL-DC", "created_date": "2025-11-21", "confidence": "100%",
     "source_location": "/HR/Policies/CLD-Policy-v2.pdf"},
    {"id": "CTRL-CLD-01", "type": "Control", "label": "Written Service Agreement Requirement",
     "entity": "MKAPL-DC", "created_date": "2025-11-21", "confidence": "High",
     "source_location": "n/a - control description"},
    {"id": "FIND-CLD-14", "type": "Issue", "label": "CLD-14: Absence of written service agreements",
     "entity": "MKAPL-DC", "created_date": "2026-05-01", "confidence": "100%",
     "source_location": "/Audit/MKAPL-Diecast-Contract-Labour-v5.docx"}
  ],
  "edges": [
    {"from": "POL-CLD-01", "to": "CTRL-CLD-01", "relationship": "supports",
     "evidence": "Policy clause 4.2", "confidence": "100%"},
    {"from": "CTRL-CLD-01", "to": "FIND-CLD-14", "relationship": "tested_by",
     "evidence": "ToD/ToE fieldwork, consolidated v5 report", "confidence": "100%"}
  ]
}
```

This example shows the discipline, not literal content for every engagement — always
build from actual evidence in front of you.
