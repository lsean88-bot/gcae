# Taxonomy & Metadata Standards — MKTRON Group

Read this before creating folders, tagging documents, or assigning IDs in any
MKTRON knowledge repository or Knowledge Graph. Builds on the naming/versioning
lessons already established in the MKTRON HTML report application and skill/plugin
packaging work (see Behavioural Rule 4 in SKILL.md — prefer taxonomy over ad hoc
folders).

## Table of Contents
1. Entity code standard
2. Country/jurisdiction standard
3. Document naming standard
4. Finding/reference ID standard
5. Version stamping standard
6. Metadata field dictionary
7. Folder hierarchy pattern

---

## 1. Entity Code Standard

MKTRON Group's nine entities, with their standard codes (use these exactly — don't
invent variants):

| Code | Entity | Country | Sector |
|---|---|---|---|
| MKAPL-JD | MK Tron Autoparts — Jacks Division | India (Chennai, TN) | Manufacturing |
| MKAPL-ST | MK Tron Autoparts — Stamping | India (Chennai, TN) | Manufacturing |
| MKAPL-DC | MK Tron Autoparts — Die Casting | India (Chennai, TN) | Manufacturing |
| MKSDL | San Luis Dasung S.A. de C.V. | Mexico | Manufacturing |
| NMSB | (Malaysia dialysis healthcare entity) | Malaysia | Healthcare |
| MABI | — | — | — |
| MKPC | MK Tron Precision/Perodua-Denso supplier | Malaysia | Manufacturing |
| Fleet Parade | — | — | — |
| SAPL | — | — | — |

For MKAPL entities operating from both Chennai (Tamil Nadu) and Pune (Maharashtra),
tag both the entity code *and* the state, since statutory frameworks diverge by
state (TN vs MH) even within the same legal entity.

Use `Group` (not blank, not "All") when a document genuinely applies across all nine
entities — e.g. the Master Audit Constitution itself.

---

## 2. Country / Jurisdiction Standard

Use ISO-style short codes consistently: `IN-TN` (Tamil Nadu), `IN-MH`
(Maharashtra), `MY` (Malaysia), `MX` (Mexico), `ME` (Middle East, entity TBD).
Never use a bare "India" or "Malaysia" tag alone when a state/region-specific
statute is in play — GST, minimum wage, professional tax, and labour welfare fund
rates are state-specific in India and this distinction is load-bearing for
compliance conclusions.

---

## 3. Document Naming Standard

Pattern: `[ENTITY]-[DOCTYPE]-[TOPIC]-[PERIOD].[ext]`

Examples (from established precedent):
- `MKAPL-Diecast-Contract-Labour-v5.docx`
- `MKAPL-JAX-HR-MAY2026.html`
- `MKSDL-IAR-May2026.docx`

Doc-type abbreviations: `HR` (HR/payroll audit), `IAR` (Internal Audit Report),
`RACM` (Risk and Control Matrix), `RCM` (same, entity-agnostic use), `FIN`
(fraud investigation), `BRD` (board/AC paper).

**Version suffix:** always `-v[N]` for a document that has gone through revision
cycles, incrementing on every materially revised version — never overwrite a prior
version's filename (this mirrors Module 8's controlled-document discipline).

---

## 4. Finding / Reference ID Standard

Pattern established from the MKAPL Diecast precedent: `[DOCTYPE]-[NN]`, e.g.
`CLD-14` (Contract Labour Diecast, finding 14). Use **three-digit padding**
(`CLD-014`) once a finding set is expected to exceed 99 items, to avoid the sort-order
inconsistency already logged as a recurring defect pattern in the MKTRON HTML report
work (three-digit reference padding inconsistency was one of the six state-persistence
defects resolved in the MKPC L99 report).

Root-cause/enabler findings (like CLD-14, identified as the single root-cause
enabler for 13+ linked findings) should be flagged distinctly in the Knowledge Graph
with a `root_cause_for` relationship to every finding it enables — don't just note
this in prose; make it a queryable graph edge.

---

## 5. Version Stamping Standard

Every controlled document (report, RCM, skill, template) carries:
- Version number (`v1.0`, `v4.0`, `v7.1` — matching the semantic pattern already used
  across GCAP, Super GRC L99, and the MKTRON HTML reports)
- Date of the version
- What changed from the prior version (one line minimum)
- Superseded-by / supersedes links, once a newer version exists

This is the same discipline as Module 8 (Prompt & Template Evolution) — applied here
specifically to naming/versioning of files, not just to prompts.

---

## 6. Metadata Field Dictionary

Minimum fields every document node in the Knowledge Graph should carry (maps to
`references/knowledge-graph-schema.md` node schema):

| Field | Required? | Notes |
|---|---|---|
| entity | Yes | Use Section 1 codes |
| jurisdiction | Yes | Use Section 2 codes |
| doc_type | Yes | Report / SOP / Policy / Contract / Email / Minutes / ERP Export / Invoice |
| period | Yes for time-bound docs | e.g. FY26, MAY2026 |
| owner | Yes if known | else "Not stated" — never guess |
| version | Yes for controlled documents | Section 5 format |
| confidence | Yes | Module 10 scale |
| source_location | Yes | original file path, never lost |

---

## 7. Folder Hierarchy Pattern

Recommended top-level pattern for a new engagement or repository segment (adapt, but
explain any deviation per Behavioural Rule 3):

```
[Entity Code]/
├── 01_Audit_Universe_and_Planning/
├── 02_PBC_and_Evidence/
├── 03_Fieldwork_Workpapers/
├── 04_Findings_and_RACM/
├── 05_Draft_Reports/
├── 06_Final_Reports_and_Board_Papers/
├── 07_Management_Response_and_Followup/
└── _Project_Memory/
    ├── PROJECT_MEMORY.md
    ├── KNOWLEDGE_GRAPH.json
    ├── LESSONS_LEARNED.md
    └── DECISIONS_LOG.md
```

`_Project_Memory/` is prefixed with an underscore so it sorts to the top and is
immediately visible as the "read this first" folder for anyone (human or AI) picking
up the engagement.
