# Evidence Hierarchy & Hallucination-Prevention Controls

Read this whenever citing evidence, making a factual claim, or citing a statutory
reference. This file operationalises "zero assumption, zero hallucination" (the same
spirit as `mac-audit-constitution-l99` Articles 12–13) specifically for the
AKOS orchestration/memory layer.

## Table of Contents
1. The R1–R5 evidence hierarchy
2. Zero-assumption discipline
3. Chain-of-custody for fraud/investigation evidence
4. Statutory citation discipline (web-validation requirement)
5. Hallucination self-check before writing any claim into Project Memory

---

## 1. The R1–R5 Evidence Hierarchy

**Updated 2026-07-27 — merged into the portfolio-canonical hierarchy** (see
`iron-rules-governance/SKILL.md` (section "Evidence Hierarchy (R1–R5)") in the live skill portfolio).
AKOS's original R2/R3 independence split is preserved — it was the one genuine improvement
this table contributed over the prior master definition — but relabeled to match.

| Rank | Description | Example |
|---|---|---|
| R1 | Government portal, gazette, or regulator's official download/certificate | Government gazette notification |
| R2 | System-of-record export, OR an independently-executed reconciliation | SAP transaction log; auditor-prepared reconciliation tying R1 sources together |
| R3 | Signed original/authoritative document **that has also been independently verified** — e.g. a signed contract corroborated against a counterparty copy | Signed board resolution, cross-checked against the minute book |
| R4 | Management-prepared but not independently verified, OR informal but documented | MIS report, management representation letter, email, meeting minutes, chat log |
| R5 | Verbal / undocumented | Interview statement with no corroborating document |

**Rule: R5 evidence is never cited standalone in a finding.** It can motivate further
testing (raise it as an Outstanding Question or trigger a targeted R1–R3 evidence
request) but never stand alone as the basis for a Confirmed Fact or a finding
conclusion.

Every Evidence Register entry (`references/project-memory-schema.md` §7) carries its
R-rank. A finding's overall confidence (Module 10) is bounded by its weakest
load-bearing evidence — a finding resting on one R4 email cannot be 100% confidence
regardless of how compelling the email reads.

---

## 2. Zero-Assumption Discipline

1. **Never supply an unstated assumption that makes a conclusion look better
   supported than it is.** If a document doesn't state an owner, the owner field is
   "Not stated" — not a plausible guess.
2. **Never fill a gap with "typically" or "usually" reasoning** when the actual
   entity's documents are available to check. Industry-typical practice is
   background context for *interpreting* evidence, not a substitute for evidence.
3. **Every extrapolation must be labelled as an extrapolation**, with its own
   (necessarily lower) confidence score, distinct from the fact it extrapolates from.
4. **When two documents conflict, record the conflict** as an Outstanding Question —
   don't silently prefer one and discard the other's existence.

---

## 3. Chain-of-Custody for Fraud/Investigation Evidence

For any evidence handled under `group-cae-fraud` or the Fraud Investigation
Coordinator role:

| Field | Required |
|---|---|
| Evidence ID | Yes |
| Source | Where/who it came from |
| Date/Time Obtained | Yes |
| Obtained By | Yes |
| Storage Location | Yes (including access-control state) |
| Handling Log | Every access/transfer, dated |
| Integrity Check | Hash/checksum if digital, seal reference if physical |

Do not summarise or paraphrase primary fraud evidence into Project Memory in a way
that loses the original — always retain (or clearly reference) the original file
alongside any summary, since an investigation's evidentiary value depends on
unaltered originals being retrievable.

---

## 4. Statutory Citation Discipline (Web-Validation Requirement)

**Never cite a rate, section number, threshold, or effective date from training-data
memory.** Regulatory frameworks in this ecosystem change on a rolling basis (see the
effective-date corrections already logged across India Labour Codes, Malaysia
Minimum Wage Order revisions, PDPA amendments, etc.). Before any statutory citation
goes into a Confirmed Fact or a final deliverable:

1. Confirm the correct Act/standard name.
2. Confirm the effective date currently in force (not just the date the provision
   was originally enacted — many provisions have staged effective dates).
3. Confirm jurisdiction match — country **and** state/region where relevant (Section
   2 of `references/taxonomy-and-metadata-standards.md`).
4. If web validation isn't possible in the current context, mark the citation
   Medium confidence at most and flag it as an Outstanding Question requiring
   validation before the deliverable is finalised.

This is the Regulatory Specialist's core operating rule (see
`agents/regulatory-specialist.md`), but it applies to *any* skill making a
statutory claim, not just that role.

---

## 5. Hallucination Self-Check Before Writing Any Claim into Project Memory

Before adding a row to the Confirmed Facts register, ask:

- Can I point to the specific document/system/page that supports this?
- Is the confidence level actually earned by that evidence's R-rank (Section 1)?
- Would this claim survive being shown to the person who provided the source
  document?
- If I'm wrong about this, what downstream conclusions would also be wrong — and am
  I comfortable with that blast radius given the confidence I'm about to assign?

If any answer is uncertain, the claim belongs in Outstanding Questions or the
Assumptions Register (Module 4), not Confirmed Facts.
