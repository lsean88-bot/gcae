# Domain Knowledge Models — SAP Business One & Manufacturing

Read this for structural guidance on how ERP and manufacturing-process knowledge
should be represented in the Knowledge Graph. For the underlying audit content
(statutory rates, OEM-specific CSRs, alloy chemistry), defer entirely to the domain
skills (`my-mkpc-mfg-audit`, `mx-manufacturing-audit`, `in-manufacturing-audit`,
`my-mfg-diecast-stamping-audit`) — this file governs *how the AKOS layer models*
that content, not the content itself.

## Table of Contents
1. SAP Business One knowledge model
2. Manufacturing process knowledge model
3. Shared control points between SAP and manufacturing

---

## 1. SAP Business One Knowledge Model

### Node types specific to ERP analysis
Add to the standard Knowledge Graph node types (`references/knowledge-graph-schema.md`):
`Role` (SAP authorisation role), `ApprovalWorkflow`, `MasterDataObject` (BP master,
item master, chart of accounts), `Integration` (EDI, bank interface, third-party
system).

### Representation pattern

```
Entity --owns--> Process --uses--> SAP Business One --contains--> Configuration
(e.g. approval workflow, authorisation role) --implements--> Control
--tested_by--> ICFR
```

### Discipline
1. Distinguish **configuration facts** (what the system is set to do — verifiable
   directly, can carry 100% confidence) from **process facts** (what people actually
   do — needs corroboration from logs/transaction data before exceeding Medium
   confidence).
2. Segregation-of-duties (SoD) conflicts are findings, derived from the actual
   role/authorisation matrix — never asserted from a generic SoD checklist without
   confirming against the entity's actual configuration.
3. Master data governance issues (duplicate BP/item records, uncontrolled changes)
   feed the Data Quality Specialist's exception log using the same format as document
   duplicates — a master data record is a node like any other.

---

## 2. Manufacturing Process Knowledge Model

### Node types specific to manufacturing analysis
`ProductionLine`, `BOM` (Bill of Materials), `Route`/`Routing`, `WorkCenter`,
`ScrapAccount`, `MTC` (Material Test Certificate).

### Representation pattern

```
Entity --operates--> ProductionLine --follows--> Routing --consumes--> BOM
--yields--> FinishedGood + Scrap --reconciled_by--> MTC/Weigh-Gate Record
--tested_by--> Audit Programme
```

### Discipline
1. **Material balance findings need the calculation shown**, not just a stated
   conclusion — BOM yield variance = (theoretical consumption per BOM) vs (actual
   consumption per issue records), traceable to specific batches/work orders.
2. **Scrap/yield anomalies need two independent evidence sources** before being
   escalated beyond Medium confidence (e.g. weigh-gate record *and* GL scrap account
   *and* MTC, not just one) — a single data point is not enough for a fraud-adjacent
   conclusion like diversion.
3. Tooling governance (die/mould lifecycle, maintenance records) is tracked as its
   own node type (`Tooling`) with `maintained_by` and `used_in` edges to
   ProductionLine — tooling failures are a distinct risk category from process
   deviations.

---

## 3. Shared Control Points Between SAP and Manufacturing

Several controls span both domains and should carry edges to *both* an SAP
Configuration node and a manufacturing Process node — don't force these into only
one domain:

- **Production order release** — SAP workflow approval + shop-floor routing
  adherence.
- **Scrap booking** — SAP GL posting + physical weigh-gate/scrap yard record.
- **Inventory movement (GRN, issue, transfer)** — SAP transaction + physical
  warehouse movement (FIFO adherence, WMS if present).
- **Standard cost / BOM maintenance** — SAP master data change control + engineering
  change notice (ECN) process.

Modelling these as dual-domain nodes is what lets the Knowledge Graph correctly
surface a finding like "scrap booked in SAP doesn't reconcile to weigh-gate
records" as a single connected issue, rather than two disconnected observations that
a human has to manually notice are related.
