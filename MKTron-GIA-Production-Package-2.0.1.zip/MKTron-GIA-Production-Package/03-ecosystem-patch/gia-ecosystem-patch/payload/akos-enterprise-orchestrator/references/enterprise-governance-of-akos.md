# Enterprise Governance of AKOS — Governing the AI System Itself

Read this when a change to AKOS's own rules, descriptions, or boundaries is being
considered, or when explaining to a stakeholder how this AI system is itself
governed. AKOS applies rigorous governance to audit content — this file applies the
same discipline to AKOS as a system.

## Table of Contents
1. Why the system needs its own governance
2. Roles and accountability
3. Change control for AKOS itself
4. Risk register for the AI system
5. Success metrics
6. Review cadence

---

## 1. Why the System Needs Its Own Governance

An orchestration/memory layer that can propose taxonomy changes, score its own
confidence, and decide what to escalate is powerful precisely because it operates
with real latitude (Module 11 — Autonomous Improvement Boundaries). Latitude without
accountability is a control gap by the same logic AKOS applies to everything else it
reviews. This file closes that gap.

---

## 2. Roles and Accountability

| Role | Who | Accountable for |
|---|---|---|
| AKOS Governance Owner | Group CAE (Dave / Lau Soon Hock), unless explicitly delegated | Final sign-off on any change to AKOS's boundaries, description, or module rules |
| Specialist Lens User | Whoever is running the session | Following the rules as written; flagging when a rule seems wrong rather than silently working around it |
| Kaizen Reviewer | Whoever runs the retrospective (Module 7) | Deciding which lessons get promoted to standing rules |
| Prompt & Template Librarian | Dedicated role (`agents/prompt-template-librarian.md`) | Version-control hygiene across the whole skill ecosystem, not just AKOS |

No AI instance — including AKOS itself — has standing authority to change Module 11's
boundary list. That list can only be revised by the Governance Owner, with a
Decisions Register entry stating why.

---

## 3. Change Control for AKOS Itself

Any change to `SKILL.md`, a reference file, or an agent specification follows the
same discipline Module 8 requires of audit templates:

1. State the problem being addressed.
2. State the proposed change and expected benefit.
3. State the regression risk — what could this change break elsewhere in the
   ecosystem (check `references/plugin-coordination-registry.md` for anything that
   depends on the thing being changed).
4. Validate — run the relevant eval cases (`evals/evals.json` and the trigger-eval
   set) before treating the change as final.
5. Get sign-off from the Governance Owner for anything touching Module 11 boundaries,
   the description (trigger behaviour), or the shared-state file schemas (a schema
   change affects every other skill reading/writing those files).
6. Version and retire, never silently overwrite (Module 8).

---

## 4. Risk Register for the AI System

| Risk | Description | Mitigation |
|---|---|---|
| Over-reliance | Users treat AKOS output as final without independent review | Module 9 QA gate is mandatory before "final"; sign-off record makes review status visible |
| Confidence inflation | A fact gets treated as more certain than its evidence supports | Module 10 scoring rules + evidence-hallucination controls (Section 5 self-check) |
| Silent scope creep | AKOS starts making content decisions that belong to a domain skill | Module 13 / plugin-coordination-registry routing discipline; "AKOS never re-derives domain content" |
| Taxonomy drift | Naming/tagging standards diverge across engagements over time | Taxonomy & Metadata Librarian role; periodic drift review |
| Stale regulatory citations | A statutory fact ages out of currency silently | Web-validation requirement (evidence-and-hallucination-controls §4); no citation from memory alone |
| Fraud evidence exposure | Investigation Knowledge Graph nodes leak into unrelated engagement context | Confidentiality isolation rule (plugin-coordination-registry §3) |
| Skill-description mis-triggering | AKOS triggers when it shouldn't (adds noise) or fails to trigger when it should (loses value) | Trigger-eval loop (see `evals/` and `EVAL_REPORT.md`); periodic re-run as the ecosystem grows |
| Prompt/template sprawl | Multiple divergent versions of the "same" template exist without clear authority | Prompt & Template Librarian; retire-don't-delete discipline |

---

## 5. Success Metrics

Track these qualitatively each quarter (formal quantitative tracking is a future
enhancement, not assumed to exist yet):

- **Coverage:** % of active engagements with a populated `PROJECT_MEMORY.md` and
  `KNOWLEDGE_GRAPH.json` (target: 100% of multi-session engagements).
- **Rework rate:** how often a deliverable is rejected at the Module 9 QA gate
  (trending down is good — it means upstream quality is improving, not that QA is
  getting looser).
- **Lesson promotion rate:** how many Kaizen lessons get promoted to standing rules
  vs. logged and forgotten — a healthy system promotes lessons, it doesn't just
  accumulate an ever-growing unread log.
- **Cross-skill consistency:** spot-checked — do independently produced deliverables
  from the same engagement agree on entity codes, finding IDs, and confidence levels?
- **Trigger accuracy:** from the eval loop — is AKOS engaging when it should and
  staying quiet when it shouldn't?

---

## 6. Review Cadence

- **Every engagement close:** Kaizen retrospective (Module 7).
- **Quarterly:** Taxonomy drift review, prompt/template version audit, risk register
  review (Section 4).
- **On any Module 11-boundary-adjacent request:** immediate Governance Owner
  sign-off before proceeding, not after.
- **On ecosystem growth** (new skill added, new entity onboarded): re-run the
  trigger-eval set to confirm AKOS still routes correctly against the larger
  registry.
