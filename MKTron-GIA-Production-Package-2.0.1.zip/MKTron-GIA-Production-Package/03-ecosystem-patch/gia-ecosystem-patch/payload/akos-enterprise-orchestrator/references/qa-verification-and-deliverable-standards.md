# QA Verification Framework & Deliverable Standards

Read this before calling any deliverable final. Expands SKILL.md Module 9 into a
runnable checklist, and sets the format standard for each deliverable type,
including executive dashboards.

## Table of Contents
1. The expanded Quality Gate checklist
2. Deliverable format standards
3. Executive dashboard standards
4. Visual-tool selection matrix
5. Sign-off record

---

## 1. The Expanded Quality Gate Checklist

Run every item; record the validated strength, evidence still required, and practical
completion action with specifics, not just a checkmark:

**Content integrity**
- [ ] Completeness — every section the deliverable's own structure promises is
  present
- [ ] Accuracy — every stated fact traces to a Confirmed Fact or properly-ranked
  evidence
- [ ] Evidence support — no claim exceeds what its R-rank (evidence hierarchy)
  justifies
- [ ] No fabricated specifics — dates, amounts, names all trace to source

**Consistency**
- [ ] Internal consistency — the document doesn't contradict itself
- [ ] Cross-document consistency — doesn't contradict other deliverables from the
  same engagement
- [ ] Terminology consistency — entity codes, finding IDs, process names match
  `references/taxonomy-and-metadata-standards.md`
- [ ] Regulatory alignment — citations match the Regulatory Specialist's validated
  output, not a separate unchecked claim

**Structural integrity**
- [ ] Logical consistency — conclusions follow from stated evidence, not from
  unstated leaps
- [ ] No duplication — the same finding/fact isn't double-counted under two IDs
- [ ] No orphan records — every Knowledge Graph node has ≥1 relationship
- [ ] No broken references — every citation/ID mentioned actually resolves to a
  real Evidence Register or Knowledge Graph entry

**Governance**
- [ ] Confidence levels are earned, not inflated (Module 10)
- [ ] Any change to a previously Confirmed Fact/policy/control has a Decisions
  Register entry (Module 11)
- [ ] Chain-of-custody intact for any fraud-related evidence (Section 3 of
  `references/evidence-and-hallucination-controls.md`)

Run this from the QA Reviewer lens (Module 2), deliberately separate from whoever
produced the work.

---

## 2. Deliverable Format Standards

| Deliverable | Structure to follow |
|---|---|
| Audit report | Dave's 13-section structure: Executive Summary → Background → Scope & Objectives → Methodology → Detailed Observations → Risk & Impact → Root Cause → Control Gap Assessment → Recommendation → Management Response → Agreed Action Plan → Timeline & Accountability → Conclusion |
| Board/AC paper | `board-chairman-briefing` strategic-reframing structure — business impact first, compliance mechanics second |
| RACM | Schema in `references/audit-universe-and-icfr-builder.md` §4 |
| Project Memory | Schema in `references/project-memory-schema.md` |
| Knowledge Graph | Schema in `references/knowledge-graph-schema.md` |
| Investigation report | ACFE/CFE structure per `group-cae-fraud` |

Every deliverable's recommendations must be SMART (Specific, Measurable, Achievable,
Relevant, Time-bound) — a recommendation that fails this test is incomplete, not
just stylistically weak.

For regulator, external-auditor, Board and stakeholder reports, use
`assurance-and-improvement-reporting.md` as the primary narrative standard: begin with
validated achievements, state current assurance with its evidence boundary, and turn
each improvement priority into an owner-led Kaizen commitment. Keep technical terms
required by law or professional standards intact in the detailed appendix.

---

## 3. Executive Dashboard Standards

For any Group Dashboard, risk heat map, or KPI view (typically produced via
`cae-command-centre` or the `visualize`/`canvas-design` tools):

- **Risk heat map:** 5×5 ISO 31000 grid (Likelihood × Impact), colour-coded, every
  plotted risk traceable to a Knowledge Graph Risk node — never a decorative heat map
  with invented positions.
- **KPI cards:** each KPI states its formula, data source, and as-of date — a KPI
  without a stated source is not audit-grade.
- **Assurance and progress panel:** show validated strengths, current assurance,
  improvement actions in progress and the next target milestone. Each measure must be
  evidence-linked; a future milestone cannot be displayed as an achieved result.
- **Status/RAG indicators:** Red/Amber/Green thresholds must be defined once and
  applied consistently across every dashboard in the engagement — don't let the
  threshold for "Red" silently shift between reports.

---

## 4. Visual-Tool Selection Matrix

| Visual need | Tool |
|---|---|
| One-off inline chart while discussing analysis | `visualize` (chart module) |
| Standalone shareable dashboard file | `canvas-design` or `data:build-dashboard` |
| Process/relationship diagram | `visualize` (diagram module) |
| Full Knowledge Graph exploration view | `visualize` (diagram module), generated from `KNOWLEDGE_GRAPH.json` |

---

## 5. Sign-Off Record

Every deliverable that passes the Quality Gate gets a short sign-off block appended
(not a separate file, just a footer):

```
QA Reviewed: [date] | Release Readiness: Ready for release / Ready with completion plan / Continue development
Reviewer Lens: QA Reviewer (independent pass)
Validated strengths: [list]
Completion actions: [owner, action, date, closure evidence; or "None"]
```

This gives the next skill in the coordination chain (Section 5 workflows in
`references/plugin-coordination-registry.md`) a fast way to confirm a deliverable is
safe to build on without re-running the whole gate itself.
