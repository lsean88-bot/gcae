# Plugin Coordination Registry — How AKOS Interlinks the MKTRON GIA Skill Ecosystem

Read this whenever a task will touch more than one skill, or when you need to decide
*which* skill should own a piece of work. SKILL.md Module 13 gives the one-line
routing table; this file gives the actual handoff contracts, shared-state
conventions, conflict-resolution rules, and worked coordination workflows.

## Table of Contents
1. Why coordination needs a contract, not just a routing table
2. Shared-state convention (how skills talk to each other without talking)
3. The full skill registry with handoff contracts
4. Conflict resolution — when two skills could both claim a task
5. Worked coordination workflows (end-to-end, multi-skill)
6. Sequencing patterns
7. What AKOS never delegates

---

## 1. Why Coordination Needs a Contract, Not Just a Routing Table

A routing table (Module 13) tells you *which* skill to call. It doesn't tell you
*what that skill expects as input*, *what it will hand back*, or *what happens to
that output next*. Without a contract, coordination degrades into re-explaining
context to every skill from scratch — which defeats the purpose of a shared Project
Memory and Knowledge Graph. Every skill in this registry gets a contract: **Reads**,
**Produces**, **Writes back to shared state**, **Typically followed by**.

---

## 2. Shared-State Convention

Every skill in this ecosystem that touches a multi-session engagement should read
and write the *same* engagement-level files, using the schemas in
`references/project-memory-schema.md` and `references/knowledge-graph-schema.md`:

| File | Who writes to it | Who reads it |
|---|---|---|
| `PROJECT_MEMORY.md` / `.json` | Every skill, after any material output | Every skill, at the start of any work on that engagement |
| `KNOWLEDGE_GRAPH.json` | Knowledge Graph Specialist (directly); other skills hand their extraction results to it | Any skill needing entity/process/risk/control context |
| `LESSONS_LEARNED.md` | Any skill, after a retrospective (Module 7) | AKOS at session start; skill-creator when a skill itself needs revising |
| `DECISIONS_LOG.md` | Any skill making a structural/methodological choice | Any skill checking whether a taxonomy/scope/naming decision already exists |

**This is what makes "interlink" real, not aspirational:** a finding drafted by
`cae-cowork-ai-plugin` should already be a node in `KNOWLEDGE_GRAPH.json` and
an Evidence Register entry before `board-chairman-briefing` ever touches it — so the
Board briefing doesn't have to re-derive the finding's context, and the Knowledge
Graph doesn't silently drift out of sync with what's actually been reported.

If an engagement folder has no `PROJECT_MEMORY.md` yet, any skill that would
otherwise start multi-session work should create the skeleton (Module 4) or prompt
the user to run `/akos-init` (plugin) before proceeding — don't let a skill start
"memoryless" work on something that will clearly span sessions.

---

## 3. The Full Skill Registry — Handoff Contracts

### Constitutional / Foundational Layer

**`iron-rules-governance`** — *corrected 27 September 2026; see note below*
- *Reads:* nothing engagement-specific — this is the constitutional ruleset (the
  Golden Rule, 30 Iron Rules, Evidence Hierarchy R1-R5, 12-item Quality Gate,
  Charlie Hills protocol).
- *Produces:* the rules other skills operate under, not deliverables itself.
- *Writes back:* nothing directly — its rules are enforced *by* every other skill.
- *Typically followed by:* whatever skill is actually doing the audit work.
- *Coordination note:* treat this as always-on background law, not a step in a
  workflow. AKOS's own Module 9-11 (quality gates, confidence, boundaries) are
  designed to be consistent with it, not a competing ruleset.

  **Correction, 27 September 2026 (Rule 27 applied — re-verified against live
  source rather than repeated as-is):** this entry previously named
  `mac-audit-constitution-l99` as the constitutional layer, with a "27-item
  quality gate." Checked against the actually-installed skill catalog: that skill
  does not currently exist in it. `iron-rules-governance`'s own reconciliation
  history records `mac-audit-constitution-l99` as reconciled and "de-framed from
  competing MASTER status" in July 2026 — of its 27 asserted Articles, only 15
  overlapped the canonical set; it was not a second valid 27-item gate, it was
  the drift `iron-rules-governance` exists to resolve. This registry pointed at
  the wrong file for over two months. Not established this session: whether
  `mac-audit-constitution-l99`'s absence from the catalog is an intentional
  retirement or an accidental drop — worth confirming, not assuming either way.

**`super-grc-audit-plugin-l99`**
- *Reads:* engagement scope, audit universe entry, prior walkthrough notes if any.
- *Produces:* Walkthrough documentation, ToD/ToE results, deficiency aggregation,
  5C findings.
- *Writes back:* Confirmed Facts (control descriptions), Evidence Register entries,
  Knowledge Graph nodes (Control, Risk, Deficiency) and edges (`tested_by`).
- *Typically followed by:* `cae-report-conversion` (to publish), or
  `board-chairman-briefing` (to elevate a finding).

**`cae-cowork-ai-plugin`** (supersedes v4/v5; contract also in the Lifecycle layer below)
- *Reads:* PBC list, prior fieldwork state, sample selections already made.
- *Produces:* Fieldwork documentation with AI-augmented Benford/variance analysis,
  findings pipeline entries, CAE quality gate results.
- *Writes back:* Evidence Register, Knowledge Graph (Document, Finding nodes),
  Outstanding Questions for anything fieldwork couldn't resolve.
- *Typically followed by:* `cae-report-conversion`, `group-cae-fraud` (if fieldwork
  surfaces a red flag), or the entity-specific skill for deeper domain testing.

### Engagement Lifecycle, Data & Engineering Layer

> *Added v2.3 (3 Oct 2026). These contracts are derived from each skill's own frontmatter description, not from
> a line-by-line read of every skill: owner to confirm or amend. Where a skill declares supersession in its own
> metadata, the declaration is quoted here, not decided here.*

**`cae-cowork-ai-plugin`** (v6.0)
- *Reads:* engagement scope, PBC/document inventory, prior fieldwork state.
- *Produces:* fieldwork (TP01-TP14), compliance validation, reconciliation tests, findings pipeline with CD/SD/MW
  aggregation, report, management-response and follow-up panels, AI-assisted analytics (Benford, variance,
  duplicate, outlier).
- *Writes back:* Evidence Register, Knowledge Graph (Document, Issue nodes), Outstanding Questions, Decisions Register.
- *Typically followed by:* `cae-report-conversion`, `group-cae-fraud-v2` (if fieldwork surfaces a red flag), or the
  entity-specific skill for deeper domain testing.
- *Coordination note:* its own metadata declares that it supersedes `cae-audit-cowork-plugin-v4` and
  `cae-audit-cowork-plugin-v5`, which are therefore superseded legacy skills kept only for engagements already begun
  on them. New work routes here. Its text still asserts a "10 items" CAE quality gate under its Rule 09 where the
  canonical gate has 12 (Decision D5).

**`racm-ecosystem`**
- *Reads:* RACM/RCM workbook, ICFR scope, control population.
- *Produces:* scoped RACM, COSO IC 2013 mapping, key-control identification, ToD/ToE structure, SD/MW/MN deficiency
  classification, red-flag surveillance, audit plan.
- *Writes back:* Knowledge Graph (Risk, Control nodes), Evidence Register, Decisions Register.
- *Typically followed by:* `cae-cowork-ai-plugin` (fieldwork), `board-chairman-briefing`.
- *Coordination note:* owns its own `RACM-`/`RC-` numbering namespace (`references/racm-rc-namespaces.md`). Do not
  renumber its items into the canonical Iron Rules list.

**`master-audit-superagent`**
- *Reads:* engagement brief and any existing Project Memory.
- *Produces:* an end-to-end lifecycle run through a 17-agent specialist team, ending in a QA-gated decision-ready report.
- *Writes back:* Evidence Register, findings, Decisions Register.
- *Typically followed by:* `cae-report-conversion`, `board-chairman-briefing`.
- *Coordination note:* overlaps AKOS's own orchestration role. Whichever of the two is already running the engagement
  leads (Module 1); the other joins as a team member. It carries its own "Iron Rules" header, which the drift check
  flags (Decision D7).

**`mktron-gia-data-reconciliation`**
- *Reads:* the 06_DATA JSON layer (entities, engagements, risk_register, racm, entity_risk_profiles, audit_plan).
- *Produces:* a reconciled data layer, regenerated AUDIT_PLAN.csv/xlsx, the rolling 12+12 month audit plan.
- *Writes back:* Decisions Register; Outstanding Questions for data conflicts it cannot resolve.
- *Typically followed by:* `cae-command-centre` (audit universe and annual plan). Owner to confirm.
- *Coordination note:* the 06_DATA JSON layer is a second store of entities, risks and RACM beside
  `KNOWLEDGE_GRAPH.json`. Do not hand-merge them: run this skill first, then update the Knowledge Graph through Module 11.

**`charlie-hills-code`**
- *Reads:* any coding, bug, architecture or technical-planning task.
- *Produces:* plan-first execution, task files, verified changes.
- *Writes back:* Decisions Register (technical choices); recurring-pattern lessons as LESSONS_LEARNED candidates.
- *Typically followed by:* `debugger` for end-to-end UAT of HTML/GIA apps.
- *Coordination note:* carries its own "CLAUDE.md Self-Update Rule", a second self-learning description. AKOS Module 7
  is canonical. Its structure also differs from the five-phase summary in `iron-rules-governance` (known open item, D6).

**`debugger`**
- *Reads:* an error, stack trace, unexpected behaviour or UAT request, including the MKTron GIA HTML app (v7-v9).
- *Produces:* root-cause diagnosis, fix, UAT results (functional, offline, localStorage, responsive, accessibility).
- *Writes back:* LESSONS_LEARNED candidates for recurring app bugs; Decisions Register.
- *Typically followed by:* return of control to the calling skill.

### Domain Content Layer (entity/jurisdiction-specific)

**`chennai-india-ops-audit`, `pune-india-ops-audit`, `my-mkpc-mfg-audit`,
`mx-manufacturing-audit`, `my-hc-dialysis-audit`,
`my-healthcare-clinical-dialysis-audit`, `my-malaysia-hr-audit`,
`my-erawan-lmw-audit`, `chennai-hr-audit`, `pune-hr-audit`,
`my-mfg-diecast-stamping-audit`, `my-phc-clinic-audit`, `in-manufacturing-audit`**
- *Reads:* entity/jurisdiction identified in Project Memory's Confirmed Facts.
- *Produces:* jurisdiction- and industry-specific findings, statutory citations,
  benchmarks.
- *Writes back:* Confirmed Facts (statutory rates/thresholds with effective dates —
  always web-validated, see `references/evidence-and-hallucination-controls.md`),
  Regulatory cross-reference entries, Knowledge Graph Regulation nodes.
- *Typically followed by:* `super-grc-audit-plugin-l99` or
  `cae-cowork-ai-plugin` for the actual test execution, or directly to
  `cae-report-conversion` if the deliverable is a standalone entity report.
- *Coordination note:* **AKOS never re-derives statutory content that already lives
  in one of these skills.** If a task needs Tamil Nadu minimum wage detail, route to
  `chennai-india-ops-audit` rather than answering from general knowledge.

### Fraud / Forensic Layer

**`group-cae-fraud`**
- *Reads:* whistleblower allegation, red flag from fieldwork, or Benford anomaly.
- *Produces:* Fraud Tree classification, investigation plan, chain-of-custody
  documentation, red flag register.
- *Writes back:* Evidence Register (with strict chain-of-custody metadata — see
  `references/evidence-and-hallucination-controls.md` §3), Confirmed Facts (only once
  an allegation moves from "alleged" to "confirmed" — never blur that distinction in
  Project Memory), Decisions Register (investigation scope decisions).
- *Typically followed by:* `board-chairman-briefing` (AC/Board must be informed per
  governance protocol), `cae-report-conversion` (formal investigation report).
- *Coordination note:* fraud investigations carry heightened confidentiality. Do not
  let Knowledge Graph nodes for an active, unconfirmed investigation be visible or
  cross-referenced in unrelated engagement contexts — treat the investigation's
  Project Memory as its own isolated engagement folder until conclusions are
  confirmed.

**`group-cae-fraud-v2`**
- *Reads:* an allegation, red flag, ABAC or financial-statement-fraud concern, or Benford anomaly.
- *Produces:* fraud risk governance (ABAC, financial statement fraud, window dressing, off-balance-sheet,
  misappropriation, abuse of power, agentic-AI monitoring), 20 modus operandi patterns, investigation plan and report.
- *Writes back:* Evidence Register (strict chain-of-custody), Confirmed Facts only once an allegation is confirmed,
  Decisions Register. Never blur "alleged" and "confirmed".
- *Typically followed by:* `board-chairman-briefing`, `cae-report-conversion`.
- *Coordination note:* same isolation rule as `group-cae-fraud`: an active, unconfirmed investigation is its own
  isolated engagement (a `confidential` shelf or Knowledge Graph, see `akos-graphify-bridge`). It overlaps
  `group-cae-fraud` and the fraud scope of `super-grc-audit-plugin-l99` (Decision D3). Interim rule: new work goes to
  v2, and v1 and v2 are never run on the same investigation.

### Governance & Oversight Layer

**`cae-command-centre`**
- *Reads:* Audit Universe entries, all engagements' Confirmed Facts/status, all open
  findings across entities.
- *Produces:* Group Dashboard (risk heat map, KPIs), Management Response Tracker,
  Follow-Up Audit tracking, AC progress reports.
- *Writes back:* aggregates from every engagement's Project Memory — this is the
  **group-level rollup consumer**, not a producer of new engagement-level facts.
- *Typically followed by:* `board-chairman-briefing` / `group-cae-reporting` for the
  actual AC/Board paper.
- *Coordination note:* this is the one skill that legitimately reads *across*
  multiple engagements' Project Memory files at once — everything else should stay
  scoped to its own engagement folder.

### Reporting & Communication Layer

**`board-chairman-briefing`**
- *Reads:* a finished or near-finished finding/report from any upstream skill.
- *Produces:* strategic reframing for Chairman/Board/AC — business-impact language,
  not compliance language.
- *Writes back:* nothing new to Project Memory (it's a communication transform, not
  a fact-generator) — but should never contradict a Confirmed Fact or a stated
  confidence level from the source material.
- *Typically followed by:* nothing — this is usually a terminal step.

**`group-cae-reporting`**
- *Reads:* findings, risk data, status updates from any upstream skill.
- *Produces:* board/AC papers, leadership updates, governance memos, narrative
  reports.
- *Writes back:* nothing new to Project Memory (same rule as above — communication
  layer, not fact-generation layer).
- *Typically followed by:* `docx`/`pptx` skills for final formatting.

**`cae-report-conversion`**
- *Reads:* a completed audit report (any format) plus the approved MKTRON HTML
  template state architecture.
- *Produces:* the official HTML report, with the `checkScriptIntegrity` validator
  applied.
- *Writes back:* Evidence Register entry for the published report itself (it becomes
  evidence for future engagements referencing "prior audit results").
- *Coordination note:* per Dave's established architecture, `_LOADED_ST` findings use
  rendered-schema field names (`rating`, `actionOwner`), never raw FDATA field names
  (`dRating`, `dOwner`) — mixing these is a recurring error pattern already logged;
  see `references/kaizen-and-lessons.md` starter error pattern library.

**`group-cae-external-reporting`**
- *Reads:* a finished, approved deliverable plus the external audience (regulator, statutory authority, external
  auditor, lender, investor).
- *Produces:* a submission-ready document with no drafting artefacts, in the objective voice external readers expect,
  with statutory terms localised per jurisdiction.
- *Writes back:* Decisions Register (what was released, to whom, when).
- *Typically preceded by:* `cae-report-conversion` or `board-chairman-briefing`.
- *Coordination note:* internal audiences stay with `group-cae-reporting`; anything leaving the Group comes here
  (stated in its own description).

### Format/Output Layer

**`docx` / `xlsx` / `pptx` / `pdf`**
- *Reads:* finished content from any upstream skill.
- *Produces:* the formatted deliverable file.
- *Writes back:* nothing to Project Memory — pure output formatting.
- *Coordination note:* these are always the *last* step in a chain, never a
  mid-chain step. Don't format content that hasn't passed Module 9 Quality Gates yet.

### Visual / Dashboard Layer

**`canvas-design`, `data:build-dashboard`, the `visualize` tool**
- *Reads:* finished risk/KPI/status data.
- *Produces:* heat maps, dashboards, diagrams.
- *Coordination note:* see `references/qa-verification-and-deliverable-standards.md`
  §4 for which tool fits which visual.

**`akos-graphify-bridge`**
- *Reads:* `KNOWLEDGE_GRAPH.json`, graphify `graph.json`, an optional entity map, and (library brain) the shelf
  folders under a brain library.
- *Produces:* graphify graph and HTML view, staged Knowledge Graph items marked PROPOSED, a Module 9 validation
  report, the Board-safe deliverable subset, recall results with trust labels, an interop report.
- *Writes back:* proposed Knowledge Graph nodes and edges only (never confirmed ones), Outstanding Questions for
  unclassified items, Decisions Register candidates for conflicts, LESSONS_LEARNED *candidates* from saved work-memory.
- *Typically followed by:* `akos-enterprise-orchestrator` (confirm and record), a domain skill (classify),
  `cae-report-conversion` or `board-chairman-briefing` (publish the deliverable subset only).
- *Coordination note:* never confirms a fact, assigns a finding rating, or decides entity classification. graphify
  confidence is not evidence rank, and a saved Q&A answer is an indicator, never evidence (Iron Rule 17).

---

### Skill families and declared supersession

Read from the skills' own metadata on 3 Oct 2026, not decided by AKOS.

| Skill that declares it | Declared superseded by it | Registry status |
|---|---|---|
| `cae-cowork-ai-plugin` v6.0 | `cae-audit-cowork-plugin-v4`, `cae-audit-cowork-plugin-v5` (and v5.01 of itself) | **Applied (D1).** Routes moved to v6; v4 and v5 are superseded legacy, kept only for engagements already begun on them |
| `cae-audit-cowork-plugin-v4` | `cae-audit-cowork-plugin` (v2.0) | `cae-audit-cowork-plugin` is superseded legacy |
| `super-grc-audit-plugin-l99` | `group-cae`, `group-cae-core`, `group-cae-fraud`, `group-cae-reporting`, `managing-internal-audit`, `cae-audit-cowork-plugin`, `ia-rag-assistant` | **Not applied (D2 pending).** Declared superseded by it, but none of those skills acknowledges that, and this registry still routes to `group-cae-reporting` and `group-cae-fraud`. Owner decision |

Open decisions with evidence and a recommendation each: see `DECISIONS_PENDING.md` shipped with the v2.3 patch
(D2 L99 family, D3 fraud overlap, D4 missing `mac-audit-constitution-l99`, D5 v6 "10-item" gate, D6 `charlie-hills-code`
structure, D7 `master-audit-superagent` rule header, D8 Perfect Longevity entity code).

---

## 4. Conflict Resolution — When Two Skills Could Both Claim a Task

1. **Specificity wins.** An entity-specific skill (`my-mkpc-mfg-audit`) outranks a
   generic one (`in-manufacturing-audit`) whenever the entity is known.
2. **Lifecycle stage wins next.** If the task is "draft the finding," that's
   `super-grc-audit-plugin-l99`/`cae-cowork-ai-plugin`, not
   `board-chairman-briefing` — briefing only touches *finished* findings.
3. **If genuinely ambiguous, ask** (Behavioural Rule 7) rather than silently picking
   one and hoping — a wrong routing choice wastes a full specialist pass.
4. **Never run two content skills on the same finding in parallel** without a
   defined merge step — this creates exactly the kind of duplicate/conflicting
   Knowledge Graph nodes that `data-quality-specialist` would then have to detect and
   clean up. Sequence, don't parallelise, when two skills would touch the same
   deliverable.
5. **AKOS itself never overrides a domain skill's regulatory or methodological
   content** — if `iron-rules-governance`'s evidence rules and a domain skill's
   local practice appear to conflict, surface the conflict as an Outstanding Question
   rather than silently picking one.
6. **Version families: newest declared successor wins.** When a skill's own metadata declares it supersedes another,
   route new work to the successor and keep the older skill only for engagements already begun on it. A declaration
   that no other skill acknowledges (D2) is surfaced as an Outstanding Question, not silently applied.
7. **One investigation, one fraud skill.** Never run `group-cae-fraud` and `group-cae-fraud-v2` on the same
   investigation; sequence, do not parallelise (rule 4).
8. **Graph analysis versus graph integrity.** Visualising, querying, shelving and validating the Knowledge Graph goes to
   `akos-graphify-bridge`; the Module 9 gate and the decision to confirm a fact stay with AKOS.

---

## 5. Worked Coordination Workflows

### Workflow A — New multi-entity contract labour audit (India)

```
1. /akos-init "MKAPL Diecast Contract Labour FY26"  → PROJECT_MEMORY skeleton
2. chennai-india-ops-audit                          → statutory framework, scope
3. cae-cowork-ai-plugin                            → fieldwork, sample testing
4. group-cae-fraud-v2 (only if red flags surface)    → investigation branch
5. QA Reviewer (Module 9 gate)                       → accept/reject
6. cae-report-conversion                             → HTML report
7. board-chairman-briefing                           → AC/Board framing
8. cae-command-centre                                → roll into Group Dashboard
9. Kaizen retrospective (Module 7)                   → log lessons
```

### Workflow B — Whistleblower tip-off (any entity)

```
1. group-cae-fraud                    → triage, Fraud Tree classification,
                                          isolated Project Memory (confidentiality)
2. Evidence chain-of-custody logging  → references/evidence-and-hallucination-
                                          controls.md §3
3. Investigation conclusion reached   → Confirmed Facts (only now, not before)
4. board-chairman-briefing            → mandatory AC/Board notification
5. cae-report-conversion              → formal investigation report
6. cae-command-centre                 → Management Response Tracker entry
```

### Workflow C — New knowledge repository ingestion (bulk documents)

```
1. Knowledge Architect      → taxonomy proposal (Decisions Register entry)
2. Document Intelligence    → per-document extraction
3. Data Quality             → duplicate/version-conflict exception log
4. Knowledge Graph          → node/edge creation from extraction output
5. QA Reviewer              → Module 9 gate, especially "no orphan records"
6. Kaizen retrospective     → what taxonomy/extraction lessons apply next time
```

---

## 6. Sequencing Patterns

- **Fan-out then fan-in:** independent entities/workstreams run in parallel
  (Module 3), then merge into one Project Memory / Knowledge Graph before the
  reporting layer touches anything.
- **Never skip the QA gate to save time.** A rushed handoff to
  `board-chairman-briefing` with an unvalidated finding is a governance risk, not a
  time saving — Chairman/Board communications carry the highest reputational cost of
  any deliverable in this ecosystem.
- **Reporting-layer skills are terminal.** Nothing should route *from*
  `board-chairman-briefing` or `group-cae-reporting` back *into* a content-generation
  skill in the same workflow — if the Board raises a question, that's a new
  Outstanding Question and potentially a new engagement, not a silent edit to the
  existing narrative.

---

## 7. What AKOS Never Delegates

AKOS keeps directly, regardless of how many specialist skills are in play:
- The Project Memory and Knowledge Graph themselves (other skills write *into* them
  via the shared-state convention; AKOS owns their integrity).
- The Module 9 Quality Gate decision to accept or reject a deliverable.
- The Module 11 boundary check on autonomous changes to facts/policies/controls.
- The Kaizen retrospective and lessons-learned promotion decision.

Everything else is a candidate for delegation to the right specialist skill above.
