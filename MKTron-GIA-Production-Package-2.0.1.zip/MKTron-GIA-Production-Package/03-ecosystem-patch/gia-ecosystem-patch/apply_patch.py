#!/usr/bin/env python3
"""apply_patch.py - apply (or roll back) the GIA ecosystem patch on a skills catalog.

DRY-RUN by default: nothing is touched, not even a lock or journal file, without --apply.

Safety properties
  * Every replaced file or folder is first copied (or moved) into --backup-dir, which must be OUTSIDE the catalog.
  * Folder installs are STAGED beside the target and swapped in by rename; a failure at any step leaves the old
    folder in place (a kill -9 between the two renames leaves '<name>.old-<pid>', which the next run restores).
  * Each operation is isolated: one failing operation is reported FAILED and the rest continue (exit code 1).
  * Idempotent: a second --apply reports ALREADY APPLIED for everything and changes nothing.
  * One apply at a time (lock file in the catalog); a second concurrent run is refused.
  * `--rollback <backup-dir>` replays the journal in reverse and restores the catalog byte for byte. It refuses to
    overwrite anything edited AFTER the patch unless --force is given.

Operations
  A  AKOS v2.3        replace each installed copy of akos-enterprise-orchestrator with the single v2.3 payload
  B1 retire stale     plugins/pune-india-ops-audit (v1.0), only if the newer mktron-pune-vda-compliance copy exists
  B2 retire stale     plugins/file-reading, only if public/file-reading exists and differs
  C  drift script     iron-rules-governance/scripts/check-governance-drift.sh -> v1.2
  D  install bridge   akos-graphify-bridge into <catalog>/user/
  E1 racm-ecosystem          apply the RACM-01..12 namespace inside the skill (verified line by line)
  E2 cae-report-conversion   apply the RC-01..12 namespace inside the skill (verified line by line)
  E3 cae-cowork-ai-plugin    quality gate: add the 2 missing checks so the asserted 12 equals the enumerated 12
  E4 master-audit-superagent give its local rule list its own MAS namespace (heading rename)
  E5 legacy skills           LEGACY banner in the description of cae-audit-cowork-plugin / -v4 / -v5 (nothing deleted)
E-ops are anchored edits checked against YOUR files at apply time; if an anchor or the approved text does not
match, that edit is SKIPPED with the reason. Nothing is forced.

Exit codes: 0 ok · 1 some operation FAILED or a rollback step was skipped · 2 refused (bad arguments, busy, unsafe).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"
sys.path.insert(0, str(PAYLOAD / "akos-graphify-bridge" / "scripts"))
sys.path.insert(0, str(HERE))
import interop_check as ic  # noqa: E402
import edits  # noqa: E402
import fsutil  # noqa: E402
import strictjson  # noqa: E402
import textsafe  # noqa: E402
from errors import GiaError, LockTimeout, RefusedError, run_cli  # noqa: E402

AKOS = "akos-enterprise-orchestrator"
AKOS_PLUGIN = "akos-enterprise-orchestrator:akos-enterprise-orchestrator"
JOURNAL = "APPLY_LOG.json"


def tree_hash(folder: Path) -> str:
    h = hashlib.sha256()
    for rel, digest in sorted(ic.tree_hashes(folder).items()):
        h.update(rel.encode())
        h.update(digest.encode())
    return h.hexdigest()


def state_hash(path: Path) -> str | None:
    if not path.exists():
        return None
    return tree_hash(path) if path.is_dir() else fsutil.sha256_file(path)


class Patcher:
    def __init__(self, catalog: Path, backup: Path, apply: bool):
        self.cat, self.backup, self.apply = Path(catalog), Path(backup), apply
        self.log: list[tuple[str, str, str]] = []
        self.entries: list[dict] = []
        jf = self.backup / JOURNAL
        if apply and jf.exists():                              # a previous run was interrupted: continue its journal
            j = strictjson.load(jf)
            if isinstance(j, dict) and j.get("catalog") == str(self.cat.resolve()) and not j.get("rolled_back"):
                self.entries = list(j.get("entries", []))
            elif isinstance(j, dict) and j.get("catalog") != str(self.cat.resolve()):
                raise RefusedError(f"{self.backup} already holds a journal for another catalog ({j.get('catalog')}); use a new backup folder")

    # ---- reporting and journal ------------------------------------------------------------------------
    def note(self, op, status, detail):
        self.log.append((op, status, detail))
        print(f"[{status:<15}] {op:<4} {textsafe.display(detail, 300)}")

    def _write_journal(self, rolled_back=False):
        if not self.apply:
            return
        fsutil.atomic_write_json(self.backup / JOURNAL, {"catalog": str(self.cat.resolve()), "created": fsutil.now_utc_iso(),
                                                         "rolled_back": rolled_back, "entries": self.entries}, 0o600)

    def _begin(self, op, kind, path: Path, backup_rel) -> dict:
        """Write-ahead intent: the journal knows about a change BEFORE it happens, so a kill at any instant is undoable."""
        e = {"op": op, "kind": kind, "path": str(path.relative_to(self.cat)), "backup": backup_rel, "after": None, "pending": True}
        self.entries.append(e)
        self._write_journal()
        return e

    def _commit(self, e: dict, path: Path):
        e["after"] = state_hash(path)
        e.pop("pending", None)
        self._write_journal()

    def _backup(self, path: Path, move: bool) -> str:
        rel = path.relative_to(self.cat)
        dest = self.backup / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists():
            shutil.rmtree(dest) if dest.is_dir() else dest.unlink()
        if move:
            shutil.move(str(path), str(dest))
        elif path.is_dir():
            shutil.copytree(path, dest)
        else:
            shutil.copy2(path, dest)
        return str(rel)

    # ---- operations ----------------------------------------------------------------------------------------
    def sync_folder(self, op, src: Path, dst: Path, label: str):
        if dst.exists() and tree_hash(dst) == tree_hash(src):
            return self.note(op, "ALREADY APPLIED", f"{label}: {dst}")
        if not self.apply:
            return self.note(op, "WOULD APPLY", f"{label}: {dst}")
        existed = dst.exists()
        brel = self._backup(dst, move=False) if existed else None
        entry = self._begin(op, "replaced-dir" if existed else "created-dir", dst, brel)
        staging = dst.with_name(f".{dst.name}.new-{os.getpid()}")
        shutil.rmtree(staging, ignore_errors=True)
        try:
            shutil.copytree(src, staging, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
            fsutil.replace_dir(staging, dst)               # old folder restored automatically if the swap fails
        except BaseException:
            shutil.rmtree(staging, ignore_errors=True)
            raise
        self._commit(entry, dst)
        self.note(op, "APPLIED", f"{label}: {dst}")

    def text_edit(self, op, path: Path, transform, label: str, ctx: dict):
        if not path.exists():
            return self.note(op, "SKIPPED", f"{label}: {path.name} not installed")
        old = path.read_text(encoding="utf-8")
        try:
            new = transform(old, ctx)
        except edits.EditError as exc:
            return self.note(op, "SKIPPED", f"{label}: {exc}")
        if new == old:
            return self.note(op, "ALREADY APPLIED", label)
        if not self.apply:
            self.note(op, "WOULD APPLY", label)
            for n in ctx.pop("notes", []):
                self.note(op, "NOTE", n)
            return
        brel = self._backup(path, move=False)
        entry = self._begin(op, "edited-file", path, brel)
        fsutil.atomic_write_text(path, new, path.stat().st_mode & 0o777)
        self._commit(entry, path)
        self.note(op, "APPLIED", label)
        for n in ctx.pop("notes", []):
            self.note(op, "NOTE", n)

    def retire(self, op, target: Path, reason_ok: bool, why_not: str, label: str):
        if not target.exists():
            return self.note(op, "ALREADY APPLIED", f"{label}: not installed")
        if not reason_ok:
            return self.note(op, "SKIPPED", f"{label}: {why_not}")
        if not self.apply:
            return self.note(op, "WOULD APPLY", f"retire {label}: {target}")
        brel = str(target.relative_to(self.cat))
        entry = self._begin(op, "retired-dir", target, brel)
        self._backup(target, move=True)
        self._commit(entry, target)
        self.note(op, "APPLIED", f"retired {label} (moved to backup)")

    def replace_file(self, op, src: Path, dst: Path, mode: int):
        if dst.exists() and dst.read_bytes() == src.read_bytes():
            return self.note(op, "ALREADY APPLIED", str(dst))
        if not self.apply:
            return self.note(op, "WOULD APPLY", str(dst))
        brel = self._backup(dst, move=False) if dst.exists() else None
        entry = self._begin(op, "replaced-file" if brel else "created-file", dst, brel)
        fsutil.atomic_write_bytes(dst, src.read_bytes(), mode)
        self._commit(entry, dst)
        self.note(op, "APPLIED", str(dst))

    def _isolated(self, op, label, fn):
        """One operation must never take the others down: report FAILED and carry on."""
        try:
            fn()
        except Exception as exc:
            self.note(op, "FAILED", f"{label}: {type(exc).__name__}: {exc}")

    def cleanup_interrupted(self):
        """Undo what an earlier killed run left behind: restore '<name>.old-<pid>', delete '.<name>.new-<pid>'."""
        if not self.apply:
            return
        for root in (self.cat / "user", self.cat / "plugins"):
            if not root.is_dir():
                continue
            for fixed in fsutil.recover_pending(root, names={AKOS, AKOS_PLUGIN, "pune-india-ops-audit", "file-reading",
                                                             "akos-graphify-bridge"}):
                self.note("-", "RECOVERED", f"restored {fixed} from an interrupted run")
            for stray in root.glob(".*.new-*"):
                if re.search(r"\.new-\d+$", stray.name) and stray.is_dir() and not stray.is_symlink():
                    shutil.rmtree(stray, ignore_errors=True)
                    self.note("-", "CLEANED", f"removed leftover staging folder {stray.name}")

    def run(self):
        c = self.cat
        self.cleanup_interrupted()
        # A - AKOS
        found = False
        for rel in (Path("user") / AKOS, Path("plugins") / AKOS_PLUGIN):
            if (c / rel).exists():
                found = True
                self._isolated("A", f"AKOS v2.3 {rel}", lambda rel=rel: self.sync_folder("A", PAYLOAD / AKOS, c / rel, "AKOS v2.3"))
        if not found:
            self.note("A", "SKIPPED", "no AKOS install found under user/ or plugins/")
        # B1 - Pune v1.0 stale
        def b1():
            old, new = c / "plugins" / "pune-india-ops-audit", c / "plugins" / "mktron-pune-vda-compliance:pune-india-ops-audit"
            ok, why = False, "newer mktron-pune-vda-compliance copy not found"
            if new.exists() and old.exists():
                vo, vn = ic.detect_version(old), ic.detect_version(new)
                ok = bool(vo and vn and ic.vkey(vn) > ic.vkey(vo))
                why = f"cannot prove the other copy is newer (old={vo}, new={vn})"
            self.retire("B1", old, ok, why, "pune-india-ops-audit v1.0")
        self._isolated("B1", "pune-india-ops-audit", b1)
        # B2 - file-reading
        def b2():
            old, pub = c / "plugins" / "file-reading", c / "public" / "file-reading"
            ok = pub.exists() and old.exists() and tree_hash(pub) != tree_hash(old)
            self.retire("B2", old, ok, "public/file-reading not found or identical", "plugins/file-reading")
        self._isolated("B2", "file-reading", b2)
        # C - drift script
        src = PAYLOAD / "iron-rules-governance" / "scripts" / "check-governance-drift.sh"
        done = False
        for rel in (Path("plugins/iron-rules-governance/scripts"), Path("user/iron-rules-governance/scripts")):
            dst = c / rel / "check-governance-drift.sh"
            if dst.parent.exists():
                done = True
                self._isolated("C", str(dst), lambda dst=dst: self.replace_file("C", src, dst, 0o755))
        if not done:
            self.note("C", "SKIPPED", "iron-rules-governance not installed")
        # E - anchored edits to live skills
        roots = [c / "plugins", c / "user"]
        ns_rel = "iron-rules-governance/references/racm-rc-namespaces.md"
        ns_doc = next((r / ns_rel for r in roots if (r / ns_rel).exists()), None)
        try:
            ns_text = ns_doc.read_text(encoding="utf-8") if ns_doc else None
        except OSError:
            ns_text = None
        ctx = {"namespace_doc": ns_text, "superseder_installed": any((r / "cae-cowork-ai-plugin/SKILL.md").exists() for r in roots)}
        plan = [("E1", "racm-ecosystem", "SKILL.md", edits.t_racm, "racm-ecosystem RACM-01..12"),
                ("E2", "cae-report-conversion", "SKILL.md", edits.t_rc, "cae-report-conversion RC-01..12"),
                ("E3", "cae-cowork-ai-plugin", "SKILL.md", edits.t_v6_gate, "cae-cowork-ai-plugin 12-item gate"),
                ("E4", "master-audit-superagent", "SKILL.md", edits.t_mas_skill, "master-audit-superagent MAS namespace"),
                ("E4", "master-audit-superagent", "references/qa-reporting-protocol.md", edits.t_mas_protocol,
                 "master-audit-superagent protocol headings"),
                ("E5", "cae-audit-cowork-plugin", "SKILL.md", edits.t_legacy, "legacy banner: cae-audit-cowork-plugin"),
                ("E5", "cae-audit-cowork-plugin-v4", "SKILL.md", edits.t_legacy, "legacy banner: cae-audit-cowork-plugin-v4"),
                ("E5", "cae-audit-cowork-plugin-v5", "SKILL.md", edits.t_legacy, "legacy banner: cae-audit-cowork-plugin-v5")]
        for op, skill, rel, fn, label in plan:
            hit = False
            for r in roots:
                if (r / skill / rel).exists():
                    hit = True
                    self._isolated(op, label, lambda r=r, rel=rel, skill=skill, fn=fn, label=label, op=op:
                                   self.text_edit(op, r / skill / rel, fn, label, ctx))
            if not hit:
                self.note(op, "SKIPPED", f"{label}: skill not installed")
        # D - bridge skill
        if self.apply and not (c / "user").exists():
            entry = self._begin("D", "created-root", c / "user", None)      # journal it, so rollback can remove it again
            (c / "user").mkdir(parents=True)
            self._commit(entry, c / "user")
        self._isolated("D", "akos-graphify-bridge",
                       lambda: self.sync_folder("D", PAYLOAD / "akos-graphify-bridge", c / "user" / "akos-graphify-bridge", "akos-graphify-bridge"))
        self._finalise_pending()
        return self.log

    def _finalise_pending(self):
        """Converge the journal: an entry left 'pending' by an interrupted run is either superseded by a later committed
        entry for the same path (drop it) or describes a change whose result is now in place (commit it)."""
        if not self.apply or not any(e.get("pending") for e in self.entries):
            return
        done = {e["path"] for e in self.entries if not e.get("pending")}
        kept = []
        for e in self.entries:
            if e.get("pending"):
                if e["path"] in done:
                    continue
                e["after"] = state_hash(self.cat / e["path"])
                e.pop("pending", None)
            kept.append(e)
        self.entries = kept
        self._write_journal()


# ---- rollback -----------------------------------------------------------------------------------------------
def rollback(catalog: Path, backup: Path, force: bool = False) -> int:
    catalog, backup = Path(catalog).resolve(), Path(backup).resolve()
    jf = backup / JOURNAL
    if not jf.exists():
        raise RefusedError(f"{backup} has no {JOURNAL}: it is not a backup folder made by this tool")
    j = strictjson.load(jf)
    if not isinstance(j, dict) or j.get("catalog") != str(catalog):
        raise RefusedError(f"this backup was made for {j.get('catalog') if isinstance(j, dict) else '?'}, not {catalog} (refused)")
    if j.get("rolled_back"):
        print("already rolled back: nothing to do")
        return 0
    failed = 0
    for e in reversed(j["entries"]):
        if e.get("rolled_back"):                               # resumable: finished entries are never redone
            continue
        try:
            path = fsutil.ensure_within(catalog, e["path"]) if (catalog / e["path"]).exists() else catalog / e["path"]
            if not str(path.resolve()).startswith(str(catalog) + os.sep):
                raise RefusedError(f"journal path {e['path']!r} is outside the catalog")
            kind, brel = e["kind"], e.get("backup")
            cur = state_hash(path)
            pending = bool(e.get("pending"))
            if pending and kind in ("replaced-dir", "edited-file", "replaced-file", "retired-dir") and not (backup / brel).exists():
                print(f"[{'SKIPPED':<15}] {e['op']:<4} {e['path']}: interrupted before its backup completed; nothing to restore")
                e["rolled_back"] = True
                continue
            if kind != "retired-dir" and not pending and cur != e.get("after") and not force:
                print(f"[{'SKIPPED':<15}] {e['op']:<4} {e['path']}: changed since the patch (use --force to overwrite your later edits)")
                failed += 1
                continue
            if kind == "replaced-dir":
                staging = path.with_name(f".{path.name}.rb-{os.getpid()}")
                shutil.rmtree(staging, ignore_errors=True)
                shutil.copytree(backup / brel, staging)
                fsutil.replace_dir(staging, path)
            elif kind == "created-dir":
                shutil.rmtree(path, ignore_errors=True)
            elif kind in ("edited-file", "replaced-file"):
                src = backup / brel
                fsutil.atomic_write_bytes(path, src.read_bytes(), src.stat().st_mode & 0o777)
            elif kind == "created-file":
                path.unlink(missing_ok=True)
            elif kind == "created-root":
                try:
                    path.rmdir()                           # only if empty: if someone has since used it, leave it alone
                except OSError:
                    pass
            elif kind == "retired-dir":
                if not (backup / brel).exists():
                    pass                                   # interrupted before the move happened: the folder never left
                elif path.exists():
                    raise RefusedError(f"{e['path']} exists again; not overwriting it with the retired copy")
                else:
                    shutil.move(str(backup / brel), str(path))
            else:
                raise RefusedError(f"unknown journal entry kind {kind!r}")
            e["rolled_back"] = True
            fsutil.atomic_write_json(jf, j, 0o600)            # persist progress after every entry
            print(f"[{'ROLLED BACK':<15}] {e['op']:<4} {e['path']}")
        except Exception as exc:
            failed += 1
            print(f"[{'FAILED':<15}] {e.get('op', '?'):<4} {textsafe.display(e.get('path'), 120)}: {type(exc).__name__}: {exc}")
    if not failed:
        j["rolled_back"] = True
        fsutil.atomic_write_json(jf, j, 0o600)
    return 1 if failed else 0


def _main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--catalog", default="/mnt/skills", help="root that contains user/ and plugins/ (default /mnt/skills)")
    ap.add_argument("--backup-dir")
    ap.add_argument("--apply", action="store_true", help="actually change files (default is a dry run)")
    ap.add_argument("--rollback", metavar="BACKUP_DIR", help="undo a previous --apply using its backup folder")
    ap.add_argument("--force", action="store_true", help="with --rollback: overwrite files edited after the patch")
    a = ap.parse_args(argv)
    cat = Path(a.catalog)
    if not cat.is_dir():
        raise RefusedError(f"{cat} is not a directory")
    if a.rollback:
        with fsutil.FileLock(cat / ".gia-patch.lock", timeout=5):
            return rollback(cat, Path(a.rollback), a.force)
    backup = Path(a.backup_dir) if a.backup_dir else Path.home() / f"gia-patch-backup-{datetime.now():%Y%m%d-%H%M%S}"
    try:
        backup.resolve().relative_to(cat.resolve())
        raise RefusedError(f"the backup folder {backup} is inside the catalog {cat}: its copies would be scanned as installed skills. "
                           f"Choose a folder outside it")
    except ValueError:
        pass
    print(f"catalog: {cat}\nmode:    {'APPLY' if a.apply else 'DRY RUN (no changes)'}\nbackup:  {backup}\n")
    if not a.apply:
        p = Patcher(cat, backup, False)
        p.run()
        print("\nDry run only. Re-run with --apply to make these changes.")
        return 0
    try:
        lock = fsutil.FileLock(cat / ".gia-patch.lock", timeout=5)
        lock.__enter__()
    except LockTimeout:
        raise RefusedError("another apply is running on this catalog (lock held); wait for it to finish")
    try:
        p = Patcher(cat, backup, True)
        p._write_journal()
        p.run()
    finally:
        lock.__exit__(None, None, None)
    failed = [x for x in p.log if x[1] == "FAILED"]
    if failed:
        print(f"\n{len(failed)} operation(s) FAILED; the rest were applied. Undo everything with: --rollback {backup}")
    return 1 if failed else 0


def main(argv=None) -> int:
    return run_cli(_main, argv)


if __name__ == "__main__":
    sys.exit(main())
