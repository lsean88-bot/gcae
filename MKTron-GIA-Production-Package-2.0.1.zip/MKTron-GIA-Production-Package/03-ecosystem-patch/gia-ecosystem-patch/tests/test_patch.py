"""Tests for the patch tooling: anchored edits, apply (dry-run/idempotent/backup/guards), drift script v1.1."""
import shutil, subprocess, sys
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "payload/akos-graphify-bridge/scripts"))
import apply_patch as ap  # noqa: E402
import build_payload as bp  # noqa: E402

DRIFT = ROOT / "payload/iron-rules-governance/scripts/check-governance-drift.sh"


# ---- anchored edits fail loudly ---------------------------------------------------------
def test_sub_exact_match_ok_and_mismatch_aborts():
    assert bp.sub("a b a", "b", "X", 1) == "a X a"
    with pytest.raises(SystemExit, match="ANCHOR MISMATCH"):
        bp.sub("a b a", "a", "X", 1)          # appears twice, expected once
    with pytest.raises(SystemExit, match="ANCHOR MISMATCH"):
        bp.sub("abc", "zzz", "X", 1)


def test_payload_has_v23_markers():
    skill = (ROOT / "payload/akos-enterprise-orchestrator/SKILL.md").read_text()
    reg = (ROOT / "payload/akos-enterprise-orchestrator/references/plugin-coordination-registry.md").read_text()
    assert 'version: "2.3"' in skill and "v2.3 change record" in skill
    assert "`cae-audit-cowork-plugin-v4` |" not in skill            # routing row moved
    for name in ("cae-cowork-ai-plugin", "racm-ecosystem", "master-audit-superagent", "mktron-gia-data-reconciliation",
                 "charlie-hills-code", "debugger", "group-cae-fraud-v2", "group-cae-external-reporting",
                 "akos-graphify-bridge"):
        assert f"**`{name}`**" in reg, name
    assert "D2 pending" in reg and "Skill families and declared supersession" in reg


# ---- apply_patch on a synthetic catalog ------------------------------------------------------
def skill(d: Path, name, version=None, extra=""):
    d.mkdir(parents=True, exist_ok=True)
    meta = f'metadata:\n  version: "{version}"\n' if version else ""
    (d / "SKILL.md").write_text(f"---\nname: {name}\ndescription: d\n{meta}---\n{extra}\n")


@pytest.fixture
def cat(tmp_path):
    c = tmp_path / "cat"
    skill(c / "user/akos-enterprise-orchestrator", "akos-enterprise-orchestrator", "2.2")
    skill(c / "plugins/akos-enterprise-orchestrator:akos-enterprise-orchestrator", "akos-enterprise-orchestrator", "2.1")
    skill(c / "plugins/pune-india-ops-audit", "pune-india-ops-audit", "1.0")
    skill(c / "plugins/mktron-pune-vda-compliance:pune-india-ops-audit", "pune-india-ops-audit", "1.1")
    skill(c / "plugins/file-reading", "file-reading", None, "old")
    skill(c / "public/file-reading", "file-reading", None, "new")
    sd = c / "plugins/iron-rules-governance/scripts"
    sd.mkdir(parents=True)
    (sd / "check-governance-drift.sh").write_text("#!/bin/bash\necho old\n")
    return c


def run_patch(cat, backup, apply=False):
    return ap.Patcher(cat, backup, apply).run()


def core(log):
    """A-D operations only. E-ops target skills the synthetic catalog does not contain and must SKIP, not fail."""
    return [x for x in log if not x[0].startswith("E")]


def test_e_ops_skip_gracefully_when_skills_are_not_installed(cat, tmp_path):
    log = run_patch(cat, tmp_path / "bk", apply=True)
    e = [x for x in log if x[0].startswith("E")]
    assert e and all(st == "SKIPPED" and "not installed" in detail for _, st, detail in e)


def status(log):
    return {(op, detail.split(":")[0].split(" ")[0]): st for op, st, detail in log}


def test_dry_run_changes_nothing(cat, tmp_path):
    before = {p: p.read_bytes() for p in cat.rglob("*") if p.is_file()}
    log = run_patch(cat, tmp_path / "bk", apply=False)
    assert all(st in ("WOULD APPLY", "ALREADY APPLIED") for _, st, _ in core(log))
    assert {p: p.read_bytes() for p in cat.rglob("*") if p.is_file()} == before
    assert not (tmp_path / "bk").exists()


def test_apply_then_idempotent_and_backed_up(cat, tmp_path):
    run_patch(cat, tmp_path / "bk", apply=True)
    assert 'version: "2.3"' in (cat / "user/akos-enterprise-orchestrator/SKILL.md").read_text()
    assert ap.tree_hash(cat / "user/akos-enterprise-orchestrator") == \
        ap.tree_hash(cat / "plugins/akos-enterprise-orchestrator:akos-enterprise-orchestrator")
    assert not (cat / "plugins/pune-india-ops-audit").exists() and not (cat / "plugins/file-reading").exists()
    assert (cat / "plugins/mktron-pune-vda-compliance:pune-india-ops-audit").exists()   # newer one kept
    assert (cat / "user/akos-graphify-bridge/SKILL.md").exists()
    bk = tmp_path / "bk"
    assert 'version: "2.1"' in (bk / "plugins/akos-enterprise-orchestrator:akos-enterprise-orchestrator/SKILL.md").read_text()
    assert (bk / "plugins/pune-india-ops-audit/SKILL.md").exists()
    assert "old" in (bk / "plugins/iron-rules-governance/scripts/check-governance-drift.sh").read_text()
    log2 = run_patch(cat, tmp_path / "bk2", apply=True)
    assert all(st == "ALREADY APPLIED" for _, st, _ in core(log2))
    assert not (tmp_path / "bk2").exists()                     # nothing changed -> nothing backed up


def test_retire_only_when_newer_copy_is_provable(cat, tmp_path):
    shutil.rmtree(cat / "plugins/mktron-pune-vda-compliance:pune-india-ops-audit")     # newer copy missing
    log = run_patch(cat, tmp_path / "bk", apply=True)
    assert status(log)[("B1", "pune-india-ops-audit")] == "SKIPPED"
    assert (cat / "plugins/pune-india-ops-audit").exists()
    skill(cat / "plugins/mktron-pune-vda-compliance:pune-india-ops-audit", "pune-india-ops-audit", "1.0")   # same version
    log = run_patch(cat, tmp_path / "bk2", apply=True)
    assert status(log)[("B1", "pune-india-ops-audit")] == "SKIPPED"


def test_file_reading_kept_if_public_copy_missing_or_identical(cat, tmp_path):
    shutil.rmtree(cat / "public/file-reading")
    log = run_patch(cat, tmp_path / "bk", apply=True)
    assert status(log)[("B2", "plugins/file-reading")] == "SKIPPED" and (cat / "plugins/file-reading").exists()


def test_cli_dry_run_and_bad_catalog(cat, tmp_path):
    r = subprocess.run([sys.executable, str(ROOT / "apply_patch.py"), "--catalog", str(cat), "--backup-dir", str(tmp_path / "b")],
                       capture_output=True, text=True)
    assert r.returncode == 0 and "DRY RUN" in r.stdout and "Re-run with --apply" in r.stdout
    r = subprocess.run([sys.executable, str(ROOT / "apply_patch.py"), "--catalog", str(tmp_path / "nope")], capture_output=True, text=True)
    assert r.returncode == 2


# ---- drift script v1.1 -------------------------------------------------------------------------
def drift(*roots):
    return subprocess.run(["bash", str(DRIFT), *map(str, roots)], capture_output=True, text=True)


@pytest.fixture
def dcat(tmp_path):
    c = tmp_path / "plugins"
    (c / "iron-rules-governance").mkdir(parents=True)
    (c / "iron-rules-governance/SKILL.md").write_text("# x\n")
    return c


def mkskill(dcat, folder):
    d = dcat / folder
    (d / "references").mkdir(parents=True, exist_ok=True)
    (d / "SKILL.md").write_text("---\nname: x\ndescription: d\n---\n")
    return d / "references"


def test_folder_without_skill_md_is_not_a_skill_and_is_not_scanned(dcat):
    d = dcat / "akos:akos/references"
    d.mkdir(parents=True)
    (d / "r.md").write_text("this claims a 27-item quality gate\n")
    assert "r.md" not in drift(dcat).stdout


def test_legacy_marked_skill_is_skipped_and_named(dcat):
    d = mkskill(dcat, "old-v4")
    (dcat / "old-v4/SKILL.md").write_text("---\nname: old-v4\ndescription: >\n  LEGACY, superseded (see x). old.\n---\n")
    (d / "r.md").write_text("A\nB\nC\nD\nE\nF\nG\nThe skill has a 14-item quality gate today.\n")
    out = drift(dcat).stdout
    assert "Skipped legacy-marked skills: old-v4" in out and "r.md" not in out


def test_akos_evidence_mirror_allowlisted_for_check_five_only(dcat):
    d = mkskill(dcat, "akos-enterprise-orchestrator")
    (d / "evidence.md").write_text("| R1 | Government portal |\n")
    other = mkskill(dcat, "some-other-skill")
    (other / "evidence.md").write_text("| R1 | Government portal |\n")
    out = drift(dcat).stdout
    assert "some-other-skill/references/evidence.md" in out and "akos-enterprise-orchestrator/references/evidence.md" not in out


def test_drift_does_not_crash_on_colon_in_folder_name(dcat):
    d = mkskill(dcat, "akos:akos")
    (d / "r.md").write_text("line\nline\nthis claims a 27-item quality gate\n")        # genuine, un-narrated
    r = drift(dcat)
    assert "unbound variable" not in r.stderr and r.returncode in (0, 1)
    assert "27-item quality gate" in r.stdout


def test_drift_ignores_correction_narrative_but_flags_live_claims(dcat):
    d = mkskill(dcat, "akos:akos")
    (d / "narr.md").write_text("**Correction, 27 Sept:** this entry previously named x\nas having a\n27-item quality gate.\n")
    (d / "live.md").write_text("A\nB\nC\nD\nE\nF\nG\nThe skill has a 14-item quality gate today.\n")
    out = drift(dcat).stdout
    assert "narr.md" not in out and "live.md" in out


def test_drift_skips_dated_history_files(dcat):
    d = dcat / "iron-rules-governance/references"
    d.mkdir(parents=True, exist_ok=True)
    (d / "drift-check-2026-09-27.md").write_text("old claim: 14-item quality gate\n")
    assert "drift-check-2026-09-27" not in drift(dcat).stdout


def test_drift_scans_multiple_roots_and_finds_skill_in_any(tmp_path, dcat):
    other = tmp_path / "user"
    (other / "some-skill").mkdir(parents=True)
    (other / "some-skill/SKILL.md").write_text("RULE 01: bare numbered rule\n")
    out = drift(other, dcat).stdout
    assert "some-skill/SKILL.md" in out
    assert "SKIPPED" not in out                     # iron-rules-governance found in the second root


def test_drift_bad_root_exits_2(tmp_path):
    assert drift(tmp_path / "nope").returncode == 2
