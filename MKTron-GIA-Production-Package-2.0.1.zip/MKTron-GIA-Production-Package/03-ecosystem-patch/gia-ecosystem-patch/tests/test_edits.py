"""Anchored live-skill edits: success, idempotency, and every refusal path. Plus a real-catalog integration test."""
import re, shutil, subprocess, sys
from pathlib import Path
import pytest, yaml

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "payload/akos-graphify-bridge/scripts"))
import edits  # noqa: E402
import apply_patch as ap  # noqa: E402

NS = """# RACM and RC Namespaces

```
""" + "\n".join(f"RACM-{i:02d}  Racm item number {i} text here for control work" for i in range(1, 13)) + """
```

```
""" + "\n".join(f"RC-{i:02d}:  Report conversion item {i} text for migration work" for i in range(1, 13)) + "\n```\n"


def racm_text(n=12, tweak=None):
    lines = [f"RULE {i:02d}  Racm item number {i} text here for control work" for i in range(1, n + 1)]
    if tweak:
        lines[tweak[0]] = tweak[1]
    return "# skill\n\n" + "\n".join(lines) + "\n\nTail text.\n"


def rc_text(tweak=None):
    lines = [f"RULE {i}:  Report conversion item {i} text for migration work" for i in range(1, 13)]
    if tweak:
        lines[tweak[0]] = tweak[1]
    return "\n".join(lines) + "\n"


CTX = {"namespace_doc": NS}


# ---- E1 / E2 ------------------------------------------------------------------------------------------------
def test_racm_rename_and_idempotent():
    out = edits.t_racm(racm_text(), dict(CTX))
    assert re.findall(r"^RACM-\d\d  ", out, re.M).__len__() == 12 and "RULE " not in out
    assert edits.t_racm(out, dict(CTX)) == out                         # already applied -> unchanged


def test_rc_rename_uses_colon_format():
    out = edits.t_rc(rc_text(), dict(CTX))
    assert out.splitlines()[0].startswith("RC-01:  Report") and out.splitlines()[11].startswith("RC-12:  ")
    assert edits.t_rc(out, dict(CTX)) == out


def test_paraphrase_is_renamed_but_wording_kept_and_reported():
    ctx = dict(CTX)
    t = racm_text(tweak=(11, "RULE 12  Racm item number 12 text here for control work, reworded slightly"))
    out = edits.t_racm(t, ctx)
    assert "RACM-12  Racm item number 12 text here for control work, reworded slightly" in out
    assert len(ctx["notes"]) == 1 and "RACM-12" in ctx["notes"][0]


@pytest.mark.parametrize("bad", [
    racm_text(tweak=(2, "RULE 03  Completely unrelated sentence about pizza")),               # material difference
    racm_text(n=11),                                                                          # wrong count
    racm_text() + "See RULE 07 for details.\n",                                               # stray reference would dangle
])
def test_racm_refuses_unsafe_cases(bad):
    with pytest.raises(edits.EditError):
        edits.t_racm(bad, dict(CTX))


def test_refuses_more_than_two_paraphrases_and_missing_namespace_doc():
    t = racm_text()
    for i in (1, 2, 3):
        t = t.replace(f"text here for control work", f"text here for control work", 1)
    many = "\n".join(f"RULE {i:02d}  Racm item number {i} text here for control work and some extra words" for i in range(1, 13)) + "\n"
    with pytest.raises(edits.EditError, match="materially|differs"):
        edits.t_racm(many, dict(CTX))
    with pytest.raises(edits.EditError, match="not found"):
        edits.t_racm(racm_text(), {"namespace_doc": None})


# ---- E3 ----------------------------------------------------------------------------------------------------------
V6 = (f"RULE 09  CAE quality gate (10 items) must FULLY pass before report is FINAL\n\n{edits.OLD_GATE}\n"
      "`generateReport()` blocked if QA score < 100%.\n\n10. CAE Quality Gate Results (10 items + score)\n")


def test_v6_gate_becomes_truthfully_12():
    out = edits.t_v6_gate(V6, {})
    rows = re.findall(r"^\| (\d+) \|", out, re.M)
    assert rows == [str(i) for i in range(1, 13)]                      # asserted 12 == enumerated 12 (Rule 30)
    assert "10-Item" not in out and "10 items" not in out and "12 items" in out
    assert "Deficiency classification (CD / SD / MW)" in out and "Aggregation assessment completed" in out
    assert edits.t_v6_gate(out, {}) == out


def test_v6_gate_refuses_if_table_was_edited():
    with pytest.raises(edits.EditError):
        edits.t_v6_gate(V6.replace("No duplicate findings", "No duplicates"), {})


# ---- E4 ------------------------------------------------------------------------------------------------------------
def test_mas_headings_do_not_trip_drift_check_two():
    s = edits.t_mas_skill("a\n## Iron Rules (apply in every phase, no exception)\nb\n", {})
    p = edits.t_mas_protocol("## 11. Iron Rules (absolute, no exception)\nx\n## 12. Golden Rules\n", {})
    for text in (s, p):
        assert not re.search(r"^#+.*iron rules", text, re.I | re.M)
    assert edits.t_mas_skill(s, {}) == s and edits.t_mas_protocol(p, {}) == p
    with pytest.raises(edits.EditError):
        edits.t_mas_skill("no such heading", {})


# ---- E5 ------------------------------------------------------------------------------------------------------------
LEG = "---\nname: old-skill\ndescription: >\n  Old plugin v4.0 does things.\n---\nbody\n"


def test_legacy_banner_added_idempotent_and_valid_yaml():
    out = edits.t_legacy(LEG, {"superseder_installed": True})
    fm = yaml.safe_load(re.match(r"^---\n(.*?)\n---", out, re.S).group(1))
    assert fm["description"].startswith("LEGACY, superseded (see cae-cowork-ai-plugin).") and fm["name"] == "old-skill"
    assert edits.t_legacy(out, {"superseder_installed": True}) == out


def test_legacy_refused_without_successor_or_when_too_long():
    with pytest.raises(edits.EditError, match="not installed"):
        edits.t_legacy(LEG, {"superseder_installed": False})
    long = LEG.replace("Old plugin v4.0 does things.", "x" * 1000)
    with pytest.raises(edits.EditError, match="1024"):
        edits.t_legacy(long, {"superseder_installed": True})
    with pytest.raises(edits.EditError, match="folded"):
        edits.t_legacy("---\nname: a\ndescription: plain one liner\n---\n", {"superseder_installed": True})


# ---- apply_patch text_edit plumbing ---------------------------------------------------------------------------------
def test_text_edit_dry_run_apply_backup_and_notes(tmp_path):
    cat = tmp_path / "cat"; f = cat / "plugins/racm/SKILL.md"; f.parent.mkdir(parents=True)
    f.write_text(racm_text(tweak=(11, "RULE 12  Racm item number 12 text here for control work, reworded slightly")))
    before = f.read_text()
    p = ap.Patcher(cat, tmp_path / "bk", apply=False)
    p.text_edit("E1", f, edits.t_racm, "racm", dict(CTX))
    assert f.read_text() == before and [s for _, s, _ in p.log] == ["WOULD APPLY", "NOTE"]
    p = ap.Patcher(cat, tmp_path / "bk", apply=True)
    p.text_edit("E1", f, edits.t_racm, "racm", dict(CTX))
    assert "RACM-01" in f.read_text() and (tmp_path / "bk/plugins/racm/SKILL.md").read_text() == before
    p2 = ap.Patcher(cat, tmp_path / "bk2", apply=True)
    p2.text_edit("E1", f, edits.t_racm, "racm", dict(CTX))
    assert p2.log[0][1] == "ALREADY APPLIED" and not (tmp_path / "bk2").exists()


def test_text_edit_skips_missing_file_and_refusals(tmp_path):
    p = ap.Patcher(tmp_path, tmp_path / "bk", apply=True)
    p.text_edit("E1", tmp_path / "nope/SKILL.md", edits.t_racm, "x", dict(CTX))
    f = tmp_path / "SKILL.md"; f.write_text("nothing here")
    p.text_edit("E1", f, edits.t_racm, "x", dict(CTX))
    assert [s for _, s, _ in p.log] == ["SKIPPED", "SKIPPED"] and f.read_text() == "nothing here"


# ---- integration: the real catalog ----------------------------------------------------------------------------------
REAL = Path("/mnt/skills")


_NEEDS = ("user/akos-enterprise-orchestrator", "plugins/iron-rules-governance", "plugins/racm-ecosystem", "plugins/cae-cowork-ai-plugin",
          "plugins/cae-report-conversion", "plugins/master-audit-superagent", "plugins/cae-audit-cowork-plugin-v4", "public/file-reading")


@pytest.mark.skipif(not all((REAL / n).exists() for n in _NEEDS) or not (REAL / "plugins/mktron-pune-vda-compliance:pune-india-ops-audit").exists(),
                    reason="needs the original maintainer catalog layout (exact operation counts); the layout-agnostic tests cover other catalogs")
def test_full_patch_on_real_catalog_copy(tmp_path):
    cat = tmp_path / "cat"
    cat.mkdir()
    for d in ("user", "plugins", "public"):
        if (REAL / d).is_dir():
            shutil.copytree(REAL / d, cat / d)
    p = ap.Patcher(cat, tmp_path / "bk", apply=True)
    log = p.run()
    assert not [x for x in log if x[1] == "SKIPPED"], [x for x in log if x[1] == "SKIPPED"]
    assert sum(1 for x in log if x[1] == "APPLIED") == 14
    out = subprocess.run(["bash", str(cat / "plugins/iron-rules-governance/scripts/check-governance-drift.sh"),
                          str(cat / "plugins"), str(cat / "user")], capture_output=True).stdout.decode("utf-8", "replace")
    flagged = re.findall(r"--- Check (\d)[^\n]*\n\s+FINDING", out)
    assert flagged == ["4"], f"only D6 (charlie-hills, owner decision) should remain, got checks {flagged}"
    assert all(x[1] == "ALREADY APPLIED" for x in ap.Patcher(cat, tmp_path / "bk2", apply=True).run())
