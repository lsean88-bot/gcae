"""apply_patch hardening: crash safety, isolation, lock, containment, journal and rollback."""
import json, os, shutil, subprocess, sys
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "payload/akos-graphify-bridge/scripts"))
import apply_patch as ap  # noqa: E402
import edits, fsutil  # noqa: E402

AKOS = ap.AKOS


@pytest.fixture(autouse=True)
def env(monkeypatch):
    monkeypatch.setenv("GIA_NO_FSYNC", "1")


def skill(d: Path, name, version=None, body=""):
    d.mkdir(parents=True, exist_ok=True)
    meta = f'metadata:\n  version: "{version}"\n' if version else ""
    (d / "SKILL.md").write_text(f"---\nname: {name}\ndescription: d\n{meta}---\n{body}\n")


@pytest.fixture
def cat(tmp_path):
    c = tmp_path / "cat"
    skill(c / "user" / AKOS, AKOS, "2.2", "old akos")
    skill(c / "plugins" / ap.AKOS_PLUGIN, AKOS, "2.1", "older akos")
    skill(c / "plugins/pune-india-ops-audit", "pune-india-ops-audit", "1.0")
    skill(c / "plugins/mktron-pune-vda-compliance:pune-india-ops-audit", "pune-india-ops-audit", "1.1")
    skill(c / "plugins/file-reading", "file-reading", None, "old")
    skill(c / "public/file-reading", "file-reading", None, "new")
    sd = c / "plugins/iron-rules-governance/scripts"; sd.mkdir(parents=True); (sd / "check-governance-drift.sh").write_text("#!/bin/bash\necho old\n")
    return c


def snapshot(root: Path) -> dict:
    out = {}
    for p in sorted(root.rglob("*")):
        if p.is_symlink():
            continue
        out[str(p.relative_to(root))] = "DIR" if p.is_dir() else fsutil.sha256_file(p)
    return out


def cli(*a):
    return subprocess.run([sys.executable, str(ROOT / "apply_patch.py"), *map(str, a)], capture_output=True, text=True,
                          env={**os.environ, "GIA_NO_FSYNC": "1"})


# ============================================================ crash safety of folder installs
def _run_with_fault(cat, tmp_path, fault):
    """Run the AKOS install with a fault injected at a named step; return the exception (swallowed)."""
    real_copytree, real_rename, real_replace_dir = shutil.copytree, os.rename, fsutil.replace_dir
    calls = {"copytree": 0, "rename": 0}
    def ct(*a, **k):
        calls["copytree"] += 1
        if fault == "staging-copy" and calls["copytree"] == 2:      # 1st copytree = backup, 2nd = staging
            raise OSError("injected: disk full while staging")
        return real_copytree(*a, **k)
    def rn(a, b):
        calls["rename"] += 1
        if fault == "first-rename" and calls["rename"] == 1: raise OSError("injected: first rename")
        if fault == "second-rename" and calls["rename"] == 2: raise OSError("injected: second rename")
        return real_rename(a, b)
    shutil.copytree, os.rename = ct, rn
    try:
        p = ap.Patcher(cat, tmp_path / "bk", True)
        p.sync_folder("A", ap.PAYLOAD / AKOS, cat / "user" / AKOS, "AKOS")
        return None
    except OSError as exc:
        return exc
    finally:
        shutil.copytree, os.rename = real_copytree, real_rename


@pytest.mark.parametrize("fault", ["staging-copy", "first-rename", "second-rename"])
def test_a_failure_at_any_install_step_leaves_the_live_skill_untouched(cat, tmp_path, fault):
    before = snapshot(cat / "user" / AKOS)
    exc = _run_with_fault(cat, tmp_path, fault)
    assert exc is not None
    assert snapshot(cat / "user" / AKOS) == before                  # the old folder is exactly as it was
    assert not [p for p in (cat / "user").iterdir() if ".new-" in p.name or ".old-" in p.name], "no debris left behind"


def test_a_kill_between_the_two_renames_is_recovered_by_the_next_run(cat, tmp_path):
    live = cat / "user" / AKOS
    os.rename(live, cat / "user" / f"{AKOS}.old-4242")             # exactly the state after kill -9
    (cat / "user" / f".{AKOS}.new-4242").mkdir(); (cat / "user" / f".{AKOS}.new-4242/SKILL.md").write_text("partial")
    assert not live.exists()
    p = ap.Patcher(cat, tmp_path / "bk", True); p.run()
    assert (live / "SKILL.md").exists() and 'version: "2.3"' in (live / "SKILL.md").read_text()
    assert not [x for x in (cat / "user").iterdir() if ".old-" in x.name or ".new-" in x.name]
    assert any(s == "RECOVERED" for _, s, _ in p.log) and any(s == "CLEANED" for _, s, _ in p.log)


def test_users_own_lookalike_folders_are_never_touched_by_recovery(cat, tmp_path):
    skill(cat / "user/my-skill.old-2025-backup", "x")
    ap.Patcher(cat, tmp_path / "bk", True).run()
    assert (cat / "user/my-skill.old-2025-backup/SKILL.md").exists() and not (cat / "user/my-skill").exists()


# ============================================================ isolation of operations
def test_one_failing_operation_does_not_stop_the_others(cat, tmp_path, monkeypatch):
    real = ap.Patcher.retire
    def boom(self, op, *a, **k):
        if op == "B1": raise RuntimeError("injected failure in B1")
        return real(self, op, *a, **k)
    monkeypatch.setattr(ap.Patcher, "retire", boom)
    p = ap.Patcher(cat, tmp_path / "bk", True); log = p.run()
    st = {(op, s) for op, s, _ in log}
    assert ("B1", "FAILED") in st and ("A", "APPLIED") in st and ("B2", "APPLIED") in st and ("C", "APPLIED") in st and ("D", "APPLIED") in st
    assert (cat / "plugins/pune-india-ops-audit").exists()          # the failed op changed nothing


def test_cli_exit_code_is_1_when_an_operation_failed(cat, tmp_path, monkeypatch):
    # a read-only target makes the drift-script replacement fail for real (skipped when running as root)
    if os.geteuid() == 0:
        pytest.skip("root ignores file permissions")
    d = cat / "plugins/iron-rules-governance/scripts"; os.chmod(d, 0o555)
    try:
        r = cli("--catalog", cat, "--backup-dir", tmp_path / "bk", "--apply")
        assert r.returncode == 1 and "FAILED" in r.stdout and "--rollback" in r.stdout
    finally:
        os.chmod(d, 0o755)


# ============================================================ lock, containment, dry run
def test_backup_inside_the_catalog_is_refused(cat):
    r = cli("--catalog", cat, "--backup-dir", cat / "user/_backup", "--apply")
    assert r.returncode == 2 and "inside the catalog" in r.stderr and not (cat / "user/_backup").exists()
    assert cli("--catalog", cat, "--backup-dir", cat / "user" / ".." / "user" / "x").returncode == 2        # sneaky relative form


def test_a_second_concurrent_apply_is_refused(cat, tmp_path):
    with fsutil.FileLock(cat / ".gia-patch.lock", timeout=1):
        r = cli("--catalog", cat, "--backup-dir", tmp_path / "bk", "--apply")
    assert r.returncode == 2 and "another apply is running" in r.stderr
    assert cli("--catalog", cat, "--backup-dir", tmp_path / "bk", "--apply").returncode == 0           # free again


def test_dry_run_writes_nothing_at_all(cat, tmp_path):
    before = snapshot(cat)
    r = cli("--catalog", cat, "--backup-dir", tmp_path / "bk")
    assert r.returncode == 0 and "DRY RUN" in r.stdout
    assert snapshot(cat) == before and not (tmp_path / "bk").exists() and not (cat / ".gia-patch.lock").exists()


def test_second_apply_changes_nothing_and_records_nothing(cat, tmp_path):
    assert cli("--catalog", cat, "--backup-dir", tmp_path / "bk1", "--apply").returncode == 0
    after = snapshot(cat)
    r = cli("--catalog", cat, "--backup-dir", tmp_path / "bk2", "--apply")
    assert r.returncode == 0 and snapshot(cat) == after
    j = json.loads((tmp_path / "bk2" / ap.JOURNAL).read_text()); assert j["entries"] == []


# ============================================================ journal and rollback
def test_rollback_restores_the_catalog_byte_for_byte(cat, tmp_path):
    before = snapshot(cat)
    assert cli("--catalog", cat, "--backup-dir", tmp_path / "bk", "--apply").returncode == 0
    assert snapshot(cat) != before
    r = cli("--catalog", cat, "--rollback", tmp_path / "bk")
    assert r.returncode == 0 and "ROLLED BACK" in r.stdout
    after = {k: v for k, v in snapshot(cat).items() if k != ".gia-patch.lock"}
    assert after == before


def test_rollback_is_idempotent(cat, tmp_path):
    cli("--catalog", cat, "--backup-dir", tmp_path / "bk", "--apply")
    cli("--catalog", cat, "--rollback", tmp_path / "bk")
    r = cli("--catalog", cat, "--rollback", tmp_path / "bk")
    assert r.returncode == 0 and "already rolled back" in r.stdout


def test_rollback_will_not_overwrite_later_edits_without_force(cat, tmp_path):
    cli("--catalog", cat, "--backup-dir", tmp_path / "bk", "--apply")
    mine = cat / "user" / AKOS / "SKILL.md"
    mine.write_text(mine.read_text() + "\nMY OWN LATER EDIT\n")
    r = cli("--catalog", cat, "--rollback", tmp_path / "bk")
    assert r.returncode == 1 and "changed since the patch" in r.stdout and "MY OWN LATER EDIT" in mine.read_text()
    r = cli("--catalog", cat, "--rollback", tmp_path / "bk", "--force")
    assert r.returncode == 0 and "MY OWN LATER EDIT" not in mine.read_text()


def test_rollback_refuses_a_foreign_or_tampered_journal(cat, tmp_path):
    cli("--catalog", cat, "--backup-dir", tmp_path / "bk", "--apply")
    other = tmp_path / "other"; other.mkdir()
    assert cli("--catalog", other, "--rollback", tmp_path / "bk").returncode == 2                 # wrong catalog
    assert cli("--catalog", cat, "--rollback", tmp_path / "empty").returncode == 2                # not a backup folder
    jf = tmp_path / "bk" / ap.JOURNAL; j = json.loads(jf.read_text())
    victim = tmp_path / "victim"; victim.mkdir(); (victim / "keep.txt").write_text("precious")
    j["entries"].insert(0, {"op": "X", "kind": "created-dir", "path": "../victim", "backup": None, "after": None})
    jf.write_text(json.dumps(j))
    r = cli("--catalog", cat, "--rollback", tmp_path / "bk")
    assert (victim / "keep.txt").read_text() == "precious" and "outside" in r.stdout + r.stderr   # a doctored journal cannot delete outside


def test_retired_folders_come_back_on_rollback_and_never_overwrite(cat, tmp_path):
    cli("--catalog", cat, "--backup-dir", tmp_path / "bk", "--apply")
    assert not (cat / "plugins/pune-india-ops-audit").exists()
    skill(cat / "plugins/pune-india-ops-audit", "pune-india-ops-audit", "9.9", "someone reinstalled it")
    r = cli("--catalog", cat, "--rollback", tmp_path / "bk")
    assert r.returncode == 1 and "someone reinstalled it" in (cat / "plugins/pune-india-ops-audit/SKILL.md").read_text()


# ============================================================ the real catalog: apply, then undo, then compare
REAL = Path(os.environ.get("GIA_REAL_CATALOG", "/mnt/skills"))
ROOTS = [d for d in ("user", "plugins", "public") if (REAL / d).is_dir()]


def _copy_real(tmp_path):
    c = tmp_path / "cat"; c.mkdir()
    for d in ROOTS:
        shutil.copytree(REAL / d, c / d)
    return c


@pytest.mark.skipif(not ROOTS, reason="no real catalog available")
def test_real_catalog_apply_then_rollback_is_byte_identical(tmp_path):
    """Layout-agnostic: works on whatever roots the catalog has (user/, plugins/, public/ in any combination)."""
    c = _copy_real(tmp_path)
    before = snapshot(c)
    r = cli("--catalog", c, "--backup-dir", tmp_path / "bk", "--apply")
    assert r.returncode == 0, r.stdout + r.stderr
    assert "FAILED" not in r.stdout
    r = cli("--catalog", c, "--rollback", tmp_path / "bk")
    assert r.returncode == 0, r.stdout
    assert {k: v for k, v in snapshot(c).items() if k != ".gia-patch.lock"} == before


@pytest.mark.skipif(not ROOTS, reason="no real catalog available")
def test_patch_on_any_real_catalog_never_fails_and_is_idempotent(tmp_path):
    c = _copy_real(tmp_path)
    r1 = cli("--catalog", c, "--backup-dir", tmp_path / "bk1", "--apply")
    assert r1.returncode == 0 and "FAILED" not in r1.stdout, r1.stdout + r1.stderr
    after = snapshot(c)
    r2 = cli("--catalog", c, "--backup-dir", tmp_path / "bk2", "--apply")
    assert r2.returncode == 0 and "APPLIED       ]" not in r2.stdout.replace("ALREADY APPLIED", "")
    assert snapshot(c) == after


def test_a_folder_that_apply_had_to_create_is_removed_again_by_rollback(tmp_path):
    c = tmp_path / "cat"; skill(c / "plugins" / ap.AKOS_PLUGIN, AKOS, "2.1", "older akos")       # NO user/ folder at all
    before = snapshot(c)
    assert cli("--catalog", c, "--backup-dir", tmp_path / "bk", "--apply").returncode == 0
    assert (c / "user/akos-graphify-bridge/SKILL.md").exists()
    assert cli("--catalog", c, "--rollback", tmp_path / "bk").returncode == 0
    assert not (c / "user").exists()
    assert {k: v for k, v in snapshot(c).items() if k != ".gia-patch.lock"} == before


def test_rollback_leaves_a_created_folder_alone_if_someone_has_since_used_it(tmp_path):
    c = tmp_path / "cat"; skill(c / "plugins" / ap.AKOS_PLUGIN, AKOS, "2.1", "older akos")
    cli("--catalog", c, "--backup-dir", tmp_path / "bk", "--apply")
    (c / "user/my-own-skill").mkdir(); (c / "user/my-own-skill/SKILL.md").write_text("mine")
    r = cli("--catalog", c, "--rollback", tmp_path / "bk", "--force")
    assert (c / "user/my-own-skill/SKILL.md").read_text() == "mine"                     # never deleted
    assert not (c / "user/akos-graphify-bridge").exists()
