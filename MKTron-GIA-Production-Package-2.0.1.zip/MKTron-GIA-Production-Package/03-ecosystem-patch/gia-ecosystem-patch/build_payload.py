#!/usr/bin/env python3
"""Build the patch payload from the live catalog. Every edit asserts its anchor text exists the expected
number of times, so a changed source file makes the build FAIL LOUDLY instead of silently mis-patching a
governance document. Usage: build_payload.py [--catalog /mnt/skills] [--out ./payload]"""
import argparse
import re
import shutil
import sys
from pathlib import Path


def sub(text, old, new, count=1, label=""):
    n = text.count(old)
    if n != count:
        sys.exit(f"ANCHOR MISMATCH [{label or old[:50]!r}]: expected {count}, found {n}. "
                 f"The source changed - review before patching.")
    return text.replace(old, new)


def insert_before(text, marker, block, label):
    if text.count(marker) < 1:
        sys.exit(f"ANCHOR MISSING [{label}]: {marker[:60]!r}")
    i = text.index(marker)
    return text[:i] + block + text[i:]


# ------------------------------------------------------------------------------------------------
REGISTRY_LAYER = '''### Engagement Lifecycle, Data & Engineering Layer

> *Added v2.3 (3 Oct 2026). These contracts are derived from each skill's own frontmatter description, not from
> a line-by-line read of every skill: owner to confirm or amend. Where a skill declares supersession in its own
> metadata, the declaration is quoted here, not decided here.*

**`cae-cowork-ai-plugin`** (v6.0)
- *Reads:* engagement scope, PBC/document inventory, prior fieldwork state.
- *Produces:* fieldwork (TP01-TP14), compliance validation, reconciliation tests, findings pipeline with CD/SD/MW
  aggregation, report, management-response and follow-up panels, AI-assisted analytics (Benford, variance,
  duplicate, outlier).
- *Writes back:* Evidence Register, Knowledge Graph (Document, Issue nodes), Outstanding Questions, Decisions Register.
- *Typically followed by:* `cae-report-conversion`, `group-cae-fraud-v2` (if fieldwork surfaces a red flag), or the
  entity-specific skill for deeper domain testing.
- *Coordination note:* its own metadata declares that it supersedes `cae-audit-cowork-plugin-v4` and
  `cae-audit-cowork-plugin-v5`, which are therefore superseded legacy skills kept only for engagements already begun
  on them. New work routes here. Its text still asserts a "10 items" CAE quality gate under its Rule 09 where the
  canonical gate has 12 (Decision D5).

**`racm-ecosystem`**
- *Reads:* RACM/RCM workbook, ICFR scope, control population.
- *Produces:* scoped RACM, COSO IC 2013 mapping, key-control identification, ToD/ToE structure, SD/MW/MN deficiency
  classification, red-flag surveillance, audit plan.
- *Writes back:* Knowledge Graph (Risk, Control nodes), Evidence Register, Decisions Register.
- *Typically followed by:* `cae-cowork-ai-plugin` (fieldwork), `board-chairman-briefing`.
- *Coordination note:* owns its own `RACM-`/`RC-` numbering namespace (`references/racm-rc-namespaces.md`). Do not
  renumber its items into the canonical Iron Rules list.

**`master-audit-superagent`**
- *Reads:* engagement brief and any existing Project Memory.
- *Produces:* an end-to-end lifecycle run through a 17-agent specialist team, ending in a QA-gated decision-ready report.
- *Writes back:* Evidence Register, findings, Decisions Register.
- *Typically followed by:* `cae-report-conversion`, `board-chairman-briefing`.
- *Coordination note:* overlaps AKOS's own orchestration role. Whichever of the two is already running the engagement
  leads (Module 1); the other joins as a team member. It carries its own "Iron Rules" header, which the drift check
  flags (Decision D7).

**`mktron-gia-data-reconciliation`**
- *Reads:* the 06_DATA JSON layer (entities, engagements, risk_register, racm, entity_risk_profiles, audit_plan).
- *Produces:* a reconciled data layer, regenerated AUDIT_PLAN.csv/xlsx, the rolling 12+12 month audit plan.
- *Writes back:* Decisions Register; Outstanding Questions for data conflicts it cannot resolve.
- *Typically followed by:* `cae-command-centre` (audit universe and annual plan). Owner to confirm.
- *Coordination note:* the 06_DATA JSON layer is a second store of entities, risks and RACM beside
  `KNOWLEDGE_GRAPH.json`. Do not hand-merge them: run this skill first, then update the Knowledge Graph through Module 11.

**`charlie-hills-code`**
- *Reads:* any coding, bug, architecture or technical-planning task.
- *Produces:* plan-first execution, task files, verified changes.
- *Writes back:* Decisions Register (technical choices); recurring-pattern lessons as LESSONS_LEARNED candidates.
- *Typically followed by:* `debugger` for end-to-end UAT of HTML/GIA apps.
- *Coordination note:* carries its own "CLAUDE.md Self-Update Rule", a second self-learning description. AKOS Module 7
  is canonical. Its structure also differs from the five-phase summary in `iron-rules-governance` (known open item, D6).

**`debugger`**
- *Reads:* an error, stack trace, unexpected behaviour or UAT request, including the MKTron GIA HTML app (v7-v9).
- *Produces:* root-cause diagnosis, fix, UAT results (functional, offline, localStorage, responsive, accessibility).
- *Writes back:* LESSONS_LEARNED candidates for recurring app bugs; Decisions Register.
- *Typically followed by:* return of control to the calling skill.

'''

REGISTRY_FRAUD_V2 = '''**`group-cae-fraud-v2`**
- *Reads:* an allegation, red flag, ABAC or financial-statement-fraud concern, or Benford anomaly.
- *Produces:* fraud risk governance (ABAC, financial statement fraud, window dressing, off-balance-sheet,
  misappropriation, abuse of power, agentic-AI monitoring), 20 modus operandi patterns, investigation plan and report.
- *Writes back:* Evidence Register (strict chain-of-custody), Confirmed Facts only once an allegation is confirmed,
  Decisions Register. Never blur "alleged" and "confirmed".
- *Typically followed by:* `board-chairman-briefing`, `cae-report-conversion`.
- *Coordination note:* same isolation rule as `group-cae-fraud`: an active, unconfirmed investigation is its own
  isolated engagement (a `confidential` shelf or Knowledge Graph, see `akos-graphify-bridge`). It overlaps
  `group-cae-fraud` and the fraud scope of `super-grc-audit-plugin-l99` (Decision D3). Interim rule: new work goes to
  v2, and v1 and v2 are never run on the same investigation.

'''

REGISTRY_REPORTING = '''**`group-cae-external-reporting`**
- *Reads:* a finished, approved deliverable plus the external audience (regulator, statutory authority, external
  auditor, lender, investor).
- *Produces:* a submission-ready document with no drafting artefacts, in the objective voice external readers expect,
  with statutory terms localised per jurisdiction.
- *Writes back:* Decisions Register (what was released, to whom, when).
- *Typically preceded by:* `cae-report-conversion` or `board-chairman-briefing`.
- *Coordination note:* internal audiences stay with `group-cae-reporting`; anything leaving the Group comes here
  (stated in its own description).

'''

REGISTRY_BRIDGE = '''**`akos-graphify-bridge`**
- *Reads:* `KNOWLEDGE_GRAPH.json`, graphify `graph.json`, an optional entity map, and (library brain) the shelf
  folders under a brain library.
- *Produces:* graphify graph and HTML view, staged Knowledge Graph items marked PROPOSED, a Module 9 validation
  report, the Board-safe deliverable subset, recall results with trust labels, an interop report.
- *Writes back:* proposed Knowledge Graph nodes and edges only (never confirmed ones), Outstanding Questions for
  unclassified items, Decisions Register candidates for conflicts, LESSONS_LEARNED *candidates* from saved work-memory.
- *Typically followed by:* `akos-enterprise-orchestrator` (confirm and record), a domain skill (classify),
  `cae-report-conversion` or `board-chairman-briefing` (publish the deliverable subset only).
- *Coordination note:* never confirms a fact, assigns a finding rating, or decides entity classification. graphify
  confidence is not evidence rank, and a saved Q&A answer is an indicator, never evidence (Iron Rule 17).

'''

REGISTRY_FAMILIES = '''### Skill families and declared supersession

Read from the skills' own metadata on 3 Oct 2026, not decided by AKOS.

| Skill that declares it | Declared superseded by it | Registry status |
|---|---|---|
| `cae-cowork-ai-plugin` v6.0 | `cae-audit-cowork-plugin-v4`, `cae-audit-cowork-plugin-v5` (and v5.01 of itself) | **Applied (D1).** Routes moved to v6; v4 and v5 are superseded legacy, kept only for engagements already begun on them |
| `cae-audit-cowork-plugin-v4` | `cae-audit-cowork-plugin` (v2.0) | `cae-audit-cowork-plugin` is superseded legacy |
| `super-grc-audit-plugin-l99` | `group-cae`, `group-cae-core`, `group-cae-fraud`, `group-cae-reporting`, `managing-internal-audit`, `cae-audit-cowork-plugin`, `ia-rag-assistant` | **Not applied (D2 pending).** Declared superseded by it, but none of those skills acknowledges that, and this registry still routes to `group-cae-reporting` and `group-cae-fraud`. Owner decision |

Open decisions with evidence and a recommendation each: see `DECISIONS_PENDING.md` shipped with the v2.3 patch
(D2 L99 family, D3 fraud overlap, D4 missing `mac-audit-constitution-l99`, D5 v6 "10-item" gate, D6 `charlie-hills-code`
structure, D7 `master-audit-superagent` rule header, D8 Perfect Longevity entity code).

'''

REGISTRY_RULES = '''6. **Version families: newest declared successor wins.** When a skill's own metadata declares it supersedes another,
   route new work to the successor and keep the older skill only for engagements already begun on it. A declaration
   that no other skill acknowledges (D2) is surfaced as an Outstanding Question, not silently applied.
7. **One investigation, one fraud skill.** Never run `group-cae-fraud` and `group-cae-fraud-v2` on the same
   investigation; sequence, do not parallelise (rule 4).
8. **Graph analysis versus graph integrity.** Visualising, querying, shelving and validating the Knowledge Graph goes to
   `akos-graphify-bridge`; the Module 9 gate and the decision to confirm a fact stay with AKOS.
'''

MODULE17_ADDENDUM = '''## v2.3 change record (3 Oct 2026)

Applied from the akos-graphify-bridge UAT and interop review (evidence: interop check across the installed catalog).

- **D1 applied.** Routing for field-audit execution moved from `cae-audit-cowork-plugin-v4` to `cae-cowork-ai-plugin`,
  because v6.0's own metadata declares it supersedes v4 and v5. v4/v5 are legacy, kept for engagements already begun
  on them. Revert by restoring the v2.2 copy.
- **Registry gaps closed.** Nine skills the registry never named now have handoff contracts (derived from each skill's
  description; owner to confirm): `cae-cowork-ai-plugin`, `racm-ecosystem`, `master-audit-superagent`,
  `mktron-gia-data-reconciliation`, `charlie-hills-code`, `debugger`, `group-cae-fraud-v2`,
  `group-cae-external-reporting`, `akos-graphify-bridge`.
- **Duplicate install resolved.** The installed-plugin copy (v2.1) is replaced by this single v2.3; two identical
  copies is acceptable, two different ones is not.
- **Still open, not decided here:** D2-D8 in `DECISIONS_PENDING.md`. `mac-audit-constitution-l99` (D4) remains
  "retired on purpose, or missing by accident?" and the reconciliation history records it as de-framed, not retired.

---

'''


def build_akos(catalog: Path, out: Path):
    src_user = catalog / "user" / "akos-enterprise-orchestrator"
    src_plug = catalog / "plugins" / "akos-enterprise-orchestrator:akos-enterprise-orchestrator"
    dst = out / "akos-enterprise-orchestrator"
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(src_user, dst, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    # keep the evals that only the older plugin copy carried
    if (src_plug / "evals").is_dir() and not (dst / "evals").exists():
        shutil.copytree(src_plug / "evals", dst / "evals")

    # ---- SKILL.md
    p = dst / "SKILL.md"
    t = p.read_text(encoding="utf-8")
    t = sub(t, '  version: "2.2"', '  version: "2.3"', 1, "version")
    t = sub(t, "cae-audit-cowork-plugin-v4, cae-command-centre, group-cae-reporting",
            "cae-cowork-ai-plugin, akos-graphify-bridge, cae-command-centre, group-cae-reporting", 1, "complements")
    t = sub(t, "See Module 17 for full disposition.\"",
            "v2.3 (3 Oct 2026): routing moved to cae-cowork-ai-plugin (declared successor of v4/v5), nine unregistered skills "
            "given handoff contracts, duplicate plugin install retired, akos-graphify-bridge added. See Module 17.\"", 1, "origin")
    t = sub(t, "| Field audit execution with AI-augmented analytics | `cae-audit-cowork-plugin-v4` |\n",
            "| Field audit execution with AI-augmented analytics | `cae-cowork-ai-plugin` (v6.0; v4/v5 are superseded legacy) |\n"
            "| Visualise, query, shelve or validate the knowledge graph (library brain) | `akos-graphify-bridge` |\n", 1, "routing")
    t = sub(t, "Version 2.2*", "Version 2.3*", 1, "footer-version")
    t = sub(t, "*cae-audit-cowork-plugin-v4, cae-command-centre, board-chairman-briefing,*",
            "*cae-cowork-ai-plugin, akos-graphify-bridge, cae-command-centre, board-chairman-briefing,*", 1, "footer")
    marker = "## QUICK REFERENCE — AKOS"
    i = t.index(marker)
    j = t.rfind("## ═", 0, i)
    t = t[:j] + MODULE17_ADDENDUM + t[j:]
    p.write_text(t, encoding="utf-8")

    # ---- agent-specifications.md
    p = dst / "references" / "agent-specifications.md"
    t = p.read_text(encoding="utf-8")
    t = sub(t, "`cae-audit-cowork-plugin-v4`", "`cae-cowork-ai-plugin`", 1, "agent-spec v4")
    p.write_text(t, encoding="utf-8")

    # ---- registry
    p = dst / "references" / "plugin-coordination-registry.md"
    t = p.read_text(encoding="utf-8")
    t = sub(t, "`cae-audit-cowork-plugin-v4` should already be a node", "`cae-cowork-ai-plugin` should already be a node", 1, "reg-44")
    t = sub(t, "**`cae-audit-cowork-plugin-v4`**\n", "**`cae-cowork-ai-plugin`** (supersedes v4/v5; contract also in the Lifecycle layer below)\n", 1, "reg-93")
    t = sub(t, "  `cae-audit-cowork-plugin-v4` for the actual test execution", "  `cae-cowork-ai-plugin` for the actual test execution", 1, "reg-116")
    t = sub(t, "`super-grc-audit-plugin-l99`/`cae-audit-cowork-plugin-v4`, not", "`super-grc-audit-plugin-l99`/`cae-cowork-ai-plugin`, not", 1, "reg-210")
    t = sub(t, "3. cae-audit-cowork-plugin-v4                       → fieldwork, sample testing",
            "3. cae-cowork-ai-plugin                            → fieldwork, sample testing", 1, "reg-233")
    t = sub(t, "4. group-cae-fraud (only if red flags surface)       → investigation branch",
            "4. group-cae-fraud-v2 (only if red flags surface)    → investigation branch", 1, "reg-234")
    t = insert_before(t, "### Domain Content Layer (entity/jurisdiction-specific)", REGISTRY_LAYER, "layer")
    t = insert_before(t, "### Governance & Oversight Layer", REGISTRY_FRAUD_V2, "fraud-v2")
    t = insert_before(t, "### Format/Output Layer", REGISTRY_REPORTING, "ext-reporting")
    t = sub(t, "- *Coordination note:* see `references/qa-verification-and-deliverable-standards.md`\n  §4 for which tool fits which visual.\n",
            "- *Coordination note:* see `references/qa-verification-and-deliverable-standards.md`\n  §4 for which tool fits which visual.\n\n" + REGISTRY_BRIDGE.rstrip("\n") + "\n", 1, "bridge")
    t = insert_before(t, "## 4. Conflict Resolution — When Two Skills Could Both Claim a Task", REGISTRY_FAMILIES + "---\n\n", "families")
    t = sub(t, "   rather than silently picking one.\n", "   rather than silently picking one.\n", 0, "noop") if False else t
    # append rules 6-8 after rule 5 (find end of rule 5 paragraph: blank line before '---' that precedes section 5)
    sec5 = "## 5. Worked Coordination Workflows"
    k = t.index(sec5)
    cut = t.rfind("\n---", 0, k)
    t = t[:cut].rstrip("\n") + "\n" + REGISTRY_RULES + t[cut:]
    p.write_text(t, encoding="utf-8")
    return dst


# ---- drift script ---------------------------------------------------------------------------------
def build_drift(catalog: Path, out: Path):
    src = catalog / "plugins" / "iron-rules-governance" / "scripts" / "check-governance-drift.sh"
    t = src.read_text(encoding="utf-8")
    # 1. multi-root scanning
    t = sub(t, 'SKILLS_DIR="${1:-/mnt/skills/user}"\n',
            '''# v1.1 (3 Oct 2026): scan EVERY root that holds skills. The original scanned only "$SKILLS_DIR/*/SKILL.md"
# (default /mnt/skills/user) so on a layout where the portfolio lives under /mnt/skills/plugins it reported
# "clean" for checks 1, 2 and 5 after looking at a single skill. Pass one or more roots, or rely on the default
# of every existing root among: /mnt/skills/user /mnt/skills/plugins $HOME/.claude/skills
if [ "$#" -gt 0 ]; then ROOTS=("$@"); else
  ROOTS=(); for d in /mnt/skills/user /mnt/skills/plugins "$HOME/.claude/skills"; do [ -d "$d" ] && ROOTS+=("$d"); done
  [ "${#ROOTS[@]}" -eq 0 ] && ROOTS=("/mnt/skills/user")
fi
SKILLS_DIR="${ROOTS[0]}"
# every SKILL.md and references/*.md under every root (one path per line)
scan_files() { for r in "${ROOTS[@]}"; do ls "$r"/*/SKILL.md "$r"/*/references/*.md 2>/dev/null; done; }
# locate one skill's SKILL.md across the roots
find_skill() { for r in "${ROOTS[@]}"; do [ -f "$r/$1/SKILL.md" ] && { echo "$r/$1/SKILL.md"; return; }; done; }
# true if the hit at FILE:LINE sits in a correction/history narrative (checked in the 6 lines above it)
is_narrative() { local f="$1" l="$2" s=$(( $2 > 6 ? $2 - 6 : 1 )); sed -n "${s},${l}p" "$f" 2>/dev/null | grep -qiE "correction|previously|formerly|used to|old claim|reconciled|de-framed"; }
''', 1, "roots")
    t = sub(t, 'if [ ! -d "$SKILLS_DIR" ]; then\n  echo "ERROR: \'$SKILLS_DIR\' is not a directory." >&2\n  exit 2\nfi',
            'for r in "${ROOTS[@]}"; do\n  [ -d "$r" ] || { echo "ERROR: \'$r\' is not a directory." >&2; exit 2; }\ndone', 1, "dir-check")
    t = sub(t, 'echo "Scanning: $SKILLS_DIR"', 'echo "Scanning: ${ROOTS[*]}"', 1, "scan-banner")
    # checks 1, 2, 3, 5: replace the glob lists
    glob = '"$SKILLS_DIR"/*/SKILL.md "$SKILLS_DIR"/*/references/*.md 2>/dev/null'
    t = sub(t, 'HITS=$(grep -rlE "^RULE [0-9]+:|^RULE [0-9]+ " ' + glob + ' \\\n',
            'HITS=$(scan_files | xargs -r grep -lE "^RULE [0-9]+:|^RULE [0-9]+ " 2>/dev/null \\\n', 1, "c1")
    t = sub(t, 'HITS=$(grep -rliE "^#+.*iron rules" ' + glob + ' \\\n',
            'HITS=$(scan_files | xargs -r grep -liE "^#+.*iron rules" 2>/dev/null \\\n', 1, "c2")
    t = sub(t, 'HITS=$(grep -rlE "^\\| ?R1 ?\\|" ' + glob + ' \\\n',
            'HITS=$(scan_files | xargs -r grep -lE "^\\| ?R1 ?\\|" 2>/dev/null \\\n', 1, "c5")
    # check 3: narrative-aware, and skip dated drift-check history files like reconciliation-history.md
    old3 = '''HITS=$(grep -rnoiE "[0-9]+-item[a-z ]*gate|gate[a-z ]*\\([0-9]+ item" ''' + glob + ''' \\
       | grep -v "reconciliation-history.md" \\
       | grep -Eiv "($KNOWN_QUALITY_GATE_COUNTS)-item|\\(($KNOWN_QUALITY_GATE_COUNTS) item" || true)'''
    new3 = '''RAW=$(scan_files | grep -Ev "reconciliation-history.md|/drift-check-[0-9-]+\\.md$" \\
       | xargs -r grep -noiE "[0-9]+-item[a-z ]*gate|gate[a-z ]*\\([0-9]+ item" 2>/dev/null \\
       | grep -Eiv "($KNOWN_QUALITY_GATE_COUNTS)-item|\\(($KNOWN_QUALITY_GATE_COUNTS) item" || true)
HITS=""
while IFS= read -r hit; do
  [ -z "$hit" ] && continue
  # parse "<path>:<line>:<match>" from the RIGHT: plugin folders may contain ':' (e.g. akos-...:akos-...)
  if [[ "$hit" =~ ^(.*):([0-9]+):[^:]*$ ]]; then f="${BASH_REMATCH[1]}"; l="${BASH_REMATCH[2]}"; else f=""; l=""; fi
  if [ -n "$f" ] && is_narrative "$f" "$l"; then continue; fi
  HITS="${HITS}${hit}"$'\\n'
done <<< "$RAW"
HITS="${HITS%$'\\n'}"'''
    t = sub(t, old3, new3, 1, "c3")
    t = sub(t, 'CH_FILE="$SKILLS_DIR/charlie-hills-code/SKILL.md"\nif [ -f "$CH_FILE" ]; then',
            'CH_FILE="$(find_skill charlie-hills-code)"\nif [ -n "$CH_FILE" ] && [ -f "$CH_FILE" ]; then', 1, "c4a")
    t = sub(t, '  echo "    charlie-hills-code/SKILL.md not found at $CH_FILE"',
            '  echo "    charlie-hills-code/SKILL.md not found under: ${ROOTS[*]}"', 1, "c4b")
    t = sub(t, 'IRG_FILE="$SKILLS_DIR/iron-rules-governance/SKILL.md"\nif [ -f "$IRG_FILE" ]; then',
            'IRG_FILE="$(find_skill iron-rules-governance)"\nif [ -n "$IRG_FILE" ] && [ -f "$IRG_FILE" ]; then', 1, "c6a")
    t = sub(t, "  echo \"  SKIPPED — $IRG_FILE not found under $SKILLS_DIR (can't self-check a file that isn't there)\"",
            "  echo \"  SKIPPED — iron-rules-governance/SKILL.md not found under ${ROOTS[*]} (can't self-check a file that isn't there)\"", 1, "c6b")
    t = sub(t, "# Usage:   ./check-governance-drift.sh [path-to-skills-dir]\n# Default: /mnt/skills/user\n",
            "# Usage:   ./check-governance-drift.sh [skills-dir ...]\n# Default: every existing root among /mnt/skills/user /mnt/skills/plugins ~/.claude/skills\n", 1, "usage")
    dst = out / "iron-rules-governance" / "scripts"
    dst.mkdir(parents=True, exist_ok=True)
    (dst / "check-governance-drift.sh").write_text(t, encoding="utf-8")
    (dst / "check-governance-drift.sh").chmod(0o755)
    return dst


# ---------------------------------------------------------------------------------------------------
# v1.2 additions (plain code, anchors verified like every other edit)
# ---------------------------------------------------------------------------------------------------
def fix_evidence_citation(akos_dir: Path):
    """AKOS's evidence file cites a canonical file that does not exist; point it at where the table really lives."""
    p = akos_dir / "references" / "evidence-and-hallucination-controls.md"
    t = p.read_text(encoding="utf-8")
    t = sub(t, "`super-grc-audit-plugin-l99/references/iron-rules-canonical.md`",
            "`iron-rules-governance/SKILL.md` (section \"Evidence Hierarchy (R1–R5)\")", 1, "evidence citation")
    p.write_text(t, encoding="utf-8")


def upgrade_drift_v12(script: Path):
    """v1.2: skip skills carrying the LEGACY banner (and name them), allowlist AKOS's merged R1-R5 mirror for check 5."""
    t = script.read_text(encoding="utf-8")
    old_scan = 'scan_files() { for r in "${ROOTS[@]}"; do ls "$r"/*/SKILL.md "$r"/*/references/*.md 2>/dev/null; done; }'
    new_scan = (
        'is_legacy() { head -25 "$1/SKILL.md" 2>/dev/null | grep -q "LEGACY, superseded"; }\n'
        '# v1.2: skills whose description carries the LEGACY banner are skipped for drift purposes AND named in the banner line\n'
        'scan_files() { for r in "${ROOTS[@]}"; do for d in "$r"/*/; do d="${d%/}"; [ -f "$d/SKILL.md" ] || continue\n'
        '  is_legacy "$d" && continue; ls "$d"/SKILL.md "$d"/references/*.md 2>/dev/null; done; done; }\n'
        'legacy_names() { for r in "${ROOTS[@]}"; do for d in "$r"/*/; do d="${d%/}"; [ -f "$d/SKILL.md" ] && is_legacy "$d" && basename "$d"; done; done | sort -u | tr \'\\n\' \' \'; }')
    t = sub(t, old_scan, new_scan, 1, "scan_files v1.2")
    t = sub(t, 'echo "Scanning: ${ROOTS[*]}"',
            'echo "Scanning: ${ROOTS[*]}"\nLEG="$(legacy_names)"; [ -n "$LEG" ] && echo "Skipped legacy-marked skills: $LEG"', 1, "legacy line")
    t = sub(t, 'NAMESPACED_HOLDERS="racm-ecosystem|cae-report-conversion"\n',
            'NAMESPACED_HOLDERS="racm-ecosystem|cae-report-conversion"\n'
            '# v1.2: AKOS carries a deliberate mirror of the canonical R1-R5 table (merged 27 Jul 2026); allowlisted for check 5 only\n'
            'EVIDENCE_TABLE_MIRRORS="akos-enterprise-orchestrator"\n', 1, "mirror allowlist")
    old5 = 'HITS=$(scan_files | xargs -r grep -lE "^\\| ?R1 ?\\|" 2>/dev/null \\\n       | grep -Ev "$CANONICAL_RULE_HOLDERS" || true)'
    new5 = 'HITS=$(scan_files | xargs -r grep -lE "^\\| ?R1 ?\\|" 2>/dev/null \\\n       | grep -Ev "$CANONICAL_RULE_HOLDERS|$EVIDENCE_TABLE_MIRRORS" || true)'
    t = sub(t, old5, new5, 1, "check5 mirrors")
    t = sub(t, "# v1.1 (3 Oct 2026): scan EVERY root",
            "# v1.2 (3 Oct 2026): legacy-skill skipping; evidence-table mirror allowlist (check 5).\n# v1.1 (3 Oct 2026): scan EVERY root", 1, "header")
    script.write_text(t, encoding="utf-8")


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--catalog", default="/mnt/skills")
    ap.add_argument("--out", default=str(Path(__file__).resolve().parent / "payload"))
    a = ap.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    cat = Path(a.catalog)
    print("AKOS v2.3 ->", build_akos(cat, out))
    fix_evidence_citation(out / "akos-enterprise-orchestrator")
    print("drift script v1.2 ->", build_drift(cat, out))
    upgrade_drift_v12(out / "iron-rules-governance" / "scripts" / "check-governance-drift.sh")


if __name__ == "__main__":
    main()
