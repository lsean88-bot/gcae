# GIA ecosystem patch, 3 Oct 2026

Resolves the evidence-clear findings from the akos-graphify-bridge interop review and lists, with evidence, the ones that
are yours to decide (`DECISIONS_PENDING.md`).

## Apply (always dry-run first)
```bash
python3 apply_patch.py --catalog /path/to/skills-root            # dry run: shows what WOULD change
python3 apply_patch.py --catalog /path/to/skills-root --apply    # backs up first, then applies
```
`--catalog` is the folder that contains `user/` and `plugins/` (in this environment `/mnt/skills`). Backups go to
`~/gia-patch-backup-<timestamp>` (override with `--backup-dir`). A second `--apply` changes nothing.

| Op | Change | Guard |
|---|---|---|
| A | Replace both installed AKOS copies with the single v2.3 (v2.2 + registry gaps + D1 routing + evals) | backup first |
| B1 | Retire `plugins/pune-india-ops-audit` v1.0 | only if the newer `mktron-pune-vda-compliance` copy is provably newer |
| B2 | Retire `plugins/file-reading` | only if `public/file-reading` exists and differs |
| C | `check-governance-drift.sh` v1.1 (scans every root; ignores correction narrative; handles `:` in folder names) | backup first |
| D | Install `akos-graphify-bridge` 1.2.0 into `user/` | |
| E1 | `racm-ecosystem`: apply the approved `RACM-01..12` namespace | verified line by line against `racm-rc-namespaces.md`; a clear paraphrase is renamed and reported, a material difference is skipped |
| E2 | `cae-report-conversion`: apply `RC-01..12` | same guard |
| E3 | `cae-cowork-ai-plugin`: gate 10 -> true 12 (adds the 2 missing checks) | exact-anchor; skipped if the table was edited |
| E4 | `master-audit-superagent`: MAS namespace for its local rule list | exact-anchor |
| E5 | LEGACY banner on `cae-audit-cowork-plugin`, `-v4`, `-v5` descriptions (nothing deleted) | only if `cae-cowork-ai-plugin` is installed; skipped if it would exceed 1,024 characters |

## Roll back
Copy the backed-up folders from the backup dir back to the same relative paths (they are byte-identical to the originals; tested).

## Rebuild the payload from a changed catalog
`python3 build_payload.py --catalog /mnt/skills`. Every edit asserts its anchor text; if a source file changed, the build **fails
loudly** instead of mis-patching a governance document.

## Verify
`pytest tests/` (31), then `python3 payload/akos-graphify-bridge/scripts/interop_check.py` and
`bash payload/iron-rules-governance/scripts/check-governance-drift.sh`.

## Not changed on purpose
D2, D3, D4, D6, D8, D10, D15 in `DECISIONS_PENDING.md`. Nothing in `iron-rules-governance/SKILL.md`; no portfolio-wide rule.

**Scope change from v1.0 of this patch:** v1.0 touched only AKOS and the drift script. This version also edits the live skills `racm-ecosystem`, `cae-report-conversion`, `cae-cowork-ai-plugin`, `master-audit-superagent` and the descriptions of three legacy skills, as you asked me to resolve the issues. Each edit is anchored, backed up and reversible; always dry-run first.
