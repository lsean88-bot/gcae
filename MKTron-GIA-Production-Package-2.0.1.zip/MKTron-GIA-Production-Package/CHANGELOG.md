# Changelog

## 2.0.1 (bridge 2.0.1, plugin 2.0.1)
- **Fixed:** without graphify installed, `to-graphify`, `index` and `remember` crashed with exit 3 ("internal error"). They now exit 2 with one clear line saying what to install; `index` says it once instead of failing every shelf. Everything that does not need graphify (validate, recall, seal, changes, verify, stale, status, guard, dashboard, deliverable, export-xlsx, merge, doctor) was proven to work without it (4 new tests).
- **Added:** `install.py` installer (dry run by default, backup, idempotent, self-checks, uninstall), a lean claude.ai upload ZIP, and `INSTALL.md` (separate Install Bundle).
- **Fixed (patch tool):** on a catalog with no `user/` folder, `apply` creates one to install the skill into, and `--rollback` left the empty folder behind, so the catalog was not byte-identical. Apply now journals folders it creates and rollback removes them (only if still empty). Found by making the real-catalog rollback test layout-agnostic. The two real-catalog tests now adapt to any catalog layout, and the exact-operation-count test skips honestly when the layout differs.
- Skill tests 344, patch tests 49 (+2 honest skips), plugin 38; golden master unchanged (43 scenarios, 0 regressions).


## 2.0.0, production release (bridge 2.0.0, plugin 2.0.0, patch 2.0, drift script 1.2, AKOS 2.3)

Hardening release. All v1.2.0 capabilities are preserved: the golden master (43 scenarios) shows no removal or change, and every v1.2.0
subcommand and flag is still present. See `docs/UAT-report-v4.md` for the 24 defects fixed, 7 intentional behaviour changes, measured
performance and stated limits.

### Added
- Concurrency safety (locks), crash safety (staged swaps, write-ahead journal, resumable rollback), strict input handling, output sanitisation.
- Tamper-evident audit trail (`audit.log`), `seal`, `changes`, `verify --anchor`; `doctor`; opt-in `recall --ranking idf`.
- `apply_patch --rollback`; refuses a backup inside the catalog; one apply at a time; per-operation failure isolation.
- `tools/release_gate.py`, `MANIFEST.sha256`, `compat/` (golden master and capability surface), `uat/` (9 stress scenarios).
- Plugin commands `/akos-brain-verify` and `/akos-brain-doctor`.

### Changed (intentional)
See section 3 of the UAT report: `index` exit code on shelf failure; confidential lessons stay in the shelf; duplicate JSON keys / NaN rejected;
local date; bounded arguments; malformed input exits 2.

### Fixed
24 defects (I-01..I-24), each reproduced before it was fixed and pinned by a test.


## 2026-10-04: Enhanced package (bridge 1.2.0, plugin 1.2.0, patch 2.0, drift script 1.2, AKOS 2.3)

### Fixed (found by testing; each has a regression test)
- Recall mangled accented words ("Nómina" matched "mina") and could never find Tamil or Chinese text. New `textnorm.py`.
- Unreadable dates (`April 2026`, `2026-4-1`) were treated as **fresh**. Now `BAD_DATE`, fail-closed; only `YYYY-MM-DD` accepted.
- Every file was written `0600`, unreadable by teammates; confidential shelves were not deliberately locked. Shared = 0644, confidential = 0700/0600; `guard` warns on drift.
- Non-ASCII ids collapsed in slugging (`ஊதிய-01` -> `01`). Hash-suffixed.
- A corrupt shelf file crashed the whole index/guard/status. Now skipped and reported; guard fails closed.
- `dashboard` on a non-library crashed (exit 1) because running `brain.py` as a script created two copies of the module. Aliased.
- `register_entity` never updated the "nine entities" wording (off-by-one).
- Status classifier fused a markdown table into one "sentence" (one "legacy" row mislabelled other skills). Per-row/bullet/heading units.
- Drift script: single-root blind spot, crash on `:` in folder names, false positives on narrative and a deliberate mirror (v1.1, v1.2).
- My own skill and a protocol heading tripped drift Check 2.
- Earlier overstatement corrected: `mac-audit-constitution-l99` is **unconfirmed**, not "retired".

### Added
- Evidence ranks R1-R5 end to end: shown in recall, `--max-rank`, R4 -> PROVISIONAL, R5 -> INDICATOR, `CONF_VS_RANK`, `RANK_INVALID`, `deliverable --max-rank`.
- Editable `synonyms.json` (payroll / nómina / gaji, EPF / provident fund, ...); expansions reported; direct matches outrank synonyms.
- Dual-format output: `brain.py dashboard` (HTML + XLSX) and `akos_graph.py export-xlsx`; HTML-escaped and Excel-formula-neutralised; confidential shelves counts only.
- `/akos-brain-dashboard`; plugin-command executability tests.
- Patch ops E1-E5: namespaces applied inside racm-ecosystem and cae-report-conversion; v6 gate made a true 12; master-audit-superagent namespace; LEGACY banners. AKOS citation fix. Drift script v1.2.
- Mutation-checked tests.

### Verified
193 tests in this package (130 + 32 + 31), graphify upstream 4,930 passed, full patch applied to a copy of the real catalog: drift 5/6 -> 1/6 flagged, interop warnings 7 -> 3, idempotent, byte-exact rollback.

## 2026-10-03: first release (bridge 1.0/1.1, library brain, interop check, patch 1.0)
