---
description: Ask the knowledge graph a question, trace a path between two items, or explain one item, using AKOS ids
argument-hint: "<question> | path <A> <B> | explain <ID> | god-nodes"
---

Read the `akos-graphify-bridge` skill first.

1. Find `graphify-bridge-out/graphify-out/graph.json` (or the path the user gave). If absent, run `/akos-graph-build` first.
2. Use the graphify CLI: `graphify query "<q>" --graph <G>`, `graphify path <A> <B> --graph <G>`, `graphify explain <node> --graph <G>`, `graphify god-nodes --graph <G>`. AKOS ids such as `CTRL-CLD-01` work as node names.
3. Answer strictly from the tool output. Quote ids, relationships, and `source` locations. If there is no path or match, say so; do not infer one.
4. Frame results as relationships worth testing. Never present a graph link as a finding or as 100% evidence. Flag any edge whose `akos_confidence` is Medium/Low or `indicator_only`.
