---
description: Test whether installed audit skills and plugins interlock - duplicates, drift, dead references, registry gaps
argument-hint: "[--roots ...] [--registry path]"
---

Read the `akos-graphify-bridge` skill first.

1. Run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/interop_check.py` (add `--json` if you need to post-process).
2. Report in this order: ERRORs; DUPLICATE_DRIFT (state which copy is newer); REF_UNRESOLVED; UNREGISTERED audit skills; INFO.
3. For each finding give a recommended action, but do not edit any other skill or the AKOS registry without the user's approval. Point to `references/registry-entry-proposal.md` for ready-made registry text.
4. Offer a `LESSONS_LEARNED.md` entry for any recurring finding; write it only after the user confirms.
