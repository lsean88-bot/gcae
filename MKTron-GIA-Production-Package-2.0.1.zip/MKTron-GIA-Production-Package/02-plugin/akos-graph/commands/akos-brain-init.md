---
description: Create the library brain (or add a shelf to it) with the right confidentiality settings
argument-hint: "<library dir> [shelf-name --kind engagement|statutory|policy|investigation|reference --entity CODE]"
---

Read the `akos-graphify-bridge` skill and `references/library-brain.md` first.

1. If the library does not exist: `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/brain.py init <lib>`.
2. To add a shelf: `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/brain.py shelf-add <lib> <name> --kind <kind> --entity <CODE>` (add `--review-days N` for statutory shelves).
   The entity must already be registered. If it is not, stop: do not invent a code. Tell the user the code and name must come from them, then offer `register_entity.py` (dry run first).
3. Investigations are always confidential. Say so, and say that they will be kept out of the global index.
4. Run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/brain.py guard <lib>` and report the result in one line.
