---
description: Run the AKOS Module 9 quality gate on the knowledge graph and export the Board-safe subset
argument-hint: "[path/to/KNOWLEDGE_GRAPH.json] [--gate draft|final, default final]"
---

Read the `akos-graphify-bridge` skill first.

1. Run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/akos_graph.py validate <kg> --gate final --json` (use `draft` only if the user asks).
2. Summarise by code with node/edge refs, ERRORs first. Give an explicit verdict: Ready / Ready with exceptions / Not ready. No generic "looks fine".
3. Run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/akos_graph.py deliverable <kg> --out <subset.json>` and state how many nodes/edges are excluded and why (PROPOSED, ALLEGED, below High, indicator-only).
4. Never edit the KG to make the gate pass. List fixes for the user to approve.
