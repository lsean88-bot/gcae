---
description: Check the environment (and optionally a library) is able to run the library brain safely
argument-hint: "[library dir]"
---

Read the `akos-graphify-bridge` skill first.

1. Run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/brain.py doctor [<lib>]`.
2. Report FAIL items first with their remedy, then WARN items. Exit code 1 means a required capability is missing.
3. Call out in particular: the extraction backend graphify would auto-select (a cloud backend is a confidentiality risk), symbolic links inside the library (refused), an interrupted index swap, and GIA_* debug variables left set.
