---
description: Check the library brain's safety (confidentiality, backend, memory-as-evidence) and freshness before sharing or scheduling
argument-hint: "<library dir>"
---

Read the `akos-graphify-bridge` skill first.

1. Run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/brain.py guard <lib>`, `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/brain.py stale <lib>` and `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/brain.py status <lib>`.
2. Report ERRORs first, then WARNs, then stale or undated statutory items, then a one-table status of shelves.
3. For `EXTRACT_BACKEND_NOT_ALLOWED`, explain that graphify would auto-pick a cloud backend (order: gemini, kimi, claude, openai, deepseek) and recommend an explicit `--backend` or unsetting the key.
4. Never fix a finding by editing a shelf's graph. List fixes for the user to approve.
