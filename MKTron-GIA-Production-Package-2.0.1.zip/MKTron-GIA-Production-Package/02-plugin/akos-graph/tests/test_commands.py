"""Plugin commands are instructions Claude will follow literally: every script, subcommand and --flag they name must exist."""
import re, subprocess, sys
from pathlib import Path
import pytest

PLUGIN = Path(__file__).resolve().parent.parent
SKILL = PLUGIN / "skills" / "akos-graphify-bridge"
COMMANDS = sorted((PLUGIN / "commands").glob("*.md"))
CALL = re.compile(r"`python3 \$\{CLAUDE_PLUGIN_ROOT\}/skills/akos-graphify-bridge/scripts/(\w+\.py)([^`]*)`")


def frontmatter(text):
    m = re.match(r"^---\n(.*?)\n---\n", text, re.S)
    assert m, "no frontmatter"
    return dict(l.split(": ", 1) for l in m.group(1).splitlines() if ": " in l)


def test_there_are_commands():
    assert len(COMMANDS) >= 12


@pytest.mark.parametrize("cmd", COMMANDS, ids=lambda p: p.stem)
def test_frontmatter_and_skill_reference(cmd):
    t = cmd.read_text()
    fm = frontmatter(t)
    assert fm.get("description") and fm.get("argument-hint")
    assert "akos-graphify-bridge" in t and t.count("`") % 2 == 0


@pytest.mark.parametrize("cmd", COMMANDS, ids=lambda p: p.stem)
def test_every_scripted_call_resolves(cmd):
    calls = CALL.findall(cmd.read_text())
    for script, rest in calls:
        f = SKILL / "scripts" / script
        assert f.exists(), f"{cmd.name}: {script} does not exist"
        tokens = rest.split()
        sub = next((t for t in tokens if re.fullmatch(r"[a-z][a-z-]+", t)), None)
        help_ = subprocess.run([sys.executable, str(f), *( [sub] if sub else []), "--help"], capture_output=True, text=True)
        assert help_.returncode == 0, f"{cmd.name}: `{script} {sub}` is not a valid subcommand\n{help_.stderr[-200:]}"
        for flag in re.findall(r"(--[a-z][a-z-]*)", rest):
            assert flag in help_.stdout, f"{cmd.name}: {script} {sub} has no {flag}"


@pytest.mark.parametrize("cmd", COMMANDS, ids=lambda p: p.stem)
def test_referenced_files_and_commands_exist(cmd):
    t = cmd.read_text()
    for ref in re.findall(r"`(references/[\w./-]+\.md)`", t):
        assert (SKILL / ref).exists(), f"{cmd.name}: missing {ref}"
    for other in re.findall(r"`/(akos-[a-z-]+)`", t):
        if other not in ("akos-init", "akos-status"):               # those two belong to the AKOS plugin
            assert (PLUGIN / "commands" / f"{other}.md").exists(), f"{cmd.name}: no command /{other}"


def test_every_script_subcommand_is_reachable_from_some_command():
    used = set()
    for c in COMMANDS:
        for script, rest in CALL.findall(c.read_text()):
            sub = next((t for t in rest.split() if re.fullmatch(r"[a-z][a-z-]+", t)), None)
            used.add((script, sub))
    must = {("akos_graph.py", s) for s in ("to-graphify", "from-graphify", "validate", "deliverable", "export-xlsx")} | \
           {("brain.py", s) for s in ("init", "shelf-add", "recall", "remember", "reflect", "guard", "stale", "status", "dashboard", "seal", "changes", "verify", "doctor")} | \
           {("interop_check.py", None)}
    assert must <= used, f"not reachable from any slash command: {sorted(must - used, key=str)}"
