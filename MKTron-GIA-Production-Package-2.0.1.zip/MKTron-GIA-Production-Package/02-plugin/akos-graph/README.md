# akos-graph plugin 2.0.0

Connects the AKOS Knowledge Graph to graphify and adds a confidentiality-aware **library brain**.

| Command | Does |
|---|---|
| `/akos-graph-build` | Validate a `KNOWLEDGE_GRAPH.json`, then build a queryable graphify graph and HTML view |
| `/akos-graph-query` | Ask a question, trace a path, explain an item (AKOS ids work) |
| `/akos-graph-ingest` | Stage a graphify extraction as PROPOSED items; unclassified and conflicts listed |
| `/akos-graph-validate` | Module 9 gate (`--gate final`) and the Board-safe deliverable subset |
| `/akos-interop-check` | Do the installed audit skills interlock? duplicates, drift, supersession, registry gaps |
| `/akos-brain-init` | Create the library or add a shelf (investigations are always confidential) |
| `/akos-brain-recall` | Ranked recall with trust labels, evidence ranks, staleness flags |
| `/akos-brain-remember` | Record helpful / dead-end / corrected (an indicator, never evidence) |
| `/akos-brain-guard` | Confidentiality, backend, memory-as-evidence, freshness, file modes |
| `/akos-brain-dashboard` | HTML dashboard plus Excel workbook |
| `/akos-brain-verify` | Seal a shelf, see what changed since, verify the tamper-evident audit trail |
| `/akos-brain-doctor` | Check the environment and library can run safely |

The skill is in `skills/akos-graphify-bridge/`. Tests: `pytest tests/` (command executability) and
`pytest skills/akos-graphify-bridge/tests/`. Requires Python 3.10+, graphify, and `openpyxl` for the Excel outputs.
