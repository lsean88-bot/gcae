"""L2 service layer gate: concurrency, corruption recovery, isolation, crash safety, security, audit/tamper,
confidentiality, local time, performance. Each class of test maps to a numbered defect in PRODUCTION_PLAN.md."""
import json, multiprocessing as mp, os, subprocess, sys, time
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parent.parent
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))
import akos_graph as ag, audit, brain, doctor, fsutil  # noqa: E402
from errors import GiaError, RefusedError  # noqa: E402

FIX = json.loads((Path(__file__).parent / "fixtures/cld_kg.json").read_text())
ENV = ["GEMINI_API_KEY", "GOOGLE_API_KEY", "MOONSHOT_API_KEY", "ANTHROPIC_API_KEY", "OPENAI_API_KEY", "DEEPSEEK_API_KEY",
       "AZURE_OPENAI_API_KEY", "AZURE_OPENAI_ENDPOINT", "AWS_PROFILE", "AWS_REGION", "AWS_DEFAULT_REGION", "OLLAMA_BASE_URL",
       "OLLAMA_HOST", "GRAPHIFY_QUERY_LOG", "GRAPHIFY_QUERY_LOG_ENABLE", "GIA_TODAY", "GIA_DEBUG"]


@pytest.fixture(autouse=True)
def clean_env(monkeypatch):
    for k in ENV:
        monkeypatch.delenv(k, raising=False)
    monkeypatch.setenv("GIA_NO_FSYNC", "1")


def node(i, typ, label, conf="High", ent="Group", **kw):
    return {"id": i, "type": typ, "label": label, "entity": ent, "created_date": "2026-10-01", "confidence": conf,
            "source_location": "https://x", **kw}


def edge(a, b, rel="relates_to", conf="High"):
    return {"from": a, "to": b, "relationship": rel, "evidence": "ev", "confidence": conf}


def put(lib, shelf, nodes, edges=(), confidential=False):
    ag.atomic_write_json(Path(lib) / "shelves" / shelf / "KNOWLEDGE_GRAPH.json",
                         {"engagement": shelf, "confidential": confidential, "last_updated": "2026-10-01",
                          "nodes": nodes, "edges": list(edges)}, 0o600 if confidential else 0o644)


@pytest.fixture
def lib(tmp_path):
    L = tmp_path / "lib"
    brain.init_library(L)
    brain.add_shelf(L, "e1", "engagement", "MKAPL-DC")
    ag.atomic_write_json(L / "shelves/e1/KNOWLEDGE_GRAPH.json", FIX)
    return L


def cli(*a, env=None):
    return subprocess.run([sys.executable, str(SCRIPTS / "brain.py"), *map(str, a)], capture_output=True, text=True,
                          env={**os.environ, "GIA_NO_FSYNC": "1", **(env or {})})


# =========================================================================== I-01 concurrency
def _remember_worker(args):
    lib, shelf, i = args
    brain.remember(Path(lib), shelf, f"question number {i}?", f"answer {i}", "useful" if i % 2 else "dead_end")
    return i


def test_concurrent_remember_loses_nothing(lib):
    N = 24
    with mp.Pool(8) as p:
        p.map(_remember_worker, [(str(lib), "e1", i) for i in range(N)])
    idx = json.loads((lib / "shelves/e1/memory_index.json").read_text())
    files = list((lib / "shelves/e1/graphify-out/memory").glob("query_*.md"))
    assert len(idx) == N and len(files) == N and len({e["question"] for e in idx}) == N
    assert audit.verify(lib) == [] and len([e for e in audit.read(lib)[0] if e["cmd"] == "remember"]) == N
    assert brain.guard(lib) == []


def _shelf_worker(args):
    lib, i = args
    brain.add_shelf(Path(lib), f"s{i}", "reference", "Group")
    return i


def test_concurrent_shelf_add_keeps_every_shelf(tmp_path):
    L = tmp_path / "lib"; brain.init_library(L)
    with mp.Pool(8) as p:
        p.map(_shelf_worker, [(str(L), i) for i in range(16)])
    assert sorted(brain.load_manifest(L)["shelves"]) == sorted(f"s{i}" for i in range(16))
    assert audit.verify(L) == []


def _same_question_worker(args):
    lib, i = args
    brain.remember(Path(lib), "e1", "exactly the same question?", f"answer {i}", "useful")


def test_same_question_in_the_same_second_never_overwrites(lib):
    with mp.Pool(4) as p:
        p.map(_same_question_worker, [(str(lib), i) for i in range(6)])
    idx = json.loads((lib / "shelves/e1/memory_index.json").read_text())
    files = list((lib / "shelves/e1/graphify-out/memory").glob("query_*.md"))
    assert len(idx) == 6 and len(files) == 6
    assert sorted(f.read_text().count("## Answer") for f in files) == [1] * 6
    bodies = " ".join(f.read_text() for f in files)
    assert all(f"answer {i}" in bodies for i in range(6))


def _index_worker(lib):
    try:
        brain.index_library(Path(lib)); return "ok"
    except Exception as e:
        return type(e).__name__


def _recall_worker(lib):
    for _ in range(5):
        brain.recall(Path(lib), "written service agreement")
    return "ok"


def test_writers_indexers_and_readers_together(lib):
    brain.index_library(lib)
    with mp.Pool(6) as p:
        jobs = [p.apply_async(_remember_worker, ((str(lib), "e1", i),)) for i in range(8)]
        jobs += [p.apply_async(_index_worker, (str(lib),)) for _ in range(2)]
        jobs += [p.apply_async(_recall_worker, (str(lib),)) for _ in range(2)]
        res = [j.get(timeout=240) for j in jobs]
    assert all(r in (0, 1, 2, 3, 4, 5, 6, 7, "ok") for r in res), res
    assert len(json.loads((lib / "shelves/e1/memory_index.json").read_text())) == 8
    json.loads((lib / "index/index_report.json").read_text())
    json.loads((lib / "index/global/global_kg.json").read_text())
    assert audit.verify(lib) == []


def _audit_worker(args):
    lib, i = args
    for j in range(8):
        audit.append(Path(lib), "test", None, {"w": i, "j": j})


def test_concurrent_audit_appends_keep_a_valid_contiguous_chain(tmp_path):
    L = tmp_path / "lib"; L.mkdir()
    with mp.Pool(8) as p:
        p.map(_audit_worker, [(str(L), i) for i in range(8)])
    entries, problems = audit.read(L)
    assert [e["seq"] for e in entries] == list(range(1, 65)) and audit.verify(L) == [] and not problems["torn_tail"]


# =========================================================================== I-02 corruption and recovery
@pytest.mark.parametrize("corrupt", [b'[{"file": "x"', b"", b"\x00\x00", b"{}", b'{"a":1,"a":2}', b"\xef\xbb\xbf[nonsense", b'["not an object"]'])
def test_corrupt_memory_index_is_quarantined_and_rebuilt(lib, corrupt):
    brain.remember(lib, "e1", "first question?", "first answer", "corrected", correction="the right answer", nodes=["CTRL-CLD-01"])
    brain.remember(lib, "e1", "second question?", "second answer", "dead_end")
    (lib / "shelves/e1/memory_index.json").write_bytes(corrupt)
    brain.remember(lib, "e1", "third question?", "third answer", "useful")             # must not crash
    idx = json.loads((lib / "shelves/e1/memory_index.json").read_text())
    assert len(idx) == 3 and [e["question"] for e in idx][:2] == ["first question?", "second question?"]
    first = next(e for e in idx if e["question"] == "first question?")
    assert first["outcome"] == "corrected" and first["correction"] == "the right answer" and first["nodes"] == ["[CTRL-CLD-01] Written Service Agreement Requirement"]
    assert list((lib / "shelves/e1").glob("memory_index.json.corrupt-*"))              # kept for forensics
    assert any(e["cmd"] == "memory-index-recovered" for e in audit.read(lib)[0]) and audit.verify(lib) == []


def test_guard_reports_index_and_disk_disagreement(lib):
    brain.remember(lib, "e1", "q one?", "a", "useful")
    idx = json.loads((lib / "shelves/e1/memory_index.json").read_text())
    next((lib / "shelves/e1/graphify-out/memory").glob("*.md")).unlink()
    (lib / "shelves/e1/graphify-out/memory/query_20200101_000000_stray.md").write_text("---\n---\n")
    msgs = [f["message"] for f in brain.guard(lib) if f["code"] == "MEMORY_INDEX_MISMATCH"]
    assert any("missing from disk" in m for m in msgs) and any("not in the index" in m for m in msgs)


@pytest.mark.parametrize("kwargs,frag", [({"question": "q" * 3000}, "too large"), ({"answer": "a" * 300000}, "too large"),
                                          ({"correction": "c" * 30000}, "too large"), ({"answer": "bad\x00answer"}, "NUL"),
                                          ({"nodes": [f"n{i}" for i in range(300)]}, "too large")])
def test_remember_size_and_nul_limits(lib, kwargs, frag):
    args = {"question": "q?", "answer": "a", "outcome": "corrected", "correction": "c"}
    args.update(kwargs)
    with pytest.raises(brain.BrainError, match=frag):
        brain.remember(lib, "e1", args["question"], args["answer"], args["outcome"], args.get("correction"), args.get("nodes"))
    assert not (lib / "shelves/e1/graphify-out/memory").exists() or not list((lib / "shelves/e1/graphify-out/memory").glob("*.md"))


def test_unicode_questions_roundtrip_and_are_indexed(lib):
    brain.remember(lib, "e1", "நிறுவன ஊதிய விதி என்ன? Nómina 薪资", "பதில்", "useful")
    idx = json.loads((lib / "shelves/e1/memory_index.json").read_text(encoding="utf-8"))
    assert idx[0]["question"].startswith("நிறுவன") and brain._memory_index_problems(lib, "e1") == []


# =========================================================================== I-03 isolation and crash safety
def _poison(lib, name, how):
    brain.add_shelf(lib, name, "engagement", "MKAPL-DC")
    f = lib / "shelves" / name / "KNOWLEDGE_GRAPH.json"
    if how == "collision":
        bad = json.loads(json.dumps(FIX)); bad["nodes"].append({**bad["nodes"][0], "id": "doc.mkapl.0142"}); ag.atomic_write_json(f, bad)
    elif how == "broken-json":
        f.write_text('{"nodes": [ BROKEN')
    elif how == "bad-shape":
        f.write_text(json.dumps({"nodes": "nope", "edges": 5}))
    elif how == "dup-keys":
        f.write_text('{"nodes": [], "nodes": [], "edges": []}')
    elif how == "node-garbage":
        f.write_text(json.dumps({"nodes": [None, 5, "x"], "edges": []}))


@pytest.mark.parametrize("how", ["collision", "broken-json", "bad-shape", "dup-keys", "node-garbage"])
def test_a_poisoned_shelf_never_blocks_the_others(lib, how):
    _poison(lib, "bad", how)
    rep = brain.index_library(lib)
    assert rep["shelves"]["e1"]["status"] == "INDEXED" and rep["shelves"]["bad"]["status"] == "ERROR"
    assert rep["failed_shelves"] == ["bad"] and (lib / "shelves/e1/graphify-out/graph.json").exists()
    g = json.loads((lib / "index/global/global_kg.json").read_text())
    assert any(n["shelf"] == "e1" for n in g["nodes"]) and not any(n["shelf"] == "bad" for n in g["nodes"])
    assert cli("index", lib).returncode == 1                                              # findings: needs action
    assert cli("recall", lib, "written service agreement").returncode in (0, 2)


def test_index_with_no_failures_exits_zero(lib):
    assert cli("index", lib).returncode == 0


def test_failed_swap_keeps_the_previous_global_graph(lib, monkeypatch):
    brain.index_library(lib)
    before = (lib / "index/global/global_kg.json").read_bytes()
    brain.remember(lib, "e1", "q?", "a", "useful")
    put(lib, "e1", FIX["nodes"] + [node("NEW-1", "Risk", "brand new risk")], FIX["edges"] + [edge("NEW-1", "CTRL-CLD-01")])
    monkeypatch.setattr(fsutil, "replace_dir", lambda *a: (_ for _ in ()).throw(OSError("injected swap failure")))
    rep = brain.index_library(lib)
    assert "(global)" in rep["failed_shelves"] and (lib / "index/global/global_kg.json").read_bytes() == before
    assert not [p for p in (lib / "index").iterdir() if p.name.startswith(".staging")]
    json.loads((lib / "index/index_report.json").read_text())


def test_index_restores_a_swap_that_was_killed_midway(lib):
    brain.index_library(lib)
    os.rename(lib / "index/global", lib / "index/global.old-99999")                        # state after kill -9 between renames
    assert not (lib / "index/global").exists()
    assert any(f["code"] == "PENDING_SWAP" for f in brain.guard(lib))
    assert any(c["name"] == "interrupted index swap" and c["status"] == "WARN" for c in doctor.run_checks(lib))
    brain.index_library(lib)
    assert (lib / "index/global/global_kg.json").exists() and not list((lib / "index").glob("*.old-*"))
    assert not any(f["code"] == "PENDING_SWAP" for f in brain.guard(lib))


# =========================================================================== I-07 security
def test_symlinked_shelf_is_refused_everywhere(lib, tmp_path):
    outside = tmp_path / "outside"; outside.mkdir()
    for f in ("shelf.json", "KNOWLEDGE_GRAPH.json"):
        (outside / f).write_text((lib / "shelves/e1" / f).read_text())
    os.symlink(outside, lib / "shelves/evil")
    mf = brain.load_manifest(lib); mf["shelves"].append("evil"); ag.atomic_write_json(lib / "brain.json", mf)
    with pytest.raises(RefusedError):
        brain.shelf_dir(lib, "evil")
    assert any(f["code"] == "SYMLINK_IN_LIBRARY" for f in brain.guard(lib))
    rep = brain.index_library(lib)
    assert rep["shelves"]["evil"]["status"] == "ERROR" and not any(n["shelf"] == "evil" for n in json.loads((lib / "index/global/global_kg.json").read_text())["nodes"])
    assert any(c["name"] == "symbolic links in library" and c["status"] == "FAIL" for c in doctor.run_checks(lib))


@pytest.mark.skipif(os.name != "posix", reason="POSIX modes")
def test_a_symlink_inside_a_confidential_shelf_cannot_redirect_chmod(lib, tmp_path):
    victim = tmp_path / "victim.txt"; victim.write_text("x"); os.chmod(victim, 0o644)
    brain.add_shelf(lib, "inv", "investigation", "MKSDL")
    put(lib, "inv", [node("A", "Issue", "a", "Medium", "MKSDL", status="ALLEGED"), node("B", "Vendor", "b", "High", "MKSDL")], [edge("A", "B")], True)
    os.symlink(victim, lib / "shelves/inv/trap")
    brain.index_library(lib); brain.remember(lib, "inv", "q?", "a", "useful")
    assert (victim.stat().st_mode & 0o777) == 0o644


@pytest.mark.parametrize("name", ["../x", "a/b", "..", ".", "A", "a b", "", "x" * 80, "a\x00b", "é"])
def test_shelf_names_cannot_traverse_or_surprise(lib, name):
    with pytest.raises(brain.BrainError):
        brain.shelf_dir(lib, name)
    with pytest.raises(brain.BrainError):
        brain.add_shelf(lib, name, "reference", "Group")
    with pytest.raises(brain.BrainError):
        brain.recall(lib, "x", shelves=[name])


# =========================================================================== I-14 audit and tamper
def _log(lib):
    return (lib / "audit.log").read_text().splitlines()


def _setup_history(lib):
    brain.index_library(lib); brain.remember(lib, "e1", "q1?", "a", "useful"); brain.remember(lib, "e1", "q2?", "a", "useful")


def test_chain_is_valid_after_normal_operations(lib):
    _setup_history(lib)
    cmds = [e["cmd"] for e in audit.read(lib)[0]]
    assert cmds[:3] == ["init", "shelf-add", "index"] and cmds.count("remember") == 2 and audit.verify(lib) == []
    assert brain.verify(lib) == []


def test_editing_an_entry_is_detected(lib):
    _setup_history(lib)
    lines = _log(lib); e = json.loads(lines[3]); e["actor"] = "someone-else"; lines[3] = json.dumps(e, separators=(",", ":"))
    (lib / "audit.log").write_text("\n".join(lines) + "\n")
    f = audit.verify(lib)
    assert f and f[0]["code"] == "AUDIT_CHAIN_BROKEN" and f[0]["ref"] == "seq 4"
    assert cli("verify", lib).returncode == 1 and cli("guard", lib).returncode == 1


def test_deleting_and_reordering_and_inserting_are_detected(lib):
    _setup_history(lib)
    lines = _log(lib)
    for mutated in (lines[:2] + lines[3:], lines[:1] + [lines[2], lines[1]] + lines[3:], lines[:2] + [lines[1]] + lines[2:]):
        (lib / "audit.log").write_text("\n".join(mutated) + "\n")
        assert any(f["code"] == "AUDIT_CHAIN_BROKEN" for f in audit.verify(lib))


def test_truncating_the_tail_is_caught_only_by_an_external_anchor(lib):
    _setup_history(lib)
    anchor = audit.head(lib)["hash"]
    lines = _log(lib); (lib / "audit.log").write_text("\n".join(lines[:-2]) + "\n")
    assert audit.verify(lib) == []                                                         # honest boundary: a valid prefix is not tampering
    assert any(f["code"] == "AUDIT_ANCHOR_MISMATCH" for f in audit.verify(lib, anchor))    # ...but the anchor proves the log shrank


def test_a_consistently_rewritten_log_fails_the_anchor(lib):
    _setup_history(lib)
    anchor = audit.head(lib)["hash"]
    entries = audit.read(lib)[0]
    prev, out = audit.ZERO, []
    for e in entries:
        e = dict(e); e["actor"] = "forged"; e["prev"] = prev; e["hash"] = audit.entry_hash(e); prev = e["hash"]; out.append(json.dumps(e, separators=(",", ":")))
    (lib / "audit.log").write_text("\n".join(out) + "\n")
    assert audit.verify(lib) == []                                                         # internally consistent...
    assert any(f["code"] == "AUDIT_ANCHOR_MISMATCH" for f in audit.verify(lib, anchor))   # ...but not the anchored history
    assert cli("verify", lib, "--anchor", anchor).returncode == 1


def test_a_torn_final_line_is_a_warning_and_the_next_append_repairs_it(lib):
    brain.remember(lib, "e1", "q?", "a", "useful")
    with open(lib / "audit.log", "ab") as fh:
        fh.write(b'{"seq": 99, "ts": "tor')                                              # crash mid-append
    f = audit.verify(lib)
    assert [x["code"] for x in f] == ["AUDIT_TORN_TAIL"] and f[0]["severity"] == "WARN"
    brain.remember(lib, "e1", "q2?", "a", "useful")
    assert audit.verify(lib) == []                                       # the crash is repaired, NOT a permanent chain error
    assert [p.read_bytes() for p in lib.glob("audit.log.torn-*")] == [b'{"seq": 99, "ts": "tor']   # torn bytes kept for forensics
    entries, _ = audit.read(lib)
    assert [e["seq"] for e in entries][-1] == entries[-1]["seq"] and entries[-1]["cmd"] == "remember"


def test_deleted_log_is_reported(lib):
    (lib / "audit.log").unlink()
    assert [f["code"] for f in audit.verify(lib)] == ["AUDIT_ABSENT"]


def test_seal_requires_a_reason_and_records_a_verifiable_snapshot(lib):
    with pytest.raises(brain.BrainError, match="reason"):
        brain.seal(lib, "e1", "  ")
    r = brain.seal(lib, "e1", "Reviewed against RACM v3 by the CAE")
    assert r["sealed"] and len(r["sha256"]) == 64 and r["audit_head"] == audit.head(lib)["hash"]
    assert (lib / "shelves/e1/.seals" / f"{r['sha256'][:16]}.json").exists() and brain.verify(lib) == []
    assert brain.changes(lib, "e1")["unchanged"] is True


def test_out_of_band_edit_after_a_seal_is_detected_and_explained(lib):
    brain.seal(lib, "e1", "reviewed")
    kg = json.loads((lib / "shelves/e1/KNOWLEDGE_GRAPH.json").read_text())
    kg["nodes"][3]["confidence"] = "100%"; kg["nodes"][3]["label"] = "TAMPERED"; kg["nodes"].pop(1)
    ag.atomic_write_json(lib / "shelves/e1/KNOWLEDGE_GRAPH.json", kg)
    assert [f["code"] for f in brain.verify(lib)] == ["UNSEALED_CHANGES"] and cli("verify", lib).returncode == 0
    assert cli("verify", lib, "--strict").returncode == 1
    ch = brain.changes(lib, "e1")
    codes = {f["code"] for f in ch["flags"]}
    assert "NODE_REMOVED" in codes and ch["unchanged"] is False and any(c["fields"].get("label") for c in ch["nodes_changed"])
    assert cli("changes", lib, "--shelf", "e1").returncode == 1


def test_confidence_raised_is_flagged_with_the_evidence_rank(lib):
    kg = json.loads(json.dumps(FIX)); kg["nodes"][1]["confidence"] = "Medium"; ag.atomic_write_json(lib / "shelves/e1/KNOWLEDGE_GRAPH.json", kg)
    brain.seal(lib, "e1", "baseline")
    kg["nodes"][1]["confidence"] = "100%"; kg["nodes"][1]["evidence_rank"] = "R5"; ag.atomic_write_json(lib / "shelves/e1/KNOWLEDGE_GRAPH.json", kg)
    flag = next(f for f in brain.changes(lib, "e1")["flags"] if f["code"] == "CONFIDENCE_RAISED")
    assert (flag["from"], flag["to"], flag["evidence_rank_now"]) == ("Medium", "100%", "R5")


def test_a_tampered_seal_snapshot_is_an_error(lib):
    r = brain.seal(lib, "e1", "reviewed")
    snap = lib / "shelves/e1/.seals" / f"{r['sha256'][:16]}.json"
    snap.write_text(snap.read_text().replace("CLRA", "XXXX"))
    assert any(f["code"] == "SEAL_SNAPSHOT_TAMPERED" and f["severity"] == "ERROR" for f in brain.verify(lib))
    assert any(f["code"] == "SEAL_SNAPSHOT_TAMPERED" for f in brain.changes(lib, "e1")["flags"])


def test_never_sealed_shelf_says_so(lib):
    ch = brain.changes(lib, "e1")
    assert ch["sealed"] is False and "never been sealed" in ch["note"] and ch["flags"] == []


# =========================================================================== I-18 confidential lessons, and general confidentiality
def test_confidential_lessons_never_reach_shared_files_or_reports(lib):
    brain.add_shelf(lib, "inv", "investigation", "MKSDL")
    put(lib, "inv", [node("A", "Issue", "secret allegation", "Medium", "MKSDL", status="ALLEGED"), node("B", "Vendor", "vendor", "High", "MKSDL")], [edge("A", "B")], True)
    brain.index_library(lib)
    brain.remember(lib, "inv", "Is ACME-SECRET linked to bribery?", "Possibly", "corrected", correction="no: confirmed unrelated to ACME-SECRET")
    brain.remember(lib, "e1", "ordinary question?", "a", "corrected", correction="ordinary correction")
    rep = brain.reflect(lib)
    shared = Path(rep["proposed_lessons"]).read_text()
    assert "ACME-SECRET" not in shared and "ordinary correction" in shared and "withheld" in shared
    shelf_file = lib / "shelves/inv/PROPOSED_LESSONS.md"
    assert "ACME-SECRET" in shelf_file.read_text()
    if os.name == "posix":
        assert (shelf_file.stat().st_mode & 0o077) == 0
    import report
    d = report.collect(lib, "2026-10-03"); html = report.render_html(d)
    assert "ACME-SECRET" not in html and "ACME-SECRET" not in json.dumps(d)
    assert brain.guard(lib) == []


def test_confidential_shelf_stays_out_of_every_shared_path(lib):
    brain.add_shelf(lib, "inv", "investigation", "MKSDL")
    put(lib, "inv", [node("ALG-SECRET", "Issue", "kickback ACME", "Medium", "MKSDL", status="ALLEGED"), node("V", "Vendor", "ACME Tooling", "High", "MKSDL")], [edge("ALG-SECRET", "V")], True)
    brain.index_library(lib)
    assert not brain.recall(lib, "kickback ACME")["results"]
    for blob in ((lib / "index/global/global_kg.json").read_text(), (lib / "index/global/graphify-out/graph.json").read_text(), json.dumps(brain.mcp_config(lib))):
        assert "ALG-SECRET" not in blob and "ACME" not in blob
    with pytest.raises(brain.BrainError):
        brain.recall(lib, "x", shelves=["inv", "e1"])
    with pytest.raises(PermissionError):
        ag.merge_kgs(FIX, {**FIX, "engagement": "INV", "confidential": True})


# =========================================================================== I-12 local time, I-11 arguments
@pytest.mark.skipif(os.name != "posix", reason="TZ semantics")
def test_default_today_is_the_local_date_in_every_command(lib):
    for tz in ("Pacific/Kiritimati", "Pacific/Pago_Pago", "Asia/Kolkata"):
        want = subprocess.run(["date", "+%F"], capture_output=True, text=True, env={**os.environ, "TZ": tz}).stdout.strip()
        for cmd in (["stale", lib], ["status", lib]):
            r = cli(*cmd, env={"TZ": tz})
            assert r.returncode == 0
            d = json.loads(r.stdout)
            assert (d.get("today") or want) == want, (tz, cmd)


def test_gia_today_makes_runs_reproducible(lib):
    ag.atomic_write_json(lib / "shelves/e1/shelf.json", {**json.loads((lib / "shelves/e1/shelf.json").read_text()), "kind": "statutory"})
    put(lib, "e1", [node("R", "Regulation", "wage rule", review_by="2026-10-04"), node("S", "Regulation", "other rule", review_by="2027-01-01")], [edge("R", "S")])
    assert brain.stale_report(lib, "2026-10-03")["items"] == []
    assert [i["id"] for i in json.loads(cli("stale", lib, env={"GIA_TODAY": "2026-10-05"}).stdout)["items"]] == ["R"]


@pytest.mark.parametrize("args", [["recall", "LIB", "x", "--limit", "0"], ["recall", "LIB", "x", "--limit", "-1"], ["recall", "LIB", "x", "--limit", "1001"],
                                  ["recall", "LIB", "x", "--limit", "abc"], ["shelf-add", "LIB", "zz", "--kind", "policy", "--entity", "Group", "--review-days", "0"],
                                  ["recall", "LIB", "x", "--today", "03/10/2026"], ["stale", "LIB", "--today", "yesterday"], ["recall", "LIB", "x", "--max-rank", "R9"]])
def test_bad_arguments_exit_2_with_one_clear_line(lib, args):
    r = cli(*[str(lib) if a == "LIB" else a for a in args])
    assert r.returncode == 2 and "Traceback" not in r.stderr


def test_future_library_schema_is_refused_older_is_accepted(lib):
    mf = json.loads((lib / "brain.json").read_text()); mf.pop("schema_version"); ag.atomic_write_json(lib / "brain.json", mf)
    assert brain.load_manifest(lib)["shelves"] == ["e1"]                                  # a v1.x library (no schema_version) still opens
    mf["schema_version"] = 99; ag.atomic_write_json(lib / "brain.json", mf)
    with pytest.raises(RefusedError):
        brain.load_manifest(lib)
    assert cli("status", lib).returncode == 2


# =========================================================================== I-16 doctor
def test_doctor_environment_and_library(lib):
    checks = {c["name"]: c for c in doctor.run_checks(lib)}
    assert checks["python"]["status"] == "OK" and checks["graphify"]["status"] == "OK" and checks["atomic write + lock"]["status"] == "OK"
    assert checks["library writable and lockable"]["status"] == "OK" and checks["symbolic links in library"]["status"] == "OK"
    r = cli("doctor", lib)
    assert r.returncode == 0 and "0 failure(s)" in r.stdout


def test_doctor_flags_debug_variables_and_a_missing_library(tmp_path, monkeypatch):
    monkeypatch.setenv("GIA_DEBUG", "1")
    assert any(c["name"] == "env GIA_DEBUG" and c["status"] == "WARN" for c in doctor.run_checks(env=os.environ))
    r = cli("doctor", tmp_path / "does" / "not" / "exist")
    assert r.returncode in (0, 1)


# =========================================================================== I-13 performance budgets
@pytest.mark.skipif(os.environ.get("GIA_SKIP_PERF"), reason="perf skipped")
def test_recall_and_validate_at_100k_nodes_meet_the_budget(tmp_path):
    import random
    random.seed(1); N = 100_000; w = ["payroll", "scrap", "EPF", "GST", "ghost", "CLRA", "vendor", "tooling", "minimum", "wage", "contract", "labour"]
    L = tmp_path / "lib"; brain.init_library(L); brain.add_shelf(L, "big", "engagement", "MKAPL-DC")
    nodes = [node(f"N-{i:06d}", "Risk", f"{random.choice(w)} {random.choice(w)} item {i}") for i in range(N)]
    edges = [edge(f"N-{i:06d}", f"N-{(i * 7 + 1) % N:06d}") for i in range(N)] * 3
    ag.atomic_write_json(L / "shelves/big/KNOWLEDGE_GRAPH.json", {"engagement": "big", "last_updated": "2026-10-01", "nodes": nodes, "edges": edges})
    t = time.time(); r = brain.recall(L, "payroll vendor wage"); dt = time.time() - t
    assert r["results"] and len(r["results"][0]["neighbors"]) <= 5 and dt < 3.0, f"recall took {dt:.2f}s"
    t = time.time(); kg = ag.load_json(L / "shelves/big/KNOWLEDGE_GRAPH.json"); ag.validate_kg(kg, "draft"); dv = time.time() - t
    assert dv < 15, f"load+validate took {dv:.1f}s"
    print(f"\nPERF recall={dt:.2f}s validate={dv:.2f}s")


# =========================================================================== found while designing the UAT
def test_an_answer_file_saved_but_never_indexed_is_adopted_by_the_next_write(lib):
    brain.remember(lib, "e1", "first question?", "first", "useful")
    # simulate a crash after the answer file was saved but before the index was updated
    from graphify.ingest import save_query_result
    time.sleep(1.1)
    save_query_result("orphan question?", "orphan answer", lib / "shelves/e1/graphify-out/memory", query_type="query", outcome="corrected", correction="fixed answer")
    assert any(f["code"] == "MEMORY_INDEX_MISMATCH" for f in brain.guard(lib))
    brain.remember(lib, "e1", "third question?", "third", "useful")
    idx = json.loads((lib / "shelves/e1/memory_index.json").read_text())
    orphan = next(e for e in idx if e["question"] == "orphan question?")
    assert len(idx) == 3 and orphan["outcome"] == "corrected" and orphan["correction"] == "fixed answer" and orphan.get("recovered") is True
    assert not any(f["code"] == "MEMORY_INDEX_MISMATCH" for f in brain.guard(lib))
    assert any(e["cmd"] == "memory-index-reconciled" for e in audit.read(lib)[0]) and audit.verify(lib) == []


def test_nothing_derived_from_confidential_content_enters_the_shared_audit_log(lib):
    brain.add_shelf(lib, "inv", "investigation", "MKSDL")
    put(lib, "inv", [node("A", "Issue", "allegation", "Medium", "MKSDL", status="ALLEGED"), node("B", "Vendor", "vendor", "High", "MKSDL")], [edge("A", "B")], True)
    brain.index_library(lib)
    brain.remember(lib, "inv", "Is ACME-SECRET-VENDOR bribing the buyer?", "possibly", "corrected", correction="no, ACME-SECRET-VENDOR is clean")
    brain.seal(lib, "inv", "Reviewed the ACME-SECRET-VENDOR allegation with the CAE")
    log = (lib / "audit.log").read_text()
    assert "ACME-SECRET-VENDOR" not in log and "acme_secret" not in log.lower() and "withheld" in log
    ch = brain.changes(lib, "inv")
    assert "ACME-SECRET-VENDOR" in ch["reason"]                                  # still available to the owner of the shelf
    reason_file = next((lib / "shelves/inv/.seals").glob("*.reason.txt"))
    if os.name == "posix": assert (reason_file.stat().st_mode & 0o077) == 0
    assert audit.verify(lib) == [] and brain.verify(lib) == []


# =========================================================================== opt-in IDF ranking (found by UAT S1)
def test_idf_ranking_lets_a_rare_word_beat_thousands_of_common_ones(lib):
    nodes = [node(f"C-{i}", "Process", f"payroll process item {i}") for i in range(300)] + [node("RARE", "Process", "Nómina semanal de planta")]
    put(lib, "e1", nodes, [edge("C-0", "C-1")])
    plain = brain.recall(lib, "payroll weekly plant", limit=1000)
    idf = brain.recall(lib, "payroll weekly plant", limit=1000, ranking="idf")
    assert plain["ranking"] == "score" and idf["ranking"] == "idf"
    assert [r["id"] for r in plain["results"]].index("RARE") > 100                 # default behaviour is unchanged: common words win
    assert idf["results"][0]["id"] == "RARE"                                       # rarity weighting surfaces it first
    assert "nomina" in idf["expanded_terms"]


def test_default_ranking_is_byte_compatible_and_idf_is_validated(lib):
    r1, r2 = brain.recall(lib, "written service agreement control"), brain.recall(lib, "written service agreement control", ranking="score")
    assert r1 == r2 and r1["results"][0]["id"] == "CTRL-CLD-01"
    with pytest.raises(brain.BrainError, match="ranking"):
        brain.recall(lib, "x", ranking="bm25")
    assert cli("recall", lib, "written service agreement", "--ranking", "idf").returncode == 0
    assert cli("recall", lib, "x", "--ranking", "nope").returncode == 2


def test_clean_temp_removes_only_old_dot_tmp_files(tmp_path):
    old, new, keep = tmp_path / ".a.json.xx.tmp", tmp_path / ".b.json.yy.tmp", tmp_path / "real.tmp"
    for f in (old, new, keep): f.write_text("x")
    os.utime(old, (time.time() - 3600,) * 2)
    assert fsutil.clean_temp(tmp_path, 600) == [str(old)] and new.exists() and keep.exists() and not old.exists()


@pytest.mark.parametrize("args", [["init", ""], ["status", ""], ["recall", "", "x"], ["doctor", " "], ["shelf-add", "", "a", "--kind", "policy", "--entity", "Group"]])
def test_an_empty_library_path_is_a_clean_error_not_an_internal_error(args):
    r = cli(*args)
    assert r.returncode == 2 and "must not be empty" in r.stderr and "internal error" not in r.stderr and "Traceback" not in r.stderr


# =========================================================================== graphify absent (e.g. a claude.ai sandbox)
@pytest.fixture
def no_graphify(tmp_path):
    shim = tmp_path / "shim" / "graphify"; shim.mkdir(parents=True)
    (shim / "__init__.py").write_text('raise ImportError("graphify is not installed (simulated)")\n')
    return {"PYTHONPATH": str(tmp_path / "shim")}


@pytest.mark.parametrize("args", [["index", "LIB"], ["remember", "LIB", "--shelf", "e1", "--question", "q?", "--answer", "a", "--outcome", "useful"]])
def test_a_missing_graphify_is_a_clear_exit_2_not_an_internal_error(lib, no_graphify, args):
    r = cli(*[str(lib) if a == "LIB" else a for a in args], env=no_graphify)
    assert r.returncode == 2 and "graphify is not installed" in r.stderr and "pip install" in r.stderr
    assert "internal error" not in r.stderr and "Traceback" not in r.stderr


def test_to_graphify_without_graphify_is_a_clear_exit_2(tmp_path, no_graphify):
    kg = tmp_path / "k.json"; kg.write_text(json.dumps(FIX))
    r = subprocess.run([sys.executable, str(SCRIPTS / "akos_graph.py"), "to-graphify", str(kg), "--out", str(tmp_path / "o")], capture_output=True, text=True, env={**os.environ, **no_graphify})
    assert r.returncode == 2 and "graphify is not installed" in r.stderr and "internal error" not in r.stderr


def test_everything_that_does_not_need_graphify_still_works_without_it(lib, no_graphify, tmp_path):
    kg = lib / "shelves/e1/KNOWLEDGE_GRAPH.json"
    for a in (["recall", lib, "written service agreement"], ["status", lib], ["stale", lib], ["guard", lib], ["verify", lib],
              ["seal", lib, "--shelf", "e1", "--reason", "no graphify here"], ["changes", lib, "--shelf", "e1"], ["dashboard", lib, "--out", tmp_path / "rep"]):
        r = cli(*a, env=no_graphify)
        assert r.returncode in (0, 1) and "internal error" not in r.stderr, (a, r.stderr[-120:])
    for a in (["validate", kg, "--gate", "final"], ["stats", kg], ["deliverable", kg, "--out", tmp_path / "d.json"], ["export-xlsx", kg, "--out", tmp_path / "x.xlsx"], ["merge", kg, kg, "--out", tmp_path / "m.json"]):
        r = subprocess.run([sys.executable, str(SCRIPTS / "akos_graph.py"), *map(str, a)], capture_output=True, text=True, env={**os.environ, **no_graphify})
        assert r.returncode in (0, 1) and "internal error" not in r.stderr, (a, r.stderr[-120:])
    d = cli("doctor", lib, env=no_graphify)
    assert d.returncode == 1 and "graphify" in d.stdout                                  # the doctor reports it as a FAILURE with the remedy
