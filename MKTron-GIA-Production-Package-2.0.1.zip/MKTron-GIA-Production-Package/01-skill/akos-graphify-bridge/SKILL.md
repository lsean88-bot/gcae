---
name: akos-graphify-bridge
description: >
  Bridge between the AKOS Knowledge Graph (KNOWLEDGE_GRAPH.json) and graphify, plus the "library brain": a shelved,
  confidentiality-aware knowledge base with recall, work-memory and staleness control. Use to turn audit folders,
  SOPs, RACMs, findings, policies or reports into a queryable graph; visualise or cluster the risk-control-finding-
  regulation network; trace what connects X to Y across entities (MKAPL, MKPC, MKSDL, NMSB, SAPL); find god-nodes,
  repeat findings or orphan controls; validate a KG before a Board or AC paper; build or query a library, second
  brain or knowledge base; use graphify memory (save-result, reflect, serve, MCP); keep investigations isolated; or
  check that installed audit skills interlock (/akos-interop-check). Also "graphify", "library brain", "knowledge
  repository". Not for single findings, formatting, or building AKOS Project Memory (use akos-enterprise-orchestrator).
metadata:
  version: "2.0.1"
  complements: "akos-enterprise-orchestrator, iron-rules-governance, cae-report-conversion, board-chairman-briefing, group-cae-fraud-v2"
---

# AKOS-Graphify Bridge

AKOS **owns** the knowledge graph and its integrity. graphify **analyses** it. This skill
is the controlled border between the two. Neither side's vocabulary is allowed to leak
into the other's evidence discipline.

```
KNOWLEDGE_GRAPH.json  ──to-graphify──▶  graphify-out/graph.json  (+ graph.html)
   (AKOS, canonical)                        │  cluster · query · path · explain · god-nodes
        ▲                                   ▼
        └──────── from-graphify ◀───── semantic / AST extraction (Claude is the extractor)
              (lands as PROPOSED, never silently confirmed)
```

Read `references/mapping-spec.md` before changing any mapping rule. Read
`references/graphify-environment.md` if graphify tests or builds fail on a fresh machine.

## When to read what

| Situation | Do |
|---|---|
| Build / refresh a visual, queryable graph from an existing KG | `to-graphify`, then use graphify CLI |
| Ingest a new folder of documents | graphify extraction → `from-graphify` → classify → promote (see Ingest workflow) |
| Anything going into a Board/AC/regulator deliverable | `validate --gate final` then `deliverable` |
| "Do my skills work together?" | `scripts/interop_check.py` (`/akos-interop-check`) |
| Active fraud investigation | Isolated engagement, `confidential: true`, never `merge` |

## Scripts (all in `scripts/`, run with `python3`)

- `akos_graph.py <cmd>`: `to-graphify`, `from-graphify`, `validate`, `merge`, `deliverable`, `stats`, `export-xlsx`.
- `brain.py <cmd>` (the library brain): `init`, `shelf-add`, `index`, `recall`, `remember`, `reflect`, `stale`, `status`,
  `guard`, `mcp-config`, `dashboard`, and (v2.0) `seal`, `changes`, `verify`, `doctor`. Guide: `references/library-brain.md`.
- `interop_check.py`, `register_entity.py`, `bootstrap_env.sh`: as before; both Python tools now exit by the contract below.
- Foundation modules (layer L0, no CLI): `errors`, `fsutil` (atomic writes, locks, containment, crash-safe swaps), `strictjson`,
  `textsafe`, `textnorm`, `schema`. Service modules: `audit` (hash-chained log), `doctor`, `report`.

**Exit codes are a contract:** `0` ok · `1` findings that need action · `2` bad input, refused, or lock timeout (the user can fix
it) · `3` internal error (a bug; one line, `GIA_DEBUG=1` for the traceback). Environment: `GIA_TODAY=YYYY-MM-DD` fixes the
date for reproducible runs; `GIA_NO_FSYNC`, `GIA_DEBUG`, `GIA_MAX_JSON_BYTES` are for tests and debugging (`doctor` flags them).

## The non-negotiable translation rules

These exist because graphify's confidence words (EXTRACTED / INFERRED / AMBIGUOUS) mean
"how the *tool* found it", whereas AKOS confidence (100% / High / Medium / Low) means "how
strongly *evidence* supports it". Conflating them is how an AI-inferred link ends up as an
audit conclusion.

1. **EXTRACTED never becomes 100%.** At most `High`. 100% needs named, authoritative evidence
   (Iron Rule 17: AI/graph output is an indicator, not evidence). `validate` errors on a
   graphify-origin node at 100%.
2. **INFERRED / AMBIGUOUS edges are `indicator_only`.** INFERRED ≥0.75 → `Medium`; below →
   `Low`. AMBIGUOUS → `Low`. An indicator edge rated High/100% is a validation ERROR.
3. **Native graphify nodes are `PROPOSED` and never guessed.** A document stays `Document`;
   a code symbol or concept is `UNCLASSIFIED` until a human or the right domain skill types
   it. Unmapped entity → `UNCLASSIFIED` plus an Outstanding Question. Never infer entity
   from a hunch (Module 12 rule 7).
4. **The existing KG always wins.** `from-graphify` never overwrites a node already in
   `KNOWLEDGE_GRAPH.json`; differences are listed as `conflicts` for the Decisions Register
   (Module 11).
5. **Direction is explicit.** graphify persists an undirected graph, so every edge carries
   `akos_from`/`akos_to`. Never rebuild an AKOS edge from graphify's source/target alone
   when those attributes exist.
6. **Saved Q&A is never evidence.** Anything from `graphify-out/memory/` is capped at `Low`, `indicator_only`,
   origin `graphify-memory`, and excluded from `deliverable`. `validate` errors if it is raised (`MEMORY_AS_EVIDENCE`).
7. **Search by AKOS id works** because the graphify-side label is `[AKOS-ID] label`. The
   prefix is stripped on the way back. Do not change this without re-running the round-trip tests.

## Ingest workflow (new documents → graph)

1. **Extract** using graphify (`/graphify <folder>`; its AST pass is free, the semantic pass
   uses Claude). Markdown/PDF structure comes for free; risk-control-finding *relationships*
   come only from the semantic pass.
2. **Stage:** `akos_graph.py from-graphify graph.json --kg KNOWLEDGE_GRAPH.json --out staged.json --entity-map entities.json --today YYYY-MM-DD`.
   `--entity-map` is a JSON of `{ "MKAPL-DC": ["path substring", ...] }` that *the user supplies*.
   There is no default: folder naming is not something to guess.
3. **Review the report:** `unclassified` list → Outstanding Questions Register; `conflicts` →
   Decisions Register; `indicator_edges` → candidates for testing, never for citing.
4. **Classify** each PROPOSED node (type, entity), ideally by routing to the owning domain
   skill (e.g. statutory items → `chennai-india-ops-audit`). Promote by setting status to
   confirmed (remove `PROPOSED`) and confidence only as high as the evidence rank supports.
5. **Gate:** `validate --gate final`. Fix every ERROR. Then `deliverable` for the safe subset.

## Quality gate (AKOS Module 9; the canonical rules live in iron-rules-governance)

`validate --gate draft` warns; `--gate final` errors on: orphan nodes, UNCLASSIFIED type or
entity, unknown entity, PROPOSED/RETRACTED status, Low confidence, near-duplicate nodes
(warn: Iron Rule 05, merge never double-count), dangling edges, invalid vocabulary, missing
source_location (every claim must trace back), 100% edge without evidence,
ALLEGED item at 100%, confidential-graph cross-engagement leak.

`deliverable` exports only: not PROPOSED/RETRACTED/ALLEGED, confidence ≥ High (Medium with
`--include-medium`, flagged for validation), and no indicator-only edges.

If entity names in your audits are missing from `config/entities.json` (the file mirrors the
AKOS schema enum), `validate` warns in draft and errors in final. Add the entity there *and*
in the AKOS schema so the two stay in step.

## Library brain (shelves, recall, memory)

Use when the user wants a standing knowledge base rather than one engagement's graph. Full explanation:
`references/library-brain.md`.

1. `brain.py init <lib>`, then `shelf-add <lib> <name> --kind engagement|statutory|policy|investigation|reference --entity <CODE>`.
   The entity must already exist in `config/entities.json`; the brain will not invent codes. Investigation shelves
   are always confidential.
2. Fill each shelf's `KNOWLEDGE_GRAPH.json` through the Ingest workflow above, then `brain.py index <lib>`.
3. `brain.py recall <lib> "<question>" [--shelf S] [--min-confidence Medium]` returns ranked nodes with a **trust
   label** (CONFIRMED / PROVISIONAL / INDICATOR), source location, neighbours and a STALE/UNDATED flag. Report the
   label with every item, and never present INDICATOR items as findings. A confidential shelf is recalled on its own.
   Each result also carries its `evidence_rank` (R1-R5 or UNRANKED). `--max-rank R3` keeps only items with a *known* rank
   no worse than R3 and reports how many unranked items it excluded. R4 is shown as PROVISIONAL and R5 as INDICATOR,
   whatever the stated confidence. Recall is script-aware (`Nómina` = `nomina`; Tamil and Chinese labels are findable)
   and expands through `synonyms.json` (e.g. payroll / nómina / gaji, EPF / provident fund). Expansions are listed in
   `expanded_terms`; direct matches always outrank synonym matches. `STALE`, `UNDATED` and `BAD_DATE` (a date that
   is not YYYY-MM-DD) all mean: re-validate before use. An unreadable date is never treated as fresh.
   On a large library add `--ranking idf`: rare words (e.g. a Spanish or Tamil term reached by synonym) count more than
   ubiquitous ones. The default ranking is unchanged from v1.x.
4. After answering, `brain.py remember <lib> --shelf S --question ... --answer ... --outcome useful|dead_end|corrected
   [--correction ...] [--nodes ID ...]`. `corrected` requires the right answer. Unknown node ids are reported, not hidden.
5. `brain.py reflect <lib>` runs graphify's reflection per shelf and writes `lessons/PROPOSED_LESSONS.md`:
   candidates only. Ask the user before promoting any of them.
6. `brain.py dashboard <lib> --out <dir>` produces `brain-dashboard.html` and `.xlsx` (confidential shelves as counts only).
7. `brain.py seal <lib> --shelf S --reason "..."` when a human has reviewed a shelf; later `changes --shelf S` shows exactly what
   moved (a confidence raised, a status changed, a node removed) and `verify [--anchor HASH]` checks the audit trail. Record the
   `audit_head` that `seal` prints somewhere you control: it is what makes truncation or a rewrite provable.
8. `brain.py doctor [lib]` checks the environment and library can run safely (backend auto-select, symlinks, locks, disk, time zone).
9. `brain.py guard <lib>` before sharing or scheduling anything: confidential content in the global graph, unisolated
   investigations, memory raised above Low, confidential files readable by others (confidential shelves are kept
   owner-only, 0700/0600), and the extraction backend graphify *would* auto-select. `stale --strict`
   gates statutory freshness. `mcp-config` prints the MCP server config (non-confidential shelves only).

## Fraud and confidential engagements

Active, unconfirmed investigations get their own KG with `"confidential": true` and a distinct
`engagement`. `merge` refuses cross-engagement merges involving a confidential graph (exit 2);
`validate` flags any node whose `engagement` differs from a confidential graph's own. Allegations
carry `status: ALLEGED` and can never be 100% or appear in a deliverable. Hand off to
`group-cae-fraud-v2` for chain-of-custody; notify Board/AC only when the investigation concludes.

## Production guarantees (v2.0) and their honest boundaries

| Guarantee | How | Boundary |
|---|---|---|
| No lost update from concurrent runs | per-shelf and library locks around every read-modify-write | cooperating tools only (advisory locks) |
| A reader never sees a half-written file | temp file, fsync, rename | power loss may keep the previous file |
| One bad shelf never blocks the others | each shelf indexed in isolation; failed shelves excluded from the global graph | the run exits 1 so it is noticed |
| The global index is always old-or-new | staging folder swapped in by rename; `index` restores a killed swap | kill -9 between the two renames leaves `global.old-<pid>`, restored next run |
| Corrupt memory index self-heals | quarantined (kept), rebuilt from the saved answer files; orphaned answers adopted | answers themselves are never reconstructed |
| Every change is recorded and tamper-evident | hash-chained `audit.log`; `seal` snapshots; `changes` and `verify` | a log truncated at the end or fully rewritten is caught **only with an external anchor** (`verify --anchor`) |
| Confidential content never reaches a shared file | no content-derived text in the audit log, shared lessons, reports, global graph or MCP config; owner-only modes; symlinks refused | the shelf's own folder, and commands that name the shelf explicitly |
| Input can never crash the tools or the terminal | structural checks before use; strict JSON (BOM ok; duplicate keys, NaN, bad UTF-8, deep nesting refused); all output sanitised for terminal, HTML and Excel | an exit 3 means a bug: report it |
| Dates fail safe | local calendar date; only `YYYY-MM-DD`; unreadable = not fresh | |

## Handoff contract (registry-format)

**`akos-graphify-bridge`**
- *Reads:* `KNOWLEDGE_GRAPH.json`, graphify `graph.json`, optional `entity-map.json`,
  `config/entities.json`.
- *Produces:* graphify `graph.json`/`graph.html`, staged KG with PROPOSED items, validation
  report, deliverable-safe KG subset, interop report.
- *Writes back:* proposed Knowledge Graph nodes/edges (never confirmed ones), Outstanding
  Questions (unclassified items), Decisions Register candidates (conflicts).
- *Typically followed by:* `akos-enterprise-orchestrator` (confirm and record), a domain
  skill (classify), `cae-report-conversion` or `board-chairman-briefing` (publish, using the
  `deliverable` subset only).
- *Coordination note:* this skill never confirms a fact, assigns a finding rating, or decides
  entity classification on its own authority.

Proposed registry text for AKOS (for the user to review, not applied automatically):
`references/registry-entry-proposal.md`.

## Using graphify itself

After `to-graphify`, the graphify CLI works directly on `<out>/graphify-out/graph.json`:
`graphify query "<question>" --graph G`, `graphify path A B --graph G`,
`graphify explain <node> --graph G` (A, B, node can be AKOS ids such as `CTRL-CLD-01`),
`graphify god-nodes --graph G`. In graphify's own output, "EXTRACTED" for an edge here means
AKOS `100%` or `High`; the true value is in the `akos_confidence` attribute.

Do not describe graph results as findings. They are navigation aids that point an auditor at
documents and relationships to *test*.

## Interop check

`python3 scripts/interop_check.py` (defaults: `/mnt/skills/{user,plugins,public,examples}`). Reports:
`DUPLICATE_DRIFT` (same skill installed twice with different content, and which copy is newer),
`SUPERSEDED_ROUTED` (registry still routes to a skill a newer installed skill declares it supersedes),
`REF_UNRESOLVED`, `REF_UNCONFIRMED` (registry itself says a missing skill's status is unknown: an owner decision,
never to be described as "retired"), `UNREGISTERED` audit skills, `ENTITY_LISTS_DISAGREE`, `FM_MISSING`,
`NAME_DIR_MISMATCH`. Agent roles and sentence-level documented retirements are exempt automatically.
Treat the output as a maintenance to-do list for the skill owner; do not edit other skills on its basis without
the user's say-so. The companion patch bundle `gia-ecosystem-patch` applies the evidence-clear fixes and lists the
owner decisions it deliberately leaves alone.

## Self-learning (Kaizen)

When a pattern recurs (a mapping fix, an entity needing registration, an environment gap),
propose a `LESSONS_LEARNED.md` entry and ask the user to confirm before writing it. Rule or
CLAUDE.md changes go through `iron-rules-governance`. Never write governance text silently.
