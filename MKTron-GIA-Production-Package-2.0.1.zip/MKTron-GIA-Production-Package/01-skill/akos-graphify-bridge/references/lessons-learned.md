# Proposed LESSONS_LEARNED entries: akos-graphify-bridge work, 3 Oct 2026

Status: **proposed, none promoted.** Per iron-rules-governance, skill-specific fixes live in the owning skill file and
go through AKOS Module 7; nothing here is a portfolio-wide rule, so no go-ahead for a standing rule is requested.
The same text is shipped as `references/lessons-learned.md` inside the skill.

| # | Lesson | Evidence | Where it lives |
|---|---|---|---|
| L1 | graphify test failures on a new machine are provisioning, not code. Four clusters: optional extras (tree-sitter-hcl), openai+tiktoken, build tooling (build, setuptools>=77), and pinned baseline commits for skillgen. Run `scripts/bootstrap_env.sh` first | 22 failures to 4,903 passed, 0 source changes | `references/graphify-environment.md` |
| L2 | Sandbox shells may be `/bin/sh` (dash): no `{a,b}` brace expansion (silently creates a literal directory), no `time`, no `<( )`. Use `bash -c` | Literal `{scripts,references,...}` directory created; `time` swallowed output | same file |
| L3 | A drift check that scans one root can say "clean" while checking one skill. Verify what a check actually scanned before trusting "clean". Plugin folders can contain `:`, so never split `grep -n` output on the first colon | Checks 1, 2, 5 clean on `user/`, findings on `plugins/`; path split bug found by test | drift script v1.1 (via the patch) |
| L4 | Keyword matching reads an unanswered question as an answer: "intentional" in a sentence that asks *whether* it was intentional. Classify status per sentence, and let doubt win over a retired marker | `mac-audit-constitution-l99` reported "consistent" when the registry says "not established" | `scripts/interop_check.py`, tests |
| L5 | Fuzzy label search must be able to find items by their governance id. Put `[AKOS-ID]` in the graphify-side label | `graphify path` resolved two different AKOS ids to one node | `references/mapping-spec.md` |
| L6 | A saved answer must not be able to become evidence for itself. Cap memory-derived nodes at Low and exclude them from deliverables | graphify re-extracts `memory/` notes into the graph | `MEMORY_AS_EVIDENCE`, `references/library-brain.md` |
| L7 | graphify's backend auto-detect picks gemini before claude. For confidential material always pass `--backend` explicitly | `detect_backend()` priority in `llm.py` | `brain.py guard` |
| L8 | Debian-owned Python packages (PyJWT) block `pip install mcp`; use `--ignore-installed PyJWT`. MCP results lack trust labels, so reliance decisions go through `brain.py recall` | pip error; real MCP handshake | `bootstrap_env.sh --with-mcp`, `references/graphify-environment.md` |
| L9 | Run the portfolio drift check on your OWN new skills before delivering: my skill heading and, later, a protocol heading both tripped Check 2 by containing "Iron Rules" | `user/akos-graphify-bridge` flagged by Check 2; again after a heading rename | drift script; keep headings free of that phrase |
| L10 | Verify a checker's claim against the files before "fixing" the checker. I assumed Check 1 lacked an allowlist entry; the files showed the namespaces were decided but never applied inside racm-ecosystem and cae-report-conversion | 12 bare `RULE nn` lines still present vs approved `RACM-nn` | patch ops E1/E2 |
| L11 | A script run as `__main__` that lazily imports a module which imports it back loads TWO copies; exception classes differ and `except` misses. Alias `sys.modules["brain"]` first | dashboard on a non-library exited 1 (crash) instead of 2 | `brain.py` |
| L12 | Fail closed on dates: an unparseable date must never read as "fresh". Accept only YYYY-MM-DD; report BAD_DATE | "April 2026" and "2026-4-1" returned not-stale | `brain.staleness` |
| L13 | ASCII-only tokenizers break real MKTron data: "Nómina" matched "mina"; Tamil and Chinese produced no tokens at all. Fold Latin accents only, keep other scripts' marks, bigram CJK | probe output | `textnorm.py` |
| L14 | Mutation-test new tests: revert the behaviour and confirm the test fails. 5 of 5 new behaviours were caught | mutation run | test practice |
| L15 | Use realistic fixtures. Fake skill folders without a SKILL.md hid that the v1.2 drift script only scans real skills | 4 stale test failures | `tests/test_patch.py` |
| L16 | `cut -c` can split a multi-byte character and the tool returns nothing. Truncate in Python | binary-output error | working practice |
| L17 | A rename that follows an approved namespace should verify text line by line, tolerate a clear paraphrase with a reported note, and refuse otherwise. Never force a governance edit | Charlie Hills line differed in RACM-12 / RC-11 | `edits.py` |
| L18 | Attack before you design: 7 of the production defects (lost updates, symlink chmod escape, torn-read tracebacks, missing-folder-after-crash...) were invisible to reading the code and obvious the moment a probe ran | probes P1-P22 | `PRODUCTION_PLAN.md` |
| L19 | "Nothing compromised" needs evidence, not intent: a deterministic golden master (43 scenarios, shown able to catch injected regressions) plus mutation-checked tests | compat/ | `release_gate.py` |
| L20 | An assertion with an `or` can hide the defect it exists to catch: the torn-audit-tail test accepted either outcome while the real behaviour was a permanent chain error | S3 prep | `audit._repair_torn_tail`, tightened test |
| L21 | Randomly timed kills silently miss the window: 13 of 14 "kills" landed after the process had finished. Use deterministic self-kill at an exact internal step | S9 first run | `uat/s4_s7_s8_s9.py` |
| L22 | A multi-step mutation needs a write-ahead journal: record the intent BEFORE the change, resume the journal across runs, finalise at the end | S9 design review | `apply_patch.py` |
| L23 | Content leaks through metadata: answer file names (a slug of the question), seal reasons and lesson files all carried confidential text into shared files | S7 design review | brain.py, tests |
| L24 | Fuzzing finds classes, not instances: wrong-typed field values (unhashable lists, missing keys) crashed 7 places. Fix at the boundary (`_hs`, `_s`, typed view) | 96,600-run campaign | akos_graph.py |
| L25 | Report performance as measured: recall 6.75s -> 1.3-1.7s cold at 100k nodes. The plan's 1.5s target was missed on the worst query; recorded, not hidden | S10 | `PRODUCTION_PLAN.md` |
| L26 | Test expectations can be wrong: a synonym match correctly ranks below direct matches, and recall echoes the caller's question. Diagnose before "fixing" either side | S1, S7 | uat scripts |

