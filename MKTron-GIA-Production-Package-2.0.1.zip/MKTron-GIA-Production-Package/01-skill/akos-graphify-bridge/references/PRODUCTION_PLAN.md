# Production hardening plan: akos-graphify-bridge 1.2.0 -> 2.0.0

Baseline frozen at `baseline-v1.2.0/` (code + `CAPABILITY_SURFACE.json`: 20 subcommands, 70 flags) and recorded as a
**golden master of 43 scenarios**, shown deterministic and able to catch injected regressions.

## 1. Issue register (every row was reproduced by a probe; none is assumed)

| ID | Sev | Area | Evidence (probe) | Root cause | Fix (layer) | Proven by |
|---|---|---|---|---|---|---|
| I-01 | **Critical** | Integrity | P1: 12 concurrent `remember` -> 6 index entries, 12 files | read-modify-write with no lock | per-shelf exclusive lock (L0 lock, L2) | 12-32 process race test |
| I-02 | High | Integrity | P16: corrupt `memory_index.json` crashes `remember`, orphan answer file; P6: same-second same-question overwrites | no pre-validation, no rebuild, name collision | validate-before-write, quarantine + rebuild from files, collision wait (L2) | corruption + collision tests |
| I-03 | High | Isolation | P2: one shelf's error aborts indexing of all | exceptions not isolated per shelf | per-shelf try/except, status ERROR, continue, exit 1 (L2) | poisoned-shelf test |
| I-04 | High | Crash safety | P8: crash between delete and copy leaves the live skill folder **missing** | rmtree then copytree | stage, then rename-swap with rollback (L3) | fault-injection test |
| I-05 | High | Atomicity | P22: injected failure on 3rd write leaves 2 of 3 entity lists changed | sequential writes | stage all, replace, roll back on failure (L0/L3) | fault-injection test |
| I-06 | Med | Patch | P28: backup dir inside the skills folder accepted; no per-op failure isolation; no rollback command | none | refuse; per-op FAILED + continue + exit 1; `--rollback`; apply lock (L3) | patch tests |
| I-07 | High | Security | P4: `lock_down` chmods a file **outside** the library via symlink | `os.chmod` follows links | never follow/touch symlinks; `guard` flags them; path containment (L0) | symlink tests |
| I-08 | Med | Security | P15b: ESC bytes in an id echoed raw to the terminal; P14: control chars crash the Excel export | no output sanitising | `display()` for all CLI text; XML-illegal stripping for xlsx (L0, L1, L2) | hostile-character tests |
| I-09 | High | Robustness | P3, P20: 24 raw tracebacks on malformed KG/graph shapes | no structural validation, no uniform handler | `schema.py` + `run_cli` (exit 2 clear message; exit 3 + `GIA_DEBUG`) (L0, L1) | fuzz: 0 tracebacks |
| I-10 | Med | Robustness | P10: BOM rejected; duplicate keys silently drop data; NaN accepted; deep nesting RecursionError | plain `json.load` | strict loader (L0) | file-edge tests |
| I-11 | Low | Validation | P9: `--limit -1` returns 0 | no bounds | bounded int arg (L2) | CLI tests |
| I-12 | High | Correctness | P5: default "today" is the UTC date; wrong for IST between 00:00-05:30 | `datetime.now(utc)` | local date; `GIA_TODAY` / `--today` override (L0) | TZ matrix test |
| I-13 | Med | Performance | P7: recall 6.75s at 100k nodes; profile: repeated tokenising inside scoring loop (quadratic) | bug in my scoring loop | hoist; token cache; ASCII fast path (L0, L2) | perf budget tests |
| I-14 | High | Governance | P18: out-of-band edit of a confirmed fact is undetectable | no audit trail | hash-chained audit log + `seal` / `verify` / `changes` (L2) | tamper tests |
| I-15 | Med | Evolution | no schema version on KG / library | none | `schema_version`, forward-compat refusal (L0, L2) | version tests |
| I-16 | Med | Operability | implicit dependencies, no self-check | none | `doctor`, `requirements.txt` (L2) | doctor tests |
| I-17 | Med | Release | no package integrity or release gate | none | `MANIFEST.sha256` + `release_gate.py` (L4) | gate run |

## 2. Design principles
1. **Additive only.** No capability, flag, output key or exit code that exists in 1.2.0 may change meaning. Proven by the golden master (old must be a deep subset of new) and a capability-surface check.
2. **Fail closed.** Unreadable date = not fresh; unreadable shelf = confidential; unknown = refuse.
3. **One writer at a time, one file at a time, atomically.** Locks protect read-modify-write; writes are temp + fsync + rename.
4. **Never follow a link, never trust a name.** All paths are contained in the library; symlinks are not traversed or modified.
5. **Output is data, not markup.** Everything shown to a terminal, HTML or Excel is sanitised for that sink.
6. **Exit codes are a contract.** 0 ok · 1 findings that need action · 2 bad input or refused · 3 internal error. No raw tracebacks unless `GIA_DEBUG=1`.
7. **Honest limits.** Where a guarantee has a boundary (e.g. SIGKILL between two renames), the boundary is documented and recoverable.

## 3. Layered architecture (bottom-up)

```
L4  Release        VERSION · MANIFEST.sha256 · release_gate.py · requirements.txt · docs
L3  Interfaces     CLIs (akos_graph, brain, interop_check, register_entity) · apply_patch · plugin commands
L2  Services       brain (locks, audit, index, recall, remember, seal/verify/changes, doctor) · report · interop
L1  Core model     akos_graph (convert, validate, merge, deliverable) · schema-checked loading
L0  Foundation     errors · fsutil (atomic, lock, contain, swap) · strictjson · textsafe · textnorm
```
Rule: a layer may import only from layers below it. Each layer is tested alone before the next is built, and a layer's tests must
stay green for every later layer.

## 4. Test boundaries

| Boundary | Scope | Technique | Gate |
|---|---|---|---|
| Unit | one function | table + property tests | each layer, before moving up |
| Contract | between layers | the lower layer's public API pinned by tests | no later change may break them |
| Compatibility | v1.2.0 behaviour | golden master (43 scenarios) + capability-surface diff | zero regressions |
| Robustness | malformed input | structural fuzz, file-edge cases, hostile characters | zero tracebacks, exit codes only 0/1/2 |
| Concurrency | races | N-process writers vs readers vs indexers | zero lost updates, zero corrupt files |
| Crash | partial failure | fault injection at every write step | library always loadable; recoverable |
| Security | containment | symlinks, traversal, injection (HTML, Excel, terminal) | nothing outside the library touched |
| Integrity | tampering | audit chain, seals, out-of-band edits | detected 100% |
| Performance | scale | 100k nodes / 300k edges budgets | recall < 1.5s, validate < 10s, index < 60s |
| UAT | realistic and hostile scenarios | multi-entity library, fraud isolation, long lifecycle, real-catalog patch | all pass |
| Regression | the wider estate | real-catalog patch (drift 1/6, interop 3 warnings), graphify upstream suite | unchanged |

## 5. Build order and acceptance criteria
1. **L0** errors, strictjson, textsafe, fsutil, textnorm perf, schema. *Accept:* unit + property tests; 32-process lock race; link and containment tests.
2. **L1** akos_graph on L0. *Accept:* golden master clean; fuzz = 0 tracebacks; sanitised output; xlsx hostile chars.
3. **L2** brain (locks, audit, crash-safe index, remember hardening, seal/verify/changes, doctor, local date, recall perf), report, interop. *Accept:* concurrency, crash, tamper, isolation, perf tests; golden master clean.
4. **L3** apply_patch (atomic swap, rollback, isolation), register_entity (all-or-nothing), plugin commands. *Accept:* fault injection; real-catalog run.
5. **L4** manifest, release gate, docs, package. *Accept:* gate green from a cold unzip.
6. **UAT stress**: complex scenarios (section 6) on the final package.

## 6. UAT stress scenarios
S1 group library (12 shelves, 5 entities, mixed scripts, 2 confidential, 40k+ nodes) · S2 concurrent writers/readers/indexers ·
S3 crash injection at every step of index and patch · S4 hostile input corpus · S5 tamper detection · S6 timezone matrix ·
S7 fraud isolation: every exit path attempted · S8 200-cycle lifecycle soak · S9 real-catalog patch + interruption + rollback ·
S10 scale 100k nodes.


## 7. Results (filled in after the build)

All 17 planned items (I-01..I-17) were fixed and proven, and 7 more were found while building and testing (I-18..I-24); see `UAT-report-v4.md`
section 2. Build order was followed: L0 70 tests (6 repeats, mutation-checked), L1 fuzz of 108,872 runs, L2 69 tests including races and
crash safety, L3 tools and patch, then L4 release gate and UAT S1-S9. Two original acceptance targets were not fully met and are stated openly:
recall at 100k nodes is 1.3-1.7s cold (target 1.5s); the persisted-index design that would go lower was deferred.
