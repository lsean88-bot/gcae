# Proposed additions to AKOS `plugin-coordination-registry.md`

**Not applied.** AKOS Module 11 and iron-rules-governance say governance text changes need the owner's
approval. Review, then paste into the registry yourself (or ask Claude to apply it).

## 1. New entry: Visual / Dashboard Layer (§3)

**`akos-graphify-bridge`**
- *Reads:* `KNOWLEDGE_GRAPH.json`; graphify `graph.json`; optional entity-map.
- *Produces:* graphify graph + HTML view; staged KG (PROPOSED items); validation report; deliverable-safe subset; interop report.
- *Writes back:* proposed KG nodes/edges only; Outstanding Questions (unclassified); Decisions Register candidates (conflicts).
- *Typically followed by:* `akos-enterprise-orchestrator` (confirm), domain skill (classify), `cae-report-conversion` / `board-chairman-briefing` (publish deliverable subset only).
- *Coordination note:* never confirms facts or assigns ratings. graphify confidence is not evidence rank (Iron Rule 17).

## 2. Conflict-resolution row (§4)

| Task | Owner | Why |
|---|---|---|
| "Visualise / query / cluster the knowledge graph" | `akos-graphify-bridge` | analysis engine; AKOS still owns the graph |
| "Is the KG ready for the Board?" | `akos-enterprise-orchestrator` Module 9 gate, executed via `akos_graph.py validate --gate final` | one gate, one definition |

## 3. Registry gaps found by `interop_check.py` (installed audit skills the registry never names)

`cae-audit-cowork-plugin-v5`, `cae-cowork-ai-plugin`, `charlie-hills-code`, `debugger`,
`group-cae-core`, `group-cae-external-reporting`, `group-cae-fraud-v2`, `managing-internal-audit`,
`master-audit-superagent`, `mktron-gia-data-reconciliation`, `racm-ecosystem`.
(The registry still describes `cae-audit-cowork-plugin-v4` and `group-cae-fraud`.) Decide for each:
register with a handoff contract, or mark as intentionally out of scope.

## 4. Duplicate-install drift to resolve

- `akos-enterprise-orchestrator`: `user/` is v2.2 (has `constructive-communication-lexicon.md`); the installed plugin copy is v2.1 and lacks it.
- `pune-india-ops-audit`: `plugins/pune-india-ops-audit` is v1.0; `plugins/mktron-pune-vda-compliance:pune-india-ops-audit` is v1.1.
- `file-reading`: `public/` and `plugins/` copies differ.
