# Production UAT report: akos-graphify-bridge 2.0.0 + library brain + plugin 2.0.0 + ecosystem patch 2.0

Run on Ubuntu 24 / Python 3.12 against graphify-8, with the real CLIs. Evidence grade: **Rank 1** (tool output captured this session).
Scripts: `uat/` · raw results: `uat/results/*.json` · one-command re-proof: `python3 tools/release_gate.py`.

## 1. Result

| Gate | Result |
|---|---|
| Tests: skill (bridge, brain, audit, report, interop, L0-L3) | **340** (339 + the 100k perf test) |
| Tests: plugin command executability | **38** |
| Tests: patch tooling, edits, hardening, rollback, real-catalog | **53** (+1 permission test that cannot run as root) |
| graphify upstream suite (unchanged) | 4,930 passed |
| Golden master recorded from v1.2.0 | **43 scenarios, 0 regressions** |
| Capability surface (every v1.2.0 subcommand and flag) | **70 flag names across 20 commands, all present** |
| Mutation checks (guarantee deliberately broken, test must fail) | L0 5/5 · L2 8/8 · v1.2 features 5/5 |
| Fuzz campaigns (type-mutated Knowledge Graphs through every command) | **108,872 command runs, 0 failures** (exit codes only 0/1/2; no traceback; no control character reaches the terminal) |
| UAT scenarios | **S1 26/26 · S2 14/14 · S3 5/5 · S4 7/7 · S5 15/15 · S7 7/7 · S8 6/6 · S9 28/28 = 108/108** |

## 2. Defects found by attacking the code, and what was done (full register: `docs/PRODUCTION_PLAN.md`)

| ID | Sev | Defect (reproduced first) | Resolution | Proven by |
|---|---|---|---|---|
| I-01 | Critical | 12 concurrent `remember` kept 6 index entries (lost updates) | per-shelf and library locks | 24-process race: 24/24; shelf-add 16/16; S2 |
| I-02 | High | corrupt memory index crashed `remember`; same-second overwrite | quarantine + rebuild; adopt orphans; wait for next second | corruption matrix, S3 |
| I-03 | High | one bad shelf blocked all indexing, then the global graph | per-shelf isolation; failed and colliding shelves excluded | 5 poison types |
| I-04 | High | patch crash left the live skill folder missing | staged install + rename swap + rollback | fault injection; S9 |
| I-05 | High | entity registration changed 2 of 3 lists on failure | all-or-nothing replace | fault injection at each file |
| I-06 | Med | backup folder inside the catalog; no rollback | refused; journal; `--rollback` | S9: 13/13 kills, rollback byte-identical |
| I-07 | High | symlink made `chmod` change a file outside the library | links never followed; refused; `guard` flags | symlink tests |
| I-08 | Med | ESC bytes echoed to the terminal; control characters crashed the Excel export | sanitise per sink | S4, hostile-character tests |
| I-09 | High | 24 raw tracebacks on malformed input | structural checks + uniform error handler | 108,872-run fuzz |
| I-10 | Med | BOM rejected; duplicate keys silently dropped data; NaN accepted | strict loader | file-edge tests |
| I-11 | Low | `--limit -1` | bounded arguments | CLI tests |
| I-12 | High | default "today" was the UTC date (wrong in IST 00:00-05:30) | local date; `GIA_TODAY` override | 6-time-zone test |
| I-13 | Med | recall 6.75s at 100k nodes (quadratic bug in my scoring loop) | hoisted; pre-checks; top-N only | see section 4 |
| I-14 | High | edit of a confirmed fact undetectable | hash-chained audit log, seals, `changes`, `verify --anchor` | S5: 14 attacks, 14 detected |
| I-15..17 | Med | no schema version, no self-check, no release gate | `schema_version`, `doctor`, `release_gate.py` | tests, gate |
| I-18 | High | confidential lesson text written to the shared lessons file | kept inside the shelf, owner-only | S7 |
| I-19 | High | confidential question text leaked through audit-log file names and seal reasons | withheld; real values stay in the shelf | S2.13, S7 |
| I-20 | High | a crash tearing the audit log's last line became a permanent chain error | torn bytes kept aside, log repaired | tightened test, S3 |
| I-21 | Med | `reflect`/`guard` promised to repair orphan answers; nothing did | adopt orphans on next write | test |
| I-22 | High | killed-then-re-run patch lost the journal: operations could not be rolled back | write-ahead intent, resumable journal | S9 |
| I-23 | Med | common words drowned rare or synonym matches in a large library | opt-in `--ranking idf` (default unchanged) | S1.5 |
| I-24 | Low | empty library path reached `Path(None)`: exit 3 | clear exit-2 message | random-argument fuzz |

## 3. Intentional behaviour changes (everything else is additive, proven by the golden master)

1. `index` exits **1** if any shelf fails (it was 0). 2. Confidential lessons are **not** in the shared `PROPOSED_LESSONS.md`.
3. JSON with duplicate keys or NaN is **rejected** (it silently lost data). 4. Default "today" is the **local** date.
5. `--limit` is bounded 1-1000 and `--review-days` is at least 1. 6. Malformed input exits **2** with one line (it was a traceback).
7. New files: `audit.log`, `shelves/<s>/.seals/`, `.lock` files, `schema_version` in new Knowledge Graphs. Old libraries open unchanged.

## 4. Performance, as measured (not as hoped)

| Operation | v1.2.0 | v2.0.0 |
|---|---|---|
| recall, 100k nodes / 300k edges | 6.75s (in-process) | **1.3-1.7s end to end, cold process** |
| tokenise 100k labels | 0.83s | 0.12s |
| validate, 100k nodes | 1.9s | 2.2s (adds structural and type checks) |
| index, 13 shelves, 39k nodes | not measured | well inside the 60s budget (S1.2) |

The plan's target of 1.5s was **missed on the worst query (1.70s)**. The floor is parsing a 64 MB file. A persisted index would go lower; it is a larger design, listed below.

## 5. What this does NOT guarantee (read before relying on it)

- **Locks are advisory**: they protect against cooperating runs of these tools, not against another program editing files directly.
- **The audit trail proves internal consistency.** A log truncated at the end or rewritten from the start is caught **only if you recorded an anchor** (`seal` prints the head hash; pass it to `verify --anchor`).
- **Not tested here:** Windows (the lock code path exists but was not run), network file shares, real graphify extraction quality on your documents, and Claude's judgement when using the skill (13 behavioural evals written, none run: no subagents available).
- One permission-based test is skipped when run as root. The failure isolation it covers is proven separately by fault injection.
- Retrieval is **lexical** (accent- and script-aware, with editable synonyms and optional IDF), not semantic.
- **Open owner decisions D2, D3, D4, D6, D8, D10, D15** are unchanged: `docs/DECISIONS_PENDING.md`.

## 6. Recommended next enhancements (not built)
1. Persisted recall index (inverted index keyed by the Knowledge Graph hash) to bring 100k-node queries under 1s. 2. Semantic retrieval behind the same trust labels.
3. A Windows run of the whole gate. 4. Run the 13 behavioural evals once subagents are available. 5. A scheduled `release_gate --fast` plus `verify --anchor` in your own CI.
