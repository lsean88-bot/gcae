"""errors.py - the exit-code contract and one uniform CLI wrapper (layer L0).

Exit codes (a contract, never changed silently):
  0  success
  1  the tool ran and found things that need action (validation errors, guard findings, stale items)
  2  bad input, refused operation, lock timeout, or an I/O problem: the user can fix it
  3  internal error (a bug): a one-line message; set GIA_DEBUG=1 for the traceback
"""
from __future__ import annotations

import json
import os
import sys


class GiaError(Exception):
    """Expected, user-fixable problem. exit code 2."""
    exit_code = 2


class InputError(GiaError, ValueError):
    """The input is malformed or the wrong shape. (Also a ValueError: v1.x callers caught ValueError.)"""


class RefusedError(GiaError, PermissionError):
    """The operation is deliberately refused. (Also a PermissionError: v1.x callers caught PermissionError.)"""


class DependencyError(GiaError):
    """A required optional dependency (graphify) is not installed. Exit 2 with what to install, never an internal error."""


class LockTimeout(GiaError):
    """Another process holds the lock for too long."""


def _display(value) -> str:
    try:
        import textsafe
        return textsafe.display(value, 600)
    except Exception:  # never let reporting an error raise another
        return repr(str(value))[:600]


def run_cli(main, argv=None) -> int:
    """Run main(argv) and translate every outcome into the exit-code contract. No raw tracebacks by default."""
    debug = bool(os.environ.get("GIA_DEBUG"))
    try:
        return int(main(argv) or 0)
    except GiaError as exc:
        print(f"error: {_display(exc)}", file=sys.stderr)
        return exc.exit_code
    except KeyboardInterrupt:
        print("interrupted", file=sys.stderr)
        return 130
    except BrokenPipeError:
        try:
            sys.stdout.close()
        except Exception:
            pass
        return 0
    except (FileNotFoundError, PermissionError, IsADirectoryError, NotADirectoryError, json.JSONDecodeError,
            UnicodeDecodeError, ValueError, OSError) as exc:
        if debug:
            raise
        print(f"error: {_display(type(exc).__name__ + ': ' + str(exc))}", file=sys.stderr)
        return 2
    except Exception as exc:  # a bug
        if debug:
            raise
        print(f"internal error: {_display(type(exc).__name__ + ': ' + str(exc))} "
              f"(re-run with GIA_DEBUG=1 for the traceback)", file=sys.stderr)
        return 3
