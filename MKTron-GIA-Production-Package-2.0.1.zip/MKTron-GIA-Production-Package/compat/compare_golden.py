#!/usr/bin/env python3
"""old must be a deep SUBSET of new: nothing removed, nothing changed. Additive fields are allowed.
Intentional behaviour changes must be listed in an ALLOWED file ({scenario: reason})."""
import json, sys
old, new = json.load(open(sys.argv[1])), json.load(open(sys.argv[2]))
allowed = json.load(open(sys.argv[3])) if len(sys.argv) > 3 else {}
import re
# Two NAMED, justified exceptions only: the release version string, and a calendar date that moves with the clock.
IGNORE_KEYS = {"bridge_version", "last_updated"}
IGNORE_PATHS = {"brain_init/json/version"}      # the manifest's release stamp, at exactly this path
def _line(x):
    return re.sub(r'("bridge_version": ")[^"]*', r"\1<VER>", x) if isinstance(x, str) and "bridge_version" in x else x
bad = []
def sub(o, n, path):
    if isinstance(o, dict):
        if not isinstance(n, dict): bad.append((path, "type", o, n)); return
        for k, v in o.items():
            if k in IGNORE_KEYS or (path + "/" + k) in IGNORE_PATHS: continue
            if k not in n: bad.append((path + "/" + k, "REMOVED", v, None))
            else: sub(v, n[k], path + "/" + k)
    elif isinstance(o, list):
        if not isinstance(n, list): bad.append((path, "type", o, n)); return
        if o and all(isinstance(x, dict) for x in o) and len(n) >= len(o):
            for i, x in enumerate(o): sub(x, n[i], f"{path}[{i}]")
        elif [_line(x) for x in o] != [_line(x) for x in n] and not (all(not isinstance(x, (dict, list)) for x in o) and all(_line(x) in [_line(y) for y in n] for x in o)):
            bad.append((path, "CHANGED", o, n))
    elif o != n: bad.append((path, "CHANGED", o, n))
for scen in old:
    if scen not in new: bad.append((scen, "SCENARIO MISSING", None, None)); continue
    sub(old[scen], new[scen], scen)
real = [b for b in bad if b[0].split("/")[0] not in allowed]
for p, kind, o, n in real: print(f"REGRESSION {kind}: {p}\n   old={str(o)[:110]}\n   new={str(n)[:110]}")
print(f"{len(old)} scenarios compared; regressions: {len(real)}; allowed intentional changes: {len(bad)-len(real)}")
sys.exit(1 if real else 0)
