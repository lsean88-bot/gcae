#!/usr/bin/env python3
"""Golden-master recorder. Runs a fixed battery of CLI scenarios against a code tree and records exit codes and
(normalised) outputs. Compare two recordings with compare_golden.py: every old value must still be present in the new
one (additive changes allowed, removals/changes are regressions)."""
import json, os, re, shutil, subprocess, sys, tempfile
from pathlib import Path

code = Path(sys.argv[1]).resolve() / "scripts"
out_file = Path(sys.argv[2])
FIX = json.loads((Path(sys.argv[1]).resolve() / "tests/fixtures/cld_kg.json").read_text())
ENV = {k: v for k, v in os.environ.items() if not k.endswith("_API_KEY")}
ENV["TZ"] = "UTC"
TODAY = "2026-10-03"
tmp = Path(tempfile.mkdtemp())


def norm(text):
    text = str(text).replace(str(tmp), "<TMP>")
    text = re.sub(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}[+-]\d{2}:\d{2}", "<TS>", text)
    text = re.sub(r"query_\d{8}_\d{6}", "query_<STAMP>", text)
    text = re.sub(r"\d{8}_\d{6}", "<STAMP>", text)
    return text


def scrub(o):
    if isinstance(o, dict):
        return {k: scrub(v) for k, v in o.items() if k not in ("built_at", "created", "date", "generated", "last_updated_ts")}
    if isinstance(o, list):
        return [scrub(x) for x in o]
    return norm(o) if isinstance(o, str) else o


def run(script, *args):
    r = subprocess.run([sys.executable, str(code / script), *map(str, args)], capture_output=True, text=True, env=ENV)
    rec = {"exit": r.returncode}
    try:
        rec["json"] = scrub(json.loads(r.stdout))
    except Exception:
        rec["text"] = [norm(l) for l in r.stdout.splitlines() if l.strip()][:60]
    if r.returncode not in (0, 1) and r.stderr:
        rec["stderr_last"] = norm(r.stderr.strip().splitlines()[-1])[:140]
    return rec


G = {}
kgf = tmp / "kg.json"; kgf.write_text(json.dumps(FIX))
G["validate_draft"] = run("akos_graph.py", "validate", kgf, "--json")
G["validate_final"] = run("akos_graph.py", "validate", kgf, "--gate", "final", "--json")
G["stats"] = run("akos_graph.py", "stats", kgf)
G["to_graphify"] = run("akos_graph.py", "to-graphify", kgf, "--out", tmp / "o", "--no-html")
G["deliverable"] = run("akos_graph.py", "deliverable", kgf, "--out", tmp / "d.json")
G["deliverable_med"] = run("akos_graph.py", "deliverable", kgf, "--out", tmp / "d2.json", "--include-medium")
native = {"nodes": [{"id": "a_policy", "label": "Policy doc", "file_type": "document", "source_file": "corpus/MKAPL-DC/policy.md"},
                    {"id": "b_concept", "label": "Some concept", "file_type": "concept", "source_file": "corpus/x.md"},
                    {"id": "c_code", "label": "duplicates()", "file_type": "code", "source_file": "corpus/p.py"},
                    {"id": "mem_q", "label": "query_x", "file_type": "document", "source_file": "/p/graphify-out/memory/query_20261003_120000_x.md"}],
          "links": [{"source": "a_policy", "target": "b_concept", "relation": "semantically_similar_to", "confidence": "INFERRED", "confidence_score": 0.65, "source_file": "corpus/x.md"},
                    {"source": "c_code", "target": "a_policy", "relation": "references", "confidence": "EXTRACTED", "confidence_score": 1.0, "source_file": "corpus/p.py", "source_location": "L4"},
                    {"source": "mem_q", "target": "a_policy", "relation": "references", "confidence": "EXTRACTED", "confidence_score": 1.0, "source_file": "/p/graphify-out/memory/query_20261003_120000_x.md"}]}
(tmp / "emap.json").write_text(json.dumps({"MKAPL-DC": ["MKAPL-DC"]})); (tmp / "native.json").write_text(json.dumps(native))
G["from_graphify_native"] = run("akos_graph.py", "from-graphify", tmp / "native.json", "--out", tmp / "staged.json", "--entity-map", tmp / "emap.json", "--today", TODAY)
G["validate_staged_final"] = run("akos_graph.py", "validate", tmp / "staged.json", "--gate", "final", "--json")
G["from_graphify_roundtrip"] = run("akos_graph.py", "from-graphify", tmp / "o/graphify-out/graph.json", "--kg", kgf, "--out", tmp / "rt.json")
conf = dict(FIX); conf["engagement"] = "INV"; conf["confidential"] = True; (tmp / "conf.json").write_text(json.dumps(conf))
G["merge_refused"] = run("akos_graph.py", "merge", kgf, tmp / "conf.json", "--out", tmp / "m.json")
G["export_xlsx"] = run("akos_graph.py", "export-xlsx", kgf, "--out", tmp / "k.xlsx", "--gate", "final")
G["export_xlsx_sheets"] = {"sheets": __import__("openpyxl").load_workbook(tmp / "k.xlsx").sheetnames}

n_ = lambda i, t, l, c="100%", e="Group", **k: {"id": i, "type": t, "label": l, "entity": e, "created_date": "2026-10-01", "confidence": c, "source_location": "https://portal.example/x", **k}
ed = lambda a, b, c="High": {"from": a, "to": b, "relationship": "relates_to", "evidence": "ev", "confidence": c}
L = tmp / "lib"
G["brain_init"] = run("brain.py", "init", L)
G["shelf_eng"] = run("brain.py", "shelf-add", L, "mkapl-dc-clrw", "--kind", "engagement", "--entity", "MKAPL-DC")
G["shelf_stat"] = run("brain.py", "shelf-add", L, "tn-statutory", "--kind", "statutory", "--entity", "Group", "--review-days", "90")
G["shelf_inv"] = run("brain.py", "shelf-add", L, "inv-01", "--kind", "investigation", "--entity", "MKSDL")
G["shelf_bad_entity"] = run("brain.py", "shelf-add", L, "x1", "--kind", "policy", "--entity", "NOPE")
G["shelf_bad_name"] = run("brain.py", "shelf-add", L, "BAD NAME", "--kind", "policy", "--entity", "Group")
shutil.copy(tmp / "kg.json", L / "shelves/mkapl-dc-clrw/KNOWLEDGE_GRAPH.json")
(L / "shelves/tn-statutory/KNOWLEDGE_GRAPH.json").write_text(json.dumps({"engagement": "tn-statutory", "confidential": False, "last_updated": "2026-10-01", "nodes": [
    n_("REG-TN-MW", "Regulation", "Tamil Nadu minimum wages notification", evidence_rank="R1", review_by="2026-04-01"),
    n_("REG-TN-PT", "Regulation", "Tamil Nadu professional tax slab", evidence_rank="R2", review_by="2027-04-01"),
    n_("REG-TN-X", "Regulation", "Provident fund rule note", evidence_rank="R4", review_by="April 2026"),
    n_("MX-01", "Process", "Nómina de contratistas", evidence_rank="R5")], "edges": [ed("REG-TN-MW", "REG-TN-PT"), ed("REG-TN-PT", "REG-TN-X"), ed("REG-TN-X", "MX-01")]}, ensure_ascii=False))
(L / "shelves/inv-01/KNOWLEDGE_GRAPH.json").write_text(json.dumps({"engagement": "inv-01", "confidential": True, "last_updated": "2026-10-01", "nodes": [
    n_("ALG-1", "Issue", "Alleged kickback by vendor ACME", "Medium", "MKSDL", status="ALLEGED"), n_("V-1", "Vendor", "ACME Tooling", "High", "MKSDL")], "edges": [ed("ALG-1", "V-1", "Medium")]}))
G["index"] = run("brain.py", "index", L)
for i, q in enumerate(["written service agreement control", "Tamil Nadu minimum wage", "nomina contratistas", "payroll process",
                       "provident fund", "tooling kickback vendor"]):
    G[f"recall_{i}"] = run("brain.py", "recall", L, q, "--today", TODAY)
G["recall_max_rank"] = run("brain.py", "recall", L, "wage", "--today", TODAY, "--max-rank", "R3")
G["recall_min_conf"] = run("brain.py", "recall", L, "wage", "--today", TODAY, "--min-confidence", "High")
G["recall_inv_alone"] = run("brain.py", "recall", L, "kickback", "--shelf", "inv-01", "--today", TODAY)
G["recall_conf_combined"] = run("brain.py", "recall", L, "x", "--shelf", "inv-01", "--shelf", "tn-statutory")
G["stale"] = run("brain.py", "stale", L, "--today", TODAY)
G["stale_strict"] = run("brain.py", "stale", L, "--today", TODAY, "--strict")
G["remember1"] = run("brain.py", "remember", L, "--shelf", "mkapl-dc-clrw", "--question", "Which control covers service agreements?", "--answer", "CTRL-CLD-01", "--outcome", "useful", "--nodes", "CTRL-CLD-01")
G["remember2"] = run("brain.py", "remember", L, "--shelf", "mkapl-dc-clrw", "--question", "Is CLRA licence needed for all contractors?", "--answer", "Yes", "--outcome", "corrected", "--correction", "Only above the notified threshold")
G["remember_bad"] = run("brain.py", "remember", L, "--shelf", "mkapl-dc-clrw", "--question", "q?", "--answer", "a", "--outcome", "corrected")
G["reflect"] = run("brain.py", "reflect", L)
G["status"] = run("brain.py", "status", L, "--today", TODAY)
G["guard"] = run("brain.py", "guard", L)
G["mcp_config"] = run("brain.py", "mcp-config", L)
G["dashboard"] = run("brain.py", "dashboard", L, "--out", tmp / "rep", "--today", TODAY)
wb = __import__("openpyxl").load_workbook(tmp / "rep/brain-dashboard.xlsx")
G["dashboard_sheets"] = {"sheets": wb.sheetnames, "shelves_total_formula": wb["Shelves"].cell(row=wb["Shelves"].max_row, column=5).value}
html = (tmp / "rep/brain-dashboard.html").read_text(encoding="utf-8")
G["dashboard_html"] = {"has_confidential_label": "ACME" in html, "has_title": "Library brain" in html, "shelf_count_cards": html.count("class='card'")}
G["interop_synthetic"] = {}
reg_dir = tmp / "cat/user/akos/references"; reg_dir.mkdir(parents=True)
(tmp / "cat/user/akos/SKILL.md").write_text("---\nname: akos\ndescription: d\n---\n"); (reg_dir / "plugin-coordination-registry.md").write_text("Uses `alpha-skill`, `ghost-skill`.\n")
(tmp / "cat/plugins/alpha-skill").mkdir(parents=True); (tmp / "cat/plugins/alpha-skill/SKILL.md").write_text("---\nname: alpha-skill\ndescription: d\n---\n")
G["interop_synthetic"] = run("interop_check.py", "--roots", tmp / "cat/user", tmp / "cat/plugins", "--json")
G["register_dry"] = {}
akos = tmp / "akos"; (akos / "references").mkdir(parents=True)
(akos / "references/knowledge-graph-schema.md").write_text('{ "entity": "string (AAA|BBB|Group)" }\n')
(akos / "references/taxonomy-and-metadata-standards.md").write_text("## 1. Entity Code Standard\n\nnine entities\n\n| Code | Entity | Country | Sector |\n|---|---|---|---|\n| AAA | a | b | c |\n\n## 2. x\n")
(tmp / "ent.json").write_text(json.dumps({"entities": ["AAA", "BBB", "Group"]}))
G["register_dry"] = run("register_entity.py", "--akos-dir", akos, "--config", tmp / "ent.json", "--code", "CCC", "--name", "n", "--country", "c", "--sector", "s")
out_file.write_text(json.dumps(G, indent=1, ensure_ascii=False, sort_keys=True))
print(f"recorded {len(G)} scenarios -> {out_file}")
