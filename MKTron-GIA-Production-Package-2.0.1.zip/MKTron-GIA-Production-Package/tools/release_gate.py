#!/usr/bin/env python3
"""release_gate.py - one command that re-proves this package is intact, compatible and working.

Run from anywhere:  python3 tools/release_gate.py [--fast]
  1 MANIFEST     every shipped file matches MANIFEST.sha256; nothing missing, nothing extra
  2 COMPILE      every .py compiles
  3 SKILL        the skill's frontmatter is valid (name, description <= 1024 characters)
  4 SURFACE      every subcommand and flag that existed in v1.2.0 still exists (compat/CAPABILITY_SURFACE.json)
  5 GOLDEN       the 43-scenario golden master recorded from v1.2.0: nothing removed, nothing changed
  6 TESTS        skill, plugin and patch test suites (--fast skips the 100k-node performance test)
Exit 0 only if every step passes. Writes RELEASE_REPORT.json beside the package.
"""
import argparse, hashlib, json, os, py_compile, re, subprocess, sys, tempfile, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SKILL = ROOT / "01-skill/akos-graphify-bridge"
PLUGIN = ROOT / "02-plugin/akos-graph"
PATCH = ROOT / "03-ecosystem-patch/gia-ecosystem-patch"
SKIP = ("__pycache__", ".pytest_cache", ".pyc", "RELEASE_REPORT.json", "MANIFEST.sha256")
report = {"version": (ROOT / "VERSION").read_text().strip() if (ROOT / "VERSION").exists() else "?", "steps": []}


def step(name, fn):
    t = time.time()
    try:
        ok, detail = fn()
    except Exception as exc:
        ok, detail = False, f"{type(exc).__name__}: {exc}"
    report["steps"].append({"step": name, "ok": bool(ok), "detail": detail, "seconds": round(time.time() - t, 1)})
    print(f"{'PASS' if ok else 'FAIL'}  {name:<9} {detail}   ({time.time() - t:.0f}s)")
    return ok


def files():
    return sorted(p for p in ROOT.rglob("*") if p.is_file() and not any(s in str(p) for s in SKIP))


def manifest():
    mf = ROOT / "MANIFEST.sha256"
    if not mf.exists():
        return False, "MANIFEST.sha256 is missing"
    want = {}
    for line in mf.read_text().splitlines():
        h, _, rel = line.partition("  ")
        want[rel] = h
    have = {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files()}
    missing, extra = sorted(set(want) - set(have)), sorted(set(have) - set(want))
    changed = sorted(r for r in set(want) & set(have) if want[r] != have[r])
    report["manifest_root_sha256"] = hashlib.sha256("".join(f"{r}{want[r]}" for r in sorted(want)).encode()).hexdigest()
    if missing or extra or changed:
        return False, f"missing={missing[:3]} extra={extra[:3]} changed={changed[:3]}"
    return True, f"{len(want)} files verified"


def compile_all():
    n = 0
    for p in files():
        if p.suffix == ".py":
            compile(p.read_bytes(), str(p), "exec"); n += 1             # compiles in memory: writes no .pyc anywhere
    return True, f"{n} Python files compile"


def skill_ok():
    t = (SKILL / "SKILL.md").read_text(encoding="utf-8")
    import yaml
    fm = yaml.safe_load(re.match(r"^---\s*\n(.*?)\n---", t, re.S).group(1))
    d = re.sub(r"\s+", " ", fm["description"]).strip()
    return bool(fm.get("name") == "akos-graphify-bridge" and 0 < len(d) <= 1024), f"description {len(d)}/1024 chars, version {fm['metadata']['version']}"


def surface():
    base = json.loads((ROOT / "compat/CAPABILITY_SURFACE.json").read_text())
    lost = []
    for script, subs in base.items():
        for sub, flags in subs.items():
            r = subprocess.run([sys.executable, str(SKILL / "scripts" / script), *([sub] if sub != "(none)" else []), "--help"], capture_output=True, text=True)
            have = set(re.findall(r"(--[a-z][a-z-]*)", r.stdout))
            if r.returncode != 0:
                lost.append(f"{script} {sub}: subcommand gone"); continue
            lost += [f"{script} {sub} {f}" for f in flags if f not in have]
    return not lost, f"{sum(len(f) for s in base.values() for f in s.values())} v1.2.0 flags across {sum(len(s) for s in base.values())} commands all present" if not lost else f"LOST: {lost[:5]}"


def golden():
    with tempfile.TemporaryDirectory() as d:
        out = Path(d) / "g.json"
        env = {**os.environ, "GIA_NO_FSYNC": "1"}
        r = subprocess.run([sys.executable, str(ROOT / "compat/make_golden.py"), str(SKILL), str(out)], capture_output=True, text=True, env=env)
        if r.returncode:
            return False, r.stderr[-200:]
        c = subprocess.run([sys.executable, str(ROOT / "compat/compare_golden.py"), str(ROOT / "compat/baseline_golden.json"), str(out)], capture_output=True, text=True)
        return c.returncode == 0, c.stdout.strip().splitlines()[-1]


def tests(fast):
    env = {**os.environ, "GIA_NO_FSYNC": "1", **({"GIA_SKIP_PERF": "1"} if fast else {})}
    out = []
    for name, cwd in (("skill", SKILL), ("plugin", PLUGIN), ("patch", PATCH)):
        r = subprocess.run([sys.executable, "-m", "pytest", "tests", "-q", "-p", "no:cacheprovider"], cwd=cwd, capture_output=True, text=True, env=env)
        last = [l for l in r.stdout.splitlines() if "passed" in l or "failed" in l or "error" in l]
        out.append((name, r.returncode == 0, last[-1].strip() if last else r.stderr[-120:]))
    return all(o[1] for o in out), "; ".join(f"{n}: {d}" for n, _, d in out)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0]); ap.add_argument("--fast", action="store_true"); a = ap.parse_args()
    print(f"release gate for MKTron GIA package {report['version']}\n")
    oks = [step("MANIFEST", manifest), step("COMPILE", compile_all), step("SKILL", skill_ok), step("SURFACE", surface), step("GOLDEN", golden), step("TESTS", lambda: tests(a.fast))]
    report["passed"] = all(oks)
    (ROOT / "RELEASE_REPORT.json").write_text(json.dumps(report, indent=2))
    print(f"\n{'RELEASE GATE PASSED' if all(oks) else 'RELEASE GATE FAILED'}")
    sys.exit(0 if all(oks) else 1)
