# MKTron GIA Production Package 2.0.1

Read this first. Everything is in one tree; `python3 tools/release_gate.py` re-proves it from a cold unzip.

| Path | What it is |
|---|---|
| `01-skill/akos-graphify-bridge/` | The skill 2.0.1: AKOS-to-graphify bridge and the library brain (+ `.skill` file one level up) |
| `02-plugin/akos-graph/` | Plugin 2.0.1: twelve slash commands wrapping the skill |
| `03-ecosystem-patch/gia-ecosystem-patch/` | Patch 2.0 for your installed skills: dry run first; `--rollback` undoes it |
| `compat/` | The v1.2.0 golden master (43 scenarios) and capability surface: the evidence that nothing was lost |
| `uat/` | The 9 stress scenarios and their raw results |
| `docs/` | `PRODUCTION_PLAN.md`, `UAT-report-v4.md`, `DECISIONS_PENDING.md`, `library-brain-guide.md`, lessons |
| `tools/release_gate.py` | Manifest, compile, skill, surface, golden master, and all test suites in one command |
| `MANIFEST.sha256`, `VERSION`, `requirements.txt` | Integrity list, version, dependencies |

## Verify (two minutes)
```
pip install -r requirements.txt            # plus: pip install -e <graphify checkout>
python3 tools/release_gate.py --fast       # drop --fast to include the 100k-node performance test
```

## Use
```
python3 01-skill/akos-graphify-bridge/scripts/brain.py doctor <library>     # environment check first
python3 03-ecosystem-patch/gia-ecosystem-patch/apply_patch.py --catalog <skills root>          # DRY RUN
python3 03-ecosystem-patch/gia-ecosystem-patch/apply_patch.py --catalog <skills root> --apply --backup-dir ~/gia-backup
python3 03-ecosystem-patch/gia-ecosystem-patch/apply_patch.py --catalog <skills root> --rollback ~/gia-backup  # undo
```

## Status, stated plainly
431 tests, 108 UAT checks, a 108,872-run fuzz campaign and a 43-scenario compatibility golden master all pass. **Not measured:** Windows,
network shares, real-document extraction quality, and Claude's judgement using the skill (13 behavioural evals written, not run).
The audit trail needs an external anchor to prove truncation or a full rewrite. Open owner decisions: `docs/DECISIONS_PENDING.md`.
