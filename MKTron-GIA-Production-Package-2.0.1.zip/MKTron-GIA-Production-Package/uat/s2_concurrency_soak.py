import json, random, sys, tempfile, time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from uatlib import *
results = []
def check(name, ok, evidence=""):
    results.append((name, bool(ok), evidence)); print(f"{'PASS' if ok else 'FAIL'} | {name} | {evidence}")
L = Path(tempfile.mkdtemp()) / "lib"; build_group_library(L, per_shelf=300, hostile=False)
assert cli("brain.py", "index", L).returncode == 0
out = {"remember": [], "index": [], "recall": [], "seal": [], "shelf-add": [], "dashboard": [], "guard": [], "verify": [], "status": []}
rnd = random.Random(3)
def rem(t):
    for i in range(12):
        out["remember"].append(cli("brain.py", "remember", L, "--shelf", "clrw-dc", "--question", f"S2 shared q{t}-{i}?", "--answer", f"answer {t}-{i}", "--outcome", "useful" if i % 2 else "dead_end").returncode)
def rem_conf(t):
    for i in range(6):
        out["remember"].append(cli("brain.py", "remember", L, "--shelf", "inv-mksdl-tooling", "--question", f"S2 conf q{t}-{i} ACMEKICKBACK?", "--answer", "a", "--outcome", "useful").returncode)
def idx(t):
    for _ in range(3): out["index"].append(cli("brain.py", "index", L).returncode)
def rec(t):
    for q in ["payroll vendor", "Nómina", "minimum wage", "ghost scrap", "EPF", "tooling"] * 2: out["recall"].append(cli("brain.py", "recall", L, q).returncode)
def sealer(t):
    for i in range(4): out["seal"].append(cli("brain.py", "seal", L, "--shelf", "frameworks", "--reason", f"S2 seal {i}").returncode)
def adder(t):
    for i in range(6): out["shelf-add"].append(cli("brain.py", "shelf-add", L, f"s2-new-{i}", "--kind", "reference", "--entity", "Group").returncode)
def dash(t):
    for i in range(2): out["dashboard"].append(cli("brain.py", "dashboard", L, "--out", L.parent / "rep", "--today", "2026-10-03").returncode)
def watch(t):
    for _ in range(6):
        out["guard"].append(cli("brain.py", "guard", L).returncode); out["verify"].append(cli("brain.py", "verify", L).returncode); out["status"].append(cli("brain.py", "status", L).returncode)
jobs = [rem] * 4 + [rem_conf] * 2 + [idx] * 2 + [rec] * 2 + [sealer, adder, dash, watch]
t0 = time.time()
with ThreadPoolExecutor(max_workers=len(jobs)) as ex:
    futs = [ex.submit(j, k) for k, j in enumerate(jobs)]
    for f in futs: f.result()
el = time.time() - t0
print(f"{len(jobs)} concurrent workers, {sum(len(v) for v in out.values())} command runs in {el:.0f}s")
check("S2.1 every remember succeeded (48 shared + 12 confidential)", out["remember"].count(0) == 60, f"{out['remember'].count(0)}/60")
check("S2.2 every seal, shelf-add and recall succeeded", all(c == 0 for k in ("seal", "shelf-add", "recall") for c in out[k]), f"seal={out['seal']} add={out['shelf-add']} recall-bad={[c for c in out['recall'] if c]}")
check("S2.3 index runs exit 0 (no shelf failures) under contention", all(c == 0 for c in out["index"]), f"{out['index']}")
check("S2.4 dashboard, status never crashed", all(c == 0 for c in out["dashboard"] + out["status"]), f"{out['dashboard']} {out['status']}")
check("S2.5 guard and verify never reported an ERROR while writers ran", all(c == 0 for c in out["guard"] + out["verify"]), f"guard={sorted(set(out['guard']))} verify={sorted(set(out['verify']))}")
idx_s = json.loads((L / "shelves/clrw-dc/memory_index.json").read_text()); idx_c = json.loads((L / "shelves/inv-mksdl-tooling/memory_index.json").read_text())
files_s = list((L / "shelves/clrw-dc/graphify-out/memory").glob("query_*.md")); files_c = list((L / "shelves/inv-mksdl-tooling/graphify-out/memory").glob("query_*.md"))
check("S2.6 no lost update: shared shelf has exactly 48 index entries AND 48 files", len(idx_s) == 48 == len(files_s), f"{len(idx_s)} entries / {len(files_s)} files")
check("S2.7 no lost update: confidential shelf has exactly 12 entries AND 12 files", len(idx_c) == 12 == len(files_c), f"{len(idx_c)} / {len(files_c)}")
mf = json.loads((L / "brain.json").read_text())
check("S2.8 no lost shelf-add: 13 + 6 shelves", len(mf["shelves"]) == 19, f"{len(mf['shelves'])}")
entries = [json.loads(l) for l in (L / "audit.log").read_text().splitlines() if l.strip()]
check("S2.9 audit chain is contiguous and valid", [e["seq"] for e in entries] == list(range(1, len(entries) + 1)) and cli("brain.py", "verify", L).returncode == 0, f"{len(entries)} entries")
stray = [str(p.relative_to(L)) for p in L.rglob("*") if p.is_file() and (p.name.endswith(".tmp") or ".staging" in str(p) or ".new-" in p.name)] + [str(p.relative_to(L)) for p in L.rglob("*.old-*")]
check("S2.10 no temp, staging or swap debris left behind", stray == [], f"{stray[:3]}")
bad_json = []
for p in L.rglob("*.json"):
    try: json.loads(p.read_bytes())
    except Exception: bad_json.append(str(p.relative_to(L)))
check("S2.11 every JSON file in the library is valid", bad_json == [], f"{len(list(L.rglob('*.json')))} files; bad={bad_json[:3]}")
g = cli("brain.py", "guard", L); check("S2.12 guard is clean after the storm", g.returncode == 0, g.stdout.strip().splitlines()[-1])
hits = grep_tree(L, SECRETS, skip_dirs=[L / "shelves/inv-mksdl-tooling", L / "shelves/inv-nmsb-billing"])
check("S2.13 no confidential token escaped during the concurrent run", hits == [], f"{hits[:3]}")
check("S2.14 final index rebuild succeeds", cli("brain.py", "index", L).returncode == 0, "")
print(f"\nS2 SUMMARY: {sum(ok for _, ok, _ in results)}/{len(results)} passed")
json.dump([{"name": n, "ok": ok, "evidence": e} for n, ok, e in results], open("/tmp/uat_s2.json", "w"), indent=1)
sys.exit(0 if all(ok for _, ok, _ in results) else 1)
