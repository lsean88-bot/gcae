"""Shared fixtures for the UAT scenarios: a realistic multi-entity library with planted needles and planted secrets."""
import json, os, random, subprocess, sys, time
from pathlib import Path

CODE = Path(os.environ.get("GIA_CODE", str(Path(__file__).resolve().parent.parent / "01-skill/akos-graphify-bridge"))) / "scripts"
ENV = {k: v for k, v in os.environ.items() if not k.endswith("_API_KEY")}
ENV.update({"GIA_NO_FSYNC": "1"})
SECRET_TOOLING, SECRET_BILLING = "SECRET-TOOLING-7731", "SECRET-BILLING-4410"
SECRETS = (SECRET_TOOLING, SECRET_BILLING, "ACMEKICKBACK", "PHANTOMTREATMENT")

SHELVES = [  # name, kind, entity, jurisdiction
    ("tn-statutory", "statutory", "MKAPL-JD", "Tamil Nadu"), ("mh-statutory", "statutory", "MKAPL-ST", "Maharashtra"),
    ("my-statutory", "statutory", "MKPC", "Malaysia"), ("mx-nomina", "statutory", "Group", "Mexico"),
    ("clrw-dc", "engagement", "MKAPL-DC", None), ("payroll-jd", "engagement", "MKAPL-JD", None), ("scrap-st", "engagement", "MKAPL-ST", None),
    ("dialysis-nmsb", "engagement", "NMSB", None), ("sathya-hr", "engagement", "SAPL", None),
    ("group-policies", "policy", "Group", None), ("frameworks", "reference", "Group", None),
    ("inv-mksdl-tooling", "investigation", "MKSDL", None), ("inv-nmsb-billing", "investigation", "NMSB", None)]
NEEDLES = {  # (shelf, id, label, expected query that must find it)
    "tn": ("tn-statutory", "TN-MW-NEEDLE", "Tamil Nadu minimum wages notification skilled worker", "Tamil Nadu minimum wage skilled"),
    "mx": ("mx-nomina", "MX-NOM-NEEDLE", "Nómina de contratistas cuotas IMSS patronales", "nomina contratistas IMSS"),
    "ta": ("tn-statutory", "TA-NEEDLE", "ஊதிய பதிவேடு பராமரிப்பு விதி", "ஊதிய பதிவேடு"),
    "my": ("my-statutory", "MY-EPF-NEEDLE", "Gaji pekerja asing caruman EPF majikan", "gaji pekerja asing EPF"),
    "zh": ("group-policies", "ZH-NEEDLE", "薪资审计程序 供应商 付款", "薪资审计"),
    "syn": ("mx-nomina", "SYN-NEEDLE", "Nómina semanal de planta", "payroll weekly plant")}
WORDS = "payroll scrap EPF GST ghost CLRA vendor tooling minimum wage contract labour dialysis reuse billing tariff overtime bonus gratuity ESIC".split()
HOSTILE = ["<script>alert(1)</script> label", "=HYPERLINK(\"http://evil.example\",\"x\") rate", "evil\x1b[31mred\x1b[0m", "tab\there",
           "bidi \u202egnp.exe", "zero\u200bwidth", "x" * 3000, "quote\"and'apostrophe", "@SUM(A1:A9)", "+cmd|' /C calc'!A0", "NUL\x00inside"]


def n_(i, typ, label, conf="High", ent="Group", **kw):
    return {"id": i, "type": typ, "label": label, "entity": ent, "created_date": "2026-10-01", "confidence": conf,
            "source_location": "https://portal.example/doc", **kw}


def make_kg(shelf, kind, entity, n, rnd, confidential=False, hostile=False):
    prefix = "".join(ch for ch in shelf.upper() if ch.isalnum())[:6]
    nodes = []
    for i in range(n):
        label = f"{rnd.choice(WORDS)} {rnd.choice(WORDS)} {rnd.choice(WORDS)} item {i}"
        if hostile and i % 97 == 0:
            label = rnd.choice(HOSTILE)
        typ = "Regulation" if kind == "statutory" and i % 3 == 0 else rnd.choice(["Risk", "Control", "Document", "Issue", "Process"])
        kw = {"evidence_rank": rnd.choice(["R1", "R2", "R3", "R4", "R5", None])}
        if typ == "Regulation":
            kw["review_by"] = rnd.choice(["2026-04-01", "2027-03-31", "April 2026", None, "2026-12-31"])
        if i % 41 == 0: kw["status"] = "PROPOSED"
        conf = rnd.choice(["100%", "High", "Medium", "Low"] if not confidential else ["Medium", "High"])
        nodes.append(n_(f"{prefix}-{i:05d}", typ, label, conf, entity, **kw))
    edges = [{"from": nodes[i]["id"], "to": nodes[(i * 7 + 3) % n]["id"], "relationship": rnd.choice(["relates_to", "supports", "mitigates", "references"]),
              "evidence": "workpaper", "confidence": "High"} for i in range(n)]
    edges += [{"from": nodes[i]["id"], "to": nodes[min(n - 1, i + 1)]["id"], "relationship": "relates_to", "evidence": "w", "confidence": "Medium"} for i in range(0, n, 2)]
    return {"engagement": shelf, "confidential": confidential, "last_updated": "2026-10-01", "nodes": nodes, "edges": edges}


def cli(script, *a, env=None, timeout=280):
    t = time.time()
    r = subprocess.run([sys.executable, str(CODE / script), *map(str, a)], capture_output=True, text=True, env={**ENV, **(env or {})}, timeout=timeout)
    r.elapsed = time.time() - t
    return r


def build_group_library(L: Path, per_shelf=3000, seed=7, hostile=True):
    rnd = random.Random(seed)
    assert cli("brain.py", "init", L).returncode == 0
    for name, kind, ent, jur in SHELVES:
        a = ["shelf-add", L, name, "--kind", kind, "--entity", ent]
        if kind == "statutory": a += ["--review-days", "90"]
        if jur: a += ["--jurisdiction", jur]
        assert cli("brain.py", *a).returncode == 0, name
    for name, kind, ent, jur in SHELVES:
        conf = kind == "investigation"
        kg = make_kg(name, kind, ent, per_shelf, rnd, conf, hostile=hostile and not conf)
        if conf:
            secret = SECRET_TOOLING if "tooling" in name else SECRET_BILLING
            kg["nodes"][0].update({"id": f"ALG-{secret}", "label": f"Alleged ACMEKICKBACK {secret} by vendor", "status": "ALLEGED", "confidence": "Medium"})
            kg["nodes"][1].update({"id": f"V-{secret}", "label": f"Vendor PHANTOMTREATMENT {secret}", "confidence": "High"})
        for key, (shelf, nid, label, _) in NEEDLES.items():
            if shelf == name:
                kg["nodes"][5 + len(nid) % 7].update({"id": nid, "label": label, "type": "Regulation" if kind == "statutory" else "Process",
                                                      "confidence": "100%", "evidence_rank": "R1", "review_by": "2027-06-30"})
        (L / "shelves" / name / "KNOWLEDGE_GRAPH.json").write_text(json.dumps(kg, ensure_ascii=False))
        if conf:
            os.chmod(L / "shelves" / name / "KNOWLEDGE_GRAPH.json", 0o600)
    return L


def grep_tree(root: Path, tokens, skip_dirs=()):
    """Every file under root (outside skip_dirs) that contains any token; reads raw bytes."""
    hits = []
    for p in root.rglob("*"):
        if p.is_symlink() or not p.is_file() or any(str(p).startswith(str(s)) for s in skip_dirs):
            continue
        try:
            raw = p.read_bytes()
        except OSError:
            continue
        for t in tokens:
            if t.encode() in raw:
                hits.append((str(p.relative_to(root)), t)); break
    return hits
