"""Installer tests, using an isolated fake home so nothing real is touched."""
import json, os, subprocess, sys, zipfile
from pathlib import Path
import pytest

BUNDLE = Path(__file__).resolve().parent.parent
INSTALL = BUNDLE / "install.py"


def run(*a, cwd=None, home=None):
    iso = {"USERPROFILE": str(home), "HOME": str(home), "APPDATA": str(Path(home) / "AppData/Roaming")} if home else {}   # isolate duplicate scan from the real account
    return subprocess.run([sys.executable, str(INSTALL), *map(str, a)], capture_output=True, text=True, cwd=cwd, env={**os.environ, **iso, "GIA_NO_FSYNC": "1", "PYTHONUTF8": "1", "GIA_DUP_SCAN_EXTRA": ""}, encoding="utf-8", errors="replace")


def snapshot(root):
    return {str(p.relative_to(root)): (p.read_bytes() if p.is_file() else None) for p in sorted(root.rglob("*"))}


def test_dry_run_changes_nothing(tmp_path):
    before = snapshot(tmp_path)
    r = run("--home", tmp_path, "--with-commands")
    assert r.returncode == 0 and "DRY RUN" in r.stdout and "INSTALL" in r.stdout
    assert snapshot(tmp_path) == before


def test_apply_installs_skill_commands_and_passes_its_own_self_checks(tmp_path):
    r = run("--home", tmp_path, "--apply", "--with-commands")
    assert r.returncode == 0 and "INSTALL OK" in r.stdout, r.stdout + r.stderr
    skill = tmp_path / ".claude/skills/akos-graphify-bridge"
    assert (skill / "SKILL.md").exists() and (skill / "scripts/brain.py").exists() and not (skill / "tests").exists()
    cmds = sorted((tmp_path / ".claude/commands").glob("*.md"))
    assert len(cmds) == 18
    text = "\n".join(c.read_text() for c in cmds)
    assert "${CLAUDE_PLUGIN_ROOT}" not in text and skill.as_posix() in text            # rendered with the real installed path


def test_a_rendered_command_line_really_runs(tmp_path):
    run("--home", tmp_path, "--apply", "--with-commands")
    text = (tmp_path / ".claude/commands/akos-brain-doctor.md").read_text()
    line = next(l for l in text.splitlines() if "brain.py doctor" in l)
    script = line.split("`python3 ")[1].split(" ")[0]
    r = subprocess.run([sys.executable, script, "--help"], capture_output=True, text=True)
    assert r.returncode == 0 and "doctor" in r.stdout


def test_installing_twice_changes_nothing_and_makes_no_new_backup(tmp_path):
    run("--home", tmp_path, "--apply", "--with-commands")
    after = snapshot(tmp_path / ".claude")
    r = run("--home", tmp_path, "--apply", "--with-commands")
    assert r.returncode == 0 and "ALREADY" in r.stdout
    assert snapshot(tmp_path / ".claude") == after and not list((tmp_path / ".claude").glob("gia-install-backup-*"))


def test_existing_skill_is_backed_up_and_uninstall_restores_it_exactly(tmp_path):
    old = tmp_path / ".claude/skills/akos-graphify-bridge"; old.mkdir(parents=True)
    (old / "SKILL.md").write_text("MY OWN OLDER VERSION"); (old / "custom.txt").write_text("keep me")
    oldcmd = tmp_path / ".claude/commands/akos-brain-doctor.md"; oldcmd.parent.mkdir(parents=True); oldcmd.write_text("my old command")
    before = {k: v for k, v in snapshot(tmp_path / ".claude").items()}
    r = run("--home", tmp_path, "--apply", "--with-commands")
    assert r.returncode == 0 and list((tmp_path / ".claude").glob("gia-install-backup-*"))
    assert "MY OWN OLDER VERSION" not in (old / "SKILL.md").read_text()
    run("--home", tmp_path, "--uninstall")
    assert (old / "SKILL.md").read_text() == "MY OWN OLDER VERSION" and (old / "custom.txt").read_text() == "keep me"
    assert oldcmd.read_text() == "my old command" and not (tmp_path / ".claude/commands/akos-graphify-x").exists()


def test_uninstall_removes_a_fresh_install_completely(tmp_path):
    run("--home", tmp_path, "--apply", "--with-commands")
    r = run("--home", tmp_path, "--uninstall")
    assert r.returncode == 0
    assert not (tmp_path / ".claude/skills/akos-graphify-bridge").exists() and not list((tmp_path / ".claude/commands").glob("*.md"))


def test_project_install_goes_into_that_projects_dot_claude(tmp_path):
    proj = tmp_path / "proj"; proj.mkdir()
    assert run("--project", proj, "--apply", home=tmp_path).returncode == 0
    assert (proj / ".claude/skills/akos-graphify-bridge/SKILL.md").exists()


def test_claude_ai_upload_zip_is_valid_and_runs(tmp_path):
    out = tmp_path / "up.zip"
    assert run("--make-upload-zip", out).returncode == 0
    z = zipfile.ZipFile(out); names = z.namelist()
    assert all(n.startswith("akos-graphify-bridge/") for n in names) and "akos-graphify-bridge/SKILL.md" in names
    assert not any("/tests/" in n or "__pycache__" in n for n in names)
    z.extractall(tmp_path / "x")
    r = subprocess.run([sys.executable, str(tmp_path / "x/akos-graphify-bridge/scripts/brain.py"), "--help"], capture_output=True, text=True)
    assert r.returncode == 0 and "seal" in r.stdout
    import re, yaml
    fm = yaml.safe_load(re.match(r"^---\s*\n(.*?)\n---", (tmp_path / "x/akos-graphify-bridge/SKILL.md").read_text(), re.S).group(1))
    assert fm["name"] == "akos-graphify-bridge" and len(" ".join(fm["description"].split())) <= 1024


def test_missing_source_is_a_clear_failure(tmp_path):
    import shutil
    b = tmp_path / "b"; b.mkdir(); shutil.copy(INSTALL, b / "install.py")
    r = subprocess.run([sys.executable, str(b / "install.py"), "--home", str(tmp_path), "--apply"], capture_output=True, text=True)
    assert r.returncode == 2 and "not found" in r.stdout and "Traceback" not in r.stderr


def _fake_plugin_copy(tmp_path):
    d = tmp_path / ".claude/plugins/akos-graph/skills/akos-graphify-bridge"; d.mkdir(parents=True)
    (d / "SKILL.md").write_text("---\nname: akos-graphify-bridge\ndescription: x\n---\n")
    return d


def test_a_second_copy_is_refused_unless_explicitly_allowed(tmp_path):
    _fake_plugin_copy(tmp_path)
    before = snapshot(tmp_path)
    dry = run("--home", tmp_path)
    assert dry.returncode == 0 and "DUPLICATE" in dry.stdout and snapshot(tmp_path) == before
    r = run("--home", tmp_path, "--apply")
    assert r.returncode == 2 and "REFUSED" in r.stdout
    assert not (tmp_path / ".claude/skills/akos-graphify-bridge").exists()
    r = run("--home", tmp_path, "--apply", "--allow-duplicate")
    assert r.returncode == 0 and (tmp_path / ".claude/skills/akos-graphify-bridge/SKILL.md").exists()


def test_verify_bundle_passes_on_every_platform():
    r = run("--verify-bundle")
    assert r.returncode == 0 and "files verified" in r.stdout, r.stdout


def test_installed_commands_carry_the_windows_python_fallback(tmp_path):
    run("--home", tmp_path, "--apply", "--with-commands", home=tmp_path)
    cmds = list((tmp_path / ".claude/commands").glob("*.md"))
    assert len(cmds) == 18 and all("**Windows:**" in c.read_text() and "py -3" in c.read_text() for c in cmds)
