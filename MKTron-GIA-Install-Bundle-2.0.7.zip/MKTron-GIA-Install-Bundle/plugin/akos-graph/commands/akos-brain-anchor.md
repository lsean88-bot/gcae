---
description: Record the audit head outside the library and prove the log was not truncated or rewritten
argument-hint: "<library dir> <anchor file outside the library>"
---

**Windows:** if `python3` fails or is not found (on Windows it is often a Microsoft Store stub), run the same command with `py -3` or `python` instead of `python3`. If the script needs graphify, use the Python that has it installed (`doctor` tells you).

Read the `akos-graphify-bridge` skill first.

1. To record: run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/brain.py anchor-record <lib> --file <anchor file>`. The file must be OUTSIDE the library (another drive, a mailed-to-self folder, a ticket export).
2. To check: run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/brain.py anchor-check <lib> --file <anchor file>`. LOG_TRUNCATED, LOG_REWRITTEN or ANCHOR_FILE_TAMPERED are ERRORs: report them first and stop; do not "repair" the log.
3. Suggest `export GIA_ANCHOR_FILE=<path>` so every `seal` anchors automatically.
