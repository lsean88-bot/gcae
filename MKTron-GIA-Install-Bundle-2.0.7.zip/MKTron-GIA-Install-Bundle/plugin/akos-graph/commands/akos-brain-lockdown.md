---
description: Re-apply owner-only protection to every confidential shelf and report anything still exposed (Windows ACL or POSIX modes)
argument-hint: "<library dir>"
---

**Windows:** if `python3` fails or is not found (on Windows it is often a Microsoft Store stub), run the same command with `py -3` or `python` instead of `python3`. If the script needs graphify, use the Python that has it installed (`doctor` tells you).

Read the `akos-graphify-bridge` skill first.

1. Run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/brain.py lockdown <lib>` and then `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/brain.py guard <lib>`.
2. Report which shelves were locked, any that failed, and any entry still readable by another account. A non-zero exit means a confidential shelf is NOT safely protected: say so plainly and do not suggest sharing the library.
3. If the volume cannot hold ACLs (some network or FAT/exFAT drives), tell the user to keep investigations under their user profile.
