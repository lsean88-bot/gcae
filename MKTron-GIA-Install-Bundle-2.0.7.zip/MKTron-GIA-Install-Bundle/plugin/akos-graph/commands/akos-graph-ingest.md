---
description: Stage a graphify extraction into the AKOS knowledge graph as PROPOSED items, with unclassified items listed for review
argument-hint: "<graphify graph.json> [entity-map.json] [--kg KNOWLEDGE_GRAPH.json]"
---

**Windows:** if `python3` fails or is not found (on Windows it is often a Microsoft Store stub), run the same command with `py -3` or `python` instead of `python3`. If the script needs graphify, use the Python that has it installed (`doctor` tells you).

Read the `akos-graphify-bridge` skill first, especially "The non-negotiable translation rules" and "Ingest workflow".

1. Confirm the graphify graph exists. If the user only has documents, run `/graphify <folder>` first (semantic pass uses Claude).
2. Ask once for an entity map (`{"MKAPL-DC": ["path substring"]}`) if none was provided. Do not guess folder-to-entity mapping.
3. Run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/akos_graph.py from-graphify <graph.json> --kg <KNOWLEDGE_GRAPH.json> --out <staged.json> --entity-map <map> --today <today>`. Never overwrite the live KG; write to a staged file.
4. Report: added nodes/edges, `unclassified` (offer to add to Outstanding Questions), `conflicts` (offer Decisions Register candidates), `indicator_edges`.
5. Do not promote anything to confirmed or raise any confidence. Promotion needs evidence and the user's decision; end by asking which items to classify first.
