---
description: Find CONFIRMED items whose wording matches but whose numbers differ (possible stale or conflicting facts)
argument-hint: "<library dir> [shelf]"
---

**Windows:** if `python3` fails or is not found (on Windows it is often a Microsoft Store stub), run the same command with `py -3` or `python` instead of `python3`. If the script needs graphify, use the Python that has it installed (`doctor` tells you).

Read the `akos-graphify-bridge` skill first.

1. Run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/brain.py contradictions <lib>` (add `--shelf <shelf>` to limit it). To also catch a confirmed figure that clashes with an unverified one, add `--include-unconfirmed`; say that this mode can show false positives (two different counts are not a conflict).
2. List each pair with both ids, shelves and numbers. State that this is a heuristic prompt to review which item is current, not a finding.
3. Never edit either item. Offer to run `recall` on both for their sources and `stale` for their review dates.
