---
description: Build a queryable graphify graph (plus HTML view) from this engagement's KNOWLEDGE_GRAPH.json
argument-hint: "[path/to/KNOWLEDGE_GRAPH.json] [output dir, default ./graphify-bridge-out]"
---

**Windows:** if `python3` fails or is not found (on Windows it is often a Microsoft Store stub), run the same command with `py -3` or `python` instead of `python3`. If the script needs graphify, use the Python that has it installed (`doctor` tells you).

Read the `akos-graphify-bridge` skill (and `references/mapping-spec.md` if anything looks unusual) before acting.

1. Locate `KNOWLEDGE_GRAPH.json` (argument, else current directory). If missing, tell the user and suggest `/akos-init`. Do not create one.
2. Run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/akos_graph.py validate <kg> --gate draft` first. Report errors and warnings; stop if there are ERRORs, because graphify should not be fed a broken graph.
3. Run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/akos_graph.py to-graphify <kg> --out <out>`.
4. Report node/edge/community counts and where `graph.html` and `graph.json` are. Present `graph.html` to the user.
5. Remind in one line: graphify labels EXTRACTED for both 100% and High edges; `akos_confidence` is the real value, and graph results are navigation, not findings.
