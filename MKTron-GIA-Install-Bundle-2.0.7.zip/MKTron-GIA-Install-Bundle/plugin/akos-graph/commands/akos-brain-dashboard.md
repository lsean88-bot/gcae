---
description: Produce the library brain dashboard as an interactive HTML page plus an Excel workbook (dual format)
argument-hint: "<library dir> [output dir, default ./brain-report]"
---

**Windows:** if `python3` fails or is not found (on Windows it is often a Microsoft Store stub), run the same command with `py -3` or `python` instead of `python3`. If the script needs graphify, use the Python that has it installed (`doctor` tells you).

Read the `akos-graphify-bridge` skill first.

1. Run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/brain.py dashboard <lib> --out <out>`. It writes `brain-dashboard.html` and `brain-dashboard.xlsx`.
2. Present the HTML and the workbook. Summarise in three lines: guard errors/warnings, stale or undated statutory items, and the trust mix (CONFIRMED / PROVISIONAL / INDICATOR).
3. Confidential shelves appear as counts only; say so if the user asks why a shelf has no detail.
4. For a single Knowledge Graph (not the whole library) use `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/akos_graph.py export-xlsx <kg> --out <file.xlsx> --gate final`: Summary (formula-driven), Nodes, Edges, Validation.
5. The workbook totals and summary use live Excel formulas; they calculate when opened in Excel.
