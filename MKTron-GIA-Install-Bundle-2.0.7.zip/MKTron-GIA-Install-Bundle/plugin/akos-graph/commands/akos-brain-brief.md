---
description: Briefing on one project: what the library knows, how far to trust it, and what needs re-validating
argument-hint: "<library dir> <project name>"
---

**Windows:** if `python3` fails or is not found (on Windows it is often a Microsoft Store stub), run the same command with `py -3` or `python` instead of `python3`. If the script needs graphify, use the Python that has it installed (`doctor` tells you).

Read the `akos-graphify-bridge` skill first.

1. Run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/brain.py brief <lib> --project "<project>"` and, for the same words, `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/brain.py recall <lib> "<project>" --limit 8`.
2. Present CONFIRMED first, then PROVISIONAL, then INDICATOR, each with shelf, id and evidence rank, then the items that need re-validating.
3. Confidential shelves are never included. Do not present INDICATOR items as findings, and do not fill gaps from memory: say what the library does not hold.
