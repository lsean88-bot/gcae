---
description: Capture a quick note into a project or notes shelf (second brain); it is always an unclassified INDICATOR
argument-hint: "<library dir> <shelf> <note text> [project]"
---

**Windows:** if `python3` fails or is not found (on Windows it is often a Microsoft Store stub), run the same command with `py -3` or `python` instead of `python3`. If the script needs graphify, use the Python that has it installed (`doctor` tells you).

Read the `akos-graphify-bridge` skill first.

1. Run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/brain.py capture <lib> --shelf <shelf> --text "<note>"` (add `--project <name>` and `--tags a b` when the user gave them).
2. Say the note id and that it is stored as an INDICATOR: it is a reminder, not evidence, and the FINAL gate blocks it until a human classifies and evidences it.
3. Never put a note into a statutory or confirmed shelf as a fact. If the user wants it treated as a fact, point them to the Ingest workflow in the skill.
