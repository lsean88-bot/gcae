---
description: Record whether a recalled answer helped, dead-ended, or was corrected, so the brain learns where to look
argument-hint: "<library dir> --shelf NAME --outcome useful|dead_end|corrected [--correction text]"
---

**Windows:** if `python3` fails or is not found (on Windows it is often a Microsoft Store stub), run the same command with `py -3` or `python` instead of `python3`. If the script needs graphify, use the Python that has it installed (`doctor` tells you).

Read the `akos-graphify-bridge` skill first.

1. Confirm with the user the question, the answer given, and the outcome. For `corrected`, get the correct answer; it is required.
2. Run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/brain.py remember <lib> --shelf <S> --question "..." --answer "..." --outcome <o> [--correction "..."] [--nodes ID ...]`.
3. Report any `unknown_nodes` the tool returns. Do not invent provenance.
4. State plainly that this is stored as an **indicator of usefulness, not evidence**.
5. Only if asked: `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/brain.py reflect <lib>`, then show `lessons/PROPOSED_LESSONS.md` as candidates for the user to accept or discard. Do not write them to LESSONS_LEARNED.md or any governance file yourself.
