---
description: Ask the library brain a question and get ranked results with trust labels, sources and staleness flags
argument-hint: "<library dir> <question> [--shelf NAME] [--min-confidence Medium]"
---

**Windows:** if `python3` fails or is not found (on Windows it is often a Microsoft Store stub), run the same command with `py -3` or `python` instead of `python3`. If the script needs graphify, use the Python that has it installed (`doctor` tells you).

Read the `akos-graphify-bridge` skill first.

1. Run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/brain.py recall <lib> "<question>"` (add `--shelf` / `--min-confidence` if given; add `--ranking idf` on a large library so rare words count more than common ones). Run `index` first if no index exists.
2. Present each result with its **trust label** (CONFIRMED / PROVISIONAL / INDICATOR), shelf, source_location, and any STALE/UNDATED flag.
3. Never present an INDICATOR item as a finding or fact. Say it tells the user where to look. For STALE/UNDATED statutory items, say the figure must be re-validated against the portal before use.
4. If nothing matches, say so. Do not fill the gap from general knowledge as though it came from the library.
5. A confidential shelf is recalled alone; never combine it with other shelves.
6. Offer to record the outcome with `/akos-brain-remember`.
