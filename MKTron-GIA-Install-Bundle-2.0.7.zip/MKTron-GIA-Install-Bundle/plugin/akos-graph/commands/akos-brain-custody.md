---
description: Export a self-checking provenance file for a shelf (HMAC-signed when GIA_CUSTODY_KEY is set), or verify one
argument-hint: "<library dir> <shelf> <output file outside the library>"
---

**Windows:** if `python3` fails or is not found (on Windows it is often a Microsoft Store stub), run the same command with `py -3` or `python` instead of `python3`. If the script needs graphify, use the Python that has it installed (`doctor` tells you).

Read the `akos-graphify-bridge` skill first.

1. To export: run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/brain.py custody-export <lib> --shelf <shelf> --out <file>`. To verify a received file: run `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/brain.py custody-verify <file>`.
2. State whether it is signed. Unsigned means the digest only detects accidental change. Remind the user that a confidential shelf's export contains seal reasons and must be handled as confidential.
3. This is a provenance record, not a legal opinion: do not describe it as proof of admissibility.
