---
description: Seal a shelf as reviewed, see exactly what changed since, and verify the tamper-evident audit trail
argument-hint: "<library dir> [seal|changes|verify] [--shelf NAME] [--reason text] [--anchor HASH]"
---

**Windows:** if `python3` fails or is not found (on Windows it is often a Microsoft Store stub), run the same command with `py -3` or `python` instead of `python3`. If the script needs graphify, use the Python that has it installed (`doctor` tells you).

Read the `akos-graphify-bridge` skill first.

- **seal** (a human attests the shelf's current content): `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/brain.py seal <lib> --shelf <S> --reason "<what was reviewed>"`. A reason is required. Tell the user to record the returned `audit_head` somewhere they control (email, ticket): it is the anchor that makes later tampering provable.
- **changes**: `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/brain.py changes <lib> --shelf <S>`. Report every flag (CONFIDENCE_RAISED with the evidence rank now, STATUS_CHANGED, NODE_REMOVED, SEAL_SNAPSHOT_TAMPERED). Exit code 1 means flags exist.
- **verify**: `python3 ${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge/scripts/brain.py verify <lib> [--anchor <hash>] [--strict]`. State plainly what it can and cannot detect: an edited, deleted or reordered entry is caught; a log truncated at the end or rewritten from the start is caught **only** if an anchor is supplied.
- Never edit the Knowledge Graph, the audit log or a snapshot to make a finding disappear. List the fix for the user to approve.
