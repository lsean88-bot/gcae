#!/usr/bin/env python3
"""akos_graph.py - bridge between AKOS KNOWLEDGE_GRAPH.json and graphify.

AKOS owns graph integrity (Module 5/9/11). graphify is the analysis engine
(clustering, god nodes, path, query, HTML). This bridge translates in both
directions WITHOUT letting graphify's confidence vocabulary leak into AKOS's
evidence discipline:

  * graphify EXTRACTED  -> AKOS "High" at most (never "100%": that needs evidence)
  * graphify INFERRED   -> AKOS "Medium"/"Low" + indicator_only (Iron Rule 17)
  * graphify AMBIGUOUS  -> AKOS "Low" (never in an official deliverable, Module 10)
  * native graphify nodes arrive as status PROPOSED, entity/type UNCLASSIFIED
    unless they can be determined (Module 12 rule 7: never guess).

Commands: to-graphify, from-graphify, validate, merge, deliverable, stats, export-xlsx.
Exit code 1 when `validate` finds ERRORs (so it can gate a pipeline).
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import re
import sys
import tempfile
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

BRIDGE_VERSION = "2.0.7"
HERE = Path(__file__).resolve().parent
CONFIG_DIR = HERE.parent / "config"

# ---- AKOS vocabulary (references/knowledge-graph-schema.md of AKOS) ----------
AKOS_NODE_TYPES = {
    "Document", "Folder", "Entity", "Division", "Company", "Department", "Process",
    "SubProcess", "Risk", "Control", "Policy", "Procedure", "Regulation", "Audit",
    "Issue", "Recommendation", "Project", "Plant", "Country", "System", "Database",
    "Vendor", "Customer", "Employee", "Role", "Committee", "Meeting", "Decision",
    "Evidence",
}
AKOS_RELATIONS = {
    "supports", "mitigates", "affects", "tested_by", "references", "reported_in",
    "owns", "uses", "contains", "implements", "supersedes", "depends_on",
    "belongs_to", "governs", "relates_to",
}
AKOS_CONFIDENCE = ("100%", "High", "Medium", "Low")
CONF_RANK = {c: i for i, c in enumerate(reversed(AKOS_CONFIDENCE))}  # Low=0..100%=3
UNCLASSIFIED = "UNCLASSIFIED"

# AKOS node type -> graphify file_type (graphify allows exactly six values)
TYPE_TO_FILE_TYPE = {
    "Document": "document", "Evidence": "document", "Policy": "document",
    "Procedure": "document", "Regulation": "document", "Folder": "document",
    "Decision": "rationale", "Meeting": "document",
}  # everything else -> "concept"

# graphify relation vocabulary -> AKOS relationship verb (original kept alongside)
GRAPHIFY_REL_TO_AKOS = {
    "calls": "uses", "imports": "depends_on", "contains": "contains",
    "references": "references", "cites": "references", "implements": "implements",
    "inherits": "depends_on", "uses": "uses", "method": "contains",
    "rationale_for": "relates_to", "shares_data_with": "relates_to",
    "semantically_similar_to": "relates_to", "conceptually_related_to": "relates_to",
}

REQ_NODE = ("id", "type", "label", "entity", "created_date", "confidence", "source_location")
REQ_EDGE = ("from", "to", "relationship", "evidence", "confidence")


# ---- helpers -------------------------------------------------------------------
import fsutil  # noqa: E402
import schema  # noqa: E402
import strictjson  # noqa: E402
import textnorm  # noqa: E402  (shared, script-aware text helpers)
import textsafe  # noqa: E402
from errors import DependencyError, InputError, RefusedError, run_cli  # noqa: E402

slug = textnorm.slug
norm_label = textnorm.norm_label


EVIDENCE_RANKS = ("R1", "R2", "R3", "R4", "R5")


def require_graphify():
    """Import graphify or fail CLEARLY. Only to-graphify, index and remember need it; validate, recall, seal, verify,
    deliverable, export-xlsx and the rest work without it."""
    try:
        import graphify  # noqa: F401
        return graphify
    except ImportError as exc:
        raise DependencyError("graphify is not installed, and this command needs it. Install it with "
                              "`pip install -e <graphify checkout>` (see requirements.txt). Commands such as validate, recall, "
                              "seal, verify, deliverable and export-xlsx work without it.") from exc


def _hs(x):
    """A hashable text/number, or None. A wrong-typed value (a list where text belongs) must never crash a lookup."""
    return x if isinstance(x, (str, int)) and not isinstance(x, bool) else None


def _s(v, default=""):
    """Text for a field handed to another library (graphify). None -> default; scalars -> str; anything else -> str()."""
    if v is None or v == "":
        return default
    return v if isinstance(v, str) else str(v)


_NODE_TEXT = ("id", "type", "label", "entity", "created_date", "confidence", "source_location", "status", "origin", "evidence_rank")
_EDGE_TEXT = ("from", "to", "relationship", "evidence", "confidence", "status", "origin")


def _typed_view(items, fields, kind):
    """Shallow copies in which wrong-typed field values become None, plus a FIELD_TYPE issue for each.
    Downstream checks can then hash and compare freely."""
    view, issues = [], []
    for i, it in enumerate(items):
        if not isinstance(it, dict):
            view.append({})
            continue
        c = dict(it)
        for f in fields:
            v = c.get(f)
            ok = v is None or isinstance(v, str) or (f in ("id", "from", "to") and isinstance(v, int) and not isinstance(v, bool))
            if not ok:
                issues.append({"severity": "ERROR", "code": "FIELD_TYPE",
                               "message": f"{kind}[{i}].{f} must be text, not {type(v).__name__}",
                               "ref": str(c.get("id", c.get("from", f"{kind}[{i}]")))[:80]})
                c[f] = None
        view.append(c)
    return view, issues


def parse_iso_date(value):
    """Strict ISO date (YYYY-MM-DD) or None. Anything else is 'unreadable', never silently 'fresh'."""
    from datetime import date
    try:
        return date.fromisoformat(str(value))
    except (TypeError, ValueError):
        return None


def gfy_label(akos_id: str, label: str) -> str:
    """Label as shown inside graphify: '[AKOS-ID] label' so auditors can search by AKOS id."""
    return f"[{akos_id}] {label}"


def strip_gfy_label(akos_id: str, label: str) -> str:
    prefix = f"[{akos_id}] "
    return label[len(prefix):] if isinstance(label, str) and label.startswith(prefix) else label


def load_json(path):
    """Strict read: BOM ok; duplicate keys, NaN, bad UTF-8, NUL, absurd nesting and oversize files refused clearly."""
    return strictjson.load(path)


def atomic_write_json(path, data, mode=0o644):
    """Atomic, fsynced JSON write (see fsutil). mode 0644 for shared files, 0600 for confidential ones."""
    fsutil.atomic_write_json(path, data, mode)


def sha256_file(path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


MEMORY_PATH = re.compile(r"(?:^|[/\\])graphify-out[/\\]memory[/\\]|(?:^|[/\\])memory[/\\]query_[^/\\]*\.md$", re.I)


def is_memory_origin(path: str) -> bool:
    """True if a graph node came from graphify's own saved Q&A (graphify-out/memory/).

    Those notes are an AI-generated *answer* that graphify re-extracts into the graph on the next update.
    They are indicators about what was useful, never evidence (Iron Rule 17) - otherwise an answer can
    later be cited as support for itself.
    """
    return bool(path) and bool(MEMORY_PATH.search(str(path).replace("\\", "/")))


def known_entities() -> set[str]:
    cfg = CONFIG_DIR / "entities.json"
    if cfg.exists():
        data = load_json(cfg)
        return set(data.get("entities", [])) | {"Group", UNCLASSIFIED}
    return {"Group", UNCLASSIFIED}


def issue(sev, code, msg, ref=None):
    return {"severity": sev, "code": code, "message": msg, "ref": ref}


# ---- AKOS -> graphify ----------------------------------------------------------
def kg_to_extraction(kg: dict) -> dict:
    """Translate an AKOS KG into a graphify extraction dict (validate-clean)."""
    nodes, seen = [], {}
    for i, n in enumerate(kg.get("nodes", [])):
        if not isinstance(n, dict) or n.get("id") in (None, ""):
            raise InputError(f"nodes[{i}] has no usable 'id' (run `validate` to see every field problem)")
        sid = slug(n["id"])
        if sid in seen and seen[sid] != n["id"]:
            raise InputError(
                f"id collision after graphify slugging: {n['id']!r} and {seen[sid]!r} "
                f"both map to {sid!r}. Rename one in KNOWLEDGE_GRAPH.json."
            )
        seen[sid] = n["id"]
        conf = n.get("confidence", "Low")
        node = {
            "id": sid,
            "label": gfy_label(n["id"], _s(n.get("label"), str(n["id"]))),
            "file_type": TYPE_TO_FILE_TYPE.get(_hs(n.get("type")), "concept"),
            "source_file": _s(n.get("source_location"), "unknown"),
            "akos_id": n["id"],
            "akos_type": _s(n.get("type"), None),
            "entity": _s(n.get("entity"), None),
            "created_date": _s(n.get("created_date"), None),
            "akos_confidence": _s(conf, "Low"),
        }
        for opt in ("status", "engagement", "shelf", "shelf_kind", "review_by", "valid_from",
                    "origin", "evidence_rank"):
            if n.get(opt) is not None:
                node[opt] = _s(n[opt])
        if n.get("indicator_only") is not None:
            node["indicator_only"] = bool(n["indicator_only"])
        nodes.append(node)

    by_akos = {n["akos_id"]: n for n in nodes}
    edges = []
    for e in kg.get("edges", []):
        if not isinstance(e, dict) or _hs(e.get("from")) not in by_akos or _hs(e.get("to")) not in by_akos:
            # keep dangling edges out of graphify (it would drop/raise); validate reports them
            continue
        conf = _s(e.get("confidence"), "Low")
        if conf in ("100%", "High"):
            gconf, score = "EXTRACTED", 1.0
        elif conf == "Medium":
            gconf, score = "INFERRED", 0.75
        else:
            gconf, score = "AMBIGUOUS", 0.2
        edge = {
            "source": by_akos[e["from"]]["id"],
            "target": by_akos[e["to"]]["id"],
            "relation": _s(e.get("relationship"), "relates_to"),
            "confidence": gconf,
            "confidence_score": score,
            "source_file": by_akos[e["from"]]["source_file"],
            "weight": 1.0,
            "evidence": _s(e.get("evidence"), ""),
            "akos_confidence": conf,
            # graphify persists an undirected graph; keep true direction explicitly
            "akos_from": e["from"],
            "akos_to": e["to"],
        }
        if e.get("indicator_only"):
            edge["indicator_only"] = True
        edges.append(edge)
    return {"nodes": nodes, "edges": edges, "hyperedges": []}


def build_graphify_outputs(kg: dict, out_dir: Path, html: bool = True) -> dict:
    """Write extraction.json + graphify-out/{graph.json,graph.html} + akos_meta.json."""
    require_graphify()
    from graphify.build import build_from_json
    from graphify.cluster import cluster
    from graphify.export import to_json, to_html
    from graphify.validate import validate_extraction

    out_dir = Path(out_dir)
    ext = kg_to_extraction(kg)
    errs = validate_extraction(ext)
    if errs:
        raise ValueError("bridge produced an extraction graphify rejects:\n  " + "\n  ".join(errs))
    atomic_write_json(out_dir / "extraction.json", ext)

    G = build_from_json(ext)
    communities = cluster(G) if G.number_of_nodes() else {}
    gdir = out_dir / "graphify-out"
    gdir.mkdir(parents=True, exist_ok=True)
    tmp_json = gdir / f".graph.json.{os.getpid()}.tmp"           # write beside, then rename: never a torn graph.json
    try:
        to_json(G, communities, str(tmp_json), force=True)
        os.replace(tmp_json, gdir / "graph.json")
    finally:
        tmp_json.unlink(missing_ok=True)
    html_ok = None
    if html and G.number_of_nodes():
        tmp_html = gdir / f".graph.html.{os.getpid()}.tmp"
        try:
            to_html(G, communities, str(tmp_html))
            html_ok = tmp_html.exists()          # graphify >= 0.9 returns None on success: judge by the file, not the return value
            if html_ok:
                os.replace(tmp_html, gdir / "graph.html")
        except Exception as exc:  # html is a convenience; never fail the build on it
            html_ok = f"skipped: {exc}"
        finally:
            tmp_html.unlink(missing_ok=True)
    meta = {
        "bridge_version": BRIDGE_VERSION,
        "engagement": kg.get("engagement"),
        "confidential": bool(kg.get("confidential", False)),
        "last_updated": kg.get("last_updated"),
        "nodes": G.number_of_nodes(),
        "edges": G.number_of_edges(),
        "communities": len(communities),
        "html": html_ok,
    }
    atomic_write_json(gdir / "akos_meta.json", meta)
    return meta


# ---- graphify -> AKOS (staging) ------------------------------------------------
def _entity_for(path: str, entity_map: dict) -> str:
    p = (path or "").replace("\\", "/").lower()
    for entity, needles in entity_map.items():
        for needle in needles:
            if needle.lower() in p:
                return entity
    return UNCLASSIFIED


def _node_conf_from_edges(_node_id, default="Medium"):
    return default


def graphify_to_staged(graph: dict, existing_kg: dict | None = None,
                       entity_map: dict | None = None, today: str = "") -> tuple[dict, dict]:
    """Return (merged_kg, report). Existing KG is authoritative and never overwritten."""
    entity_map = entity_map or {}
    existing_kg = copy.deepcopy(existing_kg) if existing_kg else {
        "engagement": "", "last_updated": today, "nodes": [], "edges": []}
    existing_kg.setdefault("nodes", [])
    existing_kg.setdefault("edges", [])
    ek_nodes = {n["id"]: n for n in existing_kg["nodes"] if isinstance(n, dict) and _hs(n.get("id")) is not None}
    edge_key = lambda e: (_hs(e.get("from")), _hs(e.get("to")), _hs(e.get("relationship")))  # noqa: E731
    ek_edges = {edge_key(e): e for e in existing_kg["edges"] if isinstance(e, dict)}

    g_nodes = graph.get("nodes", [])
    g_edges = graph.get("links", graph.get("edges", []))
    id_map = {}  # graphify id -> AKOS id
    mem_ids: set[str] = set()  # AKOS ids of nodes that came from graphify work-memory
    report = {"memory_nodes": 0, "added_nodes": 0, "added_edges": 0, "unchanged_nodes": 0, "conflicts": [],
              "unclassified": [], "indicator_edges": 0, "skipped_edges": 0}

    for gn in g_nodes:
        akos_id = _hs(gn.get("akos_id")) or "GFY-" + str(gn["id"]).upper().replace("_", "-")[:60]
        id_map[gn["id"]] = akos_id
        if akos_id in ek_nodes:
            ex = ek_nodes[akos_id]
            report["unchanged_nodes"] += 1
            for fld, gval in (("label", strip_gfy_label(akos_id, gn.get("label"))), ("type", gn.get("akos_type")),
                              ("entity", gn.get("entity"))):
                if gval is not None and ex.get(fld) not in (None, gval):
                    report["conflicts"].append({
                        "node": akos_id, "field": fld, "existing": ex.get(fld), "graphify": gval,
                        "action": "kept existing (Module 11: no silent change to confirmed content)"})
            continue
        akos_type = gn.get("akos_type")
        if not akos_type:
            akos_type = "Document" if gn.get("file_type") in ("document", "paper", "image") else UNCLASSIFIED
        src = gn.get("source_file") or "unknown"
        src = src if isinstance(src, str) else str(src)
        entity = gn.get("entity") or _entity_for(src, entity_map)
        node = {
            "id": akos_id, "type": akos_type, "label": strip_gfy_label(akos_id, gn.get("label", akos_id)),
            "entity": entity, "created_date": gn.get("created_date") or today,
            "confidence": gn.get("akos_confidence") or "Medium",
            "source_location": src, "status": "PROPOSED", "origin": "graphify",
        }
        if is_memory_origin(src):
            node.update({"origin": "graphify-memory", "confidence": "Low", "indicator_only": True})
            mem_ids.add(akos_id)
            report["memory_nodes"] += 1
        ek_nodes[akos_id] = node
        existing_kg["nodes"].append(node)
        report["added_nodes"] += 1
        if akos_type == UNCLASSIFIED or entity == UNCLASSIFIED:
            report["unclassified"].append(
                {"id": akos_id, "label": node["label"], "type": akos_type, "entity": entity})

    for ge in g_edges:
        s, t = _hs(ge.get("akos_from")), _hs(ge.get("akos_to"))
        if not s or not t:
            s, t = id_map.get(_hs(ge.get("source"))), id_map.get(_hs(ge.get("target")))
        if not s or not t:
            report["skipped_edges"] += 1
            continue
        rel_raw = ge.get("relation", "relates_to")
        rel = rel_raw if _hs(rel_raw) in AKOS_RELATIONS else GRAPHIFY_REL_TO_AKOS.get(_hs(rel_raw), "relates_to")
        key = (s, t, rel)
        if key in ek_edges:
            continue
        gconf = ge.get("confidence")
        try:
            score = float(ge.get("confidence_score", 0) or 0)
        except (TypeError, ValueError):
            score = 0.0
        indicator = False
        if ge.get("akos_confidence"):
            conf = ge["akos_confidence"]
        elif gconf == "EXTRACTED":
            conf = "High"
        elif gconf == "INFERRED":
            conf, indicator = ("Medium" if score >= 0.75 else "Low"), True
        else:
            conf, indicator = "Low", True
        evidence = ge.get("evidence") or (
            f"graphify {gconf or 'edge'} ({rel_raw}) at "
            f"{ge.get('source_file', 'unknown')}:{ge.get('source_location') or '?'}")
        origin = "graphify"
        if s in mem_ids or t in mem_ids:
            conf, indicator, origin = "Low", True, "graphify-memory"
        edge = {"from": s, "to": t, "relationship": rel, "evidence": evidence,
                "confidence": conf, "status": "PROPOSED", "origin": origin}
        if rel != rel_raw:
            edge["original_relation"] = rel_raw
        if indicator:
            edge["indicator_only"] = True
            report["indicator_edges"] += 1
        ek_edges[key] = edge
        existing_kg["edges"].append(edge)
        report["added_edges"] += 1

    if today:
        existing_kg["last_updated"] = today
    return existing_kg, report


# ---- validation (AKOS Module 9 + Iron Rules) -------------------------------------
def validate_kg(kg: dict, gate: str = "draft") -> list[dict]:
    final = gate == "final"
    out: list[dict] = []
    ents = known_entities()
    nodes, n_issues = _typed_view(kg.get("nodes", []), _NODE_TEXT, "nodes")
    edges, e_issues = _typed_view(kg.get("edges", []), _EDGE_TEXT, "edges")
    out.extend(n_issues + e_issues)
    ids, dup = {}, set()
    for n in nodes:
        nid = n.get("id")
        for f in REQ_NODE:
            if n.get(f) in (None, ""):
                out.append(issue("ERROR", "NODE_FIELD_MISSING", f"node missing '{f}'", nid))
        if nid in ids:
            dup.add(nid)
        ids[nid] = n
        if n.get("type") and n["type"] not in AKOS_NODE_TYPES and n["type"] != UNCLASSIFIED:
            out.append(issue("ERROR", "TYPE_INVALID", f"unknown node type {n['type']!r}", nid))
        if n.get("type") == UNCLASSIFIED:
            out.append(issue("ERROR" if final else "WARN", "TYPE_UNCLASSIFIED",
                             "type not yet classified (Outstanding Question; do not guess)", nid))
        if n.get("confidence") and n["confidence"] not in AKOS_CONFIDENCE:
            out.append(issue("ERROR", "CONF_INVALID", f"confidence {n['confidence']!r} not in {AKOS_CONFIDENCE}", nid))
        if n.get("entity") and n["entity"] not in ents:
            out.append(issue("ERROR" if final else "WARN", "ENTITY_UNKNOWN",
                             f"entity {n['entity']!r} not in config/entities.json", nid))
        if n.get("entity") == UNCLASSIFIED:
            out.append(issue("ERROR" if final else "WARN", "ENTITY_UNCLASSIFIED",
                             "entity not yet determined", nid))
        if n.get("confidence") == "100%" and n.get("origin") == "graphify":
            out.append(issue("ERROR", "CONF_ELEVATED",
                             "graphify-derived node at 100% - needs authoritative evidence, not repetition", nid))
        rk = n.get("evidence_rank")
        if rk is not None and rk not in EVIDENCE_RANKS:
            out.append(issue("ERROR", "RANK_INVALID", f"evidence_rank {rk!r} not in {EVIDENCE_RANKS}", nid))
        if rk in ("R4", "R5") and n.get("confidence") == "100%":
            out.append(issue("WARN", "CONF_VS_RANK",
                             f"100% confidence resting on {rk} evidence (R4 = management-prepared/unverified, R5 = verbal): "
                             f"the evidence hierarchy does not support 100%", nid))
        for dfld in ("review_by", "valid_from"):
            if n.get(dfld) not in (None, "") and parse_iso_date(n[dfld]) is None:
                out.append(issue("WARN", "DATE_FORMAT",
                                 f"{dfld} {n[dfld]!r} is not YYYY-MM-DD; freshness cannot be judged and will be treated as unknown", nid))
        if n.get("origin") == "graphify-memory" and n.get("confidence") != "Low":
            out.append(issue("ERROR", "MEMORY_AS_EVIDENCE",
                             "node derived from graphify saved-Q&A memory is above Low - a saved answer is an indicator, "
                             "never evidence (Iron Rule 17)", nid))
        if n.get("status") == "ALLEGED" and n.get("confidence") == "100%":
            out.append(issue("ERROR", "ALLEGED_AS_CONFIRMED",
                             "ALLEGED item carries 100% confidence - never blur alleged vs confirmed", nid))
        if final and n.get("status") in ("PROPOSED", "RETRACTED"):
            out.append(issue("ERROR", "STATUS_NOT_FINAL",
                             f"status {n['status']} cannot appear in a FINAL deliverable (Iron Rule 04)", nid))
        if final and n.get("confidence") == "Low":
            out.append(issue("ERROR", "LOW_IN_FINAL", "Low confidence is hypothesis only (Module 10)", nid))
        elif final and n.get("confidence") == "Medium":
            out.append(issue("WARN", "MEDIUM_IN_FINAL", "Medium needs validation before reliance", nid))
        if kg.get("confidential") and n.get("engagement") not in (None, kg.get("engagement")):
            out.append(issue("ERROR", "CONFIDENTIAL_LEAK",
                             f"node from engagement {n.get('engagement')!r} inside confidential graph "
                             f"{kg.get('engagement')!r}", nid))
    for d in dup:
        out.append(issue("ERROR", "DUPLICATE_ID", "duplicate node id", d))

    # near-duplicates (Iron Rule 05: merge, never count twice)
    buckets = defaultdict(list)
    for n in nodes:
        buckets[(n.get("type"), n.get("entity"), norm_label(n.get("label", "")))].append(n.get("id"))
    for key, members in buckets.items():
        if len(members) > 1 and key[2]:
            out.append(issue("WARN", "NEAR_DUPLICATE", f"same type/entity/label: {members}", members[0]))

    degree = Counter()
    for e in edges:
        ref = f"{e.get('from')}->{e.get('to')}"
        for f in REQ_EDGE:
            if e.get(f) in (None, ""):
                out.append(issue("ERROR", "EDGE_FIELD_MISSING", f"edge missing '{f}'", ref))
        for end in ("from", "to"):
            if e.get(end) not in ids:
                out.append(issue("ERROR", "DANGLING_EDGE", f"{end} {e.get(end)!r} is not a node", ref))
        degree[e.get("from")] += 1
        degree[e.get("to")] += 1
        if e.get("relationship") and e["relationship"] not in AKOS_RELATIONS:
            out.append(issue("ERROR", "REL_INVALID", f"unknown relationship {e['relationship']!r}", ref))
        if e.get("confidence") and e["confidence"] not in AKOS_CONFIDENCE:
            out.append(issue("ERROR", "CONF_INVALID", f"edge confidence {e['confidence']!r}", ref))
        if e.get("origin") == "graphify-memory" and e.get("confidence") != "Low":
            out.append(issue("ERROR", "MEMORY_AS_EVIDENCE", "edge derived from graphify saved-Q&A memory is above Low", ref))
        if e.get("from") == e.get("to"):
            out.append(issue("WARN", "SELF_LOOP", "edge from a node to itself", ref))
        if e.get("confidence") == "100%" and not str(e.get("evidence", "")).strip():
            out.append(issue("ERROR", "EVIDENCE_REQUIRED", "100% edge needs named evidence", ref))
        if e.get("indicator_only") and e.get("confidence") in ("100%", "High"):
            out.append(issue("ERROR", "INDICATOR_AS_EVIDENCE",
                             "AI/graph-inferred edge marked High/100% (Iron Rule 17: indicators only)", ref))
        if final and e.get("status") in ("PROPOSED", "RETRACTED"):
            out.append(issue("ERROR", "STATUS_NOT_FINAL", f"edge status {e['status']} in FINAL", ref))
        if final and e.get("confidence") == "Low":
            out.append(issue("ERROR", "LOW_IN_FINAL", "Low-confidence edge in FINAL", ref))

    for nid in ids:
        if degree[nid] == 0:
            out.append(issue("ERROR" if final else "WARN", "ORPHAN_NODE",
                             "node has no relationships (Module 9: no orphan records)", nid))
    return out


def summarize(issues):
    c = Counter(i["severity"] for i in issues)
    return {"errors": c.get("ERROR", 0), "warnings": c.get("WARN", 0)}


# ---- merge / deliverable / stats ----------------------------------------------------
def merge_kgs(a: dict, b: dict) -> dict:
    if (a.get("confidential") or b.get("confidential")) and a.get("engagement") != b.get("engagement"):
        raise RefusedError(
            "refusing to merge: one graph is flagged confidential (active investigation). "
            "Keep it as its own isolated engagement until conclusions are confirmed.")
    merged = copy.deepcopy(a)
    merged.setdefault("nodes", [])
    merged.setdefault("edges", [])
    ids = {n["id"]: n for n in merged["nodes"]}
    for n in b.get("nodes", []):
        if n["id"] in ids:
            if ids[n["id"]].get("label") != n.get("label") or ids[n["id"]].get("type") != n.get("type"):
                raise InputError(f"conflicting definition for node {n['id']!r}; resolve via Decisions Register")
            continue
        merged["nodes"].append(copy.deepcopy(n))
    keys = {(_hs(e.get("from")), _hs(e.get("to")), _hs(e.get("relationship"))) for e in merged["edges"]}
    for e in b.get("edges", []):
        if (_hs(e.get("from")), _hs(e.get("to")), _hs(e.get("relationship"))) not in keys:
            merged["edges"].append(copy.deepcopy(e))
    return merged


def deliverable_subset(kg: dict, include_medium: bool = False, max_rank: str | None = None) -> tuple[dict, dict]:
    """Board-safe subset. max_rank='R3' additionally requires a KNOWN evidence rank no worse than R3;
    unranked nodes are excluded and counted (never silently admitted)."""
    floor = CONF_RANK["Medium" if include_medium else "High"]
    lim = EVIDENCE_RANKS.index(max_rank) if max_rank else None
    unranked = 0

    def rank_ok(n):
        nonlocal unranked
        if lim is None:
            return True
        r = n.get("evidence_rank")
        if r not in EVIDENCE_RANKS:
            unranked += 1
            return False
        return EVIDENCE_RANKS.index(r) <= lim

    keep_n = [n for n in kg.get("nodes", [])
              if n.get("status") not in ("PROPOSED", "RETRACTED", "ALLEGED")
              and n.get("origin") != "graphify-memory"
              and CONF_RANK.get(_hs(n.get("confidence")), 0) >= floor and rank_ok(n)]
    kept = {n["id"] for n in keep_n}
    keep_e = [e for e in kg.get("edges", [])
              if _hs(e.get("from")) in kept and _hs(e.get("to")) in kept
              and e.get("status") not in ("PROPOSED", "RETRACTED")
              and e.get("origin") != "graphify-memory"
              and not (e.get("indicator_only") and not include_medium)
              and CONF_RANK.get(_hs(e.get("confidence")), 0) >= floor]
    out = {k: v for k, v in kg.items() if k not in ("nodes", "edges")}
    out["nodes"], out["edges"] = keep_n, keep_e
    rep = {"nodes_kept": len(keep_n), "nodes_excluded": len(kg.get("nodes", [])) - len(keep_n),
           "edges_kept": len(keep_e), "edges_excluded": len(kg.get("edges", [])) - len(keep_e)}
    if lim is not None:
        rep["excluded_unranked"] = unranked
    return out, rep


def stats(kg: dict) -> dict:
    deg = Counter()
    for e in kg.get("edges", []):
        deg[_hs(e.get("from"))] += 1
        deg[_hs(e.get("to"))] += 1
    labels = {n["id"]: n.get("label") for n in kg.get("nodes", [])}
    return {
        "nodes": len(kg.get("nodes", [])), "edges": len(kg.get("edges", [])),
        "by_type": dict(Counter(_hs(n.get("type")) for n in kg.get("nodes", []))),
        "by_entity": dict(Counter(_hs(n.get("entity")) for n in kg.get("nodes", []))),
        "by_confidence": dict(Counter(_hs(n.get("confidence")) for n in kg.get("nodes", []))),
        "proposed": sum(1 for n in kg.get("nodes", []) if n.get("status") == "PROPOSED"),
        "orphans": [n["id"] for n in kg.get("nodes", []) if deg[n["id"]] == 0],
        "top_hubs": [{"id": i, "label": labels.get(i), "degree": d} for i, d in deg.most_common(5)],
    }


# ---- CLI ---------------------------------------------------------------------------
def _print_issues(issues, as_json):
    if as_json:
        print(json.dumps({"summary": summarize(issues), "issues": issues}, indent=2))
        return
    order = {"ERROR": 0, "WARN": 1}
    for i in sorted(issues, key=lambda x: (order.get(x["severity"], 2), x["code"])):
        print(f"[{i['severity']:<5}] {i['code']:<22} {textsafe.display(i['ref'] or '-', 60):<34} {textsafe.display(i['message'], 400)}")
    s = summarize(issues)
    print(f"\n{s['errors']} error(s), {s['warnings']} warning(s)")


def _main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="akos_graph", description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("to-graphify", help="KNOWLEDGE_GRAPH.json -> graphify graph.json (+html)")
    p.add_argument("kg"); p.add_argument("--out", required=True); p.add_argument("--no-html", action="store_true")

    p = sub.add_parser("from-graphify", help="graphify graph.json -> staged (PROPOSED) AKOS KG")
    p.add_argument("graph"); p.add_argument("--kg", help="existing KNOWLEDGE_GRAPH.json (authoritative)")
    p.add_argument("--out", required=True); p.add_argument("--entity-map", help="JSON {ENTITY:[path substrings]}")
    p.add_argument("--today", default="")

    p = sub.add_parser("validate", help="AKOS Module 9 + Iron Rule checks")
    p.add_argument("kg"); p.add_argument("--gate", choices=["draft", "final"], default="draft")
    p.add_argument("--json", action="store_true")

    p = sub.add_parser("merge", help="merge two KGs (refuses confidential cross-engagement)")
    p.add_argument("a"); p.add_argument("b"); p.add_argument("--out", required=True)

    p = sub.add_parser("deliverable", help="export only what may appear in an official deliverable")
    p.add_argument("kg"); p.add_argument("--out", required=True); p.add_argument("--include-medium", action="store_true")
    p.add_argument("--max-rank", choices=list(EVIDENCE_RANKS), help="require a known evidence rank at least this good (e.g. R3)")

    p = sub.add_parser("stats", help="size, mix, orphans, hubs")
    p.add_argument("kg")

    p = sub.add_parser("export-xlsx", help="working-paper workbook: Summary (formulas), Nodes, Edges, Validation")
    p.add_argument("kg"); p.add_argument("--out", required=True); p.add_argument("--gate", choices=["draft", "final"], default="draft")

    a = ap.parse_args(argv)

    def kg(path, strict=True):
        return schema.require_kg(load_json(path), str(path), strict_edges=strict)

    if a.cmd == "to-graphify":
        meta = build_graphify_outputs(kg(a.kg), Path(a.out), html=not a.no_html)
        print(json.dumps(meta, indent=2))
        print(f"\nQuery it:  graphify query \"<question>\" --graph {textsafe.display(a.out, 200)}/graphify-out/graph.json")
        return 0
    if a.cmd == "from-graphify":
        emap = load_json(a.entity_map) if a.entity_map else {}
        if not isinstance(emap, dict) or not all(isinstance(v, list) and all(isinstance(x, str) for x in v) for v in emap.values()):
            raise InputError("--entity-map must be a JSON object of {ENTITY: [path substrings]}")
        if a.today and parse_iso_date(a.today) is None:
            raise InputError(f"--today {a.today!r} is not YYYY-MM-DD")
        existing = kg(a.kg) if a.kg else None
        graph = schema.require_graph(load_json(a.graph), str(a.graph))
        merged, rep = graphify_to_staged(graph, existing, emap, a.today)
        atomic_write_json(a.out, merged)
        print(json.dumps(rep, indent=2))
        return 0
    if a.cmd == "validate":
        issues = validate_kg(kg(a.kg, strict=False), a.gate)
        _print_issues(issues, a.json)
        return 1 if summarize(issues)["errors"] else 0
    if a.cmd == "merge":
        atomic_write_json(a.out, merge_kgs(kg(a.a), kg(a.b)))
        print(f"merged -> {textsafe.display(a.out, 200)}")
        return 0
    if a.cmd == "deliverable":
        sub_kg, rep = deliverable_subset(kg(a.kg), a.include_medium, a.max_rank)
        atomic_write_json(a.out, sub_kg)
        print(json.dumps(rep, indent=2))
        return 0
    if a.cmd == "stats":
        print(json.dumps(stats(kg(a.kg)), indent=2))
        return 0
    if a.cmd == "export-xlsx":
        import report  # lazy: openpyxl is only needed for this command
        print(report.write_kg_xlsx(kg(a.kg, strict=False), Path(a.out), a.gate))
        return 0
    return 0


def main(argv=None) -> int:
    """Public entry point: every outcome mapped to the exit-code contract (0 ok, 1 findings, 2 bad input, 3 bug)."""
    return run_cli(_main, argv)


if __name__ == "__main__":
    sys.exit(main())
