"""extras.py - v2.0.2 additions to the library brain. Wired into brain.py; every command here follows the same exit-code
contract (0 ok, 1 findings, 2 bad input, 3 bug) and the same trust rules (nothing here can create a CONFIRMED fact).

  anchor-record / anchor-check   record the audit head OUTSIDE the library, with its own hash chain; detect truncation or rewrite
  custody-export / custody-verify  one self-checking file of a shelf's provenance for hand-off (HMAC-signed if you supply a key)
  contradictions                 possible conflicts between CONFIRMED items (heuristic: a prompt to review, never a finding)
  access-log                     who recalled from a confidential shelf, when (hash-chained, owner-only)
  capture                        second-brain quick note: always an unclassified INDICATOR, can never reach a final deliverable
  lockdown                       (re)apply owner-only protection to every confidential shelf (the Windows ACL repair)
  brief                          one-page project briefing: what is known, how far to trust it, what is stale, what was learned
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
from pathlib import Path

import akos_graph as ag
import audit
import brain
import fsutil
import textsafe
from brain import BrainError

COMMANDS = {"anchor-record", "anchor-check", "custody-export", "custody-verify", "contradictions", "access-log", "capture",
            "lockdown", "brief"}
ZERO = "0" * 64


def _canon(o) -> bytes:
    return json.dumps(o, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def _inside(child: Path, parent: Path) -> bool:
    try:
        Path(child).resolve().relative_to(Path(parent).resolve())
        return True
    except ValueError:
        return False


# ================================================================ anchors (W5: truncation / rewrite detection)
def _read_anchor_file(f: Path) -> list[dict]:
    if not f.exists():
        return []
    out = []
    for i, line in enumerate(f.read_text(encoding="utf-8").splitlines(), 1):
        if line.strip():
            try:
                out.append(json.loads(line))
            except ValueError as exc:
                raise BrainError(f"anchor file line {i} is not valid JSON ({exc})") from exc
    return out


def anchor_record(lib: Path, anchor_file, note: str = "") -> dict:
    lib, f = Path(lib), Path(anchor_file)
    if _inside(f, lib):
        raise BrainError("the anchor file must be OUTSIDE the library (e.g. a mailed-to-yourself folder, a ticket export, a "
                         "different drive): a copy next to the log proves nothing")
    h = audit.head(lib)
    if not h or not h.get("hash"):
        raise BrainError("the library has no audit entries yet")
    prev = _read_anchor_file(f)
    rec = {"ts": fsutil.now_utc_iso(), "actor": audit.actor(), "seq": h["seq"], "head": h["hash"], "note": note[:200],
           "prev": prev[-1]["hash"] if prev else ZERO}
    rec["hash"] = hashlib.sha256(_canon(rec)).hexdigest()
    f.parent.mkdir(parents=True, exist_ok=True)
    with open(f, "ab") as fh:
        fh.write(json.dumps(rec, ensure_ascii=False, separators=(",", ":")).encode("utf-8") + b"\n")
        fh.flush()
        os.fsync(fh.fileno())
    return rec


def anchor_check(lib: Path, anchor_file) -> list[dict]:
    """Findings. ERROR if the anchor file itself was edited, or if any recorded head is missing from (or at the wrong
    position in) the current audit log - i.e. the log was truncated, rewritten or replaced after the anchor was taken."""
    f = Path(anchor_file)
    out: list[dict] = []
    if not f.exists():
        return [audit.issue("ERROR", "ANCHOR_FILE_MISSING", "the anchor file does not exist: nothing proves the log is complete")]
    recs = _read_anchor_file(f)
    if not recs:
        return [audit.issue("WARN", "ANCHOR_FILE_EMPTY", "the anchor file has no records yet")]
    prev = ZERO
    for i, r in enumerate(recs, 1):
        body = {k: v for k, v in r.items() if k != "hash"}
        if r.get("prev") != prev or hashlib.sha256(_canon(body)).hexdigest() != r.get("hash"):
            out.append(audit.issue("ERROR", "ANCHOR_FILE_TAMPERED", f"anchor record {i} was edited, removed or reordered", f"record {i}"))
            break
        prev = r["hash"]
    entries, _ = audit.read(lib)
    by_seq = {e.get("seq"): e for e in entries}
    for i, r in enumerate(recs, 1):
        e = by_seq.get(r.get("seq"))
        if e is None:
            out.append(audit.issue("ERROR", "LOG_TRUNCATED",
                                   f"anchor {i} recorded audit entry #{r.get('seq')} but the log now ends at #{len(entries)}: entries were removed",
                                   f"record {i}"))
        elif e.get("hash") != r.get("head"):
            out.append(audit.issue("ERROR", "LOG_REWRITTEN",
                                   f"audit entry #{r.get('seq')} no longer has the hash recorded in anchor {i}: the log was rewritten", f"record {i}"))
    return out


def auto_anchor(lib: Path, explicit, seal_result: dict) -> None:
    """`seal` calls this: if --anchor-file or GIA_ANCHOR_FILE is set, record the new head outside the library."""
    target = explicit or os.environ.get("GIA_ANCHOR_FILE")
    if target:
        rec = anchor_record(lib, target, note=f"seal {seal_result.get('shelf', '')}")
        seal_result["anchored_to"] = str(target)
        seal_result["anchor_hash"] = rec["hash"]


# ================================================================ access log for confidential shelves
def _alog(lib: Path, shelf: str) -> Path:
    return brain.shelf_dir(lib, shelf) / ".access.log"


def _alog_read(p: Path) -> list[dict]:
    return [json.loads(x) for x in p.read_text(encoding="utf-8").splitlines() if x.strip()] if p.exists() else []


def access_log_append(lib: Path, shelf: str, question: str, results: int) -> None:
    p = _alog(lib, shelf)
    with fsutil.FileLock(p.with_suffix(".lock"), timeout=30):
        rows = _alog_read(p)
        e = {"seq": len(rows) + 1, "ts": fsutil.now_utc_iso(), "actor": audit.actor(), "action": "recall",
             "question_sha256": hashlib.sha256(question.encode("utf-8")).hexdigest(), "question_chars": len(question),
             "results": results, "prev": rows[-1]["hash"] if rows else ZERO}
        e["hash"] = hashlib.sha256(_canon(e)).hexdigest()
        with open(p, "ab") as fh:
            fh.write(json.dumps(e, ensure_ascii=False, separators=(",", ":")).encode("utf-8") + b"\n")
    with __import__("contextlib").suppress(OSError):
        os.chmod(p, 0o600)


def access_log(lib: Path, shelf: str) -> dict:
    if not brain.shelf_meta(lib, shelf)["confidential"]:
        raise BrainError(f"{shelf!r} is not a confidential shelf: only confidential shelves keep an access log")
    rows, prev, problems = _alog_read(_alog(lib, shelf)), ZERO, []
    for i, e in enumerate(rows, 1):
        body = {k: v for k, v in e.items() if k != "hash"}
        if e.get("seq") != i or e.get("prev") != prev or hashlib.sha256(_canon(body)).hexdigest() != e.get("hash"):
            problems.append(f"entry {i} was edited, removed or reordered")
            break
        prev = e["hash"]
    return {"shelf": shelf, "entries": rows, "intact": not problems, "problems": problems,
            "note": "Questions are stored as SHA-256 only. Truncation of the END of this log is not detectable without an anchor."}


# ================================================================ custody export
def custody_export(lib: Path, shelf: str, out, key_env: str = "GIA_CUSTODY_KEY") -> dict:
    lib, out = Path(lib), Path(out)
    meta = brain.shelf_meta(lib, shelf)
    sd = brain.shelf_dir(lib, shelf)
    if _inside(out, lib):
        raise BrainError("write the export OUTSIDE the library")
    raw = (sd / "KNOWLEDGE_GRAPH.json").read_bytes()
    entries, _ = audit.read(lib)
    mine = [e for e in entries if e.get("shelf") == shelf]
    seals = []
    for e in audit.seals(entries).values():
        if e.get("shelf") == shelf:
            rp = sd / ".seals" / (Path(e["detail"].get("snapshot", "")).stem + ".reason.txt")
            seals.append({"seq": e["seq"], "ts": e["ts"], "actor": e["actor"], "sha256": e["detail"].get("sha256"),
                          "reason": rp.read_text(encoding="utf-8").strip() if rp.exists() else e["detail"].get("reason")})
    bundle = {"format": "gia-custody/1", "created": fsutil.now_utc_iso(), "by": audit.actor(), "shelf": shelf,
              "meta": meta, "kg_sha256": fsutil.sha256_bytes(raw), "audit_head": audit.head(lib),
              "chain_findings": [f for f in audit.verify(lib)], "seals": seals, "shelf_audit_entries": mine,
              "access_log": _alog_read(_alog(lib, shelf)) if meta["confidential"] else None,
              "handling": "CONFIDENTIAL: contains seal reasons." if meta["confidential"] else "Shared shelf."}
    body = _canon(bundle)
    key = os.environ.get(key_env)
    sig = {"alg": "HMAC-SHA256", "value": hmac.new(key.encode("utf-8"), body, hashlib.sha256).hexdigest()} if key else \
          {"alg": "none", "note": f"unsigned: set {key_env} to sign. The digest below only detects accidental change."}
    final = {"bundle": bundle, "digest_sha256": hashlib.sha256(body).hexdigest(), "signature": sig}
    out.parent.mkdir(parents=True, exist_ok=True)
    fsutil.atomic_write_bytes(out, json.dumps(final, indent=2, ensure_ascii=False).encode("utf-8"), 0o600)
    return {"written": str(out), "signed": bool(key), "digest_sha256": final["digest_sha256"], "seals": len(seals),
            "chain_ok": not any(f["severity"] == "ERROR" for f in bundle["chain_findings"])}


def custody_verify(path, key_env: str = "GIA_CUSTODY_KEY") -> dict:
    d = json.loads(Path(path).read_text(encoding="utf-8"))
    body = _canon(d["bundle"])
    ok_digest = hashlib.sha256(body).hexdigest() == d.get("digest_sha256")
    sig = d.get("signature", {})
    key = os.environ.get(key_env)
    if sig.get("alg") == "HMAC-SHA256":
        if not key:
            sig_state = f"cannot check: set {key_env}"
            ok_sig = False
        else:
            ok_sig = hmac.compare_digest(hmac.new(key.encode("utf-8"), body, hashlib.sha256).hexdigest(), sig.get("value", ""))
            sig_state = "valid" if ok_sig else "INVALID"
    else:
        sig_state, ok_sig = "unsigned", None
    return {"digest_matches": ok_digest, "signature": sig_state, "ok": bool(ok_digest and ok_sig in (True, None))}


# ================================================================ contradictions
_NUM = re.compile(r"\d")


def contradictions(lib: Path, shelves=None, min_overlap: float = 0.75, cap: int = 3000, include_unconfirmed: bool = False) -> dict:
    """Pairs of nodes of one type and entity whose wording matches but whose numbers differ. Default: both CONFIRMED. With `include_unconfirmed`,
    a pair is reported when AT LEAST ONE side is CONFIRMED (a confirmed figure against an unverified one: the case an auditor most wants to see);
    use a lower `min_overlap` (about 0.5) there, and expect some false positives (two different counts are not a conflict)."""
    if not isinstance(min_overlap, (int, float)) or not 0.2 <= min_overlap <= 1.0:
        raise BrainError("min_overlap must be a number from 0.2 to 1.0")
    mf = brain.load_manifest(lib)
    names = shelves or [s for s in mf["shelves"] if not brain.shelf_meta(lib, s)["confidential"]]
    if len(names) > 1 and any(brain.shelf_meta(lib, s)["confidential"] for s in names):
        raise BrainError("a confidential shelf is checked on its own, never together with others")
    items = []
    for s in names:
        meta = brain.shelf_meta(lib, s)
        for n in brain.shelf_kg(lib, s).get("nodes", []):
            trust = brain.trust_label(n, meta["confidential"])
            if not isinstance(n.get("label"), str) or (trust != "CONFIRMED" and not include_unconfirmed):
                continue
            toks = brain.tokens(n["label"])
            words = frozenset(t for t in toks if not _NUM.search(t))
            nums = frozenset(t for t in toks if _NUM.search(t))
            if len(words) >= 3:
                items.append((s, meta.get("jurisdiction"), n, words, nums, trust))
    postings: dict[str, list[int]] = {}
    for i, it in enumerate(items):
        for w in it[3]:
            postings.setdefault(w, []).append(i)
    seen, pairs, capped = set(), [], False
    for i, (s, jur, n, words, nums, tr) in enumerate(items):
        cands: dict[int, int] = {}
        for w in words:
            lst = postings[w]
            if len(lst) > 200:                       # a word in hundreds of labels says nothing about identity
                continue
            for j in lst:
                if j > i:
                    cands[j] = cands.get(j, 0) + 1
        for j, c in cands.items():
            s2, jur2, n2, words2, nums2, tr2 = items[j]
            if include_unconfirmed and "CONFIRMED" not in (tr, tr2):
                continue
            if n.get("type") != n2.get("type") or n.get("entity") != n2.get("entity") or jur != jur2:
                continue
            jac = len(words & words2) / len(words | words2)
            if jac < min_overlap or nums == nums2 or not (nums or nums2):
                continue
            key = (min(i, j), max(i, j))
            if key in seen:
                continue
            seen.add(key)
            pairs.append({"a": {"shelf": s, "id": n["id"], "label": n["label"], "numbers": sorted(nums), "trust": tr},
                          "b": {"shelf": s2, "id": n2["id"], "label": n2["label"], "numbers": sorted(nums2), "trust": tr2},
                          "wording_overlap": round(jac, 2), "type": n.get("type"), "entity": n.get("entity")})
            if len(pairs) >= cap:
                capped = True
                break
        if capped:
            break
    pairs.sort(key=lambda p: -p["wording_overlap"])
    return {"checked_nodes": len(items), "checked_confirmed_nodes": sum(1 for it in items if it[5] == "CONFIRMED"), "include_unconfirmed": include_unconfirmed, "possible_contradictions": pairs, "capped": capped,
            "note": "Heuristic: similar wording and the same type/entity/jurisdiction but different numbers. A prompt to review "
                    "which one is current; two correct items for different periods are also reported. Not a finding."}


# ================================================================ capture (second brain)
def capture(lib: Path, shelf: str, text: str, tags=None, project: str | None = None, source: str | None = None) -> dict:
    lib = Path(lib)
    if not isinstance(text, str) or not text.strip() or len(text) > 2000 or "\x00" in text:
        raise BrainError("the note must be 1-2000 characters of text")
    meta = brain.shelf_meta(lib, shelf)
    sd = brain.shelf_dir(lib, shelf)
    today = brain._today_local()
    digest = hashlib.sha256(text.strip().encode("utf-8")).hexdigest()[:10]
    nid = f"NOTE-{today.replace('-', '')}-{digest}"
    node = {"id": nid, "type": ag.UNCLASSIFIED, "label": text.strip(), "entity": meta["entity"], "created_date": today,
            "confidence": "Low", "status": "PROPOSED", "evidence_rank": "R5", "origin": "capture",
            "source_location": (source or "capture: typed by owner")[:300], "tags": sorted({t.strip().lower() for t in (tags or []) if t.strip()})[:12]}
    if project:
        node["project"] = project.strip()[:80]
    with brain.shelf_lock(lib, shelf):
        kg = brain.shelf_kg(lib, shelf)
        if any(n.get("id") == nid for n in kg["nodes"]):
            return {"captured": False, "id": nid, "reason": "this exact note is already on the shelf"}
        kg["nodes"].append(node)
        kg["last_updated"] = today
        ag.atomic_write_json(sd / "KNOWLEDGE_GRAPH.json", kg, brain.shelf_mode(meta))
        if meta["confidential"]:
            brain.lock_down(sd)
    audit.append(lib, "capture", shelf, {"id": nid, "chars": len(text)} if not meta["confidential"] else {"id": "withheld (confidential)"},
                 {"KNOWLEDGE_GRAPH.json": fsutil.sha256_file(sd / "KNOWLEDGE_GRAPH.json")})
    return {"captured": True, "id": nid, "trust": "INDICATOR",
            "note": "Notes are unclassified INDICATORS: recall labels them so, and the FINAL gate blocks them until you classify and evidence them."}


# ================================================================ lockdown / brief
def lockdown(lib: Path) -> dict:
    mf = brain.load_manifest(lib)
    done, failed = [], []
    for s in mf["shelves"]:
        try:
            if brain.shelf_meta(lib, s)["confidential"]:
                brain.lock_down(brain.shelf_dir(lib, s))
                done.append(s)
        except (BrainError, brain.RefusedError, fsutil.PermissionUnverifiable) as exc:
            failed.append({"shelf": s, "error": textsafe.display(exc, 200)})
    remaining = {s: len(brain.world_readable_files(brain.shelf_dir(lib, s))) for s in done}
    return {"locked": done, "failed": failed, "still_exposed": {k: v for k, v in remaining.items() if v}}


def brief(lib: Path, project: str, today=None, limit: int = 15) -> dict:
    """Everything the library holds tagged with this project (node `project`, shelf name, or a label match), grouped by trust."""
    lib = Path(lib)
    today = today or brain._today_local()
    key, rows = project.strip().lower(), {"CONFIRMED": [], "PROVISIONAL": [], "INDICATOR": []}
    stale = []
    mf = brain.load_manifest(lib)
    for s in mf["shelves"]:
        meta = brain.shelf_meta(lib, s)
        if meta["confidential"]:
            continue
        for n in brain.shelf_kg(lib, s).get("nodes", []):
            hay = f"{s} {n.get('project', '')} {n.get('label', '')} {' '.join(n.get('tags', []) or [])}".lower()
            if key not in hay:
                continue
            t = brain.trust_label(n, False)
            if len(rows[t]) < limit:
                rows[t].append({"shelf": s, "id": n["id"], "label": n.get("label"), "rank": n.get("evidence_rank") or "UNRANKED"})
            st = brain.staleness(n, meta, today)
            if st:
                stale.append({"shelf": s, "id": n["id"], "state": st})
    return {"project": project, "as_of": today, "by_trust": rows, "needs_revalidation": stale[:limit],
            "note": "Confidential shelves are never included. Trust labels, not order, say what may be relied on."}


# ================================================================ CLI wiring
def register(sub) -> None:
    p = sub.add_parser("anchor-record", help="record the audit head OUTSIDE the library (own hash chain)")
    p.add_argument("lib"); p.add_argument("--file", required=True); p.add_argument("--note", default="")
    p = sub.add_parser("anchor-check", help="prove the audit log was not truncated or rewritten since each recorded anchor")
    p.add_argument("lib"); p.add_argument("--file", required=True)
    p = sub.add_parser("custody-export", help="one self-checking provenance file for a shelf")
    p.add_argument("lib"); p.add_argument("--shelf", required=True); p.add_argument("--out", required=True)
    p = sub.add_parser("custody-verify", help="check a custody export (digest, and HMAC if signed)")
    p.add_argument("file")
    p = sub.add_parser("contradictions", help="possible conflicts between CONFIRMED items (heuristic); --include-unconfirmed also pairs a CONFIRMED item with an unverified one")
    p.add_argument("lib"); p.add_argument("--shelf", action="append")
    p.add_argument("--include-unconfirmed", action="store_true"); p.add_argument("--min-overlap", type=float, default=None, help="0.2-1.0 (default 0.75; 0.5 with --include-unconfirmed)")
    p = sub.add_parser("access-log", help="who recalled from a confidential shelf")
    p.add_argument("lib"); p.add_argument("--shelf", required=True)
    p = sub.add_parser("capture", help="second-brain quick note (always an unclassified INDICATOR)")
    p.add_argument("lib"); p.add_argument("--shelf", required=True); p.add_argument("--text", required=True)
    p.add_argument("--tags", nargs="*"); p.add_argument("--project"); p.add_argument("--source")
    p = sub.add_parser("lockdown", help="(re)apply owner-only protection to every confidential shelf")
    p.add_argument("lib")
    p = sub.add_parser("brief", help="project briefing grouped by trust")
    p.add_argument("lib"); p.add_argument("--project", required=True); p.add_argument("--today")


def run(a, lib) -> int:
    def show(o):
        print(json.dumps(o, indent=2, ensure_ascii=True))
    c = a.cmd
    if c == "anchor-record":
        show(anchor_record(lib, a.file, a.note))
    elif c == "anchor-check":
        f = anchor_check(lib, a.file)
        return 1 if brain._print_findings(f) else 0
    elif c == "custody-export":
        show(custody_export(lib, a.shelf, a.out))
    elif c == "custody-verify":
        r = custody_verify(a.file)
        show(r)
        return 0 if r["ok"] else 1
    elif c == "contradictions":
        mo = a.min_overlap if a.min_overlap is not None else (0.5 if a.include_unconfirmed else 0.75)
        r = contradictions(lib, a.shelf, mo, include_unconfirmed=a.include_unconfirmed)
        show(r)
        return 1 if r["possible_contradictions"] else 0
    elif c == "access-log":
        r = access_log(lib, a.shelf)
        show(r)
        return 0 if r["intact"] else 1
    elif c == "capture":
        show(capture(lib, a.shelf, a.text, a.tags, a.project, a.source))
    elif c == "lockdown":
        r = lockdown(lib)
        show(r)
        return 1 if (r["failed"] or r["still_exposed"]) else 0
    elif c == "brief":
        show(brief(lib, a.project, a.today))
    return 0
