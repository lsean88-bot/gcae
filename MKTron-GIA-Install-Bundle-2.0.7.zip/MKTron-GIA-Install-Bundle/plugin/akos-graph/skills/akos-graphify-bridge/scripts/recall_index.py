"""recall_index.py - persisted recall index (v2.0.2).

A per-shelf SQLite file (`<shelf>/.recall.sqlite`) holding an inverted index of the same tokens `brain._matches` would find.
Recall then reads only the matching rows instead of parsing the whole Knowledge Graph.

Guarantees (and boundaries):
  * Same answers as the scan. The index stores the exact node JSON and uses the same tokeniser and field weights, so
    `recall` returns identical results with or without it (tests/test_recall_index.py proves this on a mixed library).
  * Never stale. The index records the SHA-256 of the KG bytes it was built from; any other hash means "ignore and rebuild".
  * Never required. Missing, corrupt, unreadable or read-only => silently fall back to the scan. GIA_RECALL_INDEX=off disables it.
  * Same confidentiality as its shelf: it lives inside the shelf folder, so the shelf's owner-only protection covers it.
"""
from __future__ import annotations

import json
import os
import sqlite3
import time
from pathlib import Path

import fsutil

NAME = ".recall.sqlite"
FORMAT = "3"   # 3: tokeniser keeps single digits and dotted numbers (indexes built by older formats are ignored and rebuilt)
MIN_BYTES = 1_000_000          # below this a scan is fast enough; 'auto' mode builds only for shelves at least this large


def mode() -> str:
    m = os.environ.get("GIA_RECALL_INDEX", "auto").strip().lower()
    return m if m in ("auto", "always", "off") else "auto"


def path(shelf_dir) -> Path:
    return Path(shelf_dir) / NAME


def _connect_ro(p: Path):
    return sqlite3.connect(f"{p.resolve().as_uri()}?mode=ro", uri=True, timeout=5)


def fresh(shelf_dir, kg_sha: str) -> bool:
    p = path(shelf_dir)
    if not p.exists():
        return False
    try:
        con = _connect_ro(p)
        try:
            meta = dict(con.execute("SELECT key, value FROM meta"))
        finally:
            con.close()
        return meta.get("kg_sha") == kg_sha and meta.get("format") == FORMAT
    except (sqlite3.Error, OSError):
        return False


def build(shelf_dir, kg: dict, kg_sha: str, mode_bits: int, tokens, trust_order) -> bool:
    """Write the index atomically. Returns False (never raises) if it could not be written."""
    import akos_graph as ag
    sd = Path(shelf_dir)
    final, tmp = path(sd), sd / f"{NAME}.{os.getpid()}.tmp"
    try:
        tmp.unlink(missing_ok=True)
        con = sqlite3.connect(str(tmp))
        try:
            con.executescript("PRAGMA journal_mode=OFF; PRAGMA synchronous=OFF;"
                              "CREATE TABLE meta(key TEXT PRIMARY KEY, value TEXT);"
                              "CREATE TABLE nodes(row INTEGER PRIMARY KEY, nid TEXT, conf INTEGER, ev TEXT, trust INTEGER, body TEXT);"
                              "CREATE TABLE post(tok TEXT, row INTEGER, mult REAL);"
                              "CREATE TABLE edges(ord INTEGER PRIMARY KEY, frm TEXT, tto TEXT, body TEXT);")
            node_rows, post_rows = [], []
            for i, n in enumerate(kg.get("nodes", [])):
                if not isinstance(n, dict) or "id" not in n:
                    continue
                label = n.get("label", "")
                label = label if isinstance(label, str) else str(label)
                fields = ((2.0, label), (3.0, str(n["id"])), (0.5, f"{n.get('type', '')} {n.get('entity', '')}"))
                for mult, text in fields:
                    for t in set(tokens(text)):
                        post_rows.append((t, i, mult))
                node_rows.append((i, str(n["id"]), ag.CONF_RANK.get(ag._hs(n.get("confidence")), 0),
                                  n.get("evidence_rank"), trust_order(n), json.dumps(n, ensure_ascii=False)))
            con.executemany("INSERT INTO nodes VALUES (?,?,?,?,?,?)", node_rows)
            con.executemany("INSERT INTO post VALUES (?,?,?)", post_rows)
            con.executemany("INSERT INTO edges VALUES (?,?,?,?)",
                            [(i, str(e.get("from")), str(e.get("to")), json.dumps(e, ensure_ascii=False))
                             for i, e in enumerate(kg.get("edges", [])) if isinstance(e, dict)])
            con.executescript("CREATE INDEX post_tok ON post(tok); CREATE INDEX edges_f ON edges(frm); CREATE INDEX edges_t ON edges(tto);"
                              "CREATE INDEX nodes_nid ON nodes(nid);")
            con.executemany("INSERT INTO meta VALUES (?,?)", [("kg_sha", kg_sha), ("format", FORMAT), ("built", str(int(time.time())))])
            con.commit()
        finally:
            con.close()
        with __import__("contextlib").suppress(OSError):
            os.chmod(tmp, mode_bits)
        os.replace(tmp, final)
        return True
    except (sqlite3.Error, OSError, ValueError):
        with __import__("contextlib").suppress(OSError):
            tmp.unlink(missing_ok=True)
        return False


class Reader:
    """Read-only view used by brain.recall. All methods mirror what the scan computes."""

    def __init__(self, shelf_dir):
        self.con = _connect_ro(path(shelf_dir))

    def close(self):
        self.con.close()

    def counts(self, floor: int, allowed_ev):
        """(examined, excluded_unranked) exactly as the scan counts them."""
        ev_clause, params = "", [floor]
        if allowed_ev is not None:
            ev_clause = f" AND ev IN ({','.join('?' * len(allowed_ev))})"
            params += list(allowed_ev)
        examined = self.con.execute(f"SELECT COUNT(*) FROM nodes WHERE conf >= ?{ev_clause}", params).fetchone()[0]
        unranked = 0
        if allowed_ev is not None:
            from akos_graph import EVIDENCE_RANKS
            marks = ",".join("?" * len(EVIDENCE_RANKS))
            unranked = self.con.execute(f"SELECT COUNT(*) FROM nodes WHERE conf >= ? AND (ev IS NULL OR ev NOT IN ({marks}))",
                                        [floor, *EVIDENCE_RANKS]).fetchone()[0]
        return examined, unranked

    def top(self, weights: dict, floor: int, allowed_ev, limit: int):
        """The `limit` best rows for the DEFAULT ranking, ordered in SQL: -> [(row, score, nid, trust_order)].
        Exact, not approximate: every weight is a multiple of 0.25 so sums are exact in floating point, and the sort key is the
        scan's (score rounded to 3 places desc, trust order, id) with the row number as the final tiebreak (= file order)."""
        self.con.execute("CREATE TEMP TABLE IF NOT EXISTS q(tok TEXT PRIMARY KEY, w REAL)")
        self.con.execute("DELETE FROM q")
        self.con.executemany("INSERT INTO q VALUES (?,?)", list(weights.items()))
        ev = f" AND n.ev IN ({','.join('?' * len(allowed_ev))})" if allowed_ev is not None else ""
        sql = ("SELECT n.row, s.sc, n.nid, n.trust FROM (SELECT p.row AS row, SUM(p.mult * q.w) AS sc FROM post p JOIN q ON q.tok = p.tok GROUP BY p.row) s "
               f"JOIN nodes n ON n.row = s.row WHERE n.conf >= ?{ev} AND s.sc > 0 "
               "ORDER BY ROUND(s.sc, 3) DESC, n.trust ASC, n.nid ASC, n.row ASC LIMIT ?")
        return list(self.con.execute(sql, [floor, *(allowed_ev or []), limit]))

    def candidates(self, weights: dict, floor: int, allowed_ev):
        """-> (matches {row: ([(mult, tok)], nid, trust_order)}, examined, excluded_unranked). allowed_ev None = no rank limit."""
        ev_clause, params = "", [floor]
        if allowed_ev is not None:
            marks = ",".join("?" * len(allowed_ev))
            ev_clause = f" AND ev IN ({marks})"
            params += list(allowed_ev)
        examined = self.con.execute(f"SELECT COUNT(*) FROM nodes WHERE conf >= ?{ev_clause}", params).fetchone()[0]
        unranked = 0
        if allowed_ev is not None:
            from akos_graph import EVIDENCE_RANKS
            marks = ",".join("?" * len(EVIDENCE_RANKS))
            unranked = self.con.execute(f"SELECT COUNT(*) FROM nodes WHERE conf >= ? AND (ev IS NULL OR ev NOT IN ({marks}))",
                                        [floor, *EVIDENCE_RANKS]).fetchone()[0]
        toks = list(weights)
        out: dict[int, list] = {}
        for k in range(0, len(toks), 500):
            chunk = toks[k:k + 500]
            q = (f"SELECT p.row, p.mult, p.tok, n.nid, n.trust FROM post p JOIN nodes n ON n.row = p.row WHERE p.tok IN ({','.join('?' * len(chunk))})"
                 f" AND n.conf >= ?" + (f" AND n.ev IN ({','.join('?' * len(allowed_ev))})" if allowed_ev is not None else ""))
            args = [*chunk, floor] + (list(allowed_ev) if allowed_ev is not None else [])
            for row, mult, tok, nid, trust in self.con.execute(q, args):
                out.setdefault(row, ([], nid, trust))[0].append((mult, tok))
        return out, examined, unranked

    def nodes(self, rows) -> dict[int, dict]:
        out, rows = {}, list(rows)
        for k in range(0, len(rows), 500):
            c = rows[k:k + 500]
            for r, body in self.con.execute(f"SELECT row, body FROM nodes WHERE row IN ({','.join('?' * len(c))})", c):
                out[r] = json.loads(body)
        return out

    def node(self, row: int) -> dict:
        return json.loads(self.con.execute("SELECT body FROM nodes WHERE row = ?", (row,)).fetchone()[0])

    def node_by_id(self, nid: str) -> dict:
        r = self.con.execute("SELECT body FROM nodes WHERE nid = ? ORDER BY row DESC LIMIT 1", (nid,)).fetchone()
        return json.loads(r[0]) if r else {}

    def edges_touching(self, ids: set[str]):
        """Edges touching any id, in the original file order."""
        seen, rows = set(), []
        ids = list(ids)
        for k in range(0, len(ids), 500):
            chunk = ids[k:k + 500]
            m = ",".join("?" * len(chunk))
            for ordn, body in self.con.execute(f"SELECT ord, body FROM edges WHERE frm IN ({m}) OR tto IN ({m})", chunk + chunk):
                if ordn not in seen:
                    seen.add(ordn)
                    rows.append((ordn, json.loads(body)))
        rows.sort(key=lambda r: r[0])
        return [b for _, b in rows]
