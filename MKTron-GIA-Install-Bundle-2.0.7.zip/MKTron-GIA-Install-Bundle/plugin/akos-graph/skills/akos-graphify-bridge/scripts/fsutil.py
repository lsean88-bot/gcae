"""fsutil.py - file-system primitives with explicit guarantees (layer L0).

Guarantees (and their honest boundaries):
  atomic_write_*   readers see the old file or the new file, never a partial one. Temp file in the same directory,
                   fsync, rename. Boundary: power loss before the directory entry is flushed may keep the old file.
  FileLock         one writer at a time across processes (flock; msvcrt on Windows). Re-entrant within a process.
                   Boundary: advisory: only cooperating tools honour it.
  ensure_within    a path must resolve inside a root and cross no symlink on the way.
  tree_chmod       never follows or modifies a symlink.
  replace_dir      directory swap by rename with rollback. Boundary: a kill -9 between the two renames leaves a
                   '.old-<pid>' sibling; recover_pending() puts it back.
  multi_replace    several files replaced all-or-nothing in-process, with restore on failure.
                   Boundary: a kill -9 mid-sequence can leave a mix; the originals are kept as '<name>.pre-<pid>' until done.
"""
from __future__ import annotations

import contextlib
import hashlib
import json
import os
import re
import shutil
import tempfile
import time
from datetime import date, datetime, timezone
from pathlib import Path

from errors import InputError, LockTimeout, RefusedError

try:  # POSIX
    import fcntl
except ImportError:  # Windows
    fcntl = None
    import msvcrt


# ---- atomic writes ----------------------------------------------------------------------------------------
def _fsync_dir(d: Path) -> None:
    if os.name != "posix":
        return
    try:
        fd = os.open(str(d), os.O_RDONLY)
        try:
            os.fsync(fd)
        finally:
            os.close(fd)
    except OSError:
        pass


def _default_fsync() -> bool:
    return not os.environ.get("GIA_NO_FSYNC")      # tests and soak runs may trade durability for speed


def atomic_write_bytes(path, data: bytes, mode: int = 0o644, fsync: bool | None = None) -> None:
    fsync = _default_fsync() if fsync is None else fsync
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
            fh.flush()
            if fsync:
                os.fsync(fh.fileno())
        os.chmod(tmp, mode)
        os.replace(tmp, path)
        if fsync:
            _fsync_dir(path.parent)
    except BaseException:
        with contextlib.suppress(OSError):
            os.unlink(tmp)
        raise


def atomic_write_text(path, text: str, mode: int = 0o644, fsync: bool | None = None) -> None:
    atomic_write_bytes(path, text.encode("utf-8"), mode, fsync)


def dumps_json(data) -> str:
    try:
        return json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False) + "\n"
    except ValueError as exc:
        raise InputError(f"cannot write JSON: {exc}") from None


def atomic_write_json(path, data, mode: int = 0o644, fsync: bool | None = None) -> None:
    atomic_write_text(path, dumps_json(data), mode, fsync)


# ---- hashing ------------------------------------------------------------------------------------------------
def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_file(path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


# ---- locking --------------------------------------------------------------------------------------------------
_HELD: dict[str, list] = {}  # realpath -> [fd, count]  (re-entrancy within one process)


class FileLock:
    """Exclusive inter-process lock on a lock file. `with FileLock(p, timeout=30): ...`"""

    def __init__(self, path, timeout: float = 30.0, poll: float = 0.02):
        self.path, self.timeout, self.poll = Path(path), timeout, poll
        self._key = None

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._key = str(self.path.resolve())
        if self._key in _HELD:
            _HELD[self._key][1] += 1
            return self
        fd = os.open(str(self.path), os.O_RDWR | os.O_CREAT, 0o600)
        deadline = time.monotonic() + self.timeout
        while True:
            try:
                if fcntl:
                    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                else:  # pragma: no cover (Windows)
                    msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
                break
            except (BlockingIOError, PermissionError, OSError):
                if time.monotonic() >= deadline:
                    os.close(fd)
                    raise LockTimeout(f"could not get the lock {self.path.name} within {self.timeout:g}s: "
                                      f"another run is in progress") from None
                time.sleep(self.poll)
        _HELD[self._key] = [fd, 1]
        return self

    def __exit__(self, *exc):
        ent = _HELD.get(self._key)
        if not ent:
            return False
        ent[1] -= 1
        if ent[1] == 0:
            fd = ent[0]
            del _HELD[self._key]
            try:
                if fcntl:
                    fcntl.flock(fd, fcntl.LOCK_UN)
                else:  # pragma: no cover
                    msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
            finally:
                os.close(fd)
        return False


# ---- containment and links ------------------------------------------------------------------------------------
def ensure_within(root, path) -> Path:
    """Return the resolved path if it is inside root and NO component below root is a symlink; else RefusedError.

    The symlink walk uses the lexical (unresolved) path: resolving first would silently follow `alias -> real`
    and hide the link."""
    root_r = Path(root).resolve()
    p = Path(path)
    if not p.is_absolute():
        p = root_r / p
    lex = Path(os.path.normpath(p))                       # collapses '..' WITHOUT following links
    rel = None
    for base in (root_r, Path(os.path.normpath(Path(root).absolute()))):
        try:
            rel = lex.relative_to(base)
            break
        except ValueError:
            continue
    if rel is None:
        raise RefusedError(f"{path} is outside {root} (path traversal refused)")
    cur = root_r
    for part in rel.parts:
        cur = cur / part
        if cur.is_symlink():
            raise RefusedError(f"{cur} is a symbolic link; links inside a library are refused")
    final = (root_r / rel).resolve()
    try:
        final.relative_to(root_r)
    except ValueError:
        raise RefusedError(f"{path} resolves outside {root} (refused)") from None
    return final


def find_symlinks(path) -> list[str]:
    out = []
    for root, dirs, files in os.walk(path, followlinks=False):
        for n in dirs + files:
            fp = os.path.join(root, n)
            if os.path.islink(fp):
                out.append(fp)
    return out


def tree_chmod(path, dir_mode: int, file_mode: int) -> list[str]:
    """chmod a tree. Never follows or modifies symlinks. Returns the symlinks it skipped."""
    skipped = []
    path = Path(path)
    if os.name == "nt":                          # NTFS has no POSIX modes: owner-only means an explicit ACL
        if path.exists() and not path.is_symlink() and not (dir_mode & 0o077):
            win_lockdown(path)
        return skipped
    if os.name != "posix" or not path.exists() or path.is_symlink():
        return skipped
    os.chmod(path, dir_mode)
    for root, dirs, files in os.walk(path, followlinks=False):
        for d in list(dirs):
            dp = os.path.join(root, d)
            if os.path.islink(dp):
                skipped.append(dp)
                dirs.remove(d)
            else:
                os.chmod(dp, dir_mode)
        for f in files:
            fp = os.path.join(root, f)
            if os.path.islink(fp):
                skipped.append(fp)
                continue
            with contextlib.suppress(OSError):
                os.chmod(fp, file_mode)
    return skipped


def loose_files(path, mask: int = 0o077) -> list[str]:
    """Files readable/writable by group or other (POSIX). Symlinks are ignored, not followed."""
    if os.name == "nt":
        return win_loose_files(path)
    if os.name != "posix" or not Path(path).exists():
        return []
    bad = []
    for root, dirs, files in os.walk(path, followlinks=False):
        for f in files:
            fp = os.path.join(root, f)
            if not os.path.islink(fp) and os.lstat(fp).st_mode & mask:
                bad.append(fp)
    return bad


# ---- Windows owner-only protection (v2.0.2) ----------------------------------------------------------------------------
class PermissionUnverifiable(RuntimeError):
    """The permissions of a confidential folder could not be set or read. Callers must fail CLOSED (treat as exposed)."""


def _icacls(*args, timeout: int = 180):
    import subprocess
    try:
        return subprocess.run(["icacls", *map(str, args)], capture_output=True, text=True, timeout=timeout,
                              encoding="utf-8", errors="replace")
    except (OSError, subprocess.SubprocessError) as exc:
        raise PermissionUnverifiable(f"icacls could not run: {exc}") from exc


def _me() -> tuple[str, str, str]:
    """(DOMAIN\\user, user, SID) of the current account. The SID is what the permission check trusts."""
    import subprocess
    usr, dom = os.environ.get("USERNAME", ""), os.environ.get("USERDOMAIN", "")
    sid = ""
    try:
        w = subprocess.run(["whoami", "/user", "/fo", "csv", "/nh"], capture_output=True, text=True, timeout=30)
        m = re.search(r'"(S-1-[0-9-]+)"', w.stdout)
        sid = m.group(1) if m else ""
    except (OSError, subprocess.SubprocessError):
        pass
    return (f"{dom}\\{usr}" if dom and usr else usr), usr.lower(), sid


# trustees that may appear on an owner-only folder: SYSTEM, local Administrators, Owner Rights, Creator Owner/Group, TrustedInstaller
_OK_ALIASES = {"SY", "BA", "OW", "CO", "CG"}
_OK_SIDS = {"S-1-5-18", "S-1-5-32-544", "S-1-3-0", "S-1-3-4", "S-1-3-1"}
_ACE = re.compile(r"\(([A-Za-z]{1,2});[^;]*;[^;]*;[^;]*;[^;]*;([^)]+)\)")


def win_lockdown(path) -> None:
    """Make a folder tree owner-only: drop inherited access, remove every other explicit entry on the folder, grant the current
    user and SYSTEM full control WITH inheritance, then reset every child to inherit from the folder (so files created later
    are protected too). Idempotent. Raises PermissionUnverifiable on failure."""
    who, short, _ = _me()
    if not short:
        raise PermissionUnverifiable("USERNAME is not set; cannot build an owner-only ACL")
    path = Path(path)
    r = _icacls(path, "/inheritance:r", "/C", "/Q")
    if r.returncode != 0:
        raise PermissionUnverifiable(f"icacls failed ({r.returncode}): {(r.stdout + r.stderr).strip()[:200]}")
    for sid in win_root_extra_sids(path):
        _icacls(path, "/remove", f"*{sid}", "/C", "/Q")          # grant:r only replaces the NAMED accounts; drop every other entry
    r = _icacls(path, "/grant:r", f"{who}:(OI)(CI)F", "/grant:r", "*S-1-5-18:(OI)(CI)F", "/C", "/Q")
    if r.returncode != 0:
        raise PermissionUnverifiable(f"icacls failed ({r.returncode}): {(r.stdout + r.stderr).strip()[:200]}")
    if any(path.iterdir()):
        r = _icacls(str(path / "*"), "/reset", "/T", "/C", "/Q")
        if r.returncode != 0:
            raise PermissionUnverifiable(f"icacls reset failed ({r.returncode}): {(r.stdout + r.stderr).strip()[:200]}")
    left = win_loose_files(path)
    if left:
        raise PermissionUnverifiable(f"{len(left)} entr{'y' if len(left) == 1 else 'ies'} still grant access to other accounts (e.g. {Path(left[0]).name})")


_ALIAS_SID = {"WD": "S-1-1-0", "AU": "S-1-5-11", "BU": "S-1-5-32-545", "IU": "S-1-5-4", "NU": "S-1-5-2", "AN": "S-1-5-7",
              "SU": "S-1-5-6", "LS": "S-1-5-19", "NS": "S-1-5-20", "RC": "S-1-5-12", "BG": "S-1-5-32-546", "PU": "S-1-5-32-547",
              "RU": "S-1-5-32-554", "LU": "S-1-5-32-559", "AC": "S-1-15-2-1", "OW": "S-1-3-4", "SY": "S-1-5-18", "BA": "S-1-5-32-544"}


def win_root_extra_sids(path) -> list[str]:
    """SIDs of every allow-entry on the folder itself that is not the owner/SYSTEM/admins (read from SDDL, so no text parsing)."""
    _, _, my_sid = _me()
    first = next(iter(win_sddl(path).values()), "")
    out = []
    for ace_type, trustee in _ACE.findall(first):
        t = trustee.strip()
        if t.upper() in _OK_ALIASES or t in _OK_SIDS or t == my_sid or t.startswith("S-1-5-80-"):
            continue
        sid = _ALIAS_SID.get(t.upper()) or (t if t.startswith("S-1-") else None)
        if sid is None:
            raise PermissionUnverifiable(f"unrecognised trustee {t!r} on the folder; cannot remove it safely")
        out.append(sid)
    return sorted(set(out))


def win_sddl(path) -> dict[str, str]:
    """{entry (relative to path's parent): SDDL} for the folder tree, via `icacls /save` (SIDs: no locale, no path-with-spaces ambiguity)."""
    import tempfile
    d = Path(tempfile.mkdtemp(prefix="gia-acl-"))
    try:
        out = d / "acl.txt"
        r = _icacls(path, "/save", out, "/T", "/C", "/Q")
        if r.returncode != 0 or not out.exists():
            raise PermissionUnverifiable(f"icacls /save failed ({r.returncode}): {(r.stdout + r.stderr).strip()[:200]}")
        raw = out.read_bytes()
        text = raw.decode("utf-16-le", "replace").lstrip("﻿") if b"\x00" in raw[:4] else raw.decode("utf-8", "replace")
    finally:
        shutil.rmtree(d, ignore_errors=True)
    entries, cur = {}, None
    for line in text.splitlines():
        line = line.strip("\r\n")
        if not line:
            continue
        if line.startswith("D:") or line.startswith("O:") or line.startswith("G:"):
            if cur is not None:
                entries[cur] = line
        else:
            cur = line
    return entries


def win_loose_files(path) -> list[str]:
    """Entries under `path` that grant ANY access to an account other than the owner, SYSTEM or local administrators.
    Anything unrecognised counts as exposed (fail closed)."""
    path = Path(path)
    if not path.exists():
        return []
    _, _, my_sid = _me()
    bad = []
    for entry, sddl in win_sddl(path).items():
        for ace_type, trustee in _ACE.findall(sddl):
            if ace_type.upper() not in ("A", "OA", "XA", "ZA"):      # deny entries do not expose anything
                continue
            t = trustee.strip()
            if t.upper() in _OK_ALIASES or t in _OK_SIDS or t == my_sid or t.startswith("S-1-5-80-"):
                continue
            bad.append(str(path.parent / entry))
            break
    return bad


# ---- crash-safe replacement ----------------------------------------------------------------------------------------
def replace_dir(staging, dst) -> None:
    """Swap a fully built staging directory into place. Old content is restored if the swap fails."""
    staging, dst = Path(staging), Path(dst)
    old = dst.with_name(f"{dst.name}.old-{os.getpid()}")
    if old.exists():
        shutil.rmtree(old, ignore_errors=True)
    had = dst.exists()
    if had:
        os.rename(dst, old)
    try:
        os.rename(staging, dst)
    except BaseException:
        if had and old.exists() and not dst.exists():
            os.rename(old, dst)
        raise
    if had:
        shutil.rmtree(old, ignore_errors=True)


_OLD = re.compile(r"^(?P<base>.+)\.old-(?P<pid>\d+)$")


def recover_pending(parent, names=None) -> list[str]:
    """If a swap was killed after the first rename, restore '<name>.old-<pid>' when '<name>' is missing.
    Only names matching exactly '.old-<digits>' are touched, and only those in `names` when given, so a user's own
    folder such as 'foo.old-2025-backup' can never be renamed over something."""
    fixed = []
    parent = Path(parent)
    if not parent.is_dir():
        return fixed
    for entry in sorted(parent.iterdir()):
        m = _OLD.match(entry.name)
        if not m or not entry.is_dir() or entry.is_symlink():
            continue
        if names is not None and m.group("base") not in names:
            continue
        target = entry.with_name(m.group("base"))
        if not target.exists():
            os.rename(entry, target)
            fixed.append(str(target))
    return fixed


def multi_replace(files: dict) -> None:
    """Replace several files all-or-nothing. files: {Path: str|bytes}. Restores the originals on any failure."""
    items = [(Path(p), v.encode("utf-8") if isinstance(v, str) else v) for p, v in files.items()]
    originals = {p: (p.read_bytes() if p.exists() else None) for p, _ in items}
    modes = {p: (os.stat(p).st_mode & 0o777 if p.exists() else 0o644) for p, _ in items}
    done = []
    try:
        for p, data in items:
            atomic_write_bytes(p, data, modes[p])
            done.append(p)
    except BaseException:
        for p in reversed(done):
            orig = originals[p]
            try:
                if orig is None:
                    p.unlink()
                else:
                    atomic_write_bytes(p, orig, modes[p])
            except OSError:
                pass
        raise


def clean_temp(root, max_age: float | None = None) -> list[str]:
    """Remove leftover '.<name>.<random>.tmp' files from killed writes. Only files older than max_age seconds
    (default 600, env GIA_TMP_MAX_AGE) are removed, so a writer that is running right now is never disturbed."""
    if max_age is None:
        max_age = float(os.environ.get("GIA_TMP_MAX_AGE", 600))
    removed, now = [], time.time()
    for r, dirs, files in os.walk(root, followlinks=False):
        dirs[:] = [d for d in dirs if not os.path.islink(os.path.join(r, d))]
        for f in files:
            if f.startswith(".") and f.endswith(".tmp"):
                fp = os.path.join(r, f)
                try:
                    if not os.path.islink(fp) and now - os.lstat(fp).st_mtime >= max_age:
                        os.unlink(fp)
                        removed.append(fp)
                except OSError:
                    pass
    return removed


# ---- time ----------------------------------------------------------------------------------------------------------
def now_utc_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def today_local() -> str:
    """The user's LOCAL calendar date. GIA_TODAY=YYYY-MM-DD overrides (reproducible runs, tests)."""
    forced = os.environ.get("GIA_TODAY")
    if forced:
        try:
            return date.fromisoformat(forced).isoformat()
        except ValueError:
            raise InputError(f"GIA_TODAY={forced!r} is not YYYY-MM-DD") from None
    return datetime.now().astimezone().date().isoformat()
