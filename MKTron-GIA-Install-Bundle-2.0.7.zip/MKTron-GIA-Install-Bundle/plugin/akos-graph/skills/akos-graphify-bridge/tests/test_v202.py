"""v2.0.2: Windows owner-only protection, persisted recall index, anchors, custody export, contradictions,
access log, capture, project brief. Each guarantee has an attack test, not only a happy path."""
import json, os, random, subprocess, sys
from pathlib import Path
import pytest

SCRIPTS = Path(__file__).resolve().parent.parent / "scripts"
sys.path.insert(0, str(SCRIPTS))
import akos_graph as ag, audit, brain, extras, fsutil, recall_index  # noqa: E402
from brain import BrainError  # noqa: E402

BRAIN = SCRIPTS / "brain.py"


def node(i, label, typ="Regulation", conf="High", rank="R1", ent="Group", **kw):
    return {"id": i, "type": typ, "label": label, "entity": ent, "created_date": "2026-01-01", "confidence": conf,
            "source_location": "test", "evidence_rank": rank, **kw}


def put(lib, shelf, nodes, edges=()):
    p = Path(lib) / "shelves" / shelf / "KNOWLEDGE_GRAPH.json"
    kg = json.loads(p.read_text(encoding="utf-8"))
    kg["nodes"], kg["edges"] = list(nodes), list(edges)
    ag.atomic_write_json(p, kg, 0o600 if brain.shelf_meta(lib, shelf)["confidential"] else 0o644)


@pytest.fixture
def lib(tmp_path):
    L = tmp_path / "group lib ñ தமிழ்"
    brain.init_library(L)
    brain.add_shelf(L, "tn-statutory", "statutory", "Group", review_days=90, jurisdiction="Tamil Nadu")
    brain.add_shelf(L, "inv-x", "investigation", "Group")
    brain.add_shelf(L, "proj-a", "project", "Group")
    return L


# ------------------------------------------------------------------------------------------ owner-only (W1)
def test_confidential_shelf_is_owner_only_and_still_readable_by_its_owner(lib):
    sd = lib / "shelves" / "inv-x"
    assert fsutil.loose_files(sd) == []
    put(lib, "inv-x", [node("A-1", "secret ACMEKICKBACK vendor")])
    assert fsutil.loose_files(sd) == []                                   # a file written later is protected too
    assert "ACMEKICKBACK" in (sd / "KNOWLEDGE_GRAPH.json").read_text(encoding="utf-8")


def test_guard_flags_a_confidential_shelf_that_someone_else_can_read(lib):
    sd = lib / "shelves" / "inv-x"
    if os.name == "nt":
        subprocess.run(["icacls", str(sd), "/grant", "*S-1-1-0:(OI)(CI)R"], check=True, capture_output=True)   # Everyone: read
        subprocess.run(["icacls", str(sd / "KNOWLEDGE_GRAPH.json"), "/grant", "*S-1-1-0:R"], check=True, capture_output=True)
    else:
        os.chmod(sd / "KNOWLEDGE_GRAPH.json", 0o644)
    codes = {f["code"] for f in brain.guard(lib)}
    assert "CONFIDENTIAL_WORLD_READABLE" in codes
    r = extras.lockdown(lib)                                              # the repair command
    assert r["still_exposed"] == {} and r["failed"] == []
    assert "CONFIDENTIAL_WORLD_READABLE" not in {f["code"] for f in brain.guard(lib)}


def test_guard_fails_closed_when_permissions_cannot_be_read(lib, monkeypatch):
    def boom(_):
        raise fsutil.PermissionUnverifiable("simulated: icacls missing")
    monkeypatch.setattr(brain, "world_readable_files", boom)
    f = [x for x in brain.guard(lib) if x["code"] == "CONFIDENTIAL_PERMISSIONS_UNVERIFIABLE"]
    assert f and f[0]["severity"] == "ERROR"


def test_lock_down_failure_refuses_rather_than_pretending(lib, monkeypatch):
    monkeypatch.setattr(fsutil, "tree_chmod", lambda *a, **k: (_ for _ in ()).throw(fsutil.PermissionUnverifiable("no")))
    with pytest.raises(brain.RefusedError):
        brain.lock_down(lib / "shelves" / "inv-x")


# ------------------------------------------------------------------------------------------ recall index (W4)
def _synthetic(n, rnd):
    words = "payroll minimum wage skilled worker notification EPF GST contract labour dialysis scrap tooling overtime bonus".split()
    out = []
    for i in range(n):
        lab = " ".join(rnd.sample(words, 4)) + (" Nómina cuotas" if i % 17 == 0 else "") + (" ஊதிய பதிவேடு" if i % 29 == 0 else "")
        out.append(node(f"N-{i:04d}", lab, rank=rnd.choice(["R1", "R2", "R3", "R4", "R5", None]),
                        conf=rnd.choice(["100%", "High", "Medium", "Low"]), typ=rnd.choice(["Regulation", "Risk", "Control"]),
                        **({"review_by": rnd.choice(["2020-01-01", "2099-01-01", "April 2026", ""])} if i % 3 == 0 else {})))
    return out


@pytest.mark.parametrize("q,kw", [("minimum wage skilled", {}), ("nomina cuotas", {}), ("ஊதிய", {}), ("payroll bonus", {"ranking": "idf"}),
                                  ("EPF", {"max_rank": "R2"}), ("gst", {"min_conf": "High", "limit": 3}), ("nothing-matches-xyz", {})])
def test_index_gives_identical_answers_to_the_scan(lib, monkeypatch, q, kw):
    rnd = random.Random(7)
    nodes = _synthetic(600, rnd)
    edges = [{"from": nodes[i]["id"], "to": nodes[(i * 7 + 1) % 600]["id"], "relationship": "relates_to", "evidence": "t", "confidence": "High"}
             for i in range(0, 600, 2)]
    put(lib, "tn-statutory", nodes, edges)
    args = dict(question=q, shelves=["tn-statutory"], today="2026-06-01", min_conf=kw.get("min_conf", "Low"),
                limit=kw.get("limit", 8), max_rank=kw.get("max_rank"), ranking=kw.get("ranking", "score"))
    monkeypatch.setenv("GIA_RECALL_INDEX", "off")
    scan = brain.recall(lib, **args)
    monkeypatch.setenv("GIA_RECALL_INDEX", "always")
    first = brain.recall(lib, **args)                                     # builds the index
    again = brain.recall(lib, **args)                                     # reads it
    assert recall_index.path(lib / "shelves" / "tn-statutory").exists()
    assert first == scan and again == scan


def test_index_is_never_stale_and_survives_corruption(lib, monkeypatch):
    monkeypatch.setenv("GIA_RECALL_INDEX", "always")
    sd = lib / "shelves" / "tn-statutory"
    put(lib, "tn-statutory", [node("A", "minimum wage skilled")])
    assert [r["id"] for r in brain.recall(lib, "minimum wage", ["tn-statutory"])["results"]] == ["A"]
    put(lib, "tn-statutory", [node("A", "minimum wage skilled"), node("B", "minimum wage unskilled")])   # KG changed
    assert {r["id"] for r in brain.recall(lib, "minimum wage", ["tn-statutory"])["results"]} == {"A", "B"}
    recall_index.path(sd).write_bytes(b"this is not a database")                                           # corrupted
    assert {r["id"] for r in brain.recall(lib, "minimum wage", ["tn-statutory"])["results"]} == {"A", "B"}


def test_index_off_never_creates_a_file(lib, monkeypatch):
    monkeypatch.setenv("GIA_RECALL_INDEX", "off")
    put(lib, "tn-statutory", [node("A", "minimum wage")])
    brain.recall(lib, "minimum wage", ["tn-statutory"])
    assert not recall_index.path(lib / "shelves" / "tn-statutory").exists()


def test_the_index_of_a_confidential_shelf_stays_owner_only(lib, monkeypatch):
    monkeypatch.setenv("GIA_RECALL_INDEX", "always")
    put(lib, "inv-x", [node("A", "kickback vendor tooling")])
    brain.recall(lib, "kickback", ["inv-x"])
    assert recall_index.path(lib / "shelves" / "inv-x").exists()
    assert fsutil.loose_files(lib / "shelves" / "inv-x") == []


# ------------------------------------------------------------------------------------------ anchors (W5)
def _seal_some(lib):
    put(lib, "tn-statutory", [node("A", "minimum wage skilled")])
    brain.seal(lib, "tn-statutory", "reviewed against the portal")
    brain.seal(lib, "tn-statutory", "second review")


def test_anchor_detects_truncation_and_rewrite(lib, tmp_path):
    _seal_some(lib)
    a = tmp_path / "outside" / "anchors.jsonl"
    extras.anchor_record(lib, a)
    assert extras.anchor_check(lib, a) == []
    entries = (lib / "audit.log").read_bytes().splitlines(keepends=True)
    good = b"".join(entries)
    (lib / "audit.log").write_bytes(b"".join(entries[:-2]))                                     # truncate the end
    assert "LOG_TRUNCATED" in {f["code"] for f in extras.anchor_check(lib, a)}
    forged = [json.loads(x) for x in entries]
    forged[-1]["detail"]["reason"] = "forged"
    forged[-1]["hash"] = audit.entry_hash(forged[-1])
    (lib / "audit.log").write_bytes(b"".join(json.dumps(e, separators=(",", ":")).encode() + b"\n" for e in forged))
    assert "LOG_REWRITTEN" in {f["code"] for f in extras.anchor_check(lib, a)}
    (lib / "audit.log").write_bytes(good)
    assert extras.anchor_check(lib, a) == []


def test_anchor_file_tampering_and_inside_library_refused(lib, tmp_path):
    _seal_some(lib)
    a = tmp_path / "anchors.jsonl"
    extras.anchor_record(lib, a); extras.anchor_record(lib, a, "second")
    lines = a.read_text().splitlines()
    a.write_text(lines[1] + "\n")                                                                # drop the first record
    assert "ANCHOR_FILE_TAMPERED" in {f["code"] for f in extras.anchor_check(lib, a)}
    with pytest.raises(BrainError):
        extras.anchor_record(lib, lib / "anchors.jsonl")


def test_seal_auto_anchors_when_configured(lib, tmp_path, monkeypatch):
    a = tmp_path / "ext" / "a.jsonl"
    monkeypatch.setenv("GIA_ANCHOR_FILE", str(a))
    put(lib, "tn-statutory", [node("A", "minimum wage")])
    r = brain.seal(lib, "tn-statutory", "ok")
    extras.auto_anchor(lib, None, r)
    assert r["anchored_to"] == str(a) and extras.anchor_check(lib, a) == []


# ------------------------------------------------------------------------------------------ custody export
def test_custody_export_signs_and_detects_tampering(lib, tmp_path, monkeypatch):
    put(lib, "inv-x", [node("A", "kickback")])
    brain.seal(lib, "inv-x", "reviewed: names ACMEKICKBACK")
    monkeypatch.setenv("GIA_CUSTODY_KEY", "k-test")
    out = tmp_path / "exp" / "custody.json"
    r = extras.custody_export(lib, "inv-x", out)
    assert r["signed"] and r["chain_ok"] and extras.custody_verify(out)["ok"]
    d = json.loads(out.read_text()); d["bundle"]["seals"][0]["reason"] = "changed"
    out.write_text(json.dumps(d))
    v = extras.custody_verify(out)
    assert not v["ok"] and not v["digest_matches"]
    d2 = json.loads(out.read_text()); d2["digest_sha256"] = __import__("hashlib").sha256(extras._canon(d2["bundle"])).hexdigest()
    out.write_text(json.dumps(d2))                                                               # attacker re-computes the digest
    assert extras.custody_verify(out)["signature"] == "INVALID"                                  # ... but cannot forge the HMAC
    with pytest.raises(BrainError):
        extras.custody_export(lib, "inv-x", lib / "x.json")


# ------------------------------------------------------------------------------------------ contradictions
def test_contradictions_flags_same_subject_different_number_only(lib):
    put(lib, "tn-statutory", [
        node("R1", "Tamil Nadu minimum wage skilled worker daily rate 512"),
        node("R2", "Tamil Nadu minimum wage skilled worker daily rate 540"),
        node("R3", "Tamil Nadu minimum wage skilled worker daily rate 512 duplicate"),   # same number: not a conflict
        node("R4", "Overtime payment rule double rate", typ="Policy"),
        node("R5", "Overtime payment rule double rate", typ="Policy"),                   # identical, no numbers: nothing to conflict
        node("R6", "Maharashtra minimum wage skilled worker daily rate 600", ent="MKAPL-ST"),   # other entity
        node("R7", "Tamil Nadu minimum wage skilled worker daily rate 999", conf="Low"),        # not CONFIRMED
    ])
    pairs = extras.contradictions(lib)["possible_contradictions"]
    got = {frozenset((p["a"]["id"], p["b"]["id"])) for p in pairs}
    assert frozenset(("R1", "R2")) in got
    assert not any("R4" in g or "R5" in g or "R6" in g or "R7" in g for g in got)


# ------------------------------------------------------------------------------------------ access log
def test_access_log_records_confidential_recalls_without_the_question(lib):
    put(lib, "inv-x", [node("A", "kickback vendor")])
    brain.recall(lib, "ACMEKICKBACK vendor", ["inv-x"])
    brain.recall(lib, "kickback", ["inv-x"])
    log = extras.access_log(lib, "inv-x")
    assert log["intact"] and len(log["entries"]) == 2
    assert "ACMEKICKBACK" not in json.dumps(log) and "ACMEKICKBACK" not in (lib / "audit.log").read_text(encoding="utf-8")
    p = lib / "shelves" / "inv-x" / ".access.log"
    rows = p.read_text().splitlines()
    p.write_text(rows[1] + "\n")                                                                  # delete the first record
    assert not extras.access_log(lib, "inv-x")["intact"]
    with pytest.raises(BrainError):
        extras.access_log(lib, "tn-statutory")


def test_shared_recall_writes_no_access_log(lib):
    put(lib, "tn-statutory", [node("A", "minimum wage")])
    brain.recall(lib, "minimum wage", ["tn-statutory"])
    assert not (lib / "shelves" / "tn-statutory" / ".access.log").exists()


# ------------------------------------------------------------------------------------------ capture / brief (second brain)
def test_capture_is_always_an_unclassified_indicator_and_blocked_at_final(lib):
    r = extras.capture(lib, "proj-a", "Call Ravi about the CLD-14 sampling plan", tags=["CLD-14", "Sampling"], project="CLD-14")
    assert r["captured"] and r["trust"] == "INDICATOR"
    kg = brain.shelf_kg(lib, "proj-a")
    n = kg["nodes"][0]
    assert brain.trust_label(n) == "INDICATOR" and n["type"] == ag.UNCLASSIFIED and n["tags"] == ["cld-14", "sampling"]
    assert "TYPE_UNCLASSIFIED" in {i["code"] for i in ag.validate_kg(kg, "final") if i["severity"] == "ERROR"}
    assert extras.capture(lib, "proj-a", "Call Ravi about the CLD-14 sampling plan")["captured"] is False   # idempotent
    for bad in ("", " ", "x" * 2001, "a\x00b"):
        with pytest.raises(BrainError):
            extras.capture(lib, "proj-a", bad)


def test_capture_into_confidential_shelf_is_withheld_from_the_shared_log(lib):
    extras.capture(lib, "inv-x", "witness says ACMEKICKBACK")
    assert "ACMEKICKBACK" not in (lib / "audit.log").read_text(encoding="utf-8")
    assert fsutil.loose_files(lib / "shelves" / "inv-x") == []


def test_brief_groups_by_trust_and_never_includes_confidential(lib):
    put(lib, "tn-statutory", [node("A", "CLD-14 minimum wage notice", rank="R1")])
    extras.capture(lib, "proj-a", "CLD-14 follow up", project="CLD-14")
    extras.capture(lib, "inv-x", "CLD-14 SECRET-ZZZ")
    b = extras.brief(lib, "CLD-14")
    assert b["by_trust"]["CONFIRMED"] and b["by_trust"]["INDICATOR"]
    assert "SECRET-ZZZ" not in json.dumps(b)


# ------------------------------------------------------------------------------------------ CLI
def test_new_commands_run_through_the_cli_with_the_exit_code_contract(lib, tmp_path):
    env = {**os.environ, "GIA_NO_FSYNC": "1", "PYTHONUTF8": "1"}
    def run(*a):
        return subprocess.run([sys.executable, str(BRAIN), *map(str, a)], capture_output=True, text=True, env=env)
    assert run("capture", lib, "--shelf", "proj-a", "--text", "hello world note").returncode == 0
    assert run("capture", lib, "--shelf", "proj-a", "--text", "").returncode == 2
    assert run("brief", lib, "--project", "hello").returncode == 0
    assert run("lockdown", lib).returncode == 0
    a = tmp_path / "anch.jsonl"
    assert run("anchor-record", lib, "--file", a).returncode == 0
    assert run("anchor-check", lib, "--file", a).returncode == 0
    assert run("anchor-check", lib, "--file", tmp_path / "missing.jsonl").returncode == 1
    r = run("anchor-record", lib, "--file", lib / "inside.jsonl")
    assert r.returncode == 2 and "Traceback" not in r.stderr


def test_index_command_builds_the_recall_index_and_a_plain_recall_never_does(lib, monkeypatch):
    monkeypatch.setenv("GIA_RECALL_INDEX", "auto")
    monkeypatch.setattr(recall_index, "MIN_BYTES", 0)                      # treat every shelf as large
    put(lib, "tn-statutory", [node("A", "minimum wage skilled")])
    sd = lib / "shelves" / "tn-statutory"
    brain.recall(lib, "minimum wage", ["tn-statutory"])
    assert not recall_index.path(sd).exists()                              # a question must never pay the build cost
    rep = brain.index_library(lib)
    assert rep["shelves"]["tn-statutory"]["recall_index"] is True and recall_index.path(sd).exists()
    assert [r["id"] for r in brain.recall(lib, "minimum wage", ["tn-statutory"])["results"]] == ["A"]


@pytest.mark.parametrize("limit", [1, 3, 8, 50])
def test_sql_ranked_multi_shelf_recall_equals_the_scan_even_with_heavy_ties(lib, monkeypatch, limit):
    rnd = random.Random(11)
    same = [node(f"T-{i:03d}", "minimum wage skilled", conf=rnd.choice(["High", "Medium", "100%"]), rank=rnd.choice(["R1", "R4", "R5", None])) for i in range(40)]
    put(lib, "tn-statutory", same + _synthetic(200, rnd))
    put(lib, "proj-a", [dict(n, id=n["id"].replace("T-", "P-")) for n in same[:25]])
    monkeypatch.setenv("GIA_RECALL_INDEX", "off")
    scan = brain.recall(lib, "minimum wage skilled", limit=limit, today="2026-06-01")
    monkeypatch.setenv("GIA_RECALL_INDEX", "always")
    brain.recall(lib, "minimum wage skilled", limit=limit, today="2026-06-01")        # builds
    assert brain.recall(lib, "minimum wage skilled", limit=limit, today="2026-06-01") == scan


def test_numbers_in_audit_text_are_searchable_single_digits_and_dotted_clauses(lib, monkeypatch):
    assert "7" in brain.tokens("Rule 7")
    assert "4.2" in brain.tokens("clause 4.2") and "a" not in brain.tokens("a b c")
    put(lib, "tn-statutory", [node("R7", "Policy", "Written agreement rule 7 for contractors"), node("R8", "Policy", "Written agreement rule 8 for contractors"),
                              node("C42", "Policy", "Engagement policy clause 4.2 service agreement"), node("C43", "Policy", "Engagement policy clause 4.3 service agreement")])
    for mode in ("off", "always"):
        monkeypatch.setenv("GIA_RECALL_INDEX", mode)
        for q, want in (("rule 7 agreement", "R7"), ("rule 8 agreement", "R8"), ("clause 4.2 agreement", "C42"), ("clause 4.3 agreement", "C43")):
            assert brain.recall(lib, q, ["tn-statutory"])["results"][0]["id"] == want, (mode, q)


def test_contradictions_can_pair_a_confirmed_figure_with_an_unverified_one_when_asked(lib):
    put(lib, "tn-statutory", [
        node("N512", "Minimum wage, skilled category, zone A: 512 rupees per day, effective 2025-04-01 (notification SYN/2025/114)", typ="Regulation", rank="R1", conf="100%"),
        node("N540", "Minimum wage, skilled category, zone A: 540 rupees per day per plant circular summary (no notification number, no review date)", typ="Regulation", rank="R4", conf="Low"),
        node("W9", "Of the exceptions 9 were small contractors with fewer than 20 workers", typ="Evidence", rank="R2"),
        node("W5", "Of the exceptions 5 were large contractors", typ="Evidence", rank="R2")])
    default = extras.contradictions(lib)
    assert default["possible_contradictions"] == []                                   # unchanged default: CONFIRMED vs CONFIRMED only
    wide = extras.contradictions(lib, min_overlap=0.5, include_unconfirmed=True)
    pairs = {frozenset((p["a"]["id"], p["b"]["id"])): p for p in wide["possible_contradictions"]}
    assert frozenset(("N512", "N540")) in pairs
    p = pairs[frozenset(("N512", "N540"))]
    assert {p["a"]["trust"], p["b"]["trust"]} == {"CONFIRMED", "INDICATOR"}
    with pytest.raises(BrainError):
        extras.contradictions(lib, min_overlap=0.05)


def test_contradictions_flags_through_the_cli(lib, tmp_path):
    put(lib, "tn-statutory", [node("A", "Minimum wage skilled zone A 512 rupees per day notification", typ="Regulation", rank="R1"),
                              node("B", "Minimum wage skilled zone A 540 rupees per day circular summary", typ="Regulation", rank="R4", conf="Low")])
    env = {**os.environ, "GIA_NO_FSYNC": "1", "PYTHONUTF8": "1"}
    r = subprocess.run([sys.executable, str(BRAIN), "contradictions", str(lib), "--include-unconfirmed"], capture_output=True, text=True, env=env, encoding="utf-8")
    assert r.returncode == 1 and '"include_unconfirmed": true' in r.stdout
    r = subprocess.run([sys.executable, str(BRAIN), "contradictions", str(lib)], capture_output=True, text=True, env=env, encoding="utf-8")
    assert r.returncode == 0
