"""Tests for the library brain: shelving, confidentiality, recall trust labels, memory loop, guard."""
import json, os, shutil, subprocess, sys
from pathlib import Path
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import akos_graph as ag  # noqa: E402
import brain  # noqa: E402

FIX = Path(__file__).parent / "fixtures" / "cld_kg.json"
ENV_KEYS = ["GEMINI_API_KEY", "GOOGLE_API_KEY", "MOONSHOT_API_KEY", "ANTHROPIC_API_KEY", "OPENAI_API_KEY",
            "DEEPSEEK_API_KEY", "AZURE_OPENAI_API_KEY", "AZURE_OPENAI_ENDPOINT", "AWS_PROFILE", "AWS_REGION",
            "AWS_DEFAULT_REGION", "OLLAMA_BASE_URL", "OLLAMA_HOST", "GRAPHIFY_QUERY_LOG", "GRAPHIFY_QUERY_LOG_ENABLE"]


@pytest.fixture(autouse=True)
def clean_env(monkeypatch):
    for k in ENV_KEYS:
        monkeypatch.delenv(k, raising=False)


def node(i, typ, label, conf="100%", ent="Group", **kw):
    return {"id": i, "type": typ, "label": label, "entity": ent, "created_date": "2026-10-01",
            "confidence": conf, "source_location": "https://portal.example/x", **kw}


def edge(a, b, rel="relates_to", conf="High"):
    return {"from": a, "to": b, "relationship": rel, "evidence": "ev", "confidence": conf}


@pytest.fixture
def lib(tmp_path):
    L = tmp_path / "lib"
    brain.init_library(L)
    brain.add_shelf(L, "mkapl-dc-clrw", "engagement", "MKAPL-DC")
    shutil.copy(FIX, L / "shelves" / "mkapl-dc-clrw" / "KNOWLEDGE_GRAPH.json")
    brain.add_shelf(L, "tn-statutory", "statutory", "Group", review_days=90, jurisdiction="Tamil Nadu")
    kg = {"engagement": "tn-statutory", "confidential": False, "last_updated": "2026-10-01", "nodes": [
        node("REG-TN-MW", "Regulation", "Tamil Nadu minimum wages notification", review_by="2026-04-01"),
        node("REG-TN-PT", "Regulation", "Tamil Nadu professional tax slab", review_by="2027-04-01"),
        node("REG-TN-LWF", "Regulation", "Tamil Nadu labour welfare fund rate")],
        "edges": [edge("REG-TN-MW", "REG-TN-PT"), edge("REG-TN-PT", "REG-TN-LWF")]}
    ag.atomic_write_json(L / "shelves" / "tn-statutory" / "KNOWLEDGE_GRAPH.json", kg)
    brain.add_shelf(L, "inv-mksdl-01", "investigation", "MKSDL")
    inv = {"engagement": "inv-mksdl-01", "confidential": True, "last_updated": "2026-10-01", "nodes": [
        node("ALG-01", "Issue", "Alleged tooling kickback via vendor", conf="Medium", ent="MKSDL", status="ALLEGED"),
        node("VND-01", "Vendor", "Tooling vendor X", conf="High", ent="MKSDL")],
        "edges": [edge("ALG-01", "VND-01", "affects", "Medium")]}
    ag.atomic_write_json(L / "shelves" / "inv-mksdl-01" / "KNOWLEDGE_GRAPH.json", inv)
    return L


# ---- init / shelf-add -------------------------------------------------------------
def test_init_refuses_second_init(tmp_path):
    brain.init_library(tmp_path / "l")
    with pytest.raises(brain.BrainError, match="already"):
        brain.init_library(tmp_path / "l")


def test_not_a_library(tmp_path):
    with pytest.raises(brain.BrainError, match="not a brain library"):
        brain.load_manifest(tmp_path)


def test_shelf_validation(lib):
    for bad in ("Bad Name", "../escape", "-x", ""):
        with pytest.raises(brain.BrainError):
            brain.add_shelf(lib, bad, "engagement", "Group")
    with pytest.raises(brain.BrainError, match="not in config/entities.json"):
        brain.add_shelf(lib, "pl-audit", "engagement", "Perfect Longevity ZZ")
    with pytest.raises(brain.BrainError, match="already exists"):
        brain.add_shelf(lib, "tn-statutory", "statutory", "Group")
    with pytest.raises(brain.BrainError, match="kind"):
        brain.add_shelf(lib, "x1", "weird", "Group")


def test_investigation_is_always_confidential(lib):
    assert brain.shelf_meta(lib, "inv-mksdl-01")["confidential"] is True
    meta = brain.add_shelf(lib, "inv-two", "investigation", "MKSDL", confidential=False)
    assert meta["confidential"] is True


# ---- index -------------------------------------------------------------------------
def test_global_graph_excludes_confidential_and_namespaces_ids(lib):
    rep = brain.index_library(lib)
    g = json.loads((lib / "index/global/global_kg.json").read_text())
    shelves = {n["shelf"] for n in g["nodes"]}
    assert shelves == {"mkapl-dc-clrw", "tn-statutory"}
    assert all("::" in n["id"] for n in g["nodes"])
    assert rep["global"]["excluded"] == [{"shelf": "inv-mksdl-01", "reason": "confidential"}]
    assert rep["shelves"]["inv-mksdl-01"]["status"] == "INDEXED"  # still gets its OWN graph
    assert (lib / "shelves/inv-mksdl-01/graphify-out/graph.json").exists()


def test_id_collisions_across_shelves_do_not_merge(lib):
    brain.add_shelf(lib, "mkapl-dc-copy", "engagement", "MKAPL-DC")
    shutil.copy(FIX, lib / "shelves/mkapl-dc-copy/KNOWLEDGE_GRAPH.json")  # identical AKOS ids
    brain.index_library(lib)
    g = json.loads((lib / "index/global/global_kg.json").read_text())
    ids = [n["id"] for n in g["nodes"] if n["id"].endswith("CTRL-CLD-01")]
    assert sorted(ids) == ["mkapl-dc-clrw::CTRL-CLD-01", "mkapl-dc-copy::CTRL-CLD-01"]


def test_index_is_idempotent_and_handles_empty_and_corrupt_shelf(lib):
    brain.add_shelf(lib, "empty-one", "reference", "Group")
    (lib / "shelves/tn-statutory/KNOWLEDGE_GRAPH.json").write_text("{broken")
    rep = brain.index_library(lib)
    assert rep["shelves"]["empty-one"]["status"] == "EMPTY"
    assert rep["shelves"]["tn-statutory"]["status"] == "ERROR"
    assert rep["shelves"]["mkapl-dc-clrw"]["status"] == "INDEXED"


# ---- recall ------------------------------------------------------------------------
def test_recall_finds_by_akos_id_with_trust_and_neighbors(lib):
    r = brain.recall(lib, "what tests CTRL-CLD-01 written service agreement")
    top = r["results"][0]
    assert top["id"] == "CTRL-CLD-01" and top["trust"] == "CONFIRMED"
    assert any(n["relationship"] == "tested_by" for n in top["neighbors"])
    assert "inv-mksdl-01" not in r["shelves_searched"]


def test_recall_default_never_returns_confidential(lib):
    r = brain.recall(lib, "tooling kickback vendor")
    assert not [x for x in r["results"] if x["shelf"] == "inv-mksdl-01"]


def test_recall_named_confidential_shelf_alone_is_allowed_and_labels_alleged(lib):
    r = brain.recall(lib, "tooling kickback", shelves=["inv-mksdl-01"])
    assert r["results"][0]["id"] == "ALG-01" and r["results"][0]["trust"] == "INDICATOR"


def test_recall_refuses_confidential_combined_with_others(lib):
    with pytest.raises(brain.BrainError, match="confidential"):
        brain.recall(lib, "tooling", shelves=["inv-mksdl-01", "tn-statutory"])


def test_recall_unknown_shelf_and_min_confidence(lib):
    with pytest.raises(brain.BrainError, match="unknown shelf"):
        brain.recall(lib, "x", shelves=["nope"])
    hi = brain.recall(lib, "CLRA 1970 non-compliance risk", min_conf="100%")
    assert all(x["confidence"] == "100%" for x in hi["results"])


def test_recall_flags_stale_and_undated_statutory(lib):
    r = brain.recall(lib, "Tamil Nadu", today="2026-10-03", limit=10)
    state = {x["id"]: x["stale"] for x in r["results"]}
    assert state["REG-TN-MW"] == "STALE" and state["REG-TN-LWF"] == "UNDATED" and state["REG-TN-PT"] is None


def test_recall_no_match_returns_empty_not_guess(lib):
    assert brain.recall(lib, "zzzz qqqq")["results"] == []


def test_proposed_and_memory_items_are_indicators(lib):
    kg = brain.shelf_kg(lib, "mkapl-dc-clrw")
    kg["nodes"].append(node("DOC-NEW", "Document", "Unreviewed scrap procedure", conf="Medium",
                            ent="MKAPL-DC", status="PROPOSED"))
    ag.atomic_write_json(lib / "shelves/mkapl-dc-clrw/KNOWLEDGE_GRAPH.json", kg)
    assert brain.recall(lib, "scrap procedure")["results"][0]["trust"] == "INDICATOR"


# ---- remember / reflect -------------------------------------------------------------
def test_remember_saves_indicator_and_translates_known_ids(lib):
    r = brain.remember(lib, "mkapl-dc-clrw", "Which control covers service agreements?", "CTRL-CLD-01",
                       "useful", nodes=["CTRL-CLD-01", "NOT-A-NODE"])
    assert r["trust"] == "indicator" and r["unknown_nodes"] == ["NOT-A-NODE"]
    f = Path(r["saved"])
    assert f.exists() and "[CTRL-CLD-01] Written Service Agreement Requirement" in f.read_text()
    idx = json.loads((lib / "shelves/mkapl-dc-clrw/memory_index.json").read_text())
    assert idx[0]["outcome"] == "useful" and idx[0]["trust"] == "indicator"


def test_remember_validation(lib):
    with pytest.raises(brain.BrainError, match="requires --correction"):
        brain.remember(lib, "mkapl-dc-clrw", "q", "a", "corrected")
    with pytest.raises(brain.BrainError, match="outcome"):
        brain.remember(lib, "mkapl-dc-clrw", "q", "a", "great")
    with pytest.raises(brain.BrainError, match="non-empty"):
        brain.remember(lib, "mkapl-dc-clrw", "  ", "a", "useful")
    with pytest.raises(brain.BrainError, match="unknown shelf"):
        brain.remember(lib, "ghost", "q", "a", "useful")


def test_reflect_produces_graphify_lessons_and_proposed_lessons_only(lib):
    brain.index_library(lib)
    for _ in range(2):
        brain.remember(lib, "mkapl-dc-clrw", "Which control covers service agreements?", "CTRL-CLD-01",
                       "useful", nodes=["CTRL-CLD-01"])
    brain.remember(lib, "mkapl-dc-clrw", "Is CLRA licence required for all contractors?", "Yes for all",
                   "corrected", correction="Only above the notified headcount threshold - check portal")
    brain.remember(lib, "inv-mksdl-01", "Is vendor X linked to ALG-01?", "Possibly", "dead_end")
    rep = brain.reflect(lib)
    assert rep["shelves"]["mkapl-dc-clrw"]["status"] == "OK"
    assert Path(rep["shelves"]["mkapl-dc-clrw"]["lessons"]).read_text().strip()
    txt = Path(rep["proposed_lessons"]).read_text()
    assert "NOT standing rules" in txt and "notified headcount threshold" in txt
    # v2.0 (issue I-18): confidential lesson text must NOT land in the shared file. It stays inside its own shelf.
    assert "Is vendor X linked to ALG-01?" not in txt and "withheld" in txt
    shelf_file = lib / "shelves/inv-mksdl-01/PROPOSED_LESSONS.md"
    assert "Is vendor X linked to ALG-01?" in shelf_file.read_text() and "CONFIDENTIAL" in shelf_file.read_text()
    if os.name == "posix": assert (shelf_file.stat().st_mode & 0o077) == 0
    assert not (lib / "lessons" / "LESSONS_LEARNED.md").exists()  # reflect never writes governance


def test_reflect_with_no_memory(lib):
    assert brain.reflect(lib)["shelves"]["tn-statutory"]["status"] == "NO_MEMORY"


# ---- stale / status ------------------------------------------------------------------
def test_stale_report_item_states(lib):
    rep = brain.stale_report(lib, "2026-10-03")
    states = {i["id"]: i["state"] for i in rep["items"]}
    assert states["REG-TN-MW"] == "STALE" and states["REG-TN-LWF"] == "UNDATED"
    assert "REG-TN-PT" not in states and "(shelf)" not in states       # shelf refreshed 2 days ago: fresh


def test_stale_shelf_age_flagged_when_past_review_days(lib):
    rep = brain.stale_report(lib, "2027-01-15")                         # 106 days > review_days 90
    assert any(i["id"] == "(shelf)" and i["state"] == "STALE" for i in rep["items"])


def test_stale_cli_strict_exit_code(lib):
    r = subprocess.run([sys.executable, str(ROOT / "scripts/brain.py"), "stale", str(lib), "--today", "2026-10-03",
                        "--strict"], capture_output=True, text=True)
    assert r.returncode == 1
    r = subprocess.run([sys.executable, str(ROOT / "scripts/brain.py"), "stale", str(lib), "--today", "2026-10-03"],
                       capture_output=True, text=True)
    assert r.returncode == 0


def test_status_shape_and_unreadable_shelf(lib):
    brain.index_library(lib)
    (lib / "shelves/tn-statutory/KNOWLEDGE_GRAPH.json").write_text("{broken")
    st = brain.status(lib, "2026-10-03")
    rows = {r["shelf"]: r for r in st["shelves"]}
    assert rows["tn-statutory"]["status"] == "UNREADABLE" and rows["tn-statutory"]["confidential"] is True
    assert rows["mkapl-dc-clrw"]["nodes"] == 5 and st["last_index"]


# ---- guard -----------------------------------------------------------------------------
def gcodes(lib):
    return {i["code"]: i["severity"] for i in brain.guard(lib)}


def test_guard_clean_library(lib):
    brain.index_library(lib)
    assert gcodes(lib) == {}


def test_guard_detects_confidential_leak_into_global(lib):
    brain.index_library(lib)
    gk = lib / "index/global/global_kg.json"
    g = json.loads(gk.read_text())
    g["nodes"].append({**node("ALG-01", "Issue", "leak", conf="Medium"), "shelf": "inv-mksdl-01"})
    gk.write_text(json.dumps(g))
    assert gcodes(lib)["CONFIDENTIAL_IN_GLOBAL"] == "ERROR"


def test_guard_detects_unisolated_investigation(lib):
    m = json.loads((lib / "shelves/inv-mksdl-01/shelf.json").read_text())
    m["confidential"] = False
    (lib / "shelves/inv-mksdl-01/shelf.json").write_text(json.dumps(m))
    assert gcodes(lib)["INVESTIGATION_NOT_ISOLATED"] == "ERROR"


def test_guard_blocks_gemini_autoselect_even_when_anthropic_key_also_set(lib, monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "x")
    monkeypatch.setenv("GEMINI_API_KEY", "y")       # graphify picks gemini FIRST (gemini > kimi > claude ...)
    assert gcodes(lib)["EXTRACT_BACKEND_NOT_ALLOWED"] == "ERROR"


def test_guard_allows_claude_only_and_ollama(lib, monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "x")
    assert "EXTRACT_BACKEND_NOT_ALLOWED" not in gcodes(lib)
    monkeypatch.delenv("ANTHROPIC_API_KEY")
    monkeypatch.setenv("OLLAMA_BASE_URL", "http://localhost:11434")
    assert "EXTRACT_BACKEND_NOT_ALLOWED" not in gcodes(lib)


def test_guard_warns_on_query_log(lib, monkeypatch):
    monkeypatch.setenv("GRAPHIFY_QUERY_LOG_ENABLE", "1")
    assert gcodes(lib)["QUERY_LOG_ENABLED"] == "WARN"


def test_guard_backend_check_only_matters_when_a_confidential_shelf_exists(tmp_path, monkeypatch):
    L = tmp_path / "plain"
    brain.init_library(L)
    brain.add_shelf(L, "pol", "policy", "Group")
    monkeypatch.setenv("GEMINI_API_KEY", "y")
    assert gcodes(L) == {}


def test_guard_flags_unreadable_shelf_and_fails_closed(lib):
    (lib / "shelves/tn-statutory/KNOWLEDGE_GRAPH.json").write_text("{broken")
    assert gcodes(lib)["SHELF_UNREADABLE"] == "ERROR"


# ---- mcp-config ---------------------------------------------------------------------
def test_mcp_config_requires_index_then_points_at_global_graph(lib):
    with pytest.raises(brain.BrainError, match="run: brain.py index"):
        brain.mcp_config(lib)
    brain.index_library(lib)
    cfg = brain.mcp_config(lib)
    args = cfg["mcpServers"]["mktron-library-brain"]["args"]
    assert args[:2] == ["-m", "graphify.serve"] and Path(args[2]).as_posix().endswith("index/global/graphify-out/graph.json")
    assert "inv-mksdl-01" not in json.dumps(cfg)


# ---- CLI end to end --------------------------------------------------------------------
def run(*a):
    return subprocess.run([sys.executable, str(ROOT / "scripts/brain.py"), *map(str, a)], capture_output=True, text=True)


def test_cli_end_to_end(tmp_path):
    L = tmp_path / "L"
    assert run("init", L).returncode == 0
    assert run("shelf-add", L, "e1", "--kind", "engagement", "--entity", "MKAPL-DC").returncode == 0
    shutil.copy(FIX, L / "shelves/e1/KNOWLEDGE_GRAPH.json")
    assert run("index", L).returncode == 0
    r = run("recall", L, "written service agreement control")
    assert r.returncode == 0 and json.loads(r.stdout)["results"][0]["id"] == "CTRL-CLD-01"
    assert run("remember", L, "--shelf", "e1", "--question", "q?", "--answer", "a", "--outcome", "useful").returncode == 0
    assert run("guard", L).returncode == 0
    assert run("status", L).returncode == 0


def test_cli_errors_exit_2(tmp_path):
    assert run("status", tmp_path).returncode == 2
    L = tmp_path / "L"
    run("init", L)
    assert run("shelf-add", L, "BAD NAME", "--kind", "policy", "--entity", "Group").returncode == 2
