#!/usr/bin/env python3
"""install.py - install the MKTron GIA skill (and optionally its slash commands), safely.

DRY RUN by default: it shows what it WOULD do and changes nothing. Add --apply to install.

  python3 install.py                              # dry run, personal Claude Code skills folder (~/.claude/skills)
  python3 install.py --apply                      # install the skill
  python3 install.py --apply --with-commands      # also install the 18 slash commands
  python3 install.py --apply --project .          # install into ./.claude/ for one project instead
  python3 install.py --apply --dest /some/skills  # install into any skills folder
  python3 install.py --uninstall                  # remove it and restore anything it replaced
  python3 install.py --make-upload-zip out.zip    # build the ZIP for claude.ai: Settings > Capabilities > Skills > Upload
  python3 install.py --verify-bundle              # check this bundle's files against MANIFEST.sha256

Safety: anything it replaces is copied to <claude dir>/gia-install-backup-<time>/ first; a journal records every change so
--uninstall can undo it exactly; installing twice changes nothing; after --apply it runs the skill's own self-checks.
Needs Python 3.10+ and openpyxl for the Excel outputs; graphify only for to-graphify / index / remember (see INSTALL.md).
"""
from __future__ import annotations

import argparse, hashlib, json, os, re, shutil, subprocess, sys, tempfile, time, zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
SKILL_SRC = HERE / "skill" / "akos-graphify-bridge"
CMD_SRC = HERE / "plugin" / "akos-graph" / "commands"
NAME = "akos-graphify-bridge"
PLACEHOLDER = "${CLAUDE_PLUGIN_ROOT}/skills/akos-graphify-bridge"
JOURNAL = ".gia-install-journal.json"
SMOKE_KG = {"engagement": "install smoke test", "nodes": [
    {"id": "A", "type": "Risk", "label": "a", "entity": "Group", "created_date": "2026-01-01", "confidence": "High", "source_location": "x"},
    {"id": "B", "type": "Control", "label": "b", "entity": "Group", "created_date": "2026-01-01", "confidence": "High", "source_location": "x"}],
    "edges": [{"from": "A", "to": "B", "relationship": "mitigates", "evidence": "e", "confidence": "High"}]}


def tree_hash(p: Path) -> str:
    h = hashlib.sha256()
    for f in sorted(x for x in p.rglob("*") if x.is_file() and "__pycache__" not in x.parts and not x.name.endswith(".pyc")):
        h.update(str(f.relative_to(p)).encode()); h.update(hashlib.sha256(f.read_bytes()).digest())
    return h.hexdigest()


def claude_dir(a) -> Path:
    if a.project:
        return Path(a.project).resolve() / ".claude"
    return Path(a.home).expanduser() / ".claude" if a.home else Path.home() / ".claude"


def say(status, msg): print(f"[{status:<9}] {msg}")


def preflight() -> bool:
    ok = True
    if sys.version_info < (3, 10):
        say("FAIL", f"Python {sys.version_info.major}.{sys.version_info.minor} found; 3.10 or newer is required"); ok = False
    else:
        say("OK", f"Python {sys.version_info.major}.{sys.version_info.minor}")
    p3 = shutil.which("python3")
    if os.name == "nt" and p3 and "WindowsApps" in p3:
        say("WARN", f"`python3` on your PATH is the Microsoft Store stub ({p3}); it does not run Python. The installed slash commands carry a Windows "
                    "fallback (`py -3` or `python`), and this installer itself is running fine. To make `python3` work: Settings > Apps > Advanced app "
                    "settings > App execution aliases > turn off python3.exe.")
    try:
        import openpyxl  # noqa: F401
        say("OK", "openpyxl (Excel outputs)")
    except ImportError:
        say("WARN", "openpyxl missing: dashboard and export-xlsx need it  ->  pip install openpyxl")
    try:
        import graphify  # noqa: F401
        say("OK", "graphify (needed for to-graphify, index, remember)")
    except ImportError:
        say("WARN", "graphify not installed: validate, recall, seal, verify, deliverable, export-xlsx still work; "
                    "to-graphify / index / remember need it  ->  pip install -e <graphify checkout>")
    return ok


def find_duplicates(a, target: Path) -> list[Path]:
    """Other installed copies of this skill (a plugin, an account upload, another skills folder). Two copies = two routers
    for the same prompts, the 'duplicate master' problem the portfolio rules warn about."""
    home = Path(a.home).expanduser() if a.home else Path.home()
    cdir = claude_dir(a)
    roots = [cdir / "plugins", cdir / "skills", home / "AppData/Roaming/Claude/rpm", home / "Library/Application Support/Claude/rpm",
             home / ".config/Claude/rpm"] + [Path(x) for x in os.environ.get("GIA_DUP_SCAN_EXTRA", "").split(os.pathsep) if x]
    found = []
    for r in roots:
        if not r.exists():
            continue
        for f in r.rglob("SKILL.md"):
            if target in f.parents or "gia-install-backup" in str(f):
                continue
            try:
                head = f.read_text(encoding="utf-8", errors="replace")[:600]
            except OSError:
                continue
            if re.search(rf"^name:\s*[\"']?{re.escape(NAME)}[\"']?\s*$", head, re.M):
                found.append(f.parent)
    return found


def build_upload_zip(out: Path) -> Path:
    out = Path(out)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(SKILL_SRC.rglob("*")):
            if f.is_file() and "__pycache__" not in f.parts and not f.name.endswith(".pyc"):
                z.write(f, Path(NAME) / f.relative_to(SKILL_SRC))
    return out


def smoke(skill_dir: Path) -> bool:
    ok = True
    with tempfile.TemporaryDirectory() as d:
        kg = Path(d) / "k.json"; kg.write_text(json.dumps(SMOKE_KG))
        env = {**os.environ, "GIA_NO_FSYNC": "1", "PYTHONUTF8": "1"}
        r = subprocess.run([sys.executable, str(skill_dir / "scripts/akos_graph.py"), "validate", str(kg), "--gate", "final"], capture_output=True, text=True, encoding="utf-8", errors="replace", env=env)
        say("OK" if r.returncode == 0 else "FAIL", "self-check: validate a sample Knowledge Graph at the FINAL gate"); ok &= r.returncode == 0
        lib = Path(d) / "lib"
        for label, args in (("self-check: create a library", ["init", str(lib)]), ("self-check: add a shelf", ["shelf-add", str(lib), "demo", "--kind", "reference", "--entity", "Group"]),
                            ("self-check: audit trail verifies", ["verify", str(lib)])):
            r = subprocess.run([sys.executable, str(skill_dir / "scripts/brain.py"), *args], capture_output=True, text=True, encoding="utf-8", errors="replace", env=env)
            say("OK" if r.returncode == 0 else "FAIL", label); ok &= r.returncode == 0
    r = subprocess.run([sys.executable, str(skill_dir / "scripts/brain.py"), "doctor"], capture_output=True, text=True, encoding="utf-8", errors="replace")
    fails = [l for l in r.stdout.splitlines() if l.startswith("[FAIL")]
    say("OK" if not fails else "WARN", "doctor: " + ("no failures" if not fails else "; ".join(l.split("]", 1)[1].strip()[:70] for l in fails)))
    return ok


def render_command(text: str, skill_dir: Path) -> str:
    return text.replace(PLACEHOLDER, str(skill_dir).replace("\\", "/"))


def install(a) -> int:
    cdir = claude_dir(a)
    skills = Path(a.dest).expanduser().resolve() if a.dest else cdir / "skills"
    target = skills / NAME
    cmds = cdir / "commands"
    print(f"skill folder : {target}\ncommands     : {cmds if a.with_commands else '(not requested)'}\nmode         : {'APPLY' if a.apply else 'DRY RUN (nothing will change)'}\n")
    if not preflight():
        return 2
    if not SKILL_SRC.exists():
        say("FAIL", f"{SKILL_SRC} not found: run this from the unzipped bundle"); return 2
    dups = find_duplicates(a, target)
    for d in dups:
        say("DUPLICATE", f"{NAME} is already installed at {d}")
    if dups and a.apply and not a.allow_duplicate:
        say("REFUSED", "a second copy would give two routers for the same prompts. Update the existing copy through its own channel "
                       "(plugin / account upload), or re-run with --allow-duplicate if you really want both.")
        return 2
    plan = []
    same = target.exists() and tree_hash(target) == tree_hash(SKILL_SRC)
    plan.append(("skill", target, "ALREADY INSTALLED" if same else ("REPLACE (old copy backed up)" if target.exists() else "INSTALL")))
    cmd_files = sorted(CMD_SRC.glob("*.md")) if a.with_commands else []
    for f in cmd_files:
        dst = cmds / f.name
        new = render_command(f.read_text(encoding="utf-8"), target)
        plan.append(("command", dst, "ALREADY INSTALLED" if dst.exists() and dst.read_text(encoding="utf-8") == new else ("REPLACE (backed up)" if dst.exists() else "INSTALL")))
    print()
    for kind, path, what in plan:
        say(what.split(" ")[0], f"{kind}: {path}")
    if not a.apply:
        print("\nDry run only. Re-run with --apply to install."); return 0
    backup = cdir / f"gia-install-backup-{time.strftime('%Y%m%d-%H%M%S')}"
    jf = cdir / JOURNAL
    journal = json.loads(jf.read_text()) if jf.exists() else {"entries": []}
    def keep(path: Path):
        if path.exists():
            dst = backup / path.relative_to(cdir if str(path).startswith(str(cdir)) else path.anchor)
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copytree(path, dst) if path.is_dir() else shutil.copy2(path, dst)
            return str(dst)
        return None
    if not same:
        b = keep(target)
        staging = target.with_name(f".{NAME}.new-{os.getpid()}"); shutil.rmtree(staging, ignore_errors=True)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(SKILL_SRC, staging, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "tests", "evals") if not a.with_tests else shutil.ignore_patterns("__pycache__", "*.pyc"))
        if target.exists():
            shutil.rmtree(target)
        os.rename(staging, target)
        journal["entries"].append({"kind": "skill", "path": str(target), "backup": b}); say("DONE", f"installed skill -> {target}")
    for f in cmd_files:
        dst = cmds / f.name; new = render_command(f.read_text(encoding="utf-8"), target)
        if dst.exists() and dst.read_text(encoding="utf-8") == new:
            continue
        b = keep(dst); cmds.mkdir(parents=True, exist_ok=True); dst.write_text(new, encoding="utf-8")
        journal["entries"].append({"kind": "command", "path": str(dst), "backup": b})
    if cmd_files:
        say("DONE", f"installed {len(cmd_files)} slash commands -> {cmds}")
    cdir.mkdir(parents=True, exist_ok=True); jf.write_text(json.dumps(journal, indent=2))
    print()
    ok = smoke(target)
    print("\n" + ("INSTALL OK. Restart or open a new session so Claude picks the skill up." if ok else "INSTALLED, BUT A SELF-CHECK FAILED (see above)."))
    return 0 if ok else 1


def uninstall(a) -> int:
    cdir = claude_dir(a); jf = cdir / JOURNAL
    if not jf.exists():
        say("NOTHING", f"no install journal at {jf}"); return 0
    journal = json.loads(jf.read_text())
    for e in reversed(journal["entries"]):
        p = Path(e["path"])
        if p.exists():
            shutil.rmtree(p) if p.is_dir() else p.unlink()
        if e.get("backup") and Path(e["backup"]).exists():
            shutil.copytree(e["backup"], p) if Path(e["backup"]).is_dir() else shutil.copy2(e["backup"], p)
            say("RESTORED", str(p))
        else:
            say("REMOVED", str(p))
    jf.unlink()
    return 0


def verify_bundle() -> int:
    mf = HERE / "MANIFEST.sha256"
    if not mf.exists():
        say("FAIL", "MANIFEST.sha256 missing"); return 2
    want = {l.split("  ", 1)[1]: l.split("  ", 1)[0] for l in mf.read_text().splitlines() if "  " in l}
    have = {p.relative_to(HERE).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in HERE.rglob("*")
            if p.is_file() and p.name != "MANIFEST.sha256" and "__pycache__" not in p.parts and not p.name.endswith(".pyc")}
    bad = sorted(set(want) ^ set(have)) + sorted(k for k in set(want) & set(have) if want[k] != have[k])
    say("OK" if not bad else "FAIL", f"{len(want)} files verified" if not bad else f"mismatch: {bad[:5]}")
    return 0 if not bad else 1


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0], formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__.split("\n", 1)[1])
    ap.add_argument("--apply", action="store_true"); ap.add_argument("--with-commands", action="store_true"); ap.add_argument("--with-tests", action="store_true")
    ap.add_argument("--project", help="install into <dir>/.claude instead of your personal ~/.claude"); ap.add_argument("--dest", help="install into this skills folder")
    ap.add_argument("--home", help=argparse.SUPPRESS); ap.add_argument("--uninstall", action="store_true"); ap.add_argument("--make-upload-zip", metavar="OUT.zip")
    ap.add_argument("--verify-bundle", action="store_true")
    ap.add_argument("--allow-duplicate", action="store_true", help="install even if another copy of the skill exists")
    a = ap.parse_args(argv)
    if a.verify_bundle: return verify_bundle()
    if a.make_upload_zip:
        z = build_upload_zip(Path(a.make_upload_zip)); print(f"built {z} ({z.stat().st_size // 1024} KB). In claude.ai: Settings > Capabilities > Skills > Upload skill."); return 0
    return uninstall(a) if a.uninstall else install(a)


if __name__ == "__main__":
    sys.exit(main())
